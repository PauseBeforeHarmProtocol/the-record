# NATIONAL update pack

Release: 10.52.0 · September 13, 2026
Editorial cutoff: 2026-09-13 11:59 AM EDT
Contains 189 national records. 3 records were added or materially refreshed in this run.
