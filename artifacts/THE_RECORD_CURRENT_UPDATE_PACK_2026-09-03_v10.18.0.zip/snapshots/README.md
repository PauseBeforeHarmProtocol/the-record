# Preserved snapshots

`THE_RECORD_IN6_UPDATE_BRIEF_2026-07-18.md` is the immutable July 18 IN-6 brief. The current canonical IN-6 brief for release 10.18.0 is `../THE_RECORD_IN6_CURRENT_BRIEF_2026-09-03_v10.18.0.md`. The snapshot and current per-entry packs must not be treated as one contemporaneous package.
