# The Record current update pack

Release: 8.2.0
Release date: August 24, 2026
Checked: 2026-08-24 5:58 PM EDT

Contains 23 national and 4 IN-6 current-layer records. The complete Trump archive consumes the national layer through current_layer_bridge.js while its historical body remains stable.
