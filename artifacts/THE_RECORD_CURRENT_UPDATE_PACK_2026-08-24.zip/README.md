# The Record current update pack

Release: 8.2.1
Release date: August 24, 2026
Checked: 2026-08-24 5:58 PM EDT

Contains 23 national and 4 IN-6 current-layer records. The full searchable Trump archive renders 4,667 active canonical/bridged entries. It retains 3 duplicate tombstones outside that count. External archive units and normalized crosslinks remain separate until source review and deduplication promote a distinct event.
