# The Record current update pack

Release: 8.1.0
Release date: August 24, 2026
Checked: 2026-08-24 10:43 AM EDT

Contains 19 national and 4 IN-6 current-layer records. The complete Trump archive consumes the national layer through current_layer_bridge.js while its historical body remains stable.
