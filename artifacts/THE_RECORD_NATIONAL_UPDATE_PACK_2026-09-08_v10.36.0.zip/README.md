# NATIONAL update pack

Release: 10.36.0 · September 8, 2026
Editorial cutoff: 2026-09-08 11:58 AM EDT
Contains 152 national records. 4 records were added or materially refreshed in this run.
