# The Record current update pack

Release: 8.5.0
Release date: August 26, 2026
Checked: 2026-08-26 12:01 AM EDT

Contains 27 national and 4 IN-6 current-layer records. The full searchable Trump archive renders 4,671 active canonical/bridged entries. It retains 3 duplicate tombstones outside that count. External archive units and normalized crosslinks remain separate until source review and deduplication promote a distinct event.
