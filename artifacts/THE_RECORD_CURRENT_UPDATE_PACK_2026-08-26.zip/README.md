# The Record current update pack

Release: 8.6.0
Release date: August 26, 2026
Checked: 2026-08-26 5:58 AM EDT

Contains 28 national and 4 IN-6 current-layer records. The full searchable Trump archive renders 4,672 active canonical/bridged entries. It retains 3 duplicate tombstones outside that count. External archive units and normalized crosslinks remain separate until source review and deduplication promote a distinct event.
