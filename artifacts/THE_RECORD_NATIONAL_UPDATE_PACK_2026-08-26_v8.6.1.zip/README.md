# NATIONAL update pack

Release: 8.6.1 · August 26, 2026
Editorial cutoff: 2026-08-26 5:58 AM EDT
Contains 28 national records. The factual and Maybe / Therefore content of the 1 base editorial records is carried forward from release 8.6.0; review-status metadata is materialized separately, and this maintenance remediates Maybe / Therefore reasoning in 24 current records and does not imply a new post-cutoff finding.
