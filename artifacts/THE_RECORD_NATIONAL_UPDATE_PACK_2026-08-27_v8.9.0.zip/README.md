# NATIONAL update pack

Release: 8.9.0 · August 27, 2026
Editorial cutoff: 2026-08-27 12:00 AM EDT
Contains 38 national records. 2 records were added or materially refreshed in this run.
