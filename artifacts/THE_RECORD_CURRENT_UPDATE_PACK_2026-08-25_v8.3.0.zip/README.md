# The Record current update pack

Release: 8.3.0
Release date: August 25, 2026
Checked: 2026-08-25 11:58 AM EDT

Contains 23 national and 4 IN-6 current-layer records. The full searchable Trump archive renders 4,667 active canonical/bridged entries. It retains 3 duplicate tombstones outside that count. External archive units and normalized crosslinks remain separate until source review and deduplication promote a distinct event.
