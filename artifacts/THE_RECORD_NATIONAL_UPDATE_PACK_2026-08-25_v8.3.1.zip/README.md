# NATIONAL update pack

Release: 8.3.1 · August 25, 2026
Editorial cutoff: 2026-08-25 11:58 AM EDT
Contains 23 national records. The factual and Maybe / Therefore content of the 2 base editorial records is carried forward from release 8.3.0; review-status metadata is materialized separately, and this maintenance remediates Maybe / Therefore reasoning in 25 current records and does not imply a new post-cutoff finding.
