# The Record current update pack

Release candidate: 8.0.1-rc1
Release date: July 19, 2026
Checked: 2026-07-19 08:15 AM EDT

Contains the six national and four IN-6 current-layer records. Historical archives remain separate and preserved.
