# NATIONAL update pack

Release: 10.42.0 · September 10, 2026
Editorial cutoff: 2026-09-10 12:02 AM EDT
Contains 166 national records. 4 records were added or materially refreshed in this run.
