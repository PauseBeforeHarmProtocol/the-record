# NATIONAL update pack

Release: 10.19.0 · September 3, 2026
Editorial cutoff: 2026-09-03 6:02 PM EDT
Contains 118 national records. 7 records were added or materially refreshed in this run.
