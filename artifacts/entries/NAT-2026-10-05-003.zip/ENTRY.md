# Trump calls for media outlets to be arrested over rally reporting

**Entry ID:** NAT-2026-10-05-003
**Date:** October 5, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** retained presidential post text plus independent The Hill and TheWrap reporting; publication and public arrest call established, attached audiovisual content pending and enforcement consequences unestablished in inspected material
**Review state:** current-standard-reviewed

The president publicly advocated arrests while disputing Ohio rally coverage; the inspected post supplies no statute or enforcement directive, and does not establish arrests or charges.

## THE FACTS

- At 1:57:25 PM EDT on October 5, Trump published a Truth Social post saying The New York Times and other media outlets should be arrested over reporting about attendance at his Ohio rally. The validated retained post supplies the publication timestamp and text; its attached video was not fully reviewed.
- Trump justified the call by accusing the outlets of dishonesty and disservice to the country. He disputed reporting about empty seats and asserted that thousands were turned away. This record establishes his statement and stated rationale, not the truth of his attendance claims or allegations against reporters.
- The Hill, in a report syndicated by AOL, and TheWrap separately reported the arrest call on October 5 and identified its connection to the rally-coverage dispute. Their accounts corroborate the publicly attributed statement; they are separate reporting origins, rather than two copies of one syndicated article.
- The inspected post identifies no criminal statute, instruction to the Justice Department or another enforcement agency, or formal process for carrying out arrests. The reviewed source material establishes a presidential call for arrests, not a signed enforcement order, arrest or criminal charge resulting from that call.

## SIGNIFICANCE

A president publicly advocating arrests over disputed news coverage raises a material risk of using federal coercive power to pressure the press. That risk exists at the statement stage; the inspected material does not show that enforcement followed.

## GOALPOST / RESPONSE

Trump presents the call as a response to allegedly dishonest rally reporting and says the venue was full. The attendance dispute does not establish a legal basis for arrests. Any identified law, official instruction, enforcement action, judicial review, withdrawal or correction would change the evidence state and requires a separate review.

## MAYBE / THEREFORE

Maybe the language is rhetorical retaliation rather than an operational instruction, or officials may treat presidential statements as pressure to act. Therefore the evidence establishes a public presidential call for arrests over reporting and the associated press-freedom risk; it does not establish a signed order, arrests, charges, criminal liability or the truth of the crowd allegations.


## SOURCES

- [Donald J. Trump on Truth Social — media-arrest call over Ohio rally coverage](https://truthsocial.com/@realDonaldTrump/117389593495407380) — primary evidence of published presidential statement; retained text acquired from validated CNN-hosted mirror, not independent verification of crowd claims or enforcement
- [The Hill — Trump calls for media outlets to be arrested over rally coverage](https://www.aol.com/articles/trump-calls-media-outlets-arrested-204900000.html) — independent attributed reporting
- [TheWrap — Trump calls for media outlets to be arrested over rally coverage](https://www.thewrap.com/media-platforms/politics/trump-calls-media-outlet-arrests-rally-coverage/) — independent attributed reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
