# Trump signs coordinated ranching and meat-market executive orders

**Entry ID:** NAT-2026-09-04-010
**Date:** September 4, 2026
**Checked:** 2026-09-04 6:00 PM EDT
**Evidence state:** two primary presidential orders plus independent Reuters reporting; directives signed, downstream findings, rules, funding, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The orders direct enforcement, inspection and market-access work plus wolf and origin-labeling reviews; they do not themselves delist wolves, mandate labels or prove lower beef prices.

## THE FACTS

- President Trump signed two coordinated executive orders addressing ranchers, meat processing and record-high beef prices while the national cattle herd was at a 75-year low.
- The rancher order requires Agriculture, Interior, the U.S. Trade Representative, FDA and SBA to report within 90 days on regulations and policies affecting ranchers. Interior must determine within 90 days whether gray and Mexican wolves meet Endangered Species Act recovery criteria and begin a delisting or downlisting process only if it finds the criteria met.
- That order also directs consideration of revised livestock-depredation compensation and lethal-removal rules. It requires a 90-day legal and economic review of mandatory country-of-origin labeling for beef, after which agencies may propose lawful regulations or recommend legislation; it does not itself reinstate mandatory labeling.
- The meat-market order directs USDA to prioritize Packers and Stockyards Act investigations, increase enforcement capacity and coordinate with DOJ. It also directs steps to expand state participation in cooperative inspection programs, provide small-processor assistance, modernize inspection, remove requirements that do not advance essential food safety and establish a USDA coordinator.
- USDA must submit multiple enforcement and interstate-market reports within 60 days and take appropriate lawful steps to establish a guaranteed-loan program for small and regional beef processors. Both orders are subject to existing law and available appropriations, and neither identifies a new appropriation, completed loan, final wolf status, operative labeling mandate or measured price result.

## SIGNIFICANCE

The package directs concrete agency work across competition enforcement, federal inspection, interstate sales, predator policy and consumer labeling. Its material effects depend on later agency findings, rulemaking, funding and implementation, especially where the orders expressly condition action on statutory criteria or available appropriations.

## GOALPOST / RESPONSE

The administration says the orders will support ranchers, strengthen competition and processing capacity, improve origin information and lower consumer prices while maintaining food safety. The 60- and 90-day reports, enforcement matters, staffing and appropriations, inspection changes, state participation, issued loans, ESA findings and rules, labeling action, processing capacity and retail beef prices are the tests.

## MAYBE / THEREFORE

Maybe coordinated enforcement and expanded processing access will relieve bottlenecks without weakening safety or wildlife protections, or the reviews may produce little operative change and predator or inspection revisions may shift costs elsewhere. Therefore the record establishes signed directives and deadlines—not wolf delisting, mandatory origin labels, funded loans, expanded interstate sales or lower beef prices.


## SOURCES

- [White House — Supporting America's Ranchers executive order](https://www.whitehouse.gov/presidential-actions/2026/09/supporting-americas-ranchers/) — primary presidential order directing wolf-status, labeling and regulatory reviews
- [White House — livestock competition and meat-market-access executive order](https://www.whitehouse.gov/presidential-actions/2026/09/promoting-fair-competition-in-livestock-markets-and-expanding-market-access-for-american-meat-producers/) — primary presidential order directing enforcement, inspection, interstate-access and loan-program actions
- [Reuters — Trump signs ranching and meat-processing orders](https://www.reuters.com/world/us/trump-expected-sign-beef-related-executive-order-friday-sources-say-2026-09-04/) — independent reporting on the signed orders, beef-market context and unresolved labeling steps

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
