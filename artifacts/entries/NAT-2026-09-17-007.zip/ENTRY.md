# U.S. grants restricted visas to Iran's core UN delegation

**Entry ID:** NAT-2026-09-17-007
**Date:** September 17, 2026
**Checked:** 2026-09-18 5:59 AM EDT
**Evidence state:** independent Reuters and Associated Press reporting with an attributed State Department position; restricted visa approval implemented, travel and diplomatic outcomes unresolved
**Review state:** current-standard-reviewed

The approval permits General Assembly attendance under host-country obligations while limiting delegation size, travel and purchases.

## THE FACTS

- The State Department said the United States would permit Iran's core delegation to attend the United Nations General Assembly, citing U.S. obligations as the UN host country.
- Reuters and Associated Press reported that the delegation includes President Masoud Pezeshkian and Foreign Minister Abbas Araghchi. Officials discussed individual visa details anonymously because those records are confidential; the independently corroborated core action is the delegation's limited approval.
- The United States restricted the delegation's size and movements and maintained limits on shopping for luxury goods. The measures permit attendance under conditions; they do not establish unrestricted entry or a broader diplomatic agreement.
- Visa approval does not establish that every named official traveled, that meetings produced an agreement or that wider U.S. sanctions and military disputes with Iran changed.

## SIGNIFICANCE

The decision balances host-country obligations with a restrictive Iran policy and determines whether senior Iranian officials can participate in a major multilateral forum. Its diplomatic effects depend on actual attendance and any documented negotiations or outcomes.

## GOALPOST / RESPONSE

The State Department says the limited approval fulfills U.S. host-country obligations while enforcing travel and purchase restrictions. Attendance records, permitted movements, bilateral contacts, agreements and any sanctions or security changes are the tests.

## MAYBE / THEREFORE

Maybe restricted access preserves a diplomatic channel without easing broader pressure, or the limits may deepen an already adversarial relationship. Therefore the verified action is conditional visa approval for the core delegation—not unrestricted travel, a policy rapprochement or a negotiated result.


## SOURCES

- [Reuters — State Department approves restricted visas for Iran's core UN delegation](https://www.reuters.com/world/middle-east/iranian-delegation-will-be-able-attend-un-general-assembly-us-says-2026-09-17/) — independent diplomatic reporting with attributed State Department position
- [Associated Press — U.S. grants limited visas for Iranian UN General Assembly delegation](https://apnews.com/article/3f91ccc8def4a9d5499b7c8620450864) — independent diplomatic reporting on visa approval and restrictions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
