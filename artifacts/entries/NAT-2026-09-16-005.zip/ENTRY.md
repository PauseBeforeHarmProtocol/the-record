# House passes data-center Ratepayer Protection Act 417–3

**Entry ID:** NAT-2026-09-16-005
**Date:** September 16, 2026
**Checked:** 2026-09-17 12:01 PM EDT
**Evidence state:** primary House passage announcement and inspected reported bill text; House-passed, not established as enacted
**Review state:** current-standard-reviewed

The House approved a PURPA consideration standard; Senate and presidential action remain unverified.

## THE FACTS

- The House Energy and Commerce Committee recorded September 16 passage of H.R. 9340, the Ratepayer Protection Act, by 417–3 and called for Senate consideration.
- The reported text proposes recovering large-load customers’ incremental generation, transmission and distribution upgrade costs, including after departure, with advance financial assurances. Its definition covers specified information-technology facilities with aggregate peak demand of at least 100 MW at one site or campus.
- State regulators and covered nonregulated utilities would begin consideration within one year and complete it within two years of enactment, with exceptions for specified prior state actions. This is not a uniform retail rate or automatic adoption requirement.
- Sponsors say the measure protects households while supporting AI infrastructure. Neither enacted protection nor measured household savings was established by cutoff.

## SIGNIFICANCE

The vote advances a federal response to data-center cost allocation while leaving important decisions with regulators and utilities.

## GOALPOST / RESPONSE

Sponsors argue large customers should fund the upgrades they require. Test that promise against final law, state determinations, financial assurances and actual rate allocations—not the vote alone.

## MAYBE / THEREFORE

Maybe consideration produces effective safeguards, or regulators adopt different approaches. Therefore the established result is House passage of a proposed process, not a national rate cap or demonstrated savings.


## SOURCES

- [House Energy and Commerce Committee — Ratepayer Protection Act passes House](https://energycommerce.house.gov/posts/ratepayer-protection-act-passes-house-with-strong-bipartisan-support) — primary congressional passage announcement and recorded vote summary
- [GovInfo — H.R. 9340 Ratepayer Protection Act reported text](https://www.govinfo.gov/content/pkg/BILLS-119hr9340rh/html/BILLS-119hr9340rh.htm) — primary congressional bill text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
