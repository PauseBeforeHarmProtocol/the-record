# Trump directs DOJ review as White House counsel warns oversight could be criminal

**Entry ID:** NAT-2026-11-07-001
**Date:** November 7–11, 2026
**Checked:** 2026-11-11 6:10 PM EST
**Evidence state:** primary presidential Truth Social post plus independent Reuters, Washington Post and Roll Call reporting, including two reviews of the counsel letter; announced direction and formal warning, with DOJ implementation and underlying criminal conduct unestablished
**Review state:** current-standard-reviewed

A counsel letter escalated Trump's social-media order by warning the incoming Oversight chair that abusive subpoenas or harassment could warrant investigation.

## THE FACTS

- At 12:45:04 p.m. EST on November 7, Trump published a Truth Social statement accusing Democrats of threatening administration officials, Republican donors and supporters with impeachment, investigation or punishment. The post is primary evidence that he made those allegations; it does not independently establish extortion, criminal conduct or the innocence of every person described.
- Trump ended the statement by saying that, through the post, he was ordering the Department of Justice to look into the alleged criminal act immediately. Reuters and The Washington Post independently reported the direction. The evidence status is a presidential order announced through his social account, not a verified DOJ opening, investigative step, subpoena, grand-jury action, charge or adjudication.
- Reuters reported that Democratic congressional leaders had released oversight letters seeking documents, including about technology-company donations for the White House ballroom, and that Senator Elissa Slotkin had advocated deterrence and accountability for unlawful conduct. Those public oversight positions supply context; neither impeachment talk nor a document request by itself establishes extortion or another crime.
- The Justice Department did not immediately comment to Reuters or The Washington Post. Slotkin responded that people who break the law or use taxpayer money for personal enrichment should be accountable and that those who did not break the law should have no problem. The administration's strongest stated rationale is that political oversight threats can become unlawful coercion and merit review; no legal theory, predicate evidence or case assignment was public by cutoff.
- On November 9, White House Counsel Will Scharf sent incoming House Oversight chair Robert Garcia a letter saying the administration was monitoring what it called abusive legislative threats. Reuters and Roll Call, each reviewing the letter, reported that Scharf said process meant to harass or instill fear and unlawful subpoenas intended to deprive rights could cross into criminality or warrant investigation. Garcia said Congress would not be deterred. The letter is a formal escalation of the November 7 direction, but no public DOJ case, identified offense, subpoena challenge or charge was established by cutoff.

## SIGNIFICANCE

A presidential direction followed by a formal White House counsel warning that prospective congressional oversight could become criminal is material even before implementation because it can affect prosecutorial independence, legislative oversight and witness participation. Neither communication proves an offense or an opened case.

## GOALPOST / RESPONSE

The administration says threatened punishment, abusive process and unlawful subpoenas can become criminal intimidation rather than legitimate oversight. The tests are a written DOJ assignment, identified statute and conduct, predication and recusal records, actual subpoenas, judicial enforcement, evidence and whether protected legislative activity is distinguished from unlawful threats.

## MAYBE / THEREFORE

Maybe the warning preserves legitimate defenses against genuinely abusive process, or coupling White House legal threats with a presidential DOJ direction may chill lawful oversight without a criminal predicate. Therefore the archive records an announced DOJ direction and a formal counsel warning—not an opened investigation, a valid criminal charge, probable cause or proof that prospective congressional oversight is unlawful.


## SOURCES

- [Trump Truth Social statement directing DOJ review](https://truthsocial.com/@realDonaldTrump/117576401180733840) — primary presidential publication; proves publication and stated direction only
- [Reuters — Trump directs DOJ to look into Democrats](https://www.reuters.com/world/trump-orders-doj-look-into-democrats-threatening-people-2026-11-07/) — independent reporting; full article inspected
- [Washington Post — Trump calls for DOJ investigation of Democrats](https://www.washingtonpost.com/politics/2026/11/07/trump-calls-justice-department-investigate-democrats/) — independent reporting; article text inspected
- [Reuters — White House tells Democrats oversight investigations could be criminal](https://www.reuters.com/legal/government/white-house-tells-democrats-that-investigating-trump-administration-could-be-2026-11-11/) — independent review of White House counsel letter and congressional response
- [Roll Call — White House warns Democrats against aggressive oversight](https://rollcall.com/2026/11/11/white-house-warns-democrats-against-aggressive-oversight/) — independent review of counsel letter and separation-of-powers context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
