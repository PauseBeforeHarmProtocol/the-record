# Trump directs DOJ to examine Democrats' oversight threats

**Entry ID:** NAT-2026-11-07-001
**Date:** November 7, 2026
**Checked:** 2026-11-07 6:02 PM EST
**Evidence state:** primary presidential Truth Social post plus independent Reuters and Washington Post reporting; announced order, with DOJ implementation, legal predicate and underlying criminal conduct unestablished
**Review state:** current-standard-reviewed

Trump ordered DOJ in a Truth Social post to look into what he called a criminal act; no opened investigation, charge or underlying crime was established by cutoff.

## THE FACTS

- At 12:45:04 p.m. EST on November 7, Trump published a Truth Social statement accusing Democrats of threatening administration officials, Republican donors and supporters with impeachment, investigation or punishment. The post is primary evidence that he made those allegations; it does not independently establish extortion, criminal conduct or the innocence of every person described.
- Trump ended the statement by saying that, through the post, he was ordering the Department of Justice to look into the alleged criminal act immediately. Reuters and The Washington Post independently reported the direction. The evidence status is a presidential order announced through his social account, not a verified DOJ opening, investigative step, subpoena, grand-jury action, charge or adjudication.
- Reuters reported that Democratic congressional leaders had released oversight letters seeking documents, including about technology-company donations for the White House ballroom, and that Senator Elissa Slotkin had advocated deterrence and accountability for unlawful conduct. Those public oversight positions supply context; neither impeachment talk nor a document request by itself establishes extortion or another crime.
- The Justice Department did not immediately comment to Reuters or The Washington Post. Slotkin responded that people who break the law or use taxpayer money for personal enrichment should be accountable and that those who did not break the law should have no problem. The administration's strongest stated rationale is that political oversight threats can become unlawful coercion and merit review; no legal theory, predicate evidence or case assignment was public by cutoff.

## SIGNIFICANCE

A presidential direction asking federal law enforcement to examine political opponents and prospective congressional oversight is material even before implementation because it can affect prosecutorial independence, protected legislative activity and the willingness of witnesses or donors to participate in public affairs. The publication alone does not prove misuse or a criminal case.

## GOALPOST / RESPONSE

Trump says the letters and threatened punishment are criminal extortion and weaponized law enforcement. The tests are a written DOJ assignment, recusal or predication record, identified statute and conduct, investigative process, evidence, judicial review and whether protected oversight activity is distinguished from unlawful threats.

## MAYBE / THEREFORE

Maybe DOJ review could identify a specific unlawful threat, or the statement may remain rhetoric that produces no case and targets lawful oversight. Therefore the archive records an announced presidential order to look into the matter—not an opened investigation, probable cause, criminal offense, prosecution or proof that the cited Democrats acted unlawfully.


## SOURCES

- [Trump Truth Social statement directing DOJ review](https://truthsocial.com/@realDonaldTrump/117576401180733840) — primary presidential publication; proves publication and stated direction only
- [Reuters — Trump directs DOJ to look into Democrats](https://www.reuters.com/world/trump-orders-doj-look-into-democrats-threatening-people-2026-11-07/) — independent reporting; full article inspected
- [Washington Post — Trump calls for DOJ investigation of Democrats](https://www.washingtonpost.com/politics/2026/11/07/trump-calls-justice-department-investigate-democrats/) — independent reporting; article text inspected

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
