# DOJ preservation demands expand to Warren over planned congressional oversight

**Entry ID:** NAT-2026-11-07-001
**Date:** November 7–15, 2026
**Checked:** 2026-11-16 12:06 AM EST
**Evidence state:** primary presidential post and formal U.S. attorney preservation demands plus independent AP, Reuters, Washington Post, Roll Call and legal-news reporting; demands verified, underlying offenses, case opening and legal validity unresolved
**Review state:** current-standard-reviewed

A U.S. attorney expanded formal preservation demands to Senator Warren over planned Trump-related investigations; it remains neither a subpoena, charge nor confirmed criminal case.

## THE FACTS

- At 12:45:04 p.m. EST on November 7, Trump published a Truth Social statement accusing Democrats of threatening administration officials, Republican donors and supporters with impeachment, investigation or punishment. The post is primary evidence that he made those allegations; it does not independently establish extortion, criminal conduct or the innocence of every person described.
- Trump ended the statement by saying that, through the post, he was ordering the Department of Justice to look into the alleged criminal act immediately. Reuters and The Washington Post independently reported the direction. The evidence status is a presidential order announced through his social account, not a verified DOJ opening, investigative step, subpoena, grand-jury action, charge or adjudication.
- Reuters reported that Democratic congressional leaders had released oversight letters seeking documents, including about technology-company donations for the White House ballroom, and that Senator Elissa Slotkin had advocated deterrence and accountability for unlawful conduct. Those public oversight positions supply context; neither impeachment talk nor a document request by itself establishes extortion or another crime.
- The Justice Department did not immediately comment to Reuters or The Washington Post. Slotkin responded that people who break the law or use taxpayer money for personal enrichment should be accountable and that those who did not break the law should have no problem. The administration's strongest stated rationale is that political oversight threats can become unlawful coercion and merit review; no legal theory, predicate evidence or case assignment was public by cutoff.
- On November 9, White House Counsel Will Scharf sent incoming House Oversight chair Robert Garcia a letter saying the administration was monitoring what it called abusive legislative threats. Reuters and Roll Call, each reviewing the letter, reported that Scharf said process meant to harass or instill fear and unlawful subpoenas intended to deprive rights could cross into criminality or warrant investigation. Garcia said Congress would not be deterred. The letter is a formal escalation of the November 7 direction, but no public DOJ case, identified offense, subpoena challenge or charge was established by cutoff.
- On November 11, Southern District of Texas U.S. Attorney Aaron Reitz sent Senator Richard Blumenthal a preservation demand concerning his inquiry into White House ballroom donors. The letter cited possible violations of 18 U.S.C. §§ 241 and 242, required preservation by November 18 at 6 p.m. EST, and covered staff, agents and campaign personnel. Blumenthal said he would not be intimidated; a DOJ spokesperson called preservation requests routine when officials take extreme actions. This was a formal demand to preserve material, not a subpoena, search, charge, adjudicated rights violation or public confirmation of an opened criminal case.
- On November 15, Reitz sent Senator Elizabeth Warren a two-page preservation demand citing 18 U.S.C. §§ 241 and 242 and requiring confirmation by November 23 at 6 p.m. EST that relevant records had been preserved. The letter tied the demand to Warren’s stated plans for Senate Banking Committee investigations and warned of possible sanctions or other legal consequences. Reuters independently confirmed the letter and reported that notices to preserve records can precede investigations; Warren’s office did not immediately comment. The demand is formal but is not a subpoena, charge, public case-opening confirmation or adjudicated finding that planned oversight is unlawful.

## SIGNIFICANCE

The preservation demands now reach multiple senators and follow a presidential DOJ direction and White House counsel warning aimed at prospective congressional oversight. That expanding pattern can affect prosecutorial independence, legislative inquiry and witness participation, but it does not establish a criminal predicate, opened case or offense.

## GOALPOST / RESPONSE

The administration says oversight must have a legitimate legislative purpose and can become intimidation or a conspiracy to deprive rights when it targets donors or supporters. Warren, Blumenthal and Garcia say lawful congressional inquiry will continue. The tests are a written case assignment and predicate, compulsory process, recusal records, judicial review, evidence, outcomes and whether protected legislative activity is distinguished from unlawful coercion.

## MAYBE / THEREFORE

Maybe the demands preserve evidence concerning genuinely coercive conduct, or repeated prosecutorial warnings may chill lawful oversight without a criminal predicate. Therefore formal preservation demands have expanded to another senator—but the record does not establish an opened case, probable cause, a valid charge or proof that planned congressional oversight is unlawful.


## SOURCES

- [Trump Truth Social statement directing DOJ review](https://truthsocial.com/@realDonaldTrump/117576401180733840) — primary presidential publication; proves publication and stated direction only
- [Reuters — Trump directs DOJ to look into Democrats](https://www.reuters.com/world/trump-orders-doj-look-into-democrats-threatening-people-2026-11-07/) — independent reporting; full article inspected
- [Washington Post — Trump calls for DOJ investigation of Democrats](https://www.washingtonpost.com/politics/2026/11/07/trump-calls-justice-department-investigate-democrats/) — independent reporting; article text inspected
- [Reuters — White House tells Democrats oversight investigations could be criminal](https://www.reuters.com/legal/government/white-house-tells-democrats-that-investigating-trump-administration-could-be-2026-11-11/) — independent review of White House counsel letter and congressional response
- [Roll Call — White House warns Democrats against aggressive oversight](https://rollcall.com/2026/11/11/white-house-warns-democrats-against-aggressive-oversight/) — independent review of counsel letter and separation-of-powers context
- [U.S. Attorney Aaron Reitz — preservation demand to Senator Blumenthal](https://x.com/USAttyReitz/status/2120632462686711838?s=20) — primary publication of formal preservation demand; allegations and cited statutes are not adjudicated
- [Associated Press — federal prosecutor threatens senator over oversight](https://apnews.com/article/trump-congress-investigations-12acd4e233792f687b80eb9636aea18d) — independent reporting on preservation demand, responses and procedural posture
- [Democracy Docket — U.S. attorney preservation demand to senator](https://www.democracydocket.com/news-alerts/u-s-attorney-threatens-democratic-senator-with-prosecution-for-conducting-oversight/) — independent legal-news reporting and linked primary-letter context
- [U.S. Attorney Aaron Reitz — preservation demand to Senator Warren](https://x.com/USAttyReitz/status/2121943768345780568) — primary publication of a formal preservation demand; allegations and cited statutes are not adjudicated
- [Reuters — Justice Department warns Senator Warren over records preservation](https://www.reuters.com/world/us-justice-department-warns-senator-warren-over-records-preservation-2026-11-16/) — independent reporting on the preservation demand, procedural posture, related letters and absence of an immediate response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
