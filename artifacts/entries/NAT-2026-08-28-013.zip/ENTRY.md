# Court rules speech-based visa and deportation provisions unconstitutional as applied

**Entry ID:** NAT-2026-08-28-013
**Date:** March 2025–August 28, 2026
**Checked:** 2026-08-29 12:05 AM EDT
**Evidence state:** primary 90-page federal merits opinion plus independent Reuters reporting and a litigant-side procedural summary checked against the opinion; declaratory judgment granted, permanent injunction denied, appeal possible
**Review state:** current-standard-reviewed

The 90-page merits opinion grants declaratory judgment but denies permanent injunctive relief; appeal and other lawful removal grounds remain possible.

## THE FACTS

- U.S. District Judge Noël Wise ruled in Stanford Daily Publishing Corp. v. Rubio that the challenged portions of federal visa-revocation and deportation provisions violate the First Amendment when enforced on the basis of protected speech and are unconstitutionally vague under the Fifth Amendment in that application.
- The case arose from the administration's use of immigration authority beginning in March 2025 against noncitizens engaged in pro-Palestinian or anti-Israel expression. The plaintiffs included the Stanford Daily and an F-1 student who said the enforcement policy chilled protected reporting and speech.
- The court granted four declarations covering the challenged deportation and visa-revocation provisions. It denied permanent injunctive relief under the deportation provision, stating that only the Supreme Court could provide the requested relief, and held that an injunction under the revocation provision was not appropriate at this stage.
- The opinion does not bar removal based on independently lawful, non-speech grounds, vacate every prior immigration decision, or resolve an appeal. The State and Homeland Security departments did not immediately comment in Reuters' report.

## SIGNIFICANCE

The merits ruling rejects a central constitutional basis used in the administration's speech-linked immigration campaign and gives affected speakers and publishers declaratory relief. Its practical reach is narrower than a nationwide injunction and may depend on appeal, future enforcement choices, and case-specific immigration grounds.

## GOALPOST / RESPONSE

The government has argued that the statutes authorize action when a noncitizen's presence compromises a compelling foreign-policy interest and that immigration and visa decisions receive substantial executive and consular discretion. The court rejected enforcement based on protected speech. Judgment, appeal and stay filings, agency guidance, later removal cases, and appellate treatment of the constitutional holdings are the tests.

## MAYBE / THEREFORE

Maybe the ruling will constrain speech-based immigration enforcement, or an appellate court may narrow or reverse it while allowing action on other lawful grounds. Therefore the record reports a district-court merits declaration—not a permanent injunction, blanket immunity from immigration law, or final nationwide appellate resolution.


## SOURCES

- [U.S. District Court — Stanford Daily Publishing Corp. v. Rubio merits opinion](https://fingfx.thomsonreuters.com/gfx/legaldocs/klpyoaqawpg/08282026stanford.pdf) — primary 90-page merits opinion granting declaratory judgment and denying permanent injunctive relief
- [Reuters — judge rules against speech-based visa revocation and deportation provisions](https://www.reuters.com/legal/government/judge-deals-blow-trump-moves-deport-pro-palestinian-activists-2026-08-29/) — independent legal reporting on the merits ruling, statutory context, and possible appeal
- [FIRE — plaintiffs' account of Stanford Daily constitutional ruling](https://www.fire.org/news/breaking-federal-court-rules-statutes-trump-admin-used-its-speech-based-deportation-scheme-are) — litigant-side case summary used for procedural context, checked against the court opinion

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
