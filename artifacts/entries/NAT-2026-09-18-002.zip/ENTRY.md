# State implements ITAR country-policy and ally-list changes

**Entry ID:** NAT-2026-09-18-002
**Date:** September 18, 2026
**Checked:** 2026-09-18 12:00 PM EDT
**Evidence state:** complete primary State Department final rule; regulatory changes effective September 18, transaction-level implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The immediately effective rule ends Ethiopia's qualified denial policy, clarifies Somalia licensing and updates defense-trade provisions and ally designations.

## THE FACTS

- The State Department issued a final rule effective September 18 revising International Traffic in Arms Regulations country policies and related exemptions. State published it without advance notice and comment under the foreign-affairs exception.
- The rule removes Ethiopia's qualified policy of denial, implementing the secretary's February 5 determination ending denial for defense exports to Ethiopia's armed forces, police, intelligence and other internal-security forces.
- For Somalia, the rule clarifies that specified weapons, ammunition and military equipment may receive case-by-case review when intended solely to support or be used by named international training and support activities, or by other UN member states with a status-of-forces agreement after Security Council committee notice.
- The rule clarifies denial-policy language for exports, reexports, retransfers and temporary imports; corrects Canadian exemption language so nontransfer certificates are not required in those exemptions; and makes technical changes for Libya and South Sudan.
- The regulation adds Saudi Arabia and Peru to the ITAR definition of major non-NATO allies, reflecting presidential determinations published in January. State says the rule modestly expands permissible defense-trade activity, is significant under executive-order review and is not a major rule under the Congressional Review Act. No resulting license or transfer is established.

## SIGNIFICANCE

The rule changes the operative defense-trade framework for several countries and exemptions, including implementing an Ethiopia policy reversal and formalizing two ally designations. Its practical reach depends on later licenses, transfers and enforcement.

## GOALPOST / RESPONSE

State presents the rule as clarification and implementation of recent policy actions, with minimal costs and some expansion of permissible trade. Licensing decisions, transaction volumes, end-use controls, enforcement and regional-security outcomes are the tests.

## MAYBE / THEREFORE

Maybe the revisions align controls with current diplomatic and security relationships while reducing contradictory paperwork, or broader case-by-case access may create oversight and diversion risks. Therefore the rule is effective and changes the regulatory framework—not proof that any defense article was licensed, exported or safely used.


## SOURCES

- [Federal Register — ITAR denial policies and major non-NATO ally list](https://www.federalregister.gov/documents/2026/09/18/2026-19161/international-traffic-in-arms-regulations-clarifying-policies-of-denial-updating-the-major-non-nato) — primary final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
