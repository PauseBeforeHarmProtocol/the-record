# White House disavows flat diesel-export ban after Trump endorsement

**Entry ID:** NAT-2026-09-22-006
**Date:** September 22–23, 2026
**Checked:** 2026-09-23 5:57 PM EDT
**Evidence state:** Reuters reports of named presidential, Treasury, Energy and Interior statements plus the White House response; the flat-ban disavowal and narrower discussions are documented, while any operative instrument, authority, scope, commitments and effects remain unresolved
**Review state:** current-standard-reviewed

A White House official and the energy secretary said no flat ban was under consideration, while narrower voluntary or efficiency measures remained under discussion; no restriction was ordered or implemented.

## THE FACTS

- President Trump said on September 22 that he supported banning U.S. diesel exports and had called for the idea within his administration. The statement announces a presidential policy preference and internal proposal, not a signed order or operative export restriction.
- Treasury Secretary Scott Bessent said the administration was examining whether a ban was feasible and was considering full and partial versions. No agency published a rule, legal authority, product definition, geographic scope, volume limit, exemption, effective date or enforcement process by cutoff.
- Energy Secretary Chris Wright and Interior Secretary Doug Burgum warned that restricting exports could raise prices in coastal U.S. markets, reduce refinery production and invite retaliation. Their objections are named administration assessments of possible consequences, not measured effects from an implemented policy.
- Reuters reported the on-record statements as the administration weighed high diesel prices during disruptions linked to the Iran conflict. The report did not establish that a decision had been made, that exports had changed because of the proposal or that any price effect could be attributed to a ban that did not yet exist.
- On September 23, a White House official denied a report that the administration was considering a 90-day diesel-export ban. Energy Secretary Chris Wright separately said nobody in the administration was considering a flat ban.
- Wright said voluntary and other efficiency measures were still being discussed to increase domestic diesel supply while preserving gasoline and jet-fuel flows. No written measure, legal authority, scope, effective date, participant commitment or implementation was announced by cutoff.
- The clarification narrows the prior proposal but does not erase Trump's endorsement or establish a final decision. A separate report describing a 90-day plan relied on unnamed sources and was not treated as proof of an adopted policy.

## SIGNIFICANCE

The White House and energy secretary's public disavowal makes a flat export ban less imminent and exposes unresolved disagreement after the president's endorsement. Narrower voluntary or efficiency measures remain possible, but their design, legality, participation and effects are not yet documented.

## GOALPOST / RESPONSE

Trump endorsed a ban, while the White House and Wright now say no flat ban is being considered and point instead to possible voluntary or efficiency measures. A written instrument, statutory authority, defined scope, participant commitments, agency analysis, implementation, export volumes, refinery runs, inventories, regional prices and trading-partner responses are the tests.

## MAYBE / THEREFORE

Maybe the clarification reflects a genuine shift toward narrower measures that increase domestic supply without disrupting other fuels, or internal options may still be unsettled. Therefore officials publicly disavowed a flat ban while leaving other measures under discussion—not a final policy, ordered or implemented restriction, documented supply gain or measured price reduction.


## SOURCES

- [Reuters — Trump backs proposed diesel-export ban as cabinet examines options](https://www.reuters.com/world/us/trump-says-he-backs-idea-ban-diesel-exports-2026-09-22/) — independent reporting of named on-record presidential and cabinet statements about an announced proposal and internal review
- [Reuters — White House and energy secretary disavow flat diesel-export ban](https://www.reuters.com/world/us/white-house-denies-report-us-is-considering-diesel-export-ban-2026-09-23/) — independent reporting on named Energy Department and White House statements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
