# Trump backs proposed diesel-export ban as administration studies options

**Entry ID:** NAT-2026-09-22-006
**Date:** September 22, 2026
**Checked:** 2026-09-22 11:59 PM EDT
**Evidence state:** Reuters report of named, on-record presidential, Treasury, Energy and Interior statements; proposal and internal review documented, operative instrument, final decision, authority, scope and effects unresolved
**Review state:** current-standard-reviewed

The president endorsed an export restriction and Treasury said full and partial variants were under review; no order, rule, authority, scope, effective date or implemented ban was announced.

## THE FACTS

- President Trump said on September 22 that he supported banning U.S. diesel exports and had called for the idea within his administration. The statement announces a presidential policy preference and internal proposal, not a signed order or operative export restriction.
- Treasury Secretary Scott Bessent said the administration was examining whether a ban was feasible and was considering full and partial versions. No agency published a rule, legal authority, product definition, geographic scope, volume limit, exemption, effective date or enforcement process by cutoff.
- Energy Secretary Chris Wright and Interior Secretary Doug Burgum warned that restricting exports could raise prices in coastal U.S. markets, reduce refinery production and invite retaliation. Their objections are named administration assessments of possible consequences, not measured effects from an implemented policy.
- Reuters reported the on-record statements as the administration weighed high diesel prices during disruptions linked to the Iran conflict. The report did not establish that a decision had been made, that exports had changed because of the proposal or that any price effect could be attributed to a ban that did not yet exist.

## SIGNIFICANCE

A diesel-export restriction could redirect refinery output toward domestic buyers but also alter production incentives, regional supply and trade relationships. The president's endorsement makes the proposal consequential, while cabinet disagreement and the absence of an instrument leave its design, legality and effects unresolved.

## GOALPOST / RESPONSE

Trump presents an export ban as a possible response to high diesel prices. Bessent says feasibility and full or partial variants are under review, while Wright and Burgum warn of coastal price increases, lower production and retaliation. A written instrument, statutory authority, defined scope, agency analysis, implementation, export volumes, refinery runs, inventories, regional prices and trading-partner responses are the tests.

## MAYBE / THEREFORE

Maybe a targeted restriction could increase near-term domestic supply in constrained markets, or it could reduce output and shift costs geographically or internationally. Therefore the president endorsed a proposal and cabinet officials confirmed internal review—not a final decision, ordered or implemented ban, documented supply gain or measured price reduction.


## SOURCES

- [Reuters — Trump backs proposed diesel-export ban as cabinet examines options](https://www.reuters.com/world/us/trump-says-he-backs-idea-ban-diesel-exports-2026-09-22/) — independent reporting of named on-record presidential and cabinet statements about an announced proposal and internal review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
