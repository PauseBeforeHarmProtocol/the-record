# Trump rejects diesel export ban after G7 reserve-release commitment

**Entry ID:** NAT-2026-09-22-006
**Date:** September 22–October 2, 2026
**Checked:** 2026-10-02 5:57 PM EDT
**Evidence state:** official G7 leaders' statement plus Reuters and Associated Press reporting, including Trump’s direct statement that he would not authorize a diesel export ban; the decision and multilateral commitment are documented, while reserve deliveries and effects remain unmeasured
**Review state:** current-standard-reviewed

Trump said he would not authorize a diesel export ban after G7 leaders committed to a 100 million-barrel reserve release and rejected intra-G7 energy restrictions; actual drawdowns and price effects remain unmeasured.

## THE FACTS

- President Trump said on September 22 that he supported banning U.S. diesel exports and had called for the idea within his administration. The statement announces a presidential policy preference and internal proposal, not a signed order or operative export restriction.
- Treasury Secretary Scott Bessent said the administration was examining whether a ban was feasible and was considering full and partial versions. No agency published a rule, legal authority, product definition, geographic scope, volume limit, exemption, effective date or enforcement process by cutoff.
- Energy Secretary Chris Wright and Interior Secretary Doug Burgum warned that restricting exports could raise prices in coastal U.S. markets, reduce refinery production and invite retaliation. Their objections are named administration assessments of possible consequences, not measured effects from an implemented policy.
- Reuters reported the on-record statements as the administration weighed high diesel prices during disruptions linked to the Iran conflict. The report did not establish that a decision had been made, that exports had changed because of the proposal or that any price effect could be attributed to a ban that did not yet exist.
- On September 23, a White House official denied a report that the administration was considering a 90-day diesel-export ban. Energy Secretary Chris Wright separately said nobody in the administration was considering a flat ban.
- Wright said voluntary and other efficiency measures were still being discussed to increase domestic diesel supply while preserving gasoline and jet-fuel flows. No written measure, legal authority, scope, effective date, participant commitment or implementation was announced by cutoff.
- The clarification narrows the prior proposal but does not erase Trump's endorsement or establish a final decision. A separate report describing a 90-day plan relied on unnamed sources and was not treated as proof of an adopted policy.
- On October 2, G7 leaders formally committed to a coordinated release through the International Energy Agency of 100 million barrels of oil and fuel products beginning immediately over four months, including a front-loaded substantial diesel release by G7 members and partners within the first 20 days.
- The G7 statement also reaffirmed that members would refrain from restricting energy exports to one another and called on producers not to impose bans that could worsen market tension. This is a formal multilateral commitment, not evidence that the full volume had already left reserves by cutoff.
- Trump had posted that Europe agreed to release diesel immediately. The post proves his statement; the G7 declaration independently establishes the broader 100 million-barrel commitment and timing, while actual country allocations, deliveries, market effects and any causal share attributable to U.S. pressure remain unmeasured.
- On October 2, Trump directly said he would not authorize a U.S. diesel export ban. That statement resolves the administration’s immediate policy choice after his earlier endorsement and officials’ conflicting descriptions: no flat ban was authorized by cutoff, while no rule or order had been needed to reverse because no restriction had taken effect.

## SIGNIFICANCE

The episode moved from an unsettled U.S. export-ban proposal to a direct presidential rejection of that option and a formal, time-bounded G7 reserve commitment coordinated through the IEA. It establishes the administration’s announced policy choice and a concrete supply response while preserving open energy trade among members, but implementation and price effects remain prospective.

## GOALPOST / RESPONSE

Trump now says he will not authorize a diesel export ban, and the G7 frames its reserve commitment as coordinated market stabilization while rejecting intra-group export restrictions. A written reversal is unnecessary to establish that no ban was authorized, but later agency action could change policy. Country allocations, reserve withdrawals, shipping records, refinery runs, inventories, prices and any future export restriction are the tests.

## MAYBE / THEREFORE

Maybe the front-loaded release will ease diesel shortages without the regional distortions of a U.S. export ban, or implementation and market conditions may blunt its effect. Therefore the record establishes Trump’s announced decision not to authorize a ban and a formal 100 million-barrel G7 commitment—not completion of the release, permanent foreclosure of later restrictions or measured price relief.


## SOURCES

- [Reuters — Trump backs proposed diesel-export ban as cabinet examines options](https://www.reuters.com/world/us/trump-says-he-backs-idea-ban-diesel-exports-2026-09-22/) — independent reporting of named on-record presidential and cabinet statements about an announced proposal and internal review
- [Reuters — White House and energy secretary disavow flat diesel-export ban](https://www.reuters.com/world/us/white-house-denies-report-us-is-considering-diesel-export-ban-2026-09-23/) — independent reporting on named Energy Department and White House statements
- [French presidency — G7 Leaders' Statement on global energy security and market stability](https://www.elysee.fr/emmanuel-macron/2026/10/02/g7-leaders-statement-on-global-energy-security-and-market-stability) — primary multilateral statement
- [Reuters — G7 commits to 100 million-barrel coordinated reserve release](https://www.reuters.com/business/energy/g7-release-100-million-barrels-diesel-other-reserves-through-iea-2026-10-02/) — independent reporting on formal G7 commitment
- [Associated Press — G7 oil and diesel release after price surge](https://apnews.com/article/trump-europe-diesel-fuel-prices-774a360d1646d9ce8aba764fdd9959d2) — independent reporting on reserve-release scope, timing and policy response
- [Reuters — Trump says he will not authorize a diesel export ban](https://www.reuters.com/business/energy/trump-not-going-be-doing-diesel-export-ban-2026-10-02/) — independent reporting on direct presidential policy decision

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
