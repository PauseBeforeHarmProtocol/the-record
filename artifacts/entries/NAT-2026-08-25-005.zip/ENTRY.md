# U.S. military kills four people in Caribbean boat strike after two-month pause

**Entry ID:** NAT-2026-08-25-005
**Date:** August 25, 2026
**Checked:** 2026-08-26 12:02 PM EDT
**Evidence state:** official SOUTHCOM strike announcement corroborated by AP; strike and four reported deaths confirmed, trafficking and combatant-status claims attributed and unsupported by publicly released evidence
**Review state:** current-standard-reviewed

SOUTHCOM said the vessel was trafficking narcotics, but released no public evidence identifying the people or cargo; AP counted at least 227 deaths across 68 such strikes.

## THE FACTS

- U.S. Southern Command announced that, at the direction of Defense Secretary Pete Hegseth, Joint Task Force Southern Spear carried out a lethal strike on August 25 against a go-fast vessel in the Caribbean Sea, killing four people.
- SOUTHCOM said intelligence confirmed that the vessel was moving along known trafficking routes and carrying narcotics. The command's public release did not identify the people killed, specify the cargo, or publish evidence supporting those assertions.
- The Associated Press reported that the strike followed another reported strike on August 23 after a roughly two-month pause and brought its count to at least 227 people killed in 68 strikes. The administration says the operations are part of an armed conflict with drug cartels and are necessary to stop narcotics and overdose deaths; legal experts and lawmakers cited by AP dispute the legal basis and lack of public evidence.

## SIGNIFICANCE

The strike resumes a lethal campaign outside ordinary criminal interdiction and raises continuing war-powers, due-process, identification, and public-accountability questions. The administration's asserted intelligence and the cumulative death count cannot be independently tested from the brief public release alone.

## GOALPOST / RESPONSE

The administration says designated cartels are armed-conflict adversaries and that the strikes protect Americans from narcotics. Critics argue that suspected trafficking does not itself establish a lawful military target and that Congress has not authorized this campaign. Public target evidence, casualty identification, legal memoranda, congressional authorization or restriction, and post-strike review are the evidence tests.

## MAYBE / THEREFORE

Maybe classified intelligence reliably established the vessel's role and the identities or status of those aboard, and disclosure could compromise operations. Therefore the record reports the strike and deaths as implemented facts, attributes the trafficking claim to SOUTHCOM, and does not treat that undisclosed claim as independently verified.


## SOURCES

- [U.S. Southern Command — lethal kinetic strike, August 25, 2026](https://www.southcom.mil/News/PressReleases/Article/4583027/lethal-kinetic-strike-august-25-2026/) — primary military announcement and administration attribution
- [Associated Press — U.S. military kills four in Caribbean boat strike](https://apnews.com/article/trump-cartels-military-strike-caribbean-8a3aead624d51d2ec5a3885f3f148111) — independent reporting with campaign-wide casualty and legal context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
