# SOUTHCOM boat campaign adds another Caribbean lethal strike

**Entry ID:** NAT-2026-08-25-005
**Date:** August 25–October 4, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** AP reporting of the named SOUTHCOM announcement and its campaign tally; official release URL discovered but full retrieval blocked 403, no footage inspection claimed
**Review state:** current-standard-reviewed

The military said an October 4 Caribbean strike killed four; AP counted at least 235 deaths in 70 strikes, while target evidence and legality remain unresolved.

## THE FACTS

- U.S. Southern Command announced that, at the direction of its commander, Joint Task Force Western Hemisphere carried out a lethal strike on August 25 against a go-fast vessel in the Caribbean Sea, killing four people.
- SOUTHCOM said intelligence confirmed that the August 25 vessel was moving along known trafficking routes and carrying narcotics. Its public release did not identify the people killed, specify the cargo or publish evidence supporting those assertions.
- On September 5, the task force interdicted what SOUTHCOM called a multi-vessel floating refueling station in the Eastern Pacific. The command said people were removed and transferred to Ecuadorian authorities before U.S. forces sank the main vessel and attached support vessels.
- SOUTHCOM attributed the September 5 vessels to Los Choneros but did not name the vessels or crew, identify recovered contraband, or publish the intelligence, legal authority, coordination terms or transfer records.
- On September 7, SOUTHCOM announced a separate Eastern Pacific interdiction of another alleged Los Choneros floating refueling station. It said the crew was removed for transfer to Ecuadorian authorities and the vessel was sunk, again without publishing the vessel name, crew count, cargo, intelligence or legal basis.
- On September 8, SOUTHCOM announced another Eastern Pacific interdiction of an alleged Los Choneros refueling vessel. It said individuals were removed and transferred to Ecuadorian authorities before the vessel was sunk; the release did not identify the vessel, people, cargo, intelligence or legal authority.
- On September 9, SOUTHCOM announced a lethal strike against a go-fast vessel on established Caribbean trafficking routes and said three people were killed. The command called them narco-terrorists and cited confirmed intelligence but released no names, cargo, intelligence or legal rationale; Reuters said it could not immediately verify the announcement.
- On September 19, SOUTHCOM said U.S. forces struck another vessel in the Caribbean and killed four people. The command attributed active narco-trafficking to confirmed intelligence but did not publicly identify the people, precise location or cargo, publish the intelligence, or state a vessel-specific legal rationale. Reuters and Associated Press reported the announcement; AP said the military supplied no evidence that this vessel was ferrying drugs.
- Associated Press counted at least 231 people killed in 69 U.S. military boat strikes after the September 19 operation. That independently reported campaign count does not verify the identity, conduct or legal status of every person killed.
- SOUTHCOM said U.S. forces struck a suspected drug-trafficking boat in the Caribbean on October 4 and killed four people. AP reported the named military announcement and said no evidence was supplied that the vessel carried drugs.
- AP counted at least 235 people killed across 70 boat strikes after this operation. That is AP’s campaign count, not an independently verified finding about every target or person killed.

## SIGNIFICANCE

Another reported lethal strike continues the campaign while target identification, legal authority and demonstrated effectiveness remain unresolved. AP’s latest campaign count is distinct from a target-by-target casualty audit.

## GOALPOST / RESPONSE

SOUTHCOM describes the targets as traffickers on known smuggling routes. Trump frames the campaign as armed conflict to stop drugs and overdose deaths. Public target evidence, legal authority, casualty review, congressional oversight and independently measured trafficking outcomes remain the tests.

## MAYBE / THEREFORE

Maybe undisclosed intelligence supports the military’s target selection. Therefore the record establishes the announced October 4 strike and reported deaths; it does not prove the unnamed people’s conduct, drug cargo, legal authorization or effectiveness.


## SOURCES

- [U.S. Southern Command — lethal kinetic strike, August 25, 2026](https://www.southcom.mil/News/PressReleases/Article/4583027/lethal-kinetic-strike-august-25-2026/) — primary military announcement and administration attribution
- [Associated Press — U.S. military kills four in Caribbean boat strike](https://apnews.com/article/trump-cartels-military-strike-caribbean-8a3aead624d51d2ec5a3885f3f148111) — independent reporting with campaign-wide casualty and legal context
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel](https://www.southcom.mil/News/PressReleases/Article/4591750/interdiction-of-narco-terrorist-refueling-vessel-sept-5-2026/) — primary military release documenting the boarding, crew transfer and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel, September 7](https://www.southcom.mil/News/PressReleases/Article/4591820/interdiction-of-narco-terrorist-refueling-vessel-sept-7-2026/) — primary military release documenting crew removal, planned transfer to Ecuador and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [Associated Press — U.S. sinks Ecuadorian vessel it alleges was tied to Los Choneros](https://apnews.com/article/ecuador-us-boat-drug-trafficking-sinking-pacific-fishermen-551b40890fe249597d0236087fed019a) — independent reporting on the SOUTHCOM operation, video, crew disposition and broader boat-strike campaign
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel, September 8](https://www.southcom.mil/News/PressReleases/Article/4593113/interdiction-of-narco-terrorist-refueling-vessel-sept-8-2026/) — primary military release documenting removal and transfer of individuals and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [U.S. Southern Command — Lethal Kinetic Strike, September 9](https://www.southcom.mil/News/PressReleases/Article/4594213/lethal-kinetic-strike-september-9-2026/) — primary military release announcing a Caribbean strike and three deaths while attributing trafficking activity to undisclosed intelligence
- [Reuters — U.S. announces Caribbean vessel strike killing three](https://www.reuters.com/world/us-strikes-vessel-caribbean-killing-three-2026-09-10/) — independent reporting on SOUTHCOM's announcement, expressly noting that Reuters could not immediately verify it
- [Reuters — U.S. military announces September 19 Caribbean vessel strike killing four](https://www.reuters.com/world/us-says-it-killed-four-people-strike-vessel-caribbean-2026-09-20/) — independent reporting on a military announcement and attributed intelligence claim
- [Associated Press — U.S. military says September 19 Caribbean boat strike killed four](https://apnews.com/article/trump-cartels-military-strike-caribbean-95f3d4ae10f8e2a4a193f601101898d9) — independent reporting with campaign totals and explicit missing-evidence limitation
- [AP — Military says Caribbean boat strike killed four on October 4](https://apnews.com/article/trump-cartels-military-strike-caribbean-0589ce7065bc2dea0ae719c3420f4072) — independent reporting of named military announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
