# SOUTHCOM boat campaign expands from lethal strike to multi-vessel Pacific sinking

**Entry ID:** NAT-2026-08-25-005
**Date:** August 25–September 5, 2026
**Checked:** 2026-09-08 12:01 AM EDT
**Evidence state:** official SOUTHCOM releases plus Associated Press reporting; the August 25 strike and deaths and September 5 boarding, transfer and sinking are documented, while target intelligence, cargo, legal basis and campaign effectiveness remain undisclosed or unmeasured
**Review state:** current-standard-reviewed

A September 5 operation removed the crew before sinking a refueling vessel and attached support craft; SOUTHCOM's trafficking attribution remains publicly unsubstantiated.

## THE FACTS

- U.S. Southern Command announced that, at the direction of Defense Secretary Pete Hegseth, Joint Task Force Southern Spear carried out a lethal strike on August 25 against a go-fast vessel in the Caribbean Sea, killing four people.
- SOUTHCOM said intelligence confirmed that the August 25 vessel was moving along known trafficking routes and carrying narcotics. Its public release did not identify the people killed, specify the cargo, or publish evidence supporting those assertions.
- On September 5, Joint Task Force Western Hemisphere interdicted what SOUTHCOM called a multi-vessel floating refueling station in the Eastern Pacific. The command said the people were removed from the main vessel and transferred to Ecuadorian authorities before U.S. forces sank the main vessel and attached support vessels.
- SOUTHCOM attributed the September 5 vessels to Los Choneros and said the operation dismantled trafficking logistics. The official release did not name the vessels or crew, identify recovered contraband, or publish the intelligence, cargo, legal authority, coordination terms or transfer records.
- Associated Press reported the September 5 operation as the fifth U.S.-targeted Ecuadorian vessel in less than two weeks and counted at least 227 people killed in 68 U.S. government boat strikes since the broader campaign began. No deaths were reported in the September 5 operation, and Ecuador had not publicly commented on it by AP's report.

## SIGNIFICANCE

The September 5 operation shows the campaign includes nonlethal board-transfer-destroy missions as well as lethal strikes. Removing the crew before sinking the vessels reduces immediate loss of life, but the expanding military role, undisclosed intelligence and legal basis, and incomplete Ecuadorian record remain consequential accountability questions.

## GOALPOST / RESPONSE

SOUTHCOM says intelligence identifies trafficking routes and Los Choneros logistics and describes its operations as precise and professional. Public target evidence, cargo and crew records, legal authority, partner-government documentation, transfer outcomes, strike and interdiction counts, and independently measured effects on trafficking and civilian harm are the tests.

## MAYBE / THEREFORE

Maybe classified intelligence and Ecuadorian cooperation reliably identified a trafficking refueling network, and boarding plus safe crew removal demonstrates a more proportionate alternative to lethal force. Therefore the record establishes the August 25 lethal strike and the September 5 boarding, transfer and vessel sinking, while attributing—not independently validating—the trafficking, cargo and organizational claims.


## SOURCES

- [U.S. Southern Command — lethal kinetic strike, August 25, 2026](https://www.southcom.mil/News/PressReleases/Article/4583027/lethal-kinetic-strike-august-25-2026/) — primary military announcement and administration attribution
- [Associated Press — U.S. military kills four in Caribbean boat strike](https://apnews.com/article/trump-cartels-military-strike-caribbean-8a3aead624d51d2ec5a3885f3f148111) — independent reporting with campaign-wide casualty and legal context
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel](https://www.southcom.mil/News/PressReleases/Article/4591750/interdiction-of-narco-terrorist-refueling-vessel-sept-5-2026/) — primary military release documenting the boarding, crew transfer and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [Associated Press — U.S. sinks Ecuadorian vessel it alleges was tied to Los Choneros](https://apnews.com/article/ecuador-us-boat-drug-trafficking-sinking-pacific-fishermen-551b40890fe249597d0236087fed019a) — independent reporting on the SOUTHCOM operation, video, crew disposition and broader boat-strike campaign

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
