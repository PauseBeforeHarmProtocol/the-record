# SOUTHCOM boat campaign adds another Caribbean lethal strike

**Entry ID:** NAT-2026-08-25-005
**Date:** August 25–September 19, 2026
**Checked:** 2026-09-20 12:00 AM EDT
**Evidence state:** prior official SOUTHCOM releases plus Reuters and Associated Press reporting on the September 19 military announcement; strike and reported deaths corroborated, while identities, cargo, intelligence, legal rationale and effectiveness remain unpublished or unmeasured
**Review state:** current-standard-reviewed

The military said a September 19 strike killed four people; it published no names, cargo evidence or legal rationale for treating the vessel and crew as military targets.

## THE FACTS

- U.S. Southern Command announced that, at the direction of its commander, Joint Task Force Western Hemisphere carried out a lethal strike on August 25 against a go-fast vessel in the Caribbean Sea, killing four people.
- SOUTHCOM said intelligence confirmed that the August 25 vessel was moving along known trafficking routes and carrying narcotics. Its public release did not identify the people killed, specify the cargo or publish evidence supporting those assertions.
- On September 5, the task force interdicted what SOUTHCOM called a multi-vessel floating refueling station in the Eastern Pacific. The command said people were removed and transferred to Ecuadorian authorities before U.S. forces sank the main vessel and attached support vessels.
- SOUTHCOM attributed the September 5 vessels to Los Choneros but did not name the vessels or crew, identify recovered contraband, or publish the intelligence, legal authority, coordination terms or transfer records.
- On September 7, SOUTHCOM announced a separate Eastern Pacific interdiction of another alleged Los Choneros floating refueling station. It said the crew was removed for transfer to Ecuadorian authorities and the vessel was sunk, again without publishing the vessel name, crew count, cargo, intelligence or legal basis.
- On September 8, SOUTHCOM announced another Eastern Pacific interdiction of an alleged Los Choneros refueling vessel. It said individuals were removed and transferred to Ecuadorian authorities before the vessel was sunk; the release did not identify the vessel, people, cargo, intelligence or legal authority.
- On September 9, SOUTHCOM announced a lethal strike against a go-fast vessel on established Caribbean trafficking routes and said three people were killed. The command called them narco-terrorists and cited confirmed intelligence but released no names, cargo, intelligence or legal rationale; Reuters said it could not immediately verify the announcement.
- On September 19, SOUTHCOM said U.S. forces struck another vessel in the Caribbean and killed four people. The command attributed active narco-trafficking to confirmed intelligence but did not publicly identify the people, precise location or cargo, publish the intelligence, or state a vessel-specific legal rationale. Reuters and Associated Press reported the announcement; AP said the military supplied no evidence that this vessel was ferrying drugs.
- Associated Press counted at least 231 people killed in 69 U.S. military boat strikes after the September 19 operation. That independently reported campaign count does not verify the identity, conduct or legal status of every person killed.

## SIGNIFICANCE

The September 19 strike raises the independently reported campaign toll to at least 231 deaths across 69 strikes. Continued use of lethal military force without published target evidence or a vessel-specific legal rationale keeps authorization, identification, proportionality and accountability questions unresolved.

## GOALPOST / RESPONSE

SOUTHCOM says confirmed intelligence identifies vessels actively involved in narco-trafficking, and the administration says the campaign protects Americans from cartels and fatal drugs. Public target evidence, cargo and crew records, legal authority, strike footage, congressional reporting, corrections for mistaken identification, campaign counts and independently measured effects on trafficking and overdoses are the tests.

## MAYBE / THEREFORE

Maybe classified intelligence reliably identifies cartel vessels and the government withholds details to protect sources and operations. Therefore the record establishes that the military announced a September 19 strike and four deaths—not that the unnamed people were proved to be traffickers, that the vessel carried drugs, or that lethal force was legally authorized or effective.


## SOURCES

- [U.S. Southern Command — lethal kinetic strike, August 25, 2026](https://www.southcom.mil/News/PressReleases/Article/4583027/lethal-kinetic-strike-august-25-2026/) — primary military announcement and administration attribution
- [Associated Press — U.S. military kills four in Caribbean boat strike](https://apnews.com/article/trump-cartels-military-strike-caribbean-8a3aead624d51d2ec5a3885f3f148111) — independent reporting with campaign-wide casualty and legal context
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel](https://www.southcom.mil/News/PressReleases/Article/4591750/interdiction-of-narco-terrorist-refueling-vessel-sept-5-2026/) — primary military release documenting the boarding, crew transfer and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel, September 7](https://www.southcom.mil/News/PressReleases/Article/4591820/interdiction-of-narco-terrorist-refueling-vessel-sept-7-2026/) — primary military release documenting crew removal, planned transfer to Ecuador and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [Associated Press — U.S. sinks Ecuadorian vessel it alleges was tied to Los Choneros](https://apnews.com/article/ecuador-us-boat-drug-trafficking-sinking-pacific-fishermen-551b40890fe249597d0236087fed019a) — independent reporting on the SOUTHCOM operation, video, crew disposition and broader boat-strike campaign
- [U.S. Southern Command — Interdiction of Narco-Terrorist Refueling Vessel, September 8](https://www.southcom.mil/News/PressReleases/Article/4593113/interdiction-of-narco-terrorist-refueling-vessel-sept-8-2026/) — primary military release documenting removal and transfer of individuals and sinking while attributing the trafficking and Los Choneros claims to intelligence
- [U.S. Southern Command — Lethal Kinetic Strike, September 9](https://www.southcom.mil/News/PressReleases/Article/4594213/lethal-kinetic-strike-september-9-2026/) — primary military release announcing a Caribbean strike and three deaths while attributing trafficking activity to undisclosed intelligence
- [Reuters — U.S. announces Caribbean vessel strike killing three](https://www.reuters.com/world/us-strikes-vessel-caribbean-killing-three-2026-09-10/) — independent reporting on SOUTHCOM's announcement, expressly noting that Reuters could not immediately verify it
- [Reuters — U.S. military announces September 19 Caribbean vessel strike killing four](https://www.reuters.com/world/us-says-it-killed-four-people-strike-vessel-caribbean-2026-09-20/) — independent reporting on a military announcement and attributed intelligence claim
- [Associated Press — U.S. military says September 19 Caribbean boat strike killed four](https://apnews.com/article/trump-cartels-military-strike-caribbean-95f3d4ae10f8e2a4a193f601101898d9) — independent reporting with campaign totals and explicit missing-evidence limitation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
