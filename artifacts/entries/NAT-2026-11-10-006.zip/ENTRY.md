# Trump signs law expanding National Taxpayer Advocate independence

**Entry ID:** NAT-2026-11-10-006
**Date:** November 10, 2026
**Checked:** 2026-11-11 12:05 AM EST
**Evidence state:** White House signature announcement and primary enrolled statutory text; law enacted, implementation and measured taxpayer outcomes unresolved
**Review state:** current-standard-reviewed

H.R. 997 gives the advocate direct counsel and broader personnel authority; implementation and effects on taxpayer assistance remain unmeasured.

## THE FACTS

- The White House announced that President Trump signed H.R. 997, the National Taxpayer Advocate Enhancement Act of 2025, into law on November 10. The page was published at 4:03 p.m. EST, before the prior archive boundary; no exact signing time was stated, so this release records a same-day retrospective discovery rather than a post-boundary signature.
- The enrolled text authorizes the National Taxpayer Advocate to appoint counsel who reports directly to the advocate, consults with the Office of Chief Counsel and provides independent legal advice. It also permits the advocate to appoint personnel and requires notice and consultation before specified senior personnel actions.
- The statute says its amendments take effect as if included in the 1998 IRS restructuring law. It changes internal authority and reporting relationships; it does not establish that any counsel has been appointed, a taxpayer case has changed or service outcomes have improved.
- Supporters frame the law as restoring the independent taxpayer-assistance structure Congress intended. The observable tests are appointments, implementing procedures, recommendations, dispute resolution, case outcomes, response times and congressional oversight.

## SIGNIFICANCE

The law strengthens an independent office inside the IRS that identifies systemic taxpayer problems and assists with difficult cases. Its formal authority is now enacted, while its practical effect depends on staffing, internal access and measurable taxpayer outcomes.

## GOALPOST / RESPONSE

Supporters say direct counsel and personnel control will make the advocate more independent and effective. The tests are actual appointments, published procedures, recommendations accepted or rejected, case-resolution measures, taxpayer-service outcomes and oversight findings.

## MAYBE / THEREFORE

Maybe direct legal and personnel authority will help the advocate challenge IRS positions and resolve taxpayer problems more effectively, or internal coordination and resources may limit the change. Therefore the record establishes an enacted structural reform—not a completed appointment, a resolved taxpayer dispute or measured improvement in IRS service.


## SOURCES

- [White House — H.R. 997, H.R. 1703, H.R. 1945 and H.R. 7730 signed into law](https://www.whitehouse.gov/briefings-statements/2026/11/congressional-bills-h-r-997-h-r-1703-h-r-1945-and-h-r-7730-signed-into-law/) — primary announcement of presidential signatures and short descriptions
- [GovInfo — enrolled text of H.R. 997](https://www.govinfo.gov/content/pkg/BILLS-119hr997enr/html/BILLS-119hr997enr.htm) — primary enrolled legislation establishing National Taxpayer Advocate personnel and counsel authorities

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
