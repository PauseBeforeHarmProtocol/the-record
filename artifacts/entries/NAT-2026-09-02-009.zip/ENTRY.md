# U.S. Mint begins selling Trump semiquincentennial $1 coins

**Entry ID:** NAT-2026-09-02-009
**Date:** March 19–September 2, 2026
**Checked:** 2026-09-02 6:02 PM EDT
**Evidence state:** primary U.S. Mint sales notice and live product page, independent Associated Press reporting and Reuters background; retail availability implemented, general circulation and legal resolution pending
**Review state:** current-standard-reviewed

Sales of rolls and bags opened at noon EDT; the legal-tender coins are collectible products sold above face value, while general circulation remains planned for fall.

## THE FACTS

- The U.S. Mint opened orders at noon EDT on September 2 for rolls and bags of semiquincentennial $1 coins bearing President Trump's image. Its product page accepted orders and showed the items on backorder by the review cutoff.
- The Mint priced 25-coin rolls at $61 and 100-coin bags at $154.50, with an initial limit of two of each product per household during the first 24 hours. The coins have a $1 legal-tender face value but are being sold as numismatic products at a premium.
- The Mint says the coins commemorate the nation's 250th anniversary and relies on semiquincentennial coin authority and historical precedent. Associated Press and Reuters reported objections that federal law generally bars images of living people or current presidents on currency; the administration disputes that those restrictions foreclose this commemorative design.
- The September 2 sale is implemented distribution through the Mint's retail channel. It is not evidence that the coin has entered general circulation, which the Mint says is planned for fall 2026, or that courts have resolved the statutory dispute.

## SIGNIFICANCE

The sale turns an earlier design approval into a concrete federal product and raises an institutional question about using official money to depict a sitting president. Its reach and fiscal effect depend on sales, production and distribution, while the legal dispute remains unresolved.

## GOALPOST / RESPONSE

The Mint and administration describe the design as a lawful commemoration of the 250th anniversary and cite prior presidential imagery. Critics argue that depicting a living sitting president conflicts with statutory limits and anti-monarchical traditions. Final mintage, sales, net revenue or cost, circulation release, inspector-general or congressional review and any court ruling are the tests.

## MAYBE / THEREFORE

Maybe the coins will function as a limited anniversary collectible under a lawful special authorization, or the design may be challenged as unauthorized self-commemoration using federal currency. Therefore the record confirms that official sales began—not that the coins are broadly circulating, profitable, judicially validated or accepted as lawful by all authorities.


## SOURCES

- [U.S. Mint — Trump semiquincentennial $1 coin rolls and bags available September 2](https://www.usmint.gov/news/press-releases/2026-semiquincentennial-president-donald-j-trump-one-dollar-coin-rolls-and-bags-available-september-2) — primary agency notice of the noon EDT sales launch, prices, quantities and household limit
- [U.S. Mint — Trump $1 coin rolls and bags product page](https://www.usmint.gov/semiquincentennial-president-donald-j-trump-2026-1-coin-rolls-bags-MASTER_SEMIQDJT.html) — primary sales page showing orders open, product configurations and backorder status
- [Associated Press — U.S. Mint begins sales of Trump $1 coin](https://apnews.com/article/trump-coin-america-250-gold-817c62abfcec862b8c1ec622e5809ab4) — independent reporting on the implemented sale, legal controversy and administration rationale
- [Reuters — Trump-appointed arts panel approves coin bearing president's image](https://www.reuters.com/world/us/trump-appointed-arts-panel-approves-gold-coin-featuring-presidents-image-2026-03-19/) — independent background reporting on the design approval, statutory dispute and administration rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
