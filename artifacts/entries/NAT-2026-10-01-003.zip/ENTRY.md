# Treasury opens Iran rail and automotive sectors to sanctions and lists industrial networks

**Entry ID:** NAT-2026-10-01-003
**Date:** October 1, 2026
**Checked:** 2026-10-01 6:00 PM EDT
**Evidence state:** primary Treasury determinations and target descriptions plus independent reporting; sanctions implemented, underlying allegations and downstream effects not independently established
**Review state:** current-standard-reviewed

OFAC issued two sectoral determinations and designated Iranian companies and foreign suppliers; legal restrictions took effect, while revenue and policy effects remain unmeasured.

## THE FACTS

- Treasury announced on October 1 that OFAC issued two determinations under Executive Order 13902 authorizing sanctions against people operating in Iran’s automotive and rail sectors. The determinations expand the categories of activity exposed to designation; they do not automatically designate every participant in those sectors.
- OFAC simultaneously designated major Iranian automakers and suppliers, the state-owned Islamic Republic of Iran Railway Company, Raja Passenger Trains Company, Railway Transportation Company, and additional industrial, metals and foreign procurement entities under Executive Orders 13902 and 13871.
- The action generally blocks U.S.-jurisdiction property of designated persons, restricts covered U.S.-person transactions and applies the 50-percent ownership rule. Treasury also described possible secondary-sanctions exposure for certain dealings.
- Treasury said the action was intended to reduce revenue and logistical capacity supporting Iran and the IRGC. Those rationales and descriptions of company conduct are agency allegations; the action does not independently prove every allegation, identify total assets blocked or establish a measured revenue loss, industrial shutdown or policy concession.

## SIGNIFICANCE

The new sectoral determinations broaden Treasury’s legal basis for future designations beyond the named companies and make rail and automotive activity part of the administration’s wartime economic-pressure campaign.

## GOALPOST / RESPONSE

Treasury says the measures will drain revenue and disrupt procurement and logistics. The tests are additional designations, blocked assets, licensing and enforcement records, trade and production data, humanitarian or transportation effects, and any verified change in Iranian financing or policy.

## MAYBE / THEREFORE

Maybe broad sectoral exposure will deter foreign suppliers and constrain revenue, or firms may reroute transactions while costs fall on civilian transport and industry. Therefore the verified development is expanded sanctions authority plus named designations—not quantified economic collapse, eliminated financing or an Iranian concession.


## SOURCES

- [Treasury — Operation Economic Outcast targets Iranian rail, automotive and industrial networks](https://home.treasury.gov/news/press-releases/sb0643) — primary sanctions determinations and designation announcement
- [Reuters — U.S. sanctions Iran rail and automotive sectors and suppliers](https://www.reuters.com/world/middle-east/us-sanctions-target-irans-auto-rail-sectors-after-blockade-chokes-shipping-lanes-2026-10-01/) — independent reporting on implemented sectoral determinations and designations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
