# FTC confirms investigation of AI-company consumer risks

**Entry ID:** NAT-2026-09-30-007
**Date:** September 30, 2026
**Checked:** 2026-10-01 5:57 AM EDT
**Evidence state:** two independent reports carrying on-record FTC confirmation; investigation confirmed, precise targets and demands partly unresolved, no violation finding or enforcement action
**Review state:** current-standard-reviewed

The agency confirmed an inquiry involving OpenAI, Anthropic and other companies; it had not filed a complaint, made a violation finding or imposed a remedy by cutoff.

## THE FACTS

- The Federal Trade Commission confirmed on September 30 that it had opened an investigation into OpenAI, Anthropic and other artificial-intelligence companies over possible risks their technology poses to consumers.
- An agency spokesperson told CBS News that the FTC was examining possible FTC Act issues and planned to request information from companies and the nonprofit research group METR. A report that the agency was drafting civil investigative demands came from the New York Post and was not independently confirmed as served by the cutoff.
- Associated Press and CBS reported that OpenAI and Anthropic did not immediately respond to requests for comment. Their silence is not evidence of wrongdoing, and disclosed model or agent incidents do not by themselves establish an FTC Act violation.
- The investigation was disclosed one day after Trump and major technology executives signed a voluntary AI safety accord. Trump has emphasized rapid development and industry self-policing; the FTC inquiry is a separate law-enforcement process and does not convert the accord into a binding regulation.
- No public FTC complaint, administrative charge, civil investigative demand, testimony, settlement, penalty or violation finding was identified in the inspected material by the cutoff.

## SIGNIFICANCE

A confirmed federal consumer-protection inquiry creates a formal accountability channel for claimed AI risks while the administration otherwise emphasizes voluntary controls and rapid development. Its consequence depends on the information demanded, legal theory, evidence and any later enforcement action.

## GOALPOST / RESPONSE

The administration's strongest stated approach favors innovation and company self-policing, while the FTC says existing consumer-protection law may apply to company conduct. The companies had not publicly responded in the inspected reports. Filed demands, testimony, a Commission complaint or closing statement, company responses and any remedies are the tests.

## MAYBE / THEREFORE

Maybe the inquiry identifies deceptive or unfair practices warranting enforcement, or it may close without a case after information gathering. Therefore the record establishes a confirmed investigation into possible consumer risks—not wrongdoing, a served demand, a binding AI-safety rule or an enforcement outcome.


## SOURCES

- [Associated Press — FTC confirms investigation of AI-company consumer risks](https://apnews.com/article/ftc-ai-investigation-anthropic-openai-89ac416717adbfb1d72f2d85e6ce83d1) — independent reporting with on-record agency confirmation
- [CBS News — FTC investigation of Anthropic, OpenAI and other AI companies](https://www.cbsnews.com/news/ftc-investigation-openai-anthropic-ai-safety/) — independent reporting with on-record agency confirmation and scope details

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
