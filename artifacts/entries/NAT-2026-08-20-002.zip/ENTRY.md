# Trump sets a goal of 1,000 annual U.S. space launches and reentries by 2030

**Entry ID:** NAT-2026-08-20-002
**Date:** August 20, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** primary presidential memorandum and independent reporting; targets not yet achieved

NSPM-17 directs expedited permitting, new infrastructure, and a commercial-first approach while pairing launch growth with Moon deadlines.

## THE FACTS

- President Trump signed National Security Presidential Memorandum 17, directing federal policy toward 1,000 U.S. commercial launches and reentries annually by 2030; Reuters reported 178 in the prior year.
- The memorandum calls for more launch and reentry sites, including possible use of federal land, faster permitting and environmental review, spectrum coordination, and preference for commercial services when available.
- It also states goals of returning Americans to the Moon by 2028 and beginning construction of an initial lunar base by 2030, and calls for identifying at least one federal reentry site within 90 days.

## SIGNIFICANCE

The memorandum couples industrial policy and national-security goals with major changes to permitting, federal land use, spectrum, and public infrastructure. Its success can be measured against launch safety, schedule, environmental review quality, competition, public cost, and the stated numerical deadlines.

## GOALPOST / RESPONSE

The administration says higher launch cadence and commercial-first procurement are needed for U.S. leadership and security. The memorandum establishes direction and deadlines, not delivery; future launch totals, accident rates, site approvals, and lunar milestones are the relevant evidence.


## SOURCES

- [White House — NSPM-17 national space-transportation policy](https://www.whitehouse.gov/presidential-actions/2026/08/national-security-presidential-memorandum-nspm-17/) — primary presidential memorandum
- [Reuters — memorandum to expand U.S. space launches](https://www.reuters.com/science/trump-signs-memo-help-drastically-boost-us-space-launches-2026-08-20/) — independent reporting on a presidential memorandum

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
