# Trump threatens to halt trade with deficit countries unless Fed cuts rates

**Entry ID:** NAT-2026-09-04-006
**Date:** September 4, 2026
**Checked:** 2026-09-04 12:00 PM EDT
**Evidence state:** primary Truth Social statement plus independent Reuters reporting; announced threat only, with no implementing instrument or rate decision
**Review state:** current-standard-reviewed

The president publicly linked an unspecified future trade cutoff to monetary policy; no country list, legal instrument, deadline or implemented restriction accompanied the threat.

## THE FACTS

- After the August employment report, Trump posted that the United States should have the world's lowest interest rate and threatened to stop trading with countries with which the United States runs a deficit unless the Federal Reserve lowers rates.
- The post identified no countries, covered goods or services, statutory authority, effective date, implementing agency, exemption process or negotiating terms. No executive order, proclamation, tariff schedule or trade suspension implementing the statement was located by cutoff.
- Trump asserted that a Supreme Court tariff decision had recognized an absolute presidential right to take the action. The post did not identify a holding authorizing a total trade cutoff conditioned on central-bank policy, and the record does not treat that legal claim as independently established.
- Reuters reported the statement after the stronger-than-expected jobs estimate increased market expectations of a possible September rate hike. The Federal Reserve had not changed rates in response by cutoff.

## SIGNIFICANCE

Conditioning access to foreign trade on a domestic central-bank decision would combine two consequential presidential pressure tools and could affect prices, supply chains, diplomacy and perceptions of Federal Reserve independence. The lack of operational detail makes the immediate legal and economic effect uncertain.

## GOALPOST / RESPONSE

Trump says high rates place the United States at an unfair disadvantage and that trade leverage can force fairer outcomes. A signed legal instrument, identified authority and countries, agency guidance, actual restrictions, negotiations, market and price effects, congressional response, Federal Reserve decision and judicial review are the tests.

## MAYBE / THEREFORE

Maybe the statement is negotiating rhetoric intended to increase pressure without an actual cutoff, or it may foreshadow a broad and disruptive exercise of trade power. Therefore the record confirms a consequential presidential threat and its stated condition—not implemented trade restrictions, a Federal Reserve concession or judicial approval of the claimed authority.


## SOURCES

- [Donald Trump — trade cutoff threat tied to Federal Reserve rates](https://truthsocial.com/@realDonaldTrump/117213056648777213) — primary presidential statement establishing what Trump published, not implementation or independent proof of its legal and economic claims
- [Reuters — Trump threatens to stop trading with deficit countries unless Fed cuts rates](https://www.reuters.com/business/trump-says-if-fed-doesnt-cut-rates-hell-stop-trading-with-some-nations-2026-09-04/) — independent reporting on the presidential threat and its immediate labor-market and monetary-policy context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
