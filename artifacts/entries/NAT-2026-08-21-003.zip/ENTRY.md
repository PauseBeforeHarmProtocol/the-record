# Federal judge strikes down immigrant-visa processing suspension for 75 countries

**Entry ID:** NAT-2026-08-21-003
**Date:** August 21–22, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** federal district-court ruling described in independent reporting; appellate status subject to change
**Review state:** current-standard-reviewed

The court held that the State Department could not categorically stop immigrant-visa processing based on nationality under the authority it cited.

## THE FACTS

- U.S. District Judge Jeannette Vargas struck down a State Department policy suspending immigrant-visa processing for applicants from 75 countries.
- The judge described the categorical nationality-based suspension as 'patently unlawful' and held that Secretary of State Marco Rubio had exceeded his authority.
- The ruling addressed immigrant-visa processing rather than every form of entry restriction. Its practical reach may still be affected by an appeal, a stay, or a replacement policy grounded in different authority.

## SIGNIFICANCE

The decision draws a line between executive administration of visas and a broad nationality-based suspension that Congress did not authorize through the mechanism used. It also affects families and applicants whose cases were halted without individualized adjudication.

## GOALPOST / RESPONSE

The administration framed the suspension as immigration control and national-interest screening. The court held that the chosen categorical tool exceeded statutory authority; an appeal or narrower policy would require a separate record.

## MAYBE / THEREFORE

Maybe the categorical suspension was intended to serve immigration control and national-interest screening, and its practical effect may change through a stay, appeal, or narrower policy grounded in different authority. Therefore the record treats the mechanism—not every form of entry restriction—as struck down and tests appellate status, any replacement policy, and whether halted cases resume individualized adjudication.


## SOURCES

- [Reuters — judge strikes down 75-country immigrant-visa suspension](https://www.reuters.com/legal/government/us-judge-strikes-down-policy-suspending-immigrant-visa-processing-75-nations-2026-08-22/) — independent reporting on a federal court ruling

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
