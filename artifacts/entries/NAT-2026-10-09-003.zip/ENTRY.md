# Treasury licenses Russian diesel imports after Trump announces Putin supply deal

**Entry ID:** NAT-2026-10-09-003
**Date:** October 9, 2026
**Checked:** 2026-10-11 6:02 PM EDT
**Evidence state:** operative OFAC license and program notice, complete presidential post, a Senate Foreign Relations Committee statement, and independent Reuters and Associated Press reporting; license implemented, bipartisan legality challenge and administration authority claim documented, contracts, deliveries, judicial resolution and price effects unresolved
**Review state:** current-standard-reviewed

OFAC's six-month license is operative, while the quantities, contracts, payment terms, delivery schedule and sustained price effect remain announced or unresolved.

## THE FACTS

- President Trump announced on Truth Social that, after a call with Vladimir Putin, Russia had agreed to supply more than 300,000 metric tons of diesel immediately, 500,000 tons in November, 1 million tons thereafter and potentially another 3 million tons. Reuters and Associated Press independently reported the announcement, but the post and reporting did not establish completed contracts or deliveries.
- The Treasury Department's Office of Foreign Assets Control issued Russia-related General License 135 on October 9. The operative license authorizes transactions otherwise prohibited under the Russian sanctions programs that are ordinarily incident and necessary to the sale, delivery, offloading and importation, including into the United States, of Russian-origin diesel through 12:01 a.m. EDT on April 7, 2027; it excludes debits to blocked accounts of the Russian central bank, National Wealth Fund or Finance Ministry at U.S. financial institutions.
- Associated Press reported that the White House did not answer who would pay, when the announced fuel would become available or whether November supplies would arrive before the midterm election. Reuters reported that the initial 300,000 tons equaled about 2.25 million barrels, compared with roughly 1.5 million barrels of U.S. diesel exports per day, and quoted analysts who expected limited sustained price effects; diesel futures fell after the announcement, but delivery and consumer-price effects were not measured by cutoff.
- Trump said the action was intended to lower prices for farmers, ranchers and truckers. Russia's deputy prime minister said export restrictions would be lifted ahead of schedule, while Ukrainian President Volodymyr Zelenskyy argued the arrangement would finance Russia's war. Those positions are attributed responses, not proof of the agreement's implementation or ultimate effects.
- On October 11, seven senators—four Republicans and three Democrats—issued a joint statement saying the Russian-diesel decision runs counter to the 2022 statutory import ban and that the administration had not consulted Congress or submitted the explanation they said the law requires. This is a bipartisan congressional allegation, not a court ruling. Treasury Secretary Scott Bessent responded that the administration would proceed using existing legal authority and that lawmakers who say the earlier or current sanctions laws prohibit the deal are wrong; Senator John Barrasso separately defended the deal as a potential source of leverage and a cost-reduction decision.

## SIGNIFICANCE

The license reverses part of the practical sanctions barrier around Russian diesel for six months while the United States and allies are pressuring Russia over its war in Ukraine. A bipartisan group of senators now disputes its legality and says required consultation and explanation were omitted, while the administration asserts existing authority. Its significance depends on whether cargoes move, who buys them, whether payments reach sanctioned actors, whether Congress or a court tests the license, and whether additional supply materially changes diesel prices.

## GOALPOST / RESPONSE

The administration says it has legal authority and that Russian supply will bring prices down quickly. The tests are a published legal explanation or congressional consultation record, any oversight or litigation outcome, signed contracts, tanker loadings and arrivals, payment channels, OFAC compliance guidance, Russian export volumes, sanctions enforcement, U.S. and global diesel inventories and sustained retail-price movement.

## MAYBE / THEREFORE

Maybe OFAC lawfully used existing waiver authority to open a useful marginal supply channel during a severe shortage, as the administration argues, or the license may conflict with statutory import restrictions and required consultation, as seven senators contend; constrained Russian refining and displacement of other buyers may also make the announced quantities too small to change prices much. Therefore the record establishes an operative license, announced supply volumes and a documented interbranch legal dispute—not a judicial finding of illegality, proof that all quantities were contracted or delivered, or evidence of the promised price decline.


## SOURCES

- [Donald J. Trump — announcement of claimed Russia diesel supply agreement](https://truthsocial.com/@realDonaldTrump/117412435306815143) — primary presidential statement; publication evidence only
- [OFAC — Russia-related General License 135](https://ofac.treasury.gov/media/937216/download?inline=) — operative primary sanctions license
- [OFAC — Russian Harmful Foreign Activities Sanctions program page](https://ofac.treasury.gov/sanctions-programs-and-country-information/russian-harmful-foreign-activities-sanctions) — official program notice listing General License 135
- [Reuters — Trump says Russia will supply diesel after Treasury license](https://www.reuters.com/business/energy/trump-big-announcement-coming-up-diesel-2026-10-09/) — independent reporting of the announcement, license and market context
- [Associated Press — Trump announces Russian diesel deal and Treasury eases sanctions](https://apnews.com/article/trump-russia-diesel-midterms-12baccc7aade559bf329079b0548c9da) — independent reporting of the announcement, license, responses and unresolved terms
- [Senate Foreign Relations Committee minority — bipartisan statement on Russian diesel imports](https://www.foreign.senate.gov/press/dem/release/ranking-member-shaheen-and-6-bipartisan-senatorsstatement-on-legality-of-imports-of-russian-diesel-fuel) — primary congressional statement alleging conflict with statutory import restrictions and omitted consultation or explanation
- [Reuters — bipartisan senators challenge Russian diesel deal and administration defends authority](https://www.reuters.com/business/energy/prominent-republican-senator-says-trumps-russian-diesel-deal-may-be-illegal-2026-10-11/) — independent reporting on the congressional legality challenge, Treasury response and named Republican defense
- [Associated Press — senators call for reversal of Russian diesel plan](https://apnews.com/article/trump-diesel-russia-ukraine-senators-protest-93fa63c8a88e538f1456e7d448fc550d) — independent reporting on the bipartisan statement, statutory dispute and administration-aligned response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
