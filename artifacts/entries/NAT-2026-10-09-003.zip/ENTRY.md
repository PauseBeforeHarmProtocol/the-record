# Two Russian diesel tankers change course as U.S. discharge remains uncertain

**Entry ID:** NAT-2026-10-09-003
**Date:** October 9–November 5, 2026
**Checked:** 2026-11-05 6:08 PM EST
**Evidence state:** operative OFAC license and prior vessel data, plus independent Associated Press and Reuters reporting on November 5 course changes and discharge uncertainty; license remains effective, U.S. unloading and outcomes unverified
**Review state:** current-standard-reviewed

The license remains operative, but two initially U.S.-bound cargoes reversed course amid compliance warnings; no U.S. unloading or promised price effect is established.

## THE FACTS

- President Trump announced on Truth Social that, after a call with Vladimir Putin, Russia had agreed to supply more than 300,000 metric tons of diesel immediately, 500,000 tons in November, 1 million tons thereafter and potentially another 3 million tons. Reuters and Associated Press independently reported the announcement, but the post and reporting did not establish completed contracts or deliveries.
- The Treasury Department's Office of Foreign Assets Control issued Russia-related General License 135 on October 9. The operative license authorizes transactions otherwise prohibited under the Russian sanctions programs that are ordinarily incident and necessary to the sale, delivery, offloading and importation, including into the United States, of Russian-origin diesel through 12:01 a.m. EDT on April 7, 2027; it excludes debits to blocked accounts of the Russian central bank, National Wealth Fund or Finance Ministry at U.S. financial institutions.
- Associated Press reported that the White House did not answer who would pay, when the announced fuel would become available or whether November supplies would arrive before the midterm election. Reuters reported that the initial 300,000 tons equaled about 2.25 million barrels, compared with roughly 1.5 million barrels of U.S. diesel exports per day, and quoted analysts who expected limited sustained price effects; diesel futures fell after the announcement, but delivery and consumer-price effects were not measured by cutoff.
- Trump said the action was intended to lower prices for farmers, ranchers and truckers. Russia's deputy prime minister said export restrictions would be lifted ahead of schedule, while Ukrainian President Volodymyr Zelenskyy argued the arrangement would finance Russia's war. Those positions are attributed responses, not proof of the agreement's implementation or ultimate effects.
- On October 11, seven senators—four Republicans and three Democrats—issued a joint statement saying the Russian-diesel decision runs counter to the 2022 statutory import ban and that the administration had not consulted Congress or submitted the explanation they said the law requires. This is a bipartisan congressional allegation, not a court ruling. Treasury Secretary Scott Bessent responded that the administration would proceed using existing legal authority and that lawmakers who say the earlier or current sanctions laws prohibit the deal are wrong; Senator John Barrasso separately defended the deal as a potential source of leverage and a cost-reduction decision.
- Reuters reported on October 23 that the Malta-flagged tanker Agioi Fanendes loaded about 40,000 metric tons of ultra-low-sulfur diesel at Russia's Primorsk port on October 22 and was sailing toward New York with an estimated November 7 arrival. The buyer and seller were not identified. The loading and departure are implementation evidence for one cargo, but no U.S. delivery, payment, sanctions-compliance determination or consumer-price effect had occurred by cutoff.
- The introduced text of H.R. 10866, dated October 22, would nullify General License 135, prohibit Russian-energy import waivers and specified Treasury spending, and require Ukraine intelligence support with notice of interruptions. Fitzpatrick introduced it with Perez and Bacon; it was referred to three committees. IANS reported the proposal on October 29. This is an earlier-date recovery of a formal bill—not enactment, a revoked license, stopped cargo or a judicial finding that the administration acted illegally.
- Associated Press reported on November 5 that two tankers initially bound for the United States had changed course after New Jersey officials, lawmakers and other actors warned that handling Russian diesel could create sanctions, statutory or future-investigation exposure. Vessel movements are observable implementation evidence, but motive and final destination were not adjudicated.
- Treasury told AP that General License 135 remained consistent with prior actions and applicable law. That is the administration's legal position, not a court ruling; the bipartisan repeal bill remained pending and no agency revocation was located by cutoff.
- Reuters separately reported that the first expected U.S.-bound shipment faced regulatory, legislative and sanctions uncertainty and that discharge was not guaranteed. No reviewed evidence established that Russian diesel had been unloaded in the United States, that the larger promised volumes were contracted or delivered, or that the policy reduced sustained retail prices.

## SIGNIFICANCE

The course changes are the first reported operational setback for the licensed import plan and show that formal authorization does not ensure commercial delivery. The action remains legally permitted under the license, but political, port and compliance risk may limit implementation before any price effect can be measured.

## GOALPOST / RESPONSE

The administration says the license is lawful and additional supply can lower costs; opponents argue it conflicts with the statutory import ban and could finance Russia's war. Port records, bills of lading, ownership and payment data, actual unloading, license or legislative changes, court rulings and sustained retail-price movements remain the tests.

## MAYBE / THEREFORE

Maybe cargoes will reroute temporarily and later enter under the license, or compliance and political risk may prevent the announced supply from reaching U.S. markets. Therefore two reported course changes and unresolved discharge are documented—not a revoked license, a judicial illegality finding, completed imports or a measured price benefit.


## SOURCES

- [Donald J. Trump — announcement of claimed Russia diesel supply agreement](https://truthsocial.com/@realDonaldTrump/117412435306815143) — primary presidential statement; publication evidence only
- [OFAC — Russia-related General License 135](https://ofac.treasury.gov/media/937216/download?inline=) — operative primary sanctions license
- [OFAC — Russian Harmful Foreign Activities Sanctions program page](https://ofac.treasury.gov/sanctions-programs-and-country-information/russian-harmful-foreign-activities-sanctions) — official program notice listing General License 135
- [Reuters — Trump says Russia will supply diesel after Treasury license](https://www.reuters.com/business/energy/trump-big-announcement-coming-up-diesel-2026-10-09/) — independent reporting of the announcement, license and market context
- [Associated Press — Trump announces Russian diesel deal and Treasury eases sanctions](https://apnews.com/article/trump-russia-diesel-midterms-12baccc7aade559bf329079b0548c9da) — independent reporting of the announcement, license, responses and unresolved terms
- [Senate Foreign Relations Committee minority — bipartisan statement on Russian diesel imports](https://www.foreign.senate.gov/press/dem/release/ranking-member-shaheen-and-6-bipartisan-senatorsstatement-on-legality-of-imports-of-russian-diesel-fuel) — primary congressional statement alleging conflict with statutory import restrictions and omitted consultation or explanation
- [Reuters — bipartisan senators challenge Russian diesel deal and administration defends authority](https://www.reuters.com/business/energy/prominent-republican-senator-says-trumps-russian-diesel-deal-may-be-illegal-2026-10-11/) — independent reporting on the congressional legality challenge, Treasury response and named Republican defense
- [Associated Press — senators call for reversal of Russian diesel plan](https://apnews.com/article/trump-diesel-russia-ukraine-senators-protest-93fa63c8a88e538f1456e7d448fc550d) — independent reporting on the bipartisan statement, statutory dispute and administration-aligned response
- [Reuters — first Russian diesel cargo under licensed channel heads to New York](https://www.reuters.com/business/energy/tanker-carrying-40000-t-russian-diesel-heads-new-york-after-putin-trump-deal-2026-10-23/) — independent trade and vessel-data reporting; cargo in transit, not delivered
- [GPO — H.R. 10866, introduced text](https://www.govinfo.gov/content/pkg/BILLS-119hr10866ih/html/BILLS-119hr10866ih.htm) — primary introduced bill; complete text inspected, proposal not enacted law
- [IANS / Gulf News — bipartisan bill seeks to block Russian diesel deal](https://gulfnews.com/world/americas/bipartisan-us-bill-seeks-to-block-trumps-russian-diesel-deal-1.500727716) — independent reporting of proposed legislation; earlier introduction date retained
- [Associated Press — Russian diesel tankers change course amid legal and sanctions warnings](https://apnews.com/article/5c5bb86ddf41fc7a8b51b0698552c3d4) — independent reporting on vessel movements, compliance warnings and Treasury response
- [Reuters — renewed refinery attacks and uncertainty over Russian diesel shipments to the United States](https://www.reuters.com/world/renewed-refinery-attacks-deplete-russian-diesel-supply-us-deal-focus-2026-11-05/) — independent reporting on shipment status, supply conditions and unresolved U.S. discharge

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
