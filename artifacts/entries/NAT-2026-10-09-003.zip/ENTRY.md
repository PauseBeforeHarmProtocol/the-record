# Treasury licenses Russian diesel imports after Trump announces Putin supply deal

**Entry ID:** NAT-2026-10-09-003
**Date:** October 9, 2026
**Checked:** 2026-10-09 5:57 PM EDT
**Evidence state:** operative OFAC license and program notice, complete presidential post, and independent Reuters and Associated Press reporting; license implemented, supply quantities announced, contracts, deliveries and price effects unresolved
**Review state:** current-standard-reviewed

OFAC's six-month license is operative, while the quantities, contracts, payment terms, delivery schedule and sustained price effect remain announced or unresolved.

## THE FACTS

- President Trump announced on Truth Social that, after a call with Vladimir Putin, Russia had agreed to supply more than 300,000 metric tons of diesel immediately, 500,000 tons in November, 1 million tons thereafter and potentially another 3 million tons. Reuters and Associated Press independently reported the announcement, but the post and reporting did not establish completed contracts or deliveries.
- The Treasury Department's Office of Foreign Assets Control issued Russia-related General License 135 on October 9. The operative license authorizes transactions otherwise prohibited under the Russian sanctions programs that are ordinarily incident and necessary to the sale, delivery, offloading and importation, including into the United States, of Russian-origin diesel through 12:01 a.m. EDT on April 7, 2027; it excludes debits to blocked accounts of the Russian central bank, National Wealth Fund or Finance Ministry at U.S. financial institutions.
- Associated Press reported that the White House did not answer who would pay, when the announced fuel would become available or whether November supplies would arrive before the midterm election. Reuters reported that the initial 300,000 tons equaled about 2.25 million barrels, compared with roughly 1.5 million barrels of U.S. diesel exports per day, and quoted analysts who expected limited sustained price effects; diesel futures fell after the announcement, but delivery and consumer-price effects were not measured by cutoff.
- Trump said the action was intended to lower prices for farmers, ranchers and truckers. Russia's deputy prime minister said export restrictions would be lifted ahead of schedule, while Ukrainian President Volodymyr Zelenskyy argued the arrangement would finance Russia's war. Those positions are attributed responses, not proof of the agreement's implementation or ultimate effects.

## SIGNIFICANCE

The license reverses part of the practical sanctions barrier around Russian diesel for six months while the United States and allies are pressuring Russia over its war in Ukraine. Its significance depends on whether cargoes move, who buys them, whether payments reach sanctioned actors and whether additional supply materially changes diesel prices.

## GOALPOST / RESPONSE

The administration says Russian supply will bring prices down quickly. The tests are signed contracts, tanker loadings and arrivals, payment channels, OFAC compliance guidance, Russian export volumes, sanctions enforcement, U.S. and global diesel inventories and sustained retail-price movement.

## MAYBE / THEREFORE

Maybe the temporary license opens a useful marginal supply channel during a severe shortage, or constrained Russian refining and displacement of other buyers may make the announced quantities too small to change prices much. Therefore OFAC implemented a defined sanctions license and Trump announced supply volumes—not evidence that all quantities were contracted, delivered, paid for or capable of producing the promised price decline.


## SOURCES

- [Donald J. Trump — announcement of claimed Russia diesel supply agreement](https://truthsocial.com/@realDonaldTrump/117412435306815143) — primary presidential statement; publication evidence only
- [OFAC — Russia-related General License 135](https://ofac.treasury.gov/media/937216/download?inline=) — operative primary sanctions license
- [OFAC — Russian Harmful Foreign Activities Sanctions program page](https://ofac.treasury.gov/sanctions-programs-and-country-information/russian-harmful-foreign-activities-sanctions) — official program notice listing General License 135
- [Reuters — Trump says Russia will supply diesel after Treasury license](https://www.reuters.com/business/energy/trump-big-announcement-coming-up-diesel-2026-10-09/) — independent reporting of the announcement, license and market context
- [Associated Press — Trump announces Russian diesel deal and Treasury eases sanctions](https://apnews.com/article/trump-russia-diesel-midterms-12baccc7aade559bf329079b0548c9da) — independent reporting of the announcement, license, responses and unresolved terms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
