# FDA finalizes voluntary path for salt substitutes in standardized foods

**Entry ID:** NAT-2026-10-13-002
**Date:** October 9–13, 2026
**Checked:** 2026-10-13 12:05 PM EDT
**Evidence state:** primary FDA final rule and agency announcement; legal permission finalized, effective date scheduled, uptake and health outcomes unmeasured
**Review state:** current-standard-reviewed

The rule permits—but does not require—reformulation and takes effect December 14, subject to the dairy-product objection process.

## THE FACTS

- FDA announced the final rule on October 9 and formally published it October 13. It permits safe and suitable ingredients to replace some or all required or optional sodium chloride in standardized foods, while preserving each food's basic nature and essential characteristics. The rule does not require reformulation and does not itself approve a particular substitute.
- FDA says 139 standards of identity previously specified salt without allowing substitutes; the codified amendments revise 80 standards-of-identity regulations that cover those foods. The rule is effective December 14, 2026, subject to the statutory objection and hearing process for dairy provisions.
- The agency says excessive sodium contributes to hypertension, heart disease and stroke and expects added formulation flexibility could support lower-sodium products. Its economic analysis did not quantify or monetize health benefits because manufacturer uptake, formulations and consumer demand are uncertain; it identifies no mandatory regulatory cost because use is voluntary.
- Some substitutes use potassium salts, which can pose risks for people with impaired potassium excretion. FDA declined to create a new warning requirement in this rule and pointed to existing ingredient and Nutrition Facts labeling; manufacturers that reformulate may incur testing, relabeling or consumer-acceptance costs.

## SIGNIFICANCE

The final rule removes a federal formulation barrier across a broad set of standardized foods and creates an implemented regulatory option for sodium reduction. It does not establish that manufacturers will reformulate, consumers will accept the products or population sodium intake and disease will decline.

## GOALPOST / RESPONSE

FDA says flexibility will encourage innovation and healthier lower-sodium foods while existing safety and labeling rules protect consumers. Reformulation uptake, sodium content and sales, potassium exposure and adverse events, labeling comprehension, consumer acceptance and measured health outcomes are the tests.

## MAYBE / THEREFORE

Maybe voluntary flexibility produces meaningful sodium reductions without sacrificing safety or taste, or uptake may be limited and some substitutes may create new risks for susceptible consumers. Therefore FDA has finalized permission to use safe and suitable substitutes—not mandated their use, approved every substitute or demonstrated a public-health effect.


## SOURCES

- [Federal Register — salt substitutes in standardized foods final rule](https://www.federalregister.gov/documents/2026/10/13/2026-20848/use-of-salt-substitutes-to-reduce-the-sodium-content-in-standardized-foods) — primary final rule and regulatory analysis
- [FDA — final rule on salt substitutes in standardized foods](https://www.fda.gov/food/hfp-constituent-updates/fda-issues-final-rule-salt-substitutes-standardized-foods) — primary agency announcement and stated public-health rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
