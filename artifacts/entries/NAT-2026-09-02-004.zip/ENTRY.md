# Trump continues the election-interference national emergency for another year

**Entry ID:** NAT-2026-09-02-004
**Date:** September 2, 2026
**Checked:** 2026-09-02 6:02 AM EDT
**Evidence state:** primary presidential notice published in the Federal Register; emergency authority continued for one year, specific new interference findings or designations not supplied
**Review state:** current-standard-reviewed

The notice preserves emergency authorities beyond September 12, 2026; it does not itself designate a new actor, prove a specific interference campaign or impose a new sanction.

## THE FACTS

- President Trump continued for one year the national emergency created by Executive Order 13848 concerning foreign interference in, or efforts to undermine public confidence in, United States elections.
- The notice says unauthorized access to election and campaign infrastructure and covert propaganda or disinformation by persons substantially outside the United States continue to pose an unusual and extraordinary national-security and foreign-policy threat.
- The continuation preserves the emergency beyond September 12, 2026 and was transmitted to Congress under the National Emergencies Act. The underlying order provides an International Emergency Economic Powers Act framework for blocking property and related measures against persons determined to have engaged in covered interference.
- The continuation maintains existing authority. It does not itself identify or sanction a new person, establish that a particular 2026 operation occurred, change election-administration rules or report a measured reduction in foreign interference.

## SIGNIFICANCE

The annual continuation keeps extraordinary economic authorities available during the 2026 election period while the administration says digital vulnerabilities and foreign influence remain active threats. Whether the authority is used accurately and proportionately depends on later intelligence findings, designations and review.

## GOALPOST / RESPONSE

The White House says foreign access, propaganda and disinformation continue to threaten election infrastructure and public confidence, requiring the emergency to remain available. A competing concern is that broad emergency authority can outlast specific evidence or be applied selectively. Intelligence assessments, attribution evidence, designations, sanctions, congressional oversight, court review and election-security outcomes are the tests.

## MAYBE / THEREFORE

Maybe retaining the authority will deter or rapidly punish documented foreign interference, or it may continue an expansive emergency framework without transparent evidence of a new threat or demonstrated effect. Therefore the record confirms a one-year continuation of the existing national emergency—not proof of a specific interference operation, a new sanctions designation or improved election security.


## SOURCES

- [Federal Register — continuation of election-interference national emergency](https://www.federalregister.gov/documents/2026/09/02/2026-18046/continuation-of-the-national-emergency-with-respect-to-foreign-interference-in-or-undermining-public) — primary presidential notice continuing the national emergency for one year

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
