# FCC finalizes prospective restrictions on devices containing Covered List components

**Entry ID:** NAT-2026-09-11-001
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 AM EDT
**Evidence state:** complete primary final rule inspected; restrictions finalized with future effective and compliance dates, downstream security and market effects unmeasured
**Review state:** current-standard-reviewed

The October 13 rule targets logic-bearing hardware and adds online-marketplace duties; it does not revoke earlier authorizations or impose a general foreign-component ban.

## THE FACTS

- The Federal Communications Commission published a final rule on September 11, effective October 13, 2026, barring equipment authorization for a device containing a logic-bearing hardware component produced by an entity identified on the FCC Covered List when the finished device itself would be ineligible if produced by that entity.
- The rule is prospective: it does not affect equipment already authorized, and pending applications are exempt unless a later component change triggers review. It also declines at this time to extend the prohibition to software, firmware, passive components or every component associated with a foreign adversary.
- The FCC clarified that online marketplaces fall within its equipment-marketing rules and generally must display or verify a valid FCC identifier for covered radio-frequency devices. Compliance begins March 1, 2027 for marketplaces with physical access to or title over products and June 1, 2027 for marketplaces relying on third-party seller certification.
- Covered List entities face full recertification for equipment changes rather than the ordinary permissive-change process, subject to stated transition treatment. The rule changes authorization and marketing conditions; it does not itself identify compromised units, order replacement of installed equipment, appropriate funds or establish a measured reduction in security incidents.

## SIGNIFICANCE

The rule expands the FCC's supply-chain controls from finished products to specified components and adds enforceable marketplace screening duties. Its security benefits, compliance costs, product availability and evasion risks remain prospective rather than measured.

## GOALPOST / RESPONSE

The FCC says compromised logic-bearing components can create national-security vulnerabilities and that marketplace verification will reduce unlawful device sales. Authorization decisions, compliance records, enforcement actions, security incidents, product availability and measured costs are the tests.

## MAYBE / THEREFORE

Maybe component-level review and marketplace verification close genuine supply-chain gaps, or manufacturers may reroute components while compliant sellers bear costs and previously authorized equipment remains in use. Therefore the rule creates prospective authorization and marketing restrictions—not proof that a particular device is compromised or that the communications supply chain is now secure.


## SOURCES

- [FCC — Protecting Against National Security Threats to the Communications Supply Chain](https://www.federalregister.gov/documents/2026/09/11/2026-18535/protecting-against-national-security-threats-to-the-communications-supply-chain-through-the) — primary Federal Register final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
