# Judge requires advance notice of major Kennedy Center physical changes

**Entry ID:** NAT-2026-09-15-006
**Date:** September 15, 2026
**Checked:** 2026-09-17 6:01 PM EDT
**Evidence state:** Reuters and AP independently report the September 17 notice order and safety explanation; complete order unavailable; prior chronology retained
**Review state:** current-standard-reviewed

Reuters and AP report a 30-day notice requirement; the order is not demolition approval or final resolution of the broader closure dispute.

## THE FACTS

- U.S. District Judge Christopher Cooper had blocked the Kennedy Center board from placing Trump's name on the building without congressional authorization and separately limited a two-year shutdown after finding that the earlier board process did not properly balance the center's statutory duties. The Justice Department appealed the naming ruling; no appellate stay or merits reversal existed by cutoff.
- On September 15 the Trump-aligned board again voted to close most of the center immediately for a proposed $257 million renovation. Associated Press documented fencing and reduced normal public access on September 16, making the closure an implemented operational consequence rather than only an announced plan.
- Representative Joyce Beatty filed an emergency motion arguing that the renewed vote violated Cooper's prior order. Cooper directed the administration to respond by September 17 on whether the closure plan was permissible; that direction required an explanation but did not itself grant an injunction, contempt finding or final ruling on the renewed vote.
- Congress had allocated $257 million for repairs and the center has documented serious deterioration. Trump has said reconstruction will not begin unless the naming plan may proceed and claimed $17 million in private funds was deposited; audited funding, a final contract, full scope, employee plan and reopening date remained unavailable.
- The White House, Kennedy Center and Justice Department had not responded to Reuters by publication. The administration and board say closure is needed for safety and reconstruction; Beatty argues the board is evading the court's restraints. Those positions remain subject to the district and appellate proceedings.
- On September 17 Reuters reported that Beatty’s lawyers filed Trump’s September 16 remarks linking recognition of his administration to the center’s survival and possible demolition. Reuters explicitly did not verify a circulating photograph cited by counsel. Neither the photograph nor the remarks establish an approved demolition plan or a new judicial ruling.
- On September 17 Reuters and AP reported that Cooper required 30 days' notice before major physical changes, including demolition, while denying an emergency hearing. Center director Matt Floca cited structural safety risks for a temporary closure of at least seven days, separate from the longer renovation plan. The complete new order was not retrieved; this update relies on the two independent reports.

## SIGNIFICANCE

The new notice requirement adds an opportunity for scrutiny before irreversible physical changes. It does not resolve the larger statutory dispute.

## GOALPOST / RESPONSE

The administration attributes the temporary closure to safety; Beatty disputes that explanation. Inspect the complete order, safety assessments and any later notice or authorization before asserting broader permission.

## MAYBE / THEREFORE

Maybe documented hazards justify limited repairs, or continued closure exceeds lawful authority. Therefore a reported notice requirement is established—not permission to demolish, a reopening date or final judgment.


## SOURCES

- [Associated Press — judge blocks Kennedy Center Trump naming plan](https://apnews.com/article/6dc2fb38cc5c97d36f60e3aa474f19c4) — independent legal reporting on the district-court order and congressional naming authority
- [Associated Press — Kennedy Center board votes to close most of venue](https://apnews.com/article/1dfbfaac695f6817719477101b971a54) — independent reporting on the board vote, immediate closure, repair funding and naming dispute
- [Donald Trump — Kennedy Center closure and conditional reconstruction statement](https://truthsocial.com/@realDonaldTrump/117276573235915643) — primary evidence that Trump published the closure, appeal, funding and reconstruction claims; not independent proof of those claims
- [Reuters — judge orders response on Kennedy Center closure](https://www.reuters.com/legal/government/judge-kennedy-center-case-orders-trump-administration-explain-closure-plans-2026-09-16/) — independent court reporting based on the judge's direction and plaintiff filing
- [Associated Press — fencing and access limits after Kennedy Center closure vote](https://apnews.com/article/76857d537ec8cabd87be5065fb9428ac) — independent on-site reporting and litigation update
- [Reuters — Kennedy Center filing cites demolition comments and unverified photo](https://www.reuters.com/legal/government/court-filing-cites-trump-comments-photo-reading-kennedy-center-demolished-2026-09-17/) — independent reporting on public remarks and plaintiff filing; photograph explicitly unverified
- [Associated Press — Kennedy Center 30-day notice order](https://apnews.com/article/kennedy-center-fencing-trump-closed-repairs-128f25afb33841baff16245d492f320c) — independent court reporting; complete order not retrieved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
