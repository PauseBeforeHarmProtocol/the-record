# Kennedy Center board closes most of venue after court blocks Trump naming plan

**Entry ID:** NAT-2026-09-15-006
**Date:** September 15, 2026
**Checked:** 2026-09-15 6:02 PM EDT
**Evidence state:** two Associated Press reports plus Trump's primary publication; closure independently reported and court order described, while funding, reconstruction conditions and future appellate outcome remain qualified
**Review state:** current-standard-reviewed

The closure is implemented, but reconstruction remains conditional and the district court's naming order is on appeal.

## THE FACTS

- U.S. District Judge Christopher Cooper blocked the Kennedy Center board from placing President Trump's name on the building or grounds without congressional authorization. Associated Press reported that the court treated naming or memorialization of the federally established center as a decision reserved to Congress; the Justice Department appealed.
- Later September 15, the Trump-aligned Kennedy Center board voted to close most of the performing-arts venue immediately. Associated Press independently reported the vote and closure after Trump's Truth Social announcement; the closure is an implemented institutional action, not merely a proposed renovation.
- Congress had allocated $257 million for repairs, and the center has documented serious physical deterioration. Those facts support a substantial repair need but do not independently establish that every performance space had to close immediately, the final reconstruction scope or a completion date.
- Trump said reconstruction would not begin unless the D.C. Circuit, or ultimately the Supreme Court, allowed the board's approved naming plan. He also claimed that $17 million he raised had been deposited into the center's account. The post proves that he made those statements; the archive did not locate audited account records or a final construction instrument independently verifying the funding claim or conditional project terms.
- The closure and appeal are separate lifecycle stages from earlier injunction and naming-removal records. By cutoff, no appellate stay or merits ruling had reversed Judge Cooper's order, and no completed reconstruction, final budget or reopening date had been established.

## SIGNIFICANCE

A national cultural institution has now largely closed, and the president has expressly tied the timing of a congressionally funded reconstruction to an unresolved naming dispute. That creates immediate public-access and operational consequences while leaving the legal authority, project financing, duration and reopening plan unsettled.

## GOALPOST / RESPONSE

Trump and the board say closure is necessary for safety and reconstruction and that the naming decision should be reversed; the district court says Congress controls memorial naming. The tests are the appellate docket and any stay, a published closure and construction plan, contracts and audited funding, treatment of employees and scheduled performances, congressional action, safety findings, costs, milestones and a reopening date.

## MAYBE / THEREFORE

Maybe the closure will permit overdue repairs while the naming dispute is resolved, or conditioning reconstruction on a personal naming outcome may delay public use and increase costs. Therefore the record confirms the board vote, immediate closure, district-court restraint and appeal—not a final appellate result, audited $17 million deposit, approved reconstruction contract, completed renovation or permanent shutdown.


## SOURCES

- [Associated Press — judge blocks Kennedy Center Trump naming plan](https://apnews.com/article/6dc2fb38cc5c97d36f60e3aa474f19c4) — independent legal reporting on the district-court order and congressional naming authority
- [Associated Press — Kennedy Center board votes to close most of venue](https://apnews.com/article/1dfbfaac695f6817719477101b971a54) — independent reporting on the board vote, immediate closure, repair funding and naming dispute
- [Donald Trump — Kennedy Center closure and conditional reconstruction statement](https://truthsocial.com/@realDonaldTrump/117276573235915643) — primary evidence that Trump published the closure, appeal, funding and reconstruction claims; not independent proof of those claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
