# EPA unions sue to restore terminated collective-bargaining agreement

**Entry ID:** NAT-2026-09-29-010
**Date:** September 29, 2026
**Checked:** 2026-09-30 6:00 AM EDT
**Evidence state:** filed federal complaint plus Federal News Network and Guardian reporting with named union and agency responses; allegations pending and no judicial merits determination
**Review state:** current-standard-reviewed

A filed federal complaint alleges EPA unlawfully ended a 2024 labor contract and did so to suppress dissent; the claims have not been adjudicated.

## THE FACTS

- AFGE Local 3428 and AFGE Council 238 filed a September 29 complaint in the U.S. District Court for the District of Massachusetts against the Environmental Protection Agency and Administrator Lee Zeldin. The complaint is docketed as No. 1:26-cv-14436.
- The unions represent more than 8,000 EPA employees and ask the court to declare unlawful and set aside EPA's August 8, 2025 termination of a collective-bargaining agreement that was scheduled to run through June 2028.
- The complaint alleges EPA offered no reasoned explanation or consideration of reliance interests as required by the Administrative Procedure Act. It separately alleges First Amendment retaliation, citing the timing between a June 2025 employee dissent letter, the contract termination and later discipline of signers.
- The terminated agreement covered workplace procedures, grievances, disciplinary representation and a scientific-integrity article intended to protect good-faith reporting and independent scientific work. Those provisions and the alleged motive are described in the plaintiffs' filing; they are not adjudicated facts.
- EPA declined to comment on pending litigation. The administration's broader executive order invoked a statutory national-security exemption for covered agencies, while the unions argue that the order did not require EPA to terminate an existing agreement. No court ruling or restoration order had issued by cutoff.

## SIGNIFICANCE

The case tests whether EPA lawfully used the administration's government-wide collective-bargaining policy and whether ending the contract impaired scientific-integrity and employee-representation safeguards for a large federal workforce.

## GOALPOST / RESPONSE

The administration has defended the underlying exclusion policy as necessary for national-security work and managerial accountability; EPA has not answered the new complaint on the merits. The unions say the agency acted without reasoned decision-making and in retaliation for protected dissent. EPA's response, the administrative record, jurisdictional rulings, merits findings, remedies and any measurable effects on scientific work and discipline are the tests.

## MAYBE / THEREFORE

Maybe EPA can show a lawful, nonretaliatory basis for ending the agreement under the executive order, or discovery and judicial review may substantiate the unions' APA or First Amendment claims. Therefore the record establishes a filed, evidence-backed federal challenge affecting more than 8,000 represented workers—not a finding that EPA acted unlawfully or an order restoring the contract.


## SOURCES

- [AFGE Local 3428 and Council 238 v. Zeldin — complaint](https://afge238.org/wp-content/uploads/1-Complaint-2026-09-29.pdf) — filed federal complaint, No. 1:26-cv-14436; allegations not adjudicated
- [Federal News Network — EPA union challenges collective-bargaining termination](https://federalnewsnetwork.com/unions/2026/09/union-sues-epa-over-termination-of-collective-bargaining-agreement/) — specialist independent reporting linking the complaint and quoting named parties
- [The Guardian — EPA unions seek restoration of bargaining agreement](https://www.theguardian.com/environment/2026/sep/29/epa-union-sues-trump-administration) — independent reporting on the complaint and EPA response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
