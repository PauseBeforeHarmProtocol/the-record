# Judge vacates remaining block on USPS mail-ballot rule as states seek emergency relief

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–26, 2026
**Checked:** 2026-08-26 5:59 PM EDT
**Evidence state:** August 26 vacatur and emergency-relief requests independently reported by Reuters and AP after the noon boundary; remaining implementation block vacated, new merits challenges and restraining-order requests pending
**Review state:** current-standard-reviewed

The Postal Service may implement the rule after Judge Indira Talwani vacated the remaining injunction, while states and voting-rights groups seek a new restraining order before ballots are mailed.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, and at that time a separate nationwide injunction obtained by voting-rights groups remained in force.
- On August 25, U.S. District Judge Indira Talwani found that USPS violated that separate injunction when it completed and sent a final ballot-mail rule to the Federal Register. The rule would require voter lists and unique barcodes on outbound and return ballot envelopes.
- Talwani initially imposed no additional remedy because USPS acknowledged that the final rule had no force for the November 3 election while her injunction remained.
- On August 26, a coalition of 25 Democratic-led states filed a new federal lawsuit in Massachusetts challenging the final USPS rule. Later that day, Talwani vacated the remaining injunction at the administration's request, saying the Supreme Court's procedural ruling compelled that result despite the potential chaos while litigation is pending. USPS may now implement the rule unless new relief is entered.
- The states and voting-rights groups immediately requested a temporary restraining order. Talwani ordered the administration to respond by August 27 and scheduled a September 3 preliminary-injunction hearing. Their claims that the rule exceeds federal authority and risks disenfranchisement remain allegations; the merits are unresolved.

## SIGNIFICANCE

Vacatur changes the rule from issued-but-blocked to immediately implementable days before the first mailed ballots, while the new cases race toward emergency review. The dispute now combines executive authority over election administration, concrete state compliance costs, and a compressed risk of voter disruption.

## GOALPOST / RESPONSE

The administration calls the rule a commonsense election-security measure and says it will continue implementation. The states and voting-rights groups say USPS lacks authority to determine ballot eligibility and that last-minute envelope, barcode, and voter-list requirements risk disenfranchisement. The requested restraining orders, September 3 hearing, implementation instructions, ballot rejection data, and any appellate action are the evidence tests.

## MAYBE / THEREFORE

Maybe expedited merits review will re-block or narrow the rule before ballots are mailed, or the government may implement it without the disruption opponents predict. Therefore the record now says the prior injunction was vacated and implementation is legally permitted, not that the rule's legality has been decided or that every state has already changed its procedures.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
