# USPS stops work on blocked mail-ballot system before midterms

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–September 17, 2026
**Checked:** 2026-09-18 12:00 AM EDT
**Evidence state:** primary appellate and Supreme Court records plus independent Associated Press and Reuters reporting; preliminary restraints followed by an implemented USPS halt for the 2026 election, final merits unresolved
**Review state:** current-standard-reviewed

The postmaster general says the enjoined requirements will not be used for the 2026 federal election; final merits remain unresolved.

## THE FACTS

- On September 10, the First Circuit denied motions to stay the September 4 preliminary injunction against parts of the USPS ballot-mail rule, including a request for an administrative stay. The order covers consolidated appeals Nos. 26-2029 through 26-2032.
- The order describes the challenged requirements as voter-specific barcodes matched to a USPS database, new envelope approval and replacement, and uploads to a portal that was not yet operational. The preliminary injunction runs in favor of the plaintiff states and organizations.
- The panel concluded that appellants had not made the required strong showing of likely success: it agreed that the rule likely regulated elections without the congressional authorization the Elections Clause requires. It confined that analysis to the constitutional claim rather than deciding the additional statutory claims.
- The court also relied on the unrefuted implementation difficulties and projected risk of widespread disenfranchisement if requirements took effect for November 3. These are judicial assessments of prospective harm, not measured rejected ballots or a finding that millions already lost their votes.
- The order denies emergency stay relief; it neither finally decides the merits nor automatically forecloses further appellate review. The earlier event chronology and all its source references are preserved in the timestamped 10.44.0 before-and-after note rather than retrospectively certified as newly inspected facts.
- Late September 13, U.S. District Judge Carl J. Nichols issued a separate preliminary injunction against implementation of the USPS rule in the consolidated D.C. case DSCC v. Trump. Associated Press quoted Nichols as finding an increased risk that a significant number of otherwise appropriate absentee or mail ballots would not be counted without relief; Reuters independently reported that he found no statute authorizing critical parts of the rule. This is a second, overlapping preliminary restraint—not a final merits judgment—and the complete D.C. order was not publicly retrievable during this review.
- On September 14, the Supreme Court denied the government’s application to stay the Massachusetts preliminary injunction. The docket order said the government was unlikely to succeed on the merits of its challenge and that the emergency equities did not favor a stay. Justice Kavanaugh concurred; Justices Alito and Thomas dissented. The denial leaves preliminary relief in place for now and does not resolve the consolidated cases’ final merits.
- On September 17, Associated Press reported that USPS stopped work on the planned citizenship-list and ballot-mail portal system. Postmaster General David Steiner said the new requirements would not be enforced for the 2026 federal election, and an all-employee memo said operations would remain ‘business as usual.’ AP's report and named interview establish the operational halt; they do not resolve the underlying cases or bar a later lawful rule.

## SIGNIFICANCE

The courts' interim restraints now have an operational consequence: USPS says the disputed system and requirements will not be used for the 2026 federal election. That reduces the immediate implementation risk while leaving final authority and any future rule unresolved.

## GOALPOST / RESPONSE

The administration had described the rule as a modest integrity measure under USPS authority. USPS now says it has stopped the system work and will maintain ordinary 2026 election operations; optional barcode incentives may still be considered later. Final merits rulings, any replacement process and documented delivery and counting outcomes remain the tests.

## MAYBE / THEREFORE

Maybe the operational halt preserves stable election procedures while litigation proceeds, or a later narrower system may satisfy legal and practical requirements. Therefore the 2026 requirements are not being implemented—not permanently invalidated for every future election, and no measured ballot outcome is inferred.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects
- [Reuters — USPS says federal mail-ballot requirements are in effect](https://www.reuters.com/world/us/mail-in-voting-restrictions-now-effect-us-postal-service-says-2026-08-27/) — independent reporting on agency-confirmed implementation and pending emergency litigation
- [The Guardian — USPS implements mail-ballot requirements](https://www.theguardian.com/us-news/2026/aug/27/us-postal-service-mail-ballot-rules-trump-order) — independent reporting corroborating immediate implementation and litigation status
- [League of Women Voters of Massachusetts v. Trump — temporary restraining order staying core USPS ballot-mail requirements](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/rDP_zBX5vmWQ/v0) — primary federal court temporary restraining order
- [Reuters — judge temporarily blocks core USPS mail-ballot rule provisions](https://www.reuters.com/world/judge-blocks-rule-implementing-trump-plan-restrict-mail-in-voting-2026-08-28/) — independent reporting on the 14-day order, affected provisions, and pending hearing
- [U.S. District Court docket — League of Women Voters of Massachusetts v. Trump](https://www.courtlistener.com/docket/73133197/league-of-women-voters-of-massachusetts-v-trump/) — primary federal docket containing the temporary restraining order and notice of appeal
- [Associated Press — administration appeals temporary block on mail-ballot rule](https://apnews.com/article/8ef4a669a50f3406481ffb8387ccad3c) — independent reporting on the notice of appeal, continuing stay, and election timetable
- [Justice Department — emergency First Circuit motion to stay USPS ballot-mail restraining order](https://fingfx.thomsonreuters.com/gfx/legaldocs/dwpknxnoevm/08312026doj_stay.pdf) — primary appellate filing stating the requested administrative and pending-appeal stays, the government's legal position and the continuing effect of the district-court order
- [Reuters — administration seeks emergency First Circuit stay of mail-ballot order](https://www.reuters.com/legal/government/trump-administration-asks-us-appeals-court-lift-order-blocking-mail-in-voting-2026-09-01/) — independent legal reporting on the district-court stay denial, appellate motion, approaching ballot-mail dates and unresolved status
- [Senate Permanent Subcommittee on Investigations — USPS whistleblower disclosure and oversight letter](https://www.blumenthal.senate.gov/imo/media/doc/2026-08-31_final_letter-disclosure.pdf) — primary publication of an attributed congressional oversight letter and anonymous whistleblower disclosure alleging rushed portal development and a zero-percent batch-verification rule
- [Associated Press — USPS portal whistleblower alleges rushed and error-prone implementation](https://apnews.com/article/midterm-elections-postal-service-mail-voting-7f7cf4fdf2e9cf369ae96f96fbda03f2) — independent reporting on the whistleblower disclosure, still-inactive portal, litigation status and administration response
- [Reuters — USPS whistleblower warns ballot rules could reject legal mail](https://www.reuters.com/legal/government/us-homeland-security-ramp-up-voter-fraud-investigations-this-week-cnn-reports-2026-09-01/) — independent reporting on the congressional disclosure, alleged zero-percent batch rule and unresolved litigation
- [Justice Department — Supreme Court application to stay USPS mail-ballot temporary restraining order](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/rXqXoSpVYNl0/v0) — primary emergency application presenting the government's legal argument and requested relief
- [Reuters — administration takes USPS mail-ballot stay request to Supreme Court](https://www.reuters.com/world/trump-administration-takes-mail-in-ballot-fight-us-supreme-court-2026-09-03/) — independent reporting on the emergency application, operative temporary order and procedural posture
- [Associated Press — government seeks Supreme Court relief over mail-ballot requirements](https://apnews.com/article/trump-mail-voting-executive-order-lawsuit-63899f738d28d161b629054a314f161a) — independent reporting on the application, portal status, state implementation and lower-court hearing
- [Associated Press — district judge enters preliminary injunction against USPS mail-ballot requirements](https://apnews.com/article/ce207ff2d0533de05cc2d299e91a0198) — independent reporting on the longer preliminary relief and continuing appellate posture
- [Associated Press — administration renews Supreme Court request over mail-ballot rule](https://apnews.com/article/trump-mail-voting-executive-order-lawsuit-65067233db6ebda8dedcdc3f6714a96c) — independent reporting on the renewed emergency filing after entry of the preliminary injunction and the unchanged operative status
- [First Circuit — League of Women Voters litigation, Nos. 26-2029 through 26-2032](https://www.ca1.uscourts.gov/sites/ca1/files/opnfiles/26-2029O-01A.pdf) — primary order denying stays of preliminary injunction
- [Associated Press — second federal judge preliminarily blocks USPS mail-ballot rule](https://apnews.com/article/906aa1247f096609e61a1bd2369a57e9) — independent reporting quoting Judge Carl Nichols's preliminary-injunction finding and describing the separate D.C. restraint, implementation timing and Supreme Court posture
- [Reuters — second judge blocks Trump mail-voting restrictions](https://www.reuters.com/world/trumps-mail-in-voting-restrictions-blocked-by-second-judge-2026-09-14/) — independent confirmation of the D.C. preliminary injunction, reported statutory-authority holding and continuing Supreme Court review; complete order unavailable during review
- [Supreme Court docket 26A305 — USPS stay application denied](https://www.supremecourt.gov/search.aspx?filename=/docket/docketfiles/html/public/26a305.html) — primary docket order denying emergency stay and recording concurrence and dissent
- [Reuters — Supreme Court leaves USPS mail-ballot injunction in place](https://www.reuters.com/world/loss-trump-us-supreme-court-wont-let-postal-service-restrict-mail-ballots-2026-09-14/) — independent reporting of the stay denial, opinions and continuing preliminary posture
- [Associated Press — Supreme Court rejects emergency bid on mail-ballot restrictions](https://apnews.com/article/trump-mail-voting-executive-order-lawsuit-78a4fbeb48d9c5fd27d1c865529fc65f) — independent confirmation of the stay denial, state procedures and nonfinal merits posture
- [Associated Press — USPS stops work on blocked ballot-mail system](https://apnews.com/article/trump-mail-ballot-us-postal-service-995f98147fbb49fb71696be824abff95) — independent reporting based on a USPS employee memo and named postmaster-general interview

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
