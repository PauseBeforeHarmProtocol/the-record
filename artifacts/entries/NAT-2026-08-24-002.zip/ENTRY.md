# Twenty-five states challenge USPS mail-ballot rule that remains blocked for 2026

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–26, 2026
**Checked:** 2026-08-26 12:02 PM EDT
**Evidence state:** Supreme Court emergency action, August 25 district-court order, and August 26 state complaint and attorney-general announcement independently reported by Reuters and AP; allegations newly filed, merits unresolved, 2026 implementation enjoined
**Review state:** current-standard-reviewed

The new state lawsuit directly challenges the completed rule after a court found USPS violated a separate injunction; implementation remains blocked for the 2026 election.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, and a separate nationwide injunction obtained by voting-rights groups remained in force.
- On August 25, U.S. District Judge Indira Talwani found that USPS violated that separate injunction when it completed and sent a final ballot-mail rule to the Federal Register. The rule would require voter lists and unique barcodes on outbound and return ballot envelopes.
- Talwani imposed no additional remedy because USPS acknowledged that the final rule has no force for the November 3 election while her injunction remains. The final rule was issued, but its 2026-election implementation remained enjoined at the checked time.
- On August 26, a coalition of 25 Democratic-led states filed a new federal lawsuit in Massachusetts challenging the final USPS rule and requested emergency relief. The states allege that the rule exceeds federal authority, conflicts with election statutes, and would impose unlawful costs and administrative burdens; those are filed allegations, not adjudicated findings.

## SIGNIFICANCE

The August 26 case supplies the direct rule challenge that the August 25 court said publication could enable, while the remaining injunction continues to prevent use of the rule in the 2026 election. The dispute now involves both executive authority over election administration and the concrete costs states say they would bear.

## GOALPOST / RESPONSE

The administration describes the directive as an election-integrity measure and has argued that the final rule preserves the status quo while injunctions remain. The states say the rule unlawfully shifts federal election policy and costs onto them. The complaint, any temporary restraining order, appellate stays, voter-list accuracy, and the election calendar are the evidence tests.

## MAYBE / THEREFORE

Maybe the new suit will accelerate merits review while the rule remains dormant, and the government may narrow or successfully defend parts of it. Therefore the record distinguishes the Supreme Court's stay of one injunction, USPS's issuance of a final rule, the separate injunction violation, the states' newly filed allegations, and the still-enjoined 2026 implementation.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
