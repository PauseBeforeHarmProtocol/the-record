# USPS puts mail-ballot rule into effect while emergency challenges proceed

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–27, 2026
**Checked:** 2026-08-27 11:59 AM EDT
**Evidence state:** USPS implementation statement independently reported by Reuters and The Guardian after the prior boundary; requirements in effect, emergency challenges and merits unresolved
**Review state:** current-standard-reviewed

The Postal Service says the new voter-list, barcode, and envelope requirements are in effect for the November election after the remaining injunction was vacated; emergency challenges remain pending.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, and at that time a separate nationwide injunction obtained by voting-rights groups remained in force.
- On August 25, U.S. District Judge Indira Talwani found that USPS violated that separate injunction when it completed and sent a final ballot-mail rule to the Federal Register. The rule would require voter lists and unique barcodes on outbound and return ballot envelopes.
- Talwani initially imposed no additional remedy because USPS acknowledged that the final rule had no force for the November 3 election while her injunction remained.
- On August 26, a coalition of 25 Democratic-led states filed a new federal lawsuit in Massachusetts challenging the final USPS rule. Later that day, Talwani vacated the remaining injunction at the administration's request, saying the Supreme Court's procedural ruling compelled that result despite the potential chaos while litigation is pending. USPS may now implement the rule unless new relief is entered.
- The states and voting-rights groups immediately requested a temporary restraining order. Talwani ordered the administration to respond by August 27 and scheduled a September 3 preliminary-injunction hearing. Their claims that the rule exceeds federal authority and risks disenfranchisement remain allegations; the merits are unresolved.
- On August 27, USPS said the new requirements were in effect and would apply to the November 3 election. That agency confirmation changes the evidence status from legally permitted implementation to implemented policy, but it does not resolve the pending emergency motions or the rule's legality.

## SIGNIFICANCE

USPS's confirmation moves the rule from issued and legally implementable to operational federal policy days before the first mailed ballots, while emergency litigation proceeds. The dispute combines executive authority over election administration, concrete state compliance costs, and a compressed risk of voter disruption.

## GOALPOST / RESPONSE

The administration calls the rule a commonsense election-security measure and says implementation will help ensure only eligible voters' ballots are delivered. The states and voting-rights groups say USPS lacks authority to determine ballot eligibility and that last-minute envelope, barcode, and voter-list requirements risk disenfranchisement. Court orders, implementation instructions, ballot acceptance and rejection data, and any state compliance failures are the evidence tests.

## MAYBE / THEREFORE

Maybe expedited review will re-block or narrow the rule before ballots are mailed, or implementation may proceed without the disruption opponents predict. Therefore the record says USPS put the requirements into effect, not that their legality has been decided, that every state has completed compliance, or that any ballots have yet been rejected under them.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects
- [Reuters — USPS says federal mail-ballot requirements are in effect](https://www.reuters.com/world/us/mail-in-voting-restrictions-now-effect-us-postal-service-says-2026-08-27/) — independent reporting on agency-confirmed implementation and pending emergency litigation
- [The Guardian — USPS implements mail-ballot requirements](https://www.theguardian.com/us-news/2026/aug/27/us-postal-service-mail-ballot-rules-trump-order) — independent reporting corroborating immediate implementation and litigation status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
