# Mail-voting directive remains blocked after court finds USPS violated its injunction

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–25, 2026
**Checked:** 2026-08-25 6:00 PM EDT
**Evidence state:** Supreme Court emergency action and August 25 district-court order; one injunction stayed, a separate injunction violated but still operative, merits unresolved and 2026 implementation enjoined
**Review state:** current-standard-reviewed

The Supreme Court lifted one injunction, but a second court found USPS violated its order by completing a final rule and the rule still cannot be implemented for the 2026 election.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, and a separate nationwide injunction obtained by voting-rights groups remained in force.
- On August 25, U.S. District Judge Indira Talwani found that USPS violated that separate injunction when it completed and sent a final ballot-mail rule to the Federal Register. The rule would require voter lists and unique barcodes on outbound and return ballot envelopes.
- Talwani imposed no additional remedy because USPS acknowledged that the final rule has no force for the November 3 election while her injunction remains. The final rule was issued, but its 2026-election implementation remained enjoined at the checked time.

## SIGNIFICANCE

The August 25 ruling clarifies that the Supreme Court's emergency action did not clear the policy for the 2026 election. It also creates a documented violation of a federal injunction while leaving the final rule available for a direct legal challenge. Practical effects remain contingent on further stays, appeals, rule litigation, voter-list accuracy, and the election calendar.

## GOALPOST / RESPONSE

The administration says the states sued prematurely and that the final rule itself preserves the status quo while injunctions remain; it describes the directive as an election-integrity measure. Voting-rights groups argue that the executive branch lacks authority to regulate elections and that publication creates confusion. Talwani accepted that implementation remains blocked but rejected the claim that completing the rule complied with her order.

## MAYBE / THEREFORE

Maybe the completed final rule will permit faster merits review and may never affect the 2026 election if the remaining injunction survives. Therefore the record distinguishes the Supreme Court's stay of one injunction, USPS's issuance of a final rule, the district court's violation finding, and the rule's still-enjoined implementation.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
