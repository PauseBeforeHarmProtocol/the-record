# Supreme Court lifts one injunction blocking Trump's mail-voting directive

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24, 2026
**Checked:** 2026-08-24 5:58 PM EDT
**Evidence state:** Supreme Court emergency action corroborated by AP and Reuters; one injunction stayed, merits unresolved and another restraint remains
**Review state:** current-standard-reviewed

The emergency action permits implementation work to continue, but it did not decide the directive's legality and another judicial obstacle remains.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, additional challenges remain possible, and Reuters reported that another judicial restraint still remained at the checked time.

## SIGNIFICANCE

The emergency ruling removes one immediate barrier to a federal effort that could alter mail-ballot administration shortly before the midterms. Its practical reach is still uncertain because implementation, state election authority, voter-list accuracy, remaining litigation, and the election calendar are unresolved.

## GOALPOST / RESPONSE

The Justice Department says the states sued prematurely, lacked standing, and had not shown concrete injury; the administration describes the directive as an election-integrity measure. The states argue that it exceeds presidential authority, imposes administration costs, and risks disenfranchisement. The emergency ruling did not resolve those competing claims.

## MAYBE / THEREFORE

Maybe, as the Justice Department argues, the states sued before implementation produced a concrete injury, and verified voter lists could reduce invalid ballot delivery. Therefore the emergency order establishes neither the directive’s legality nor the reliability of conditioning Postal Service delivery on approved lists; implementation errors, exclusions of eligible voters, state burdens, remaining injunctions, and merits rulings are the tests.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
