# Federal judge temporarily blocks core USPS mail-ballot requirements

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–31, 2026
**Checked:** 2026-09-01 12:03 AM EDT
**Evidence state:** primary August 27 temporary restraining order and August 31 Justice Department emergency stay motion, federal docket, and independent Reuters and Associated Press reporting; core mandatory provisions remain stayed and appellate relief is pending
**Review state:** current-standard-reviewed

A 14-day restraining order stays mandatory ballot-envelope standards and portal registration while the judge considers longer preliminary relief on September 3.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, and at that time a separate nationwide injunction obtained by voting-rights groups remained in force.
- On August 25, U.S. District Judge Indira Talwani found that USPS violated that separate injunction when it completed and sent a final ballot-mail rule to the Federal Register. The rule would require voter lists and unique barcodes on outbound and return ballot envelopes.
- Talwani initially imposed no additional remedy because USPS acknowledged that the final rule had no force for the November 3 election while her injunction remained.
- On August 26, a coalition of 25 Democratic-led states filed a new federal lawsuit in Massachusetts challenging the final USPS rule. Later that day, Talwani vacated the remaining injunction at the administration's request, saying the Supreme Court's procedural ruling compelled that result despite the potential chaos while litigation is pending. USPS may now implement the rule unless new relief is entered.
- The states and voting-rights groups immediately requested a temporary restraining order. Talwani ordered the administration to respond by August 27 and scheduled a September 3 preliminary-injunction hearing. Their claims that the rule exceeds federal authority and risks disenfranchisement remain allegations; the merits are unresolved.
- On August 27, USPS said the new requirements were in effect and would apply to the November 3 election. That agency confirmation changed the evidence status from legally permitted implementation to implemented policy, but did not resolve the pending emergency motions or the rule's legality.
- Later on August 27, Talwani granted the challengers' motions in part and temporarily stayed the rule's mandatory outbound- and return-envelope standards and mandatory Postal Service ballot-portal registration. The 14-day order requires USPS to notify affected election officials; motions for preliminary injunctions remain under advisement for a September 3 hearing.
- On August 28, the administration filed a notice of appeal to the First Circuit from the temporary restraining order. The appeal did not itself stay Talwani's order, restore the mandatory requirements, or decide the rule's legality; the September 3 preliminary-injunction hearing remained scheduled.
- On August 31, Talwani denied the administration's district-court stay request. The Justice Department then filed an emergency First Circuit motion seeking a stay pending appeal and a temporary administrative stay, arguing that the rule regulates mail rather than voter eligibility and that North Carolina and Alabama were scheduled to begin mailing ballots while the 14-day order remained in force. The appellate court had not ruled by cutoff, so the specified mandatory provisions remained stayed.

## SIGNIFICANCE

The emergency stay motion puts the rule's operational status before the First Circuit days before North Carolina is scheduled to mail ballots. Talwani's order still preserves state systems temporarily while the courts assess whether a postal rule unlawfully intrudes on election administration, but neither the restraining order, the appeal nor the stay motion is a final merits judgment.

## GOALPOST / RESPONSE

The administration and intervenors call the rule a modest mail-design and data-reporting measure within USPS's authority and say it leaves voter eligibility to states. Talwani found the challengers likely to succeed, while the states and voting-rights groups warned of disenfranchisement and administrative disruption. A First Circuit administrative-stay or merits ruling, the September 3 hearing, implementation notices, and ballot-delivery data are the tests.

## MAYBE / THEREFORE

Maybe the temporary stay will become a longer injunction and keep the core requirements off the books through the midterms, or the First Circuit may allow some provisions to take effect before the first ballots are mailed. Therefore the record says an emergency appellate stay request is pending and specified mandatory provisions remain temporarily stayed—not that the motion restored them, the full rule has been permanently invalidated, or the litigation is over.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects
- [Reuters — USPS says federal mail-ballot requirements are in effect](https://www.reuters.com/world/us/mail-in-voting-restrictions-now-effect-us-postal-service-says-2026-08-27/) — independent reporting on agency-confirmed implementation and pending emergency litigation
- [The Guardian — USPS implements mail-ballot requirements](https://www.theguardian.com/us-news/2026/aug/27/us-postal-service-mail-ballot-rules-trump-order) — independent reporting corroborating immediate implementation and litigation status
- [League of Women Voters of Massachusetts v. Trump — temporary restraining order staying core USPS ballot-mail requirements](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/rDP_zBX5vmWQ/v0) — primary federal court temporary restraining order
- [Reuters — judge temporarily blocks core USPS mail-ballot rule provisions](https://www.reuters.com/world/judge-blocks-rule-implementing-trump-plan-restrict-mail-in-voting-2026-08-28/) — independent reporting on the 14-day order, affected provisions, and pending hearing
- [U.S. District Court docket — League of Women Voters of Massachusetts v. Trump](https://www.courtlistener.com/docket/73133197/league-of-women-voters-of-massachusetts-v-trump/) — primary federal docket containing the temporary restraining order and notice of appeal
- [Associated Press — administration appeals temporary block on mail-ballot rule](https://apnews.com/article/8ef4a669a50f3406481ffb8387ccad3c) — independent reporting on the notice of appeal, continuing stay, and election timetable
- [Justice Department — emergency First Circuit motion to stay USPS ballot-mail restraining order](https://fingfx.thomsonreuters.com/gfx/legaldocs/dwpknxnoevm/08312026doj_stay.pdf) — primary appellate filing stating the requested administrative and pending-appeal stays, the government's legal position and the continuing effect of the district-court order
- [Reuters — administration seeks emergency First Circuit stay of mail-ballot order](https://www.reuters.com/legal/government/trump-administration-asks-us-appeals-court-lift-order-blocking-mail-in-voting-2026-09-01/) — independent legal reporting on the district-court stay denial, appellate motion, approaching ballot-mail dates and unresolved status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
