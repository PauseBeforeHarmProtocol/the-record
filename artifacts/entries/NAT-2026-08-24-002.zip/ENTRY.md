# Federal judge temporarily blocks core USPS mail-ballot requirements

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–September 1, 2026
**Checked:** 2026-09-01 12:03 PM EDT
**Evidence state:** primary court orders and stay motion, final rule, formally published anonymous whistleblower disclosure, congressional oversight letter and independent Associated Press and Reuters reporting; specified provisions stayed, portal inactive, allegations unadjudicated
**Review state:** current-standard-reviewed

A 14-day restraining order stays core requirements while a documented whistleblower disclosure alleges that the still-inactive ballot portal was rushed, undertested and designed with a zero-percent batch-failure rule.

## THE FACTS

- The Supreme Court granted the Justice Department's emergency request to pause a Massachusetts federal judge's injunction that had blocked the administration from implementing the March mail-voting executive order in 23 states and the District of Columbia.
- The order directs federal agencies to compile state voter-eligibility lists and tells the Postal Service to deliver mail ballots only to voters on approved state lists. The Postal Service had begun implementation planning before the Supreme Court acted.
- The justices did not decide the merits. The three liberal justices dissented, and at that time a separate nationwide injunction obtained by voting-rights groups remained in force.
- On August 25, U.S. District Judge Indira Talwani found that USPS violated that separate injunction when it completed and sent a final ballot-mail rule to the Federal Register. The rule would require voter lists and unique barcodes on outbound and return ballot envelopes.
- Talwani initially imposed no additional remedy because USPS acknowledged that the final rule had no force for the November 3 election while her injunction remained.
- On August 26, a coalition of 25 Democratic-led states filed a new federal lawsuit in Massachusetts challenging the final USPS rule. Later that day, Talwani vacated the remaining injunction at the administration's request, saying the Supreme Court's procedural ruling compelled that result despite the potential chaos while litigation is pending. USPS may now implement the rule unless new relief is entered.
- The states and voting-rights groups immediately requested a temporary restraining order. Talwani ordered the administration to respond by August 27 and scheduled a September 3 preliminary-injunction hearing. Their claims that the rule exceeds federal authority and risks disenfranchisement remain allegations; the merits are unresolved.
- On August 27, USPS said the new requirements were in effect and would apply to the November 3 election. That agency confirmation changed the evidence status from legally permitted implementation to implemented policy, but did not resolve the pending emergency motions or the rule's legality.
- Later on August 27, Talwani granted the challengers' motions in part and temporarily stayed the rule's mandatory outbound- and return-envelope standards and mandatory Postal Service ballot-portal registration. The 14-day order requires USPS to notify affected election officials; motions for preliminary injunctions remain under advisement for a September 3 hearing.
- On August 28, the administration filed a notice of appeal to the First Circuit from the temporary restraining order. The appeal did not itself stay Talwani's order, restore the mandatory requirements, or decide the rule's legality; the September 3 preliminary-injunction hearing remained scheduled.
- On August 31, Talwani denied the administration's district-court stay request. The Justice Department then filed an emergency First Circuit motion seeking a stay pending appeal and a temporary administrative stay, arguing that the rule regulates mail rather than voter eligibility and that North Carolina and Alabama were scheduled to begin mailing ballots while the 14-day order remained in force.
- A September 1 public disclosure from an anonymous federal official represented by Whistleblower Aid alleged that USPS tried to build the Federal Ballot Mail Portal in roughly three months rather than the year or more normally required, used unclear and changing requirements, and omitted sufficient component, internal, customer-acceptance and final integrated testing. The source's identity and underlying internal records were not public, so these are documented allegations rather than independently established system defects.
- The disclosure also alleged a zero-percent physical-scan failure rule: if a sampled barcode does not match portal data, USPS would reject the entire batch until the election office resolves the discrepancy and resubmits it. The example given was one failure holding up the other 9,999 ballots in a 10,000-ballot batch; no evidence showed that any such batch had actually been rejected because the portal remained inactive.
- Senator Richard Blumenthal requested explanations by September 4 and internal records by September 8 and referred the concerns to the USPS inspector general. USPS did not comment to the Associated Press; the White House has called the mail-voting provisions common-sense anti-fraud measures. At cutoff, the First Circuit had not granted a stay and the specified mandatory provisions remained temporarily blocked.

## SIGNIFICANCE

The disclosure adds a specific implementation-risk claim to litigation already unfolding days before states begin mailing ballots: an undertested portal and all-or-nothing batch verification could delay large volumes if activated. The allegation is serious and formally placed before Congress and the inspector general, but it is not yet an audit finding, court finding or observed election failure.

## GOALPOST / RESPONSE

The administration and intervenors call the rule a modest mail-design and data-reporting measure within USPS's authority and say it leaves eligibility to states; the White House calls its provisions common-sense fraud safeguards. Challengers and the whistleblower warn of disenfranchisement, unlawful implementation and technical failure. First Circuit and district-court rulings, USPS records and testing, inspector-general findings, portal activation, batch-rejection data, ballot-delivery times and documented voter effects are the tests.

## MAYBE / THEREFORE

Maybe the whistleblower has identified genuine launch-critical defects that would disrupt ballot delivery, or later records and testing may show the described controls are narrower, remediable or inaccurately characterized. Therefore the record confirms a detailed anonymous disclosure, congressional oversight request and continuing temporary stay—not proven deliberate disenfranchisement, actual discarded ballots, a completed audit or a final ruling on the system's legality.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects
- [Reuters — USPS says federal mail-ballot requirements are in effect](https://www.reuters.com/world/us/mail-in-voting-restrictions-now-effect-us-postal-service-says-2026-08-27/) — independent reporting on agency-confirmed implementation and pending emergency litigation
- [The Guardian — USPS implements mail-ballot requirements](https://www.theguardian.com/us-news/2026/aug/27/us-postal-service-mail-ballot-rules-trump-order) — independent reporting corroborating immediate implementation and litigation status
- [League of Women Voters of Massachusetts v. Trump — temporary restraining order staying core USPS ballot-mail requirements](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/rDP_zBX5vmWQ/v0) — primary federal court temporary restraining order
- [Reuters — judge temporarily blocks core USPS mail-ballot rule provisions](https://www.reuters.com/world/judge-blocks-rule-implementing-trump-plan-restrict-mail-in-voting-2026-08-28/) — independent reporting on the 14-day order, affected provisions, and pending hearing
- [U.S. District Court docket — League of Women Voters of Massachusetts v. Trump](https://www.courtlistener.com/docket/73133197/league-of-women-voters-of-massachusetts-v-trump/) — primary federal docket containing the temporary restraining order and notice of appeal
- [Associated Press — administration appeals temporary block on mail-ballot rule](https://apnews.com/article/8ef4a669a50f3406481ffb8387ccad3c) — independent reporting on the notice of appeal, continuing stay, and election timetable
- [Justice Department — emergency First Circuit motion to stay USPS ballot-mail restraining order](https://fingfx.thomsonreuters.com/gfx/legaldocs/dwpknxnoevm/08312026doj_stay.pdf) — primary appellate filing stating the requested administrative and pending-appeal stays, the government's legal position and the continuing effect of the district-court order
- [Reuters — administration seeks emergency First Circuit stay of mail-ballot order](https://www.reuters.com/legal/government/trump-administration-asks-us-appeals-court-lift-order-blocking-mail-in-voting-2026-09-01/) — independent legal reporting on the district-court stay denial, appellate motion, approaching ballot-mail dates and unresolved status
- [Senate Permanent Subcommittee on Investigations — USPS whistleblower disclosure and oversight letter](https://www.blumenthal.senate.gov/imo/media/doc/2026-08-31_final_letter-disclosure.pdf) — primary publication of an attributed congressional oversight letter and anonymous whistleblower disclosure alleging rushed portal development and a zero-percent batch-verification rule
- [Associated Press — USPS portal whistleblower alleges rushed and error-prone implementation](https://apnews.com/article/midterm-elections-postal-service-mail-voting-7f7cf4fdf2e9cf369ae96f96fbda03f2) — independent reporting on the whistleblower disclosure, still-inactive portal, litigation status and administration response
- [Reuters — USPS whistleblower warns ballot rules could reject legal mail](https://www.reuters.com/legal/government/us-homeland-security-ramp-up-voter-fraud-investigations-this-week-cnn-reports-2026-09-01/) — independent reporting on the congressional disclosure, alleged zero-percent batch rule and unresolved litigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
