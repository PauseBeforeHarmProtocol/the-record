# First Circuit denies stays of the preliminary block on USPS mail-ballot requirements

**Entry ID:** NAT-2026-08-24-002
**Date:** August 24–September 10, 2026
**Checked:** 2026-09-10 5:57 PM EDT
**Evidence state:** primary nine-page First Circuit order inspected; stay motions denied, preliminary relief preserved, final merits unresolved
**Review state:** current-standard-reviewed

The September 10 appellate order leaves the challenged preliminary injunction in place; it is not a final merits judgment.

## THE FACTS

- On September 10, the First Circuit denied motions to stay the September 4 preliminary injunction against parts of the USPS ballot-mail rule, including a request for an administrative stay. The order covers consolidated appeals Nos. 26-2029 through 26-2032.
- The order describes the challenged requirements as voter-specific barcodes matched to a USPS database, new envelope approval and replacement, and uploads to a portal that was not yet operational. The preliminary injunction runs in favor of the plaintiff states and organizations.
- The panel concluded that appellants had not made the required strong showing of likely success: it agreed that the rule likely regulated elections without the congressional authorization the Elections Clause requires. It confined that analysis to the constitutional claim rather than deciding the additional statutory claims.
- The court also relied on the unrefuted implementation difficulties and projected risk of widespread disenfranchisement if requirements took effect for November 3. These are judicial assessments of prospective harm, not measured rejected ballots or a finding that millions already lost their votes.
- The order denies emergency stay relief; it neither finally decides the merits nor automatically forecloses further appellate review. The earlier event chronology and all its source references are preserved in the timestamped 10.44.0 before-and-after note rather than retrospectively certified as newly inspected facts.

## SIGNIFICANCE

The refusal to lift the injunction preserves the current restraint while ballots are being prepared and mailed. The court’s assessment weighs near-term implementation risk against claimed anti-fraud benefits, but does not determine the final legal outcome or measure actual voter harm.

## GOALPOST / RESPONSE

The administration and supporting states characterize the rule as a modest regulation of mail under USPS’s general statutory powers and invoke election integrity. The panel found that characterization unpersuasive at the stay stage and found no countervailing record evidence rebutting the implementation risks. Further orders, final merits review, usable systems and documented delivery outcomes are the tests.

## MAYBE / THEREFORE

Maybe the injunction preserves stable voting procedures while courts resolve authority, or further appellate review may accept the government’s postal-regulation rationale. Therefore September 10 establishes denial of stay relief and continuation of the challenged preliminary restraint—not a final merits victory, a categorical ban on ballot regulation or measured disenfranchisement.


## SOURCES

- [Associated Press — Supreme Court clears path for mail-voting order](https://apnews.com/article/trump-mail-voting-supreme-court-157afc3c195ce0a62c522da5ce904b04) — independent reporting on an emergency Supreme Court action
- [Reuters — Supreme Court lifts one injunction against mail-ballot directive](https://www.reuters.com/world/us-supreme-court-lifts-judicial-hurdle-trumps-mail-in-ballot-curbs-2026-08-24/) — independent reporting on an emergency Supreme Court action
- [U.S. District Court for the District of Massachusetts — order finding USPS violated mail-voting injunction](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzeojynvw/08252026talwani.pdf) — primary federal court order
- [Reuters — judge finds USPS violated mail-voting injunction while leaving existing block in place](https://www.reuters.com/world/judge-chides-us-postal-service-over-mail-in-voting-rule-wont-block-it-2026-08-25/) — independent reporting on the district-court order and rule status
- [Massachusetts Attorney General — 25-state challenge to USPS mail-ballot rule](https://www.mass.gov/news/ag-campbell-sues-united-states-postal-service-over-unlawful-attempt-to-interfere-with-states-vote-by-mail-procedures) — primary plaintiff announcement and filed allegations
- [Reuters — states renew challenge to mail-voting restrictions](https://www.reuters.com/legal/government/democratic-led-states-renew-challenge-trump-plans-restrict-mail-in-voting-2026-08-26/) — independent reporting on the filed lawsuit and procedural status
- [Associated Press — states sue over USPS ballot-mail rule](https://apnews.com/article/7ed54dda90705ff169d0a022f6a1dde9) — independent reporting on the filed lawsuit and election-administration effects
- [Reuters — USPS says federal mail-ballot requirements are in effect](https://www.reuters.com/world/us/mail-in-voting-restrictions-now-effect-us-postal-service-says-2026-08-27/) — independent reporting on agency-confirmed implementation and pending emergency litigation
- [The Guardian — USPS implements mail-ballot requirements](https://www.theguardian.com/us-news/2026/aug/27/us-postal-service-mail-ballot-rules-trump-order) — independent reporting corroborating immediate implementation and litigation status
- [League of Women Voters of Massachusetts v. Trump — temporary restraining order staying core USPS ballot-mail requirements](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/rDP_zBX5vmWQ/v0) — primary federal court temporary restraining order
- [Reuters — judge temporarily blocks core USPS mail-ballot rule provisions](https://www.reuters.com/world/judge-blocks-rule-implementing-trump-plan-restrict-mail-in-voting-2026-08-28/) — independent reporting on the 14-day order, affected provisions, and pending hearing
- [U.S. District Court docket — League of Women Voters of Massachusetts v. Trump](https://www.courtlistener.com/docket/73133197/league-of-women-voters-of-massachusetts-v-trump/) — primary federal docket containing the temporary restraining order and notice of appeal
- [Associated Press — administration appeals temporary block on mail-ballot rule](https://apnews.com/article/8ef4a669a50f3406481ffb8387ccad3c) — independent reporting on the notice of appeal, continuing stay, and election timetable
- [Justice Department — emergency First Circuit motion to stay USPS ballot-mail restraining order](https://fingfx.thomsonreuters.com/gfx/legaldocs/dwpknxnoevm/08312026doj_stay.pdf) — primary appellate filing stating the requested administrative and pending-appeal stays, the government's legal position and the continuing effect of the district-court order
- [Reuters — administration seeks emergency First Circuit stay of mail-ballot order](https://www.reuters.com/legal/government/trump-administration-asks-us-appeals-court-lift-order-blocking-mail-in-voting-2026-09-01/) — independent legal reporting on the district-court stay denial, appellate motion, approaching ballot-mail dates and unresolved status
- [Senate Permanent Subcommittee on Investigations — USPS whistleblower disclosure and oversight letter](https://www.blumenthal.senate.gov/imo/media/doc/2026-08-31_final_letter-disclosure.pdf) — primary publication of an attributed congressional oversight letter and anonymous whistleblower disclosure alleging rushed portal development and a zero-percent batch-verification rule
- [Associated Press — USPS portal whistleblower alleges rushed and error-prone implementation](https://apnews.com/article/midterm-elections-postal-service-mail-voting-7f7cf4fdf2e9cf369ae96f96fbda03f2) — independent reporting on the whistleblower disclosure, still-inactive portal, litigation status and administration response
- [Reuters — USPS whistleblower warns ballot rules could reject legal mail](https://www.reuters.com/legal/government/us-homeland-security-ramp-up-voter-fraud-investigations-this-week-cnn-reports-2026-09-01/) — independent reporting on the congressional disclosure, alleged zero-percent batch rule and unresolved litigation
- [Justice Department — Supreme Court application to stay USPS mail-ballot temporary restraining order](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/rXqXoSpVYNl0/v0) — primary emergency application presenting the government's legal argument and requested relief
- [Reuters — administration takes USPS mail-ballot stay request to Supreme Court](https://www.reuters.com/world/trump-administration-takes-mail-in-ballot-fight-us-supreme-court-2026-09-03/) — independent reporting on the emergency application, operative temporary order and procedural posture
- [Associated Press — government seeks Supreme Court relief over mail-ballot requirements](https://apnews.com/article/trump-mail-voting-executive-order-lawsuit-63899f738d28d161b629054a314f161a) — independent reporting on the application, portal status, state implementation and lower-court hearing
- [Associated Press — district judge enters preliminary injunction against USPS mail-ballot requirements](https://apnews.com/article/ce207ff2d0533de05cc2d299e91a0198) — independent reporting on the longer preliminary relief and continuing appellate posture
- [Associated Press — administration renews Supreme Court request over mail-ballot rule](https://apnews.com/article/trump-mail-voting-executive-order-lawsuit-65067233db6ebda8dedcdc3f6714a96c) — independent reporting on the renewed emergency filing after entry of the preliminary injunction and the unchanged operative status
- [First Circuit — League of Women Voters litigation, Nos. 26-2029 through 26-2032](https://www.ca1.uscourts.gov/sites/ca1/files/opnfiles/26-2029O-01A.pdf) — primary order denying stays of preliminary injunction

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
