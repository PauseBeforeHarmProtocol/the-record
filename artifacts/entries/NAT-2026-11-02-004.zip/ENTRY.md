# Judge orders Chicago U.S. attorney testimony in Broadview Six inquiry

**Entry ID:** NAT-2026-11-02-004
**Date:** November 2, 2026
**Checked:** 2026-11-03 12:08 AM EST
**Evidence state:** Associated Press plus two independent local reports describing and quoting the November 2 order; original order unavailable in this review, prior DOJ explanation inspected, allegations and findings kept distinct
**Review state:** current-standard-reviewed

Four prosecutors must testify under oath on November 16 about grand-jury materials and representations to the court; the order opens an inquiry, not a misconduct finding.

## THE FACTS

- Associated Press, CBS Chicago and WTTW independently reported that U.S. District Judge April Perry ordered Chicago U.S. Attorney Andrew Boutros and three assistant U.S. attorneys to testify under oath on November 16 in United States v. Rabbitt, No. 1:25-cr-00693. The original November 2 order was not separately retrieved, so its terms are attributed to the corroborated reports.
- The reported order concerns the failed Broadview Six prosecution, grand-jury transcripts and redactions, and the accuracy of statements made to the court. AP reports that Perry found more than an adequate factual basis to inquire whether willful false statements were made. Ordering testimony and opening an inquiry do not establish perjury, contempt, professional misconduct or criminal liability.
- The prosecution had been dismissed with prejudice months earlier. Boutros previously said nobody intended to mislead the court and his office issued a special report defending aspects of the grand-jury process. In later filings, Associate Attorney General Stanley Woodward said the government had not agreed to provide information and sought concrete notice of the inquiry's factual basis. Those are administration positions, not adjudicated answers.
- AP also reported former Chicago FBI chief Douglas DePodesta's same-day lawsuit alleging that he was forced out and scapegoated over the case. The lawsuit is a separate allegation and is not treated as proof of retaliation or prosecutorial wrongdoing; the qualifying development here is the court-ordered sworn testimony and scheduled inquiry.

## SIGNIFICANCE

Compelling the sitting U.S. attorney and assistants to testify under oath is a consequential judicial inquiry into the integrity of federal prosecution and representations to the court. It may produce evidence for sanctions, contempt or exoneration, but no such outcome has yet occurred.

## GOALPOST / RESPONSE

Boutros and the Justice Department say there was no intent to mislead and have challenged the scope and notice supporting further inquiry. The court says the record warrants sworn examination. The tests are the November 16 testimony, authenticated transcripts and redaction history, specific findings, any sanction or contempt process and appellate review—not the existence of allegations alone.

## MAYBE / THEREFORE

Maybe testimony will explain good-faith mistakes and disputed redactions, or it may substantiate deliberate misrepresentations requiring sanctions. Therefore the record establishes a scheduled, court-ordered evidentiary inquiry—not a finding that Boutros or any assistant lied, committed contempt or retaliated against the former FBI official.


## SOURCES

- [Associated Press — judge orders Chicago U.S. attorney and assistants to testify](https://apnews.com/article/736be23019542b9346b8a55e349c85a3) — independent report quoting and describing the November 2 order; original order not separately retrieved
- [CBS Chicago — prosecutors ordered to testify in Broadview Six inquiry](https://www.cbsnews.com/chicago/news/andrew-boutros-ordered-testify-broadview-six-judge-april-perry/) — independent local corroboration of the testimony order and hearing date
- [WTTW — judge orders testimony over failed Broadview Six prosecution](https://news.wttw.com/2026/11/02/judge-orders-chicago-us-attorney-andrew-boutros-testify-botched-broadview-six) — independent local report on the court inquiry, government response and unresolved allegations
- [Northern District of Illinois — special report on Broadview Six grand-jury appearances](https://www.justice.gov/usao-ndil/pr/united-states-attorney-andrew-s-boutros-issues-rare-special-report-regarding-federal) — primary administration explanation issued before the November testimony order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
