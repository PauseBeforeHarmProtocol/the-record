# Military reports laser interceptions of 11 border drones in one week

**Entry ID:** NAT-2026-09-04-013
**Date:** August 27–September 4, 2026
**Checked:** 2026-09-04 6:00 PM EDT
**Evidence state:** U.S. Northern Command figures and attributed official statements reported by Reuters; implementation and claimed output documented, attribution, location, safety and effectiveness not independently verified
**Review state:** current-standard-reviewed

Northern Command reported implemented laser use and more than 300 drone takedowns this year, while locations, airspace, evidence and independent operational verification remain undisclosed.

## THE FACTS

- U.S. Northern Command said the military had used the Army Multipurpose High-Energy Laser system to down 11 unmanned aircraft since deploying the technology along the U.S.-Mexico border the prior week.
- The command assessed the aircraft as associated with illicit border activity. That is an official operational assessment; the public statement did not release imagery, recovered payloads, ownership evidence or case-specific information independently establishing cartel control of each drone.
- The military also reported that kinetic and non-kinetic systems had taken down more than 300 drones in support of Customs and Border Protection since the start of 2026, including more than 100 in August. Reuters had previously reported three laser interceptions during the first week of deployment.
- Officials did not disclose the exact locations, whether the interceptions occurred in U.S. or Mexican airspace, the laser manufacturer, rules of engagement, safety incidents or how many assessed threats crossed the border. The totals are administration-reported implementation and output measures, not an independently audited effectiveness or legality finding.

## SIGNIFICANCE

The disclosure documents repeated domestic-border use of a directed-energy weapon and a much larger drone-interception campaign than previously public. Missing location, attribution and safety information limits assessment of sovereignty, civil-aviation risk, proportionality and whether the operations reduce trafficking or surveillance.

## GOALPOST / RESPONSE

Northern Command says the systems support Customs and Border Protection against drones associated with illicit activity. Incident logs, coordinates and airspace, recovered devices and payloads, attribution evidence, FAA coordination, rules of engagement, false-positive and safety records, costs and changes in trafficking or surveillance are the tests.

## MAYBE / THEREFORE

Maybe the laser system is a precise and cost-effective response to a documented drone threat, or incomplete attribution and airspace disclosure may conceal false positives, safety risks or cross-border complications. Therefore the record confirms the military's reported 11 laser interceptions and broader totals—not independent proof that every aircraft was cartel-operated, where each was engaged or that the campaign has reduced illicit activity.


## SOURCES

- [Reuters — military reports laser interceptions of border drones](https://www.reuters.com/business/media-telecom/lasers-down-11-cartel-drones-along-southern-border-us-military-says-2026-09-04/) — independent reporting based on U.S. Northern Command's statement and administration-reported operational totals

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
