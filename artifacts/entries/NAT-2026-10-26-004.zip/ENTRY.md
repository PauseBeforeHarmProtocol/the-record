# FTC and states sue Dollar General over alleged shelf-to-register overcharging

**Entry ID:** NAT-2026-10-26-004
**Date:** October 26, 2026
**Checked:** 2026-10-28 12:47 AM EDT
**Evidence state:** Original stamped complaint, FTC announcement and defendant’s original statement; brief independent confirmation from The Guardian. Filed/pending, with contested claims. October 26 recovery; no claim of first publication within the new source window.
**Review state:** current-standard-reviewed

The October 26 complaint seeks injunctions and monetary relief; Dollar General disputes the allegations, redress calculation and monetary-authority theory.

## THE FACTS

- On October 26, the FTC and twenty state plaintiffs filed No. 3:26-cv-01693 in the Middle District of Tennessee against Dollar General. The stamped complaint invokes the FTC Act, Gramm-Leach-Bliley Act and state laws, seeking injunctive and monetary relief and civil penalties.
- The FTC alleges a recurring pattern of charging more at checkout than shelf tags or advertisements promise. Its announcement describes protecting consumers, particularly those with low or fixed incomes, and reports a 2–0 commission vote authorizing the suit. The allegations and requested relief are not a liability finding or an awarded refund.
- Dollar General says occasional discrepancies occur despite its procedures, employees are expected to correct errors, and price-accuracy processes have improved. It disputes the FTC’s consumer-redress methodology and interpretation of monetary-recovery authority under the Gramm-Leach-Bliley Act, and says it will defend the case.
- The Guardian independently reported the filing and company denial. No judgment or completed consumer recovery was established by the material inspected.

## SIGNIFICANCE

The enforcement case concerns whether shoppers receive advertised prices and whether federal and state authorities can obtain the requested remedies. A filed consumer-protection action is material, but does not itself demonstrate deterrence, compensation or verified agency effectiveness.

## GOALPOST / RESPONSE

The FTC’s strongest case is protecting affordability through accurate pricing. Dollar General contests the alleged pattern, calculations and statutory monetary theory while describing corrective processes. Evidence at trial, legal authority, enforceable relief and realized customer outcomes are the tests.

## MAYBE / THEREFORE

Maybe the evidence will establish systemic overcharging requiring relief, or the defendant’s factual and legal objections will limit the case. Therefore this is a pending enforcement suit, not proven liability, delivered refunds or a measured consumer-benefit result.


## SOURCES

- [FTC and state plaintiffs v. Dollar General, No. 3:26-cv-01693, Document 1](https://www.ftc.gov/system/files/ftc_gov/pdf/DollarGeneral-Complaint.pdf) — primary court filing
- [FTC and state partners sue Dollar General over advertised and register prices](https://www.ftc.gov/news-events/news/press-releases/2026/10/ftc-state-partners-sue-dollar-general-charging-consumers-more-advertised-many-products) — primary agency enforcement announcement
- [Statement regarding FTC lawsuit](https://newscenter.dollargeneral.com/news/statement-regarding-ftc-lawsuit-10262026/1b9f00d7-e1a1-4391-8dce-af2dc5bf1bb9) — primary defendant response
- [FTC sues Dollar General over alleged overcharging](https://www.theguardian.com/us-news/2026/oct/26/dollar-general-ftc-lawsuit) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
