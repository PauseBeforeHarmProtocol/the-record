# EPA grants 29 small refineries 1.76 billion biofuel-compliance credits

**Entry ID:** NAT-2026-08-31-010
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** primary EPA announcement with petition counts, credit volume and proposed next steps, corroborated by Reuters market and policy reporting; exemptions decided, reallocation and deadline rule not yet final
**Review state:** current-standard-reviewed

The agency decided 34 exemption petitions for the 2025 Renewable Fuel Standard; its plan to shift the unexpected shortfall into 2026 and 2027 remains a future proposal.

## THE FACTS

- EPA announced final decisions on 34 petitions for small-refinery exemptions from 2025 Renewable Fuel Standard obligations after consultation with the Department of Energy. It granted 18 full exemptions and 11 half exemptions, denied three petitions and found two ineligible.
- The 29 full or partial exemptions release 1.76 billion Renewable Identification Number compliance credits, compared with the 990 million credits EPA had projected when setting the 2025 volumes. The petition decisions are implemented agency actions; the identities and refinery-specific reasoning are protected in part by confidential-business-information rules.
- EPA said it will propose reallocating 100% of the difference between projected and actual 2025 exemptions into the 2026 and 2027 Renewable Volume Obligations before the end of October. That reallocation has not yet been proposed or finalized and should not be treated as operative.
- EPA also said it would issue a direct final rule extending the 2025 compliance deadline by 30 days to October 1, 2026. The announcement is evidence of the intended procedural action, not a substitute for the published rule and its effective status.
- Reuters reported that the credits were almost twice the earlier estimate and described competing concerns from refiners and biofuel producers. The decision does not itself establish the eventual effect on fuel prices, refinery viability, biofuel demand or agricultural markets.

## SIGNIFICANCE

The exemptions materially reduce 2025 compliance obligations for 29 refineries and add hundreds of millions more credits to the market than EPA anticipated. Whether the agency later restores those volumes through 2026–2027 obligations will determine how much of the burden shifts to other refiners and future compliance years rather than disappearing.

## GOALPOST / RESPONSE

EPA says the case-by-case decisions follow the Clean Air Act, current refinery economics and governing case law while a future reallocation can preserve renewable-fuel volumes. Refiners argue exemptions protect plants facing disproportionate hardship; biofuel interests argue large waivers weaken statutory demand. The proposed reallocation text, final rule, litigation, RIN prices, blending volumes, refinery financial data and fuel-price effects are the tests.

## MAYBE / THEREFORE

Maybe later reallocation will fully offset the unexpected exemptions and mainly change timing, or legal and market developments may leave part of the 2025 reduction uncompensated. Therefore the record treats the 34 petition decisions and 1.76 billion exempted credits as implemented, while treating the 100% reallocation and deadline change as announced future actions whose legal and market effects remain unmeasured.


## SOURCES

- [EPA — 2025 small-refinery exemption decisions and related actions](https://www.epa.gov/newsreleases/epa-announces-action-2025-small-refinery-exemptions-and-related-actions) — primary agency announcement with petition outcomes, exempted RIN volume and clearly prospective reallocation and compliance-date actions
- [Reuters — EPA grants 1.76 billion credits in 2025 refinery exemptions](https://www.reuters.com/legal/litigation/us-expected-approve-expanded-biofuel-waivers-early-monday-sources-say-2026-08-31/) — independent reporting on exemption scale, petition outcomes, proposed reallocation and industry responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
