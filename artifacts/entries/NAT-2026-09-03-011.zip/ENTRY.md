# FAA announces $481 million across 191 airport infrastructure grants

**Entry ID:** NAT-2026-09-03-011
**Date:** September 3, 2026
**Checked:** 2026-09-04 12:00 PM EDT
**Evidence state:** primary FAA award announcement; grant round documented, expenditure progress and outcomes not yet established
**Review state:** current-standard-reviewed

The awards cover airports in 36 states and two territories, including major runway and terminal projects; announced grants are not completed construction or measured safety improvements.

## THE FACTS

- The Federal Aviation Administration announced September 3 that it was providing $481 million through 191 Airport Infrastructure Grants to airports in 36 states and two territories.
- The largest listed awards included $100 million for runway, taxiway, terminal and runway-safety-area work at Hartsfield-Jackson Atlanta International Airport; $32.5 million for Louisville terminal reconstruction; and $30.3 million for San Diego terminal construction.
- Other examples included $14.2 million for Milwaukee taxiway work, $8.7 million for El Paso apron rehabilitation and $2.5 million across Wisconsin general-aviation airports. FAA says the program can fund planning, terminals, baggage systems, runways, taxiways, roads and other safety-related infrastructure.
- The announcement identifies grant awards, not proof that all funds were already drawn, every project had started or finished, costs remained within budget, capacity improved or safety outcomes changed.

## SIGNIFICANCE

A $481 million national award round is a material allocation of federal infrastructure resources, with implications for airport safety, capacity, construction employment and regional access. Outcomes depend on project execution and oversight rather than the headline award amount alone.

## GOALPOST / RESPONSE

Transportation officials say the grants will improve safety, efficiency and future capacity. Executed grant agreements, obligations and draws, procurement, project schedules, cost changes, completion, runway and terminal performance, safety indicators, inspector-general findings and geographic distribution are the tests.

## MAYBE / THEREFORE

Maybe the projects will address documented capital needs and improve airport operations, or delays, cost escalation and weak prioritization may reduce the return. Therefore the record establishes 191 announced grants totaling $481 million—not universal disbursement, completed infrastructure or measured travel and safety gains.


## SOURCES

- [FAA — $481 million Airport Infrastructure Grants announcement](https://www.faa.gov/newsroom/trumps-transportation-secretary-sean-p-duffy-invests-481-million-ahead-labor-day-weekend) — primary agency announcement of 191 grants across 36 states and two territories

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
