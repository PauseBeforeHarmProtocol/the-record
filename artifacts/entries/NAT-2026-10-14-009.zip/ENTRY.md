# Trump announces Pentagon weapons-testing 'super range' in Montana

**Entry ID:** NAT-2026-10-14-009
**Date:** October 14, 2026
**Checked:** 2026-10-14 11:56 PM EDT
**Evidence state:** two Associated Press accounts of the president's public rally announcement; no official Pentagon instrument, funding document, site or implementation record located by cutoff
**Review state:** current-standard-reviewed

The president said the Pentagon will establish the range for advanced weapons; no site, legal instrument, funding, schedule or implementation record was located by cutoff.

## THE FACTS

- At an October 14 campaign rally in Kalispell, Montana, President Trump announced that the Pentagon would establish a new military testing range in the state. Associated Press contemporaneous coverage described his term for it as a 'super range' for testing advanced weapons.
- Trump said the range would help ensure U.S. military supremacy and credited Montana's two Republican senators with repeatedly pressing him to bring it to the state. That is the administration's stated national-defense rationale and political provenance for the announcement.
- The announcement occurred after Trump took the stage at about 7:30 p.m. Mountain time. AP's separate event report also described it as a new military testing range sought by Montana Republicans, providing a second AP account of the same public statement.
- No Pentagon order, acquisition notice, environmental document, land designation, appropriation, contract, exact location, operating authority or implementation schedule was located by the research cutoff. The evidence therefore establishes a presidential announcement, not an established or operational range.

## SIGNIFICANCE

A new advanced-weapons test range could carry large defense, land-use, environmental, safety and regional spending consequences. At this stage those consequences are prospective because the public record inspected contained an announcement without an implementing instrument or defined footprint.

## GOALPOST / RESPONSE

The administration says the range will support advanced-weapons testing and enduring military superiority. Tests include a Pentagon directive, mission and weapons scope, site selection, land and airspace authorities, environmental and tribal consultation, congressional authorization or appropriations, contracts, construction, safety rules and actual tests.

## MAYBE / THEREFORE

Maybe the announcement reflects completed internal planning that will soon produce a funded test complex, or it may remain contingent on siting, legal review, appropriations and local approvals. Therefore the archive records an announced Pentagon range—not a funded, sited, approved, constructed or operational facility.


## SOURCES

- [Associated Press — live coverage of Trump rallies in Arizona and Montana](https://apnews.com/article/0b0d871b2ac233895f0fa3e66e9418a2) — independent contemporaneous reporting on presidential announcement and court development
- [Associated Press — Trump campaigns in Arizona and Montana](https://apnews.com/article/trump-rallies-arizona-montana-midterms-e47553b45b0401455899e08caf80d9e6) — independent event reporting on military-range announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
