# CDC continues Ebola-related entry suspension through October 11

**Entry ID:** NAT-2026-09-11-014
**Date:** September 11–16, 2026
**Checked:** 2026-09-16 5:59 AM EDT
**Evidence state:** primary CDC signed order, Federal Register notice and operational traveler guidance; continuation implemented through October 11, with effectiveness and individual-risk outcomes unmeasured
**Review state:** current-standard-reviewed

The time-limited order covers many noncitizens recently present in the DRC, Uganda or South Sudan and preserves separate routing or boarding rules for other travelers.

## THE FACTS

- CDC issued a September 11 order, published in the Federal Register on September 16, continuing through October 11 at 4:59 p.m. EDT a 30-day suspension covering defined aliens who had been present in the Democratic Republic of the Congo, Uganda or South Sudan during the preceding 21 days.
- The order applies to covered aliens including lawful permanent residents, subject to listed exceptions and case-by-case humanitarian, public-health, law-enforcement and national-interest exceptions. U.S. citizens and nationals are excluded from the statutory entry suspension itself.
- Separate CDC travel guidance says people traveling from the DRC, including U.S. citizens and nationals, cannot board commercial flights until day 22 after leaving, while U.S. citizens and nationals returning from Uganda or South Sudan must route through designated airports. Those operational measures should not be conflated with the narrower statutory definition in the order.
- CDC cited agency-reported outbreak snapshots, including 6,779 confirmed DRC cases and 3,267 deaths as of September 9, a contained Uganda outbreak with 20 confirmed cases and two deaths but continuing overland risk, and no confirmed South Sudan cases but elevated regional risk. These are the agency's time-specific risk findings, not an independent archive measurement.
- The agency rejected individualized screening as operationally infeasible and retained the geographic-presence rule. The notice invites comments through October 1; comments raised due-process and narrower-screening concerns, and no causal evidence showing the continuation's effect on U.S. transmission was published with the order.

## SIGNIFICANCE

The continuation keeps a broad, time-limited public-health border control in force and reaches some lawful permanent residents while placing different constraints on citizens and nationals through separate travel operations. Its legal scope, exceptions and effectiveness therefore matter independently from the underlying outbreak counts.

## GOALPOST / RESPONSE

CDC says temporary suspension and controlled routing reduce the risk that infected travelers enter before symptoms or effective screening. Case trends, exception decisions, operational records, legal challenges, less-restrictive alternatives, domestic transmission and renewal or termination after October 11 are the tests.

## MAYBE / THEREFORE

Maybe the temporary controls reduce importation risk during a severe regional outbreak, or narrower testing, monitoring and routing could provide similar protection with fewer due-process and travel burdens. Therefore the record establishes a continued order and operational restrictions—not that every covered traveler poses a risk or that the policy has measurably prevented U.S. transmission.


## SOURCES

- [Federal Register — continuation of Ebola-related entry suspension](https://www.federalregister.gov/documents/2026/09/16/2026-18948/order-under-sections-362-and-365-of-the-public-health-service-act-continuing-the-suspension-of-the) — primary legal order and notice
- [CDC — signed September 11 Ebola entry-suspension order](https://www.cdc.gov/port-health/media/pdfs/2026/09/September-T42-Order_clean_10Sept26.pdf) — primary signed agency order
- [CDC — requirements for travelers returning from Ebola-affected areas](https://www.cdc.gov/ebola/situation-summary/returning-travelers.html) — primary operational guidance

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
