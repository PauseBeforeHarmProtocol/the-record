# CDC orders DRC-presence attestations for U.S.-bound air passengers starting November 3

**Entry ID:** NAT-2026-09-11-014
**Date:** September 11–October 27, 2026
**Checked:** 2026-10-28 12:47 AM EDT
**Evidence state:** New Federal Register order and CDC instructions establish scope and future dates; no independent implementation or effectiveness finding located. Original September–October facts, Reuters findings and their prior review times retained with dated scope.
**Review state:** current-standard-reviewed

The October 22 order, published October 27, includes U.S. citizens and is not yet effective; it does not establish continuous renewal of the earlier October 11-expiring suspension.

## THE FACTS

- CDC issued a September 11 order, published in the Federal Register on September 16, continuing through October 11 at 4:59 p.m. EDT a 30-day suspension covering defined aliens who had been present in the Democratic Republic of the Congo, Uganda or South Sudan during the preceding 21 days.
- The order applies to covered aliens including lawful permanent residents, subject to listed exceptions and case-by-case humanitarian, public-health, law-enforcement and national-interest exceptions. U.S. citizens and nationals are excluded from the statutory entry suspension itself.
- Separate CDC travel guidance says people traveling from the DRC, including U.S. citizens and nationals, cannot board commercial flights until day 22 after leaving, while U.S. citizens and nationals returning from Uganda or South Sudan must route through designated airports. Those operational measures should not be conflated with the narrower statutory definition in the order.
- CDC cited agency-reported outbreak snapshots, including 6,779 confirmed DRC cases and 3,267 deaths as of September 9, a contained Uganda outbreak with 20 confirmed cases and two deaths but continuing overland risk, and no confirmed South Sudan cases but elevated regional risk. These are the agency's time-specific risk findings, not an independent archive measurement.
- The agency rejected individualized screening as operationally infeasible and retained the geographic-presence rule. The notice invites comments through October 1; comments raised due-process and narrower-screening concerns, and no causal evidence showing the continuation's effect on U.S. transmission was published with the order.
- Reuters reported on October 6 that two named American doctors exposed while treating Ebola patients were sent to Europe rather than U.S. biocontainment centers: Peter Stafford recovered after treatment in Germany, while Patrick LaRochelle did not develop the disease after isolation in the Czech Republic. Both praised the care they received and described disappointment about not returning home; their experiences document implementation, not comparative medical effectiveness.
- Franklin Graham, president of Samaritan's Purse, told Reuters that Americans had fallen from about 80% to about 20% of staff at the charity's Congo Ebola treatment centers and that deployment costs had more than doubled because of the quarantine policy. These are named organization-level measurements; they do not by themselves measure the policy's effect on outbreak transmission.
- Reuters also reported that more than 120 CDC personnel were deployed in Congo and Uganda, that the State Department described $780 million in U.S. response support, and that the White House had requested a $1.4 billion supplemental. The deployment and support amounts do not establish that every dollar was obligated, spent or effective, and the supplemental remained a request.
- HHS spokeswoman Emily Hilliard said the investigation overlooked extensive HHS and CDC work in the United States and Africa, that preventing importation and fighting the outbreak at its source were both essential, and that Secretary Kennedy received regular expert briefings and was deeply engaged. That is the administration's response to the reported operational consequences, not an independent effectiveness finding.
- This record does not conclude that U.S. policy caused the epidemic's case total; conflict, protective-equipment shortages, misinformation and other conditions were also reported as contributing factors.
- A distinct CDC order signed October 22 and published in the Federal Register October 27 requires covered passengers on international flights into or connecting through the United States to attest they were not present in DRC during the preceding 21 days. It includes U.S. citizens, nationals and lawful permanent residents. The order takes effect November 3, 2026, at 11:59 PM EST and runs through December 18 at 11:59 PM EST unless amended or rescinded.
- Airlines must obtain signed paper or digital attestations before boarding, refuse boarding without one absent exemption, retain copies for at least 42 days and provide them on request. DRC airport transit counts as presence. Authorized Ebola-patient transport and individual CDC humanitarian or important-government exemptions are available. This future order does not establish that the earlier October 11-expiring suspension remained continuously in force.

## SIGNIFICANCE

The new order would condition U.S.-bound international boarding on a DRC-presence attestation, including for citizens. Earlier named aid-worker staffing and cost findings remain dated context; neither those reports nor this order establish net effectiveness.

## GOALPOST / RESPONSE

CDC describes the attestation as reducing Ebola importation risk over its maximum incubation period. HHS previously defended simultaneous border and overseas response work. Exemption decisions, staffing and costs, domestic transmission and comparative outcomes remain the tests.

## MAYBE / THEREFORE

Maybe the time-limited attestation reduces importation risk while exemptions preserve essential travel, or its burdens weaken source containment. Therefore this is an ordered future requirement, not measured success or proof the earlier suspension continued after October 11.


## SOURCES

- [Federal Register — continuation of Ebola-related entry suspension](https://www.federalregister.gov/documents/2026/09/16/2026-18948/order-under-sections-362-and-365-of-the-public-health-service-act-continuing-the-suspension-of-the) — primary legal order and notice
- [CDC — signed September 11 Ebola entry-suspension order](https://www.cdc.gov/port-health/media/pdfs/2026/09/September-T42-Order_clean_10Sept26.pdf) — primary signed agency order
- [CDC — requirements for travelers returning from Ebola-affected areas](https://www.cdc.gov/ebola/situation-summary/returning-travelers.html) — primary operational guidance
- [Reuters — investigation of U.S. Ebola-response staffing, quarantine and funding consequences](https://www.reuters.com/world/how-trumps-america-first-policy-hit-ebola-response-congo-2026-10-06/) — independent investigative reporting with named medical, aid and administration sources; unnamed-source claims retained as attributed and not independently established
- [CDC October 22 order requiring DRC-presence attestations, FR Doc. 2026-21828](https://www.govinfo.gov/content/pkg/FR-2026-10-27/pdf/2026-21828.pdf) — primary agency order
- [CDC attestation order, technical instructions and passenger FAQs](https://www.cdc.gov/port-health/legal-authorities/attestation-order.html) — primary agency implementation instructions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
