# Energy Department offers Northeast heating-oil reserve exchange

**Entry ID:** NAT-2026-10-21-002
**Date:** October 21, 2026
**Checked:** 2026-10-21 11:57 AM EDT
**Evidence state:** primary Energy Department announcement and solicitation terms plus Reuters reporting on scale, history and competing effectiveness assessment; bids, awards, deliveries and price effects pending
**Review state:** current-standard-reviewed

A competitive solicitation offers up to 315,000 barrels for temporary exchange, with deliveries due by November 13 and replacement fuel plus a premium due before the 2027–28 heating season.

## THE FACTS

- The Energy Department announced a request for proposals to exchange up to 315,000 barrels of ultra-low-sulfur distillate from the Northeast Home Heating Oil Reserve. The department said the temporary exchange was intended to address supply-chain disruptions and heating-oil costs in the Northeast.
- DOE said borrowing companies must return the same volume plus a premium before the 2027–28 heating season. Fuel would come from storage sites in South Portland, Maine; Boston, Massachusetts; and New Haven, Connecticut, with transfers or deliveries scheduled by November 13, 2026. Bids are due October 27.
- Reuters reported that the offered volume is roughly one third of the reserve's approximately one million barrels and described the action as the reserve's first use since Hurricane Sandy in 2012. The solicitation had opened, but bids, awards, deliveries, replacement premiums and consumer-price effects were not yet known by cutoff.
- Energy Secretary Chris Wright said the exchange would mitigate elevated winter heating costs and characterized the disruption as temporary. Reuters quoted an energy analyst who said the relatively small volume was unlikely to have much price effect. Neither statement is a measured outcome.

## SIGNIFICANCE

The solicitation is an implemented use of a federal emergency stockpile process rather than a rhetorical proposal, but the physical exchange and any market effect remain pending. Its limited size makes bid participation, delivered volumes and regional price data essential to judging effectiveness.

## GOALPOST / RESPONSE

The administration says the temporary exchange will ease supply constraints and lower costs while preserving the reserve through return barrels and a premium. The tests are competitive awards, completed deliveries, replacement terms, reserve restoration and Northeast heating-oil prices relative to supply conditions.

## MAYBE / THEREFORE

Maybe a targeted exchange can relieve a short regional bottleneck before winter, or its roughly 315,000-barrel ceiling may be too small to materially affect prices. Therefore the record establishes an authorized solicitation with binding return conditions—not completed delivery, a permanent drawdown or demonstrated consumer savings.


## SOURCES

- [Department of Energy — Northeast Home Heating Oil Reserve exchange](https://www.energy.gov/articles/energy-department-authorizes-exchange-northeast-home-heating-oil-reserve) — primary agency announcement and solicitation terms for a competitive exchange of up to 315,000 barrels
- [Reuters — Energy Department offers Northeast heating-oil reserve exchange](https://www.reuters.com/business/energy/us-aims-loan-about-third-heating-oil-reserve-bid-tame-prices-2026-10-21/) — independent reporting on the announced exchange, reserve scale, timing and disputed likely price effect

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
