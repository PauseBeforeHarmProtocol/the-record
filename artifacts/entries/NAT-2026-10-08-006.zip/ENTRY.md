# HHS launches vaccine-injury research, reporting and care package

**Entry ID:** NAT-2026-10-08-006
**Date:** October 5–8, 2026
**Checked:** 2026-10-09 12:03 AM EDT
**Evidence state:** official HHS announcement with independent Reuters context; clinic opened, reimbursement proposed, and EHR/VAERS changes announced with implementation and effectiveness unresolved
**Review state:** current-standard-reviewed

The department opened an NIH clinic, proposed Medicare payment for physician VAERS reports and announced health-record and reporting-system changes; the package mixes implemented, proposed and planned steps.

## THE FACTS

- HHS announced on October 8 that NIH had opened a clinic on October 5 to evaluate and care for patients reporting health problems after vaccination while studying possible causes and care approaches. The clinic opening is implemented; patient access, enrollment, protocols and outcomes were not detailed in the inspected release.
- CMS proposed reimbursing physicians for time spent submitting suspected vaccine-injury reports to VAERS. That payment policy is proposed rather than final, and a VAERS report is a safety signal report—not proof that a vaccine caused the reported event.
- HHS said federal health-information-technology standards will require electronic health records to capture vaccine-related adverse events. The release did not supply an effective date, final technical specification or compliance measure, so implementation remains to be documented.
- CDC is modernizing VAERS under a contract announced September 28 after an August solicitation, including mobile access and research tools. That earlier contract is part of the package but is not counted as a second October 8 action.
- Secretary Robert F. Kennedy Jr. said the initiative would take patient reports seriously, follow evidence and strengthen vaccine safety. Reuters supplied independent context on the injury-compensation system; neither the official announcement nor a passive report establishes causation or a measured safety improvement.

## SIGNIFICANCE

The package changes how the department intends to connect clinical care, adverse-event reporting, medical records and safety research. It may improve signal detection and patient evaluation, but it could also amplify unsupported causal interpretations unless reporting and research retain clear epidemiologic safeguards.

## GOALPOST / RESPONSE

HHS says the actions will generate better evidence, improve care and rebuild trust. Final CMS and health-IT instruments, clinic protocols and enrollment, VAERS modernization delivery, signal-validation methods, peer-reviewed findings and patient outcomes are the tests.

## MAYBE / THEREFORE

Maybe integrated care and reporting will identify rare harms and improve treatment, or poorly bounded interpretation of passive reports may confuse temporal association with causation. Therefore HHS launched a material multi-agency initiative with one clinic operating and other components proposed or developing—not proof of new vaccine-caused injuries or improved outcomes.


## SOURCES

- [HHS — agency-wide vaccine-injury research, reporting and patient-care actions](https://www.hhs.gov/press-room/hhs-strengthens-vaccine-injury-research-reporting-patient-care.html) — primary official announcement of implemented, proposed and planned agency actions
- [Reuters — HHS vaccine-injury research and reporting initiative](https://www.reuters.com/legal/litigation/us-health-secretary-kennedy-launches-new-push-vaccine-injuries-2026-10-08/) — independent reporting and public-health context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
