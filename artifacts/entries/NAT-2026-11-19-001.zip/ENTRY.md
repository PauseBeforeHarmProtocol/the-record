# Treasury blocks five Southeast Asia cyber-scam targets

**Entry ID:** NAT-2026-11-19-001
**Date:** November 19, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** official Treasury designation release plus independent Reuters confirmation; sanctions implemented with named targets and legal effects, while operational disruption and recovery remain unmeasured
**Review state:** current-standard-reviewed

OFAC designated three people and two companies tied to scam compounds and armed-group protection networks, immediately applying U.S. blocking and transaction prohibitions.

## THE FACTS

- OFAC designated Cambodian national Zhao Hui; Bei Fang Bo Lin Construction Decoration Co., Ltd.; ZHZ Investment Consulting Co., Ltd.; Democratic Karen Benevolent Army commander-in-chief General Saw Shwe Wah; and Colonel Saw A One under Executive Order 13694 as further amended.
- Treasury said Zhao leased one Prince Group scam center and owned and operated another targeting Americans and Europeans through virtual-currency investment fraud. It designated his two companies because they were owned or controlled by, or acted for, Zhao.
- Treasury designated Saw Shwe Wah and Saw A One as DKBA leaders or officials, alleging the armed group protects and facilitates scam compounds near the Thai-Burma border. Reuters independently confirmed the five named targets and Treasury's description.
- As implemented sanctions, property and interests in property of the designated persons within U.S. jurisdiction are blocked and reportable, entities at least 50 percent owned by blocked persons are also blocked, and covered U.S.-linked transactions are generally prohibited absent authorization.

## SIGNIFICANCE

The action expands financial pressure from scam operators to armed actors and affiliated companies that Treasury says enable industrial-scale fraud against Americans. Designation imposes legal restrictions, but disruption, victim recovery and behavioral change have not yet been measured.

## GOALPOST / RESPONSE

Treasury says the sanctions implement Trump's cybercrime order and are intended to disrupt foreign scam compounds and protect Americans. The tests are asset identifications and freezes, enforcement actions, network or payment disruption, prosecutions, victim losses and any later delisting or license.

## MAYBE / THEREFORE

Maybe the blocking action will constrain the targeted compounds and their protection networks, or they may route activity through other actors and jurisdictions. Therefore OFAC implemented sanctions against five named targets—not proof that the scam centers were dismantled or victims repaid.


## SOURCES

- [Treasury Targets Cyber Scam Operators and Armed Group Facilitators in Southeast Asia](https://home.treasury.gov/news/press-releases/sb0695) — primary OFAC sanctions release identifying three people, two companies, legal authorities and blocking consequences
- [US Treasury sanctions three people linked to Southeast Asia scam centers](https://www.reuters.com/world/us-treasury-sanctions-three-people-linked-southeast-asia-scam-centers-2026-11-19/) — independent reporting confirming the targets and Treasury's stated basis for the implemented sanctions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
