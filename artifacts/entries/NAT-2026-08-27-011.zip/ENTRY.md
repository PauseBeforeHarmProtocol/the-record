# ICE awards $16.7 million sole-source contract for electric-shock gloves

**Entry ID:** NAT-2026-08-27-011
**Date:** August 26–27, 2026
**Checked:** 2026-08-27 11:58 PM EDT
**Evidence state:** primary ICE noncompetitive-acquisition justification plus independent AP, Reuters, and CBS reporting; contract awarded and posted, distribution and operational outcomes pending
**Review state:** current-standard-reviewed

The six-month purchase covers 6,000 devices plus support equipment and services for officers to use during arrests, detainee transport, and civil disturbances.

## THE FACTS

- Immigration and Customs Enforcement signed and then publicly posted a $16,700,640 noncompetitive contract package for 6,000 Generated Low Output Voltage Emitter gloves from Kentucky-based Compliant Technologies LLC, plus refills, testers, training or certification, disinfectant, and support services over six months.
- The agency's acquisition justification says the devices function as patrol gloves until activated and deliver low-level electrical pulses through direct contact with bare skin. ICE says officers may use them when a person is actively or passively resisting during arrests, detainee transport, or civil disturbances, and describes them as a lower-impact alternative to higher levels of force.
- ICE selected the company as the only source it found for the patented wearable technology. The procurement record says the devices will be used under approved policy, training, and accountability standards but does not disclose those safeguards. Sixteen Democratic senators urged cancellation and requested public use, training, and review rules; DHS responded that denying safety equipment would endanger officers and said its technology decisions are reviewed for compliance with law-enforcement policies.

## SIGNIFICANCE

The award moves a controversial use-of-force technology from a purchasing plan to a funded nationwide deployment. Its direct-contact design and authorized use against passive resistance and in civil disturbances raise proportionality, medical-safety, documentation, and accountability questions that cannot be resolved by the procurement rationale alone.

## GOALPOST / RESPONSE

ICE says the gloves can de-escalate encounters, reduce injuries, and avoid batons, chemical or impact munitions, and lethal force; DHS says officers are highly trained and equipment choices are reviewed. Critics say electrically induced pain during civil arrests creates abuse risks without disclosed limits and oversight. The final use-of-force policy, training completion, deployment records, medical events, complaints, investigations, and comparative force data are the tests.

## MAYBE / THEREFORE

Maybe the devices will reduce more injurious force when officers follow strict training and reporting rules, or their discreet direct-contact design and passive-resistance authorization may expand painful force with limited visibility. Therefore the record reports a funded sole-source acquisition—not completed field distribution, demonstrated safety, reduced injuries, or proven misuse.


## SOURCES

- [ICE — justification for sole-source purchase of 6,000 G.L.O.V.E. devices](https://assets1.cbsnewsstatic.com/hub/cms/prod_cms_alt/file/2026/08/27/98a184b9-cebe-4a1e-8217-768f1f42e242/1.4.1-far_6.3_glove-rev_4_r_redacted.pdf) — primary federal noncompetitive-acquisition justification and cost schedule
- [Associated Press — ICE awards $16.7 million contract for electric-shock gloves](https://apnews.com/article/ice-electric-shock-gloves-immigration-680c6f8a96736f46529287178c57b44b) — independent reporting on contract status, intended uses, criticism, and DHS response
- [Reuters — ICE grants $16.7 million contract for electric-shock gloves](https://www.reuters.com/world/us-ice-grants-167-million-contract-buy-thousands-electric-shock-gloves-2026-08-28/) — independent confirmation of award value, quantity, and sole-source status
- [CBS News — ICE electric-shock glove contract and procurement safeguards](https://www.cbsnews.com/news/ice-electric-shock-glove-16-7-million-contract/) — independent reporting linked to the federal procurement record and agency response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
