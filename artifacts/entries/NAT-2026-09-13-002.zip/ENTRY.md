# Trump announces removal of 10% tariff on Irish whiskey

**Entry ID:** NAT-2026-09-13-002
**Date:** September 13, 2026
**Checked:** 2026-09-13 5:59 PM EDT
**Evidence state:** independent Reuters and Associated Press eyewitness reporting of the on-record announcement and current tariff context; removal announced, implementing instrument, scope details, effective date and outcomes pending
**Review state:** current-standard-reviewed

The president announced a product-specific exemption, but no implementing instrument or effective date was available by cutoff.

## THE FACTS

- At the close of the Irish Open on September 13, Trump announced that the United States would remove the 10% tariff on Irish whiskey. Reuters and Associated Press reporters witnessed and independently reported the announcement.
- Irish whiskey currently faces the 10% rate applied to most European Union wine and spirits exports after a 15% rate was reduced in July. The administration previously removed tariffs on U.K. whiskey, including Scotch and spirits from Northern Ireland; AP reported that the zero rate took effect July 24.
- Trump said Ireland's prime minister, golfer Shane Lowry and others had urged him to act. The Irish Whiskey Association welcomed the announcement and said it looked forward to implementation while continuing to seek zero-for-zero treatment for all drinks exports.
- No proclamation, customs notice, tariff-schedule amendment or effective date implementing the Irish-whiskey exemption was identified by cutoff. The record therefore treats the change as announced, not already collected at a zero rate or extended to all Irish, European Union or alcoholic-beverage imports.

## SIGNIFICANCE

A product-specific tariff exemption can change prices, inventories and competitive conditions for Irish producers and U.S. importers while creating differential treatment inside the broader European Union trade framework. Its practical effect begins only when customs treatment changes.

## GOALPOST / RESPONSE

Trump says the tariff was unfair and responded to requests from Irish political, industry and sports figures. The Irish Whiskey Association welcomes relief but seeks zero tariffs for all drinks exports. A signed instrument, Customs and Border Protection guidance, effective date, covered tariff lines, import values, retail prices and any reciprocal European Union action are the tests.

## MAYBE / THEREFORE

Maybe the announcement quickly becomes a narrow, mutually beneficial exemption, or implementation may be delayed, narrowed or folded into broader negotiations. Therefore the record confirms a presidential announcement to remove the current 10% Irish-whiskey tariff—not a completed customs change, a zero rate for all European Union spirits or measured consumer savings.


## SOURCES

- [Reuters — Trump announces removal of Irish-whiskey tariff](https://www.reuters.com/world/us/trump-says-he-is-lifting-tariffs-irish-whiskey-2026-09-13/) — independent eyewitness reporting of the presidential announcement, current 10% rate, trade context and industry response; implementation pending
- [Associated Press — Trump plans to remove 10% Irish-whiskey tariff](https://apnews.com/article/trump-tariffs-irish-whiskey-e2eaed86e5c13013af92c102ad082b76) — independent eyewitness reporting, corrected by AP to the current 10% rate and April 30 date of the earlier U.K.-whiskey statement; effective date unavailable

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
