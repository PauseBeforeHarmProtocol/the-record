# FAR Council proposes four-part federal procurement overhaul

**Entry ID:** NAT-2026-09-18-004
**Date:** September 18, 2026
**Checked:** 2026-09-18 12:00 PM EDT
**Evidence state:** four complete primary FAR Council proposed rules; government-wide revisions proposed with October 19 comment deadline, final text and effects unresolved
**Review state:** current-standard-reviewed

The linked proposals would rewrite major contracting, commercial-buying, intellectual-property, transportation and construction provisions; comments close October 19.

## THE FACTS

- The Office of Federal Procurement Policy, Defense Department, General Services Administration and NASA jointly published four proposed rules implementing Executive Order 14275's ‘Revolutionary FAR Overhaul.’ Comments are due October 19, 2026.
- The package proposes revisions spanning FAR parts 8, 9, 12 through 17, 27, 28, 35, 36, 38, 44, 47, 51 and related part 52 clauses. The council says these are four of twelve proposed rules intended collectively to streamline the FAR in its entirety.
- The largest proposal reorganizes purchasing, commercial-product and service acquisitions, simplified acquisitions, negotiation, federal supply schedules, subcontracting and government supply sources. It would consolidate commercial-acquisition procedures and continue simplified commercial procedures up to $9 million, or $15 million for specified contingencies.
- The other proposals address contract types and special contracting methods, research and development, contractor responsibility, intellectual property and transportation, sealed bidding, bonds and insurance, construction and related clauses. Several proposed changes remove or relocate nonstatutory provisions and revise which clauses apply to commercial acquisitions.
- The council says the changes should reduce burden, increase commercial and small-business participation and competition, and improve value, but it does not quantify overall savings. Existing agency class deviations may already use model text, yet these notices remain proposed government-wide regulations and no final text or measured procurement outcome is established.

## SIGNIFICANCE

The package begins formal notice-and-comment rulemaking for a broad rewrite of the government-wide acquisition code. If finalized, it could alter how hundreds of billions of dollars in federal contracts are competed, negotiated and administered.

## GOALPOST / RESPONSE

The council says a shorter, plain-language FAR will speed buying, reduce compliance costs and widen competition without sacrificing stewardship. Final text, retained statutory protections, protest and oversight outcomes, competition rates, procurement lead times, prices, small-business participation and audit findings are the tests.

## MAYBE / THEREFORE

Maybe simplification lowers barriers and helps agencies buy faster from a broader market, or deleting and relocating safeguards may reduce consistency or oversight without producing promised savings. Therefore four formal proposals are open for comment—not a completed FAR rewrite or demonstrated improvement in cost, speed or competition.


## SOURCES

- [Federal Register — proposed FAR overhaul parts 8, 12, 13, 15, 38, 44 and 51](https://www.federalregister.gov/documents/2026/09/18/2026-19162/federal-acquisition-regulation-revolutionary-far-overhaul-parts-8-12-13-15-38-44-and-51) — primary proposed rule
- [Federal Register — proposed FAR overhaul parts 16, 17 and 35](https://www.federalregister.gov/documents/2026/09/18/2026-19160/federal-acquisition-regulation-revolutionary-federal-acquisition-regulation-overhaul-parts-16-17-and) — primary proposed rule
- [Federal Register — proposed FAR overhaul parts 9, 27 and 47](https://www.federalregister.gov/documents/2026/09/18/2026-19159/federal-acquisition-regulation-revolutionary-federal-acquisition-regulation-overhaul-parts-9-27-and) — primary proposed rule
- [Federal Register — proposed FAR overhaul parts 14, 28, 36 and 52](https://www.federalregister.gov/documents/2026/09/18/2026-19158/federal-acquisition-regulation-revolutionary-federal-acquisition-regulation-overhaul-parts-14-28-36) — primary proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
