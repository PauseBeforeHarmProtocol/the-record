# Trump signs religious-freedom commission and ALS research laws

**Entry ID:** NAT-2026-11-03-003
**Date:** November 3, 2026
**Checked:** 2026-11-03 6:16 PM EST
**Evidence state:** White House signing announcement and two inspected enrolled statutory texts; enacted authorities and duties, with appropriations, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

One law extends USCIRF through 2028; the other reauthorizes the ALS therapies program through fiscal 2031 and adds safety, review and FDA planning duties.

## THE FACTS

- The White House announced that President Trump signed H.R. 1744 and H.R. 8205 on November 3. The inspected enrolled texts establish enactment; they do not by themselves establish later appropriations, grants, research results or patient outcomes.
- H.R. 1744 extends the United States Commission on International Religious Freedom through December 31, 2028 and authorizes appropriations for fiscal years 2027 and 2028 and the first three months of fiscal 2029. An authorization permits future appropriations; it is not itself a completed expenditure.
- H.R. 8205 reauthorizes the Accelerating Access to Critical Therapies for ALS Act and its ALS research-grant authority through fiscal year 2031.
- The ALS law requires renewal reviews to request and assess enrollment, safety and available efficacy data; requires prompt reporting of new, serious and unexpected safety information; and allows qualifying combined phase 2/3 trials within the grant program.
- The ALS law also directs FDA to publish a rare-neurodegenerative-disease action plan within 18 months and a report within five years. Those deadlines are enacted duties, not evidence that the plan, report or therapeutic advances have already occurred.

## SIGNIFICANCE

The laws preserve two federal institutions beyond expiring authorizations and add inspectable safety and planning requirements to an ALS access-and-research program. Their consequences depend on appropriations, grant administration, FDA compliance and resulting evidence, not enactment alone.

## GOALPOST / RESPONSE

The administration describes both measures as signed legislation. The enrolled texts confirm the legal changes. The tests are subsequent appropriations and USCIRF operations, ALS grant decisions and safety reporting, the FDA action plan and report, and measured research or patient outcomes.

## MAYBE / THEREFORE

Maybe the extensions sustain useful religious-freedom oversight and accelerate responsible ALS research, or authorized programs may receive limited resources and produce uncertain results. Therefore two laws are enacted with specific authorities and deadlines; no funding level, research success or patient benefit should be inferred without later evidence.


## SOURCES

- [White House — H.R. 1744 and H.R. 8205 signed into law](https://www.whitehouse.gov/briefings-statements/2026/11/congressional-bills-h-r-1744-and-h-r-8205-signed-into-law/) — primary presidential signing announcement
- [GovInfo — H.R. 1744 enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119hr1744enr/html/BILLS-119hr1744enr.htm) — primary enrolled statutory text
- [GovInfo — H.R. 8205 enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119hr8205enr/xhtml/BILLS-119hr8205enr.html) — primary enrolled statutory text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
