# Treasury reports $1.966 trillion fiscal-year deficit through August as payment timing reduces monthly gap

**Entry ID:** NAT-2026-09-11-009
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 PM EDT
**Evidence state:** primary Monthly Treasury Statement plus Reuters timing analysis; cash flows measured, causal attribution and final-year outcome unresolved
**Review state:** current-standard-reviewed

August's $166.8 billion headline deficit was reduced by calendar shifts; year-to-date debt interest rose 13%, while net customs receipts remained far below the proposed $5,000-payment cost.

## THE FACTS

- Treasury's September 11 Monthly Treasury Statement reported August receipts of $360.033 billion, outlays of $526.830 billion and a $166.797 billion monthly deficit. Through August, receipts were $4.845 trillion, outlays were $6.811 trillion and the fiscal-year deficit was $1.966 trillion, compared with $1.973 trillion for the comparable prior-year period.
- Treasury cautioned that August's monthly comparison was distorted because an August 1 non-business day shifted several military, retirement, veterans, Supplemental Security Income and Medicare payments into July, while a September 1 holiday shifted veterans benefits into August. Reuters reported a Treasury official's timing-adjusted August deficit estimate of $248 billion, about $7 billion higher than a year earlier.
- The statement reported $292.533 billion in gross customs receipts and $125.225 billion in customs refunds through August, leaving $167.308 billion net. August alone produced $23.377 billion gross and $12.836 billion net after $10.541 billion of refunds.
- Gross Treasury debt-interest outlays reached $1.267 trillion through August, up $143.018 billion, or about 13%, from the comparable period. The official data measure federal cash flows but do not assign the deficit, tariff receipts or interest costs to one policy or actor.

## SIGNIFICANCE

The results provide an official fiscal baseline for claims that tariff receipts or economic growth can fund new cash payments. Calendar shifts make the August headline misleading on its own, and the year-to-date data show both a nearly $2 trillion deficit and rising interest costs.

## GOALPOST / RESPONSE

The administration points to customs receipts and economic growth as resources for its agenda. The tests are enacted appropriations and offsets, final fiscal-year results, tariff refunds and litigation, debt-service costs, and transparent scoring of any new payment proposal.

## MAYBE / THEREFORE

Maybe stronger receipts and future spending restraint narrow the eventual deficit, or higher interest and new commitments may widen it despite customs revenue. Therefore Treasury measured a $1.966 trillion deficit through August and $167.308 billion in net customs receipts—not a balanced budget, a causal verdict on one policy or available authority to spend those receipts without Congress.


## SOURCES

- [Treasury — Monthly Treasury Statement, August 2026](https://fiscaldata.treasury.gov/static-data/published-reports/mts/MonthlyTreasuryStatement_202608.pdf) — primary fiscal statement
- [Reuters — August budget deficit and fiscal-year-to-date results](https://www.reuters.com/markets/us/us-budget-deficit-shrinks-august-year-to-date-flat-197-trillion-2026-09-11/) — independent fiscal reporting based on Treasury data

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
