# Energy Department solicits reserve exchange, then authorizes 400,000-barrel refinery loan

**Entry ID:** NAT-2026-09-29-007
**Date:** September 29–October 23, 2026
**Checked:** 2026-10-23 11:59 AM EDT
**Evidence state:** primary Energy Department announcements plus independent Reuters context; solicitation issued and recipient-specific exchange authorized, with delivery, operational effect and repayment unresolved
**Review state:** current-standard-reviewed

DOE authorized immediate crude delivery from the Strategic Petroleum Reserve to Phillips 66's Lake Charles refinery, with all borrowed oil plus a premium due back.

## THE FACTS

- The Energy Department issued a September 29 request for proposals for an exchange of up to 40 million barrels of crude oil from the Big Hill and Bryan Mound Strategic Petroleum Reserve sites. Bids are due October 6, with proposed deliveries in November and December.
- An exchange is a loan rather than an outright sale: selected companies would return oil later with a premium. DOE described the solicitation as part of a 172-million-barrel U.S. commitment within a 400-million-barrel International Energy Agency response.
- Reuters reported that a prior June offer of 40 million barrels produced borrowing of only about 500,000 barrels and that the reserve held fewer than 284 million barrels, its lowest level since 1982. The new solicitation therefore does not guarantee that 40 million barrels will be awarded or delivered.
- DOE said repayment would occur by late 2028 and could include a premium of up to 24 percent, presenting the exchange as a way to stabilize markets while replenishing the reserve at no acquisition cost.
- By the September 29 cutoff, DOE had solicited bids but had not announced awards, delivered barrels, received repayments or demonstrated an effect on fuel prices or market supply.
- On October 23, DOE separately authorized an emergency exchange of up to 400,000 barrels from the West Hackberry reserve site to Phillips 66's Lake Charles refinery for immediate delivery after a crude-supply disruption. The company must return all borrowed crude plus premium barrels; delivery was authorized, while completed transfer and repayment remained to be documented.
- DOE said the exchange would support refinery operations and transportation-fuel supply in Louisiana and surrounding areas. The authorization identifies a recipient and volume, but it does not establish the quantity ultimately delivered, a measured change in refinery output or fuel prices, or repayment completion.

## SIGNIFICANCE

The Phillips 66 authorization moves one part of reserve policy from solicitation to a recipient-specific emergency exchange intended to keep a refinery supplied. Its actual operational value and effect on reserve readiness depend on delivery, refinery use and timely repayment.

## GOALPOST / RESPONSE

DOE says the exchange will support fuel supply while returning more oil than was borrowed. Delivery records, refinery throughput, transportation-fuel availability, premium terms, barrels returned, repayment timing and reserve levels are the tests.

## MAYBE / THEREFORE

Maybe the targeted loan prevents a near-term refinery disruption and later leaves the reserve with a premium, or delivery and market effects may be small while the reserve remains historically low. Therefore the record establishes a 400,000-barrel exchange authorization—not completed delivery, restored output, lower prices or repayment.


## SOURCES

- [Energy Department — Strategic Petroleum Reserve exchange solicitation](https://www.energy.gov/articles/united-states-energy-department-continues-execution-strategic-reserve-release-commitments) — official request for proposals for an exchange of up to 40 million barrels
- [Reuters — U.S. offers up to 40 million SPR barrels by exchange](https://www.reuters.com/business/energy/us-release-40-million-barrels-crude-strategic-petroleum-reserve-energy-2026-09-29/) — independent reporting on the solicitation, prior uptake and reserve level
- [Energy Department — 400,000-barrel SPR exchange for Phillips 66 Lake Charles refinery](https://www.energy.gov/articles/energy-department-authorizes-strategic-petroleum-reserve-exchange-support-fuel-supply) — official implemented exchange authorization with delivery and repayment terms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
