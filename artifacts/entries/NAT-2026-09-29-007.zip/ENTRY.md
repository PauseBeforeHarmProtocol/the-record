# Energy Department solicits exchange of up to 40 million reserve barrels

**Entry ID:** NAT-2026-09-29-007
**Date:** September 29, 2026
**Checked:** 2026-09-29 11:57 PM EDT
**Evidence state:** primary Energy Department solicitation announcement plus independent Reuters reporting; request for proposals issued, awards, deliveries, repayments and effects unresolved
**Review state:** current-standard-reviewed

The request for proposals offers crude from two Strategic Petroleum Reserve sites for November and December delivery, with later repayment plus a premium; no award or release was complete by cutoff.

## THE FACTS

- The Energy Department issued a September 29 request for proposals for an exchange of up to 40 million barrels of crude oil from the Big Hill and Bryan Mound Strategic Petroleum Reserve sites. Bids are due October 6, with proposed deliveries in November and December.
- An exchange is a loan rather than an outright sale: selected companies would return oil later with a premium. DOE described the solicitation as part of a 172-million-barrel U.S. commitment within a 400-million-barrel International Energy Agency response.
- Reuters reported that a prior June offer of 40 million barrels produced borrowing of only about 500,000 barrels and that the reserve held fewer than 284 million barrels, its lowest level since 1982. The new solicitation therefore does not guarantee that 40 million barrels will be awarded or delivered.
- DOE said repayment would occur by late 2028 and could include a premium of up to 24 percent, presenting the exchange as a way to stabilize markets while replenishing the reserve at no acquisition cost.
- By cutoff, DOE had solicited bids but had not announced awards, delivered barrels, received repayments or demonstrated an effect on fuel prices or market supply.

## SIGNIFICANCE

The solicitation makes a large share of the diminished emergency reserve available during market stress, while using a structure intended to recover more oil later. Its practical scale and market effect depend on industry uptake and completed deliveries.

## GOALPOST / RESPONSE

DOE says the exchange helps fulfill the coordinated response, stabilize energy markets and replenish the reserve through repayment premiums. Valid bids, awarded volume, delivery records, price movements, repayment schedules, barrels returned and reserve levels are the tests.

## MAYBE / THEREFORE

Maybe the exchange supplies timely market liquidity and later rebuilds the reserve at a premium, or weak bidder demand and a low reserve balance may limit the response and increase preparedness concerns. Therefore the record establishes an issued solicitation for up to 40 million barrels—not a completed drawdown, a guaranteed award or a measured price effect.


## SOURCES

- [Energy Department — Strategic Petroleum Reserve exchange solicitation](https://www.energy.gov/articles/united-states-energy-department-continues-execution-strategic-reserve-release-commitments) — official request for proposals for an exchange of up to 40 million barrels
- [Reuters — U.S. offers up to 40 million SPR barrels by exchange](https://www.reuters.com/business/energy/us-release-40-million-barrels-crude-strategic-petroleum-reserve-energy-2026-09-29/) — independent reporting on the solicitation, prior uptake and reserve level

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
