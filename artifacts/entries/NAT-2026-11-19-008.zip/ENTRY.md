# Court preliminarily limits USDA secretary's official religious messages

**Entry ID:** NAT-2026-11-19-008
**Date:** November 19, 2026
**Checked:** 2026-11-20 7:13 AM EST
**Evidence state:** primary preliminary-injunction ruling plus independent Associated Press reporting; interim constitutional relief issued, APA claims dismissed and final merits or appellate disposition unresolved
**Review state:** current-standard-reviewed

A federal judge preliminarily restricted official religious messages by the agriculture secretary while preserving voluntary faith discussion; USDA says it is considering an appeal.

## THE FACTS

- U.S. District Judge Trina Thompson granted a preliminary injunction on six USDA employees' and their union's Establishment Clause claim concerning Secretary Brooke Rollins' official religious messages. The ruling is interim relief based on likelihood and related injunction factors, not a final judgment after trial.
- The order requires Rollins to stop a religious discussion when a colleague asks, avoid a hostile environment through persistent unwelcome advances and not use official authority to pressure subordinates. The boundaries quote the USDA workplace-religion policy Rollins adopted.
- The ruling also preserves voluntary conduct: Rollins may discuss faith with interested colleagues, explain its personal importance, invite colleagues to religious events and express religious views in appropriate conversations. The court expressly did not decide what she may do in her personal capacity.
- The judge dismissed the plaintiffs' Administrative Procedure Act claims but declined to dismiss the constitutional claim. USDA called the injunction an unprecedented attempt to muzzle a Cabinet secretary, maintained the messages conveyed personal views rather than coercion, and said it was evaluating options including a prompt appeal.

## SIGNIFICANCE

The injunction sets immediate limits on how a Cabinet secretary may use official authority and an all-employee channel for religious messages. Its tailored scope separates government workplace coercion from protected voluntary expression while the constitutional dispute continues.

## GOALPOST / RESPONSE

USDA says the messages expressed the secretary's personal views and were not coercive; the court imposed boundaries rather than a blanket ban. The tests are compliance with those limits, any appeal or stay, later merits findings, employee reports, additional messages and whether official communications create or avoid coercive workplace effects.

## MAYBE / THEREFORE

Maybe the injunction will permit ordinary voluntary religious expression while preventing official pressure, or later proceedings may narrow or reverse its constitutional analysis. Therefore a federal court issued preliminary workplace boundaries for Rollins' official communications; it did not bar all faith discussion, decide her personal conduct or enter a final appellate judgment.


## SOURCES

- [National Federation of Federal Employees v. USDA — preliminary-injunction ruling](https://www.courthousenews.com/wp-content/uploads/2026/11/nffe-v-usda-preliminary-injunction-ruling.pdf) — primary preliminary-injunction ruling, No. 3:26-cv-04406-TLT, ECF 59
- [Associated Press — preliminary injunction governing USDA secretary religious messages](https://apnews.com/article/89eae01839b2e43bddec69fee116b1bc) — independent reporting on the injunction, its workplace boundaries and USDA response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
