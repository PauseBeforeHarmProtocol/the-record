# FCC votes to restrict direct U.S. number access for Chinese telecom firms

**Entry ID:** NAT-2026-11-19-004
**Date:** November 19, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** Reuters post-vote reporting plus the official Federal Register meeting notice; Commission action reported adopted, with final text, vote detail and effective date unresolved
**Review state:** current-standard-reviewed

Reuters reported the Commission adopted restrictions covering China Mobile, China Telecom, China Unicom and other IP-enabled providers; the final adopted text and effective date were not yet available in the inspected official sources.

## THE FACTS

- The Federal Communications Commission voted November 19 to bar China Mobile, China Telecom and China Unicom from direct access to U.S. telephone numbers, Reuters reported after the public meeting. The FCC had previously barred the three firms from providing international telecommunications services to the United States.
- Reuters reported that the action also applies eligibility restrictions to other IP-enabled service providers, including providers using equipment from companies on the FCC Covered List. The Commission says the restrictions address national-security risk and access to numbers used for scam-related robocalls.
- The Federal Register public-meeting notice verifies that the Commission convened an open meeting on November 19. The inspected official sources did not yet expose the final adopted order, vote breakdown, Federal Register publication, compliance deadlines or effective date, so those implementation details remain unresolved.

## SIGNIFICANCE

The vote advances a proposed telecom-security screen into an adopted Commission action that can constrain direct number access and raise compliance duties for VoIP providers. Until the final order is published, the exact scope, timing and operational effect should not be overstated.

## GOALPOST / RESPONSE

The FCC frames the restrictions as a first-line defense against illegal robocalls and national-security threats; China has denied wrongdoing and previously criticized the proposal as obstructing normal commercial cooperation. The tests are the released order, legal authority and vote, effective date, affected authorizations, provider compliance, litigation and measured robocall or security outcomes.

## MAYBE / THEREFORE

Maybe the final rule will materially reduce risky direct-number access and scam traffic, or implementation and litigation may narrow its effect. Therefore a Commission vote is independently reported—not yet a fully inspected final order, effective ban or measured reduction in robocalls.


## SOURCES

- [FCC votes to ban Chinese telecoms from direct access to US phone numbers](https://www.reuters.com/world/fcc-votes-ban-chinese-telecoms-direct-access-us-phone-numbers-2026-11-19/) — independent reporting on the completed FCC vote, covered firms and stated national-security and robocall rationale
- [Sunshine Act; Open Commission Meeting Thursday, November 19, 2026](https://www.govinfo.gov/content/pkg/FR-2026-11-18/html/2026-23467.htm) — primary public meeting notice identifying the scheduled open meeting and regulatory agenda

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
