# HHS establishes in-house legal-representation division for unaccompanied migrant children

**Entry ID:** NAT-2026-09-29-014
**Date:** September 29, 2026
**Checked:** 2026-10-06 6:08 PM EDT
**Evidence state:** primary HHS organization notice and independent AP reporting; division established, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The organization notice creates a government legal-services unit; staffing, full operation and the future of outside-counsel contracts remain unresolved.

## THE FACTS

- HHS published an organization notice on September 29 establishing the Unaccompanied Alien Children Legal Representation Division within the Office of General Counsel. The division is assigned legal orientation, advice, counsel and representation for unaccompanied children in federal immigration proceedings and related matters.
- The notice says the division will operate independently from the Office of Refugee Resettlement and Administration for Children and Families and will not advise those components in matters in which it represents a child. Organizational separation is stated; actual case-level independence and performance have not yet been measured.
- AP reported the notice on October 6 and quoted HHS describing the unit as another mechanism to help children reach safe reunification while receiving legal support. Advocates raised conflict-of-interest concerns because the lawyers would be government employees; those concerns are not findings that a conflict occurred.
- The notice establishes functions and reporting lines, but the inspected material does not establish when the unit will be fully staffed, how many children it will represent or whether existing nonprofit representation contracts will continue. It therefore supports creation of the division, not completed nationwide implementation or measured outcomes.

## SIGNIFICANCE

The federal government is moving representation for a vulnerable population partly inside the department that houses the custody program. The notice states an independence safeguard, while staffing, continuity and zealous-representation outcomes remain critical unresolved tests.

## GOALPOST / RESPONSE

HHS says the division adds legal support and can help safe reunification. Its caseload, staffing, funding, conflict-screening, outcomes and relationship to independent nonprofit counsel are the tests of that explanation.

## MAYBE / THEREFORE

Maybe an in-house division creates stable access and useful institutional capacity, or employment within HHS may create perceived or actual conflicts. Therefore HHS formally created the division and stated separation rules; the record does not yet establish full operation, diminished independence or improved case outcomes.


## SOURCES

- [HHS organization notice establishing Unaccompanied Alien Children Legal Representation Division](https://public-inspection.federalregister.gov/2026-19903.pdf) — primary Federal Register organization notice
- [AP — HHS creates government legal team for unaccompanied migrant children](https://apnews.com/article/migrant-children-attorneys-immigration-trump-representation-66f27919898d2c2bfa18279c1c85d8c3) — independent reporting and stakeholder response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
