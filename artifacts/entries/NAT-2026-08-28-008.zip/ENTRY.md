# California challenges $120 million federal offshore-wind lease buyout

**Entry ID:** NAT-2026-08-28-008
**Date:** April 27–August 28, 2026
**Checked:** 2026-08-28 6:08 PM EDT
**Evidence state:** California attorney general announcement describing the filed complaint and independent Reuters reporting with Interior's response; lawsuit filed, agreement challenged, merits and payment details unresolved
**Review state:** current-standard-reviewed

The complaint attacks Interior's agreement to cancel Golden State Wind's lease; the payment and legal claims have not been adjudicated.

## THE FACTS

- California's attorney general and Energy Commission sued the Interior Department and Golden State Wind over an April agreement canceling a federal offshore-wind lease in the Morro Bay Wind Energy Area.
- Golden State Wind had paid $120 million in a 2022 federal auction for the lease and planned a 2-gigawatt floating-wind project with more than $30 million in workforce, supply-chain, and community commitments. The cancellation agreement provides a $120 million federal reimbursement and requires investment in conventional-energy projects instead.
- The complaint alleges that the reimbursement is an unlawful use of federal funds, that the purported settlement was not tied to actual litigation, and that the agreement violates the Outer Continental Shelf Lands Act and Judgment Fund Act. These are plaintiff allegations; no court has invalidated the agreement or ordered repayment.
- Interior declined to discuss the litigation but told Reuters that Justice Department review approved the agreement and that it went through appropriate channels. Golden State Wind had not publicly responded by the checked time.

## SIGNIFICANCE

The suit tests whether the administration can use federal reimbursements and negotiated lease terminations to reverse offshore-wind development after auctions and state investments. Its outcome could affect other federal wind-lease buyouts and the reliability of federal energy-development commitments.

## GOALPOST / RESPONSE

Interior says the agreement was lawfully reviewed and has cited national-security and conventional-energy priorities for wind-lease cancellations. California says the deal spends federal money without a valid settlement basis and harms jobs, infrastructure planning, and clean-energy targets. The complaint, appropriation and Judgment Fund records, payment status, Interior's filing, discovery, and court rulings are the tests.

## MAYBE / THEREFORE

Maybe the government can establish lawful settlement and national-security authority for the cancellation, or the court may find the reimbursement and lease termination exceeded statutory limits. Therefore the record reports a filed state challenge to an executed agreement—not a ruling that the buyout was illegal, proof that every dollar was disbursed, or restoration of the wind lease.


## SOURCES

- [California Attorney General — lawsuit challenging Golden State Wind lease buyout](https://oag.ca.gov/news/press-releases/attorney-general-bonta-announces-lawsuit-challenging-unlawful-trump) — primary plaintiff announcement and complaint description; allegations not adjudicated
- [Reuters — California sues over offshore-wind lease cancellation](https://www.reuters.com/business/energy/california-sues-trump-administration-over-offshore-wind-lease-cancelation-2026-08-28/) — independent reporting on the complaint, $120 million agreement, and Interior response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
