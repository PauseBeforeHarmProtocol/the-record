# Seven states challenge $1.4 billion in federal offshore-wind buyouts

**Entry ID:** NAT-2026-08-28-008
**Date:** April 27–September 22, 2026
**Checked:** 2026-09-22 11:59 PM EDT
**Evidence state:** California attorney general announcement plus Reuters and Associated Press reporting on filed state litigation, named agreements, amounts and the administration response; lawsuits and challenged arrangements documented, merits, disbursement and energy outcomes unresolved
**Review state:** current-standard-reviewed

California and a New York-led coalition filed suits over the Invenergy and Bluepoint Wind arrangements; the states' statutory and cost allegations have not been adjudicated.

## THE FACTS

- California's attorney general and Energy Commission sued the Interior Department and Golden State Wind over an April agreement canceling a federal offshore-wind lease in the Morro Bay Wind Energy Area.
- Golden State Wind had paid $120 million in a 2022 federal auction for the lease and planned a 2-gigawatt floating-wind project with more than $30 million in workforce, supply-chain, and community commitments. The cancellation agreement provides a $120 million federal reimbursement and requires investment in conventional-energy projects instead.
- The complaint alleges that the reimbursement is an unlawful use of federal funds, that the purported settlement was not tied to actual litigation, and that the agreement violates the Outer Continental Shelf Lands Act and Judgment Fund Act. These are plaintiff allegations; no court has invalidated the agreement or ordered repayment.
- Interior declined to discuss the litigation but told Reuters that Justice Department review approved the agreement and that it went through appropriate channels. Golden State Wind had not publicly responded by the checked time.
- On September 22, New York led Connecticut, Delaware, Maine, Massachusetts, New Jersey, Rhode Island and Vermont in suits seeking to block the Invenergy arrangement and a separate Bluepoint Wind proposal. California separately sued over the Invenergy deal. Associated Press reported the filed actions and identified the participating states; the archive does not treat their legal allegations as adjudicated findings.
- Associated Press reported that the two arrangements would provide $1.4 billion in federal reimbursements in exchange for canceling multiple projects, within nearly $4 billion the administration had pledged for wind-project cancellations. Interior did not respond to the outlet's new requests but Secretary Doug Burgum previously said companies were shifting toward dependable, secure infrastructure that could lower utility costs. The reported totals do not establish that every dollar was disbursed or that either side's projected energy effects occurred.

## SIGNIFICANCE

The expanded litigation tests whether the administration can use federal reimbursements and negotiated lease terminations to reverse multiple offshore-wind projects after auctions and state investments. The challenged agreements involve $1.4 billion and sit within nearly $4 billion in announced cancellations, but no court has resolved legality, payment status or energy-price effects.

## GOALPOST / RESPONSE

Interior says the arrangements were lawfully reviewed and shift investment toward dependable energy infrastructure that can lower utility costs. The states allege unlawful federal spending and harm to grid and clean-energy plans. The complaints, appropriation and Judgment Fund records, payment status, federal responses, discovery, rulings, replacement investments and measured electricity and reliability effects are the tests.

## MAYBE / THEREFORE

Maybe the government can establish lawful settlement authority and demonstrate that replacement projects improve reliability and costs, or courts may find the reimbursements and cancellations exceeded statutory limits and impaired planned generation. Therefore California and a seven-state coalition filed challenges to two executed arrangements—not rulings that the deals are illegal, proof that all $1.4 billion was disbursed, restoration of any lease or a measured energy-price outcome.


## SOURCES

- [California Attorney General — lawsuit challenging Golden State Wind lease buyout](https://oag.ca.gov/news/press-releases/attorney-general-bonta-announces-lawsuit-challenging-unlawful-trump) — primary plaintiff announcement and complaint description; allegations not adjudicated
- [Reuters — California sues over offshore-wind lease cancellation](https://www.reuters.com/business/energy/california-sues-trump-administration-over-offshore-wind-lease-cancelation-2026-08-28/) — independent reporting on the complaint, $120 million agreement, and Interior response
- [Associated Press — California and New York-led coalition sue over offshore-wind buyouts](https://apnews.com/article/trump-offshore-wind-energy-fossil-fuels-e757e0492d91ac0dbb0d5992175a869a) — independent reporting on filed state lawsuits, challenged agreements, claimed amounts and the administration's stated energy rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
