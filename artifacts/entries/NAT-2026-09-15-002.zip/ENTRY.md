# OPM reopens employee-accountability proposal after data show no significant action increase

**Entry ID:** NAT-2026-09-15-002
**Date:** September 15, 2026
**Checked:** 2026-09-15 12:00 PM EDT
**Evidence state:** primary Federal Register proposal, reopened-comment notice and OPM EHRI tables; lifecycle remains proposed, fiscal 2026 data run only through June and important causal and coverage limits are explicit
**Review state:** current-standard-reviewed

The administration's own partial-year data found fiscal 2026 performance and adverse actions consistent with fiscal 2025; the rule remains proposed and comments now close September 29.

## THE FACTS

- OPM reopened for two weeks the comment period on its and the Merit Systems Protection Board's July 2 proposed employee-accountability rule. The reopened period is limited to newly released personnel data and an August 27 outside report; comments are due September 29, 2026, and no final rule was issued.
- The underlying proposal would revise procedures for performance-based reductions in grade and removals, nondisciplinary separations, adverse actions, MSPB review and supervisor training. The September notice supplies new support for parts 412, 432 and 752 but says neither agency relied on the data for the proposed changes to parts 715 and 1201.
- OPM reported that, despite major presidential policy changes, fiscal 2026 had not produced significant increases in covered performance-based and adverse actions through June and that the number and types appeared consistent with fiscal 2025. The table lists 3,105 covered actions excluding the disputed ZLM code through June 2026, compared with 3,492 for all of fiscal 2025; including ZLM, the figures are 3,572 and 4,160. Those partial- and full-year figures are not directly equivalent annual totals.
- The EHRI extract excludes several institutions and personnel groups, including USPS, intelligence agencies, the White House, State Department foreign service personnel and Census temporary workers. OPM also says ZLM-coded actions may or may not fall within the proposal's scope and therefore reports totals with and without them.
- OPM says deferred resignations, reductions in force, retirements and voluntary separations may affect the observed action counts. It nevertheless argues that presidential policy changed workplace culture and that the data and the We the Doers report support structural incentives for supervisors; the notice does not independently measure culture, employee performance, due process or service outcomes.

## SIGNIFICANCE

The notice supplies a rare administration-authored effectiveness check: the chosen disciplinary indicators had not significantly increased even after major policy changes. Reopening comments makes the evidence part of an active rulemaking, but the data do not establish whether unchanged action counts reflect stronger informal management, other separations, under-enforcement or a lack of need.

## GOALPOST / RESPONSE

OPM argues the proposal would reduce barriers and better incentivize supervisors while preserving appropriate process, and it treats the new data as support for structural change despite unchanged action levels. The tests are final text, MSPB and judicial review, comparable full-year actions, appeal outcomes, workforce composition, service performance, retention, due-process measures and public comments addressing the disclosed limitations.

## MAYBE / THEREFORE

Maybe policy changes improved accountability through channels the selected action codes do not capture, or other separation programs displaced formal removals. Therefore the evidence establishes a reopened proposal and OPM's partial-year finding of no significant increase in the covered actions—not a final rule, improved performance, weakened due process or a causal explanation for the counts.


## SOURCES

- [Federal Register — OPM employee-accountability data and reopened comment period](https://www.federalregister.gov/documents/2026/09/15/2026-18943/promoting-employee-accountability) — primary proposed-rule notice, agency-reported personnel data and comment reopening
- [Federal Register — Promoting Employee Accountability proposed rule](https://www.federalregister.gov/documents/2026/07/02/2026-13445/promoting-employee-accountability) — primary underlying proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
