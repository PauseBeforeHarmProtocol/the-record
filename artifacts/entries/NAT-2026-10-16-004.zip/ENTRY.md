# DOJ and Labor settle Cloudera PERM discrimination case with debarment and $2 million fund and penalty

**Entry ID:** NAT-2026-10-16-004
**Date:** October 16, 2026
**Checked:** 2026-10-16 11:59 PM EDT
**Evidence state:** executed DOJ/DOL/Cloudera agreement and primary agency release; obligations verified, allegations and agency reasonable-cause finding distinguished from adjudication, payments and outcomes pending
**Review state:** current-standard-reviewed

The executed resolution imposes a two-year PERM self-debarment, a $1.4 million conditional back-pay fund, a $600,000 civil penalty and three years of compliance duties; Cloudera denied discriminatory intent.

## THE FACTS

- DOJ, the Labor Department and Cloudera executed a coordinated settlement resolving DOJ investigations and an April 2026 administrative complaint alleging citizenship-status discrimination in recruitment for seven PERM positions.
- The agreement says investigators found reasonable cause to believe Cloudera departed from ordinary recruitment and used an email account that could not receive outside applications, preventing at least one U.S. worker from being considered. These are agency findings memorialized in a settlement, not adjudicated trial findings.
- Cloudera agreed to self-debar from new PERM filings and advertising for 24 months, withdraw affected pending applications, pay a $600,000 civil penalty and establish a $1.4 million back-pay fund for eligible claimants identified through DOJ's process.
- The three-year agreement also requires revised equal recruitment procedures, training, semiannual reporting, monitoring, an independent auditor if PERM activity resumes and steps to join the Defense Department's SkillBridge program.
- Cloudera maintained that it complied with the law, denied discriminatory intent and said it withdrew applications and corrected the email problem after notice. The parties entered the agreement voluntarily to resolve the dispute without further delay or expense.
- The payment and back-pay obligations have deadlines after the effective date; the agreement establishes enforceable obligations but does not prove that the full fund was distributed or that future recruitment outcomes improved by cutoff.

## SIGNIFICANCE

The resolution combines immigration-program debarment, monetary relief and continuing recruitment oversight in a nationally relevant employment-immigration enforcement action. Its practical effect will depend on payment, claimant identification, monitoring and post-debarment compliance.

## GOALPOST / RESPONSE

DOJ and Labor say the agreement protects U.S. workers and PERM integrity; Cloudera denies discriminatory intent and says it corrected an email failure. Executed payments, eligible claimants and distributions, application withdrawals, audit reports, compliance findings and later PERM filings are the tests.

## MAYBE / THEREFORE

Maybe the coordinated sanctions deter recruitment practices that exclude U.S. workers, or the case may principally reflect a correctable process failure without discriminatory intent. Therefore an executed settlement, debarment and payment obligations are established—not an adjudicated liability verdict, completed distribution or measured labor-market outcome.


## SOURCES

- [Justice Department — Cloudera PERM settlement, debarment and back-pay release](https://www.justice.gov/opa/pr/us-departments-justice-and-labor-secure-settlement-cloudera-enforce-two-year-perm-debarment) — primary agency release describing executed settlement
- [DOJ/DOL/Cloudera — executed settlement agreement](https://www.justice.gov/crt/media/1465571/dl) — primary settlement agreement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
