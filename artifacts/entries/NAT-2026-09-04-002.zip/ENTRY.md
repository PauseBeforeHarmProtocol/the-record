# EPA proposes ocean-discharge permit exclusion for vessels and floating craft

**Entry ID:** NAT-2026-09-04-002
**Date:** September 4, 2026
**Checked:** 2026-09-04 6:02 AM EDT
**Evidence state:** primary EPA proposal and current codified-regulation context; proposed for comment, no permitting change yet
**Review state:** current-standard-reviewed

The proposal would generally remove Clean Water Act NPDES permitting for pollutant additions from unsecured vessels in the contiguous zone and ocean; fixed seabed facilities would remain covered.

## THE FACTS

- EPA proposed September 4 to revise National Pollutant Discharge Elimination System definitions so pollutant additions from a vessel or floating craft not secured to the ocean floor would not require an NPDES permit when discharged in the contiguous zone or ocean.
- The proposal would not extend the exclusion to fixed platforms or other facilities secured to the seabed, and other federal or state requirements could still apply. Comments are due October 19, 2026; no exclusion is operative yet.
- EPA estimated about $1.8 million in total compliance-cost savings. The agency also acknowledged foregone benefits, including less management of localized discharges from seafood-processing vessels, possible effects on marine and receiving waters, and reduced monitoring, reporting and public information.
- EPA said the revision would clarify its jurisdiction and reduce burdens by aligning the regulation with the agency's reading of the Clean Water Act. The proposal does not measure current pollution loads or predict a quantified environmental effect.

## SIGNIFICANCE

The proposal would narrow a federal water-pollution permitting boundary for mobile offshore operations. It could remove duplicative or low-value paperwork, but it could also reduce enforceable controls and public data for concentrated discharges in marine waters.

## GOALPOST / RESPONSE

EPA says the exclusion would provide clarity and cost savings while leaving fixed facilities and other legal authorities intact. The final rule, comment record, affected-vessel count, discharge monitoring, water-quality data, enforcement activity, state responses and judicial review are the tests.

## MAYBE / THEREFORE

Maybe mobile ocean discharges are already better governed by other legal regimes and do not justify NPDES permits, or the exclusion may create avoidable monitoring and accountability gaps near sensitive waters. Therefore the record establishes a proposed jurisdictional and permitting change—not a final exemption, verified savings or measured environmental harm.


## SOURCES

- [EPA — proposed NPDES definitions and exclusions update](https://www.federalregister.gov/documents/2026/09/04/2026-18134/updates-to-the-national-pollutant-discharge-elimination-system-definitions-and-exclusions) — primary proposed rule on Clean Water Act permitting for vessel and floating-craft discharges in ocean waters
- [eCFR — current NPDES program definitions and permit requirements](https://www.ecfr.gov/current/title-40/chapter-I/subchapter-D/part-122) — primary codified-regulation context for the EPA proposal

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
