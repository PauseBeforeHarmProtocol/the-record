# G20 ministers adopt Carolina Principles and six-pillar innovation statement

**Entry ID:** NAT-2026-09-01-005
**Date:** September 1–2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** primary White House announcement of the G20 ministerial consensus plus Reuters reporting on the joint statement and copyright proposal; framework adopted at ministerial level, domestic implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The U.S.-hosted ministerial converted an American proposal into a nonbinding consensus framework; it did not enact domestic AI or copyright law.

## THE FACTS

- At a G20 technology meeting in Chapel Hill, North Carolina, the United States pressed member governments to avoid new artificial-intelligence rules and new international oversight bodies.
- White House technology adviser Michael Kratsios asked countries to adopt the Carolina Principles, under which signatories would reserve new regulation for novel considerations, invest in foundational research and strengthen commercial opportunities for emerging technology.
- Kratsios said policymakers should not treat every emerging technology as a first-of-its-kind policy problem. A White House official said the United States would oppose creating new organizations to oversee AI development.
- Canada said its delegation would advocate balancing innovation with public trust and safety. The meeting precedes the December G20 leaders' summit and included major U.S. technology executives.
- No list of signatories, final G20 text, binding commitment, U.S. regulation, repeal or measured innovation or safety outcome was public by cutoff.
- At the close of the September 2 ministerial, participating G20 ministers released a consensus statement across six pillars: pro-innovation policy frameworks; technology for opportunity and prosperity; technical-workforce development; intellectual-property policy for AI; AI-related standards; and industrial innovation and supply-chain investment.
- The ministers also reached consensus on the Carolina Principles for Emerging Technologies. Reuters reported that the joint statement says new AI-specific rules should address novel considerations not already covered by existing law and that China was among the participating governments endorsing the text.
- Commerce Secretary Howard Lutnick separately urged a framework that permits AI training under fair-use principles while protecting creators, without specifying how competing rights would be adjudicated. The consensus statement is a ministerial political commitment, not a treaty, binding G20 law, a domestic copyright amendment or a judicial fair-use ruling.

## SIGNIFICANCE

Consensus advances the administration's light-touch AI preference from a U.S. request to a shared G20 ministerial framework, including intellectual-property and commercialization principles. The political signal may influence national policy, but the statement is not a treaty, regulation or court interpretation and its practical effect depends on implementation in each jurisdiction.

## GOALPOST / RESPONSE

The administration says flexible, research-oriented governance and fair-use-compatible intellectual-property frameworks will protect creators while accelerating innovation and commercial opportunity. The strongest response is that the statement leaves key terms and enforcement unspecified and may privilege incumbent AI developers before safety and creator-compensation disputes are resolved. National laws, copyright rulings, licensing practices, safety standards, investment, market access and documented harms are the tests.

## MAYBE / THEREFORE

Maybe the consensus will create durable common ground for research, commercialization and targeted AI safeguards, or broad language about innovation and fair use may mask continuing disagreement over safety, competition and creator rights. Therefore the record treats the ministerial statement as an adopted but nonbinding international policy framework—not a G20 treaty, a change to U.S. copyright law or proof of improved innovation or safety outcomes.


## SOURCES

- [Reuters — United States presses G20 on the Carolina Principles for AI](https://www.reuters.com/legal/litigation/us-urge-hands-off-ai-regulation-g-20-official-says-2026-09-01/) — independent reporting from the G20 technology meeting documenting the U.S. proposal, Michael Kratsios's remarks and a Canadian response
- [White House — G20 Innovation Ministerial consensus statement announcement](https://www.whitehouse.gov/releases/2026/09/g20-innovation-ministerial-concludes-with-consensus-statement/) — primary U.S. announcement that participating ministers released a six-pillar consensus statement and agreed to the Carolina Principles
- [Reuters — G20 nations endorse Carolina Principles and AI copyright framework](https://www.reuters.com/business/media-telecom/nvidia-ceo-urges-g20-avoid-ai-rules-theoretical-harms-2026-09-02/) — independent reporting on the joint statement, the fair-use proposal and China's participation in the ministerial consensus

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
