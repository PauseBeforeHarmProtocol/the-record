# United States presses G20 members to adopt light-touch AI principles

**Entry ID:** NAT-2026-09-01-005
**Date:** September 1, 2026
**Checked:** 2026-09-01 12:03 PM EDT
**Evidence state:** independent on-site Reuters reporting documenting Michael Kratsios's remarks, the proposed principles, the White House position and a Canadian response; proposal presented, adoption and effects unresolved
**Review state:** current-standard-reviewed

The Carolina Principles are a formal U.S. negotiating proposal at the G20 technology meeting—not an adopted international agreement or domestic rule.

## THE FACTS

- At a G20 technology meeting in Chapel Hill, North Carolina, the United States pressed member governments to avoid new artificial-intelligence rules and new international oversight bodies.
- White House technology adviser Michael Kratsios asked countries to adopt the Carolina Principles, under which signatories would reserve new regulation for novel considerations, invest in foundational research and strengthen commercial opportunities for emerging technology.
- Kratsios said policymakers should not treat every emerging technology as a first-of-its-kind policy problem. A White House official said the United States would oppose creating new organizations to oversee AI development.
- Canada said its delegation would advocate balancing innovation with public trust and safety. The meeting precedes the December G20 leaders' summit and included major U.S. technology executives.
- No list of signatories, final G20 text, binding commitment, U.S. regulation, repeal or measured innovation or safety outcome was public by cutoff.

## SIGNIFICANCE

The proposal makes regulatory restraint an explicit U.S. objective in international AI diplomacy, potentially shaping how allied markets govern powerful systems and how U.S. firms compete abroad. Its effect depends on adoption, final language and whether safety, competition and accountability mechanisms accompany the pro-innovation framework.

## GOALPOST / RESPONSE

The administration says flexible, research-oriented governance will accelerate discovery and keep countries in the American technology ecosystem. The strongest counterargument is that minimizing new oversight before risks are understood may leave public-safety and accountability gaps while benefiting incumbent firms. Signatories, final G20 language, enacted national rules, safety requirements, market outcomes and documented incidents are the tests.

## MAYBE / THEREFORE

Maybe the principles will prevent duplicative regulation while supporting research and interoperable markets, or they may discourage safeguards that prove necessary as AI capabilities advance. Therefore the record confirms a formal U.S. proposal presented to G20 officials—not G20 adoption, binding international law, domestic deregulation or evidence that lighter rules are safer or more innovative.


## SOURCES

- [Reuters — United States presses G20 on the Carolina Principles for AI](https://www.reuters.com/legal/litigation/us-urge-hands-off-ai-regulation-g-20-official-says-2026-09-01/) — independent reporting from the G20 technology meeting documenting the U.S. proposal, Michael Kratsios's remarks and a Canadian response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
