# State Department reports more than 300,000 visa revocations

**Entry ID:** NAT-2026-10-20-005
**Date:** October 20, 2026
**Checked:** 2026-10-21 12:03 AM EDT
**Evidence state:** primary State Department spokesperson statement with independent Reuters reporting; aggregate is agency-reported, not independently audited or case-level verified
**Review state:** current-standard-reviewed

The department reported a sharply higher second-term total, but did not publish a case-level breakdown or independent audit of the figure.

## THE FACTS

- State Department spokesperson Tommy Pigott said the Trump administration had revoked more than 300,000 visas during its second term and characterized the pace as faster than under any prior administration. The post is primary evidence of the department’s reported total, not an independent audit of each revocation.
- Reuters independently reported the announcement and compared it with the department’s August 10 figure of more than 175,000 revocations, indicating a substantial increase in the agency-reported total over roughly ten weeks. Reuters reported that the administration cited national security, legal violations and fraud while critics raised due-process and free-speech concerns.
- A visa revocation is an administrative change to permission to travel or remain under a visa; it is not by itself a criminal conviction, deportation order or finding that every affected person committed misconduct. The inspected material did not provide a case-level dataset, category totals, reinstatement count or adjudicated error rate.

## SIGNIFICANCE

The reported scale marks a major implementation measure in the administration’s legal-immigration crackdown and could affect travel, study, employment and family separation for a large population. Its legal and practical significance depends on the grounds, notice, review process and error rate behind the aggregate.

## GOALPOST / RESPONSE

The State Department says the faster pace reflects zero tolerance for visa holders who violate U.S. law, threaten security or commit fraud. The tests are a reproducible category breakdown, lawful notice and review, court outcomes, reinstatements, independently audited totals and evidence connecting revocations to stated security or integrity goals.

## MAYBE / THEREFORE

Maybe the accelerated reviews removed visas that should not remain valid and strengthened screening, or a high-volume process may also produce overbroad, speech-linked or erroneous revocations. Therefore the record establishes an agency-reported total above 300,000 and an increase from the August benchmark—not the validity of every case or a measured security benefit.


## SOURCES

- [State Department spokesperson — more than 300,000 visas revoked](https://x.com/statedeptspox/status/2112538966150791298) — primary agency statement reporting an administration-wide visa-revocation total
- [Reuters — Trump administration says it has revoked over 300,000 visas](https://www.reuters.com/legal/government/trump-administration-says-it-has-revoked-over-300000-visas-2026-10-20/) — independent reporting on the agency-reported total, prior benchmark, stated rationale and civil-liberties criticism

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
