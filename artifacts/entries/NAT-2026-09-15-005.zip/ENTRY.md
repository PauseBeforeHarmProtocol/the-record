# Bank regulators propose replacing third-party risk guidance with a more tailored standard

**Entry ID:** NAT-2026-09-15-005
**Date:** September 11–15, 2026
**Checked:** 2026-09-15 12:00 PM EDT
**Evidence state:** primary Federal Register proposed interagency guidance, parallel community-bank proposal and an on-record Federal Reserve dissent; lifecycle remains proposed and outcome claims are prospective
**Review state:** current-standard-reviewed

The proposal would replace 2023 guidance and related resources, remains nonbinding and open for comment through November 16; Governor Michael Barr dissented on safety-and-soundness grounds.

## THE FACTS

- The OCC, Federal Reserve Board, FDIC and NCUA jointly proposed guidance that would replace the 2023 interagency third-party risk-management guidance and supplemental resources if finalized. Federal Register publication opened comments through November 16, 2026; no final guidance or rescission has occurred.
- The proposal emphasizes tailoring oversight to each relationship's reasonably assessed risk, the banking organization's size and complexity, legal compliance and material financial risk. It says the change would promote consistency and fintech innovation under Executive Order 14405 and is expected to be deregulatory under Executive Order 14192.
- The proposed text retains banks' responsibility to operate safely and comply with law even when using affiliates, service providers or subcontractors. It presents risk identification, proportionate oversight, residual-risk acceptance and governance as components rather than a single prescribed process.
- The agencies say the guidance would not create enforceable standards and that deviation from it alone would not support supervisory action. They reserve action for legal violations, unsafe or unsound practices and other material risks caused by insufficient third-party management.
- Federal Reserve Governor Michael Barr dissented. He said a material-financial-risk threshold and language giving due consideration to banks' reasonable decisions could delay correction or be read as deference, and warned that excluding consumer compliance and complex bank-fintech partnerships could create gaps or conflicting guidance.

## SIGNIFICANCE

Third parties carry cybersecurity, compliance, operational and consumer risks across banks and credit unions, while fintech partnerships can expand access and competition. Replacing the existing framework could reduce compliance burden and encourage innovation, but the practical balance between tailoring and earlier supervisory intervention remains unresolved.

## GOALPOST / RESPONSE

The participating agencies say risk-based tailoring will improve allocation, clarity and innovation without relieving banks of legal or safety responsibilities. Barr says the proposal may increase risk, confusion and supervisory gaps. The tests are final language, retained or rescinded consumer guidance, examination practice, enforcement timing, bank-fintech failures, access, costs and measured operational and consumer outcomes.

## MAYBE / THEREFORE

Maybe a less prescriptive framework focuses scarce compliance resources on the highest-risk relationships, or it may weaken preventive oversight before problems become material. Therefore the agencies have proposed—not finalized—replacement guidance, and neither efficiency gains nor the dissent's predicted harms are established outcomes.


## SOURCES

- [Federal Register — proposed third-party risk-management guidance](https://www.federalregister.gov/documents/2026/09/15/2026-18859/proposed-third-party-risk-management-guidance) — primary proposed interagency supervisory guidance and request for comment
- [Federal Register — proposed third-party risk-management guide for traditional community banks](https://www.federalregister.gov/documents/2026/09/15/2026-18852/proposed-third-party-risk-management-guide-for-traditional-community-banking-organizations) — primary proposed supervisory guide and request for comment
- [Federal Reserve Board — Governor Michael Barr dissent on third-party risk proposals](https://www.federalreserve.gov/newsevents/pressreleases/barr-statement-20260911a.htm) — primary on-record dissent and risk assessment

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
