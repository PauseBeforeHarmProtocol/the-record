# NTSB details failed Marine One coordination before simultaneous airport departure

**Entry ID:** NAT-2026-08-27-010
**Date:** August 4 and 27, 2026
**Checked:** 2026-08-27 6:00 PM EDT
**Evidence state:** NTSB preliminary report and independent Reuters reporting; communications failure and FAA corrective action documented, probable cause and final proximity pending
**Review state:** current-standard-reviewed

The preliminary report says radio coverage prevented the required three-minute call before Marine One and an Envoy jet became airborne; the FAA relocated equipment and the investigation remains open.

## THE FACTS

- The National Transportation Safety Board’s preliminary report says Marine One, carrying President Trump, and Envoy Air Flight 3742 were involved in a loss-of-separation event near Reagan National Airport on August 4. No injuries or aircraft damage were reported, and both flights continued without further incident.
- Marine One’s first attempt to contact the tower was not received and its second was unreadable because federal technicians later found inadequate radio line of sight between the temporary Ellipse operating site and the helicopter frequency. Attempts to relay the required three-minute departure notice through Joint Base Anacostia-Bolling also failed, and Marine One departed before the tower received the notice; a controller unaware of the departure had cleared the Envoy jet for takeoff.
- The FAA’s preliminary closest-proximity estimate was 0.82 nautical mile laterally and 700 feet vertically. Although the lateral distance was below 1.5 nautical miles, the NTSB says the 700-foot vertical distance met the applicable minimum because the rule requires either 1.5 nautical miles lateral or 500 feet vertical separation. The Envoy crew received a traffic advisory but no resolution command.
- FAA technicians relocated the helicopter-frequency radios to the airport control tower, and subsequent tests reported no communication deficiencies. The NTSB’s investigation and its own calculation of the closest proximity remain ongoing, so the report does not assign probable cause or a final safety finding.

## SIGNIFICANCE

The report documents a breakdown in required coordination around presidential air transport at an airport already subject to heightened helicopter restrictions after the fatal January 2025 collision. It also records a concrete corrective action while preserving that the measured vertical separation met the cited minimum and that final cause remains unsettled.

## GOALPOST / RESPONSE

The FAA’s response is that relocating the antenna and changing procedures resolved the communication problem; the preliminary report confirms successful post-move checks. The accountability test is whether the final investigation identifies system, equipment, crew, or procedural causes and whether corrective measures prevent recurrence. Final proximity calculations, probable cause, safety recommendations, radio-performance data, and later incidents are the tests.

## MAYBE / THEREFORE

Maybe the equipment move fully fixes a localized line-of-sight problem, or the prior reports of spotty communication point to a broader coordination risk. Therefore the record reports a preliminary communications failure and simultaneous departures without calling it a collision, an injury event, a violation of the cited radar minimum, or a final finding of crew fault.


## SOURCES

- [NTSB — preliminary report OPS26LA063 on Marine One and Envoy loss-of-separation event](https://www.ntsb.gov/investigations/Documents/Prelim%20OPS26LA063.pdf) — primary preliminary aviation investigation report
- [Reuters — NTSB details Marine One communication failure and FAA response](https://www.reuters.com/world/us/ntsb-says-marine-one-helicopter-crew-failed-reach-air-traffic-control-before-2026-08-27/) — independent reporting on preliminary findings, aircraft proximity, and corrective action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
