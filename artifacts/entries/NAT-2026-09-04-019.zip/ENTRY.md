# CDC consolidates influenza and other respiratory-virus operations

**Entry ID:** NAT-2026-09-04-019
**Date:** September 4–9, 2026
**Checked:** 2026-09-09 12:01 PM EDT
**Evidence state:** primary CDC Federal Register organizational notice; HHS approval and September 4 effective reorganization documented, resource and performance consequences not reported
**Review state:** current-standard-reviewed

The HHS-approved reorganization became effective September 4; the notice establishes a new division structure but reports no staffing, funding or performance result.

## THE FACTS

- CDC published notice that HHS approved a reorganization of the National Center for Immunization and Respiratory Diseases on August 18 and made it effective September 4, 2026. The agency consolidated offices, retitled divisions and branches, and revised mission and function statements.
- The reorganization merges the Influenza Division with the Coronavirus and Other Respiratory Diseases Division into a new Influenza and Respiratory Viruses Division. The new division contains offices or branches for laboratory surveillance, respiratory-virus detection and immunology, surveillance and modeling, public-health interventions, and emerging viral respiratory threats.
- CDC assigns the division responsibilities covering disease surveillance and response, virus characterization and diagnostics, vaccine-virus and countermeasure work, prevention strategies, pandemic preparedness, communications, informatics, laboratory quality and partnerships with health departments and international organizations.
- The notice documents an effective organizational change, but it does not state how many positions, laboratories or contracts moved; identify appropriations; report layoffs or closures; or measure surveillance, vaccine, outbreak-response or preparedness outcomes.

## SIGNIFICANCE

Combining influenza, coronavirus and other respiratory-virus work changes the formal organization responsible for national surveillance, laboratory science, countermeasures and pandemic preparedness. Whether consolidation improves coordination or reduces specialized capacity depends on staffing, budgets, operating plans and measured response performance not disclosed in the notice.

## GOALPOST / RESPONSE

CDC describes the reorganization as a structure for integrated respiratory-virus prevention, detection and response. The tests are published organization charts and delegations, retained expertise and laboratory capacity, surveillance timeliness and completeness, outbreak response, vaccine and diagnostic work, budgets, staffing and external public-health-partner assessments.

## MAYBE / THEREFORE

Maybe consolidation reduces silos and improves coordinated respiratory-threat work, or it may obscure program-specific capacity and accountability if resources or expertise shrink. Therefore CDC implemented a formal structural merger with stated functions—not a documented funding cut, workforce reduction or demonstrated improvement in public-health performance.


## SOURCES

- [Federal Register — reorganization of the National Center for Immunization and Respiratory Diseases](https://www.federalregister.gov/documents/2026/09/09/2026-18263/reorganization-of-the-national-center-for-immunization-and-respiratory-diseases) — primary organizational notice documenting an August 18 approval and September 4 effective reorganization

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
