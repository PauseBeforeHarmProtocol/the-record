# Treasury and State designate three Guatemalan trafficking groups

**Entry ID:** NAT-2026-11-13-010
**Date:** November 13, 2026
**Checked:** 2026-11-14 12:08 AM EST
**Evidence state:** Primary Treasury and OFAC designation records plus Associated Press reporting; legal designations implemented, underlying conduct attributed and operational effects not measured
**Review state:** current-standard-reviewed

OFAC blocked Los Mendoza and Los Huistas under counter-narcotics and counter-terrorism authorities while State designated Los Lorenzanas as a foreign terrorist organization and global terrorist; the conduct allegations remain attributed to the government.

## THE FACTS

- Treasury's Office of Foreign Assets Control designated the Los Mendoza Drug Trafficking Organization and Los Huistas Drug Trafficking Organization, while the State Department concurrently designated Los Lorenzanas as a Foreign Terrorist Organization under section 219 of the Immigration and Nationality Act and as a Specially Designated Global Terrorist under Executive Order 13224.
- OFAC designated Los Mendoza under Executive Orders 14059 and 13224 for providing material support to the Sinaloa Cartel, and designated Los Huistas under Executive Order 13224 for providing material support to the Sinaloa Cartel and Cartel de Jalisco Nueva Generacion. The target-level designations were added to OFAC's public notice.
- Treasury alleged that the two organizations control trafficking corridors along Guatemala's borders with Honduras and Mexico and facilitate receipt, storage, protection and movement of narcotics. These conduct descriptions are government allegations supporting the designations, not criminal convictions established by the inspected announcement.
- The OFAC action blocks property and interests in property of the designated persons within the United States or U.S. persons' possession or control, applies the 50-percent ownership rule to covered entities and generally prohibits U.S.-nexus transactions absent authorization or exemption.
- Treasury said the action targets logistical networks supporting Mexican cartels and the flow of narcotics into the United States. The public material did not quantify assets blocked, prosecutions produced, trafficking disrupted or fentanyl supply reduced by the new designations.

## SIGNIFICANCE

The coordinated action imposes immediate financial restrictions and, for Los Lorenzanas, a foreign-terrorist legal status that can support material-support prosecutions. It also expands the administration's use of terrorism authorities against Latin American trafficking organizations, while operational effectiveness remains unmeasured.

## GOALPOST / RESPONSE

The administration can demonstrate results through identified and frozen assets, licenses and enforcement actions, prosecutions tied to the designations, partner-government cooperation, network disruption and independently measured changes in trafficking or drug supply. Allegations in the designation record should remain distinct from adjudicated guilt.

## MAYBE / THEREFORE

Maybe the combined terrorism and financial authorities will materially constrain cartel logistics, or the groups may shift routes and financial intermediaries while public asset effects remain small. Therefore the record establishes implemented legal designations and blocking rules—not adjudicated criminal liability or measured reductions in trafficking, violence or drug availability.


## SOURCES

- [Treasury — sanctions Guatemalan trafficking organizations supporting Mexican cartels](https://home.treasury.gov/news/press-releases/sb0689) — primary sanctions announcement stating targets, legal authorities, concurrent State action and blocking consequences; conduct allegations remain attributed
- [OFAC — counter-narcotics and counter-terrorism designations](https://ofac.treasury.gov/recent-actions/20261113) — primary target-level designation notice for Los Lorenzanas, Los Mendoza and Los Huistas
- [Associated Press — United States designates three Guatemalan groups and imposes sanctions](https://apnews.com/article/5036440b50789cec893916478bc45471) — independent reporting on the implemented designations and legal consequences while attributing government allegations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
