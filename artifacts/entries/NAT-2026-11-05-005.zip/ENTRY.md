# Treasury and IRS designate 6,576 next-generation Opportunity Zones

**Entry ID:** NAT-2026-11-05-005
**Date:** November 5, 2026
**Checked:** 2026-11-06 6:10 AM EST
**Evidence state:** primary IRS and Treasury designation announcements plus independent Bloomberg Government reporting; formal geography and future effective date established, investment and outcome claims unmeasured
**Review state:** current-standard-reviewed

The formal nationwide designations include 2,594 rural tracts and take effect January 1, 2027 for ten years; future investment and community outcomes are not yet measured.

## THE FACTS

- Treasury and the Internal Revenue Service formally announced 6,576 census-tract designations for the next generation of Qualified Opportunity Zones across all 50 states, the District of Columbia and five U.S. territories.
- IRS said 2,594 of the designated tracts are rural. The designations take effect January 1, 2027 and remain in effect for ten years under the recurring framework enacted in the 2025 tax law.
- The administration said governors submitted nominated tracts and presented the program as a way to attract private capital to underserved communities. Bloomberg Government independently reported the designation announcement and future effective date.
- The announcement establishes the eligible geography and timetable; it does not itself establish how much capital will be invested, who will benefit, the fiscal cost, or measured changes in jobs, housing, displacement or poverty.

## SIGNIFICANCE

The designations set the national geography for a decade-long federal capital-gains tax incentive and can shape where subsidized investment flows beginning in 2027. The material action is the formal tract selection, not a claim that investment or community outcomes have already occurred.

## GOALPOST / RESPONSE

Treasury says the redesigned program will drive long-term investment and opportunity in underserved communities, with enhanced rural incentives. The tests are final implementing guidance, investment and tax-expenditure data, rural participation, job and business formation, housing and displacement measures, and geographically matched community outcomes.

## MAYBE / THEREFORE

Maybe the selected tracts will attract durable investment that reaches residents, or benefits may be concentrated among investors and projects with limited local gains. Therefore the federal government has formally selected 6,576 eligible tracts with a 2027 effective date—not demonstrated the program's cost or effectiveness.


## SOURCES

- [IRS — Treasury and IRS announce 6,576 Opportunity Zone designations](https://www.irs.gov/newsroom/treasury-irs-announce-opportunity-zones-designations-for-over-6500-communities-across-america) — primary federal announcement listing the designation count, rural count, nationwide scope and 2027 effective date
- [Treasury — new Qualified Opportunity Zone designations](https://home.treasury.gov/news/press-releases/sb0682/) — primary department release on the formal decennial Opportunity Zone designations and administration rationale
- [Bloomberg Government — Treasury and IRS announce more than 6,500 Opportunity Zone areas](https://news.bloomberglaw.com/bloomberg-government-news/treasury-irs-announce-over-6-500-new-opportunity-zone-areas) — independent reporting on the new designations and future effective date

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
