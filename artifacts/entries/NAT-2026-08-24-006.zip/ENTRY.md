# Senators seek declassification of Saudi civil-nuclear agreement and side letters

**Entry ID:** NAT-2026-08-24-006
**Date:** August 24–September 16, 2026
**Checked:** 2026-09-16 5:58 PM EDT
**Evidence state:** Energy Department record, prior AP and Wall Street Journal confirmation and Reuters's inspection of the bipartisan disclosure letter; review and oversight actions established, classified terms and implementation unverified
**Review state:** current-standard-reviewed

The bipartisan request highlights undisclosed terms during the statutory review; it does not itself declassify the pact, block it or resolve enrichment and normalization conditions.

## THE FACTS

- The Trump administration transmitted the signed U.S.–Saudi civil nuclear cooperation agreement to Congress on August 24, starting the section 123 review period. The Energy Department says the agreement enables U.S. participation while maintaining required nuclear-safety, security and nonproliferation standards.
- Reuters reported on September 16 that a bipartisan group of 18 senators asked the State and Energy departments to declassify and release the full agreement, two classified side letters and related documents. The letter was led by Senators Jeff Merkley and Ed Markey and included Republicans Rand Paul and John Kennedy.
- The senators argued that Congress and the public need the complete text to understand mutual commitments. Their letter is a formal oversight request; it did not declassify any document, amend the pact, extend the review period or enact a resolution of disapproval.
- Reuters reported that the 30-year proposal calls for AP1000 reactors in a project worth tens of billions of dollars. Critics say the publicly described arrangement does not bar Saudi uranium enrichment or spent-fuel reprocessing; the administration says it includes nonproliferation measures required by law.
- Trump has separately said the deal takes effect only if Saudi Arabia normalizes relations with Israel, while congressional aides told Reuters the pact itself does not address that condition. State and Energy had not responded to the disclosure request by cutoff, and the classified terms remained unavailable for independent review.

## SIGNIFICANCE

The bipartisan disclosure request sharpens congressional scrutiny of a long-term nuclear-commerce pact whose key safeguards and side commitments remain classified during a time-limited review. It increases transparency pressure without changing the agreement's legal status or proving that critics' or the administration's descriptions are complete.

## GOALPOST / RESPONSE

The administration says the agreement supports U.S. exports, jobs, bilateral ties and legally required nonproliferation measures; senators and advocates seek the full text and stronger limits on enrichment and reprocessing. The tests are declassification, committee access and analysis, any resolution of disapproval, Saudi safeguards, export authorizations, reactor contracts and the legal treatment of normalization.

## MAYBE / THEREFORE

Maybe classified handling protects sensitive diplomatic terms while Congress receives enough information to test them, or hidden side commitments may conceal material proliferation, commercial or normalization conditions from public scrutiny. Therefore the record confirms transmission and a bipartisan declassification request—not public disclosure, congressional rejection, effective export authorization, reactor construction or permission to enrich uranium.


## SOURCES

- [Department of Energy — United States and Saudi Arabia reach civil nuclear cooperation agreement](https://www.energy.gov/articles/united-states-and-saudi-arabia-reach-historic-nuclear-cooperation-agreement) — primary administration announcement of the signed section 123 agreement and stated safeguards rationale
- [The Wall Street Journal — Trump sends Saudi nuclear agreement to Congress](https://www.wsj.com/world/middle-east/trump-sends-nuclear-agreement-with-saudi-arabia-to-congress-7f01af2c) — independent reporting on formal congressional transmission, agreement structure, and proliferation dispute
- [Associated Press — Trump submits Saudi civil-nuclear agreement for congressional review](https://apnews.com/article/2be6c822995be2a9f2a39b2c05e8f9b0) — independent reporting based on separate administration and congressional sourcing, with statutory-review context
- [Reuters — bipartisan senators seek Saudi nuclear agreement disclosure](https://www.reuters.com/legal/government/us-senators-seek-more-information-trumps-saudi-nuclear-proposal-letter-says-2026-09-16/) — independent reporting based on direct inspection of the senators' letter and the pending section 123 review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
