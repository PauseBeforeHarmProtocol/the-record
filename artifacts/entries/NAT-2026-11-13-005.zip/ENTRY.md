# Trump publicly backs pending bipartisan film and television tax-credit bills

**Entry ID:** NAT-2026-11-13-005
**Date:** November 13, 2026
**Checked:** 2026-11-13 6:03 PM EST
**Evidence state:** Trump publication record plus GovInfo introduced-bill text/status and the lead sponsor's release; presidential endorsement announced, legislation pending and outcome claims unmeasured
**Review state:** current-standard-reviewed

Trump urged passage of the Motion Picture, Television, and Entertainment Revitalization Act and described active bipartisan meetings; the Senate and House bills were introduced September 24 and remain proposals.

## THE FACTS

- At 5:52:34 p.m. EST on November 13, Trump published a Truth Social statement saying he was working with named lawmakers on the Motion Picture, Television, and Entertainment Revitalization Act, that meetings were being arranged with both parties' leaders and that he wanted the legislation finalized. The post is primary evidence of his endorsement, not independent verification of its economic claims.
- S. 5552 was introduced September 24 by Senators Tim Scott, Adam Schiff, John Cornyn and Raphael Warnock and referred to the Senate Finance Committee. A House companion, H.R. 10582, was also introduced; neither inspected record established passage or enactment.
- The Senate bill would create a 20% base federal tax credit on qualifying U.S. compensation for eligible commercial film and television productions, with specified bonuses capped at a 30% total rate. A production generally must cost more than $1 million and have at least 75% of principal-photography days in the United States.
- The bill excludes specified programming and uses additional rules for animation, independent producers, multi-state production and increased domestic production. The sponsor release frames the proposal as a jobs and competitiveness measure supported by industry groups and labor organizations.
- Trump asserted that tax-incentive costs would be recovered tenfold and that hundreds of thousands of workers would benefit. No independent cost estimate, revenue score or measured outcome substantiating those figures was located in the material reviewed by cutoff.

## SIGNIFICANCE

The statement makes presidential support for a specific bipartisan, bicameral tax-credit proposal current and explicit, increasing its political salience. It does not change the bills' pending legislative status or establish their fiscal or employment effects.

## GOALPOST / RESPONSE

The proposal should be evaluated through committee action, a Congressional Budget Office or Joint Committee on Taxation score, enacted eligibility rules, forgone revenue, domestic production and employment changes, distribution across firms and regions, and evidence separating shifted activity from net new activity.

## MAYBE / THEREFORE

Maybe a federal credit would retain production and skilled jobs that otherwise move abroad, or it may subsidize activity that would occur anyway while shifting costs to taxpayers. Therefore the record establishes Trump's endorsement of already-introduced bills and their operative proposal terms—not passage, enactment, a tenfold return or a measured jobs result.


## SOURCES

- [Donald Trump Truth Social statement supporting the Motion Picture, Television, and Entertainment Revitalization Act](https://truthsocial.com/@realDonaldTrump/117611584206041319) — primary evidence that Trump published the endorsement and described ongoing meetings; not independent verification of claims inside the post
- [GovInfo — S. 5552, Motion Picture, Television, and Entertainment Revitalization Act](https://www.govinfo.gov/content/pkg/BILLS-119s5552is/html/BILLS-119s5552is.htm) — primary introduced-bill text and legislative-status record
- [GovInfo — H.R. 10582, Motion Picture, Television, and Entertainment Revitalization Act](https://www.govinfo.gov/app/details/BILLS-119hr10582ih) — primary House introduced-bill record
- [Senator Tim Scott — bipartisan film and television production-credit legislation introduced](https://www.scott.senate.gov/media-center/press-releases/sens-scott-schiff-and-colleagues-introduce-legislation-to-revitalize-film-and-television-production-in-the-u-s/) — primary sponsor release describing the introduced Senate and House bills and sponsors' policy rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
