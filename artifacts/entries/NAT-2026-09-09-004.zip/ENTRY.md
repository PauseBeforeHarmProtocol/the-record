# Salvadoran TPS protections continue temporarily while DHS postpones a final decision

**Entry ID:** NAT-2026-09-09-004
**Date:** September 9, 2026
**Checked:** 2026-09-10 12:02 AM EDT
**Evidence state:** Reuters and Associated Press reporting quoting DHS and explaining the statutory continuation; temporary protection continues, final DHS determination and longer-term consequences pending
**Review state:** current-standard-reviewed

DHS said current beneficiaries retain protection until its announcement; AP reported that statutory inaction produces a six-month extension.

## THE FACTS

- El Salvador's Temporary Protected Status designation had been scheduled to expire September 9. DHS told Reuters and Associated Press that it would announce a decision at an appropriate time and that Salvadoran beneficiaries would retain protection until then; it gave no decision date.
- Associated Press reported that when DHS takes no action, the TPS statute automatically extends protections for six months. The continuation preserves temporary protection from removal and work authorization for current beneficiaries; it is not a new permanent status or pathway to citizenship.
- AP estimated that about 200,000 people have lived in the United States under the designation, while the National TPS Alliance told Reuters that about 170,000 holders remained. The sources use different estimates, and this record does not collapse them into a single verified count.
- No DHS termination, redesignation or discretionary longer extension, and no new Federal Register notice, had been identified by cutoff. The administration's final country-conditions rationale and the duration beyond the statutory continuation therefore remain pending.

## SIGNIFICANCE

The temporary continuation preserves lawful presence and work authorization for a large, long-settled population that otherwise faced an immediate loss of protection. It also leaves families, employers and agencies without a final duration or policy rationale.

## GOALPOST / RESPONSE

The administration says TPS is temporary and that country conditions should determine whether protection continues; DHS has not yet published its El Salvador determination. The tests are the final notice, effective date, country-conditions record, work-authorization guidance, litigation and actual removal or employment consequences.

## MAYBE / THEREFORE

Maybe DHS needs additional time for a country-conditions review and the statutory continuation prevents an abrupt gap, or delay may prolong uncertainty without resolving whether safe return is possible. Therefore the evidence establishes continuing protection under DHS's statement and the reported statutory default—not permanent status, a discretionary long-term extension or a final termination decision.


## SOURCES

- [Reuters — Salvadoran TPS holders retain protection pending DHS announcement](https://www.reuters.com/legal/government/us-says-immigrants-el-salvador-will-now-keep-temporary-protected-status-2026-09-09/) — independent reporting quoting DHS's temporary-continuation statement and preserving that no final decision date was announced
- [Associated Press — El Salvador TPS deadline and statutory automatic extension](https://apnews.com/article/db4ed0314ca2ff0c4aff4e076bb0e894) — independent reporting on the expiring designation, DHS statement and statutory six-month continuation when DHS takes no action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
