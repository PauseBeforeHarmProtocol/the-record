# Labor finalizes repeal of formal farmworker enforcement coordination rules

**Entry ID:** NAT-2026-08-31-003
**Date:** August 31, 2026
**Checked:** 2026-08-31 5:58 AM EDT
**Evidence state:** published Labor Department final rule with operative repeal, effective date, history, comments and agency responses; procedural rescission finalized, enforcement consequences not yet measured
**Review state:** current-standard-reviewed

The final rule removes four-decade-old national and regional coordination procedures for wage, safety and employment agencies; it is scheduled to take effect September 30.

## THE FACTS

- The Department of Labor published a final rule rescinding 29 CFR part 42, effective September 30, 2026. Part 42 established formal coordination procedures among the Wage and Hour Division, Occupational Safety and Health Administration, and Employment and Training Administration for enforcing protections affecting migrant and seasonal farmworkers.
- The repealed framework required national and regional farm-labor enforcement committees, designated agency contacts, recurring plans and meetings, and collection and review of specified enforcement data. Labor says the committees largely ceased operating decades ago and that later statutes and programs, including the Migrant and Seasonal Agricultural Worker Protection Act and H-2A system, now structure coordination.
- Farmworker and public-interest commenters urged Labor to update rather than eliminate the rule and argued that rescission could weaken transparency, accountability and a 2024 court-approved settlement. Labor responded that the settlement applied only while Part 42 remained unchanged, that coordination already occurs through newer mechanisms, and that the old procedures constrained flexibility without improving enforcement outcomes.
- The final rule removes the formal regulatory mandates; it does not repeal the underlying wage, safety, H-2A or migrant-farmworker statutes and does not itself prove that field enforcement will increase or decrease after September 30.

## SIGNIFICANCE

The action shifts migrant-farmworker enforcement coordination from enforceable procedural rules to agency-managed practices. That may reduce obsolete bureaucracy, as Labor argues, but it also removes formal committees, planning duties and data-review structures that advocates could use to demand accountability.

## GOALPOST / RESPONSE

Labor says modern WHD, OSHA and ETA programs coordinate effectively without Part 42 and that the final rule does not reduce substantive worker protections. Critics say updating the regulation would preserve enforceable oversight while fixing obsolete references. Post-effective-date joint investigations, referrals, outreach, published data, staffing, enforcement results and any lawsuit challenging the rescission are the tests.

## MAYBE / THEREFORE

Maybe the rescission changes little because the prescribed committees had already fallen out of use and newer systems perform the same work, or removing enforceable procedures may make coordination less visible and consistent. Therefore the record confirms a finalized procedural repeal with a future effective date—not a repeal of farmworker labor laws or a measured decline in enforcement outcomes.


## SOURCES

- [Federal Register — rescission of coordinated farmworker enforcement regulations](https://www.federalregister.gov/documents/2026/08/31/2026-17726/rescission-of-coordinated-enforcement-regulations) — primary final rule with operative repeal, effective date, public comments and agency responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
