# Iran financial sanctions record adds Iraq Development Bank wind-down extension

**Entry ID:** NAT-2026-10-08-007
**Date:** October 8–29, 2026
**Checked:** 2026-10-30 12:04 PM EDT
**Evidence state:** primary Treasury and OFAC announcements plus independent Reuters reporting; October 8 and October 15 designations and licensing changes implemented, FinCEN alert issued, aggregate effectiveness not independently measured; complete October 15 FF and October 29 FF-1 instruments inspected and compared, extension implemented
**Review state:** current-standard-reviewed

OFAC replaced FF with FF-1, extending a narrowly bounded wind-down authorization through December 1; the bank was not delisted.

## THE FACTS

- Treasury announced an October 8 sanctions action under Executive Order 13902 targeting 17 vessels it identified as transporting Iranian crude oil, petroleum products or petrochemicals, along with companies associated with the ships. OFAC's same-day notice records the legal list changes.
- The broader OFAC action also added six individuals and entities tied to Iran-related networks under Executive Order 13846 and issued General License EE authorizing wind-down transactions involving Samudra Marine Services. Counts and authorities should not be collapsed into the 17-vessel Treasury subset.
- OFAC removed the vessels HAKUNA MATATA and PINOCCHIO from the SDN List after Treasury said they had left the shadow fleet and were sold to non-sanctioned, U.S.-aligned operators. The removals are implemented list changes, not waivers for the newly designated vessels.
- Treasury says the action neutralizes most of Iran's remaining shadow-fleet network and restricts oil revenue used for war, missiles, cyberattacks and the IRGC. Reuters independently confirmed the action, but the effectiveness claim is an administration assessment rather than a measured outcome in the inspected material.
- On October 15, Treasury designated International Development Bank for Investment and Finance in Iraq, two Iranian offshore banks, an oil intermediary and associated companies, exchange houses, employees and a Hong Kong trading company under Executive Order 13902. Reuters reported that the accompanying notice targeted 16 individuals and 10 entities.
- Treasury said the targets facilitated U.S.-dollar access, oil-revenue movement and shadow-banking transactions. Those descriptions are the administration's basis for the listings; the inspected material did not independently quantify how much money the action blocked.
- FinCEN separately issued an alert asking financial institutions to report potential Iranian regime abuse of religious charity networks and listed red flags. The alert also tells banks to use a risk-based approach and recognizes that legitimate charities should retain access to financial services.
- OFAC's same-day notice records the designation and licensing changes. Blocking and transaction prohibitions are implemented legal consequences, while Treasury's claim that the measures sever core financial lifelines remains an outcome assertion awaiting transaction, enforcement and revenue data.
- Effective October 29, OFAC General License FF-1 replaced and superseded October 15 General License FF. Transactions ordinarily incident and necessary to wind down business involving International Development Bank for Investment and Finance, also called Iraq Development Bank, and entities in which the bank owns a 50% or greater interest, directly or indirectly are authorized through 12:01 AM Eastern Standard Time on December 1, 2026. The superseded license would have expired at 12:01 AM Eastern Daylight Time on October 30.
- FF-1 requires any payment to a blocked person to enter a blocked account and does not authorize otherwise-prohibited transactions involving other blocked persons unless separately authorized. This is an implemented, time-limited licensing change—not the bank’s delisting, general sanctions relief, a completed payment or evidence that Treasury’s financing-disruption goal has been achieved.

## SIGNIFICANCE

The October 15 package broadens Operation Economic Outcast from vessels and oil logistics into formal banking, foreign-exchange and financial-intelligence channels. Blocking and reporting duties have legal effect, but the record does not establish how much financing was disrupted or whether legitimate charity access was affected. The later license materially extends the period for covered counterparties to unwind transactions while retaining blocking safeguards; it changes compliance timing rather than removing the designation.

## GOALPOST / RESPONSE

Treasury says the operation will cut remaining financial lifelines and improve detection of diverted religious funds. Blocked transactions, correspondent-account restrictions, enforcement cases, suspicious-activity reporting, oil and foreign-exchange flows, target substitution, legitimate-charity access and any delistings are the tests. The license’s strongest practical rationale is orderly wind-down rather than abrupt disruption; that is an interpretation of its operative authorization, not a newly quoted Treasury explanation. Actual blocked-account treatment, compliance, later extensions and financial flows remain the tests.

## MAYBE / THEREFORE

Maybe a longer, blocked-account wind-down window reduces collateral disruption while preserving pressure, or it prolongs some transaction exposure without demonstrably restricting the network. Therefore OFAC implemented the specific FF-1 extension with exclusions intact; delisting, unrestricted payments and measured sanctions effectiveness are not established.


## SOURCES

- [Treasury — Operation Economic Outcast shadow-fleet action](https://home.treasury.gov/news/press-releases/sb0653/) — primary official designation announcement
- [OFAC — Iran-related designations, licenses and SDN-list changes](https://ofac.treasury.gov/recent-actions/20261008) — primary official sanctions action and list notice
- [Reuters — new Iran shadow-fleet sanctions](https://www.reuters.com/world/middle-east/us-imposes-fresh-iran-related-sanctions-2026-10-08/) — independent reporting of the named sanctions action
- [Treasury — Operation Economic Outcast targets international financial and shadow-banking architecture](https://home.treasury.gov/news/press-releases/sb0660) — primary official sanctions announcement
- [Treasury — FinCEN alert on potential Iranian abuse of religious charity networks](https://home.treasury.gov/news/press-releases/sb0661) — primary official financial-crime alert announcement
- [OFAC — Iran-related designations and licensing actions](https://ofac.treasury.gov/recent-actions/20261015) — primary official sanctions, licensing and list-change notice
- [Reuters — U.S. issues fresh Iran-related sanctions](https://www.reuters.com/world/middle-east/us-issues-fresh-iran-related-sanctions-treasury-website-shows-2026-10-15/) — independent reporting of published designation counts
- [OFAC — Iran General License FF-1](https://ofac.treasury.gov/media/937311/download?inline) — primary operative general license
- [OFAC — Iran General License FF, superseded October29](https://ofac.treasury.gov/media/937246/download?inline) — primary superseded general license; comparison only
- [OFAC — Issuance of Amended Iran-related General License](https://ofac.treasury.gov/recent-actions/20261029) — primary official issuance notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
