# Treasury expands Operation Economic Outcast with banking sanctions and charity alert

**Entry ID:** NAT-2026-10-08-007
**Date:** October 8–15, 2026
**Checked:** 2026-10-16 5:57 AM EDT
**Evidence state:** primary Treasury and OFAC announcements plus independent Reuters reporting; October 8 and October 15 designations and licensing changes implemented, FinCEN alert issued, aggregate effectiveness not independently measured
**Review state:** current-standard-reviewed

After the October 8 shadow-fleet action, Treasury designated banks, financiers, exchange houses and related companies, while FinCEN issued a separate charity-network alert. The legal restrictions are implemented; economic effects remain unmeasured.

## THE FACTS

- Treasury announced an October 8 sanctions action under Executive Order 13902 targeting 17 vessels it identified as transporting Iranian crude oil, petroleum products or petrochemicals, along with companies associated with the ships. OFAC's same-day notice records the legal list changes.
- The broader OFAC action also added six individuals and entities tied to Iran-related networks under Executive Order 13846 and issued General License EE authorizing wind-down transactions involving Samudra Marine Services. Counts and authorities should not be collapsed into the 17-vessel Treasury subset.
- OFAC removed the vessels HAKUNA MATATA and PINOCCHIO from the SDN List after Treasury said they had left the shadow fleet and were sold to non-sanctioned, U.S.-aligned operators. The removals are implemented list changes, not waivers for the newly designated vessels.
- Treasury says the action neutralizes most of Iran's remaining shadow-fleet network and restricts oil revenue used for war, missiles, cyberattacks and the IRGC. Reuters independently confirmed the action, but the effectiveness claim is an administration assessment rather than a measured outcome in the inspected material.
- On October 15, Treasury designated International Development Bank for Investment and Finance in Iraq, two Iranian offshore banks, an oil intermediary and associated companies, exchange houses, employees and a Hong Kong trading company under Executive Order 13902. Reuters reported that the accompanying notice targeted 16 individuals and 10 entities.
- Treasury said the targets facilitated U.S.-dollar access, oil-revenue movement and shadow-banking transactions. Those descriptions are the administration's basis for the listings; the inspected material did not independently quantify how much money the action blocked.
- FinCEN separately issued an alert asking financial institutions to report potential Iranian regime abuse of religious charity networks and listed red flags. The alert also tells banks to use a risk-based approach and recognizes that legitimate charities should retain access to financial services.
- OFAC's same-day notice records the designation and licensing changes. Blocking and transaction prohibitions are implemented legal consequences, while Treasury's claim that the measures sever core financial lifelines remains an outcome assertion awaiting transaction, enforcement and revenue data.

## SIGNIFICANCE

The October 15 package broadens Operation Economic Outcast from vessels and oil logistics into formal banking, foreign-exchange and financial-intelligence channels. Blocking and reporting duties have legal effect, but the record does not establish how much financing was disrupted or whether legitimate charity access was affected.

## GOALPOST / RESPONSE

Treasury says the operation will cut remaining financial lifelines and improve detection of diverted religious funds. Blocked transactions, correspondent-account restrictions, enforcement cases, suspicious-activity reporting, oil and foreign-exchange flows, target substitution, legitimate-charity access and any delistings are the tests.

## MAYBE / THEREFORE

Maybe the combined vessel, bank, exchange-house and reporting actions materially constrain Iran's access to foreign currency, or networks may shift intermediaries while compliance burdens fall more broadly. Therefore Treasury implemented another target-level sanctions package and issued a formal FinCEN alert—not proof that Iran's financing has been severed or that every flagged charity transaction is illicit.


## SOURCES

- [Treasury — Operation Economic Outcast shadow-fleet action](https://home.treasury.gov/news/press-releases/sb0653/) — primary official designation announcement
- [OFAC — Iran-related designations, licenses and SDN-list changes](https://ofac.treasury.gov/recent-actions/20261008) — primary official sanctions action and list notice
- [Reuters — new Iran shadow-fleet sanctions](https://www.reuters.com/world/middle-east/us-imposes-fresh-iran-related-sanctions-2026-10-08/) — independent reporting of the named sanctions action
- [Treasury — Operation Economic Outcast targets international financial and shadow-banking architecture](https://home.treasury.gov/news/press-releases/sb0660) — primary official sanctions announcement
- [Treasury — FinCEN alert on potential Iranian abuse of religious charity networks](https://home.treasury.gov/news/press-releases/sb0661) — primary official financial-crime alert announcement
- [OFAC — Iran-related designations and licensing actions](https://ofac.treasury.gov/recent-actions/20261015) — primary official sanctions, licensing and list-change notice
- [Reuters — U.S. issues fresh Iran-related sanctions](https://www.reuters.com/world/middle-east/us-issues-fresh-iran-related-sanctions-treasury-website-shows-2026-10-15/) — independent reporting of published designation counts

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
