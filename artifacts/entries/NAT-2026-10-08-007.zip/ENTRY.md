# Treasury sanctions 17 vessels in Iran shadow-fleet action

**Entry ID:** NAT-2026-10-08-007
**Date:** October 8, 2026
**Checked:** 2026-10-09 12:03 AM EDT
**Evidence state:** primary Treasury announcement and OFAC list notice plus independent Reuters reporting; designations and delistings implemented, effectiveness not independently measured
**Review state:** current-standard-reviewed

The coordinated sanctions block vessels, companies and related networks while removing two ships after changed circumstances; effectiveness claims remain administration assertions pending shipping and revenue data.

## THE FACTS

- Treasury announced an October 8 sanctions action under Executive Order 13902 targeting 17 vessels it identified as transporting Iranian crude oil, petroleum products or petrochemicals, along with companies associated with the ships. OFAC's same-day notice records the legal list changes.
- The broader OFAC action also added six individuals and entities tied to Iran-related networks under Executive Order 13846 and issued General License EE authorizing wind-down transactions involving Samudra Marine Services. Counts and authorities should not be collapsed into the 17-vessel Treasury subset.
- OFAC removed the vessels HAKUNA MATATA and PINOCCHIO from the SDN List after Treasury said they had left the shadow fleet and were sold to non-sanctioned, U.S.-aligned operators. The removals are implemented list changes, not waivers for the newly designated vessels.
- Treasury says the action neutralizes most of Iran's remaining shadow-fleet network and restricts oil revenue used for war, missiles, cyberattacks and the IRGC. Reuters independently confirmed the action, but the effectiveness claim is an administration assessment rather than a measured outcome in the inspected material.

## SIGNIFICANCE

The action expands financial and shipping exposure for owners, operators, counterparties and foreign financial institutions while showing that delisting can follow verified changes in ownership or conduct. Actual pressure depends on enforcement, flag and port cooperation, replacement capacity and Iranian export revenue.

## GOALPOST / RESPONSE

Treasury says the designations will sever core evasion channels and starve the Iranian government of revenue. Vessel movements, port access, insurer and bank behavior, enforcement cases, export volumes, oil revenue, replacement ships and any further delistings are the tests.

## MAYBE / THEREFORE

Maybe the coordinated designations materially constrain Iran's remaining shipping network, or operators may reflag, rename or replace vessels and blunt the effect. Therefore the United States implemented a substantial target-level sanctions package and two delistings—not proof that the shadow fleet is neutralized or that Iranian oil revenue has fallen by a measured amount.


## SOURCES

- [Treasury — Operation Economic Outcast shadow-fleet action](https://home.treasury.gov/news/press-releases/sb0653/) — primary official designation announcement
- [OFAC — Iran-related designations, licenses and SDN-list changes](https://ofac.treasury.gov/recent-actions/20261008) — primary official sanctions action and list notice
- [Reuters — new Iran shadow-fleet sanctions](https://www.reuters.com/world/middle-east/us-imposes-fresh-iran-related-sanctions-2026-10-08/) — independent reporting of the named sanctions action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
