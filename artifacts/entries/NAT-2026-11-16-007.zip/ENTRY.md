# CMS proposes CRUSH program-integrity rule across federal health programs

**Entry ID:** NAT-2026-11-16-007
**Date:** November 16, 2026
**Checked:** 2026-11-16 6:00 PM EST
**Evidence state:** CMS announcement and fact sheet plus complete Federal Register public-inspection proposal; proposed only, open for comment through January 19, 2027, savings projected rather than achieved
**Review state:** current-standard-reviewed

CMS proposed broad program-integrity changes across Medicare, Medicaid, CHIP and the federal Marketplace; its nearly $90 billion figure is a ten-year projection, not recovered money.

## THE FACTS

- CMS issued the Comprehensive Regulations to Uncover Suspicious Healthcare, or CRUSH, proposed rule, file CMS-6098-P. CMS set a January 19, 2027 comment deadline; none of the proposed provisions is final or effective at the evidence cutoff.
- For Medicare, CMS proposes additional enrollment-denial and revocation grounds when identities or locations cannot be verified or risks are unacceptable, 30-day reporting of enrollment changes, mandatory Medicare Advantage and Part D reporting of suspicious or substantiated fraud, waste and abuse, and changes to risk-adjustment audits and overpayment recovery.
- For Medicaid and CHIP, the proposal includes expanded use of National Provider Identifiers and ownership data, new denial and termination grounds, additional state reporting and corrective-action requirements, and required review of electronic-visit-verification information for specified program-integrity activities.
- For the Marketplace, CMS proposes authority to suspend or terminate agent, broker and web-broker agreements for specified abusive conduct or noncompliance and to require safeguards against system access from outside the United States, including certain virtual-private-network routing.
- CMS projects that quantified provisions could save federal taxpayers nearly $90 billion over ten years and says the proposal would prevent fraud before payment. The rule itself says its estimates exclude more than $90 billion in projected transfers among governments and private entities and seeks comment on the estimates; no savings or fraud reduction has yet been achieved by the proposal.

## SIGNIFICANCE

If finalized, the proposal would alter enrollment, reporting, audit and access controls across federal health programs and state systems. Its scale and projected fiscal effects are material, but public comment, final legal text, operational burden and actual error and recovery rates remain unresolved.

## GOALPOST / RESPONSE

CMS's prevention and savings rationale should be tested only after any final rule through final text and implementation dates, enrollment and payment denials, false positives and appeals, recovered overpayments, state and plan compliance costs, beneficiary access, enforcement outcomes and independently validated net federal savings.

## MAYBE / THEREFORE

Maybe stronger screening, reporting and audit tools will prevent large improper payments, or broad new controls may add cost and access errors without delivering the projected return. Therefore CRUSH is a formal, comment-stage proposal with an agency savings estimate—not implemented policy, recovered funds or measured fraud reduction.


## SOURCES

- [CMS — CRUSH proposed-rule announcement](https://www.cms.gov/newsroom/press-releases/cms-crush-proposed-rule-aims-reap-nearly-90-billion-taxpayers-savings-targeting-fraud-across) — primary agency announcement and ten-year savings projection
- [CMS — CRUSH proposed-rule fact sheet](https://www.cms.gov/newsroom/fact-sheets/comprehensive-regulations-uncover-suspicious-healthcare-crush-proposed-rule-cms-6098-p) — primary agency summary of proposed Medicare, Medicaid, CHIP and Marketplace provisions
- [Federal Register public-inspection copy — Comprehensive Regulations to Uncover Suspicious Healthcare](https://public-inspection.federalregister.gov/2026-23461.pdf) — primary complete proposed rule, CMS-6098-P; SHA-256 10dc39561396e815428b82d2d391f6198a953f03c9a56df7cded9cd5834a1348

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
