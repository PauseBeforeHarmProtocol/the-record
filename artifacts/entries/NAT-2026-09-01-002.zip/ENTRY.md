# OCC and FDIC narrow formal bank-supervision findings to material risks

**Entry ID:** NAT-2026-09-01-002
**Date:** September 1, 2026
**Checked:** 2026-09-01 6:04 AM EDT
**Evidence state:** primary OCC-FDIC final rule documenting the definitions, scope, comments, agency responses and future effective date; rule finalized, implementation and outcomes pending
**Review state:** current-standard-reviewed

The joint final rule limits unsafe-or-unsound findings and Matters Requiring Attention to defined material-risk or legal-violation circumstances when it takes effect November 2.

## THE FACTS

- The Office of the Comptroller of the Currency and Federal Deposit Insurance Corporation issued a joint final rule defining when examiners may cite unsafe or unsound practices and issue formal Matters Requiring Attention. It is scheduled to take effect November 2, 2026.
- The rule centers an unsafe-or-unsound finding on conduct likely to cause material financial harm to an institution or a material risk of loss to the Deposit Insurance Fund. It limits Matters Requiring Attention to qualifying material risks or actual violations of law and requires supervisory action to be tailored to the institution.
- Examiners may still communicate observations and recommendations that do not meet the MRA threshold. The rule changes the conditions for formal supervisory findings; it does not eliminate examinations, safety-and-soundness authority or enforcement for legal violations.
- Supporters said the standards provide clarity, reduce examiner micromanagement and focus attention on material financial risk. Critics warned that a higher threshold could inhibit early intervention and give less weight to documentation, operational, consumer-protection or systemic weaknesses before losses become likely.
- The agencies said the material-risk focus would make supervision more effective. No post-effective-date examination record, bank-failure data, compliance-cost measurement or Deposit Insurance Fund result existed by cutoff.

## SIGNIFICANCE

Formal supervisory findings can drive bank remediation, management attention and regulatory costs. Narrowing their threshold may reduce inconsistent or low-value directives, but it may also alter how early regulators formally intervene in emerging weaknesses; evidence after November 2 will determine which effect dominates.

## GOALPOST / RESPONSE

The agencies say clear, material-risk standards will strengthen supervision and accountability while preserving examiners' ability to identify concerns. Critics say some serious problems are easiest to correct before they become likely sources of material loss. Examination manuals, post-effective MRAs, supervisory observations, enforcement cases, remediation timing, compliance costs, bank failures and Deposit Insurance Fund losses are the tests.

## MAYBE / THEREFORE

Maybe the rule will concentrate formal findings on consequential problems without suppressing early warnings, or the tighter standard may discourage escalation until weaknesses are harder to correct. Therefore the record confirms publication of a final rule scheduled for November 2—not that supervisory intensity has already changed, banks are safer, regulatory burden has fallen or future losses will increase.


## SOURCES

- [Federal Register — unsafe-or-unsound-practices and Matters Requiring Attention final rule](https://www.federalregister.gov/documents/2026/09/01/2026-17823/unsafe-or-unsound-practices-matters-requiring-attention) — primary joint final rule defining material-risk standards for supervisory findings and its November 2 effective date

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
