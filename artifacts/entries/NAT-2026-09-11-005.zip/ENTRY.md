# EXIM announces $99.6 million Africell loan for Angola network technology

**Entry ID:** NAT-2026-09-11-005
**Date:** September 11, 2026
**Checked:** 2026-09-11 12:02 PM EDT
**Evidence state:** published financing announcement described by AP and independently reviewed by Reuters; amount and stated purpose confirmed, disbursement and outcomes unresolved
**Review state:** current-standard-reviewed

The financing is intended to support American and allied telecom equipment and compete with Huawei; disbursement, purchases, jobs and security effects are not yet verified.

## THE FACTS

- Associated Press reported on September 11 that the Trump administration had provided a $99.6 million Export-Import Bank loan to U.S.-owned Africell, based on a financing announcement published by the operator that day. Reuters separately reviewed the published release after an earlier draft-based report.
- Africell said the financing would support investment in American and European mobile-network technology for its Angola operations and would boost U.S.-based telecommunications employment. The public reporting did not identify a disbursement schedule, supplier-by-supplier allocation or verified job count.
- Reuters reported that Africell serves about 15 million customers in Angola, Gambia, the Democratic Republic of Congo and Sierra Leone and described the loan as part of U.S. efforts to promote non-Huawei technology abroad under a 2025 executive order.
- Reuters cited an estimate that Huawei supplies about 52% of Africa's 5G infrastructure. Huawei denies U.S. spying allegations; China's embassy said Chinese investment has supported African growth and urged the United States not to pursue its Africa agenda by undermining China-Africa cooperation.

## SIGNIFICANCE

A federal export-credit commitment of this size can shape network procurement, U.S. exports and strategic technology alignment in Africa. The announcement establishes the financing decision and rationale, not delivery of equipment, creation of jobs or reduced cybersecurity risk.

## GOALPOST / RESPONSE

Africell and the administration frame the loan as support for U.S. employment, American technology leadership and more trusted communications infrastructure. Executed loan terms, disbursements, named suppliers, U.S. content, network deployment, repayment, employment and independently measured security outcomes are the tests.

## MAYBE / THEREFORE

Maybe the financing expands reliable non-Huawei infrastructure and U.S. exports, or it may mainly shift vendor competition while placing repayment and execution risk on a public credit program. Therefore the established action is an announced $99.6 million EXIM loan—not verified spending, completed procurement or proof of strategic benefit.


## SOURCES

- [Associated Press — EXIM loan to Africell announced](https://apnews.com/article/trump-huawei-africell-tech-us-china-a755a634563876d52c9738dce4e5d7f4) — independent reporting citing the operator's announcement
- [Reuters — EXIM loan to Africell and U.S. technology strategy](https://www.reuters.com/world/china/trump-administration-lend-100-million-africell-countering-huawei-africa-2026-09-11/) — independent reporting citing the published financing release and named responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
