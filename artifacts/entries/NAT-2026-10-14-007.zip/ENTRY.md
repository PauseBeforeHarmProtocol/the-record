# Justice Department reports first national tax-enforcement surge

**Entry ID:** NAT-2026-10-14-007
**Date:** October 14, 2026
**Checked:** 2026-10-14 6:03 PM EDT
**Evidence state:** primary Justice Department nationwide case summary with explicit allegation disclaimer; coordinated actions reported, unresolved charges unproven and recoveries not established
**Review state:** current-standard-reviewed

The September-to-October effort covered 76 defendants and more than $490 million in alleged or proven intended losses; charges remain allegations unless resolved.

## THE FACTS

- The Justice Department said its National Fraud Enforcement Division's Tax Section and 35 U.S. Attorneys' Offices conducted the department's first National Tax Enforcement Surge from early September through October 14, with participation by the IRS and IRS Criminal Investigation.
- DOJ reported prosecutorial actions involving 76 defendants whose alleged and proven conduct represented more than $490 million in intended federal revenue loss. That total combines unresolved allegations with resolved cases and describes intended loss, not necessarily money paid out or recovered.
- The department said 23 new charging actions involved 31 defendants and more than $350 million in alleged intended loss, while roughly 39 other actions—including trials, guilty pleas and sentencings—involved 45 defendants and nearly $140 million in intended loss. Individual procedural status must be evaluated case by case.
- DOJ expressly stated that indictments, informations and complaints are allegations and that defendants are presumed innocent unless proven guilty. The release also included guilty pleas and sentencings, which are resolved stages and should not be conflated with newly filed charges.
- The department says the surge advances a whole-of-government fraud initiative. Effectiveness tests include convictions or dismissals, restitution and collections, recovered versus intended loss, repeat-offense measures, resource costs, due-process outcomes and sustained enforcement after the surge.

## SIGNIFICANCE

The surge is a nationally coordinated charging and case-resolution campaign with a large claimed fiscal scope. Its mixed procedural stages make careful labeling essential: the announcement documents federal actions and resolved outcomes but does not prove every accusation or establish $490 million in recovered revenue.

## GOALPOST / RESPONSE

DOJ and IRS present concentrated interdistrict enforcement as a way to deter tax fraud and protect federal revenue. Tests include final case outcomes, actual collections and restitution, error or dismissal rates, sentencing consistency, audited net revenue and whether the initiative improves durable enforcement capacity.

## MAYBE / THEREFORE

Maybe coordinated surge staffing identifies complex fraud more efficiently, or headline intended-loss totals may overstate recoverable harm and short campaigns may not repair underlying enforcement capacity. Therefore DOJ reported a nationwide mix of charges and resolved cases involving 76 defendants—not 76 convictions or $490 million already recovered.


## SOURCES

- [Justice Department — national tax enforcement surge results](https://www.justice.gov/opa/pr/dojs-fraud-division-irs-and-irs-ci-expose-more-490m-tax-fraud-national-tax-enforcement-surge) — primary nationwide charging, plea, trial and sentencing summary with allegation disclaimer

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
