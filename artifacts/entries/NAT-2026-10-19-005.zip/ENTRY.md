# Justice Department opens civil-rights investigation of D.C. jail conditions

**Entry ID:** NAT-2026-10-19-005
**Date:** October 19, 2026
**Checked:** 2026-10-19 6:00 PM EDT
**Evidence state:** DOJ CRIPA notice and release plus independent Washington Post reporting; investigation formally opened, allegations and historical concerns documented, conclusions and remedies unresolved
**Review state:** current-standard-reviewed

The CRIPA investigation covers excessive force, medical care, safety, sanitation and nutrition since January 2021; DOJ says it has reached no conclusions.

## THE FACTS

- The Justice Department sent District of Columbia Mayor Muriel Bowser statutory notice that it is commencing an investigation of D.C. Department of Corrections facilities under the Civil Rights of Institutionalized Persons Act.
- The inquiry will examine whether the District engages in a pattern or practice of violating inmates' and detainees' constitutional rights through excessive force, inadequate medical care, unsafe or unsanitary conditions and inadequate nutrition. Its stated review period begins January 1, 2021.
- DOJ's notice expressly says the department has reached no conclusions. It says investigators will consider the District's compliance efforts, close the matter if they find no constitutional violations, or issue findings and seek remedies if they identify systemic violations.
- The Washington Post reported recent allegations and litigation over contaminated food and longstanding problems including mold, plumbing and health care. The D.C. corrections department said it takes food-quality concerns seriously and aims to meet USDA nutrition standards; the mayor's office and department had not responded to the new investigation by publication time.

## SIGNIFICANCE

A CRIPA investigation is a formal federal civil-rights process that can produce public findings, negotiated reforms or litigation affecting confinement conditions in the nation's capital. Opening the inquiry establishes scrutiny and scope, not that constitutional violations have been proven.

## GOALPOST / RESPONSE

DOJ says it will review all relevant information and work with the District if systemic violations are found. Inspection access, records reviewed, District cooperation, public findings, remedial commitments, court filings and independently measured changes in force, health care, sanitation and nutrition are the tests.

## MAYBE / THEREFORE

Maybe the investigation validates longstanding complaints and produces durable reforms, or it may find narrower problems or no systemic constitutional violation. Therefore DOJ has opened a broad investigation—not issued findings, imposed a remedy or established liability.


## SOURCES

- [Justice Department — D.C. corrections civil-rights investigation announcement](https://www.justice.gov/opa/pr/justice-department-notifies-district-columbia-investigation-whether-conditions-dc-department) — primary announcement of the CRIPA investigation and stated scope
- [Justice Department — CRIPA notice to the District of Columbia](https://www.justice.gov/crt/media/1466936/dl?inline=) — primary statutory notice defining the investigation, evidence status and possible dispositions
- [Washington Post — DOJ opens investigation of D.C. jail conditions](https://www.washingtonpost.com/dc-md-va/2026/10/19/doj-announces-investigation-into-whether-dc-jail-conditions-violate-constitution/) — independent reporting on the investigation, prior allegations and District response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
