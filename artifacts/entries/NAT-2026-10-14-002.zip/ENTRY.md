# OCC reports all nine reviewed large banks had policies capable of influencing debanking

**Entry ID:** NAT-2026-10-14-002
**Date:** October 14, 2026
**Checked:** 2026-10-14 11:55 AM EDT
**Evidence state:** primary OCC supervisory-review findings and methodology plus independent Reuters reporting and bank response; agency findings published, individual liability and remedial effectiveness unresolved
**Review state:** current-standard-reviewed

The supervisory review covered policies from 2020 through September 2025; the regulator announced no fines and is considering further framework changes.

## THE FACTS

- The Office of the Comptroller of the Currency released findings from its supervisory review of JPMorgan Chase, Bank of America, Citibank, Wells Fargo, U.S. Bank, Capital One, PNC, TD Bank and BMO Bank. The OCC said all nine had policies between 2020 and September 2025 that could require, encourage or influence denial or limitation of financial services because of political or religious beliefs or lawful business activity.
- The regulator said broad reputation-risk policies often lacked clear standards and objective, risk-based criteria. It also identified restrictions affecting oil and gas, coal, firearms and ammunition, detention facilities, tobacco and e-cigarettes, and digital-asset activity.
- OCC said it reviewed nearly 100,000 complaints and approximately 50,000 bank documents totaling about 420,000 pages. Those figures describe the review's evidence base; the public release does not establish that every complaint was substantiated or that every account decision was politically motivated.
- Reuters reported that the OCC imposed no fines or sanctions with the report and said further regulatory or supervisory changes were under consideration. The report is therefore an agency supervisory finding and policy-development stage, not a court judgment or completed enforcement penalty.
- Large banks have said they deny or close accounts for legal, financial or reputational risk rather than politics. JPMorgan said it prohibits political and religious discrimination and argued that years of regulatory second-guessing contributed to excessive caution; objective decision criteria, complaint outcomes and future examinations are the tests of both accounts.

## SIGNIFICANCE

The report converts a politically contested allegation into a documented supervisory finding across the nine largest OCC-supervised banks and may shape access-to-banking rules. Its limits matter: the public findings cover policies and selected decisions, while individual causation, legal liability, sanctions and the effect of future reforms remain unresolved.

## GOALPOST / RESPONSE

The administration and OCC say fair access requires objective risk-based banking decisions and that subjective reputation risk enabled discrimination. Banks say legitimate compliance pressure, not political viewpoint, drove caution. Tests include revised policies, measurable criteria, complaint dispositions, examination findings, enforcement actions and access outcomes for lawful customers and sectors.

## MAYBE / THEREFORE

Maybe the review exposes systematic use of vague standards against disfavored lawful customers, or some restrictions may reflect genuine compliance and credit risks that the public report cannot resolve account by account. Therefore OCC found problematic policies at all nine reviewed banks—not that every closure was unlawful, that every bank acted from partisan motive or that penalties were imposed.


## SOURCES

- [OCC — report on nine large banks' debanking activities](https://www.occ.gov/news-issuances/news-releases/2026/nr-occ-2026-90.html) — primary supervisory-review findings and methodology
- [Reuters — OCC faults nine large banks over debanking policies](https://www.reuters.com/legal/transactional/us-bank-regulator-faults-several-large-lenders-over-debanking-practices-2026-10-14/) — independent reporting with bank response and penalty status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
