# DHS finalizes domestic-PPE acquisition rules

**Entry ID:** NAT-2026-09-18-003
**Date:** September 18, 2026
**Checked:** 2026-09-18 12:00 PM EDT
**Evidence state:** complete primary DHS final rule; October 19 effectiveness scheduled, contract-level spending, domestic content and readiness outcomes unresolved
**Review state:** current-standard-reviewed

The October 19 rule codifies domestic sourcing, minimum contract terms and public-health-emergency exceptions required by the 2021 statute.

## THE FACTS

- The Department of Homeland Security published a final Homeland Security Acquisition Regulation rule implementing the Make PPE in America Act. It takes effect October 19, 2026.
- The rule covers specified masks, respirators and filters, face shields and protective eyewear, gloves, gowns, head and foot coverings and related disease-protection gear. Covered DHS contracts generally must use PPE and components grown, reprocessed, reused or produced in the United States.
- Covered contracts must generally last at least two years plus needed option periods. The statute and rule allow specified alternatives and nonavailability or price exceptions; emergency alternatives and exceptions require recurring or case-specific certifications rather than becoming blanket waivers.
- DHS says it has applied a class deviation since October 2022. It reported moving all nitrile-glove requirements to domestic manufacturers by January 2026, while domestic manufacturers still rely on foreign nitrile butadiene rubber because it is not produced domestically.
- The rule codifies statutory procurement conditions; it does not establish the value of future awards, complete domestic sourcing of all inputs or measured emergency readiness. DHS declined requests to narrow statutory nonavailability provisions beyond the law's text.

## SIGNIFICANCE

Codifying the procurement requirements turns a temporary acquisition deviation into a durable DHS rule intended to sustain domestic PPE manufacturing, while preserving exceptions that may remain important where U.S. inputs or capacity are unavailable.

## GOALPOST / RESPONSE

DHS says longer domestic contracts will support supply-chain resilience for public-health crises. Contract awards, domestic-content certifications, exceptions, prices, delivery performance, capacity and emergency stock availability are the tests.

## MAYBE / THEREFORE

Maybe longer domestic contracts create reliable demand and reduce emergency dependence on foreign supply, or exceptions and missing domestic inputs may limit that effect or raise costs. Therefore DHS finalized the acquisition framework—not proof that all PPE is domestic or that readiness and prices improved.


## SOURCES

- [Federal Register — DHS domestic PPE acquisition final rule](https://www.federalregister.gov/documents/2026/09/18/2026-19207/homeland-security-acquisition-regulation-make-personal-protective-equipment-in-america-act) — primary final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
