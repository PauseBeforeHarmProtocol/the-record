# United States and Venezuela announce oil-development framework

**Entry ID:** NAT-2026-08-28-010
**Date:** August 28–September 1, 2026
**Checked:** 2026-09-01 6:04 AM EDT
**Evidence state:** primary White House disclosure and Trump statements, counterpart announcements, and independent Reuters and Associated Press reporting; agreement structure announced and partly documented, underlying contract text, investment, production, deliveries and measured outcomes unresolved
**Review state:** current-standard-reviewed

The White House disclosed 100-year concessions for 17 fields, a 35% Pentagon-linked equity stake and federal oil-purchase rights; investment, production and public returns remain prospective.

## THE FACTS

- Trump announced that the United States had secured what he called majority control of more than 65 billion barrels of Venezuelan oil through a partnership with private business. Venezuela's interim president, Delcy Rodríguez, publicly welcomed the arrangement and projected $100 billion in investment.
- In a late-night state-television address, Rodríguez said the bilateral framework would run for 25 years, develop 17 strategic oilfields and eight greenfield blocks, and initially target more than 1.5 million barrels per day. She projected $209 billion in Venezuelan state revenue at a $65 benchmark price and said roughly $19 from each barrel produced and sold under the arrangement would flow to Venezuela.
- Reuters independently confirmed weeks of negotiations and Rodríguez's counterpart announcements. It reported that Venezuelan officials expected to prepare company agreements the following week, while the companies, field identities, ownership structure, legal basis, financing, and signed operative contracts remained undisclosed. Rodríguez said Venezuela retained ownership and sovereignty over its resources.
- A White House fact sheet released August 31 identified North American Blue Energy Partners, or NABEP, as the private operator and said Venezuelan interim authorities granted it 100-year concessions covering 17 fields with approximately 65 billion barrels of reserves. The disclosure confirms a concession framework; it does not establish that the reserves changed sovereign ownership or became U.S. public assets.
- The White House said the Department of War's Office of Strategic Capital would receive 35% equity in NABEP's parent company, with the United States holding board-appointment, director-citizenship and veto rights. It also described a guaranteed federal right to buy 20% of production at cost and a right of first refusal on the remaining 80%. The public fact sheet, rather than a complete executed contract, is the available primary description of those rights.
- The administration said Secretary of State Marco Rubio and Secretary of War Pete Hegseth signed the agreement and that NABEP plans to invest as much as $100 billion. It projected more than $200 billion in Venezuelan royalty and tax revenue over 25 years and no taxpayer cost, but disclosed no completed investment, production increase, federal dividend, oil delivery, procurement schedule or audited fiscal result.
- Reuters and AP reported that rebuilding production could take years and described sanctions, infrastructure, financing, legal, political and beneficial-ownership risks. Reuters also reported concern among some major producers. Those reports do not prove failure, but they make future investment, production, governance and returns material tests rather than completed outcomes.
- Trump separately said oil from the framework would soon refill the Strategic Petroleum Reserve and called it a gift. No public volume, delivery schedule, payment or gift mechanism, Energy Department receipt, or counterpart confirmation that oil would be transferred without payment was available by cutoff.

## SIGNIFICANCE

The disclosure converts an unusually broad bilateral announcement into a more specific public-private governance and purchase framework involving a Pentagon office, a private operator and century-long Venezuelan concessions. The arrangement could influence U.S. energy security and Venezuela's economy, but its scale also makes legal authority, ownership, sanctions compliance, financing and measurable public returns central accountability questions.

## GOALPOST / RESPONSE

The administration says the agreement secures U.S. energy leadership without taxpayer cost, will attract up to $100 billion in private investment, and can support lower prices, Venezuelan recovery and the Strategic Petroleum Reserve. Venezuela describes it as development under continued national resource sovereignty. The complete executed agreement, beneficial ownership, concession and constitutional approvals, sanctions treatment, financing commitments, board records, production, U.S. purchases, dividends, tax and royalty receipts, and consumer-price effects are the tests.

## MAYBE / THEREFORE

Maybe the disclosed control and purchase rights will draw capital, raise output and generate public value without federal spending, or political, legal, financing, sanctions and infrastructure constraints may prevent the projected scale and returns. Therefore the record confirms publicly disclosed agreement terms and government rights—not transferred sovereign reserves, $100 billion already invested, produced or delivered oil, a verified gift, taxpayer profit, a refilled reserve or lower fuel prices.


## SOURCES

- [Donald Trump — Truth Social announcement of Venezuela oil framework](https://truthsocial.com/@realDonaldTrump/117175567133618952) — primary evidence that Trump published the announcement; claims inside the post require independent verification
- [Reuters — United States and Venezuela announce oil-development framework](https://www.reuters.com/business/energy/us-enters-into-oil-agreement-with-venezuela-trump-says-2026-08-28/) — independent reporting confirming the counterpart announcement, negotiations, unresolved structure, and implementation barriers
- [Associated Press — Trump announces Venezuela oil agreement](https://apnews.com/article/trump-venezuela-oil-reserves-eb0ed5a1e99602c21a7f690c3368020e) — independent reporting on the announced framework and attributed nonpublic structural details
- [Reuters — Venezuela publicly specifies 25-year U.S. energy framework terms](https://www.reuters.com/business/energy/venezuelas-interim-president-says-us-energy-deal-will-last-25-years-2026-08-30/) — independent reporting on the Venezuelan interim president's state-television statement specifying duration, production targets, fields and revenue assumptions
- [Donald Trump — Truth Social statement on Venezuelan oil and the Strategic Petroleum Reserve](https://truthsocial.com/@realDonaldTrump/117184857420534704) — primary evidence that Trump published the SPR plan and gift characterization; claims inside the post require independent verification
- [Reuters — Trump says Venezuelan oil will refill Strategic Petroleum Reserve](https://www.reuters.com/business/energy/trump-says-us-will-refill-strategic-petroleum-reserve-using-venezuelan-oil-2026-08-30/) — independent reporting on the announced SPR plan, reserve level and unresolved delivery timing
- [White House — fact sheet on the Venezuela oil agreement](https://www.whitehouse.gov/fact-sheets/2026/08/fact-sheet-president-donald-j-trump-announces-historic-oil-agreement-to-secure-american-energy-dominance-and-drive-venezuelas-economic-recovery/) — primary administration description of the concession structure, U.S. government rights, planned private investment and projected outcomes
- [Reuters — White House releases Venezuela oil-deal terms](https://www.reuters.com/business/energy/white-house-releases-terms-oil-deal-with-north-american-blue-energy-partners-2026-09-01/) — independent reporting on the disclosed 100-year concessions, government equity and purchase rights, company identity and unresolved implementation
- [Associated Press — U.S. and NABEP form Venezuela oil venture](https://apnews.com/article/trump-venezuela-oil-nabep-reserves-7a4fa51f842e17b9b1d092fbeef2646a) — independent reporting on the venture structure, government control rights, investment plan and long implementation horizon
- [Reuters — Venezuela agreement raises concerns among major oil producers](https://www.reuters.com/business/energy/trumps-oil-deal-with-venezuela-raises-red-flags-some-major-producers-sources-say-2026-09-01/) — independent industry reporting on legal, political, financing, sanctions and beneficial-ownership risks surrounding implementation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
