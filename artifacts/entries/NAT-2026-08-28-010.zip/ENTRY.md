# United States and Venezuela announce oil-development framework

**Entry ID:** NAT-2026-08-28-010
**Date:** August 28–30, 2026
**Checked:** 2026-08-30 12:03 PM EDT
**Evidence state:** Trump's two published announcements plus independent Reuters and Associated Press reporting and two public counterpart statements; bilateral framework and SPR intention announced, operative agreements, procurement mechanism, deliveries and outcomes not yet public
**Review state:** current-standard-reviewed

Trump now says Venezuelan oil will soon refill the Strategic Petroleum Reserve, but no procurement instrument, volume, delivery schedule or receipt was public by cutoff.

## THE FACTS

- Trump announced that the United States had secured what he called majority control of more than 65 billion barrels of Venezuelan oil through a partnership with private business. Venezuela's interim president, Delcy Rodríguez, publicly welcomed the arrangement and projected $100 billion in investment.
- In a late-night state-television address, Rodríguez said the bilateral framework would run for 25 years, develop 17 strategic oilfields and eight greenfield blocks, and initially target more than 1.5 million barrels per day. She projected $209 billion in Venezuelan state revenue at a $65 benchmark price and said roughly $19 from each barrel produced and sold under the arrangement would flow to Venezuela.
- Reuters independently confirmed weeks of negotiations and Rodríguez's counterpart announcements. It reported that Venezuelan officials expected to prepare company agreements the following week, while the companies, field identities, ownership structure, legal basis, financing, and signed operative contracts remained undisclosed. Rodríguez said Venezuela retained ownership and sovereignty over its resources.
- The Associated Press attributed additional structure to an unnamed U.S. official: a new private company involving the U.S. government and an unnamed operator, 100-year rights, and an asserted 55% effective share of production through ownership and at-cost purchase rights. Those details are reported and attributed, not independently documented in a public agreement.
- Reuters and AP described substantial legal, constitutional, infrastructure, and financing barriers. Increased production or lower consumer prices could take years and were not established by the announcement. The public evidence did not show that the United States had taken sovereign title to Venezuela's reserves or booked them as U.S. assets.
- On August 30, Trump said oil from the framework would be used to refill the Strategic Petroleum Reserve soon and called it a gift from Venezuela. Reuters reported that the reserve held about 290 million barrels on August 21, near a 44-year low, but found no disclosed timing for Venezuelan deliveries or near-term effect. No public procurement contract, volume, delivery schedule, payment or gift mechanism, Energy Department receipt, or counterpart confirmation of a gift was available by cutoff.

## SIGNIFICANCE

Using Venezuelan crude to refill the Strategic Petroleum Reserve would connect the foreign-policy framework to a concrete U.S. energy-security objective. The missing procurement and delivery details remain decisive because the framework still requires investment and infrastructure work before materially higher production is available.

## GOALPOST / RESPONSE

The administration says the arrangement will bring stable, lower-cost oil, roughly $100 billion in private investment, and a soon-refilled reserve; Rodríguez presents it as a revival of Venezuela's energy sector. Published contracts, company identities and beneficial ownership, field licenses, constitutional approvals, sanctions treatment, financing, SPR procurement authority, delivery volumes and timing, actual receipts, government revenue, and consumer-price effects are the tests.

## MAYBE / THEREFORE

Maybe existing Venezuelan production can supply some reserve barrels before new investment raises output, or infrastructure, financing, legal and political constraints may delay or prevent deliveries. Therefore the record describes an announced, counterpart-confirmed framework and a presidential SPR plan—not transferred reserves, completed contracts, a verified gift, delivered oil, a refilled reserve, or lower fuel prices.


## SOURCES

- [Donald Trump — Truth Social announcement of Venezuela oil framework](https://truthsocial.com/@realDonaldTrump/117175567133618952) — primary evidence that Trump published the announcement; claims inside the post require independent verification
- [Reuters — United States and Venezuela announce oil-development framework](https://www.reuters.com/business/energy/us-enters-into-oil-agreement-with-venezuela-trump-says-2026-08-28/) — independent reporting confirming the counterpart announcement, negotiations, unresolved structure, and implementation barriers
- [Associated Press — Trump announces Venezuela oil agreement](https://apnews.com/article/trump-venezuela-oil-reserves-eb0ed5a1e99602c21a7f690c3368020e) — independent reporting on the announced framework and attributed nonpublic structural details
- [Reuters — Venezuela publicly specifies 25-year U.S. energy framework terms](https://www.reuters.com/business/energy/venezuelas-interim-president-says-us-energy-deal-will-last-25-years-2026-08-30/) — independent reporting on the Venezuelan interim president's state-television statement specifying duration, production targets, fields and revenue assumptions
- [Donald Trump — Truth Social statement on Venezuelan oil and the Strategic Petroleum Reserve](https://truthsocial.com/@realDonaldTrump/117184857420534704) — primary evidence that Trump published the SPR plan and gift characterization; claims inside the post require independent verification
- [Reuters — Trump says Venezuelan oil will refill Strategic Petroleum Reserve](https://www.reuters.com/business/energy/trump-says-us-will-refill-strategic-petroleum-reserve-using-venezuelan-oil-2026-08-30/) — independent reporting on the announced SPR plan, reserve level and unresolved delivery timing

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
