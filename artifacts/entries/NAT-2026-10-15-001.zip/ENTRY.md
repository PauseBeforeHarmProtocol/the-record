# HHS publishes six-peptide enforcement-discretion policy text

**Entry ID:** NAT-2026-10-15-001
**Date:** October 15–October 28, 2026
**Checked:** 2026-10-29 12:07 AM EDT
**Evidence state:** Original three-page public-inspection notice and policy pages 1–4 inspected; notice draft/nonbinding language preserved alongside announced interim enforcement intent. Scientific appendices not independently validated.
**Review state:** current-standard-reviewed

Public text replaces the earlier unpublished proposal stage, with conditions, draft/nonbinding language and no FDA approval.

## THE FACTS

- The Office of Information and Regulatory Affairs listed an HHS-FDA submission titled “Interim Access Policy for Compounding Using Certain Peptides,” RIN 0910-ZD94, received October 14 and pending review. The listing classifies the action as a notice and does not supply operative text.
- The official listing establishes that a proposed policy entered White House regulatory review; it does not establish that the notice was cleared, issued or implemented, which substances it would cover, or what legal conditions would apply.
- The Associated Press independently reported the submission and said HHS did not immediately comment. AP described intended enforcement-discretion details using two unnamed people familiar with confidential deliberations; because no second independent confirmation or published text was located, this record does not treat those details or a BPC-157 inclusion as established policy.
- AP reported that Kennedy has argued compounding access could divert consumers from gray-market foreign products, while FDA staff have cited insufficient safety and effectiveness evidence and possible contamination, allergic-reaction and tumor risks for some peptides. Those competing positions frame the proposal; they do not resolve product-specific safety or legality.
- On October 28, HHS filed a notice of availability and posted interim enforcement-policy text covering BPC-157, epitalon, KPV, MOTS-c, semax and TB-500. The notice is scheduled for October 30 Federal Register publication, calls the policy draft and nonbinding, and invites comments for two weeks after publication. This advances beyond the earlier OIRA submission, but is not final 503A-list rulemaking or drug approval.
- The text states that HHS does not intend enforcement against specified compounders meeting conditions including patient-specific prescriptions, identified and tested ingredients, registered manufacturers, safety and quality reporting, labeling and single-active-ingredient products. HHS argues this offers a controlled alternative to research-use-only foreign products and may reconsider for safety or quality signals. The text does not establish clinical safety, effectiveness, actual dispensing or measured harm reduction.

## SIGNIFICANCE

The public text makes the scope and safeguards inspectable rather than relying on confidential descriptions. It changes the announced enforcement posture while leaving final listing decisions, product-specific evidence and realized access or safety outcomes unresolved.

## GOALPOST / RESPONSE

HHS’s strongest explanation is that bounded compounding and traceable ingredients may reduce risks from unregulated foreign research-use products. Its policy retains quality and reporting conditions and the ability to reconsider. Compliance, adverse events, final rulemaking, state oversight and independent product evidence are the tests—not sales or approval inferred from the announcement.

## MAYBE / THEREFORE

Maybe supervised compounding will displace unsafe products, or wider availability will outrun adequate evidence and enforcement capacity. Therefore the archive records published interim policy text with explicit draft/nonbinding limits—not FDA approval, proven efficacy, guaranteed safety or demonstrated implementation.


## SOURCES

- [OIRA — Interim Access Policy for Compounding Using Certain Peptides](https://www.reginfo.gov/public/do/eoReviewSearch?rin=0910-ZD94) — primary regulatory-review listing
- [Associated Press — HHS advances peptide compounding plan](https://apnews.com/article/peptides-kennedy-drugs-trump-bpc157-fb12641dfe791f443f7b7d1eb3bd4a0a) — independent reporting with unnamed-source limits on unpublished policy details
- [HHS — peptide policy notice of availability, FR Doc. 2026-22192](https://public-inspection.federalregister.gov/2026-22192.pdf) — primary public-inspection notice; scheduled October 30 publication
- [HHS — 503A peptide enforcement-discretion policy and appendices](https://www.hhs.gov/sites/default/files/hhs-503a-peptide-enforcement-discretion-policy-appendix-b.pdf) — primary interim enforcement-policy text; not drug approval

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
