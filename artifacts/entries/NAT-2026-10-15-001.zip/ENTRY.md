# FDA sends an interim peptide-compounding access policy to White House review

**Entry ID:** NAT-2026-10-15-001
**Date:** October 15, 2026
**Checked:** 2026-10-15 5:58 PM EDT
**Evidence state:** Official OIRA regulatory-review listing plus AP reporting; proposal and pending-review status verified, unpublished scope and unnamed-source implementation details not accepted as established
**Review state:** current-standard-reviewed

OIRA lists an HHS-FDA notice on access to compounded peptides as pending review; no policy text, covered-product list or implemented enforcement change was public by cutoff.

## THE FACTS

- The Office of Information and Regulatory Affairs listed an HHS-FDA submission titled “Interim Access Policy for Compounding Using Certain Peptides,” RIN 0910-ZD94, received October 14 and pending review. The listing classifies the action as a notice and does not supply operative text.
- The official listing establishes that a proposed policy entered White House regulatory review; it does not establish that the notice was cleared, issued or implemented, which substances it would cover, or what legal conditions would apply.
- The Associated Press independently reported the submission and said HHS did not immediately comment. AP described intended enforcement-discretion details using two unnamed people familiar with confidential deliberations; because no second independent confirmation or published text was located, this record does not treat those details or a BPC-157 inclusion as established policy.
- AP reported that Kennedy has argued compounding access could divert consumers from gray-market foreign products, while FDA staff have cited insufficient safety and effectiveness evidence and possible contamination, allergic-reaction and tumor risks for some peptides. Those competing positions frame the proposal; they do not resolve product-specific safety or legality.

## SIGNIFICANCE

A formal OIRA submission is a concrete proposal stage for a potentially consequential drug-compounding policy, but the absence of public text prevents a reliable account of scope, safeguards or effect. The distinction between regulatory review and implementation is therefore central.

## GOALPOST / RESPONSE

HHS leadership has framed peptide access as a medical-access and gray-market safety issue; FDA staff have emphasized inadequate evidence and potential risks. OIRA clearance, published text, named substances, legal authority, quality controls, adverse-event monitoring, formal rulemaking and measured access and safety outcomes are the tests.

## MAYBE / THEREFORE

Maybe a bounded interim policy could move demand into supervised compounding and reduce unsafe gray-market use, or it could expand access before product-specific safety and effectiveness are established. Therefore a pending OIRA submission is documented; detailed coverage, final terms, implementation and consequences remain unknown.


## SOURCES

- [OIRA — Interim Access Policy for Compounding Using Certain Peptides](https://www.reginfo.gov/public/do/eoReviewSearch?rin=0910-ZD94) — primary regulatory-review listing
- [Associated Press — HHS advances peptide compounding plan](https://apnews.com/article/peptides-kennedy-drugs-trump-bpc157-fb12641dfe791f443f7b7d1eb3bd4a0a) — independent reporting with unnamed-source limits on unpublished policy details

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
