# Joe diGenova resigns from DOJ investigation of officials who scrutinized Trump

**Entry ID:** NAT-2026-09-10-007
**Date:** September 10, 2026
**Checked:** 2026-09-10 11:59 PM EDT
**Evidence state:** direct confirmation to AP and Reuters; resignation established, circumstances undisclosed and unnamed-source causation excluded
**Review state:** current-standard-reviewed

The prosecutor directly confirmed his departure after the inquiry produced no charges; its cause and future remain undisclosed.

## THE FACTS

- Joe diGenova directly confirmed to the Associated Press and Reuters on September 10 that he resigned from his Justice Department role leading an investigation of former law-enforcement and intelligence officials who had scrutinized Trump.
- The inquiry encompassed matters connected to Russian interference in the 2016 election, Trump's retention of classified documents and efforts to overturn the 2020 election. AP and Reuters reported that it had produced no criminal charges after about one year.
- DiGenova did not tell either outlet why he resigned. Reports attributing his departure to dissatisfaction inside the White House or Justice Department depended on unnamed sourcing and are not presented here as established causation.
- DiGenova called serving an honor and said separately that evidence existed and cases take time to build. Reuters reported that the Justice Department did not immediately comment. His resignation does not establish that the investigation has ended, that charges will follow, or that any target committed a crime.

## SIGNIFICANCE

The departure is a material lifecycle event in a politically consequential Justice Department inquiry aimed at officials who investigated the president. It heightens oversight questions about leadership, evidence and prosecutorial independence without proving improper motive by either the investigators or the investigation's targets.

## GOALPOST / RESPONSE

DiGenova said evidence exists and careful cases take time. A named successor, filed charges supported by disclosed evidence, closure documentation, inspector-general or congressional review and court rulings are the tests; a resignation alone is not a merits finding.

## MAYBE / THEREFORE

Maybe a leadership change allows an evidence-based inquiry to continue, or the absence of charges and unexplained resignation may reflect evidentiary or management problems. Therefore the verified event is diGenova's resignation and the inquiry's no-charge status at cutoff—not proof of a conspiracy, retaliation, misconduct or termination of the probe.


## SOURCES

- [AP — Joe diGenova confirms resignation from DOJ investigation](https://apnews.com/article/5741c227d76e813c01923df943b8544e) — independent reporting with direct confirmation from the subject
- [Reuters — Prosecutor overseeing probe of Trump foes resigns](https://www.reuters.com/legal/government/us-prosecutor-overseeing-probe-trump-foes-resigns-2026-09-10/) — independent reporting with direct confirmation from the subject

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
