# DOJ inquiry remains unresolved after lead prosecutor and national-security chief resign

**Entry ID:** NAT-2026-09-10-007
**Date:** September 10–November 6, 2026
**Checked:** 2026-11-07 12:07 PM EST
**Evidence state:** directly attributed resignation statements and attorney-general responses plus independently corroborated reporting on investigation posture; departures confirmed, reasons and future of inquiry unresolved
**Review state:** current-standard-reviewed

Jason Reding Quiñones and John Eisenberg resigned; DOJ praised their service and had said the politically charged inquiry would continue, while no overarching conspiracy charge had been filed by cutoff.

## THE FACTS

- Joe diGenova directly confirmed to the Associated Press and Reuters on September 10 that he resigned from his Justice Department role leading an investigation of former law-enforcement and intelligence officials who had scrutinized Trump.
- The inquiry encompassed matters connected to Russian interference in the 2016 election, Trump's retention of classified documents and efforts to overturn the 2020 election. AP and Reuters reported that it had produced no criminal charges after about one year.
- Associated Press, Reuters and The Washington Post separately reported on September 28 that Kurt Olsen resigned from the same Justice Department investigation. Every outlet's departure account relied on unnamed sources; Reuters also reported that a third source said Olsen still worked for the department, so the record describes the resignation as reported rather than officially confirmed.
- The Washington Post quoted the Justice Department saying leadership had full confidence in the Southern District of Florida team, that work on the investigation continued and that its attorney team continued to grow. The statement did not directly confirm Olsen's personnel status.
- The outlets reported conflicting explanations involving investigative pace, management frustration or a security-clearance issue. Those anonymously sourced causal accounts are not treated as established. AP reported no criminal charges had resulted by publication, and the staffing changes do not establish that the inquiry ended or that any target committed a crime.
- On October 15, U.S. District Judge Jia Cobb dismissed Brennan’s separate lawsuit seeking an order requiring DOJ to preserve records for a potential future selective- or vindictive-prosecution defense. She found the asserted injury too speculative and attenuated to establish standing and said Brennan had not shown DOJ was failing to preserve relevant records.
- The dismissal did not decide whether a future prosecution would be vindictive. Associated Press reported that Brennan had not been charged, remained a target of a false-statements inquiry and had been subpoenaed in the broader investigation; he denies wrongdoing. Any appeal, charges or later preservation dispute remained unresolved at cutoff.
- On November 6, U.S. Attorney Jason Reding Quiñones, whose Southern District of Florida office was overseeing the so-called grand-conspiracy inquiry, resigned. Associated Press and CBS News reported the resignation, Attorney General Todd Blanche publicly praised his service, and Quiñones thanked Trump and the district's staff; the public statements did not give a reason for his departure.
- Blanche also confirmed that Assistant Attorney General John Eisenberg, who led DOJ's National Security Division, resigned the same day. That separate leadership departure is relevant to the department's investigative capacity but does not itself establish a change in the inquiry's legal status.
- CBS News reported that the investigation had generated extensive grand-jury activity but no charge establishing the alleged overarching conspiracy. Blanche had said in late October that the investigation would continue, that Quiñones remained in charge and that there was no frustration with its pace. The later resignation changes leadership, not the evidentiary status of the allegations.

## SIGNIFICANCE

The confirmed departures add a senior leadership transition to an inquiry already marked by prosecutor turnover and unresolved evidentiary questions. They do not establish why either official left, that the investigation ended, that charges are warranted or that any target committed a crime.

## GOALPOST / RESPONSE

Attorney General Todd Blanche praised Quiñones and Eisenberg and had said in late October that the investigation would continue and that he was not frustrated with its pace. Quiñones thanked Trump and the district's staff. Filed charges supported by disclosed evidence, formal closure or reassignment documentation, preservation compliance, appellate review and independent oversight remain the tests.

## MAYBE / THEREFORE

Maybe the resignations are ordinary post-election turnover and the inquiry can continue under new leadership, or the accumulated departures may reflect deeper evidentiary or management problems. Therefore two senior resignations and the absence of an overarching conspiracy charge are established; motives, future staffing, investigative viability and the truth of the alleged conspiracy remain unresolved.


## SOURCES

- [AP — Joe diGenova confirms resignation from DOJ investigation](https://apnews.com/article/5741c227d76e813c01923df943b8544e) — independent reporting with direct confirmation from the subject
- [Reuters — Prosecutor overseeing probe of Trump foes resigns](https://www.reuters.com/legal/government/us-prosecutor-overseeing-probe-trump-foes-resigns-2026-09-10/) — independent reporting with direct confirmation from the subject
- [AP — Second prosecutor reportedly resigns from DOJ grand-conspiracy probe](https://apnews.com/article/ddc68873796154266b3f09d2b685b0a5) — independent reporting based on a person familiar with the matter
- [Reuters — Former White House election official reportedly leaves DOJ probe](https://www.reuters.com/world/us/ex-white-house-election-official-leaves-doj-probe-trump-foes-sources-say-2026-09-29/) — independent reporting based on multiple sources, including a conflicting employment-status account
- [Washington Post — DOJ probe into Trump foes sees another prominent departure](https://www.washingtonpost.com/national-security/2026/09/28/doj-probe-into-trump-foes-sees-another-prominent-departure/) — independent reporting based on three people familiar with the matter and a named Justice Department response
- [Brennan v. Blanche docket](https://www.courtlistener.com/docket/73562893/brennan-v-blanche/) — case docket
- [Associated Press — judge dismisses Brennan preservation lawsuit](https://apnews.com/article/brennan-cia-justice-department-b270554efce62124cd8a6644b3ec56e5) — independent reporting of district-court dismissal
- [Washington Post — Brennan preservation suit dismissed](https://www.washingtonpost.com/politics/2026/10/15/judge-dismisses-ex-cia-director-john-brennans-lawsuit-against-doj/) — independent reporting of district-court dismissal
- [Associated Press — two Justice Department officials resign](https://apnews.com/article/justice-department-resignations-grand-conspiracy-florida-jason-quinones-9a10b4ffcb620edb3c2298cec066062d) — independent reporting on confirmed resignations, investigation posture and official responses
- [Reuters — Quiñones and Eisenberg resign from Justice Department](https://www.streetinsider.com/Reuters/Two+top+Justice+Department+officials+resign+as+post-election+exodus+accelerates/27306245.html) — independent wire reporting on confirmed resignations and investigation context
- [CBS News — Quiñones resigns amid questions about grand-conspiracy probe](https://www.cbsnews.com/news/doj-jason-reding-quinones-resigns-grand-conspiracy-probe/) — independent reporting on resignation, investigation status and named DOJ response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
