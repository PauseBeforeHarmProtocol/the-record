# Second prosecutor reportedly resigns from DOJ investigation of officials who scrutinized Trump

**Entry ID:** NAT-2026-09-10-007
**Date:** September 10–28, 2026
**Checked:** 2026-09-29 5:58 AM EDT
**Evidence state:** diGenova directly confirmed his earlier resignation; Olsen's departure is separately reported by AP, Reuters and The Washington Post through unnamed sources, with Reuters noting a conflicting employment-status account and DOJ saying the investigation continues
**Review state:** current-standard-reviewed

Three independent outlets report Kurt Olsen left after Joe diGenova; the resignation remains anonymously sourced, its cause is disputed and the investigation continues.

## THE FACTS

- Joe diGenova directly confirmed to the Associated Press and Reuters on September 10 that he resigned from his Justice Department role leading an investigation of former law-enforcement and intelligence officials who had scrutinized Trump.
- The inquiry encompassed matters connected to Russian interference in the 2016 election, Trump's retention of classified documents and efforts to overturn the 2020 election. AP and Reuters reported that it had produced no criminal charges after about one year.
- Associated Press, Reuters and The Washington Post separately reported on September 28 that Kurt Olsen resigned from the same Justice Department investigation. Every outlet's departure account relied on unnamed sources; Reuters also reported that a third source said Olsen still worked for the department, so the record describes the resignation as reported rather than officially confirmed.
- The Washington Post quoted the Justice Department saying leadership had full confidence in the Southern District of Florida team, that work on the investigation continued and that its attorney team continued to grow. The statement did not directly confirm Olsen's personnel status.
- The outlets reported conflicting explanations involving investigative pace, management frustration or a security-clearance issue. Those anonymously sourced causal accounts are not treated as established. AP reported no criminal charges had resulted by publication, and the staffing changes do not establish that the inquiry ended or that any target committed a crime.

## SIGNIFICANCE

Two reported departures from a politically consequential Justice Department inquiry raise material questions about leadership, evidence and prosecutorial independence. Multiple independent reports strengthen the personnel finding while leaving motive, employment status and the investigation's merits unresolved.

## GOALPOST / RESPONSE

The Justice Department says the Southern District of Florida team retains leadership's confidence and continues its work. Direct personnel confirmation, a named successor, filed charges supported by disclosed evidence, closure documentation, inspector-general or congressional review and court rulings are the tests.

## MAYBE / THEREFORE

Maybe ordinary staffing changes leave an evidence-based investigation intact, or repeated unexplained departures may reflect management, clearance or evidentiary problems. Therefore the record supports a second reported resignation and a continuing investigation—not a proven conspiracy, confirmed causal account, termination of the probe or guilt by any target.


## SOURCES

- [AP — Joe diGenova confirms resignation from DOJ investigation](https://apnews.com/article/5741c227d76e813c01923df943b8544e) — independent reporting with direct confirmation from the subject
- [Reuters — Prosecutor overseeing probe of Trump foes resigns](https://www.reuters.com/legal/government/us-prosecutor-overseeing-probe-trump-foes-resigns-2026-09-10/) — independent reporting with direct confirmation from the subject
- [AP — Second prosecutor reportedly resigns from DOJ grand-conspiracy probe](https://apnews.com/article/ddc68873796154266b3f09d2b685b0a5) — independent reporting based on a person familiar with the matter
- [Reuters — Former White House election official reportedly leaves DOJ probe](https://www.reuters.com/world/us/ex-white-house-election-official-leaves-doj-probe-trump-foes-sources-say-2026-09-29/) — independent reporting based on multiple sources, including a conflicting employment-status account
- [Washington Post — DOJ probe into Trump foes sees another prominent departure](https://www.washingtonpost.com/national-security/2026/09/28/doj-probe-into-trump-foes-sees-another-prominent-departure/) — independent reporting based on three people familiar with the matter and a named Justice Department response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
