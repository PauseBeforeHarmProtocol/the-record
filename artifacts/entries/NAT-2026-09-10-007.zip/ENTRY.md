# DOJ inquiry continues after prosecutor departures and Brennan preservation-suit dismissal

**Entry ID:** NAT-2026-09-10-007
**Date:** September 10–October 15, 2026
**Checked:** 2026-10-15 11:57 PM EDT
**Evidence state:** Prior direct and independently corroborated staffing evidence plus AP and Washington Post reporting of the October 15 district-court dismissal; standing and preservation relief resolved at district-court level, underlying investigations and vindictive-prosecution allegations unresolved
**Review state:** current-standard-reviewed

A district judge found Brennan lacked standing for a pre-charge preservation order; the court did not resolve his vindictive-prosecution allegations, and DOJ says the broader inquiry continues.

## THE FACTS

- Joe diGenova directly confirmed to the Associated Press and Reuters on September 10 that he resigned from his Justice Department role leading an investigation of former law-enforcement and intelligence officials who had scrutinized Trump.
- The inquiry encompassed matters connected to Russian interference in the 2016 election, Trump's retention of classified documents and efforts to overturn the 2020 election. AP and Reuters reported that it had produced no criminal charges after about one year.
- Associated Press, Reuters and The Washington Post separately reported on September 28 that Kurt Olsen resigned from the same Justice Department investigation. Every outlet's departure account relied on unnamed sources; Reuters also reported that a third source said Olsen still worked for the department, so the record describes the resignation as reported rather than officially confirmed.
- The Washington Post quoted the Justice Department saying leadership had full confidence in the Southern District of Florida team, that work on the investigation continued and that its attorney team continued to grow. The statement did not directly confirm Olsen's personnel status.
- The outlets reported conflicting explanations involving investigative pace, management frustration or a security-clearance issue. Those anonymously sourced causal accounts are not treated as established. AP reported no criminal charges had resulted by publication, and the staffing changes do not establish that the inquiry ended or that any target committed a crime.
- On October 15, U.S. District Judge Jia Cobb dismissed Brennan’s separate lawsuit seeking an order requiring DOJ to preserve records for a potential future selective- or vindictive-prosecution defense. She found the asserted injury too speculative and attenuated to establish standing and said Brennan had not shown DOJ was failing to preserve relevant records.
- The dismissal did not decide whether a future prosecution would be vindictive. Associated Press reported that Brennan had not been charged, remained a target of a false-statements inquiry and had been subpoenaed in the broader investigation; he denies wrongdoing. Any appeal, charges or later preservation dispute remained unresolved at cutoff.

## SIGNIFICANCE

The court’s dismissal closes one attempted pre-charge safeguard while leaving the politically consequential Justice Department inquiries and their evidentiary merits unresolved. The staffing departures and preservation ruling together sharpen questions about prosecutorial independence without proving either misconduct or innocence.

## GOALPOST / RESPONSE

The Justice Department says the Southern District of Florida team continues its work; Brennan denies wrongdoing and alleges political retaliation. Filed charges supported by disclosed evidence, preservation compliance, appellate review, direct personnel confirmation, closure documentation or independent oversight are the tests.

## MAYBE / THEREFORE

Maybe ordinary staffing changes and a premature preservation suit say little about an evidence-based inquiry, or the pattern may reflect institutional and political pressure. Therefore the record supports two reported prosecutor departures, continuing investigations and a standing-based dismissal—not a merits rejection of Brennan’s retaliation claim, proof of a conspiracy or proof that records will be lost.


## SOURCES

- [AP — Joe diGenova confirms resignation from DOJ investigation](https://apnews.com/article/5741c227d76e813c01923df943b8544e) — independent reporting with direct confirmation from the subject
- [Reuters — Prosecutor overseeing probe of Trump foes resigns](https://www.reuters.com/legal/government/us-prosecutor-overseeing-probe-trump-foes-resigns-2026-09-10/) — independent reporting with direct confirmation from the subject
- [AP — Second prosecutor reportedly resigns from DOJ grand-conspiracy probe](https://apnews.com/article/ddc68873796154266b3f09d2b685b0a5) — independent reporting based on a person familiar with the matter
- [Reuters — Former White House election official reportedly leaves DOJ probe](https://www.reuters.com/world/us/ex-white-house-election-official-leaves-doj-probe-trump-foes-sources-say-2026-09-29/) — independent reporting based on multiple sources, including a conflicting employment-status account
- [Washington Post — DOJ probe into Trump foes sees another prominent departure](https://www.washingtonpost.com/national-security/2026/09/28/doj-probe-into-trump-foes-sees-another-prominent-departure/) — independent reporting based on three people familiar with the matter and a named Justice Department response
- [Brennan v. Blanche docket](https://www.courtlistener.com/docket/73562893/brennan-v-blanche/) — case docket
- [Associated Press — judge dismisses Brennan preservation lawsuit](https://apnews.com/article/brennan-cia-justice-department-b270554efce62124cd8a6644b3ec56e5) — independent reporting of district-court dismissal
- [Washington Post — Brennan preservation suit dismissed](https://www.washingtonpost.com/politics/2026/10/15/judge-dismisses-ex-cia-director-john-brennans-lawsuit-against-doj/) — independent reporting of district-court dismissal

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
