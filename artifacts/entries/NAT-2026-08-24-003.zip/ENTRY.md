# Treasury sanctions nearly 60 Iran-linked targets and broadens its secondary-sanctions warning

**Entry ID:** NAT-2026-08-24-003
**Date:** August 24, 2026
**Checked:** 2026-08-24 5:58 PM EDT
**Evidence state:** implemented Treasury designations corroborated by AP and Reuters; broader secondary sanctions announced as a warning, not yet imposed

The designations took effect; threatened penalties against major third-country trading partners had not yet been imposed.

## THE FACTS

- The Treasury Department imposed sanctions on nearly 60 people, entities, and vessels tied to Iran's nuclear, missile, cyber, oil, brokerage, and shadow-fleet networks across several foreign jurisdictions.
- Treasury identified digital assets, technology, gold, aviation, and shipping as sectors that could face secondary sanctions and warned countries and businesses to wind down identified Iran-related activity.
- Treasury Secretary Scott Bessent did not announce secondary penalties against Iran's major foreign trading partners. He said countries would receive time to disengage, leaving those broader penalties warned or proposed rather than implemented at the checked time.

## SIGNIFICANCE

The blocked targets face immediate U.S. financial restrictions, while the wider warning could have much larger effects if Treasury later penalizes foreign banks, refiners, carriers, or governments. Keeping those two stages separate is necessary to measure both enforcement and effects on Iranian revenue, global finance, and energy markets.

## GOALPOST / RESPONSE

The administration says the campaign is intended to sever Iran's revenue and financial access while allowing other countries time to disengage without destabilizing the global financial system. Iranian parliamentary speaker Mohammad Bagher Qalibaf said Iran's trading partners were not taking the threats seriously. Follow-on designations, actual secondary penalties, trade flows, and Iranian revenue are the evidence tests.


## SOURCES

- [Associated Press — implemented Iran sanctions and secondary-sanctions warning](https://apnews.com/article/iran-rial-currency-bessent-trade-august-24-2026-e367634d8853c8fa4a341132cd577f31) — independent reporting from the Treasury announcement and press conference
- [Reuters — Treasury designations and broadened secondary-sanctions threat](https://www.reuters.com/world/middle-east/us-treasury-broaden-scope-secondary-sanctions-iran-source-says-2026-08-24/) — independent reporting on implemented designations and announced future enforcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
