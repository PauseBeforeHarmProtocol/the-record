# DOT finalizes individualized review for disadvantaged-business programs

**Entry ID:** NAT-2026-09-25-001
**Date:** September 25, 2026
**Checked:** 2026-09-25 11:59 AM EDT
**Evidence state:** primary Federal Register final rule; effective September 25, 2026, with agency burden estimates and predicted effects not yet measured
**Review state:** current-standard-reviewed

The effective final rule removes race- and sex-based presumptions and requires individualized disadvantage narratives for applicants and currently certified firms.

## THE FACTS

- The Department of Transportation published a final rule effective September 25 that finalizes, with modifications, its October 2025 interim revisions to the Disadvantaged Business Enterprise and Airport Concession Disadvantaged Business Enterprise programs.
- The rule eliminates presumptions of social and economic disadvantage based on race or sex. Applicants and owners of currently certified firms must establish disadvantage through individualized evidence, including a personal narrative and personal net-worth information; failure to complete reevaluation can lead to removal from the program.
- DOT says the change responds to constitutional requirements and preserves a need-based program open to people of any race or sex. Critics cited in the rule said the individualized process imposes burdens and may reduce participation; the final rule records those objections rather than resolving their predicted effects.
- DOT estimates one-time preparation burdens of about 820,000 hours and $31.9 million for roughly 41,000 firms, plus about 82,000 hours and $4.1 million for certifying authorities. Those are agency estimates, not measured compliance costs or participation outcomes.

## SIGNIFICANCE

The rule changes the eligibility mechanism for federally assisted transportation and airport-concession programs immediately, replacing categorical presumptions with owner-specific proof and requiring reevaluation of existing certifications.

## GOALPOST / RESPONSE

DOT says individualized review is constitutionally required and better targets assistance to owners who can prove disadvantage. Program participation, reevaluation outcomes, processing times, appeals, contract awards and measured compliance costs are the tests.

## MAYBE / THEREFORE

Maybe individualized review will make the programs more legally durable and precisely targeted, or documentation burdens may exclude eligible firms and slow awards. Therefore the rule implements a new proof standard; it does not establish either improved fairness or reduced participation.


## SOURCES

- [Disadvantaged Business Enterprise and Airport Concession Disadvantaged Business Enterprise Program Implementation Modifications](https://www.govinfo.gov/content/pkg/FR-2026-09-25/pdf/2026-19688.pdf) — primary final rule; 91 FR 60904; effective September 25, 2026

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
