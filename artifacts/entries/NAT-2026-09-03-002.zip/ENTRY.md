# SEC and CFTC delay revised private-fund reporting to July 2027

**Entry ID:** NAT-2026-09-03-002
**Date:** September 3, 2026
**Checked:** 2026-09-03 12:03 PM EDT
**Evidence state:** primary SEC-CFTC joint final rule and CFTC announcement; compliance date legally extended to July 1, 2027, underlying reporting and reconsideration proceeding continue
**Review state:** current-standard-reviewed

The immediately effective joint final rule postpones compliance with 2024 Form PF amendments by nine months while the agencies reconsider them; existing reporting continues.

## THE FACTS

- The Securities and Exchange Commission and Commodity Futures Trading Commission issued an immediately effective joint final rule extending the compliance date for 2024 Form PF amendments from October 1, 2026, to July 1, 2027.
- Form PF is a confidential report filed by certain SEC-registered private-fund advisers, including advisers to hedge, private-equity and liquidity funds; some filers are also registered with the CFTC. The extension postpones the revised requirements but does not repeal Form PF or end existing reporting.
- The agencies said the delay would avoid costs associated with changing systems for requirements that may be removed or modified through a separate 2026 proposal. They classified the extension as a deregulatory action under Executive Order 14192.
- The final rule also acknowledges that delay postpones the benefits of the new information to the SEC and Financial Stability Oversight Council for systemic-risk monitoring and investor protection. The future amendments and their costs or information benefits remain under review.

## SIGNIFICANCE

The extension gives private-fund advisers nine additional months before revised confidential reporting is required, reducing near-term compliance work while delaying regulators' access to data designed for systemic-risk and investor-protection oversight. It implements a timing change, not a substantive repeal of the reporting system.

## GOALPOST / RESPONSE

The agencies say firms should not bear implementation costs for requirements under active reconsideration; the final rule itself acknowledges delayed oversight benefits. The outcome of the separate amendment proposal, actual compliance costs, data quality, filing behavior, FSOC use and any further extension or repeal are the tests.

## MAYBE / THEREFORE

Maybe the delay will prevent wasteful systems work while producing a more durable reporting design, or it may leave regulators with less timely information during a period of private-fund risk. Therefore the record confirms an operative nine-month compliance extension—not cancellation of Form PF, removal of current filing duties or evidence that the delayed data are unnecessary.


## SOURCES

- [SEC and CFTC — further extension of Form PF compliance date](https://www.federalregister.gov/documents/2026/09/03/2026-18104/form-pf-reporting-requirements-for-all-filers-and-large-hedge-fund-advisers-further-extension-of) — primary joint final rule immediately extending compliance with the 2024 Form PF amendments
- [CFTC — agencies extend Form PF compliance date to July 1, 2027](https://www.cftc.gov/PressRoom/PressReleases/9290-26) — primary agency announcement of the joint final rule and stated cost-avoidance rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
