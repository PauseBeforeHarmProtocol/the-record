# USDA announces plans for up to $472.5 million in domestic food purchases

**Entry ID:** NAT-2026-10-29-006
**Date:** October 29, 2026
**Checked:** 2026-11-01 4:03 PM EST
**Evidence state:** original USDA announcement and AMS procurement notice, independent AP corroboration, and a separately attributed food-bank stakeholder response; announced intent, with actual awards/payments/deliveries unverified
**Review state:** current-standard-reviewed

Section 32 purchase intentions would support producers and nutrition-assistance networks; the announced ceiling is not completed spending or delivered food.

## THE FACTS

- On October 29, USDA announced its intent to purchase up to $472.5 million in American-grown and American-raised agricultural commodities for the charitable food network and other nutrition-assistance programs. Associated Press independently reported the announcement in its November 1 review of agricultural support. The amount is an announced purchase ceiling, not a verified total of awarded contracts, payments or deliveries.
- USDA's Agricultural Marketing Service said the purchases would use Section 32 authority and that solicitations would be issued in the near future through its Web-Based Supply Chain Management system. The notice anticipates firm-fixed-price contracts and requires domestic agricultural products. Actual solicitations, awards, obligations and deliveries were not inspected in this review.
- The announcement's commodity allocations include $165.5 million for dairy, $41 million for pork and $21 million for rice. These are components of the announced $472.5 million plan, not additional appropriations or verified expenditures.

## SIGNIFICANCE

The planned federal purchases could support agricultural markets and supply food-assistance organizations at national scale. Accountability depends on transparent contract awards, actual obligations, deliveries and nutrition outcomes rather than treating a maximum announcement as completed relief.

## GOALPOST / RESPONSE

USDA says Section 32 purchases can steady disrupted agricultural markets, support rural supply-chain jobs and move domestic food to people in need. Feeding America welcomed the announced plan as support for producers and food banks. That is the strongest documented supporting case; it does not establish the size or timing of completed benefits.

## MAYBE / THEREFORE

Maybe targeted domestic-food purchases provide useful producer support and nutrition assistance, while temporary market interventions may leave broader farm-cost and hunger pressures unresolved. Therefore this record establishes an announced procurement plan, not completed spending, delivered meals, measured market stabilization or any electoral effect; contracts and delivery/outcome records remain the tests.


## SOURCES

- [USDA — announced up-to-$472.5 million domestic food purchase plan](https://www.usda.gov/about-usda/news/press-releases/2026/10/29/usda-announces-4725-million-food-purchase-support-us-producers-and-strengthen-americas-food-supply) — primary announcement, Release 0148.26; intent and proposed commodity allocations
- [USDA AMS — Section 32 commodity procurement notice](https://www.ams.usda.gov/content/announcement-section-32-purchases-chicken-dairy-fish-fruit-pork-pulses-rice-and-tree-nut) — primary trade notice; forthcoming solicitations, anticipated contract form and domestic-product requirements
- [AP — agricultural support review corroborating October 29 commodity-purchase announcement](https://apnews.com/article/farmers-ranchers-midterms-agriculture-payments-trump-113757ded4631a2debfa184a36c4d85e) — independent reporting by Sarah Raza; procurement paragraph, not a new combined appropriation
- [Feeding America — response to announced domestic food purchases](https://www.feedingamerica.org/about-us/press-room/feeding-america-thanks-usda-4725-million-investment-american-grown-food) — primary stakeholder response; not independent confirmation of contract awards or delivery

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
