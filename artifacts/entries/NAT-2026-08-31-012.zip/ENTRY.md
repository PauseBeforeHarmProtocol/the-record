# Trump asks Congress for a federal film and television production incentive

**Entry ID:** NAT-2026-08-31-012
**Date:** August 31, 2026
**Checked:** 2026-09-01 12:03 AM EDT
**Evidence state:** primary Trump publication establishing the announced request, corroborated and contextualized by Reuters reporting; proposal announced, legislative text, enactment, cost and outcomes unresolved
**Review state:** current-standard-reviewed

The president endorsed an unspecified federal production incentive after meeting Jon Voight; no bill, enacted credit, appropriation or official cost estimate existed by cutoff.

## THE FACTS

- Trump published a Truth Social statement saying he would ask Republicans and Democrats to craft legislation and that Congress should approve a federal production incentive for film and television work in the United States.
- Reuters independently reported the presidential request and said Trump made it after meeting actor and administration Hollywood ambassador Jon Voight. The announcement is a legislative proposal, not enacted tax law or an executive action creating a credit.
- Trump's statement did not specify a credit rate, eligibility formula, duration, budget cap, funding source or administering agency. Reuters reported that Voight's representatives had separately proposed a 20% federal credit for U.S. production labor costs; that outside proposal is not treated as the president's adopted term.
- Reuters reported that a coalition including the Motion Picture Association, Directors Guild of America and entertainment unions supports a national incentive. Motion Picture Association chief Charles Rivkin said the group would work with the White House and bipartisan congressional leaders to enact one.
- Trump said an incentive would restore domestic production and jobs and asserted that resulting revenue would repay its cost tenfold. No congressional score, introduced bill, enacted appropriation, production response or measured revenue effect substantiated that projection by cutoff.

## SIGNIFICANCE

A presidential endorsement can increase the prospects for a federal subsidy or tax credit affecting where film and television work is performed, but Congress controls whether any incentive becomes law and its fiscal and distributional terms. The proposal could shift production decisions and federal revenue if enacted; none of those effects has yet occurred.

## GOALPOST / RESPONSE

Trump and industry supporters say foreign and state incentives have pulled production and jobs away from the United States and that a national incentive would rebuild the domestic industry and eventually pay for itself. Critics may question whether a broad credit would subsidize projects that would have been produced domestically anyway or deliver benefits commensurate with its cost. Introduced bipartisan bill text, a budget score, committee action, enactment, Treasury or IRS implementation, qualifying production levels, employment data and tax expenditure estimates are the tests.

## MAYBE / THEREFORE

Maybe bipartisan industry support will turn the announcement into a targeted, measurable credit, or the request may remain rhetoric without agreed terms, offsets or congressional votes. Therefore the record treats this as an announced presidential request for legislation—not an enacted tax incentive, committed expenditure, guaranteed production return or demonstrated tenfold fiscal gain.


## SOURCES

- [Donald Trump Truth Social post requesting federal film and television production legislation](https://truthsocial.com/@realDonaldTrump/117192406705033763) — primary evidence that Trump announced a legislative request and his stated rationale, not evidence that Congress enacted an incentive or that projected returns will occur
- [Reuters — Trump urges Congress to pass an entertainment-production incentive](https://www.reuters.com/world/trump-urges-congress-pass-tax-incentives-entertainment-industry-2026-08-31/) — independent reporting on the announced legislative request, industry support and distinction between Trump's unspecified request and advocates' 20% proposal

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
