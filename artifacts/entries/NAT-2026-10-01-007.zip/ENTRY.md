# Federal Medicaid eligibility restriction takes effect for many legal immigrants

**Entry ID:** NAT-2026-10-01-007
**Date:** October 1–10, 2026
**Checked:** 2026-10-10 11:58 PM EDT
**Evidence state:** operative federal statute and detailed CMS implementation guidance plus AP reporting on state counts and KFF's cross-state estimate; restriction implemented October 1, with complete national disenrollment and outcome measurement unresolved
**Review state:** current-standard-reviewed

States began applying a 2025 law that ends federal matching funds for full Medicaid and CHIP coverage for many refugees, asylees, parolees and trafficking survivors; emergency care and specified groups remain eligible.

## THE FACTS

- Section 71109 of Public Law 119-21 added Social Security Act section 1903(v)(5). Beginning October 1, 2026, federal matching funds for full Medicaid and CHIP benefits are generally limited to U.S. citizens and nationals, lawful permanent residents, Cuban and Haitian entrants, and people covered by Compacts of Free Association, subject to statutory exceptions.
- CMS guidance required states to apply the new federal-funding limits to applicants and people enrolled on October 1. It identifies refugees, asylees, humanitarian parolees and trafficking victims among the qualified noncitizens who can lose federally matched full benefits unless they also hold another eligible status. CMS said states may use state-only programs, but it will not treat those programs as Medicaid or CHIP.
- The law preserves federal matching for emergency Medicaid, the state option covering lawfully residing children and pregnant people, and CHIP Health Services Initiatives. Lawful permanent residents remain subject to existing five-year-wait rules unless an exception applies; the change is not a termination of every immigrant's Medicaid eligibility.
- Associated Press reported on October 10 that Arizona had removed about 29,000 legal immigrants and Florida estimated about 177,000 affected people. AP cited KFF estimates that more than 281,000 immigrants across nine states and the District of Columbia would lose coverage. Those figures are state reports and an estimate, not a complete national audited disenrollment count.
- CMS Administrator Mehmet Oz said the guidance carries out Congress's mandate and safeguards taxpayer-funded programs. The White House told AP that immigrants should support themselves without drawing on overburdened benefit programs. Advocates told AP that affected people may delay care or rely on emergency rooms; those projected consequences require outcome measurement.

## SIGNIFICANCE

The statutory implementation removed comprehensive federally matched health coverage from many people lawfully present for humanitarian reasons, while shifting any continuation outside Medicaid or CHIP onto state-only funding. Early state counts show a large immediate coverage effect, but the national total and health, budget and emergency-care consequences remain unsettled.

## GOALPOST / RESPONSE

The administration says the restriction protects federal resources and enforces the 2025 law. The tests are verified state disenrollment counts, error and appeal rates, state-only replacement coverage, emergency-care use, continuity of treatment, uncompensated-care costs, federal and state spending, and any litigation or legislative change.

## MAYBE / THEREFORE

Maybe narrowing federally funded eligibility reduces federal spending and encourages self-sufficiency as the administration argues, or it may shift costs to states, hospitals and families while interrupting necessary care for lawfully present people. Therefore the record establishes an implemented federal funding and eligibility restriction with substantial early state effects—not a ban on emergency care, loss of coverage for every legal immigrant, a final national count or a measured long-term health outcome.


## SOURCES

- [U.S. Code — Social Security Act section 1903(v)(5) noncitizen funding limits](https://uscode.house.gov/view.xhtml?edition=prelim&f=treesort&fq=true&granuleId=USC-prelim-title42-section1396b&hl=true&num=1070&req=alien) — codified federal statute
- [CMS — implementation of section 71109 noncitizen Medicaid eligibility](https://www.hhs.gov/guidance/sites/default/files/hhs-guidance-documents/AID/sho26001.pdf) — official state health officer implementation guidance
- [CMS — guidance on federal Medicaid and CHIP funding limits for certain noncitizens](https://www.cms.gov/newsroom/press-releases/cms-issues-guidance-implement-new-limits-federal-medicaid-chip-funding-certain-noncitizens) — official press release and administration explanation
- [KFF — implementation of Medicaid immigrant eligibility restrictions](https://www.kff.org/immigrant-health/implementation-of-medicaid-immigrant-eligibility-restrictions-under-the-2025-reconciliation-law-issues-to-consider/) — independent policy analysis of eligibility scope, exceptions and implementation
- [Associated Press — legal immigrants lose Medicaid coverage after October 1 restriction](https://apnews.com/article/medicaid-cuts-immigrants-refugees-trump-crackdown-0b567c75189f35dded65dfe623cef668) — independent reporting on implementation, state counts and administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
