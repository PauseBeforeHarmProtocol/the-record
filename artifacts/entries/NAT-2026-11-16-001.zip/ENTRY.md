# Commerce imposes remote-compute and expanded advanced-chip export controls

**Entry ID:** NAT-2026-11-16-001
**Date:** November 16, 2026
**Checked:** 2026-11-16 12:08 PM EST
**Evidence state:** primary BIS interim final rule plus independent Reuters reporting; finalized for immediate effectiveness on Federal Register publication, with a 60-day post-publication comment period and operational effects unmeasured
**Review state:** current-standard-reviewed

The interim final rule restricts high-volume remote computing for specified countries of concern and adds licenses for advanced-chip shipments to five diversion-risk countries; it becomes effective on publication.

## THE FACTS

- The Commerce Department's Bureau of Industry and Security issued an interim final rule restricting overseas data centers from supplying significant volumes of advanced U.S.-technology computing power to companies headquartered, or ultimately parented, in Macau or Country Group D:5 countries. The rule is final for immediate effectiveness on Federal Register publication rather than merely proposed.
- The rule requires data centers, foundries and exporters to perform customer due diligence, including indirect ownership or control, and requires existing covered data centers that want to continue service to obtain a license within 90 days of the effective date. Commercial recommender systems used by online retailers and social-media companies are excluded from the remote-compute license requirement.
- BIS also adds license requirements for covered advanced semiconductors to Indonesia, Malaysia, Singapore, Thailand and Brazil, subject to stated exclusions, and formally rescinds the never-enforced Biden-era AI Diffusion Rule. Applications under the new remote-compute control will be reviewed case by case.
- Commerce says the rule is intended to prevent countries of concern from circumventing physical chip controls through third-country cloud computing. Reuters independently reported the rule and its China-diversion context; the inspected record does not yet measure licenses, denied transactions, compliance cost, diversion reduction or effects on legitimate cloud customers.
- The rule was issued without advance notice and comment under the Export Control Reform Act exemption; BIS will accept comments for 60 days after publication. Post-publication comments may inform later changes but do not suspend the rule's effective status.

## SIGNIFICANCE

The action extends export controls from physical chip transfers into access to computing power and broadens country-level licensing, materially affecting data centers, chip sellers and users across several major technology hubs. Its security benefit and commercial burden remain to be measured after implementation.

## GOALPOST / RESPONSE

Commerce says the rule closes a remote-computing route around existing controls while preserving legitimate commercial recommender systems. The tests are publication and implementation, license volumes and decisions, due-diligence compliance, identified diversion attempts, enforcement, changes after comments, effects on covered data centers and independently measured access by prohibited users.

## MAYBE / THEREFORE

Maybe the rule will close a meaningful circumvention channel, or restricted users may shift providers and structures while legitimate cloud activity bears new costs. Therefore Commerce has issued an immediately effective-on-publication control framework—not proof that remote access has stopped, that every named jurisdiction is diverting chips or that the rule's costs and security benefits are known.


## SOURCES

- [Bureau of Industry and Security — Addressing Remote Access to Advanced Semiconductors](https://www.bis.gov/media/documents/rin-0694-ak50.pdf) — primary interim final rule; effective on Federal Register publication with post-publication comments
- [Reuters — U.S. restricts remote access to advanced AI chips](https://www.reuters.com/legal/litigation/us-issues-rule-protect-advanced-ai-chips-being-accessed-remotely-2026-11-16/) — independent reporting on rule scope, China-circumvention rationale and industry context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
