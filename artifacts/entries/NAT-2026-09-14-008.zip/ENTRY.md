# Judge postpones DHS fixed-duration rule for students, researchers and journalists

**Entry ID:** NAT-2026-09-14-008
**Date:** September 14, 2026
**Checked:** 2026-09-14 11:59 PM EDT
**Evidence state:** primary Federal Register final rule and complete 48-page district-court order plus independent Reuters reporting and DHS response; effective date postponed nationwide, vacatur and final merits unresolved
**Review state:** current-standard-reviewed

A nationwide APA order stopped the September 15 effective date for the F, J and I admission rule; the court did not vacate the rule or enter final judgment.

## THE FACTS

- DHS’s July 17 final rule would replace duration-of-status admissions with fixed periods: generally no more than four years for F students and J exchange visitors, and 240 days for most I foreign-media representatives, followed by an extension-of-stay process. The rule was scheduled to take effect September 15.
- On September 14, U.S. District Judge F. Dennis Saylor IV found the plaintiffs likely to succeed on their Administrative Procedure Act claim. His 48-page opinion said DHS inadequately addressed significant comments and less burdensome alternatives and failed to connect the rule rationally to its stated fraud and national-security objectives.
- The court used APA section 705 to postpone the rule’s effective date nationwide. It declined to vacate the rule or grant summary judgment at this stage, denying that additional relief without prejudice. The order is preliminary and leaves merits litigation and appellate review open.
- The opinion cited DHS estimates of roughly 1.6 million people in F status, 504,000 in J status and 24,000 in I status, and up to $267.9 million in first-year institutional familiarization and adaptation costs. These are administrative-record estimates and judicial findings about likely harm, not measured post-rule outcomes.
- DHS General Counsel James Percival said the ruling would permit abuse of the immigration system and pointed to students taking minimal coursework while remaining for years. The court acknowledged system problems but found the agency’s chosen response inadequately justified; future agency records, merits rulings and appellate decisions remain the tests.

## SIGNIFICANCE

The order prevents an immediate nationwide change to admission periods and extension procedures affecting students, researchers and foreign journalists. It preserves the longstanding duration-of-status framework while litigation proceeds, without establishing a final judgment that DHS can never adopt a fixed-period system.

## GOALPOST / RESPONSE

DHS says fixed review points would deter fraud, address national-security risks and improve oversight; the court found the current record and reasoning insufficient and credited serious educational, economic and press-related disruption. Appellate rulings, final merits, a revised rule and record, extension processing capacity, enrollment and research trends, compliance costs, overstay data and documented fraud or security outcomes are the tests.

## MAYBE / THEREFORE

Maybe a better-supported, narrower review system could improve compliance without major disruption, or fixed periods may deter talent and burden institutions without materially reducing fraud. Therefore the September 14 order postpones this rule’s effective date under APA section 705—it does not vacate the rule, finally resolve DHS authority or measure long-term immigration, education or security effects.


## SOURCES

- [Federal Register — fixed admission periods for F, J and I nonimmigrants](https://www.federalregister.gov/documents/2026/07/17/2026-14439/establishing-a-fixed-time-period-of-admission-and-an-extension-of-stay-procedure-for-nonimmigrant) — primary final rule, scope, extension process and scheduled effective date
- [District of Massachusetts — Presidents’ Alliance v. DHS preliminary order](https://www.presidentsalliance.org/wp-content/uploads/2026/09/9.14.26-opinion-in-DS-case.pdf) — primary 48-page memorandum and order postponing the final rule under APA section 705
- [Reuters — judge blocks fixed-duration F, J and I rule](https://www.reuters.com/world/us-judge-blocks-trump-limits-duration-visas-foreign-students-journalists-2026-09-14/) — independent reporting of the ruling, affected categories and DHS response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
