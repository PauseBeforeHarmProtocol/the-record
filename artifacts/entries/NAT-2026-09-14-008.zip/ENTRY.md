# Court vacates DHS fixed-duration rule for students, researchers and journalists

**Entry ID:** NAT-2026-09-14-008
**Date:** September 14, 2026
**Checked:** 2026-11-16 6:00 PM EST
**Evidence state:** Complete Federal Register rule and final district-court order plus independent Bloomberg Law reporting and litigation-status record; final district-court vacatur entered, appellate review still available
**Review state:** current-standard-reviewed

The district court entered final judgment vacating the F, J and I fixed-duration rule after granting summary judgment; the longstanding duration-of-status framework remains in place unless later appellate relief changes the result.

## THE FACTS

- DHS's July 17 final rule would replace duration-of-status admissions with fixed periods: generally no more than four years for F students and J exchange visitors, and 240 days for most I foreign-media representatives, followed by an extension-of-stay process. The rule never took effect because the court postponed its September 15 effective date.
- On November 16, U.S. District Judge F. Dennis Saylor IV granted the plaintiffs' motion for summary judgment, denied the government's cross-motion and entered final judgment vacating the entire rule under Administrative Procedure Act section 706.
- The court adopted its September reasoning that DHS inadequately weighed costs and benefits, did not connect the fraud and national-security rationales to the chosen system, failed to consider less burdensome alternatives and did not adequately answer significant comments. It additionally found the academic-mobility restrictions contrary to statutory authority.
- The court rejected DHS's request for remand without vacatur, reasoning that the longstanding regime has existed for decades and the challenged rule had not gone into effect. The duration-of-status framework therefore remains operative nationwide at this stage.
- DHS had argued that fixed review points would deter fraud, address national-security risks and improve oversight. The government's existing First Circuit appeal concerns the September preliminary order rather than the November final judgment; the administration may separately appeal the final judgment and seek a stay, but an appeal alone would not suspend the vacatur.

## SIGNIFICANCE

The final judgment replaces a preliminary postponement with merits relief that sets aside the national rule before implementation. Students, exchange visitors, foreign-media representatives and institutions remain under duration of status, while an appeal, stay or new rulemaking could create another lifecycle stage.

## GOALPOST / RESPONSE

DHS can seek a stay or appeal the final judgment, or undertake a new rulemaking with a different statutory and evidentiary record. Any future fixed-period system should be assessed through appellate holdings, statutory fit, extension-processing capacity, enrollment and research effects, compliance costs, overstay data and documented fraud or security outcomes.

## MAYBE / THEREFORE

Maybe a narrower, better-supported review system could improve compliance without major disruption, or fixed periods may burden institutions and deter talent without materially reducing fraud. Therefore the November 16 judgment vacates this rule on the merits and preserves duration of status for now—it does not prevent every future rule, foreclose appellate review or measure long-term immigration, education or security effects.


## SOURCES

- [Federal Register — fixed admission periods for F, J and I nonimmigrants](https://www.federalregister.gov/documents/2026/07/17/2026-14439/establishing-a-fixed-time-period-of-admission-and-an-extension-of-stay-procedure-for-nonimmigrant) — primary final rule, scope, extension process and scheduled effective date
- [District of Massachusetts — final summary-judgment order in Presidents' Alliance v. DHS](https://www.presidentsalliance.org/wp-content/uploads/2026/11/2026-11-16-District-Judge-dckt-73_0.pdf) — primary eight-page judicial order granting summary judgment and vacating the final rule; docket 1:26-cv-13799-FDS, document 73; SHA-256 3a91f8ec1e925d3b783acc13bf304f9ad0aa1461b3af7104e5fae489784c3345
- [Presidents' Alliance — duration-of-status litigation status and document index](https://www.presidentsalliance.org/duration-of-status-litigation/) — plaintiff coalition litigation status page distinguishing the preliminary appeal from the final judgment
- [Bloomberg Law — DHS restrictions on F-1 students overturned](https://news.bloomberglaw.com/us-law-week/dhs-restrictions-on-f-1-foreign-students-stay-in-us-overturned) — independent legal reporting on the final summary-judgment order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
