# DOE extends the stay of federal-building fossil-fuel standards through March 2027

**Entry ID:** NAT-2026-09-02-001
**Date:** September 2, 2026
**Checked:** 2026-09-02 6:02 AM EDT
**Evidence state:** primary Department of Energy Federal Register notification; compliance stay operative, underlying rule and final policy disposition unresolved
**Review state:** current-standard-reviewed

Federal agencies are not required to comply with the affected clean-energy design standards during the extended stay; DOE has not yet repealed the underlying rule.

## THE FACTS

- The Department of Energy published a notification further staying the compliance date for clean-energy requirements governing certain new federal buildings and major renovations until March 1, 2027.
- The underlying 2024 rule requires covered projects whose design began on or after May 1, 2025, to reduce fossil-fuel-generated energy consumption using standards tailored to building type and climate zone. DOE had already delayed compliance in May 2025 and April 2026.
- DOE said its review of the implementation guidance and rule remains ongoing and cited the administration's energy-security, grid-reliability and deregulatory policies. It said the stay avoids imposing compliance burdens on federal agencies during that review.
- The stay is operative as of September 2. It means covered agencies are not required to comply with the affected standards during the stay; it does not itself repeal the underlying regulatory text, complete DOE's review or establish the energy, cost or emissions effects of a later final policy.

## SIGNIFICANCE

The stay postpones federal clean-building requirements for another six months, affecting how covered federal construction and major-renovation projects are designed. Its practical consequences depend on which projects advance during the pause and whether DOE later retains, revises or rescinds the standards.

## GOALPOST / RESPONSE

DOE says the pause avoids regulatory burdens while it aligns federal-building policy with the administration's energy-security, reliability and deregulatory priorities. Supporters of the standards may argue that continued delay locks in fuel use, emissions and future operating costs. Covered-project designs, energy-source choices, construction and operating costs, emissions estimates, the review record and any later repeal or replacement are the tests.

## MAYBE / THEREFORE

Maybe the additional review will produce more flexible and reliable building standards, or the repeated stays may function as a de facto rollback while projects proceed without the clean-energy requirements. Therefore the record confirms an operative compliance stay through March 1, 2027—not repeal of the underlying rule or a measured cost, reliability or emissions result.


## SOURCES

- [Federal Register — DOE stay of federal-building clean-energy standards](https://www.federalregister.gov/documents/2026/09/02/2026-17979/repeal-of-fossil-fuel-restrictions-for-new-federal-buildings-and-major-renovations-of-federal) — primary agency notification of an operative compliance stay through March 1, 2027

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
