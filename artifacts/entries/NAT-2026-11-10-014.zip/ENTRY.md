# Interior plan calls for selling federal lands to shrink the federal estate

**Entry ID:** NAT-2026-11-10-014
**Date:** November 10–11, 2026
**Checked:** 2026-11-11 6:10 PM EST
**Evidence state:** primary Interior strategic plan plus Associated Press reporting; formally announced agency strategy, with parcels, authority, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The 2026–2030 roadmap proposes offers to states, localities and Tribes but identifies no parcels, acreage, prices or completed sale.

## THE FACTS

- The Interior Department published its fiscal 2026–2030 strategic plan on November 10, before the prior archive boundary; this release records a retrospective discovery. Under Objective 4.2, the plan says Interior will work to decrease the federal estate by offering states, localities and Tribes opportunities to purchase federal lands.
- The plan identifies no parcels, acreage target, sale schedule, valuation method or completed transaction. It says sales would let Interior concentrate on primary federal responsibilities and nationally significant lands, and that part of the proceeds would return to purchasers for conservation elsewhere.
- The plan also directs more Land and Water Conservation Fund investment toward easements on private land and calls for transfers or exchanges that support energy production. Those are agency priorities and proposed strategies, not executed conveyances or congressional authorization for a particular sale.
- Associated Press reported that existing law restricts disposal of protected lands and generally requires sale criteria, and that former Interior Secretary Ryan Zinke and Democratic natural-resources leaders opposed broad sales. Interior's strongest explanation is that a smaller estate would focus resources and reduce federal management costs; the plan supplies no quantified savings or conservation outcome.

## SIGNIFICANCE

A department-wide roadmap to reduce federal land ownership could affect conservation, recreation, Tribal interests, energy development and local tax bases across the West. Its present legal effect is a policy direction, not a land transfer.

## GOALPOST / RESPONSE

Interior says sales and easement-focused conservation will concentrate resources on nationally significant lands while expanding access and reducing taxpayer responsibility. The tests are identified parcels, statutory authority, public and Tribal consultation, appraisals, congressional action where required, completed conveyances, proceeds, access and measurable conservation and development effects.

## MAYBE / THEREFORE

Maybe carefully selected sales or exchanges could resolve isolated management problems and fund conservation, or an estate-reduction target could prioritize disposal over long-term public access and stewardship. Therefore the record establishes a formal agency roadmap—not acreage offered, authority for every contemplated sale, a completed conveyance, savings or environmental outcome.


## SOURCES

- [Interior Department — Strategic Plan for Fiscal Years 2026–2030](https://www.doi.gov/media/document/strategic-plan-fiscal-years-2026-2030) — primary agency strategic plan; complete plan and land-sales objective inspected
- [AP — Trump administration plans public-land sales and smaller federal estate](https://apnews.com/article/9c6078b69f8525ab1b220e5aa321d62f) — independent reporting on plan, legal limits and bipartisan response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
