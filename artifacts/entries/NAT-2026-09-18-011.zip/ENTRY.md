# Two federal judges vacate EPA's Solar for All termination

**Entry ID:** NAT-2026-09-18-011
**Date:** September 18–23, 2026
**Checked:** 2026-09-23 5:57 PM EDT
**Evidence state:** complete federal court opinions and judgment from the District of Rhode Island and District of Columbia plus independent Reuters and Associated Press reporting; two merits rulings entered, no stay, appellate disposition, completed grant payment or measured outcome by cutoff
**Review state:** current-standard-reviewed

A second district judge held that EPA unlawfully ended the fully obligated $7 billion program; appeals, grant administration and project outcomes remain unresolved.

## THE FACTS

- U.S. District Judge Mary S. McElroy granted the plaintiffs' summary-judgment motion in Rhode Island AFL-CIO v. EPA, No. 1:25-cv-00510-MSM-PAS, declared EPA's termination of Solar for All unlawful under the Administrative Procedure Act and ordered the termination decision vacated. A separate judgment entered the same day.
- The order says Congress appropriated $7 billion for Solar for All within the Greenhouse Gas Reduction Fund and EPA obligated the full amount before September 30, 2024. The 2025 law repealed the program's authorizing section and rescinded unobligated balances, but the court held that Congress intended EPA to continue administering grants already obligated and supplied no authority for terminating them.
- The court found jurisdiction because the plaintiffs are downstream beneficiaries rather than federal grantees seeking contract damages, and it treated EPA's termination memorandum as reviewable final agency action. Having found the decision contrary to law and beyond EPA's statutory authority, the judge did not decide the plaintiffs' separate arbitrary-and-capricious, Presentment Clause or Spending Clause claims.
- The court declined a separate permanent injunction because EPA acknowledged that vacatur would prohibit continued implementation of the termination and the plaintiffs had not shown additional injunctive relief was necessary. Associated Press reported that EPA was reviewing the decision and considering appeal; no stay, appellate ruling, completed grant administration or measured household outcome was established by cutoff.
- In Harris County v. EPA, U.S. District Judge Tanya Chutkan separately held on September 22 that EPA's program-wide elimination decision exceeded the agency's statutory authority and was arbitrary and capricious. She vacated that policy determination while denying Harris County's requested injunction without prejudice.
- The District of Columbia opinion held that the 2025 law rescinded only unobligated balances and did not authorize EPA to terminate already obligated grants. The ruling did not itself adjudicate Harris County's individual grant appeal, require immediate payment or establish that any project had resumed.
- Reuters reported that EPA was considering appeals of both the Rhode Island and District of Columbia decisions. No stay, appellate disposition, final agency guidance, completed disbursement or measured program outcome was established by cutoff.

## SIGNIFICANCE

Two district courts have now independently vacated EPA's program-wide termination premise, strengthening the judicial barrier to treating the 2025 repeal as authority to cancel already obligated grants. Practical restoration still depends on agency compliance, individual grant processes and any stays or appeals.

## GOALPOST / RESPONSE

EPA argued that the 2025 repeal ended its authority and has said it is considering appeals of both rulings. The courts rejected the program-wide termination premise, while the District of Columbia court left Harris County's individual grant process unresolved. Docket activity, stays, agency guidance, grant appeals, disbursement, completed projects, household savings and emissions results are the tests.

## MAYBE / THEREFORE

Maybe the two vacaturs allow obligated grants to proceed and reach intended communities, or appeals, stays, administrative delay and grant-specific disputes may limit or postpone implementation. Therefore two district judges invalidated EPA's program-wide termination—not that every grant was restored in practice, funds were disbursed or program benefits were measured by cutoff.


## SOURCES

- [District of Rhode Island — Solar for All memorandum and order](https://storage.courtlistener.com/recap/gov.uscourts.rid.60578/gov.uscourts.rid.60578.48.0.pdf) — primary 20-page federal court order
- [District of Rhode Island — Solar for All judgment](https://storage.courtlistener.com/recap/gov.uscourts.rid.60578/gov.uscourts.rid.60578.49.0.pdf) — primary federal court judgment
- [Reuters — judge vacates EPA termination of Solar for All](https://www.reuters.com/legal/litigation/trumps-epa-unlawfully-terminated-7-billion-solar-grant-program-judge-rules-2026-09-18/) — independent reporting
- [Associated Press — judge rules EPA illegally terminated Solar for All](https://apnews.com/article/0bae42fcf85906ea48ee0f6f4d6c83a9) — independent reporting
- [U.S. District Court for the District of Columbia — Harris County v. EPA memorandum opinion](https://fingfx.thomsonreuters.com/gfx/legaldocs/lbpgxozbjvq/09232026epa.pdf) — primary federal court opinion (No. 1:25-cv-03646, Document 58)
- [Reuters — second federal judge vacates EPA Solar for All termination](https://www.reuters.com/legal/government/second-judge-finds-trumps-epa-unlawfully-nixed-7-billion-solar-grant-program-2026-09-23/) — independent legal reporting on the District of Columbia ruling and EPA appeal response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
