# Federal judge vacates EPA's Solar for All termination

**Entry ID:** NAT-2026-09-18-011
**Date:** September 18, 2026
**Checked:** 2026-09-19 12:02 AM EDT
**Evidence state:** complete 20-page federal court order and separate judgment plus independent Reuters and Associated Press reporting; district-court merits ruling entered, no permanent injunction, stay or appellate disposition by cutoff
**Review state:** current-standard-reviewed

The court held that EPA exceeded its statutory authority when it ended the fully obligated $7 billion program; appeal, compliance and project outcomes remain unresolved.

## THE FACTS

- U.S. District Judge Mary S. McElroy granted the plaintiffs' summary-judgment motion in Rhode Island AFL-CIO v. EPA, No. 1:25-cv-00510-MSM-PAS, declared EPA's termination of Solar for All unlawful under the Administrative Procedure Act and ordered the termination decision vacated. A separate judgment entered the same day.
- The order says Congress appropriated $7 billion for Solar for All within the Greenhouse Gas Reduction Fund and EPA obligated the full amount before September 30, 2024. The 2025 law repealed the program's authorizing section and rescinded unobligated balances, but the court held that Congress intended EPA to continue administering grants already obligated and supplied no authority for terminating them.
- The court found jurisdiction because the plaintiffs are downstream beneficiaries rather than federal grantees seeking contract damages, and it treated EPA's termination memorandum as reviewable final agency action. Having found the decision contrary to law and beyond EPA's statutory authority, the judge did not decide the plaintiffs' separate arbitrary-and-capricious, Presentment Clause or Spending Clause claims.
- The court declined a separate permanent injunction because EPA acknowledged that vacatur would prohibit continued implementation of the termination and the plaintiffs had not shown additional injunctive relief was necessary. Associated Press reported that EPA was reviewing the decision and considering appeal; no stay, appellate ruling, completed grant administration or measured household outcome was established by cutoff.

## SIGNIFICANCE

Vacatur removes EPA's program-wide termination decision and preserves a judicial route for downstream beneficiaries to challenge an agency's refusal to administer already obligated funds. The practical effect still depends on compliance, any stay or appeal, and whether grants and projects resume.

## GOALPOST / RESPONSE

EPA argued that the 2025 repeal ended its authority, that the dispute belonged in the Court of Federal Claims and that any remedy should be limited to remand; the court rejected those positions and EPA said it was considering appeal. Docket activity, a stay, agency guidance, grant administration, disbursement, completed projects, household savings and emissions results are the tests.

## MAYBE / THEREFORE

Maybe vacatur allows the obligated Solar for All grants to proceed and reach the intended communities, or an appeal, stay, administrative delay or later legal dispute may limit or postpone implementation. Therefore the district court vacated EPA's termination as unlawful—not that every grant was already restored in practice, that funds were disbursed, or that program benefits were measured by cutoff.


## SOURCES

- [District of Rhode Island — Solar for All memorandum and order](https://storage.courtlistener.com/recap/gov.uscourts.rid.60578/gov.uscourts.rid.60578.48.0.pdf) — primary 20-page federal court order
- [District of Rhode Island — Solar for All judgment](https://storage.courtlistener.com/recap/gov.uscourts.rid.60578/gov.uscourts.rid.60578.49.0.pdf) — primary federal court judgment
- [Reuters — judge vacates EPA termination of Solar for All](https://www.reuters.com/legal/litigation/trumps-epa-unlawfully-terminated-7-billion-solar-grant-program-judge-rules-2026-09-18/) — independent reporting
- [Associated Press — judge rules EPA illegally terminated Solar for All](https://apnews.com/article/0bae42fcf85906ea48ee0f6f4d6c83a9) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
