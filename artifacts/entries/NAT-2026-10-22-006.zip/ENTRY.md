# State Department restores three diplomatic fellowships at lower enrollment

**Entry ID:** NAT-2026-10-22-006
**Date:** October 22, 2026
**Checked:** 2026-10-23 12:00 AM EDT
**Evidence state:** Associated Press reporting quoting the State Department and Deputy Secretary announcement; program restoration announced, cohort, criteria, funding and outcomes incomplete
**Review state:** current-standard-reviewed

The department announced that the Pickering, Rangel and Payne graduate fellowships would resume with higher support payments but fewer participants; selection criteria and workforce effects remain unclear.

## THE FACTS

- The State Department and Deputy Secretary Christopher Landau announced on October 22 that the Pickering, Rangel and Payne fellowships for graduate students pursuing Foreign Service careers would resume after partial or full suspension during the prior year's diplomatic-corps reductions.
- Associated Press reported that the restored programs would offer higher stipends and living-expense payments than before. The inspected announcement did not establish how many fellows would receive support, the aggregate appropriation or a measured recruitment outcome.
- The programs will resume with lower enrollment. AP reported that it was not immediately clear whether acceptance criteria had materially changed, so the archive does not infer that the prior diversity-focused selection model was fully restored.
- The restoration is an announced program decision, not proof that positions have been filled or that the department's staffing composition, retention or diplomatic capacity has improved.

## SIGNIFICANCE

Restoring three established recruitment pipelines reverses part of the prior suspension and may affect the future Foreign Service workforce, while lower enrollment and unclear criteria limit claims of full restoration.

## GOALPOST / RESPONSE

The administration presents the programs as renewed pathways into diplomatic service with improved financial support. The tests are published eligibility rules, cohort size, obligated funding, completed awards, placement and retention—not the announcement alone.

## MAYBE / THEREFORE

Maybe higher stipends will widen access despite smaller cohorts, or reduced enrollment and changed criteria may substantially narrow the programs' earlier function. Therefore this is a formal restoration announcement with bounded details—not completed hiring or a measured reversal of diplomatic-corps cuts.


## SOURCES

- [Associated Press live report — State Department fellowship restoration and visa restrictions](https://apnews.com/article/7f7b10c7974ed379a11f4c5421f0e62e) — independent reporting quoting State Department and Secretary of State announcements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
