# HHS sends nine foster-benefit letters and opens state technical assistance

**Entry ID:** NAT-2026-11-16-003
**Date:** November 16, 2026
**Checked:** 2026-11-16 12:08 PM EST
**Evidence state:** primary HHS announcement of sent letters and available assistance plus independent Children's Advocacy Institute state-by-state tracker; federal actions implemented, administration aggregate qualified by differing definitions and documentation
**Review state:** current-standard-reviewed

HHS says 41 states have ended or substantially reformed diversion of survivor benefits, but an independent state tracker distinguishes enacted protections from announcements, partial measures and documentation gaps.

## THE FACTS

- HHS and the Administration for Children and Families sent updated letters to governors of Connecticut, Florida, Illinois, Maryland, Minnesota, New York, Pennsylvania, Texas and Wisconsin urging them to stop using foster youths' Social Security survivor benefits to offset state care costs.
- ACF also made a new technical-assistance center available to work with state child-welfare and budget offices on implementation and possible funding offsets, and sent a coordination letter to the National Association of State Budget Officers. Those letters and assistance are implemented federal actions; state acceptance and policy changes are not automatic.
- HHS said 30 states acted after its December 2025 outreach, joining 11 states and the District of Columbia that had acted earlier, and described 41 states—82%—as having ended or substantially reformed the practice. It estimated the diverted benefits at 0.22% of state child-welfare budgets and identified possible TANF and Title IV-E offsets; the release did not provide a state-by-state fiscal audit.
- The Children's Advocacy Institute's current state tracker reports 42 states and jurisdictions taking some form of action, but separates full conservation, partial or benefit-specific reform, management measures, unsuccessful legislation, pending bills and undocumented announcements. It specifically says formal implementation documentation was not located for several states HHS counts and notes that some announced changes are not complete.
- The differing totals are not directly comparable: HHS counts states it says ended or substantially reformed survivor-benefit diversion, while CAI includes a broader range of actions and separately flags incomplete or undocumented implementation. The archive therefore records the federal letters and assistance as completed and treats the 41-state outcome as an administration classification requiring state-level verification.

## SIGNIFICANCE

The federal government has moved from public pressure to a named implementation-support mechanism and a focused nine-state request, which can produce identifiable state policy changes. The independent tracker shows why headline state counts require definition and documentation rather than being treated as uniform completed reform.

## GOALPOST / RESPONSE

HHS says governors can end the practice and that assistance and offsets can close budget gaps. The tests are public copies of the letters, state executive orders or enacted policies, benefits actually conserved for children, fiscal substitutions, implementation dates, audits and resolution of discrepancies between federal claims and state documentation.

## MAYBE / THEREFORE

Maybe federal assistance will convert announcements into durable protections without reducing other child-welfare services, or budget and implementation gaps may leave partial reforms and continued diversion. Therefore HHS has sent letters and opened technical assistance, while its 41-state characterization is not treated as 41 uniformly verified, fully implemented laws.


## SOURCES

- [HHS — updated foster-youth survivor-benefit letters and technical assistance](https://www.hhs.gov/press-room/hhs-announces-41-states-end-orphan-tax-foster-youth-survivor-benefits.html) — primary announcement of sent letters, technical-assistance availability and administration state count
- [Children's Advocacy Institute — state foster-benefit reform tracker](https://www.sandiego.edu/cai/advocacy/youth-benefits/state.php) — independent state-by-state tracker distinguishing enacted, partial, announced, attempted and undocumented reforms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
