# DOJ and EEOC secure $5 million Instacart hiring-discrimination settlement

**Entry ID:** NAT-2026-10-20-001
**Date:** October 20, 2026
**Checked:** 2026-10-20 11:57 AM EDT
**Evidence state:** official DOJ announcement and joint settlement summary; agreement and required remedies announced, claimant eligibility, payments and compliance outcomes unresolved
**Review state:** current-standard-reviewed

The agreement creates a $4 million claimant fund, a $1 million civil penalty and PERM recruitment, training, monitoring and reporting duties.

## THE FACTS

- The Justice Department’s Civil Rights Division and the Equal Employment Opportunity Commission announced a $5 million settlement with Maplebear Inc., doing business as Instacart, to resolve citizenship-status and national-origin discrimination allegations under the Immigration and Nationality Act and Title VII. The settlement resolves allegations rather than a court adjudication of liability.
- The agencies said Instacart required physically mailed applications for jobs advertised through the permanent labor certification process even though its standard recruitment process accepted electronic applications, and that many U.S. applicants were not timely considered.
- Instacart will establish a $4 million fund for applicants and deterred applicants affected from December 2023 through February 2026; a claims administrator will contact potential claimants and determine eligibility for back pay and compensatory damages. Instacart will also pay a $1 million civil penalty to the United States.
- The settlement requires Instacart to post PERM positions on its public career site, accept electronic applications, revise related policies, provide annual anti-discrimination training, appoint a monitor and report on compliance. Claimant eligibility, actual compensation and later compliance results were unresolved at the cutoff.

## SIGNIFICANCE

The agreement imposes material compensation, penalty and hiring-process remedies through joint federal civil-rights enforcement. Its practical effect depends on claimant outreach, eligibility decisions, payments and compliance monitoring.

## GOALPOST / RESPONSE

DOJ and EEOC say the settlement protects U.S. workers from unlawful barriers and visa-holder preference. Claimant contacts and determinations, fund payments, the civil penalty, electronic-application access, annual training, monitoring reports and recurrence are the tests.

## MAYBE / THEREFORE

Maybe the fund and process changes compensate affected workers and prevent repeated discrimination, or claimant administration and monitoring may reveal limited reach or compliance gaps. Therefore Instacart accepted enforceable remedies to resolve the agencies’ allegations—not that a court found liability, every claimant has been identified or compensation has already been paid.


## SOURCES

- [Justice Department — $5 million Instacart hiring-discrimination settlement announcement](https://www.justice.gov/opa/pr/civil-rights-division-and-equal-employment-opportunity-commission-secure-5000000-joint) — primary announcement of settlement, allegations and remedies
- [Justice Department and EEOC — summary of Instacart settlement terms](https://www.justice.gov/crt/media/1466996/dl) — primary settlement-term summary

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
