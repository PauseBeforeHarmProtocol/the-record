# CMS publishes final organ-procurement oversight and competition rule

**Entry ID:** NAT-2026-11-03-002
**Date:** November 3, 2026
**Checked:** 2026-11-03 12:07 PM EST
**Evidence state:** Federal Register final rule, CMS fact sheet, HHS rationale and independent AHA summary; implementation, competitions, decertifications, costs and outcomes remain prospective
**Review state:** current-standard-reviewed

The January 4, 2027 rule retains outcome-based performance tiers, limits automatic decertification to tier 3, expands competition and adds urgent safety, quality and research-organ requirements.

## THE FACTS

- CMS published a final rule at 91 FR 69390 on November 3, scheduled to take effect January 4, 2027. It revises Medicare conditions for coverage for organ procurement organizations, or OPOs. A final rule with a future effective date is not the same as completed competition, decertification or transplant outcomes.
- CMS retained donation-rate and transplant-rate outcome measures and three performance tiers. Under the final policy, tier 2 OPOs must compete to retain their donation service areas, while automatic decertification is limited to tier 3; CMS may select more than one OPO for a service area and provides appeal and transition procedures.
- The rule defines specified unsound medical practices that can support urgent decertification and requires quality-assessment and performance-improvement policies for adverse events. It also adds or clarifies medical-director, reporting, organ-tracking and research-organ requirements.
- For performance calculations, CMS removes pancreata used only for islet-cell research from the transplant-rate numerator while counting the deceased donor, and requires tracking of organs used for research. These technical choices change measurement and accountability; they do not themselves show more organs reaching transplant recipients.
- HHS cited a 36% rise in organ donations and a 30% rise in transplants since 2020 as context for stronger accountability. Those are agency-reported period changes, not proof that this not-yet-effective rule caused them. The Federal Register estimates about $583,000 in annual reduced interpretation costs, a prospective estimate rather than measured savings.
- The American Hospital Association independently summarized the final performance, competition and decertification provisions. Effects on OPO consolidation, service continuity, discarded organs, safety, donation and transplant rates, disparities, costs and appeals remain unmeasured.

## SIGNIFICANCE

The rule changes how federally certified OPOs can retain service areas, face competition or urgent decertification and report quality events. Because OPO performance affects organ recovery and allocation infrastructure, implementation could affect both accountability and continuity, but outcomes are prospective.

## GOALPOST / RESPONSE

CMS and HHS say stronger competition, outcome measures and safety tools will improve accountability and increase successful transplantation. The tests are service-area awards, appeals and transitions, adverse-event findings, organ-use and discard data, donation and transplant rates, disparities, continuity and realized costs after the effective date.

## MAYBE / THEREFORE

Maybe competition and clearer safety standards improve OPO performance, or transitions and measurement choices may create disruption or incentives that do not translate into more successful transplants. Therefore CMS published a binding final framework effective January 4, 2027; the archive does not claim that an OPO has yet been decertified under it, that costs have been saved or that transplant outcomes have improved because of it.


## SOURCES

- [Federal Register — organ procurement organization conditions-for-coverage final rule](https://www.federalregister.gov/documents/2026/11/03/2026-22381/medicare-and-medicaid-programs-organ-procurement-organizations-conditions-for-coverage-revisions-to-the-conditions-for-c) — primary final rule, 91 FR 69390, effective January 4, 2027
- [CMS — organ procurement organization final-rule fact sheet](https://www.cms.gov/newsroom/fact-sheets/medicare-medicaid-programs-organ-procurement-organizations-conditions-coverage-revisions-conditions) — primary agency summary of performance tiers, competition, urgent decertification, QAPI and reporting provisions
- [HHS — final rule on organ procurement organization accountability](https://www.hhs.gov/press-room/cms-finalizes-rule-organ-procurement-organizations-transplant-accountability.html) — primary agency announcement and administration rationale
- [American Hospital Association — CMS issues final OPO oversight rule](https://www.aha.org/news/headline/2026-11-02-cms-issues-final-rule-oversight-organ-procurement-organizations) — independent health-system summary of final performance, competition and decertification provisions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
