# State Department announces South Africa-related visa restriction policy

**Entry ID:** NAT-2026-09-15-014
**Date:** September 15, 2026
**Checked:** 2026-09-16 5:59 AM EDT
**Evidence state:** primary State Department policy announcement preserved through an unaltered full-text mirror, plus independent Reuters and Associated Press reporting; formal policy announced, targets and implementation undisclosed
**Review state:** current-standard-reviewed

The policy invokes immigration-law authority against officials tied to asserted race-based discrimination, but names no individuals and supplies no denial or enforcement count.

## THE FACTS

- The State Department announced a new visa-restriction policy under Immigration and Nationality Act section 212(a)(3)(C) for foreign nationals it determines are responsible for or complicit in specified race-based discrimination in South Africa.
- The policy announcement describes covered conduct as laws or policies enabling uncompensated land seizures, race-based discrimination and incitement of imminent violence against minority ethnic or racial groups. It says certain immediate family members may also be covered.
- The release did not name a person, announce a completed visa denial or publish a case count, evidentiary standard or review record. The policy is therefore a formal announced screening basis, not proof that any particular official has engaged in the described conduct or already been denied entry.
- The State Department frames the measure as protecting U.S. foreign-policy interests and responding to discrimination. South Africa's government rejects the administration's broader claims of race persecution; Reuters also noted that most murder victims in South Africa are Black. Those positions do not resolve a future individual visa determination.

## SIGNIFICANCE

The policy creates a discretionary U.S. entry consequence tied to contested claims about South African land and race policy. Its practical reach cannot yet be measured because visa records are often confidential and no targets or implemented decisions were disclosed.

## GOALPOST / RESPONSE

The administration says the restrictions will hold officials accountable for race-based discrimination and threats to minority groups; South Africa denies the premise of racial persecution. Named or aggregate determinations, legal standards, consistent application, waiver or review procedures, diplomatic effects and independently documented underlying conduct are the tests.

## MAYBE / THEREFORE

Maybe the policy deters genuinely discriminatory conduct, or its broad and contested predicates may produce selective, opaque or primarily symbolic enforcement. Therefore the record establishes a formal visa-policy announcement—not an adjudicated finding of persecution, a named sanction, a completed denial or proof of deterrence.


## SOURCES

- [State Department — visa restriction policy targeting asserted race-based discrimination in South Africa](https://www.state.gov/releases/office-of-the-spokesman/2026/09/announcement-of-new-visa-restriction-policy-targeting-foreign-nationals-involved-in-race-based-discrimination) — primary government policy announcement under INA 212(a)(3)(C)
- [PublicNow mirror — unaltered State Department South Africa visa-policy release](https://ebs.publicnow.com/view/A1E14439ED40FB314152FD5CAFB0DCEB4E9085C8) — full-text mirror of primary government release used because the State page returned an access error
- [Reuters — U.S. announces South Africa-related visa restrictions](https://www.reuters.com/world/africa/us-announces-visa-curbs-some-foreign-nationals-south-africa-2026-09-15/) — independent reporting with South African response
- [Associated Press — Rubio announces South Africa visa policy](https://apnews.com/article/5cedd7e02f570f5bbf4cdd3cef365fb9) — independent reporting and policy context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
