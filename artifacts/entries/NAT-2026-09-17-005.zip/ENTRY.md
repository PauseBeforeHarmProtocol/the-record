# Senate passes Protect College Sports Act 77–22

**Entry ID:** NAT-2026-09-17-005
**Date:** September 17–28, 2026
**Checked:** 2026-09-28 11:59 PM EDT
**Evidence state:** primary Senate and committee records, White House and Trump statements, and independent Associated Press reporting; Senate passage verified, House and presidential action pending
**Review state:** current-standard-reviewed

The bill advances after a bipartisan final vote, but still requires House approval and a presidential signature before becoming law.

## THE FACTS

- The Senate passed the Protect College Sports Act 77–22 on September 28 after earlier procedural votes. This is final Senate passage, not enactment.
- The amended proposal would establish national rules for name-image-likeness compensation, revenue sharing, transfers and eligibility, limited antitrust protection for specified governing-body actions, and scholarship, health and academic protections. Those remain proposed statutory terms.
- Trump published an endorsement after the vote, and the White House had called for Congress to send the bill to his desk. Their claim that the measure will save college sports and colleges is advocacy, not a measured outcome.
- The House must pass the bill and the president must sign it before it becomes law. No nationwide payment rule, scholarship guarantee, transfer rule or antitrust immunity is counted as implemented.

## SIGNIFICANCE

Bipartisan Senate passage moves a national college-sports framework from procedural consideration to a completed chamber vote. Its legal effects remain contingent on House action and presidential approval.

## GOALPOST / RESPONSE

Supporters say the measure will stabilize college sports while protecting compensation, scholarships, health care and women's and Olympic programs. Critics raise concerns about athlete labor rights and antitrust protection. House text, final enactment, regulations, enforcement and measured athlete and school outcomes are the tests.

## MAYBE / THEREFORE

Maybe the Senate vote will produce a durable national framework, or House negotiations and disputes over labor and antitrust treatment may change or stop it. Therefore the record verifies final Senate passage—not enactment or implementation of the bill's promised benefits.


## SOURCES

- [Senate Daily Press — S. 4668 motion to proceed, 77–22](https://www.dailypress.senate.gov/) — primary Senate floor-action record
- [Senate Commerce Committee — updated Protect College Sports Act summary and text](https://www.commerce.senate.gov/pressreleases/updated-bipartisan-protect-college-sports-act-will-stabilize-college-sports-codify-athletes-rights-protections-in-law-expand-athlete-compensation-opportunities/) — primary bill summary and linked legislative text
- [Associated Press — Senate advances Protect College Sports Act](https://apnews.com/article/d4a1a9e0cd6c0a36c0cfd5cf4f87fc42) — independent legislative reporting on the 74–24 cloture vote and proposal
- [Senate passes college-sports bill 77–22](https://apnews.com/article/a63e3f4e0be41fb95062b2bc5e646f9f) — independent reporting
- [President Trump Calls on Congress to Save College Sports](https://www.whitehouse.gov/releases/2026/09/president-trump-calls-on-congress-to-save-college-sports/) — official statement
- [Trump post on Senate passage of the Protect College Sports Act](https://truthsocial.com/@realDonaldTrump/117351985093810875) — primary presidential statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
