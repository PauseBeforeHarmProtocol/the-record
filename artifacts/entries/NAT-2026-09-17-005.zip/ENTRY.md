# Senate votes 77–22 to begin considering college-sports bill

**Entry ID:** NAT-2026-09-17-005
**Date:** September 17, 2026
**Checked:** 2026-09-18 12:00 AM EDT
**Evidence state:** primary Senate floor-action record and committee bill summary plus independent Associated Press reporting; procedural advance, final legislative outcome pending
**Review state:** current-standard-reviewed

The motion to proceed followed a 74–24 cloture vote; neither vote is final Senate passage or enactment.

## THE FACTS

- The Senate agreed 77–22 on September 17 to the motion to proceed to S. 4668, the Protect College Sports Act of 2026. The Senate Daily Press record says leaders then offered a substitute amendment and filled the amendment tree.
- The procedural vote followed a 74–24 vote on September 15 to invoke cloture on the motion to proceed. These votes allow consideration; they do not constitute final passage by the Senate, House approval or enactment.
- The Commerce Committee's published summary says the proposal would establish a national name-image-likeness standard, scholarship and health protections, agent rules, transfer provisions and limited antitrust protection for voluntary pooled media rights. Those are proposed statutory terms, not current nationwide outcomes.
- A final Senate vote was still expected after cutoff, and any enacted text could differ through amendments or subsequent House action. No new payment, scholarship guarantee or legal immunity is counted as implemented.

## SIGNIFICANCE

A lopsided procedural vote moves a national framework for college-athlete compensation and institutional rules closer to a final chamber decision, while leaving the proposal's operative text and legal effects unsettled.

## GOALPOST / RESPONSE

Sponsors say the bill would stabilize college sports while codifying compensation, scholarship, health and women's and Olympic-sports protections. The tests are final amended text, recorded chamber passage, House action, presidential action, regulations, enforcement and measured athlete and school outcomes.

## MAYBE / THEREFORE

Maybe bipartisan procedural support carries through to enactment, or disputes over compensation, antitrust treatment and institutional authority may change or stop the bill. Therefore the verified result is Senate agreement to proceed—not passage of a national college-sports law.


## SOURCES

- [Senate Daily Press — S. 4668 motion to proceed, 77–22](https://www.dailypress.senate.gov/) — primary Senate floor-action record
- [Senate Commerce Committee — updated Protect College Sports Act summary and text](https://www.commerce.senate.gov/pressreleases/updated-bipartisan-protect-college-sports-act-will-stabilize-college-sports-codify-athletes-rights-protections-in-law-expand-athlete-compensation-opportunities/) — primary bill summary and linked legislative text
- [Associated Press — Senate advances Protect College Sports Act](https://apnews.com/article/d4a1a9e0cd6c0a36c0cfd5cf4f87fc42) — independent legislative reporting on the 74–24 cloture vote and proposal

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
