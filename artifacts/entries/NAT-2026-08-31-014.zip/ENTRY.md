# Vance accepts either an 'end times' or long-lived outcome while doing what he calls God's work

**Entry ID:** NAT-2026-08-31-014
**Date:** August 31, 2026
**Checked:** 2026-09-03 6:02 PM EDT
**Evidence state:** primary timestamped podcast recording plus independent Associated Press and Guardian reporting; statement and full-answer context documented, connection to any specific policy or operational decision not established
**Review state:** current-standard-reviewed

The vice president framed his public duties through personal faith and said an end-times outcome would be acceptable, while equally welcoming a better world that survives long after him.

## THE FACTS

- In an August 31 interview with Christian podcaster Bryce Crawford, Vice President JD Vance was asked whether humanity was living in or approaching the Christian 'end times.' He said he did not know and that focusing too much on the question could be spiritually harmful.
- Vance said he was trying to do 'as much of God's work as possible' and added that if this led to the end times, 'okay.' In the same answer, he said it would also be 'great' if it instead helped build a better world that thrives and survives long after his death.
- Earlier in the answer, Vance said his immediate obligations were to be good to his wife and children and to be as good a leader for the United States as possible. The full answer therefore presented two possible outcomes rather than declaring that he wanted or was trying to cause an apocalypse.
- The interview did not define which government policies Vance considers God's work and did not explicitly connect the statement to Iran, nuclear weapons or a particular official decision. Contemporary commentary made that connection, but the primary recording does not establish it.
- Associated Press independently reported the broader discussion, including Vance's statement that he would not be shocked if the Antichrist were present and his concerns about spiritually dark uses of artificial intelligence. These are documented vice-presidential beliefs and rhetoric, not an executive order, military directive or announced policy.

## SIGNIFICANCE

A vice president's public description of governing as God's work—and his stated acceptance of an end-times outcome—matters to evaluating his risk framing, judgment and public accountability, especially during an active war. The complete answer also matters: he did not express a desire to end the world and explicitly welcomed the opposite outcome.

## GOALPOST / RESPONSE

Vance's strongest contextual explanation is the rest of his own answer: people do not know when God is coming, should focus on present duties and should try to build the world God wants. Evidence that this theology influences policy would require decision records, directives, contemporaneous communications or consistent official explanations linking it to a concrete government action; none was identified here.

## MAYBE / THEREFORE

Maybe Vance was expressing conventional religious humility about unknowable outcomes while emphasizing moral conduct, or his willingness to call an apocalyptic result acceptable may reveal a troubling tolerance for catastrophic risk. Therefore the record confirms his complete public statement and faith-based framing—not that he seeks the end times, believes they are certain or used that belief to direct the Iran war or any other policy.


## SOURCES

- [Bryce Crawford Podcast — JD Vance discusses leadership, faith and the end times](https://youtu.be/41RTb_dWORg?t=3671) — primary video record of the vice president's statement in its complete interview context
- [Associated Press — Vance discusses end times and spiritual darkness](https://apnews.com/article/jd-vance-end-times-ai-1914946b096677c40938bb170c02288a) — independent reporting on the podcast's broader context, including Vance's end-times, AI and leadership remarks
- [The Guardian — Vance says he is doing God's work even if it leads to the end times](https://www.theguardian.com/us-news/2026/sep/02/jd-vance-god-podcast-end-times) — independent reporting quoting the operative statement and its alternative long-lived-better-world outcome

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
