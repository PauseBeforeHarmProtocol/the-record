# Forest Service proposes longer grazing permits, leasing priority and a surcharge

**Entry ID:** NAT-2026-11-12-002
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:13 AM EST
**Evidence state:** published Forest Service proposed rule, USDA explanation, agricultural specialist summary and named conservation-group response; proposed only, comments due December 14
**Review state:** current-standard-reviewed

The proposal would expand permit flexibility and access for beginning ranchers while adding a 35% leasing surcharge; comments close December 14 and no provision is final.

## THE FACTS

- The Forest Service published a proposed rangeland-management rule on November 12 and requested comments through December 14. It is a proposal, not a final rule or implemented change.
- The proposal would extend temporary livestock-use permits from one year to as many as five years, authorize targeted and temporary grazing for vegetation and fuels management, and formalize adaptive responses to drought, wildfire and other changing conditions.
- It would let authorized officers give leasing priority to beginning ranchers, mentees and qualifying small businesses. For livestock placed on a permitted allotment under a lease, it proposes a surcharge equal to 35% of the applicable grazing fee, subject to stated exceptions and administration rules.
- USDA says the proposal reduces barriers, supports rural economies and uses grazing as a stewardship tool. Western Watersheds Project argues that it entrenches livestock use and understates wildlife, water and restoration harms. Neither access, revenue, wildfire-risk nor ecological effects have been measured because the rule is not final.

## SIGNIFICANCE

The proposal could change who receives federal grazing access, how long temporary use lasts, how leases are priced and how grazing is used in restoration or fuels work across national forests and grasslands. Its effects depend on the final text and site-level decisions.

## GOALPOST / RESPONSE

USDA frames the proposal as flexible stewardship and a pathway for new and small ranchers. Conservation critics say it privileges livestock and may weaken resource protection. The final rule, allotment decisions, lessee selection, surcharge collections, drought closures, ecological monitoring, wildfire outcomes and litigation are the tests.

## MAYBE / THEREFORE

Maybe longer permits and targeted grazing will improve continuity, entry and land management, or the same flexibility may entrench grazing and shift environmental costs without adequate safeguards. Therefore the archive records a formal proposal open for comment—not a finalized access right, collected surcharge, completed lease or proven ecological or economic result.


## SOURCES

- [Forest Service — rangeland management proposed rule](https://www.federalregister.gov/documents/2026/11/12/2026-23033/rangeland-management) — primary proposed rule; grazing permits, leasing surcharge and adaptive management
- [USDA — proposed rule to expand grazing-allotment access](https://usda.azureedge.us/about-usda/news/press-releases/2026/11/10/usda-proposes-federal-rule-expand-access-grazing-allotments-american-ranchers) — primary administration announcement and rationale
- [U.S. Farm News — Forest Service grazing proposal](https://usfarmnews.com/livestock/forest-service-grazing-rule-permits-leasing-surcharge-2026/) — independent agricultural specialist summary of permit, leasing and surcharge provisions
- [Western Watersheds Project — response to Forest Service grazing proposal](https://www.westernwatersheds.org/2026/11/forest-services-proposed-regulations-entrench-livestock-industry-on-public-lands/) — named conservation-group response and competing land-management analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
