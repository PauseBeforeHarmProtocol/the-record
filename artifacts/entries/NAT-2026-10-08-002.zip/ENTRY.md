# Labor inspector general subpoenas nine universities in visa and foreign-influence probe

**Entry ID:** NAT-2026-10-08-002
**Date:** October 8, 2026
**Checked:** 2026-10-08 12:00 PM EDT
**Evidence state:** named Labor inspector general announcement independently reported by Reuters and AP; subpoenas reported served, underlying evidence and findings not public
**Review state:** current-standard-reviewed

The investigation covers Harvard, Yale, Stanford and six other institutions; subpoenas establish a formal inquiry, not findings of visa abuse or unlawful foreign influence.

## THE FACTS

- Labor Department Inspector General Anthony D'Esposito said subpoenas had been served in an investigation of foreign influence, improper financial relationships and possible visa abuse in federally funded university research. Reuters and Associated Press independently reported the White House news conference.
- Associated Press identified the nine institutions as Harvard, Yale, Stanford, Brown, the University of Pittsburgh, the University of California at Davis, the California Institute of Technology, Arizona State University and the Massachusetts Institute of Technology.
- Vance alleged that universities were using J-1 visas and international students to undercut American wages. The inspector general framed the inquiry as examining whether foreign relationships or visa practices compromised federally funded research. Those statements define the investigation's theories; they are not findings that any named institution broke the law.
- No subpoena text, institution-specific allegation, response deadline, institutional response or investigative finding was public in the reviewed material by cutoff. The record therefore treats the served subpoenas as a credible investigation stage, not a completed enforcement case.

## SIGNIFICANCE

Subpoenas give the inquiry compulsory investigative force across major research universities and connect visa enforcement to federal research security. The breadth also creates risk of reputational or operational consequences before institution-specific evidence is disclosed.

## GOALPOST / RESPONSE

The administration says the investigation will protect U.S. workers and federally funded research from visa abuse and improper foreign influence. The subpoena scopes, responses, inspector-general findings, referrals, enforcement decisions and any judicial review are the tests.

## MAYBE / THEREFORE

Maybe the subpoenas uncover concrete abuse or undisclosed foreign relationships, or the inquiry may find compliant programs and no institution-specific violations. Therefore nine universities are under a formal subpoena-backed investigation; no inspected evidence establishes guilt, compromised research or wage effects at any named institution.


## SOURCES

- [White House Live — Vice President JD Vance Holds Press Conference on Fighting Visa Fraud](https://www.whitehouse.gov/live/) — official event listing
- [Reuters — U.S. suspends Microsoft and major IT firms from key green-card program](https://www.reuters.com/business/us-suspending-permanent-residency-program-for-microsoft-vance-says-2026-10-08/) — independent reporting
- [AP — Microsoft suspended from green-card program as administration alleges fraud](https://apnews.com/article/h1b-visa-program-vance-microsoft-e7b3a407f822702b269ee277d21343ea) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
