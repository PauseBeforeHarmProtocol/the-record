# Reuters analysis measures EV-factory cancellations and auto-job decline

**Entry ID:** NAT-2026-09-15-017
**Date:** September 15–16, 2026
**Checked:** 2026-09-16 12:33 PM EDT
**Evidence state:** Reuters special report using Atlas Public Policy project data, federal employment data, company statements and on-site reporting; measured cancellations and employment change with causal and coverage limitations
**Review state:** current-standard-reviewed

Projects canceled since January 2025 had promised about 27,000 jobs, while auto-manufacturing employment fell 1.3%; preexisting demand weakness and uncounted gas-vehicle conversions limit single-cause claims.

## THE FACTS

- Reuters analyzed Atlas Public Policy records and found that electric-vehicle and related battery projects canceled from January 2025 through August 24, 2026 had promised about 27,000 jobs. Reuters called that an undercount because some projects lacked job estimates and the tally excluded scaled-back projects and mixed investments whose EV share could not be isolated.
- The Atlas data showed nearly $20 billion of projects canceled in 2025. New auto-investment announcements fell to about $6.5 billion that year, 29% of the prior year's level and well below the approximately $55 billion peak in 2023; about four-fifths of canceled investment was in states Trump won in 2024.
- Federal data cited by Reuters showed U.S. auto-manufacturing employment down 1.3% from January 2025 to about 963,000 in August 2026. The analysis did not quantify all jobs or investment that may result from converting EV facilities to gasoline vehicles, and it therefore did not establish a complete net effect across every announced project.
- Reuters linked the retreat to the expired $7,500 consumer tax credit, weaker emissions and fuel-economy requirements, tariffs on battery inputs and tighter immigration enforcement. Ford's chief executive called the post-credit sales decline the impetus for a major write-down, while Reuters also documented that EV investment and demand had slowed before the policy changes because of prices, range concerns and overly optimistic forecasts.
- The White House said Biden-era subsidies created artificial demand and pointed to deregulation, tax changes, trade deals and announced auto investment. Reuters reported that tariffs and gas-vehicle retooling had not yet produced a net auto-manufacturing job gain; later hiring, factory conversions and completed investments remain measurable tests rather than assumed outcomes.

## SIGNIFICANCE

The analysis connects national policy changes to a measurable reversal in a manufacturing buildout concentrated in politically supportive states, while preserving market weakness and incomplete conversion data as material alternative explanations. It tests the administration's manufacturing claims against project and employment outcomes rather than announcements alone.

## GOALPOST / RESPONSE

The administration says removing an artificial EV mandate protects consumer choice and that its broader policies are attracting new auto investment. The tests are completed capital spending, openings and closures, net auto jobs, capacity utilization, domestic battery output, EV and gasoline sales, project conversions and U.S. market share against China and Europe.

## MAYBE / THEREFORE

Maybe canceled EV projects are replaced by profitable domestic gasoline, hybrid or storage-battery production, or the policy reversal may leave durable unused capacity and lost supply-chain capability. Therefore the evidence shows canceled projects promising about 27,000 jobs and a 1.3% auto-employment decline through August—not that federal policy alone caused every cancellation or that announced replacement investment will fail.


## SOURCES

- [Reuters investigation — EV policy changes and U.S. auto-factory investment](https://www.reuters.com/investigations/how-trumps-war-evs-derailed-americas-auto-factory-revival-2026-09-15/) — independent data analysis using Atlas Public Policy project records, federal employment data, company statements and on-site reporting
- [Atlas EV Hub — electric-vehicle market, policy and manufacturing data](https://www.atlasevhub.com/) — primary project page for the nonpartisan EV-investment dataset used in the Reuters analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
