# Trump signs narrower revision to Canadian 50% tariff product scope

**Entry ID:** NAT-2026-08-22-001
**Date:** August 18–October 23, 2026
**Checked:** 2026-10-23 6:01 PM EDT
**Evidence state:** primary presidential proclamation plus Associated Press reporting; product-scope revision ordered with October 30 effective date, implementation and effects pending
**Review state:** current-standard-reviewed

The October 23 proclamation schedules product removals and additions for October 30 while leaving the broader Canada trade restrictions in place.

## THE FACTS

- After bilateral talks collapsed, 50% U.S. tariffs took effect August 22 on C$27.6 billion in Canadian goods—about $20 billion and roughly 5% of Canada's exports to the United States, according to Reuters. The duties cover selected products rather than all Canadian trade.
- Canada's matching 15%, 25%, and 50% counter-tariffs took effect at 12:01 a.m. EDT on September 8 under an order in council. The official schedule covers C$27.6 billion—about $20 billion—in U.S. imports across steel, dairy, appliances, agricultural equipment, pulp and paper, electronics, and other product categories; in-transit goods are excluded.
- Reuters reported after the effective time that no official bilateral talks were under way. It also reported, from Canadian and U.S. government data, that roughly 80% of Canada's exports to the United States had moved duty-free this year through USMCA exemptions, limiting the direct reach of the selected U.S. duties while leaving concentrated sector exposure.
- On September 8, Trump signed five proclamations under section 338 of the Tariff Act. Two modify the products covered by existing 50% motor-vehicle and alcoholic-beverage duties effective September 15, adding some tariff lines and removing others. Three separately exclude listed Canadian alcoholic beverages, dairy-related products, motorcycles and mopeds from importation beginning September 29. The annex-based measures are product-specific, not blanket bans on all Canadian alcohol, dairy or vehicles.
- At announcement, the White House said the measures answered Canada's dairy and vehicle systems, provincial restrictions on U.S. alcohol and Saskatchewan's new levy. Canada called the measures unjustified, while officials on both sides said their trade representatives remained in contact. The proclamations established the September 29 effective date; later implementation is recorded separately below.
- Trump's separate threat to impose 50% tariffs in 2027 on broader Canadian vehicle, parts and steel trade remains announced rather than implemented. A September 8 direction concerning Canadian goods on GSA procurement schedules is tracked as a separate mechanism in NAT-2026-09-08-005.
- Restored as a prior-window omission, Reuters reported on September 12 that Canadian grocers were expanding local and third-country sourcing amid a consumer boycott of U.S. products. Canadian government data put the U.S. share of Canada's vegetable imports at 62.6% in July, down from 69% in July 2023; Reuters also documented one Ontario grocer sourcing about 90% of produce domestically, new origin labeling and a federal C$3 billion greenhouse-investment plan. These observations show adaptation in selected products and businesses—not a complete national boycott, a post-tariff causal estimate or measured U.S. employment and price effects.
- The three product-specific import bans took effect at 12:01 a.m. EDT on September 29. Associated Press reported an American Action Forum estimate that covered 2025 trade totaled about $967 million, roughly 87% of it alcoholic beverages, with additional covered dairy and whey products, motorcycles and mopeds. AP said the earlier 50% tariffs had already sharply reduced affected trade, so the incremental economic effect was expected to be modest; no concession, price effect, output gain or employment result had been measured by cutoff.
- On October 23, Trump signed a proclamation removing certain Canadian products listed in Annex I Part A from the 50% additional duties and adding products listed in Part B, effective October 30 at 12:01 a.m. EDT. Associated Press reported examples among the exemptions including plywood sheets, packing crates and some machinery. The order was signed and scheduled, not yet effective by cutoff; its annex-based changes do not repeal the broader Canada measures.

## SIGNIFICANCE

The administration is recalibrating a product-specific tariff regime rather than lifting the broader trade dispute. The signed revision may reduce costs for exempted products while adding exposure elsewhere, but no October 30 customs outcome or broader concession was measured by cutoff.

## GOALPOST / RESPONSE

The administration says the changes serve the public interest while continuing to offset Canadian discrimination. Customs implementation, product-level import and price data, published exceptions, Canadian response, negotiations and any judicial challenge are the tests.

## MAYBE / THEREFORE

Maybe targeted exemptions reduce unintended costs while preserving bargaining leverage, or shifting tariff lines may merely redistribute burdens without concessions. Therefore the proclamation is signed and scheduled for October 30—not yet implemented or proof of lower prices, stronger output or a resolved Canada dispute.


## SOURCES

- [Reuters — U.S.-Canada talks fail before 50% duties take effect](https://www.reuters.com/world/americas/us-canadian-trade-teams-meet-again-tariffs-deadline-looms-2026-08-21/) — independent reporting on trade negotiations and implemented tariffs
- [Department of Finance Canada — product list for September 8 counter-tariffs](https://www.canada.ca/en/department-finance/news/2026/08/list-of-products-from-the-united-states-subject-to-counter-tariffs-effective-september-8-2026.html) — primary government schedule identifying the rates, covered imports, sectors, origin rule and 12:01 a.m. effective time
- [Reuters — Canadian counter-tariffs take effect as trade talks stall](https://www.reuters.com/business/autos-transportation/canadas-retaliatory-tariffs-take-effect-us-trade-talks-stall-2026-09-08/) — independent reporting published after the effective time on implementation, trade exposure, talks and USMCA exemptions
- [Associated Press — Canada implements counter-tariffs on U.S. goods](https://apnews.com/article/4620ffb5ecc029322217207fa6758431) — independent reporting on the order-in-council implementation, covered trade, product rates and competing economic rationales
- [White House — modified Canadian motor-vehicle tariff scope](https://www.whitehouse.gov/presidential-actions/2026/09/modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-united-states-with-respect-to-motor-vehicles/) — primary proclamation adding and removing tariff lines under the 50% motor-vehicle duty effective September 15
- [White House — modified Canadian alcoholic-beverage tariff scope](https://www.whitehouse.gov/presidential-actions/2026/09/modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-united-states-with-respect-to-alcoholic-beverages/) — primary proclamation changing tariff lines under the 50% alcoholic-beverage duty effective September 15
- [White House — Canadian alcoholic-beverage import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-alcoholic-beverages-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-alcoholic-bever/) — primary proclamation scheduling annex-listed Canadian alcoholic-beverage exclusions for September 29
- [White House — Canadian dairy-related import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-products-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-dairy/) — primary proclamation scheduling annex-listed Canadian dairy-related product exclusions for September 29
- [White House — Canadian motor-product import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-products-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-motor-vehicles/) — primary proclamation scheduling annex-listed Canadian motorcycle and moped exclusions for September 29
- [Associated Press — United States schedules Canadian dairy, alcohol and motorcycle bans](https://apnews.com/article/a5fbb50d1c30327ae813482556a37ac3) — independent reporting on the five proclamations, product scope, future effective dates and Canadian response
- [Reuters — Canadian grocery boycott shifts sourcing away from U.S. products](https://www.reuters.com/business/retail-consumer/canadian-boycott-us-products-pushes-grocers-adapt-explore-new-supply-sources-2026-09-12/) — independent reporting and government-data analysis of trade-related supply-chain adaptation
- [AP — Targeted U.S. bans on Canadian imports take effect](https://apnews.com/article/canada-us-trade-ban-tariffs-bdb4d9b946e98f84088c5c0f7f522588) — independent reporting with trade-data analysis and named responses
- [White House — proclamation further modifying Canadian tariff scope](https://www.whitehouse.gov/presidential-actions/2026/10/further-modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-commerce-of-the-united-states-with-respect-to-motor-vehicles/) — primary presidential proclamation with October 30 effective date
- [Associated Press — Trump exempts some Canadian imports from 50% tariffs](https://apnews.com/article/trump-tariffs-canada-susan-collins-ede51283125c071561178e6455048994) — independent reporting on product examples, political context and effective date

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
