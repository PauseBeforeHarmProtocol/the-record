# U.S. schedules Canadian import bans after reciprocal tariffs take effect

**Entry ID:** NAT-2026-08-22-001
**Date:** August 18–September 8, 2026
**Checked:** 2026-09-08 11:58 PM EDT
**Evidence state:** primary Canadian schedule and five White House proclamations plus Associated Press and Reuters reporting; reciprocal selected tariffs implemented, U.S. tariff-list changes scheduled for September 15 and targeted import exclusions scheduled for September 29, broader 2027 threat unimplemented
**Review state:** current-standard-reviewed

Canada’s counter-tariffs are implemented; five U.S. proclamations change tariff coverage on September 15 and schedule targeted import bans for September 29.

## THE FACTS

- After bilateral talks collapsed, 50% U.S. tariffs took effect August 22 on C$27.6 billion in Canadian goods—about $20 billion and roughly 5% of Canada's exports to the United States, according to Reuters. The duties cover selected products rather than all Canadian trade.
- Canada's matching 15%, 25%, and 50% counter-tariffs took effect at 12:01 a.m. EDT on September 8 under an order in council. The official schedule covers C$27.6 billion—about $20 billion—in U.S. imports across steel, dairy, appliances, agricultural equipment, pulp and paper, electronics, and other product categories; in-transit goods are excluded.
- Reuters reported after the effective time that no official bilateral talks were under way. It also reported, from Canadian and U.S. government data, that roughly 80% of Canada's exports to the United States had moved duty-free this year through USMCA exemptions, limiting the direct reach of the selected U.S. duties while leaving concentrated sector exposure.
- On September 8, Trump signed five proclamations under section 338 of the Tariff Act. Two modify the products covered by existing 50% motor-vehicle and alcoholic-beverage duties effective September 15, adding some tariff lines and removing others. Three separately exclude listed Canadian alcoholic beverages, dairy-related products, motorcycles and mopeds from importation beginning September 29. The annex-based measures are product-specific, not blanket bans on all Canadian alcohol, dairy or vehicles.
- The White House says the measures answer Canada's dairy and vehicle systems, provincial restrictions on U.S. alcohol and Saskatchewan's new levy. Canada called the measures unjustified, while officials on both sides said their trade representatives remained in contact. The proclamations establish future effective dates; they do not show that the bans have taken effect, produced concessions or improved U.S. prices, output or employment.
- Trump's separate threat to impose 50% tariffs in 2027 on broader Canadian vehicle, parts and steel trade remains announced rather than implemented. A September 8 direction concerning Canadian goods on GSA procurement schedules is tracked as a separate mechanism in NAT-2026-09-08-005.

## SIGNIFICANCE

The September 8 proclamations move the dispute beyond reciprocal tariffs to scheduled, product-level import exclusions and further tariff-list changes. They create new legal and economic tests for integrated North American supply chains, but their future effective dates and limited annexes make it inaccurate to describe all Canadian dairy, alcohol or vehicles as already banned.

## GOALPOST / RESPONSE

The administration says the restrictions answer Canadian discrimination and will create leverage for reciprocal access. Canada says the measures are unjustified and that diversification is preferable to dependency. The tests are September 15 and 29 customs implementation, published tariff lines and exceptions, collections, import volumes, consumer and producer prices, supply-chain changes, employment and investment, renewed negotiations and any suspension or judicial challenge.

## MAYBE / THEREFORE

Maybe targeted duties and exclusions produce bargaining leverage without broad disruption, or concentrated industries and consumers may absorb costs while each side diversifies rather than concedes. Therefore both countries' selected tariffs are implemented and the United States has signed future-effective tariff modifications and import exclusions—not a blanket Canadian-goods ban, completed procurement removal, measured economic success or implementation of the broader 2027 threat.


## SOURCES

- [Reuters — U.S.-Canada talks fail before 50% duties take effect](https://www.reuters.com/world/americas/us-canadian-trade-teams-meet-again-tariffs-deadline-looms-2026-08-21/) — independent reporting on trade negotiations and implemented tariffs
- [Department of Finance Canada — product list for September 8 counter-tariffs](https://www.canada.ca/en/department-finance/news/2026/08/list-of-products-from-the-united-states-subject-to-counter-tariffs-effective-september-8-2026.html) — primary government schedule identifying the rates, covered imports, sectors, origin rule and 12:01 a.m. effective time
- [Reuters — Canadian counter-tariffs take effect as trade talks stall](https://www.reuters.com/business/autos-transportation/canadas-retaliatory-tariffs-take-effect-us-trade-talks-stall-2026-09-08/) — independent reporting published after the effective time on implementation, trade exposure, talks and USMCA exemptions
- [Associated Press — Canada implements counter-tariffs on U.S. goods](https://apnews.com/article/4620ffb5ecc029322217207fa6758431) — independent reporting on the order-in-council implementation, covered trade, product rates and competing economic rationales
- [White House — modified Canadian motor-vehicle tariff scope](https://www.whitehouse.gov/presidential-actions/2026/09/modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-united-states-with-respect-to-motor-vehicles/) — primary proclamation adding and removing tariff lines under the 50% motor-vehicle duty effective September 15
- [White House — modified Canadian alcoholic-beverage tariff scope](https://www.whitehouse.gov/presidential-actions/2026/09/modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-united-states-with-respect-to-alcoholic-beverages/) — primary proclamation changing tariff lines under the 50% alcoholic-beverage duty effective September 15
- [White House — Canadian alcoholic-beverage import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-alcoholic-beverages-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-alcoholic-bever/) — primary proclamation scheduling annex-listed Canadian alcoholic-beverage exclusions for September 29
- [White House — Canadian dairy-related import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-products-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-dairy/) — primary proclamation scheduling annex-listed Canadian dairy-related product exclusions for September 29
- [White House — Canadian motor-product import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-products-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-motor-vehicles/) — primary proclamation scheduling annex-listed Canadian motorcycle and moped exclusions for September 29
- [Associated Press — United States schedules Canadian dairy, alcohol and motorcycle bans](https://apnews.com/article/a5fbb50d1c30327ae813482556a37ac3) — independent reporting on the five proclamations, product scope, future effective dates and Canadian response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
