# U.S. imposes 50% duties on selected Canadian goods as Trump announces a broader 2027 escalation

**Entry ID:** NAT-2026-08-22-001
**Date:** August 18–25, 2026
**Checked:** 2026-08-25 11:58 AM EDT
**Evidence state:** primary U.S. and Canadian announcements plus independent reporting; selected U.S. duties implemented, Canadian counter-tariffs scheduled, broader 2027 U.S. action announced

The entry separates tariffs already in force from the president's later statement about future duties on vehicles, parts, and steel.

## THE FACTS

- Trump temporarily suspended additional duties on certain Canadian alcoholic beverages, dairy products, and motor vehicles for three days beginning August 18 while trade talks continued.
- After the talks failed, 50% U.S. tariffs took effect August 22 on C$27.6 billion in Canadian goods—about $20 billion and roughly 5% of Canada's exports—according to Reuters. Canada suspended talks; the U.S. duties were implemented, while Canada's response remained pending at the checked time.
- On August 24, Trump said tariffs on all Canadian cars, trucks, parts, and steel would rise to 50% on January 1, 2027. That broader step was announced but was not yet in force at the checked time.
- On August 25, Canada formally announced matching 15%, 25%, and 50% counter-tariffs on more than 700 U.S. product categories covering C$27.6 billion in imports, effective September 8. The package targets steel, aluminum, dairy, appliances, agricultural equipment, pulp and paper, electronics, and other products; it was announced but had not taken effect.
- Canada also announced C$7.5 billion in worker and business support. Prime Minister Mark Carney said Canada rejected U.S. proposals that would dismantle major Canadian industries. Ontario Premier Doug Ford said electricity and critical-mineral restrictions remained possible if the dispute worsened; those additional countermeasures were threatened, not implemented.

## SIGNIFICANCE

The Canadian package converts an earlier promise of retaliation into a dated, product-level plan and adds substantial public support for affected firms and workers. The implemented U.S. duties and scheduled Canadian response now create measurable exposure on both sides of an integrated trading relationship, while the broader 2027 U.S. escalation remains only announced.

## GOALPOST / RESPONSE

The administration says the tariffs answer Canadian discrimination against U.S. commerce and create leverage for a better agreement. Canada says its response is designed to match U.S. measures while protecting workers and strategic sectors. The economic test will be whether the September 8 counter-tariffs take effect as scheduled, the final exemptions, consumer and producer costs, supply-chain changes, and any negotiated settlement.

## MAYBE / THEREFORE

Maybe the September 8 lead time leaves room for negotiation or product exemptions, and announced aid may offset some domestic harm. Therefore the record distinguishes the U.S. tariffs already in force from Canada's scheduled counter-tariffs and Trump's future 2027 expansion, and will measure implementation and economic effects separately.


## SOURCES

- [White House — three-day suspension of additional Canada duties](https://www.whitehouse.gov/presidential-actions/2026/08/temporary-suspension-of-additional-duties-to-offset-canadian-discrimination-against-the-commerce-of-the-united-states-with-respect-to-alcoholic-beverages-dairy-and-motor-vehicles/) — primary presidential proclamation
- [Reuters — U.S.-Canada talks fail before 50% duties take effect](https://www.reuters.com/world/americas/us-canadian-trade-teams-meet-again-tariffs-deadline-looms-2026-08-21/) — independent reporting on trade negotiations and implemented tariffs
- [Reuters — Trump announces broader 2027 Canada tariff escalation](https://www.reuters.com/business/autos-transportation/trump-says-he-will-raise-tariffs-all-cars-trucks-50-amid-canada-trade-spat-2026-08-24/) — independent reporting on a stated future action
- [Associated Press — Canada rejects subordination as tariff conflict escalates](https://apnews.com/article/canada-trade-trump-ontario-53c4f83c8365c14b372b314396ae8179) — independent reporting on implemented tariffs, announced escalation, and Canada's response
- [Department of Finance Canada — counter-tariffs and worker and business support package](https://www.canada.ca/en/department-finance/news/2026/08/canada-announces-targeted-countermeasures-and-substantive-support-for-workers-and-businesses-in-response-to-us-tariffs.html) — primary government announcement of scheduled counter-tariffs and support measures
- [Reuters — Canada announces retaliatory tariffs and support measures](https://www.reuters.com/business/canada-announces-20-bln-retaliatory-tariffs-us-goods-unveils-support-measures-2026-08-25/) — independent reporting on the scheduled counter-tariffs, product coverage, and support package
- [Associated Press — Canada sets retaliatory tariffs for September 8](https://apnews.com/article/810649a0a4143d9042094626c4a36dad) — independent reporting on the scheduled Canadian counter-tariffs and official response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
