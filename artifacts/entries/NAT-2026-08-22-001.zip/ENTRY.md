# U.S.-Canada trade fight shifts sourcing after reciprocal tariffs and scheduled import bans

**Entry ID:** NAT-2026-08-22-001
**Date:** August 18–September 12, 2026
**Checked:** 2026-09-13 11:59 AM EDT
**Evidence state:** primary Canadian schedule and five White House proclamations plus Associated Press and Reuters reporting; selected tariffs implemented, U.S. exclusions scheduled, and limited Canadian sourcing adaptation measured without a national causal estimate
**Review state:** current-standard-reviewed

Canada’s counter-tariffs are implemented and U.S. bans remain scheduled, while measured import shares and grocery sourcing show limited early diversification rather than a complete break from U.S. supply.

## THE FACTS

- After bilateral talks collapsed, 50% U.S. tariffs took effect August 22 on C$27.6 billion in Canadian goods—about $20 billion and roughly 5% of Canada's exports to the United States, according to Reuters. The duties cover selected products rather than all Canadian trade.
- Canada's matching 15%, 25%, and 50% counter-tariffs took effect at 12:01 a.m. EDT on September 8 under an order in council. The official schedule covers C$27.6 billion—about $20 billion—in U.S. imports across steel, dairy, appliances, agricultural equipment, pulp and paper, electronics, and other product categories; in-transit goods are excluded.
- Reuters reported after the effective time that no official bilateral talks were under way. It also reported, from Canadian and U.S. government data, that roughly 80% of Canada's exports to the United States had moved duty-free this year through USMCA exemptions, limiting the direct reach of the selected U.S. duties while leaving concentrated sector exposure.
- On September 8, Trump signed five proclamations under section 338 of the Tariff Act. Two modify the products covered by existing 50% motor-vehicle and alcoholic-beverage duties effective September 15, adding some tariff lines and removing others. Three separately exclude listed Canadian alcoholic beverages, dairy-related products, motorcycles and mopeds from importation beginning September 29. The annex-based measures are product-specific, not blanket bans on all Canadian alcohol, dairy or vehicles.
- The White House says the measures answer Canada's dairy and vehicle systems, provincial restrictions on U.S. alcohol and Saskatchewan's new levy. Canada called the measures unjustified, while officials on both sides said their trade representatives remained in contact. The proclamations establish future effective dates; they do not show that the bans have taken effect, produced concessions or improved U.S. prices, output or employment.
- Trump's separate threat to impose 50% tariffs in 2027 on broader Canadian vehicle, parts and steel trade remains announced rather than implemented. A September 8 direction concerning Canadian goods on GSA procurement schedules is tracked as a separate mechanism in NAT-2026-09-08-005.
- Restored as a prior-window omission, Reuters reported on September 12 that Canadian grocers were expanding local and third-country sourcing amid a consumer boycott of U.S. products. Canadian government data put the U.S. share of Canada's vegetable imports at 62.6% in July, down from 69% in July 2023; Reuters also documented one Ontario grocer sourcing about 90% of produce domestically, new origin labeling and a federal C$3 billion greenhouse-investment plan. These observations show adaptation in selected products and businesses—not a complete national boycott, a post-tariff causal estimate or measured U.S. employment and price effects.

## SIGNIFICANCE

The dispute has moved beyond formal tariffs and scheduled product exclusions into observable sourcing changes by some Canadian grocers and a lower U.S. share of Canadian vegetable imports. Those measurements show supply-chain adaptation, but the comparison predates the latest tariffs and does not establish national causality, a complete boycott or net economic effects on either country.

## GOALPOST / RESPONSE

The administration says the restrictions answer Canadian discrimination and will create leverage for reciprocal access. Canada says the measures are unjustified and is promoting diversification and domestic supply. The tests are September 15 and 29 customs implementation, published tariff lines and exceptions, collections, product-level import shares, consumer and producer prices, U.S. export volumes, employment and investment, renewed negotiations and any suspension or judicial challenge.

## MAYBE / THEREFORE

Maybe targeted duties and exclusions produce bargaining leverage while diversification remains limited, or sustained sourcing shifts may reduce U.S. market share without producing Canadian concessions. Therefore selected tariffs are implemented, U.S. exclusions are scheduled and some Canadian supply-chain adaptation is measured—not a blanket Canadian-goods ban, a complete boycott, proof the latest tariffs caused every sourcing change or measured overall economic success.


## SOURCES

- [Reuters — U.S.-Canada talks fail before 50% duties take effect](https://www.reuters.com/world/americas/us-canadian-trade-teams-meet-again-tariffs-deadline-looms-2026-08-21/) — independent reporting on trade negotiations and implemented tariffs
- [Department of Finance Canada — product list for September 8 counter-tariffs](https://www.canada.ca/en/department-finance/news/2026/08/list-of-products-from-the-united-states-subject-to-counter-tariffs-effective-september-8-2026.html) — primary government schedule identifying the rates, covered imports, sectors, origin rule and 12:01 a.m. effective time
- [Reuters — Canadian counter-tariffs take effect as trade talks stall](https://www.reuters.com/business/autos-transportation/canadas-retaliatory-tariffs-take-effect-us-trade-talks-stall-2026-09-08/) — independent reporting published after the effective time on implementation, trade exposure, talks and USMCA exemptions
- [Associated Press — Canada implements counter-tariffs on U.S. goods](https://apnews.com/article/4620ffb5ecc029322217207fa6758431) — independent reporting on the order-in-council implementation, covered trade, product rates and competing economic rationales
- [White House — modified Canadian motor-vehicle tariff scope](https://www.whitehouse.gov/presidential-actions/2026/09/modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-united-states-with-respect-to-motor-vehicles/) — primary proclamation adding and removing tariff lines under the 50% motor-vehicle duty effective September 15
- [White House — modified Canadian alcoholic-beverage tariff scope](https://www.whitehouse.gov/presidential-actions/2026/09/modifying-the-scope-of-products-of-canada-subject-to-the-additional-duties-imposed-to-offset-canadian-discrimination-against-the-united-states-with-respect-to-alcoholic-beverages/) — primary proclamation changing tariff lines under the 50% alcoholic-beverage duty effective September 15
- [White House — Canadian alcoholic-beverage import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-alcoholic-beverages-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-alcoholic-bever/) — primary proclamation scheduling annex-listed Canadian alcoholic-beverage exclusions for September 29
- [White House — Canadian dairy-related import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-products-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-dairy/) — primary proclamation scheduling annex-listed Canadian dairy-related product exclusions for September 29
- [White House — Canadian motor-product import exclusions](https://www.whitehouse.gov/presidential-actions/2026/09/excluding-certain-canadian-products-from-importation-into-the-united-states-in-response-to-continued-discrimination-against-the-commerce-of-the-united-states-with-respect-to-motor-vehicles/) — primary proclamation scheduling annex-listed Canadian motorcycle and moped exclusions for September 29
- [Associated Press — United States schedules Canadian dairy, alcohol and motorcycle bans](https://apnews.com/article/a5fbb50d1c30327ae813482556a37ac3) — independent reporting on the five proclamations, product scope, future effective dates and Canadian response
- [Reuters — Canadian grocery boycott shifts sourcing away from U.S. products](https://www.reuters.com/business/retail-consumer/canadian-boycott-us-products-pushes-grocers-adapt-explore-new-supply-sources-2026-09-12/) — independent reporting and government-data analysis of trade-related supply-chain adaptation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
