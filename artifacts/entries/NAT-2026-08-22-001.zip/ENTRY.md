# U.S. imposes 50% duties on selected Canadian goods as Trump announces a broader 2027 escalation

**Entry ID:** NAT-2026-08-22-001
**Date:** August 18–24, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** primary temporary proclamation and independent reporting; selected duties implemented, broader 2027 action announced

The entry separates tariffs already in force from the president's later statement about future duties on vehicles, parts, and steel.

## THE FACTS

- Trump temporarily suspended additional duties on certain Canadian alcoholic beverages, dairy products, and motor vehicles for three days beginning August 18 while trade talks continued.
- After the talks failed, 50% U.S. tariffs took effect August 22 on about $20 billion in Canadian goods—roughly 5% of Canada's exports—according to Reuters. Canada suspended talks and announced dollar-for-dollar retaliation.
- On August 24, Trump said tariffs on all Canadian cars, trucks, parts, and steel would rise to 50% on January 1, 2027. That broader step was announced but was not yet in force at the checked time.

## SIGNIFICANCE

The implemented duties already affect a major trading relationship; the announced 2027 expansion could reach integrated North American vehicle and steel supply chains much more broadly. Separating effective tariffs from future threats prevents market-moving rhetoric from being recorded as completed policy.

## GOALPOST / RESPONSE

The administration says the tariffs answer Canadian discrimination against U.S. commerce and create leverage for a better agreement. Canada calls them unjustified and promises retaliation. The economic test will be the final tariff schedule, exemptions, consumer and producer costs, supply-chain changes, and any negotiated settlement.


## SOURCES

- [White House — three-day suspension of additional Canada duties](https://www.whitehouse.gov/presidential-actions/2026/08/temporary-suspension-of-additional-duties-to-offset-canadian-discrimination-against-the-commerce-of-the-united-states-with-respect-to-alcoholic-beverages-dairy-and-motor-vehicles/) — primary presidential proclamation
- [Reuters — U.S.-Canada talks fail before 50% duties take effect](https://www.reuters.com/world/americas/us-canadian-trade-teams-meet-again-tariffs-deadline-looms-2026-08-21/) — independent reporting on trade negotiations and implemented tariffs
- [Reuters — Trump announces broader 2027 Canada tariff escalation](https://www.reuters.com/business/autos-transportation/trump-says-he-will-raise-tariffs-all-cars-trucks-50-amid-canada-trade-spat-2026-08-24/) — independent reporting on a stated future action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
