# Canadian counter-tariffs take effect after U.S. imposes 50% duties

**Entry ID:** NAT-2026-08-22-001
**Date:** August 18–September 8, 2026
**Checked:** 2026-09-08 1:16 AM EDT
**Evidence state:** primary Canadian tariff schedule plus Reuters and Associated Press reporting; selected U.S. and Canadian duties implemented, broader future U.S. escalation announced
**Review state:** current-standard-reviewed

Canada's matching tariffs are now implemented; Trump's broader vehicle, parts, and steel escalation remains an announced future step.

## THE FACTS

- After bilateral talks collapsed, 50% U.S. tariffs took effect August 22 on C$27.6 billion in Canadian goods—about $20 billion and roughly 5% of Canada's exports to the United States, according to Reuters. The duties cover selected products rather than all Canadian trade.
- Canada's matching 15%, 25%, and 50% counter-tariffs took effect at 12:01 a.m. EDT on September 8 under an order in council. The official schedule covers C$27.6 billion—about $20 billion—in U.S. imports across steel, dairy, appliances, agricultural equipment, pulp and paper, electronics, and other product categories; in-transit goods are excluded.
- Reuters reported after the effective time that no official bilateral talks were under way. It also reported, from Canadian and U.S. government data, that roughly 80% of Canada's exports to the United States had moved duty-free this year through USMCA exemptions, limiting the direct reach of the selected U.S. duties while leaving concentrated sector exposure.
- Trump has separately threatened 50% tariffs next year on Canadian vehicles, auto parts, and steel if Canada does not 'fall in line.' That broader escalation remains announced rather than implemented, and the administration has not published a final product schedule or operative instrument for it.

## SIGNIFICANCE

Canada's implementation converts a scheduled response into reciprocal duties on selected cross-border trade and creates an observable cost and negotiation test. The measures affect integrated supply chains, but most Canadian exports had continued to enter the United States duty-free under exemptions, so neither side's selected tariff package should be described as covering all bilateral commerce.

## GOALPOST / RESPONSE

The administration says its tariffs answer Canadian discrimination and create leverage for a better agreement. Canada says dollar-for-dollar retaliation protects domestic workers and industries while creating leverage of its own. The tests are customs collections, exemptions, consumer and producer prices, trade diversion, employment and investment effects, renewed negotiations, and whether the separately threatened 2027 U.S. duties receive an operative instrument.

## MAYBE / THEREFORE

Maybe reciprocal tariffs produce bargaining leverage and a later settlement without broad economic damage; alternatively, exemptions may soften aggregate effects while individual industries absorb substantial costs. Therefore the record now treats both selected tariff packages as implemented, but does not treat the wider U.S. escalation as operative or infer economic success or failure before outcomes are measured.


## SOURCES

- [Reuters — U.S.-Canada talks fail before 50% duties take effect](https://www.reuters.com/world/americas/us-canadian-trade-teams-meet-again-tariffs-deadline-looms-2026-08-21/) — independent reporting on trade negotiations and implemented tariffs
- [Department of Finance Canada — product list for September 8 counter-tariffs](https://www.canada.ca/en/department-finance/news/2026/08/list-of-products-from-the-united-states-subject-to-counter-tariffs-effective-september-8-2026.html) — primary government schedule identifying the rates, covered imports, sectors, origin rule and 12:01 a.m. effective time
- [Reuters — Canadian counter-tariffs take effect as trade talks stall](https://www.reuters.com/business/autos-transportation/canadas-retaliatory-tariffs-take-effect-us-trade-talks-stall-2026-09-08/) — independent reporting published after the effective time on implementation, trade exposure, talks and USMCA exemptions
- [Associated Press — Canada implements counter-tariffs on U.S. goods](https://apnews.com/article/4620ffb5ecc029322217207fa6758431) — independent reporting on the order-in-council implementation, covered trade, product rates and competing economic rationales

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
