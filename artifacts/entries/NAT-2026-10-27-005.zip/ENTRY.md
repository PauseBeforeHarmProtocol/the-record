# State Department reportedly plans U.S. visas for Flavio Bolsonaro and family

**Entry ID:** NAT-2026-10-27-005
**Date:** October 27, 2026
**Checked:** 2026-10-28 12:01 AM EDT
**Evidence state:** Independent ABC News reporting and AP reporting carried by ABC7; both attribute the visa plan to a senior State Department official. Announced/reported, not document-verified issuance or admission. Anonymous-source dependence disclosed; two outlets are distinct reporting origins, not proof of two distinct officials.
**Review state:** current-standard-reviewed

ABC News and AP separately attribute the plan to a senior official; visa documents, entry and the decision’s legal rationale were not inspected.

## THE FACTS

- ABC News and Associated Press separately reported October 27 that a senior State Department official said the department would issue U.S. visas to Flavio Bolsonaro and his family and allow entry. AP says its official was anonymous because of visa privacy laws.
- The announcement followed Bolsonaro’s loss to Luiz Inacio Lula da Silva. AP reports a Brazilian passport-surrender order and financial-crime investigations; Bolsonaro denies wrongdoing. Those allegations are not convictions established by this record.
- No visa instrument, category, issuance date, admission record or direct public State Department explanation was located in this review. The reported plan does not independently establish completed entry, asylum, immunity from Brazilian proceedings or a U.S. decision on any extradition request.

## SIGNIFICANCE

A reported use of federal visa authority involving a defeated foreign presidential candidate facing legal proceedings warrants scrutiny of the process and diplomatic consequences. The evidence does not establish that U.S. officials acted to obstruct a foreign court.

## GOALPOST / RESPONSE

The official’s reported position is that visas and entry will be permitted; no substantive justification was supplied in the inspected reports. Ordinary lawful visa discretion is a possible supporting case, not an administration explanation documented here. Category, legal basis and subsequent official records are the tests.

## MAYBE / THEREFORE

Maybe this is an ordinary lawful visa decision, or preferential treatment requiring further scrutiny. Therefore the supported finding is a multiply reported official announcement, not a verified arrival, asylum grant, criminal exoneration or proven motive.


## SOURCES

- [State Department will issue visas to Flavio Bolsonaro and family, official says](https://abcnews.com/International/brazilian-authorities-investigating-flvio-bolsonaro-fled-us-election/story?id=137618388) — independent reporting
- [Flavio Bolsonaro and family will be granted U.S. visas, official says](https://abc7news.com/story/brazils-flvio-bolsonaro-leaves-brazil-united-states-according-multiple-media-reports/19986023/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
