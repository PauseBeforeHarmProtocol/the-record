# DOE says 2022 manufactured-home efficiency rule has no legal effect

**Entry ID:** NAT-2026-09-18-005
**Date:** September 18, 2026
**Checked:** 2026-09-18 12:00 PM EDT
**Evidence state:** complete primary DOE notification of legal effect and statutory chronology; nonenforcement effective September 18, replacement HUD standards and outcomes unresolved
**Review state:** current-standard-reviewed

The department will not enforce its standards while HUD develops replacement minimums under the July housing law.

## THE FACTS

- The Energy Department published a notification applicable September 18 stating that its May 2022 manufactured-housing energy-conservation final rule has no legal effect after enactment of the 21st Century ROAD to Housing Act.
- The July 11 statute says federal manufactured-home efficiency standards have no legal effect unless HUD adopts them through the statutory consensus-standards and regulatory-development process. It directs HUD to adopt minimum standards within one year and update them every three years.
- DOE says HUD had not adopted qualifying standards by September 18. The department therefore will not enforce the 2022 rule and intends to begin a rulemaking conforming its regulations to the new statute.
- The notification establishes DOE's current legal and enforcement position. It does not itself issue replacement HUD standards, determine their eventual stringency or measure changes in home prices, energy use or household utility costs.

## SIGNIFICANCE

The notice removes DOE's 2022 standards from present enforcement and leaves a temporary federal standards gap while HUD develops a replacement, shifting both the rulemaking process and the timing of requirements for manufactured homes.

## GOALPOST / RESPONSE

DOE says the housing law legally displaced its rule and requires HUD to use a specified consensus process. HUD's deadline, proposed and final standards, implementation dates, home prices, energy bills, climate impacts and enforcement are the tests.

## MAYBE / THEREFORE

Maybe HUD's process produces workable standards with broader industry input, or the enforcement gap and future replacement may weaken energy savings and raise long-run utility costs. Therefore DOE has stopped treating its 2022 rule as legally effective—not that HUD standards are already in place or that consumer and energy outcomes are known.


## SOURCES

- [Federal Register — DOE notice on manufactured-housing energy standards](https://www.federalregister.gov/documents/2026/09/18/2026-19154/energy-conservation-program-energy-conservation-standards-for-manufactured-housing) — primary notification of legal effect

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
