# Tenth Circuit upholds EPA extension of Oklahoma environmental authority in Indian country

**Entry ID:** NAT-2026-10-16-001
**Date:** October 16, 2026
**Checked:** 2026-10-16 6:01 PM EDT
**Evidence state:** published Tenth Circuit opinion plus independent Reuters reporting; petition denied and agency interpretation affirmed, further review and program-level consequences unresolved
**Review state:** current-standard-reviewed

A divided appellate panel denied the Pawnee Nation’s challenge and affirmed EPA’s May 2025 approval. The ruling sustains Oklahoma’s administration of 26 federal environmental programs in covered Indian country, while EPA retains federal oversight.

## THE FACTS

- In Pawnee Nation of Oklahoma v. Zeldin, No. 25-9548, a divided Tenth Circuit panel denied the tribe’s petition and affirmed EPA’s interpretation of SAFETEA §10211(a). The court held that the provision remains active and did not expire in 2009.
- The majority held that EPA complied with §10211(a) when it approved Oklahoma’s request to administer 26 previously approved environmental programs in covered Indian country. The programs span six federal statutes, including the Clean Air Act, Clean Water Act and Safe Drinking Water Act; EPA retains federal oversight of state programs.
- The opinion records that EPA’s January 2025 approval imposed a State-Tribal Engagement Condition, but the agency removed that condition on May 12, 2025 after concluding that the statute’s mandatory language did not authorize additional conditions. The ruling upholds that May 2025 decision; it does not newly transfer authority on October 16.
- Judge Richard Federico dissented, reasoning that Indian-law canons, the federal trust responsibility and tribal sovereignty supported EPA discretion to retain protective engagement conditions. Reuters independently reported the 2-1 ruling and its consequences for tribal environmental authority.

## SIGNIFICANCE

The decision preserves a post-McGirt allocation of regulatory authority that can place state agencies, rather than tribes or EPA, in the primary role for covered federal environmental programs across substantial areas of eastern Oklahoma. The majority treated Congress’s mandatory text as controlling; the dissent emphasized sovereignty and the trust relationship.

## GOALPOST / RESPONSE

EPA and Oklahoma can point to the court’s holding that §10211(a) remains operative and requires approval when its stated conditions are met. The mandate, any rehearing or Supreme Court petition, EPA oversight, state permitting and enforcement, tribal consultation practices and measured environmental outcomes are the tests.

## MAYBE / THEREFORE

Maybe uniform state administration improves regulatory continuity under federal oversight, or removing mandatory tribal-engagement procedures may weaken tribal influence over decisions affecting Indian country. Therefore the Tenth Circuit affirmed EPA’s May 2025 approval and rejected this statutory challenge; it did not resolve every program-specific dispute or eliminate EPA oversight.


## SOURCES

- [Tenth Circuit — Pawnee Nation of Oklahoma v. Zeldin published opinion](https://www.ca10.uscourts.gov/sites/ca10/files/opinions/010111527860.pdf) — primary published appellate opinion
- [Reuters — Tenth Circuit upholds EPA approval of Oklahoma environmental authority in Indian country](https://www.reuters.com/legal/government/court-backs-epa-giving-oklahoma-authority-over-environmental-rules-tribal-lands-2026-10-16/) — independent legal reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
