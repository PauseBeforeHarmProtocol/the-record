# Census measures record household income and lower official poverty in 2025

**Entry ID:** NAT-2026-09-15-019
**Date:** September 15, 2026
**Checked:** 2026-09-16 5:58 PM EDT
**Evidence state:** primary Census statistical release and linked methodology plus independent Reuters reporting; measured annual estimates with statistical-significance, measure-definition and nonresponse caveats
**Review state:** current-standard-reviewed

Real median household income rose 2.6% and official poverty fell to 10.2%; the supplemental poverty and full-year uninsured rates did not change significantly.

## THE FACTS

- The Census Bureau reported that real median household income was $87,460 in 2025, up 2.6% from 2024 and the highest in the series dating to 1967. The measure is pretax money income unless otherwise stated and does not assign the change to one policy or administration.
- The official poverty rate fell 0.5 percentage points to 10.2%, representing 34.5 million people. The official child poverty rate fell to a series low of 13.4%; the official measure excludes tax credits and many noncash benefits.
- The Supplemental Poverty Measure was 13.1% and not statistically different from 2024. It incorporates taxes, tax credits, several transfers, work and medical expenses and geographic housing costs, so it answers a different question from the official rate.
- An estimated 26.7 million people, or 7.9%, lacked health insurance for the entire year, not a statistically significant change. Median income at the 90th percentile rose 1.7%, income at the 10th percentile did not change significantly and the Gini measure of inequality was unchanged.
- The findings come from the 2026 Current Population Survey Annual Social and Economic Supplement. Its weighted response rate was 61.3%, below prepandemic levels; Census adjusted survey weights but warned that lower response increases nonresponse-bias risk.

## SIGNIFICANCE

The release is the government's principal annual national measurement of household income, poverty and insurance. It documents broad improvement in median income and official poverty during 2025 while showing no significant improvement in the supplemental poverty measure, insurance coverage, low-end income or overall inequality.

## GOALPOST / RESPONSE

The administration highlighted the record income and poverty findings as evidence of economic success. The appropriate tests are revised Census estimates, distributional measures, real earnings, employment, tax-and-transfer effects, insurance coverage and future comparable surveys—not attribution of a full calendar-year outcome to a single policy or headline measure.

## MAYBE / THEREFORE

Maybe 2025 labor-market and income gains will persist and reach lower-income households more broadly, or later data may show that high-end gains, costs and coverage losses offset part of the headline improvement. Therefore the record establishes Census's measured 2025 changes and explicit nonsignificant findings—not a single-cause explanation, elimination of poverty or improvement across every distributional and insurance measure.


## SOURCES

- [U.S. Census Bureau — Income, Poverty and Health Insurance Coverage in the United States: 2025](https://www.census.gov/newsroom/press-releases/2026/income-poverty-health-insurance-coverage.html) — primary federal statistical release and linked reports, including response-rate and significance limitations
- [Reuters — Census income, poverty and insurance findings for 2025](https://www.reuters.com/world/us-poverty-rate-102-2025-census-bureau-says-2026-09-15/) — independent reporting on the federal statistical release and its economic context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
