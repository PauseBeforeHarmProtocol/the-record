# Trump extends Fort Peck rural-water authorization through 2028

**Entry ID:** NAT-2026-09-25-006
**Date:** September 25, 2026
**Checked:** 2026-09-25 5:59 PM EDT
**Evidence state:** primary White House signing statement and enrolled statutory text; authorization dates extended September 25, with funding and project outcomes not established by the law
**Review state:** current-standard-reviewed

The law replaces 2026 with 2028 in two authorization provisions; it does not itself state a funding amount, obligate money or establish completed construction.

## THE FACTS

- Trump signed H.R. 7250, reauthorizing the Fort Peck Reservation Rural Water System, on September 25.
- The enrolled text changes two dates in section 9 of the Fort Peck Reservation Rural Water System Act, replacing 2026 with 2028 in the applicable authorization provisions.
- The two-section law states no dollar amount and does not itself document an appropriation, obligation, disbursement, construction award or completed water service.

## SIGNIFICANCE

The extension preserves federal statutory authority for a Tribal rural-water project for two additional years, but the practical effect depends on appropriations and administration outside this law.

## GOALPOST / RESPONSE

The administration can say the authorization was preserved through 2028. Appropriations, obligations, contracts, construction milestones and delivered water service are the outcome tests.

## MAYBE / THEREFORE

Maybe the extension prevents a lapse and enables additional work, or it may remain nominal without funding and execution. Therefore the authorization dates changed—not that money was spent or the system completed.


## SOURCES

- [Congressional bills H.R. 3657, H.R. 7250, S. 550, S. 603, S. 759 and S. 790 signed into law](https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bills-h-r-3657-h-r-7250-s-550-s-603-s-759-and-s-790-signed-into-law/) — primary presidential signing statement
- [H.R. 7250 — Fort Peck Reservation Rural Water System Act reauthorization, enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119hr7250enr/pdf/BILLS-119hr7250enr.pdf) — primary enacted legislation; enrolled text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
