# Federal agents execute search warrant at Rep. Ilhan Omar's home

**Entry ID:** NAT-2026-10-12-001
**Date:** October 12, 2026
**Checked:** 2026-10-14 11:56 PM EDT
**Evidence state:** Justice Department confirmation and independent Reuters, AP and ABC reporting on the executed search; AP, CBS News and Wall Street Journal corroboration of later investigative steps; key evidence remains sealed, reporting relies partly on unnamed sources, and no charge or adjudicated finding exists
**Review state:** current-standard-reviewed

Independent outlets now corroborate a phone seizure, family subpoenas and a Minnesota grand jury; no affidavit, charge or adjudicated fraud finding was public by cutoff.

## THE FACTS

- Homeland Security Investigations agents searched Democratic Rep. Ilhan Omar's Washington-area home on October 12. The Justice Department confirmed that HSI executed a judicially authorized search warrant secured by the department as part of an ongoing federal criminal investigation, but it did not identify Omar or disclose the warrant, affidavit, alleged offense or seized material in its statement.
- Reuters and ABC News, each citing sources familiar with the investigation, reported that investigators were examining possible immigration fraud involving Omar's immigration paperwork. Reuters reported that part of the inquiry concerned paperwork filed by her late father when she was a child. That reported focus rests on unnamed-source accounts; no charge, adjudicated violation or public evidentiary filing had established immigration fraud by cutoff.
- The search occurred while Omar was campaigning for reelection and after Trump, Vice President JD Vance and Homeland Security Secretary Markwayne Mullin had publicly discussed accusations or an investigation involving her. Associated Press noted longstanding Justice Department guidance cautioning against overt investigative steps near elections; the inspected material did not establish whether that guidance applied, whether an exception was approved or whether officials violated it.
- The administration's strongest disclosed procedural explanation is that the search was judicially authorized and part of an ongoing criminal investigation. Omar responded that the government was being weaponized against a political enemy, called the search an escalation in political intimidation and said she would not be silenced. She has long denied the immigration-fraud allegations. A search warrant reflects a judge's probable-cause determination for the authorized search, not a criminal charge or finding of guilt.
- Associated Press reported, citing a person briefed on the probe, that agents seized Omar's phone and issued more than a dozen grand-jury subpoenas, including to relatives, for a Minnesota grand jury. CBS News separately reported, citing sources familiar with the matter, that multiple relatives received subpoenas concerning possible fraud or false statements in family immigration paperwork. The Wall Street Journal separately reported that seized items included her phone and that more than a dozen subpoenas had issued. These independent accounts corroborate the investigative steps, while their unnamed sourcing and the sealed record limit what can be established about the underlying evidence.
- U.S. Attorney Jeanine Pirro said publicly that several Omar-related investigations were underway and that her office was examining financial-disclosure issues. Her statement confirms investigative activity, not a charge or proof of a reporting violation; the relationship between that examination and the immigration investigation remains unclear.

## SIGNIFICANCE

The corroborated seizure, subpoenas and grand-jury process make this more than a reported search while still leaving the merits sealed. Investigating a sitting member of Congress and current candidate after senior officials publicly targeted her remains institutionally consequential; judicial process is a safeguard, but neither a subpoena nor a seizure establishes wrongdoing.

## GOALPOST / RESPONSE

The administration points to judicial authorization, a grand-jury investigation and multiple investigative tracks. The tests are the warrant and affidavit if unsealed, subpoena scope, the specific alleged offenses, charging or civil-denaturalization filings, evidence, election-sensitivity compliance, any inspector-general or congressional review, and eventual judicial findings—not prior political claims or investigative process alone.

## MAYBE / THEREFORE

Maybe the sealed evidence supports legitimate criminal or civil proceedings, and independent judicial and grand-jury process may constrain abuse; or the election timing and prior political pressure may support scrutiny of selective enforcement. Therefore the archive records corroborated investigative steps and a reported denaturalization objective—not proof of immigration fraud, financial-disclosure violations, a charge, loss of citizenship, deportation or political retaliation.

## CORRECTIONS

- **2026-10-12T22:07:25Z** — Corrected the earlier cutoff-qualified statement that Omar had not responded. Reuters' October 12 report included her response before the prior release boundary; the record now preserves her political-intimidation allegation without treating it as an established finding. The prior content remains in version history.


## SOURCES

- [Reuters — U.S. immigration authorities search Rep. Ilhan Omar's home](https://www.reuters.com/legal/government/us-launches-immigration-raid-democratic-congresswoman-ilhan-omars-home-fox-news-2026-10-12/) — independent reporting, Justice Department confirmation and investigation context
- [Associated Press — federal agents search Rep. Ilhan Omar's home](https://apnews.com/article/8e18c2aea948bd90f4d7a4eb32b9ec3a) — independent reporting, Justice Department confirmation and political response
- [ABC News — Rep. Ilhan Omar's residence searched in ongoing investigation](https://abcnews.com/US/rep-ilhan-omars-residence-searched-part-ongoing-criminal/story?id=137192001) — independent reporting and second-source investigation-scope confirmation
- [Associated Press — Omar phone seized and relatives subpoenaed](https://apnews.com/article/ilhan-omar-search-f968cfe403d61ad61812422f1252fd2c) — independent reporting with clearly attributed unnamed-source details and on-record prosecutor response
- [CBS News — Omar relatives received grand-jury subpoenas](https://www.cbsnews.com/news/ilhan-omar-subpoenas-relatives-investigation-homeland-security/) — second independent confirmation based on separately described sources
- [Wall Street Journal — investigation targets Omar citizenship](https://www.wsj.com/politics/policy/ilhan-omar-investigation-aims-to-build-case-for-stripping-her-citizenship-6adf1edc) — second independent reporting on seized items, subpoenas and stated investigative objective

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
