# Federal agents execute search warrant at Rep. Ilhan Omar's home

**Entry ID:** NAT-2026-10-12-001
**Date:** October 12, 2026
**Checked:** 2026-10-12 12:09 PM EDT
**Evidence state:** Justice Department confirmation reported by Reuters and AP, independent eyewitness/source reporting of the executed search, and Reuters plus ABC News corroboration of the reported investigation focus; warrant application and affidavit unavailable, no charge or adjudicated finding
**Review state:** current-standard-reviewed

Justice confirmed a court-authorized search in an ongoing criminal investigation; reporting points to immigration records, but no affidavit, charge or finding was public by cutoff.

## THE FACTS

- Homeland Security Investigations agents searched Democratic Rep. Ilhan Omar's Washington-area home on October 12. The Justice Department confirmed that HSI executed a judicially authorized search warrant secured by the department as part of an ongoing federal criminal investigation, but it did not identify Omar or disclose the warrant, affidavit, alleged offense or seized material in its statement.
- Reuters and ABC News, each citing sources familiar with the investigation, reported that investigators were examining possible immigration fraud involving Omar's immigration paperwork. Reuters reported that part of the inquiry concerned paperwork filed by her late father when she was a child. That reported focus rests on unnamed-source accounts; no charge, adjudicated violation or public evidentiary filing had established immigration fraud by cutoff.
- The search occurred while Omar was campaigning for reelection and after Trump, Vice President JD Vance and Homeland Security Secretary Markwayne Mullin had publicly discussed accusations or an investigation involving her. Associated Press noted longstanding Justice Department guidance cautioning against overt investigative steps near elections; the inspected material did not establish whether that guidance applied, whether an exception was approved or whether officials violated it.
- The administration's strongest disclosed procedural explanation is that the search was judicially authorized and part of an ongoing criminal investigation. Omar has long denied the immigration-fraud allegations; her office had not issued a response to the search by the reporting cutoff. A search warrant reflects a judge's probable-cause determination for the authorized search, not a criminal charge or finding of guilt.

## SIGNIFICANCE

Executing a search warrant at the home of a sitting member of Congress and current candidate is a consequential federal investigative act, particularly after senior administration officials publicly targeted the same person and subject. Judicial authorization is an important safeguard, while the sealed evidentiary basis, election-period timing and absence of charges make the investigation's merits and independence unresolved rather than established conclusions.

## GOALPOST / RESPONSE

The administration points to a judicially authorized warrant and an ongoing criminal investigation. The tests are the warrant and affidavit if unsealed, the specific alleged offense, evidence and charging decision, compliance with election-sensitivity policy, any inspector-general or congressional review, Omar's response, and eventual judicial findings—not prior political claims or the search itself.

## MAYBE / THEREFORE

Maybe the sealed application contains specific evidence that justified immediate investigative action, and judicial authorization supplies independent probable-cause review; or the timing and prior public pressure may raise legitimate concerns about selective or politically influenced enforcement. Therefore the archive records an executed, court-authorized search and an unresolved federal investigation—not proof of immigration fraud, a criminal charge, a policy violation or political retaliation.


## SOURCES

- [Reuters — U.S. immigration authorities search Rep. Ilhan Omar's home](https://www.reuters.com/legal/government/us-launches-immigration-raid-democratic-congresswoman-ilhan-omars-home-fox-news-2026-10-12/) — independent reporting, Justice Department confirmation and investigation context
- [Associated Press — federal agents search Rep. Ilhan Omar's home](https://apnews.com/article/8e18c2aea948bd90f4d7a4eb32b9ec3a) — independent reporting, Justice Department confirmation and political response
- [ABC News — Rep. Ilhan Omar's residence searched in ongoing investigation](https://abcnews.com/US/rep-ilhan-omars-residence-searched-part-ongoing-criminal/story?id=137192001) — independent reporting and second-source investigation-scope confirmation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
