# Trump repeats energy-ceasefire claim as strikes continue and terms remain unconfirmed

**Entry ID:** NAT-2026-09-13-001
**Date:** September 13–October 13, 2026
**Checked:** 2026-10-13 6:03 AM EDT
**Evidence state:** primary Ukrainian statements, independent Reuters and Associated Press reporting on post-announcement strikes and Trump’s response, and Reuters reporting of the Kremlin’s ongoing-contacts statement and the Russian Defense Ministry’s narrower denial; continued attacks reported, bilateral acceptance and sustained implementation not established
**Review state:** current-standard-reviewed

Russia struck Ukrainian energy sites after Trump said an immediate ceasefire was in place; Moscow later described contacts as ongoing without confirming accepted terms.

## THE FACTS

- On September 13, President Trump told reporters that he had spoken with Ukrainian President Volodymyr Zelenskyy and asked him to stop attacks on Russian diesel infrastructure. Reuters and Associated Press independently reported the on-record remarks; the public record did not establish a written directive, bilateral agreement or Ukrainian acceptance.
- Trump attributed the global diesel shortage to Ukrainian strikes on Russian refineries and said the Middle East was not the cause. Reuters and AP reported that the strikes had reduced Russian fuel production and contributed to Russian shortages, while both described other pressures—including the Iran conflict and Russian export restrictions—so the president's exclusive causal attribution is not independently established.
- Ukraine says Russian energy infrastructure is a legitimate military target because it funds and supports Russia's invasion, while Russia has repeatedly attacked Ukraine's power system. Those are the parties' stated military rationales; the archive does not independently adjudicate the legality or proportionality of particular strikes.
- On September 14, Trump posted that Russia and Ukraine had agreed not to attack each other's energy targets. The post is primary evidence that he made the claim. The Kremlin welcomed Trump's earlier call for Ukraine to stop refinery strikes, but no independently confirmed text, scope, duration, enforcement mechanism or reciprocal Russian acceptance was located by cutoff.
- Zelenskyy subsequently said no formal agreement had been reached. Reuters and AP reported his conditional position: Ukraine was prepared to halt responsive strikes if the United States and allies secured a genuine, reliable and long-term Russian commitment to stop attacks on Ukrainian critical infrastructure. That statement is a conditional offer and qualification of Trump's account—not confirmation that a ceasefire was already agreed or operating.
- No public aid suspension, sanctions relief, operational order or verified cessation of attacks tied to Trump's statements was located by the evidence cutoff. The development remains a presidentially claimed understanding followed by a conditional Ukrainian response, not an independently verified or implemented bilateral ceasefire.
- On September 15, Reuters reported that Russia launched about 200 drones overnight, damaging Kyiv petrol stations and energy and port infrastructure elsewhere, while Ukraine reported striking the Syzran refinery and drone facilities. The reports document continued attacks after Trump's announcement; individual battlefield claims remain attributed to the named governments and officials.
- The observed continuation of energy strikes means the publicly claimed reciprocal restraint was not operating by cutoff. Zelenskyy reiterated that Ukraine would halt responsive strikes only with credible Russian guarantees, while Kremlin spokesman Dmitry Peskov described Trump's idea as good but did not confirm accepted reciprocal terms.
- On October 11 at 10:16 a.m. EDT, Trump again posted that an “ENERGY CEASEFIRE” between Russia and Ukraine was effective immediately and that both parties had agreed. The post is primary evidence that he made the announcement; it does not independently establish acceptance or implementation.
- Reuters reported that Zelenskyy said Trump’s post was the first he had heard of the deal and that a senior Ukrainian official said Ukraine was ready to agree if Russia was. Associated Press reported Zelenskyy’s public position that Ukraine supported the announced ceasefire, that Russian support was essential and that Kyiv was awaiting details from the United States.
- By the October 11 editorial cutoff, neither the White House nor Moscow had publicly supplied or confirmed terms, scope, duration, monitoring or enforcement. Ukraine’s position remained reciprocal and conditional: it would stop attacks on Russian refineries if Russia halted attacks on Ukrainian energy infrastructure and credible guarantees existed.
- Reuters and Associated Press reported on October 12 that Russian attacks after Trump’s announcement hit Ukrainian energy facilities, including a Kharkiv power plant, a gas-production facility and a gas station. Zelenskyy said Ukraine had refrained from attacking Russian refineries and was prepared to observe reciprocal restraint. The Ukrainian claims about specific targets are attributed; AP independently documented damage from the broader Russian attack wave.
- Trump told reporters on October 12 that the parties had agreed and said he would examine the reported attacks, while adding that there had been violations on both sides. The public record inspected for this update still contained no bilateral text, monitoring mechanism or direct Russian confirmation that an immediate ceasefire had taken effect.
- On October 13, Kremlin spokesman Dmitry Peskov said contacts concerning a possible energy ceasefire were continuing but did not identify the participants or confirm that Russia had accepted Trump’s announced arrangement. Russia’s Defense Ministry separately said its forces had not struck Ukrainian energy targets overnight. That denial concerns the later overnight period and does not resolve the independently reported October 12 strikes or establish a broader operating ceasefire.

## SIGNIFICANCE

The post-announcement strikes are an evidence-based implementation finding: the restraint Trump described as effective immediately was not operating across the reported period. Continued contacts could still produce a later agreement, but the distinction between an announced deal and an uncompleted negotiation matters for civilian infrastructure, winter energy security and accountability for U.S. claims about war diplomacy.

## GOALPOST / RESPONSE

Trump says both governments accepted an immediate energy ceasefire. Ukraine says it observed unilateral restraint but Russia continued attacking energy sites; Moscow says contacts are continuing without confirming accepted terms. Written reciprocal terms, direct confirmations, monitoring, sustained strike data, enforcement, any U.S. conditions, and measurable reductions in attacks remain the tests.

## MAYBE / THEREFORE

Maybe private contacts could still mature into a reciprocal pause, and Russia’s denial of later overnight energy strikes may signal limited restraint. Therefore the record establishes continued attacks after Trump’s announcement and an ongoing negotiation—not a verified bilateral agreement, enforceable terms or sustained compliance.


## SOURCES

- [Reuters — Trump asks Ukraine to stop strikes on Russian diesel infrastructure](https://www.reuters.com/business/energy/trump-tells-ukraines-zelenskiy-stop-hitting-russian-diesel-2026-09-13/) — independent reporting of presidential foreign-policy remarks and energy context
- [Associated Press — Trump calls on Ukraine to halt Russian diesel strikes](https://apnews.com/article/17bb6a0401abc3eaa7d4586150a41d7d) — independent reporting of presidential remarks, Ukrainian operations and reciprocal energy attacks
- [Donald Trump Truth Social post — claimed Russia-Ukraine energy-target agreement](https://truthsocial.com/@realDonaldTrump/117270009579288120) — primary evidence only that Trump published the claimed reciprocal understanding; not independent evidence of acceptance, terms or compliance
- [Reuters — Kremlin welcomes Trump's call to halt Ukrainian refinery strikes](https://www.reuters.com/business/energy/kremlin-welcomes-trumps-call-ukraine-halt-strikes-diesel-facilities-2026-09-14/) — independent reporting of the Kremlin response to Trump's initial request and continuing absence of a publicly confirmed reciprocal agreement
- [Reuters — Ukraine conditionally supports reciprocal energy ceasefire](https://www.reuters.com/world/europe/ukraine-wants-specifics-partners-halting-strikes-zelenskiy-says-2026-09-14/) — independent reporting of Zelenskyy's direct denial of a formal agreement and conditional de-escalation position
- [Associated Press — Zelenskyy conditions strike pause on Russian restraint](https://apnews.com/article/dbba56f09562f337aa731f7d4bbd1235) — independent reporting of Ukraine's conditional position, absence of Russian confirmation and prior ceasefire failures
- [Reuters — Russia and Ukraine continue energy strikes after Trump's claimed agreement](https://www.reuters.com/world/europe/russia-hits-petrol-station-warehouse-facilities-kyiv-mayor-says-2026-09-15/) — independent conflict reporting and implementation-status check
- [Donald Trump Truth Social post — claimed immediate Russia–Ukraine energy ceasefire](https://truthsocial.com/@realDonaldTrump/117422699218841250) — primary evidence only that Trump published the claimed immediate agreement; not independent evidence of bilateral acceptance, terms or compliance
- [Reuters — Trump says Russia and Ukraine reached an immediate energy ceasefire](https://www.reuters.com/world/europe/ukraine-will-halt-strikes-refineries-if-russia-stops-energy-attacks-zelenskiy-2026-10-11/) — independent reporting on the announcement, Ukrainian response and absence of immediate confirmation from Moscow
- [Associated Press — Trump announces energy ceasefire without details](https://apnews.com/article/f621fa788196f204448e7f75fcc78c68) — independent reporting on the announcement, Ukraine’s conditional support and the lack of clarified terms or immediate Russian response
- [Reuters — Russia strikes Ukrainian energy targets after Trump ceasefire announcement](https://www.reuters.com/business/energy/ukraine-accuses-russia-violating-trumps-energy-ceasefire-eu-imposes-new-2026-10-12/) — independent reporting on post-announcement energy strikes, Ukrainian restraint claim, Trump response and Kremlin position
- [Associated Press — energy strikes continue after Trump ceasefire claim](https://apnews.com/article/russia-ukraine-energy-strikes-trump-ceasefire-6fdef6ff4d033b379c74e1d62183d078) — independent reporting and on-scene documentation of the attack wave, Trump response, Ukrainian claims and Kremlin position
- [President of Ukraine — reported Russian energy strikes after Trump ceasefire statement](https://www.president.gov.ua/en/news/yevropa-ta-ssha-mayut-posilyuvati-tisk-na-rosiyu-shob-stvori-106861) — primary Ukrainian government statement on claimed target damage, unilateral restraint and requested reciprocal compliance
- [Reuters — Kremlin says energy-ceasefire contacts are continuing](https://www.reuters.com/world/kremlin-says-contacts-trumps-russia-ukraine-energy-ceasefire-are-continuing-2026-10-13/) — independent reporting on the Kremlin's nonconfirmation and the Russian Defense Ministry's narrower overnight-target denial

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
