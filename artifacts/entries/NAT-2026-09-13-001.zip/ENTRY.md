# Trump asks Ukraine to stop strikes on Russian diesel infrastructure

**Entry ID:** NAT-2026-09-13-001
**Date:** September 13, 2026
**Checked:** 2026-09-13 11:59 AM EDT
**Evidence state:** independent Reuters and Associated Press reporting of on-record presidential remarks and conflict context; request stated, implementation, Ukrainian response and causal price effect unresolved
**Review state:** current-standard-reviewed

The presidential request may affect Ukraine's war strategy, but no written order, aid condition, agreement or Ukrainian compliance was established by cutoff.

## THE FACTS

- On September 13, President Trump told reporters that he had spoken with Ukrainian President Volodymyr Zelenskyy and asked him to stop attacks on Russian diesel infrastructure. Reuters and Associated Press independently reported the on-record remarks; the public record did not establish a written directive, bilateral agreement or Ukrainian acceptance by cutoff.
- Trump attributed the global diesel shortage to Ukrainian strikes on Russian refineries and said the Middle East was not the cause. Reuters and AP reported that the strikes had reduced Russian fuel production and contributed to Russian shortages, while both described other pressures—including the Iran conflict and Russian export restrictions—so the president's exclusive causal attribution is not independently established.
- Ukraine says Russian energy infrastructure is a legitimate military target because it funds and supports Russia's invasion, while Russia has repeatedly attacked Ukraine's power system. Those are the parties' stated military rationales; the archive does not independently adjudicate the legality or proportionality of particular strikes.
- No public aid suspension, sanctions relief, operational order, ceasefire term or enforcement mechanism tied to Trump's request was located by the evidence cutoff. The statement is therefore recorded as a presidential request with possible strategic consequences, not an implemented constraint on Ukraine or a completed change in U.S. policy.

## SIGNIFICANCE

A U.S. presidential request to stop attacks on Russia's fuel infrastructure could alter Ukraine's leverage, battlefield choices and Russian export capacity at a time of high diesel prices. Its practical effect depends on whether Washington attaches policy consequences and whether Ukraine complies; neither was established by cutoff.

## GOALPOST / RESPONSE

Trump says stopping the refinery campaign would ease the diesel shortage. Ukraine says Russian energy assets support the invasion and are legitimate targets, while Russia continues striking Ukrainian energy infrastructure. A written U.S. policy, aid or sanctions condition, Ukrainian response and strike activity, Russian production and exports, diesel inventories and prices, and any negotiated reciprocal restraint are the tests.

## MAYBE / THEREFORE

Maybe the request produces a reciprocal reduction in energy attacks and eases supply pressure, or it may constrain Ukraine without changing Russian attacks or materially lowering diesel prices. Therefore the record confirms Trump's public request and stated rationale—not Ukrainian agreement, an enforceable U.S. order, a ceasefire or proof that Ukrainian strikes alone caused the global shortage.


## SOURCES

- [Reuters — Trump asks Ukraine to stop strikes on Russian diesel infrastructure](https://www.reuters.com/business/energy/trump-tells-ukraines-zelenskiy-stop-hitting-russian-diesel-2026-09-13/) — independent reporting of presidential foreign-policy remarks and energy context
- [Associated Press — Trump calls on Ukraine to halt Russian diesel strikes](https://apnews.com/article/17bb6a0401abc3eaa7d4586150a41d7d) — independent reporting of presidential remarks, Ukrainian operations and reciprocal energy attacks

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
