# Trump claims Russia and Ukraine agreed to stop strikes on energy targets

**Entry ID:** NAT-2026-09-13-001
**Date:** September 13–15, 2026
**Checked:** 2026-09-15 12:00 PM EDT
**Evidence state:** primary evidence that Trump published the claimed agreement, plus Reuters and Associated Press reporting of the request, responses and continued September 15 strikes; no bilateral terms, reciprocal confirmation, implementation or single-cause price finding established
**Review state:** current-standard-reviewed

Ukraine denied a formal accord and both sides continued energy strikes; the claimed reciprocal restraint was not implemented by cutoff.

## THE FACTS

- On September 13, President Trump told reporters that he had spoken with Ukrainian President Volodymyr Zelenskyy and asked him to stop attacks on Russian diesel infrastructure. Reuters and Associated Press independently reported the on-record remarks; the public record did not establish a written directive, bilateral agreement or Ukrainian acceptance.
- Trump attributed the global diesel shortage to Ukrainian strikes on Russian refineries and said the Middle East was not the cause. Reuters and AP reported that the strikes had reduced Russian fuel production and contributed to Russian shortages, while both described other pressures—including the Iran conflict and Russian export restrictions—so the president's exclusive causal attribution is not independently established.
- Ukraine says Russian energy infrastructure is a legitimate military target because it funds and supports Russia's invasion, while Russia has repeatedly attacked Ukraine's power system. Those are the parties' stated military rationales; the archive does not independently adjudicate the legality or proportionality of particular strikes.
- On September 14, Trump posted that Russia and Ukraine had agreed not to attack each other's energy targets. The post is primary evidence that he made the claim. The Kremlin welcomed Trump's earlier call for Ukraine to stop refinery strikes, but no independently confirmed text, scope, duration, enforcement mechanism or reciprocal Russian acceptance was located by cutoff.
- Zelenskyy subsequently said no formal agreement had been reached. Reuters and AP reported his conditional position: Ukraine was prepared to halt responsive strikes if the United States and allies secured a genuine, reliable and long-term Russian commitment to stop attacks on Ukrainian critical infrastructure. That statement is a conditional offer and qualification of Trump's account—not confirmation that a ceasefire was already agreed or operating.
- No public aid suspension, sanctions relief, operational order or verified cessation of attacks tied to Trump's statements was located by the evidence cutoff. The development remains a presidentially claimed understanding followed by a conditional Ukrainian response, not an independently verified or implemented bilateral ceasefire.
- On September 15, Reuters reported that Russia launched about 200 drones overnight, damaging Kyiv petrol stations and energy and port infrastructure elsewhere, while Ukraine reported striking the Syzran refinery and drone facilities. The reports document continued attacks after Trump's announcement; individual battlefield claims remain attributed to the named governments and officials.
- The observed continuation of energy strikes means the publicly claimed reciprocal restraint was not operating by cutoff. Zelenskyy reiterated that Ukraine would halt responsive strikes only with credible Russian guarantees, while Kremlin spokesman Dmitry Peskov described Trump's idea as good but did not confirm accepted reciprocal terms.

## SIGNIFICANCE

Continued energy attacks materially resolve the immediate implementation question: whatever discussions occurred, the claimed bilateral restraint was not operating by September 15. A future verified halt could still reduce infrastructure damage and fuel-market pressure, but the announcement had not yet produced observable compliance.

## GOALPOST / RESPONSE

Trump says both governments accepted reciprocal restraint and that stopping energy attacks will ease diesel shortages. Zelenskyy conditions a halt on credible Russian guarantees, and the Kremlin has praised the idea without confirming reciprocal terms. Written terms, direct confirmations, strike monitoring, any U.S. conditions, Russian production and exports, and diesel inventories and prices remain the tests.

## MAYBE / THEREFORE

Maybe talks could still yield a later reciprocal pause, or the announcement may have preceded agreement on enforceable terms. Therefore the record now establishes Trump's request and claim, Ukraine's conditional response and continued strikes by both sides—not an implemented ceasefire, verified compliance or proof that Ukrainian attacks alone caused the shortage.


## SOURCES

- [Reuters — Trump asks Ukraine to stop strikes on Russian diesel infrastructure](https://www.reuters.com/business/energy/trump-tells-ukraines-zelenskiy-stop-hitting-russian-diesel-2026-09-13/) — independent reporting of presidential foreign-policy remarks and energy context
- [Associated Press — Trump calls on Ukraine to halt Russian diesel strikes](https://apnews.com/article/17bb6a0401abc3eaa7d4586150a41d7d) — independent reporting of presidential remarks, Ukrainian operations and reciprocal energy attacks
- [Donald Trump Truth Social post — claimed Russia-Ukraine energy-target agreement](https://truthsocial.com/@realDonaldTrump/117270009579288120) — primary evidence only that Trump published the claimed reciprocal understanding; not independent evidence of acceptance, terms or compliance
- [Reuters — Kremlin welcomes Trump's call to halt Ukrainian refinery strikes](https://www.reuters.com/business/energy/kremlin-welcomes-trumps-call-ukraine-halt-strikes-diesel-facilities-2026-09-14/) — independent reporting of the Kremlin response to Trump's initial request and continuing absence of a publicly confirmed reciprocal agreement
- [Reuters — Ukraine conditionally supports reciprocal energy ceasefire](https://www.reuters.com/world/europe/ukraine-wants-specifics-partners-halting-strikes-zelenskiy-says-2026-09-14/) — independent reporting of Zelenskyy's direct denial of a formal agreement and conditional de-escalation position
- [Associated Press — Zelenskyy conditions strike pause on Russian restraint](https://apnews.com/article/dbba56f09562f337aa731f7d4bbd1235) — independent reporting of Ukraine's conditional position, absence of Russian confirmation and prior ceasefire failures
- [Reuters — Russia and Ukraine continue energy strikes after Trump's claimed agreement](https://www.reuters.com/world/europe/russia-hits-petrol-station-warehouse-facilities-kyiv-mayor-says-2026-09-15/) — independent conflict reporting and implementation-status check

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
