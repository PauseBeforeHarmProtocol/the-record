# Trump claims Russia and Ukraine agreed to stop strikes on energy targets

**Entry ID:** NAT-2026-09-13-001
**Date:** September 13–15, 2026
**Checked:** 2026-09-15 6:02 AM EDT
**Evidence state:** primary evidence that Trump published the claimed agreement, plus Reuters and Associated Press reporting of the initial request, Kremlin response and Zelenskyy's conditional denial; bilateral terms, reciprocal Russian confirmation, compliance and causal price effect unresolved
**Review state:** current-standard-reviewed

Ukraine denied that a formal agreement existed and made any pause conditional on verified, reciprocal Russian restraint; Russia had not independently confirmed terms by cutoff.

## THE FACTS

- On September 13, President Trump told reporters that he had spoken with Ukrainian President Volodymyr Zelenskyy and asked him to stop attacks on Russian diesel infrastructure. Reuters and Associated Press independently reported the on-record remarks; the public record did not establish a written directive, bilateral agreement or Ukrainian acceptance.
- Trump attributed the global diesel shortage to Ukrainian strikes on Russian refineries and said the Middle East was not the cause. Reuters and AP reported that the strikes had reduced Russian fuel production and contributed to Russian shortages, while both described other pressures—including the Iran conflict and Russian export restrictions—so the president's exclusive causal attribution is not independently established.
- Ukraine says Russian energy infrastructure is a legitimate military target because it funds and supports Russia's invasion, while Russia has repeatedly attacked Ukraine's power system. Those are the parties' stated military rationales; the archive does not independently adjudicate the legality or proportionality of particular strikes.
- On September 14, Trump posted that Russia and Ukraine had agreed not to attack each other's energy targets. The post is primary evidence that he made the claim. The Kremlin welcomed Trump's earlier call for Ukraine to stop refinery strikes, but no independently confirmed text, scope, duration, enforcement mechanism or reciprocal Russian acceptance was located by cutoff.
- Zelenskyy subsequently said no formal agreement had been reached. Reuters and AP reported his conditional position: Ukraine was prepared to halt responsive strikes if the United States and allies secured a genuine, reliable and long-term Russian commitment to stop attacks on Ukrainian critical infrastructure. That statement is a conditional offer and qualification of Trump's account—not confirmation that a ceasefire was already agreed or operating.
- No public aid suspension, sanctions relief, operational order or verified cessation of attacks tied to Trump's statements was located by the evidence cutoff. The development remains a presidentially claimed understanding followed by a conditional Ukrainian response, not an independently verified or implemented bilateral ceasefire.

## SIGNIFICANCE

Ukraine's direct response materially narrows the claimed breakthrough: Kyiv expressed willingness to support reciprocal de-escalation while denying that formal consent already existed and conditioning action on verified Russian commitment. A genuine halt could reduce infrastructure damage and fuel-market pressure, but no confirmed terms or observed compliance were available by cutoff.

## GOALPOST / RESPONSE

Trump says both governments accepted reciprocal restraint and that stopping energy attacks will ease diesel shortages. Zelenskyy says Ukraine is conditionally ready if the United States can secure genuine, reliable and long-term Russian reciprocity; Russia had not confirmed a reciprocal accord. Written terms, direct confirmations, strike monitoring, any U.S. conditions, Russian production and exports, and diesel inventories and prices are the tests.

## MAYBE / THEREFORE

Maybe the statements are an early, imperfectly communicated path to reciprocal de-escalation, or they may reflect a presidential announcement made before the parties accepted enforceable terms. Therefore the record establishes Trump's request and claim plus Ukraine's conditional response and denial of a formal accord—not completed bilateral consent, enforceable terms, observed compliance or proof that Ukrainian strikes alone caused the shortage.


## SOURCES

- [Reuters — Trump asks Ukraine to stop strikes on Russian diesel infrastructure](https://www.reuters.com/business/energy/trump-tells-ukraines-zelenskiy-stop-hitting-russian-diesel-2026-09-13/) — independent reporting of presidential foreign-policy remarks and energy context
- [Associated Press — Trump calls on Ukraine to halt Russian diesel strikes](https://apnews.com/article/17bb6a0401abc3eaa7d4586150a41d7d) — independent reporting of presidential remarks, Ukrainian operations and reciprocal energy attacks
- [Donald Trump Truth Social post — claimed Russia-Ukraine energy-target agreement](https://truthsocial.com/@realDonaldTrump/117270009579288120) — primary evidence only that Trump published the claimed reciprocal understanding; not independent evidence of acceptance, terms or compliance
- [Reuters — Kremlin welcomes Trump's call to halt Ukrainian refinery strikes](https://www.reuters.com/business/energy/kremlin-welcomes-trumps-call-ukraine-halt-strikes-diesel-facilities-2026-09-14/) — independent reporting of the Kremlin response to Trump's initial request and continuing absence of a publicly confirmed reciprocal agreement
- [Reuters — Ukraine conditionally supports reciprocal energy ceasefire](https://www.reuters.com/world/europe/ukraine-wants-specifics-partners-halting-strikes-zelenskiy-says-2026-09-14/) — independent reporting of Zelenskyy's direct denial of a formal agreement and conditional de-escalation position
- [Associated Press — Zelenskyy conditions strike pause on Russian restraint](https://apnews.com/article/dbba56f09562f337aa731f7d4bbd1235) — independent reporting of Ukraine's conditional position, absence of Russian confirmation and prior ceasefire failures

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
