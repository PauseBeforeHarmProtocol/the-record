# Trump claims Russia and Ukraine agreed to stop strikes on energy targets

**Entry ID:** NAT-2026-09-13-001
**Date:** September 13–14, 2026
**Checked:** 2026-09-14 11:58 AM EDT
**Evidence state:** primary evidence that Trump published the claimed agreement, plus independent Reuters and Associated Press reporting of the initial request, Kremlin response and conflict context; bilateral confirmation, terms, compliance and causal price effect unresolved
**Review state:** current-standard-reviewed

The president announced a reciprocal understanding after first asking Ukraine to halt refinery attacks, but neither government independently confirmed terms or implementation by cutoff.

## THE FACTS

- On September 13, President Trump told reporters that he had spoken with Ukrainian President Volodymyr Zelenskyy and asked him to stop attacks on Russian diesel infrastructure. Reuters and Associated Press independently reported the on-record remarks; the public record did not establish a written directive, bilateral agreement or Ukrainian acceptance by cutoff.
- Trump attributed the global diesel shortage to Ukrainian strikes on Russian refineries and said the Middle East was not the cause. Reuters and AP reported that the strikes had reduced Russian fuel production and contributed to Russian shortages, while both described other pressures—including the Iran conflict and Russian export restrictions—so the president's exclusive causal attribution is not independently established.
- Ukraine says Russian energy infrastructure is a legitimate military target because it funds and supports Russia's invasion, while Russia has repeatedly attacked Ukraine's power system. Those are the parties' stated military rationales; the archive does not independently adjudicate the legality or proportionality of particular strikes.
- On September 14, Trump posted that Russia and Ukraine had agreed not to attack each other's energy targets. The post is primary evidence that he made the claim. By cutoff, no independently confirmed text, scope, duration, enforcement mechanism or acceptance from Kyiv or Moscow was located; Reuters reported only that the Kremlin welcomed Trump's earlier call for Ukraine to stop refinery strikes.
- No public aid suspension, sanctions relief, operational order or verified cessation of attacks tied to Trump's statements was located by the evidence cutoff. The development is therefore recorded as a presidentially claimed reciprocal understanding, not an independently verified ceasefire or implemented U.S. constraint.

## SIGNIFICANCE

A genuine reciprocal halt could reduce infrastructure damage and fuel-market pressure without asymmetrically constraining Ukraine. The difference between a presidential announcement and an accepted, observed arrangement is decisive: no independently confirmed terms or compliance were available by cutoff.

## GOALPOST / RESPONSE

Trump says both governments accepted reciprocal restraint and that stopping energy attacks will ease diesel shortages. Ukraine says Russian energy assets support the invasion, while Russia has attacked Ukraine's power system. Direct confirmations from Kyiv and Moscow, written terms, strike-monitoring data, any U.S. conditions, Russian production and exports, and diesel inventories and prices are the tests.

## MAYBE / THEREFORE

Maybe the announcement reflects a real reciprocal understanding that reduces attacks and supply pressure, or it may be an incomplete presidential account that neither side implements. Therefore the record establishes Trump's request and later public claim—not verified bilateral consent, enforceable terms, observed compliance or proof that Ukrainian strikes alone caused the shortage.


## SOURCES

- [Reuters — Trump asks Ukraine to stop strikes on Russian diesel infrastructure](https://www.reuters.com/business/energy/trump-tells-ukraines-zelenskiy-stop-hitting-russian-diesel-2026-09-13/) — independent reporting of presidential foreign-policy remarks and energy context
- [Associated Press — Trump calls on Ukraine to halt Russian diesel strikes](https://apnews.com/article/17bb6a0401abc3eaa7d4586150a41d7d) — independent reporting of presidential remarks, Ukrainian operations and reciprocal energy attacks
- [Donald Trump Truth Social post — claimed Russia-Ukraine energy-target agreement](https://truthsocial.com/@realDonaldTrump/117270009579288120) — primary evidence only that Trump published the claimed reciprocal understanding; not independent evidence of acceptance, terms or compliance
- [Reuters — Kremlin welcomes Trump's call to halt Ukrainian refinery strikes](https://www.reuters.com/business/energy/kremlin-welcomes-trumps-call-ukraine-halt-strikes-diesel-facilities-2026-09-14/) — independent reporting of the Kremlin response to Trump's initial request and continuing absence of a publicly confirmed reciprocal agreement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
