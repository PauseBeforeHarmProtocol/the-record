# Administration asks Supreme Court to review transgender military-service ban

**Entry ID:** NAT-2026-08-28-014
**Date:** January 27, 2025–November 17, 2026
**Checked:** 2026-11-17 6:06 PM EST
**Evidence state:** primary Solicitor General petition and D.C. Circuit merits opinion and public-order index plus Associated Press reporting; stay denied and mandate issued for the named serving plaintiffs, Supreme Court review pending
**Review state:** current-standard-reviewed

The D.C. Circuit denied the government's request to hold its mandate during Supreme Court review and directed immediate issuance, activating protection for the named serving plaintiffs without opening enlistment or invalidating the policy nationwide.

## THE FACTS

- The Solicitor General filed a petition asking the Supreme Court to review Talbott v. United States, a challenge to the Pentagon policy implementing Trump's January 27, 2025 executive order on transgender military service.
- The petition asks whether the policy's general disqualification of people with gender dysphoria, a history of the condition, or related interventions violates the Fifth Amendment's equal-protection component. It urges the Court to reverse the D.C. Circuit and decide the constitutional question before the district court completes a merits trial.
- On June 1, a divided D.C. Circuit panel affirmed preliminary protection for the named plaintiffs already serving, finding at that stage that the policy appeared arbitrary and based on animus. It vacated protection for the plaintiffs seeking to enlist and narrowed the injunction to the named current-service plaintiffs.
- The government argues that the policy regulates a medical condition and related treatment rather than transgender identity, satisfies rational-basis review, and deserves substantial judicial deference because military composition and readiness are entrusted to the political branches.
- The plaintiffs say the government seeks premature Supreme Court intervention without a final judgment or circuit split and that the serving plaintiffs meet military standards.
- On November 17, the D.C. Circuit denied the government's motion to stay issuance of its mandate while the certiorari petition is pending and directed the clerk to issue the mandate immediately. Associated Press reported that 27 named serving plaintiffs are protected from discharge under the panel's narrowed ruling; the order does not permit new transgender recruits to enlist or block application of the policy to everyone outside that group.
- Judge Robert Wilkins said the government had not shown that retaining the serving plaintiffs would cause irreparable harm or endanger national security; Judge Justin Walker voted to grant the stay. The administration may seek Supreme Court relief, and the certiorari petition remains pending; the November 17 order is not a Supreme Court merits decision or a nationwide final judgment.

## SIGNIFICANCE

The order converts the panel's earlier ruling from a stayed appellate decision into effective preliminary protection for the named serving plaintiffs while the government seeks Supreme Court review. It narrows immediate implementation risk for that group but leaves the broader policy, new accessions and the ultimate constitutional question unresolved.

## GOALPOST / RESPONSE

The administration says the policy is a medical-readiness rule, not identity discrimination, and that courts must defer to professional military judgments; it sought to preserve separation authority while pursuing Supreme Court review. The serving plaintiffs say the record shows qualified personnel targeted by hostility rather than readiness evidence. Any Supreme Court stay or certiorari disposition, the January trial, actual separation actions and a final merits judgment remain the tests.

## MAYBE / THEREFORE

Maybe the Supreme Court will stay the mandate, grant review and uphold greater military discretion, or it may leave the narrowed protection in place while trial and ordinary appellate review continue. Therefore the D.C. Circuit has made its preliminary protection effective for the named serving plaintiffs—not authorized new enlistment, invalidated the policy nationwide, resolved the merits finally or determined what the Supreme Court will do.


## SOURCES

- [Solicitor General — petition for certiorari in United States v. Talbott](https://glad-org-wpom.nyc3.cdn.digitaloceanspaces.com/wp-content/uploads/2025/01/20260828_Talbott-USA_Writ-of-Certiorari.pdf) — primary Supreme Court certiorari petition challenging preliminary protection for named serving plaintiffs
- [D.C. Circuit — Talbott v. United States preliminary-injunction opinion](https://media.cadc.uscourts.gov/opinions/docs/2026/06/25-5087-2176040.pdf) — primary divided appellate opinion affirming protection for named serving plaintiffs and vacating accession relief
- [The Advocate — administration seeks Supreme Court review of transgender military-service policy](https://www.advocate.com/politics/national/talbott-trans-military-supreme-court) — independent specialist reporting on the certiorari petition, procedural posture, and plaintiffs' response
- [D.C. Circuit — Talbott order denying stay and directing immediate mandate](https://media.cadc.uscourts.gov/orders/bydate/2026/11) — primary appellate order
- [Appeals court blocks Pentagon from expelling named transgender troops](https://apnews.com/article/dcdb4c91f17e59c7c2dc5fb725d3b7e9) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
