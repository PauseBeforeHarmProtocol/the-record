# Administration asks Supreme Court to review transgender military-service ban

**Entry ID:** NAT-2026-08-28-014
**Date:** January 27, 2025–August 28, 2026
**Checked:** 2026-08-29 6:07 AM EDT
**Evidence state:** primary Solicitor General certiorari petition and D.C. Circuit opinion plus independent specialist reporting with the plaintiffs' response; petition filed, review and merits pending
**Review state:** current-standard-reviewed

The certiorari petition seeks review before a scheduled trial; it does not itself dissolve the injunction protecting the named serving plaintiffs or decide the policy's constitutionality.

## THE FACTS

- The Solicitor General filed a petition asking the Supreme Court to review Talbott v. United States, a challenge to the Pentagon policy implementing Trump's January 27, 2025 executive order on transgender military service.
- The petition asks whether the policy's general disqualification of people with gender dysphoria, a history of the condition, or related interventions violates the Fifth Amendment's equal-protection component. It urges the Court to reverse the D.C. Circuit and decide the constitutional question before the district court completes a merits trial.
- On June 1, a divided D.C. Circuit panel affirmed preliminary protection for the named plaintiffs already serving, finding at that stage that the policy appeared arbitrary and based on animus. It vacated protection for the plaintiffs seeking to enlist and narrowed the injunction to the named current-service plaintiffs.
- The government argues that the policy regulates a medical condition and related treatment rather than transgender identity, satisfies rational-basis review, and deserves substantial judicial deference because military composition and readiness are entrusted to the political branches.
- The plaintiffs say the government seeks premature Supreme Court intervention without a final judgment or circuit split and that the serving plaintiffs meet military standards. The petition remains pending; filing it did not grant review, reverse the D.C. Circuit, dissolve the preliminary injunction, or newly authorize discharge of the protected plaintiffs.

## SIGNIFICANCE

The filing asks the Supreme Court to resolve the constitutional standard for the administration's transgender-service policy before full factual development at trial. A grant could produce a nationwide merits precedent on equal protection and military deference; a denial would leave the narrowed preliminary injunction and district-court proceedings in place.

## GOALPOST / RESPONSE

The administration says the policy is a medical-readiness rule, not identity discrimination, and that courts must defer to professional military judgments. The serving plaintiffs and their counsel say the record shows qualified personnel targeted by hostility rather than readiness evidence. Supreme Court docketing and disposition, opposition briefs, the January trial schedule, separation actions, and any final merits judgment are the tests.

## MAYBE / THEREFORE

Maybe the Court will grant review and uphold greater military discretion, or it may deny review and require the case to proceed through trial and ordinary appellate channels. Therefore the record reports a filed certiorari petition—not Supreme Court acceptance, a merits ruling, a nationwide injunction, or new authority to discharge the named protected plaintiffs.


## SOURCES

- [Solicitor General — petition for certiorari in United States v. Talbott](https://glad-org-wpom.nyc3.cdn.digitaloceanspaces.com/wp-content/uploads/2025/01/20260828_Talbott-USA_Writ-of-Certiorari.pdf) — primary Supreme Court certiorari petition challenging preliminary protection for named serving plaintiffs
- [D.C. Circuit — Talbott v. United States preliminary-injunction opinion](https://media.cadc.uscourts.gov/opinions/docs/2026/06/25-5087-2176040.pdf) — primary divided appellate opinion affirming protection for named serving plaintiffs and vacating accession relief
- [The Advocate — administration seeks Supreme Court review of transgender military-service policy](https://www.advocate.com/politics/national/talbott-trans-military-supreme-court) — independent specialist reporting on the certiorari petition, procedural posture, and plaintiffs' response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
