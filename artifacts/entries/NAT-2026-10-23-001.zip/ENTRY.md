# DOJ charges two former FBI officials over Hunter Biden investigation testimony

**Entry ID:** NAT-2026-10-23-001
**Date:** October 23, 2026
**Checked:** 2026-10-23 6:34 PM EDT
**Evidence state:** official DOJ announcement and 27-page statement of facts, independently corroborated by Reuters and Associated Press with defense responses and Washington Post court reporting; criminal complaints filed, no indictment or adjudication
**Review state:** current-standard-reviewed

Criminal complaints accuse Nikki Floris and Bradley Benavides of false statements to Congress; both deny wrongdoing, and neither has been indicted or convicted.

## THE FACTS

- The U.S. Attorney's Office for the District of Columbia announced that former FBI officials Nikki Floris and Bradley Benavides were each charged by criminal complaint with one count of making false statements within Congress's jurisdiction under 18 U.S.C. § 1001(a)(2). They surrendered or were taken into custody, appeared in federal court and were released. The complaints have not been approved as indictments by a grand jury.
- The charging papers allege that Floris and Benavides, former leaders of the FBI's Foreign Influence Task Force, participated in or knew about FBI investigations involving Hunter Biden but gave materially false testimony to the House Judiciary Committee in 2023. The complaint cites Floris's denial of involvement and Benavides's statement that he learned of the laptop through Wikipedia. Those are prosecutorial allegations, not adjudicated facts.
- Associated Press and The Washington Post reported that Magistrate Judge Zia Faruqui scheduled a preliminary hearing for October 27. The Post reported that the judge questioned the age and materiality of the allegations; Reuters reported that a federal grand jury would have to approve an indictment for the case to proceed beyond the complaint stage.
- Lawyers for both defendants denied wrongdoing and characterized the cases as politically motivated or baseless. Justice Department and FBI leaders said the charges enforce accountability for alleged lies to Congress and described the case as part of their response to government 'weaponization.' No guilt finding, sentence or independently measured institutional effect was established by cutoff.

## SIGNIFICANCE

The complaints are an implemented Justice Department use of criminal process against two former senior FBI officials over a politically contested investigation, ten days before the midterm elections. Their timing and subject make the cases institutionally consequential, while the preliminary complaint posture sharply limits what can be concluded.

## GOALPOST / RESPONSE

The administration says senior law-enforcement officials must be held accountable for alleged lies to Congress and that political weaponization will not be tolerated. The tests are the October 27 probable-cause hearing, any grand-jury indictment, disclosed evidence, rulings on materiality and timeliness, trial or dismissal, and eventual appellate review—not the charging announcement alone.

## MAYBE / THEREFORE

Maybe the complaint evidence will establish knowing, material false statements, or judicial and grand-jury review may find the proof, materiality or timing inadequate. Therefore the supported conclusion is that two former FBI officials face active criminal complaints—not that either allegation is true, that an indictment exists, or that either defendant is guilty.


## SOURCES

- [U.S. Attorney's Office for D.C. — Two Former FBI Officials Charged in Lying to Congress about Hunter Biden Investigations](https://www.justice.gov/usao-dc/pr/two-former-fbi-officials-charged-lying-congress-about-hunter-biden-investigations) — official charging announcement
- [U.S. District Court for D.C. — Statement of facts in United States v. Floris and Benavides](https://www.justice.gov/usao-dc/media/1468056/dl?inline=) — official 27-page criminal-complaint statement of facts; allegations not adjudicated
- [Reuters — Ex-FBI officials charged with lying to Congress about Hunter Biden probes](https://www.reuters.com/legal/government/ex-fbi-officials-charged-with-lying-congress-about-hunter-biden-probes-2026-10-23/) — independent court and charging report
- [Associated Press — Two former FBI officials charged over Hunter Biden investigation testimony](https://apnews.com/article/biden-laptop-fbi-official-charged-e41b7407f97c6dfc7c017875054c0c67) — independent court report with defense responses
- [Washington Post — Former FBI officials charged over Hunter Biden laptop inquiry](https://www.washingtonpost.com/national-security/2026/10/23/former-fbi-officials-charged-with-lying-congress-about-hunter-biden-laptop-inquiry/) — independent court report including magistrate's preliminary-hearing remarks

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
