# Judge dismisses complaints against former FBI officials for lack of probable cause

**Entry ID:** NAT-2026-10-23-001
**Date:** October 23–November 2, 2026
**Checked:** 2026-11-02 6:09 PM EST
**Evidence state:** original DOJ charging announcement and statement of facts retained; Reuters and Associated Press independently report the November 2 oral dismissal, probable-cause reasoning, judicial criticism and DOJ response; no written order, transcript, indictment, appeal or final closure retrieved
**Review state:** current-standard-reviewed

A magistrate judge found DOJ had not shown knowing, material false statements and dismissed the complaint-stage cases; prosecutors may still seek grand-jury indictments.

## THE FACTS

- The U.S. Attorney's Office for the District of Columbia announced that former FBI officials Nikki Floris and Bradley Benavides were each charged by criminal complaint with one count of making false statements within Congress's jurisdiction under 18 U.S.C. § 1001(a)(2). They surrendered or were taken into custody, appeared in federal court and were released. The complaints have not been approved as indictments by a grand jury.
- The charging papers allege that Floris and Benavides, former leaders of the FBI's Foreign Influence Task Force, participated in or knew about FBI investigations involving Hunter Biden but gave materially false testimony to the House Judiciary Committee in 2023. The complaint cites Floris's denial of involvement and Benavides's statement that he learned of the laptop through Wikipedia. Those are prosecutorial allegations, not adjudicated facts.
- Associated Press and The Washington Post reported that Magistrate Judge Zia Faruqui scheduled a preliminary hearing for October 27. The Post reported that the judge questioned the age and materiality of the allegations; Reuters reported that a federal grand jury would have to approve an indictment for the case to proceed beyond the complaint stage.
- Lawyers for both defendants denied wrongdoing and characterized the cases as politically motivated or baseless. Justice Department and FBI leaders said the charges enforce accountability for alleged lies to Congress and described the case as part of their response to government 'weaponization.' No guilt finding, sentence or independently measured institutional effect was established by cutoff.
- On November 2, U.S. Magistrate Judge Zia Faruqui dismissed the criminal complaints against Nikki Floris and Bradley Benavides after an oral ruling that prosecutors had not established probable cause of knowing, material false statements. Reuters and Associated Press report that he found some challenged statements were not false and others could reflect honest memory errors, and that DOJ had not shown motive, direct evidence or material effect on Congress. The dismissal resolves the complaints before him; it is not an acquittal after trial.
- Faruqui described the investigation and charging process as rushed and politically timed and called what occurred weaponization. Those are the judge’s findings and characterization in the reported bench ruling, not this archive’s independent conclusion about motive. DOJ said it disagreed, would evaluate its options and would remain guided by facts, evidence and law. Prosecutors may still ask a grand jury to indict, but no indictment, appeal or revived charge had issued by cutoff; no written order or transcript was retrieved.

## SIGNIFICANCE

Judicial probable-cause review ended the two complaint-stage prosecutions and directly rejected the evidentiary showing that supported the arrests. The ruling also documents a judge’s unusually strong concern about political timing and process, while preserving that prosecutors can seek a new indictment and that no trial acquittal occurred.

## GOALPOST / RESPONSE

DOJ’s strongest response is that it disagrees, is evaluating all options and says its decisions are based on facts, evidence and law. The next tests are any written ruling, grand-jury presentation, indictment, appeal or closure—not the original charging announcement, whose complaints have now been dismissed.

## MAYBE / THEREFORE

Maybe additional admissible evidence could support a grand-jury indictment, or the probable-cause failure may end the matter and reinforce concerns about process and political timing. Therefore the supported conclusion is that the filed complaints were dismissed for insufficient probable cause—not that the defendants were acquitted at trial, that every investigative concern was fabricated, or that DOJ has exhausted all lawful options.


## SOURCES

- [U.S. Attorney's Office for D.C. — Two Former FBI Officials Charged in Lying to Congress about Hunter Biden Investigations](https://www.justice.gov/usao-dc/pr/two-former-fbi-officials-charged-lying-congress-about-hunter-biden-investigations) — official charging announcement
- [U.S. District Court for D.C. — Statement of facts in United States v. Floris and Benavides](https://www.justice.gov/usao-dc/media/1468056/dl?inline=) — official 27-page criminal-complaint statement of facts; allegations not adjudicated
- [Reuters — Ex-FBI officials charged with lying to Congress about Hunter Biden probes](https://www.reuters.com/legal/government/ex-fbi-officials-charged-with-lying-congress-about-hunter-biden-probes-2026-10-23/) — independent court and charging report
- [Associated Press — Two former FBI officials charged over Hunter Biden investigation testimony](https://apnews.com/article/biden-laptop-fbi-official-charged-e41b7407f97c6dfc7c017875054c0c67) — independent court report with defense responses
- [Washington Post — Former FBI officials charged over Hunter Biden laptop inquiry](https://www.washingtonpost.com/national-security/2026/10/23/former-fbi-officials-charged-with-lying-congress-about-hunter-biden-laptop-inquiry/) — independent court report including magistrate's preliminary-hearing remarks
- [Reuters — judge dismisses case against former FBI officials](https://www.reuters.com/world/us-judge-tosses-case-against-ex-fbi-officials-accused-lying-about-hunter-biden-2026-11-02/) — independent report on oral probable-cause ruling and Justice Department response
- [AP — judge cites weaponization and dismisses Floris-Benavides complaints](https://apnews.com/article/101ccd65d10b5f779985747eb0045b52) — independent report on bench ruling, probable-cause findings and remaining indictment option

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
