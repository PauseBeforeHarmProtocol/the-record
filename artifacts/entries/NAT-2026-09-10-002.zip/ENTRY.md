# NRC proposes uranium-recovery groundwater rules and more flexible decommissioning timelines

**Entry ID:** NAT-2026-09-10-002
**Date:** September 10, 2026
**Checked:** 2026-09-10 11:57 AM EDT
**Evidence state:** primary Federal Register proposed rule and draft guidance; agency rationale and projections are attributed, with no independently measured outcome
**Review state:** current-standard-reviewed

The proposal would create in-situ-recovery-specific standards and expand options to delay decommissioning; comments close October 13.

## THE FACTS

- On September 10, the NRC published proposed rules and draft guidance under Docket NRC-2025-1204. Comments are due October 13, 2026, at 11:59 PM Eastern time; the proposal does not itself change licensees’ obligations.
- The proposal would establish groundwater-protection requirements specific to uranium in situ recovery and clarify use of alternate concentration limits as a groundwater cleanup standard.
- It would extend notification timeframes and provide additional flexibility to delay initiation of decommissioning at nuclear-materials facilities. Power-reactor licensees could use the existing specific-exemption process to request completion beyond the 60-year decommissioning timeframe.
- The NRC links the proposal to Executive Order 14300 and projects administrative savings while maintaining safety. It does not calculate an aggregate industry saving because future licensing and decommissioning activity cannot reliably be projected.

## SIGNIFICANCE

The proposal connects uranium extraction, groundwater restoration and long-term nuclear cleanup obligations. If finalized, it could change compliance costs and the timing of cleanup, but neither realized savings nor environmental or safety outcomes have been measured.

## GOALPOST / RESPONSE

The NRC argues that risk-informed, process-specific rules can reduce unnecessary burdens while protecting groundwater and maintaining safety. Public comments, final regulatory text, site-specific exemptions, restoration measurements, financial assurance and actual cleanup timelines will test that rationale.

## MAYBE / THEREFORE

Maybe tailored standards improve clarity and allow safe delays at facilities with continuing business needs, or greater flexibility may postpone restoration and shift monitoring burdens into the future. Therefore this is a proposed regulatory change with stated safeguards and estimated efficiencies—not completed deregulation, an approved site exemption, proven pollution or measured savings.


## SOURCES

- [Federal Register — In Situ Recovery Monitoring and Decommissioning Timeliness, 91 FR 57728](https://www.federalregister.gov/documents/2026/09/10/2026-18504/in-situ-recovery-monitoring-and-decommissioning-timeliness) — primary proposed rule and draft guidance

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
