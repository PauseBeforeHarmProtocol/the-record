# Treasury sanctions eight Canadian money firms and orders U.S. banks to cut off MEXC Global

**Entry ID:** NAT-2026-11-06-003
**Date:** November 6, 2026
**Checked:** 2026-11-06 6:10 PM EST
**Evidence state:** primary Treasury, FinCEN and OFAC records plus independent Reuters corroboration; eight designations implemented, MEXC order issued with future effective date, underlying allegations and effectiveness not independently adjudicated
**Review state:** current-standard-reviewed

OFAC implemented eight Iran-related designations while FinCEN issued a separate transfer prohibition effective 30 days after Federal Register publication; Treasury's transaction allegations and future disruption claims remain distinct from the legal actions.

## THE FACTS

- Treasury's Office of Foreign Assets Control added eight Canada-based money services businesses to the Specially Designated Nationals list under Executive Order 13902 for operating in Iran's digital-asset sector. OFAC said U.S.-held property is blocked and U.S. persons generally may not transact with the designated entities; Reuters independently reported the designations and their dollar-system consequences.
- In the same Operation Economic Outcast release cycle, FinCEN issued a separate order prohibiting U.S. financial institutions from transmitting funds to or from Seychelles-incorporated virtual-currency exchanger MEXC Global. Treasury said that order becomes effective 30 days after Federal Register publication, so it was ordered but not yet effective at the cutoff.
- Treasury alleged that MEXC facilitated at least $16 billion in transactions connected to sanctions evasion, cybercrime and other illicit activity between May 2021 and May 2026, and alleged links between the Canadian firms and sanctioned Iranian or criminal actors. Those figures and characterizations are formal agency findings and allegations supporting the actions; the inspected independent report confirms what Treasury did, not an independent adjudication of every underlying transaction.
- Treasury described the two measures as part of a campaign to disrupt Iranian financial channels and illicit use of digital assets. No inspected source established by cutoff how much property was actually frozen, how many transfers were prevented, whether MEXC or the eight firms contested the findings, or whether the measures changed Iranian financing behavior.

## SIGNIFICANCE

The actions impose immediate U.S. blocking consequences on eight foreign financial businesses and direct a future system-wide transfer prohibition against a major crypto exchanger. Their material legal effects are distinct from Treasury's allegations and from any later proof of deterrence, evasion or financial impact.

## GOALPOST / RESPONSE

Treasury says it is severing financial lifelines used by Iran, sanctioned actors and transnational criminals, and that institutions must choose between supporting the Iranian regime and access to the U.S. financial system. The tests are Federal Register publication and the MEXC order's effective date, compliance guidance, blocked property and rejected-transfer data, enforcement or litigation, target responses, and measurable changes in sanctioned financial flows.

## MAYBE / THEREFORE

Maybe the measures will materially disrupt the named networks, or activity may migrate to other exchanges, intermediaries and jurisdictions while legal or evidentiary challenges develop. Therefore OFAC implemented eight designations and FinCEN issued a separate future-effective transfer order—not that Treasury's every transaction allegation has been independently adjudicated or that the campaign's effectiveness is already measured.


## SOURCES

- [Treasury — Operation Economic Outcast severs MEXC Global's access to the U.S. financial system](https://home.treasury.gov/news/press-releases/sb0685) — primary FinCEN order announcement with statutory authority, alleged transaction findings and future effective date
- [FinCEN — Operation Economic Outcast severs MEXC Global's access to the U.S. financial system](https://www.fincen.gov/news/news-releases/operation-economic-outcast-severs-mexc-globals-access-us-financial-system) — primary agency order announcement
- [Treasury — sanctions eight Canadian money services businesses enabling Iran](https://home.treasury.gov/news/press-releases/sb0686) — primary OFAC designation announcement and sanctions implications
- [OFAC — Iran-related designations, November 6, 2026](https://ofac.treasury.gov/recent-actions/20261106) — primary Specially Designated Nationals list update
- [Reuters — U.S. Treasury sanctions Canadian money-services firms over Iran-related transactions](https://www.reuters.com/world/middle-east/us-treasury-sanctions-canadian-money-services-firms-over-iran-related-2026-11-06/) — independent reporting on OFAC designations and FinCEN MEXC order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
