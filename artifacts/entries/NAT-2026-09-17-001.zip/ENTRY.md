# OFAC sanctions BitBank and related Iranian digital-asset network

**Entry ID:** NAT-2026-09-17-001
**Date:** September 17, 2026
**Checked:** 2026-09-17 6:01 PM EDT
**Evidence state:** primary OFAC list action and Treasury announcement, corroborated by Reuters; implemented listings, underlying conduct alleged
**Review state:** current-standard-reviewed

Two entities and three individuals were designated; Treasury's claims about IRGC transfers remain attributed allegations.

## THE FACTS

- On September 17 OFAC added BitBank, its developer Pishtaz Simorgh Electronic Trade Company, and three individuals to the SDN List under Iran authorities. Treasury identifies Executive Order 13902 as the designation authority.
- Treasury alleges BitBank transferred hundreds of millions of dollars in Bitcoin to the IRGC and handled payments received by the Hormuz Safe Marine Services Authority. These are the agency's allegations, not independently verified transaction findings or criminal convictions.
- Treasury states that covered U.S.-jurisdiction property is blocked, U.S.-person transactions are generally prohibited unless authorized or exempt, and the 50-percent ownership rule applies. The OFAC listings flag secondary-sanctions exposure. No recovered sum or measured reduction in transfers was established.

## SIGNIFICANCE

The action extends sanctions to a named exchange and software infrastructure. A legal designation changes compliance obligations; it does not by itself measure disruption of a financial network.

## GOALPOST / RESPONSE

Treasury says the measures deny Iran financing routes and demonstrate that cryptocurrency is within sanctions enforcement. Tests include disclosed blocked assets, enforceable licenses, target responses and independently measured transaction changes. The inspected announcement and report contain no target response.

## MAYBE / THEREFORE

Maybe counterparties stop processing these flows, or activity moves to other services. Therefore the confirmed outcome is designation and associated restrictions—not a proven end to alleged transfers or adjudicated guilt.


## SOURCES

- [OFAC — Iran and Cuba designations and Belarus deletions, September 17](https://ofac.treasury.gov/recent-actions/20260917) — primary sanctions-list action
- [Treasury — Operation Economic Outcast digital-asset designations](https://home.treasury.gov/news/press-releases/sb0632/) — official designation announcement and attributed allegations
- [Reuters — Iranian financier's cryptocurrency exchange sanctioned](https://www.reuters.com/world/middle-east/us-sanctions-iranian-financiers-crypto-exchange-says-it-processes-hormuz-2026-09-17/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
