# D.C. Circuit upholds preliminary relief against IRS sharing taxpayer data with ICE

**Entry ID:** NAT-2026-09-08-006
**Date:** September 8, 2026
**Checked:** 2026-09-08 6:02 PM EDT
**Evidence state:** primary appellate opinion plus Reuters; preliminary injunction affirmed, merits likelihood assessed
**Review state:** current-standard-reviewed

The panel found the challenged procedure likely unlawful; the underlying litigation is not finally resolved.

## THE FACTS

- On September 8, the D.C. Circuit affirmed the order staying the IRS data-exchange procedure and requiring strict statutory compliance and court notice before further DHS-requested disclosures.
- The opinion records 47,289 disclosures after ICE sought information concerning 1.28 million people. The procedure accepted incomplete address fields and lacked safeguards tying disclosure to the responsible criminal investigators and relevant periods.
- The panel found plaintiffs likely to succeed and upheld preliminary relief. This is not a criminal conviction, damages award or final resolution of all claims.

## SIGNIFICANCE

The decision preserves judicial constraints on repurposing confidential tax information for immigration enforcement. It does not undo disclosures already made.

## GOALPOST / RESPONSE

The government argues the injunction obstructs lawful criminal investigations. The court says enforcement must respect Congress’s disclosure conditions. Compliance, further review and remedies for past disclosures remain to be tracked.

## MAYBE / THEREFORE

Maybe compliant individual requests can serve legitimate investigations. Therefore the challenged bulk procedure remains blocked under preliminary relief; neither a blanket prohibition on all interagency sharing nor completed remediation is established.


## SOURCES

- [D.C. Circuit — Center for Taxpayer Rights v. IRS, No. 26-5006](https://media.cadc.uscourts.gov/opinions/docs/2026/09/26-5006-2191763.pdf) — primary appellate opinion affirming preliminary relief against the IRS data-exchange procedure
- [Reuters — appeals court upholds IRS–ICE data-sharing injunction](https://www.reuters.com/legal/government/irs-under-trump-unlawfully-shared-taxpayer-info-with-immigration-authorities-2026-09-08/) — independent court reporting; appellate affirmance of preliminary relief, not final disposition of the underlying case

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
