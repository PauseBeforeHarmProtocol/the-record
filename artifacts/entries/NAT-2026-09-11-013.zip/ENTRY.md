# Court rules DHS and FEMA staffing actions unlawful while leaving remedies unresolved

**Entry ID:** NAT-2026-09-11-013
**Date:** September 11–13, 2026
**Checked:** 2026-09-13 6:01 AM EDT
**Evidence state:** complete primary 32-page district-court opinion plus independent Reuters and Associated Press reporting; merits ruling issued, relief, appeal and operational consequences unresolved
**Review state:** current-standard-reviewed

A federal judge granted partial summary judgment on four APA claims over DHS control of FEMA personnel and a roughly 50% staffing plan; the court has not yet ordered relief.

## THE FACTS

- In American Federation of Government Employees v. Trump, No. 25-cv-03698-SI, the Northern District of California granted plaintiffs partial summary judgment on September 11 on four Administrative Procedure Act claims concerning DHS control of FEMA personnel decisions and FEMA's fiscal 2026 staffing plan. The court declined to reach two alternative ultra vires claims and denied the government's cross-motion.
- The court held that DHS unlawfully removed FEMA's longstanding authority to renew Cadre of On-Call Response/Recovery Employees and that DHS and FEMA actions conflicted with the Post-Katrina Emergency Management Reform Act and the continuing resolution. It also found the renewal restrictions, employee nonrenewals and a plan projecting 11,383 personnel—approximately half the prior staffing level—arbitrary and capricious for lack of reasoned decision-making.
- The opinion says the planned 50% staffing reduction had not been fully carried out and notes later appointments and leadership changes. Associated Press reported that some previously terminated employees had been rehired. The ruling therefore does not establish that FEMA lost half its workforce or that every staffing change was unlawful.
- The court did not order a remedy in this decision. It directed the parties to meet and confer and file a joint statement about remaining relief by October 9, after which it said it would rule. Any injunction, restoration order, appeal or final staffing result remains unresolved.
- The opinion also summarizes a separate evidence-preservation ruling finding that high-level FEMA and DHS officials intentionally deleted relevant Signal messages and ordering an adverse presumption, limits on hindsight testimony and plaintiffs' fees. Those are court findings in this litigation, not a criminal judgment.
- FEMA told Associated Press that DHS and FEMA were ready for the 2026 hurricane season and were maintaining workforce stability and a strong deployable force while making the agency leaner and faster. DHS did not separately respond to AP or Reuters before their reports were published.

## SIGNIFICANCE

The ruling is a merits-stage judicial finding that DHS overrode statutory limits protecting FEMA's personnel authority and that the half-staffing plan lacked reasoned support. Because FEMA supplies national disaster-response capacity, the decision bears directly on executive reorganization power and preparedness, while the practical remedy and staffing consequences remain unsettled.

## GOALPOST / RESPONSE

The administration says FEMA retains flexibility to choose proper staffing and says the agency remains ready, stable and deployable while becoming leaner and faster. The October relief ruling, any appeal or stay, restored renewal authority, actual staffing levels, deployment capacity, response performance and congressional action are the tests.

## MAYBE / THEREFORE

Maybe later relief restores FEMA's internal staffing authority without requiring a particular headcount, or appellate review may narrow or reverse the district court's reasoning. Therefore the record confirms partial summary judgment against DHS and FEMA on four APA claims—not a final appellate judgment, a completed remedy, restoration of every job or proof that FEMA currently lacks disaster-response capacity.


## SOURCES

- [Northern District of California — FEMA staffing partial-summary-judgment order](https://storage.courtlistener.com/recap/gov.uscourts.cand.448664/gov.uscourts.cand.448664.491.0.pdf) — primary judicial opinion
- [Reuters — FEMA staffing partial-summary-judgment ruling](https://www.reuters.com/legal/government/us-judge-rules-that-trump-plan-halve-fema-workforce-violated-law-2026-09-12/) — independent legal reporting
- [Associated Press — FEMA staffing cuts ruling and agency response](https://apnews.com/article/e56494458ed43faacccebb3d62eeb30f) — independent legal reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
