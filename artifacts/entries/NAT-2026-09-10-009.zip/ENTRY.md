# Administration reroutes migrant-child trafficking reports through ORR

**Entry ID:** NAT-2026-09-10-009
**Date:** September 10–16, 2026
**Checked:** 2026-09-16 12:33 PM EDT
**Evidence state:** Associated Press direct inspection of the administration memo and attributed ORR response; reported implemented directive, with the instrument unavailable publicly and outcomes unmeasured
**Review state:** current-standard-reviewed

A September 10 memo reviewed by AP ended direct caregiver reporting to the trafficking office; ORR now screens referrals, while effects on identification, benefits and removal cases remain unmeasured.

## THE FACTS

- A September 10 Trump administration memo reviewed by the Associated Press directed federal employees and care providers to stop reporting suspected labor or sex trafficking involving migrant children directly to the Office on Trafficking in Persons. Reports are now submitted only to the Office of Refugee Resettlement, which investigates and decides which matters to forward.
- The change applies to about 1,800 children then in federal custody and to additional released children who remain under supervision. Under the prior process, caregivers screened unaccompanied children within five days of admission and notified the trafficking office within 24 hours when they suspected trafficking.
- ORR said a review found 95% of more than 9,000 reports were not viable trafficking leads for criminal investigators. AP separately reported that 58% of the reports qualified for trafficking-related benefits, a different legal and administrative determination; neither percentage establishes how the new screen will affect valid future referrals.
- ORR said the change will strengthen integrity, reduce improper referrals and fraud, and ensure immediate support for children who may have experienced trafficking. Advocates and a former ORR deputy director said the trafficking office has specialized expertise and warned that routing claims through the custodial agency could delay or suppress valid cases.
- The underlying memo was not publicly retrievable by cutoff. AP directly inspected it and obtained the administration response, but no implementation data yet measure referral times, certification rates, services, visa or asylum outcomes, erroneous denials or removals under the new process.

## SIGNIFICANCE

The directive changes the gate through which vulnerable children reach federally recognized trafficking protections and related services. It is an implemented reporting change, but the absence of outcome data means neither the administration's efficiency claim nor critics' predicted harms are established.

## GOALPOST / RESPONSE

ORR says centralized screening will reduce improper claims and fraud while getting support to children who may have been trafficked. The tests are referral and processing times, referral and certification rates, reasons for rejection, access to services and counsel, immigration outcomes, audit findings and whether valid cases are missed.

## MAYBE / THEREFORE

Maybe ORR screening separates abuse or neglect reports from statutory trafficking cases more consistently, or placing a new gate inside the custodial agency may delay or block meritorious referrals. Therefore the record establishes the September 10 reporting directive and changed decision path—not improved accuracy, reduced fraud, denied benefits or increased deportations.


## SOURCES

- [Associated Press — migrant-child trafficking reporting directive](https://apnews.com/article/human-trafficking-claims-unaccompanied-minors-trump-4cd31c79202b49c6144f474c970eeff4) — independent reporting based on direct inspection of the September 10 administration memo and an attributed ORR response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
