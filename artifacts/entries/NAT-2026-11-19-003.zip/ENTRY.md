# United States, Russia and China issue limited summit declaration

**Entry ID:** NAT-2026-11-19-003
**Date:** November 19, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** official White House joint declaration plus Reuters and Associated Press reporting; commitments announced, with no treaty, arsenal reduction, implementation timetable or measured outcome
**Review state:** current-standard-reviewed

The three leaders committed to dialogue on nuclear risk and several broad policy goals but announced no arsenal reductions, treaty or implementation timetable.

## THE FACTS

- Trump, Vladimir Putin and Xi Jinping met in Shenzhen on November 19 and issued a four-part heads-of-state declaration committing to maintain strategic stability and international security.
- The declaration commits the countries to pursue United Nations reform and says they plan to increase production and supply of refined petroleum products while supporting stable energy flows. It contains no quantities, legal instrument, funding, implementing agency or deadline.
- The leaders emphasized state consent and immunities of state officials and said the International Criminal Court and similar bodies must not abuse jurisdiction. This is a joint policy position, not a treaty or independently enforceable jurisdictional change.
- They reaffirmed that nuclear war cannot be won and must never be fought and said the three countries will conduct dialogue on nuclear risk reduction and nonproliferation. Reuters and Associated Press reported no arms-control commitments or reductions, and the declaration omitted Russia's war in Ukraine and the Iran conflict.

## SIGNIFICANCE

The declaration creates a formal trilateral diplomatic position among the three largest nuclear powers and could open a channel that includes China in nuclear-risk discussions. Its immediate substantive reach is limited: it contains no arms-control limits, verification, timetable or operative implementation measure.

## GOALPOST / RESPONSE

The administration presents the summit as historic engagement and a step toward peace and strategic stability. Independent reports emphasize the declaration's narrow scope. The tests are scheduled talks, negotiating mandates, written arms-control or nonproliferation proposals, measurable energy-supply changes, UN or ICC actions and verified implementation.

## MAYBE / THEREFORE

Maybe the declaration will begin sustained nuclear-risk or institutional negotiations, or it may remain symbolic without deadlines or verification. Therefore the leaders made formal but broad commitments—not a peace treaty, arms-reduction agreement or implemented energy plan.


## SOURCES

- [U.S.-Russia-China Heads of State Declaration toward Peace](https://www.whitehouse.gov/briefings-statements/2026/11/u-s-russia-china-heads-of-state-declaration-toward-peace/) — primary joint declaration stating the leaders' four commitments after the Shenzhen summit
- [Trump, Xi and Putin release 'peace declaration' from unprecedented summit](https://www.reuters.com/world/china/trump-xi-putin-release-peace-declaration-unprecedented-summit-2026-11-19/) — independent reporting on the declaration, summit and absence of arms-control commitments
- [Trump, Xi and Putin agree to a narrower agenda after historic trilateral meeting](https://apnews.com/article/trump-xi-putin-nuclear-ukraine-iran-a04dc76ed8e786b087e2c1ea9598783a) — independent reporting on the summit, declaration's limited commitments and administration framing

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
