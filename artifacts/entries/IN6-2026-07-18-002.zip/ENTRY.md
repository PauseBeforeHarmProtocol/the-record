# Seventeen IN‑6 community-project requests advance through Appropriations

**Entry ID:** IN6-2026-07-18-002
**Date:** June 24, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** official member statement; final enactment pending

Shreve’s office reports more than $45 million in requested projects cleared the committee stage; the money is not yet enacted.

## THE FACTS

- Rep. Shreve’s office announced that all 17 of his Community Project Funding requests advanced through the House Appropriations Committee, totaling more than $45 million.
- The listed projects include a $27.5 million Indiana National Guard aircraft-maintenance hangar in Shelbyville, public-safety equipment, water and sewer infrastructure, roads, workforce development, and first-responder projects.
- The member’s own release states that final funding still must pass the full House and Senate and be signed into law.

## SIGNIFICANCE

Committee advancement is a meaningful use of appropriations power, but it is not the same as money delivered. A finished accountability record must track each project through final bill text, conference changes, enactment, obligation, and local receipt.

## GOALPOST / RESPONSE

“Secured” and “delivered” are premature unless the funds survive the remaining legislative and administrative stages. The accurate current status is: requested and committee-approved, with final funding pending.


## SOURCES

- [Rep. Shreve release — 17 community projects advance](https://shreve.house.gov/media/press-releases/shreve-secures-committee-approval-17-community-projects-advancing-more-45) — official member statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
