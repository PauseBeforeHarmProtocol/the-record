# DOJ and HHS establish agency-wide Do Not Pay data-matching programs

**Entry ID:** NAT-2026-09-02-003
**Date:** September 2, 2026
**Checked:** 2026-09-02 6:02 AM EDT
**Evidence state:** two primary Federal Register Privacy Act notices describing the DOJ and HHS matching programs, covered records, effective period and review process; implementation and outcomes pending
**Review state:** current-standard-reviewed

The future-effective programs will compare benefit and grant-payment records with Treasury databases to flag possible improper payments; a match requires agency review rather than automatic denial.

## THE FACTS

- The Justice Department and Department of Health and Human Services published separate notices establishing computerized matching programs with Treasury's Do Not Pay Working System.
- DOJ's program covers the Radiation Exposure Compensation Act and September 11th Victim Compensation Fund and uses claimant or beneficiary names, Social Security numbers and dates of birth. HHS's agency-wide program covers HHS grantees and grant payments made through the Payment Management System.
- Both departments said the comparisons are intended to identify, prevent or recover improper payments under the Payment Integrity Information Act and Executive Order 14249. A potential match identifies a database record for agency review; the notices do not make every match an automatic denial, recovery or finding of fraud.
- Comments are due October 2. The programs become effective 30 days after publication and are scheduled to run through September 10, 2029 under Treasury's four-year waiver of the usual matching-agreement requirement for qualifying Do Not Pay programs.

## SIGNIFICANCE

The programs expand federal use of cross-agency identity and eligibility data across sensitive compensation programs and the HHS grant-payment system. They may prevent improper payments, but accuracy, redress, privacy safeguards and the treatment of false matches will determine their human and fiscal effects.

## GOALPOST / RESPONSE

DOJ and HHS say Do Not Pay matching is required by payment-integrity law and will help verify eligibility before awards or payments and support later recovery. Claimants, beneficiaries and grantees may reasonably question database accuracy, data minimization, waiver of individual matching agreements, notice and correction procedures. Match rates, false positives, manual review, payment delays, recoveries, privacy incidents, appeals and audited savings are the tests.

## MAYBE / THEREFORE

Maybe the comparisons will prevent material improper payments while human review protects eligible recipients, or inaccurate or stale records may delay benefits and grants or expose sensitive data without producing verified savings. Therefore the record confirms two future-effective agency matching programs and their stated scope—not a finding that any listed person or grantee is ineligible, an automatic denial system or measured fraud reduction.


## SOURCES

- [Federal Register — DOJ Do Not Pay matching program](https://www.federalregister.gov/documents/2026/09/02/2026-17963/privacy-act-of-1974-matching-program) — primary Privacy Act notice establishing a future-effective agency benefit-record matching program
- [Federal Register — HHS Do Not Pay matching program](https://www.federalregister.gov/documents/2026/09/02/2026-17907/privacy-act-of-1974-matching-program) — primary Privacy Act notice establishing a future-effective agency grant-payment matching program

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
