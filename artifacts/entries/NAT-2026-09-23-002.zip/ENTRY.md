# FBI investigates claimed compromise of its jobs portal and employee data

**Entry ID:** NAT-2026-09-23-002
**Date:** September 23, 2026
**Checked:** 2026-09-24 6:02 AM EDT
**Evidence state:** Associated Press reporting containing the FBI's on-record statement, observed portal status and clearly attributed hacker and third-party claims; formal investigation documented, underlying compromise, scope, attribution and remediation unresolved
**Review state:** current-standard-reviewed

The bureau opened an investigation after ShinyHunters claimed it compromised FBIJobs.gov and employee information; the point of entry, authenticity, scope and any exfiltration remained unverified.

## THE FACTS

- The FBI said it was actively and aggressively investigating a cybercriminal group's claim that FBIJobs.gov had been compromised and that FBI employee personally identifiable information was affected. The bureau said it was working with third-party providers that support the portal to mitigate risk.
- The FBI said the point of breach had not been determined and could involve either a third party or the bureau's enterprise. FBIJobs.gov, the recruitment and application portal, was offline when Associated Press checked on September 23.
- A group calling itself ShinyHunters claimed it held sensitive information about agents and job applicants. Associated Press reported that the claim could not immediately be verified; the group's statements are allegations, not an FBI finding that a breach or stated data volume occurred.
- Associated Press reported that 404 Media reviewed what appeared to be a sample concerning 5,000 employees and attributed an Oracle PeopleSoft vulnerability theory to a group representative. The FBI did not confirm that sample, attack path or scope, so the record does not treat them as established facts.
- The bureau's stated response establishes a formal investigation and mitigation effort. No public forensic report, victim count, notice of confirmed exfiltration, attribution, arrest, charge or completed remediation existed by cutoff.

## SIGNIFICANCE

A compromise of a federal law-enforcement recruitment system or employee data could expose personnel and applicants to identity theft, coercion or targeted harassment. The investigation is material because of that potential risk, while the absence of confirmed entry point, data set and victim scope requires strict separation between the hackers' claim and verified findings.

## GOALPOST / RESPONSE

The FBI says it is investigating aggressively and working with service providers to mitigate risk, while the group asserts a broad compromise. A forensic finding, confirmed attack vector, vendor notice, authenticated sample, affected-person count, required notifications, restored service, attribution, enforcement action and documented remediation are the tests.

## MAYBE / THEREFORE

Maybe the investigation will verify a significant portal or vendor compromise, or the group's claims and apparent sample may prove exaggerated, incomplete or unrelated to current systems. Therefore the FBI opened a formal investigation and took the portal offline amid a claimed compromise—not that the alleged breach, attack path, data scope or perpetrator has been independently established.


## SOURCES

- [Associated Press — FBI investigates claimed jobs-portal and employee-data compromise](https://apnews.com/article/fbi-criminal-hacking-group-jobs-website-beach-d627cbc6811344e7ad41e9f164cdf1c9) — independent reporting containing the FBI's on-record statement and clearly attributed unverified claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
