# Trump announces Stephen Miller will become White House chief of staff on November 9

**Entry ID:** NAT-2026-11-06-002
**Date:** November 6, 2026
**Checked:** 2026-11-06 6:10 PM EST
**Evidence state:** Trump's publication and a formal White House release, independently corroborated by AP and Reuters; appointment announced with a future effective date, implementation and policy effects not yet established
**Review state:** current-standard-reviewed

The formally announced transition replaces Susie Wiles and moves her to Trump's political operation; it had not yet taken effect at the cutoff and does not itself establish a change in policy outcomes.

## THE FACTS

- Trump published that current Deputy Chief of Staff Stephen Miller will become White House chief of staff on Monday, November 9, 2026. A later White House release formally described Miller as the incoming 33rd chief of staff, and AP and Reuters independently reported the announcement.
- The announcement says Miller will succeed Susie Wiles. Trump said Wiles will move to his political operation; AP reported that Wiles thanked Trump and described her service in a separate public statement.
- The White House presented Miller's experience, institutional knowledge and commitment to Trump's agenda as the rationale for the appointment. Reuters described the chief of staff as the president's gatekeeper who manages White House staff, the president's schedule and coordination with departments and lawmakers.
- The transition was announced, not yet implemented, at the cutoff. The sources do not establish that Miller had assumed the office before November 9 or that the personnel change had produced a specific policy, legal or measured outcome.

## SIGNIFICANCE

Chief of staff is the White House's senior management and coordination role, so a formally announced replacement is a material governance transition rather than routine personnel chatter. The record is bounded to the announced appointment and future effective date; forecasts about how Miller will use the office remain interpretation, not completed fact.

## GOALPOST / RESPONSE

Trump and the White House describe Miller as a trusted, experienced operator who will advance the administration's agenda, while praising Wiles's tenure and moving her to the political operation. The tests are whether the transition occurs on November 9, the resulting staff and process changes, dealings with Congress and agencies, and documented policy or oversight outcomes rather than assumptions from the appointment alone.

## MAYBE / THEREFORE

Maybe Miller's promotion will consolidate his influence over immigration, executive-power and congressional strategy, or the practical change may be smaller because he already held a central policy role. Therefore Trump formally announced a consequential White House management transition effective November 9—not that the handoff had occurred by cutoff or that any future policy result is established.


## SOURCES

- [Trump Truth Social — Stephen Miller chief-of-staff announcement](https://truthsocial.com/@realDonaldTrump/117571000109141399) — primary record that Trump published the appointment statement; claims inside are not independently verified
- [White House — President Trump names Stephen Miller as 33rd White House Chief of Staff](https://www.whitehouse.gov/releases/2026/11/president-trump-names-stephen-miller-as-33rd-white-house-chief-of-staff/) — primary official appointment announcement and administration explanation
- [AP — Stephen Miller replaces Susie Wiles as Trump's White House chief of staff](https://apnews.com/article/95690fe076f6bb8cfe2bf77435a1910d) — independent reporting and transition context
- [Reuters — Trump makes Stephen Miller his chief of staff](https://www.reuters.com/world/us/trump-says-stephen-miller-become-chief-staff-2026-11-06/) — independent reporting and institutional context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
