# CBP opens rulemaking on heightened import and supply-chain disclosures

**Entry ID:** NAT-2026-09-02-002
**Date:** September 2, 2026
**Checked:** 2026-09-02 6:02 AM EDT
**Evidence state:** primary CBP Federal Register advance notice of proposed rulemaking; comment-stage concepts documented, final requirements and effects unresolved
**Review state:** current-standard-reviewed

The advance proposal asks whether importers should provide foreign identifiers, production details and export records; it imposes no new disclosure duty yet.

## THE FACTS

- U.S. Customs and Border Protection published an advance notice of proposed rulemaking seeking comment on heightened import disclosures intended to reveal more of the parties, production methods and documentation behind goods entering the United States.
- The agency is considering requirements for foreign tax and global-business identifiers, detailed supply-chain and production information, technological tracing tools and documents submitted to foreign customs authorities, including export declarations, commercial invoices, packing lists, certificates of origin, licenses and transport records.
- CBP said the proposal implements Executive Order 14411 and could help detect illegal transshipment, dual invoicing, forced-labor violations, origin misstatements, intellectual-property violations and other customs evasion.
- Comments are due December 1. The document asks questions about scope, transmission, retention, random requests, responsible parties, standards of care, exemptions, costs, data formats and technology; it does not select a final design or impose a new reporting requirement by cutoff.

## SIGNIFICANCE

A final rule could substantially expand the data importers must collect and transmit across global supply chains, strengthening enforcement while adding compliance, interoperability and data-security burdens. Because the document is an advance inquiry, the eventual scope and economic impact remain open.

## GOALPOST / RESPONSE

CBP says greater visibility can close customs loopholes and improve enforcement against dangerous goods, evasion and unlawful sourcing. Importers and trading partners may argue that universal or poorly targeted requirements would be costly, duplicative, difficult to verify and risky for confidential business data. A proposed regulatory text, cost analysis, privacy and security controls, exemptions, enforcement results and a final rule are the tests.

## MAYBE / THEREFORE

Maybe targeted disclosures and interoperable tracing will help CBP identify real violations without excessive burden, or a broad mandate may collect large volumes of unreliable or sensitive data at high cost. Therefore the record confirms a formal advance rulemaking and the categories CBP is considering—not an adopted disclosure mandate, a final technology system or measured enforcement benefit.


## SOURCES

- [Federal Register — heightened import disclosures for supply-chain visibility](https://www.federalregister.gov/documents/2026/09/02/2026-17926/heightened-import-disclosures-for-supply-chain-visibility) — primary advance notice of proposed rulemaking describing contemplated import and supply-chain disclosures

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
