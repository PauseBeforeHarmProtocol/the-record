# Independent analysis estimates U.S. consumers bore outsized Iran-war fuel costs

**Entry ID:** NAT-2026-10-26-003
**Date:** October 26, 2026
**Checked:** 2026-10-26 6:02 PM EDT
**Evidence state:** primary Centre for Research on Energy and Clean Air methodology and results with independent Reuters reporting and a separate Reuters analysis of AAA price data; measured estimates with stated counterfactual limits
**Review state:** current-standard-reviewed

A cross-country study estimated $160 billion in additional U.S. fuel costs since the war began, while a separate AAA comparison put second-term gasoline prices fractionally above the Biden-era average.

## THE FACTS

- The Centre for Research on Energy and Clean Air estimated that consumers worldwide paid $468 billion in additional road-fuel costs from March through mid-October compared with January-February prices, including $160 billion in the United States. It estimated the average U.S. consumer paid $471 more, versus a $60 global average.
- The analysis covered 169 countries and attributed the comparatively high U.S. burden to greater private-vehicle use, longer driving distances, lower fleet efficiency and slower electric-vehicle adoption. The estimate is model-based and counterfactual: it measures the difference from early-2026 prices and does not prove that every subsequent price change was caused solely by the Iran war or a single administration decision.
- Reuters separately calculated from AAA data that average regular gasoline during Trump's second term was $3.472 per gallon through October 26, compared with $3.471 during the Biden administration, while diesel averaged $4.343 versus $4.078. Diesel reached a reported record $6.523 on September 22. Those period averages describe consumer prices; they do not isolate causation.
- The administration said higher prices were a small cost for preventing Iran from obtaining a nuclear weapon and argued that prices would fall when the war ended. That is the administration's policy justification and forecast, not an independent measurement of the campaign's necessity, effectiveness or future prices.
- The findings measure an economic consequence of the continuing hostilities already tracked in NAT-2026-08-17-001. This record does not create a second count for the war decision itself; it isolates a newly published effectiveness-and-cost finding as a distinct consequence stage.

## SIGNIFICANCE

The new estimates quantify a household-level cost of the Iran campaign and show why war-power decisions can produce unequal domestic burdens even in a major oil-producing country. The result adds measurable consequences to a policy debate previously dominated by military claims and forecasts.

## GOALPOST / RESPONSE

The administration argues the fuel-price burden is justified by the objective of stopping an Iranian nuclear weapon and will recede when hostilities end. The tests are future retail-price data, the duration and legal status of the war, independently verified progress toward the stated nuclear objective, updated cost estimates and whether prices normalize after a ceasefire or settlement.

## MAYBE / THEREFORE

Maybe the study overstates the war's share by using early-2026 prices as its counterfactual, or it may understate wider transport and inflation effects not captured in direct fuel spending. Therefore the supported conclusion is that a transparent cross-country analysis estimated an outsized U.S. burden and AAA data showed elevated gasoline and diesel prices—not that the war alone caused every dollar or that the policy's benefits have been measured.


## SOURCES

- [Centre for Research on Energy and Clean Air — U.S. Hormuz fuel-cost analysis](https://energyandcleanair.org/us-paying-most-for-hormuz-oil-shock/) — primary cross-country methodology and modeled fuel-cost findings
- [Reuters — U.S. consumers paying most for Iran-war fuel spike](https://www.reuters.com/business/energy/us-consumers-paying-most-fuel-price-spikes-iran-war-study-says-2026-10-26/) — independent reporting on the CREA analysis, methodology and administration response
- [Reuters — Trump-term gasoline average edges above Biden-term average](https://www.reuters.com/legal/government/average-price-gasoline-during-trumps-term-now-exceeds-bidens-midterms-loom-2026-10-26/) — independent analysis of AAA gasoline and diesel price data with stated period comparisons

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
