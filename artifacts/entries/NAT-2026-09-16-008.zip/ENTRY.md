# Senate Agriculture Committee advances farm bill 12–11

**Entry ID:** NAT-2026-09-16-008
**Date:** September 16, 2026
**Checked:** 2026-09-17 6:01 PM EDT
**Evidence state:** primary committee announcement plus agricultural reporting of the vote and meeting; committee-approved proposal, prior-window omission
**Review state:** current-standard-reviewed

The resumed markup produced committee passage, not a law; this prior-window omission was located while reviewing Trump's new post.

## THE FACTS

- The Senate Agriculture Committee's September 16 announcement confirms committee passage of the Agriculture Act of 2026, branded Farm Bill 2.0. AgWired reports a 12–11 party-line vote after the panel resumed its August markup.
- Chairman John Boozman described passage as a step toward an updated law and said more senators' support was needed. Neither his announcement nor the committee vote establishes full-Senate passage, enactment or new benefit payments.
- AgWired reports that Joni Ernst unsuccessfully sought an amendment vote concerning state livestock-production standards. Amy Klobuchar emphasized areas of agreement but pressed for a two-year delay of the SNAP cost-share requirement. These disagreements remained part of the legislative process.

## SIGNIFICANCE

The committee action advances a major national agriculture and nutrition proposal while leaving floor votes and final policy terms unresolved.

## GOALPOST / RESPONSE

Boozman argues rural producers urgently need updated legislation. The next tests are reported text, amendments, chamber votes, reconciliation of differences and presidential action—not a promotional claim that the bill has already delivered assistance.

## MAYBE / THEREFORE

Maybe further negotiation builds the votes for enactment, or unresolved nutrition and livestock issues stall the measure. Therefore the established result is committee passage, not a completed national farm-policy change.


## SOURCES

- [Senate Agriculture Committee — Boozman statement on committee passage](https://www.agriculture.senate.gov/newsroom/rep/press/release/boozman-statement-on-committee-passage-of-farm-bill-20) — primary committee passage announcement
- [AgWired — farm bill reported out of Senate Agriculture Committee](https://agwired.com/2026/09/17/farm-bill-reported-out-of-senate-ag-committee/) — independent agricultural reporting with meeting audio

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
