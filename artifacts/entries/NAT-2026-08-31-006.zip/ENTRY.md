# White House announces nine additional drug-pricing arrangements

**Entry ID:** NAT-2026-08-31-006
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** primary White House fact sheet naming nine manufacturers and commitments, plus Reuters reporting from the event and Teva's contrary statement; arrangements announced, underlying terms undisclosed, savings and implementation unmeasured
**Review state:** current-standard-reviewed

The administration says the companies accepted Medicaid most-favored-nation pricing and manufacturing commitments, but Teva described its agreement as still under discussion and the pricing terms remain undisclosed.

## THE FACTS

- The White House announced most-favored-nation drug-pricing arrangements with Alcon, Astellas Pharma, BeOne Medicines, BridgeBio, CSL, Kyowa Kirin, Sun Pharma, Teva Pharmaceuticals and UCB. It said the additions brought the administration's total to 26 manufacturers covering 89% of the branded-drug market.
- The White House said every state Medicaid program would receive most-favored-nation prices on products made by the nine companies and that new innovative medicines would launch at those prices. It also announced at least $19.6 billion in collective near-term U.S. manufacturing commitments and specified active-pharmaceutical-ingredient donations from UCB, Sun Pharma, Teva and Astellas to a federal reserve.
- Reuters reported that executives attended the Oval Office event and that Trump said deals had been signed with several named companies. Teva, however, said it remained in discussions with the administration about a potential agreement, creating a material conflict with the White House's representation that all nine agreements were complete.
- The White House did not publish the agreements, covered-drug lists, net prices, discount schedules or implementation dates. Reuters said companies described some terms as private, so the savings for government and patients remain unknown. Medicaid already receives substantial statutory rebates and most enrollees pay little out of pocket for prescriptions.
- The administration's decade-long savings estimates and claims about market coverage are projections or administration measurements, not independently measured savings from these nine arrangements. No record by cutoff established delivered API quantities, completed manufacturing investment or realized price reductions under this round.

## SIGNIFICANCE

If implemented as described, the arrangements could change Medicaid net prices, future drug launches and domestic supply-chain investment across nine additional manufacturers. The undisclosed terms and Teva's contrary status statement make it impossible at cutoff to verify uniform finalization, covered products or actual savings.

## GOALPOST / RESPONSE

The administration says international reference pricing ends foreign free-riding, lowers American prices and trades pricing commitments for supply-chain investment. Critics note that Medicaid already secures deep rebates and that confidential agreements make incremental savings difficult to audit. Executed company agreements, state Medicaid submissions, effective dates, product-level net prices, independent spending data, completed facilities and documented reserve deliveries are the tests.

## MAYBE / THEREFORE

Maybe private implementation details will later show binding, broad price reductions and completed investments, or the arrangements may be narrower and less final than the announcement suggests. Therefore the record confirms a White House announcement and multiple company participations while flagging Teva's unresolved status; it does not present projected savings, investment pledges or reserve donations as already realized outcomes.


## SOURCES

- [White House — nine additional most-favored-nation pharmaceutical arrangements](https://www.whitehouse.gov/fact-sheets/2026/08/fact-sheet-president-donald-j-trump-announces-deal-with-nine-additional-pharmaceutical-manufacturers-to-lower-drug-prices-for-americans/) — primary administration fact sheet naming manufacturers, pricing representations, manufacturing commitments, API pledges and projected savings
- [Reuters — administration announces drug-pricing arrangements with nine manufacturers](https://www.reuters.com/legal/litigation/trump-administration-announce-drug-pricing-deals-2026-08-31/) — independent reporting on participating companies, undisclosed terms, unknown savings, Medicaid context and Teva's contrary status statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
