# DOJ directs 29 states and D.C. to preserve 2024 election records amid voter-data lawsuits

**Entry ID:** NAT-2026-09-10-008
**Date:** September 10, 2026
**Checked:** 2026-09-10 11:59 PM EDT
**Evidence state:** Associated Press reporting based on inspected letters and on-record federal and state responses; directive reported, underlying litigation and any liability unresolved
**Review state:** current-standard-reviewed

The preservation letters warn of possible penalties but do not establish that any election official destroyed records or committed a crime.

## THE FACTS

- The Associated Press reported at 5:59:29 p.m. EDT on September 10 that the Justice Department had sent preservation letters to officials in 29 states and the District of Columbia in connection with pending lawsuits seeking detailed voter-registration information.
- The letters directed recipients not to destroy records from the 2024 election and warned that failure to preserve relevant material could carry civil or criminal consequences. AP inspected a letter describing Utah Lieutenant Governor Deidre Henderson as under investigation.
- Henderson said she was unaware of any investigation and said her office had cooperated with the department. Other state officials cited privacy and federalism concerns about demands for information including addresses, dates of birth, driver's-license numbers and partial Social Security numbers.
- The Justice Department characterized the letters as normal litigation-preservation notices sent to parties in pending cases. The letters do not by themselves prove record destruction, voter fraud, unlawful noncompliance or criminal liability, and no charge against a state official was reported by cutoff.

## SIGNIFICANCE

The federal directive expands pressure on state election officials while the administration litigates for access to sensitive voter data. Preservation orders can protect evidence, but the scope, accusatory language and privacy stakes make judicial review and documented handling of personal information important.

## GOALPOST / RESPONSE

DOJ says it is preserving evidence in ordinary litigation and seeking information needed to enforce federal election laws. The actual letters, case-by-case court orders, statutory authority, data-security controls, state responses and any filed enforcement action are the tests—not treating the word investigation as proof of wrongdoing.

## MAYBE / THEREFORE

Maybe broad preservation notices are routine safeguards for evidence in active cases, or their scope and penalty warnings may improperly pressure state officials amid disputed voter-data demands. Therefore the record establishes that the letters were sent and what AP reported they required—not voter fraud, destroyed evidence, valid criminal exposure or a judicial endorsement of DOJ's data claims.


## SOURCES

- [AP — DOJ directs states to preserve 2024 election records](https://apnews.com/article/b92e31e436ccf31516e02f1ca9f69aea) — independent reporting based on inspected government letters and on-record responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
