# DOJ election-record demands face judicial limits as Utah voter-file suit is dismissed

**Entry ID:** NAT-2026-09-10-008
**Date:** September 10, 2026
**Checked:** 2026-10-25 12:01 PM EDT
**Evidence state:** Filed U.S. district-court memorandum decision and order plus independent local court reporting; Utah complaint dismissed with prejudice, appeal status unresolved
**Review state:** current-standard-reviewed

A federal judge dismissed DOJ's Utah suit with prejudice after holding that the statewide voter-registration list falls outside the Civil Rights Act provision DOJ invoked.

## THE FACTS

- The Associated Press reported at 5:59:29 p.m. EDT on September 10 that the Justice Department had sent preservation letters to officials in 29 states and the District of Columbia in connection with pending lawsuits seeking detailed voter-registration information.
- The letters directed recipients not to destroy records from the 2024 election and warned that failure to preserve relevant material could carry civil or criminal consequences. AP inspected a letter describing Utah Lieutenant Governor Deidre Henderson as under investigation.
- Henderson said she was unaware of any investigation and said her office had cooperated with the department. Other state officials cited privacy and federalism concerns about demands for information including addresses, dates of birth, driver's-license numbers and partial Social Security numbers.
- The Justice Department characterized the letters as normal litigation-preservation notices sent to parties in pending cases. The letters do not by themselves prove record destruction, voter fraud, unlawful noncompliance or criminal liability, and no charge against a state official was reported by cutoff.
- On October 23, U.S. District Judge David Barlow denied the attorney general's motion to compel and dismissed DOJ's Utah complaint with prejudice. The court held that Utah's statewide voter-registration list falls outside Title III of the Civil Rights Act because the lieutenant governor develops the list rather than receiving it as a record that comes into her possession.
- The order did not reach Utah's alternative arguments about the stated basis for DOJ's demand, state-law redactions or the federal Privacy Act. Dismissal with prejudice resolves this district-court complaint, but an appeal and the separate voter-data cases remain possible; no appellate disposition was located by cutoff.

## SIGNIFICANCE

The ruling is a concrete judicial limit on one legal theory DOJ used to obtain a complete state voter file. It does not decide every voter-data dispute, but it turns the Utah matter from an unresolved demand into a district-court loss and clarifies that litigation and preservation language is not itself proof of state wrongdoing.

## GOALPOST / RESPONSE

DOJ says it is preserving evidence and seeking records needed to enforce federal election laws. The strongest test is now the filed order: the district court rejected the Title III theory as applied to Utah's statewide list. Any appeal, different statutory claim, narrower demand, data-security controls and rulings in the other state cases remain the appropriate tests.

## MAYBE / THEREFORE

Maybe the Utah ruling reflects a narrow textual defect DOJ can address through another statute or on appeal, or it may mark a broader limit on the administration's effort to compel statewide voter files. Therefore the record establishes a dismissal with prejudice in this case—not a nationwide injunction, proof that every DOJ demand is unlawful, or a final appellate resolution.


## SOURCES

- [AP — DOJ directs states to preserve 2024 election records](https://apnews.com/article/b92e31e436ccf31516e02f1ca9f69aea) — independent reporting based on inspected government letters and on-record responses
- [U.S. District Court for the District of Utah — memorandum decision and order in United States v. Henderson](https://utahnewsdispatch.com/wp-content/uploads/2026/10/Henderson-suit-memo-and-order-.pdf) — primary filed judicial order, Case No. 2:26-cv-00166-DBB, Document 68; mirror hosted by Utah News Dispatch
- [KSL — judge dismisses federal effort to obtain Utah voter rolls](https://www.ksl.com/article/51640411/judge-blocks-fed-effort-to-obtain-utah-voter-rolls) — independent local court reporting with named state response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
