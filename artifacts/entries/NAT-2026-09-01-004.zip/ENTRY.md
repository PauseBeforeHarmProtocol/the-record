# FAA proposes special flight rules around Mar-a-Lago

**Entry ID:** NAT-2026-09-01-004
**Date:** September 1, 2026
**Checked:** 2026-09-02 6:02 AM EDT
**Evidence state:** primary Federal Register notice of proposed rulemaking plus independent Reuters reporting quoting the FAA and Secret Service; proposal formally published, final instrument and outcomes pending
**Review state:** current-standard-reviewed

The published proposal would codify a one-nautical-mile, 2,000-foot security area while preserving specified airport and emergency access; it is not yet a final permanent restriction.

## THE FACTS

- The Federal Aviation Administration said it is proposing special flight rules in a one-nautical-mile radius and up to 2,000 feet around President Trump's Mar-a-Lago residence near President Donald J. Trump International Airport in Palm Beach.
- The U.S. Secret Service requested the restrictions based on what it called adverse threat intelligence and said the rules would improve its ability to mitigate risks from unauthorized crewed aircraft and drones.
- The proposal would permit commercial aircraft that follow the established procedures; the FAA said omitting that exception would essentially make the airport's primary runway unusable. Emergency, lifesaving and law-enforcement aircraft could also enter with authorization and two-way air-traffic-control communication.
- The FAA said broader temporary restrictions will continue when Trump is at Mar-a-Lago and cited existing protected airspace near seven presidential or vice-presidential residences as precedent.
- The September 2 Federal Register proposal would codify the current one-nautical-mile special-security-instruction footprint, which otherwise expires October 20, 2026. Outside a presidential temporary flight restriction, covered airport arrivals and departures would need an active flight plan, an approved approach or departure procedure, two-way air-traffic-control communication, authorization to enter and a discrete transponder code.
- Comments are due October 2. The published instrument is a proposed rule, not a final or operative permanent restriction; no realized security benefit, flight-delay measurement, noise finding or completed change to permanent airspace existed by cutoff.

## SIGNIFICANCE

A standing security area around a president's private residence can redistribute flight paths and operating burdens around a major airport while protecting against unauthorized aircraft. The exceptions and final boundaries will determine whether the proposal materially changes airport capacity, neighborhood exposure or security enforcement.

## GOALPOST / RESPONSE

The FAA and Secret Service say the proposal responds to adverse threat intelligence while preserving necessary airline and emergency access. Airport users and nearby communities may reasonably ask whether the restriction is proportionate and how flight paths, noise, delays and enforcement will change. A published final rule, supporting record, operational data, incursions, delays and community-impact evidence are the tests.

## MAYBE / THEREFORE

Maybe the tailored exceptions will provide added protection with little additional disruption, or permanent-style restrictions may shift meaningful costs to airport users and neighboring communities. Therefore the record confirms a federal airspace proposal and its stated security rationale—not a finalized permanent restriction, proof of a specific threat, a closed runway or measured safety and community outcomes.


## SOURCES

- [Reuters — FAA proposes special flight rules near Mar-a-Lago](https://www.reuters.com/world/us/faa-proposes-flight-restrictions-near-trump-palm-beach-airport-2026-09-01/) — independent reporting quoting FAA and Secret Service descriptions of the proposed airspace, security rationale and operating exceptions
- [Federal Register — proposed special flight rules near Mar-a-Lago](https://www.federalregister.gov/documents/2026/09/02/2026-17957/establishment-of-special-air-traffic-rules-in-the-vicinity-of-president-donald-j-trump-international) — primary notice of proposed rulemaking defining the proposed airspace, operating requirements and comment period

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
