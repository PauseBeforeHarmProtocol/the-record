# U.S. envoys complete Moscow and Kyiv talks without an announced peace breakthrough

**Entry ID:** NAT-2026-09-05-001
**Date:** September 5–6, 2026
**Checked:** 2026-09-06 12:02 PM EDT
**Evidence state:** Reuters and Associated Press observed the Kyiv visit and reported named public statements from U.S., Ukrainian and Russian officials; both meetings and limited pledges documented, proposal terms, concrete concessions, compliance and negotiated outcome unresolved
**Review state:** current-standard-reviewed

Witkoff and Kushner met Putin and Zelenskyy during a capital-specific strike pause, but no agreed framework, nationwide ceasefire or territorial settlement was announced.

## THE FACTS

- U.S. envoys Steve Witkoff and Jared Kushner arrived in Moscow on September 5 for talks aimed at reviving negotiations over Russia's war in Ukraine. Reuters and Associated Press reported that Russian envoy Kirill Dmitriev met them on arrival and that a meeting with Russian President Vladimir Putin was planned.
- President Trump said the envoys were carrying a proposal to end the war, but the United States had not disclosed its terms. Ukrainian President Volodymyr Zelenskyy said the envoys planned to travel to Kyiv on Sunday after the Moscow meetings; that visit had not occurred by cutoff.
- Kremlin spokesperson Dmitry Peskov said Putin ordered no strikes on Kyiv for three days beginning at midnight, tying the order to the planned U.S. visit. Zelenskyy said Ukraine was prepared to refrain from strikes on Moscow through Monday and expected reciprocal restraint regarding Kyiv.
- The pledges were limited to the two capitals rather than a nationwide ceasefire. Associated Press reported continued Russian attacks elsewhere in Ukraine, including five deaths at an industrial facility in Dnipropetrovsk, and additional casualties and damage during overnight strikes.
- Reuters reported that Russian and Ukrainian positions remained far apart. Russia continued to demand territorial concessions and abandonment of Ukraine's NATO ambitions, while Ukraine rejected terms it regarded as surrender. No agreed framework, verified compliance mechanism, territorial settlement, security guarantee or cessation of frontline combat was public by the prior cutoff.
- The envoys then held a closed-door meeting with Putin for more than three hours. Kremlin aide Yuri Ushakov called it constructive, frank and useful and said economic projects were also discussed, but neither side announced a major development. A White House official told Reuters that next steps would be announced in the coming weeks.
- On September 6, Witkoff and Kushner traveled to Kyiv and met Zelenskyy and senior Ukrainian officials in their first official visit to Ukraine as U.S. negotiators. Reuters and Associated Press observed the visit. After roughly three hours of initial talks and a working lunch, Witkoff called the discussion substantive, important and encouraging, while Zelenskyy said Ukraine sought a just peace and durable security guarantees.
- Further talks with British, French and German national-security advisers were planned later that day. Fighting continued outside the two capitals, including reported casualties in Ukraine and a Ukrainian strike on the Ryazan refinery. No proposal text, nationwide ceasefire, territorial settlement, security guarantee or verified compliance mechanism was announced by cutoff.

## SIGNIFICANCE

The completed meetings moved the initiative beyond an announced trip and gave both governments direct access to the same U.S. envoys during the limited strike pause. The absence of an announced breakthrough and continued combat outside the capitals sharply limit what the encouraging public descriptions establish.

## GOALPOST / RESPONSE

The administration presents Witkoff and Kushner as carrying a fresh peace proposal and says the Kyiv discussions were encouraging. Publication of the proposal, concrete next steps, verified adherence to the capital pause, a broader ceasefire, agreed territorial and security terms, and sustained reductions in attacks are the tests.

## MAYBE / THEREFORE

Maybe sequential talks in both capitals and a short strike pause create the basis for consequential negotiations, or they may repeat earlier diplomatic rounds that produced positive language without narrowing incompatible war aims. Therefore the record confirms completed Moscow and Kyiv meetings and the limited pledges—not a breakthrough, nationwide ceasefire, verified compliance, agreed peace framework or end to hostilities.


## SOURCES

- [Reuters — Witkoff and Kushner arrive in Moscow for Ukraine talks](https://www.reuters.com/world/europe/putins-envoy-dmitriev-meet-witkoff-kushner-upon-their-arrival-moscow-sources-say-2026-09-05/) — independent reporting on the U.S. mission, planned Putin and Zelenskyy meetings, undisclosed proposal and unresolved negotiating positions
- [Associated Press — Russia and Ukraine announce limited capitals strike pause during U.S. mission](https://apnews.com/article/russia-ukraine-war-kushner-witkoff-visit-36a991feaff241bb8f24857ac159202a) — independent reporting on the reciprocal capital-specific pause, envoys' arrival and continued fighting outside the arrangement
- [Reuters — U.S. envoys meet Zelenskyy in Kyiv after Moscow talks](https://www.reuters.com/business/aerospace-defense/us-envoys-make-first-kyiv-visit-amid-ukraine-war-peace-push-2026-09-06/) — independent reporting on the completed Moscow and Kyiv meetings, public descriptions and absence of an announced breakthrough
- [Associated Press — Witkoff and Kushner hold Kyiv talks after meeting Putin](https://apnews.com/article/russia-ukraine-war-witkoff-kushner-zelenskyy-putin-44bba3b57b480560d9f48dba7d28534e) — independent observed reporting on the envoys' first official Kyiv visit, the parties' statements and continuing fighting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
