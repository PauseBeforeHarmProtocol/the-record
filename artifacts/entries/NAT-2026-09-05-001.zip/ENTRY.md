# U.S. envoys complete Moscow and Kyiv talks; capital pause expires without ceasefire

**Entry ID:** NAT-2026-09-05-001
**Date:** September 5–8, 2026
**Checked:** 2026-09-08 11:58 AM EDT
**Evidence state:** Reuters and Associated Press reporting based on observed visits, named official statements and reported strike consequences; meetings, limited pledges and resumed attacks documented, while proposal terms, concessions and a negotiated outcome remain unresolved
**Review state:** current-standard-reviewed

Russia resumed missile and drone attacks on Kyiv after the U.S. envoys departed, while officials continued to praise ideas but announced no framework, ceasefire or territorial settlement.

## THE FACTS

- U.S. envoys Steve Witkoff and Jared Kushner arrived in Moscow on September 5 for talks aimed at reviving negotiations over Russia's war in Ukraine. Reuters and Associated Press reported that Russian envoy Kirill Dmitriev met them on arrival and that a meeting with Russian President Vladimir Putin was planned.
- President Trump said the envoys were carrying a proposal to end the war, but the United States had not disclosed its terms. Ukrainian President Volodymyr Zelenskyy said the envoys planned to travel to Kyiv on Sunday after the Moscow meetings; that visit had not occurred by cutoff.
- Kremlin spokesperson Dmitry Peskov said Putin ordered no strikes on Kyiv for three days beginning at midnight, tying the order to the planned U.S. visit. Zelenskyy said Ukraine was prepared to refrain from strikes on Moscow through Monday and expected reciprocal restraint regarding Kyiv.
- The pledges were limited to the two capitals rather than a nationwide ceasefire. Associated Press reported continued Russian attacks elsewhere in Ukraine, including five deaths at an industrial facility in Dnipropetrovsk, and additional casualties and damage during overnight strikes.
- Reuters reported that Russian and Ukrainian positions remained far apart. Russia continued to demand territorial concessions and abandonment of Ukraine's NATO ambitions, while Ukraine rejected terms it regarded as surrender. No agreed framework, verified compliance mechanism, territorial settlement, security guarantee or cessation of frontline combat was public by the prior cutoff.
- The envoys then held a closed-door meeting with Putin for more than three hours. Kremlin aide Yuri Ushakov called it constructive, frank and useful and said economic projects were also discussed, but neither side announced a major development. A White House official told Reuters that next steps would be announced in the coming weeks.
- On September 6, Witkoff and Kushner traveled to Kyiv and met Zelenskyy and senior Ukrainian officials in their first official visit to Ukraine as U.S. negotiators. Reuters and Associated Press observed the visit. After roughly three hours of initial talks and a working lunch, Witkoff called the discussion substantive, important and encouraging, while Zelenskyy said Ukraine sought a just peace and durable security guarantees.
- Further talks with British, French and German national-security advisers were planned later that day. Fighting continued outside the two capitals, including reported casualties in Ukraine and a Ukrainian strike on the Ryazan refinery. No proposal text, nationwide ceasefire, territorial settlement, security guarantee or verified compliance mechanism was announced by cutoff.
- After the envoys left Kyiv and the capital-specific pause expired, Russia resumed missile and drone attacks on September 8. Reuters and Associated Press reported at least five civilians killed and roughly 25 or more wounded in Kyiv, along with damage to residential and public buildings; strikes and casualties were also reported elsewhere in Ukraine and Russia.
- Zelenskyy said the U.S. envoys had presented decent or very good ideas and that further coordination was planned. That positive assessment did not include a published proposal, agreed territorial terms, security guarantees, verified nationwide pause or ceasefire; the renewed Kyiv attacks demonstrate that the visit-specific restraint did not become broader or durable.

## SIGNIFICANCE

The completed meetings gave both governments direct access to the same U.S. envoys, but the resumed Kyiv attacks provide an immediate effectiveness finding: the short capital pause ended on schedule and did not produce broader or durable restraint. Positive descriptions remain evidence of diplomatic intent, not agreement.

## GOALPOST / RESPONSE

The administration and Ukrainian officials describe the ideas and discussions as encouraging. Publication of the proposal, concrete negotiated steps, a broader verified ceasefire, agreed territorial and security terms, prisoner exchanges attributable to the talks, and sustained reductions in attacks are the tests.

## MAYBE / THEREFORE

Maybe the talks created useful private negotiating space despite immediate renewed fighting, or the praise may again precede no narrowing of incompatible war aims. Therefore the record confirms the meetings, the limited capitals pause and its expiration with renewed Kyiv attacks—not a breakthrough, durable ceasefire, verified compliance mechanism or agreed peace framework.


## SOURCES

- [Reuters — Witkoff and Kushner arrive in Moscow for Ukraine talks](https://www.reuters.com/world/europe/putins-envoy-dmitriev-meet-witkoff-kushner-upon-their-arrival-moscow-sources-say-2026-09-05/) — independent reporting on the U.S. mission, planned Putin and Zelenskyy meetings, undisclosed proposal and unresolved negotiating positions
- [Associated Press — Russia and Ukraine announce limited capitals strike pause during U.S. mission](https://apnews.com/article/russia-ukraine-war-kushner-witkoff-visit-36a991feaff241bb8f24857ac159202a) — independent reporting on the reciprocal capital-specific pause, envoys' arrival and continued fighting outside the arrangement
- [Reuters — U.S. envoys meet Zelenskyy in Kyiv after Moscow talks](https://www.reuters.com/business/aerospace-defense/us-envoys-make-first-kyiv-visit-amid-ukraine-war-peace-push-2026-09-06/) — independent reporting on the completed Moscow and Kyiv meetings, public descriptions and absence of an announced breakthrough
- [Associated Press — Witkoff and Kushner hold Kyiv talks after meeting Putin](https://apnews.com/article/russia-ukraine-war-witkoff-kushner-zelenskyy-putin-44bba3b57b480560d9f48dba7d28534e) — independent observed reporting on the envoys' first official Kyiv visit, the parties' statements and continuing fighting
- [Reuters — Russia resumes Kyiv strikes after U.S. envoys leave](https://www.reuters.com/world/europe/russian-ballistic-missiles-hit-kyiv-us-envoys-leave-2026-09-08/) — independent reporting on the expiration of the capital-specific pause, renewed attacks and reported casualties
- [Associated Press — Kyiv attacked after U.S. envoys present peace ideas](https://apnews.com/article/russia-ukraine-war-kyiv-missiles-drones-attacks-fd634a6786462bc95b7dfefc97d2331e) — independent reporting on renewed strikes, casualties and Zelenskyy's assessment that U.S. ideas had not produced a breakthrough

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
