# U.S. envoys arrive in Moscow as Russia and Ukraine announce a limited capitals strike pause

**Entry ID:** NAT-2026-09-05-001
**Date:** September 5, 2026
**Checked:** 2026-09-05 12:00 PM EDT
**Evidence state:** Reuters and Associated Press reporting based on observed arrival and named public statements from Trump, Zelenskyy and the Kremlin; diplomatic mission and limited pledges documented, proposal terms, compliance and negotiated outcome unresolved
**Review state:** current-standard-reviewed

Witkoff and Kushner began a new diplomatic mission, while Moscow and Kyiv separately pledged a three-day pause in strikes on each other's capitals; no broader ceasefire or peace agreement existed by cutoff.

## THE FACTS

- U.S. envoys Steve Witkoff and Jared Kushner arrived in Moscow on September 5 for talks aimed at reviving negotiations over Russia's war in Ukraine. Reuters and Associated Press reported that Russian envoy Kirill Dmitriev met them on arrival and that a meeting with Russian President Vladimir Putin was planned.
- President Trump said the envoys were carrying a proposal to end the war, but the United States had not disclosed its terms. Ukrainian President Volodymyr Zelenskyy said the envoys planned to travel to Kyiv on Sunday after the Moscow meetings; that visit had not occurred by cutoff.
- Kremlin spokesperson Dmitry Peskov said Putin ordered no strikes on Kyiv for three days beginning at midnight, tying the order to the planned U.S. visit. Zelenskyy said Ukraine was prepared to refrain from strikes on Moscow through Monday and expected reciprocal restraint regarding Kyiv.
- The pledges were limited to the two capitals rather than a nationwide ceasefire. Associated Press reported continued Russian attacks elsewhere in Ukraine, including five deaths at an industrial facility in Dnipropetrovsk, and additional casualties and damage during overnight strikes.
- Reuters reported that Russian and Ukrainian positions remained far apart. Russia continued to demand territorial concessions and abandonment of Ukraine's NATO ambitions, while Ukraine rejected terms it regarded as surrender. No agreed framework, verified compliance mechanism, territorial settlement, security guarantee or cessation of frontline combat was public by cutoff.

## SIGNIFICANCE

The envoys' arrival converted an announced trip into an active diplomatic mission and coincided with reciprocal, capital-specific strike restraints. The pause may reduce immediate risk to Kyiv and Moscow during the talks, but it does not stop the broader war or establish progress toward an agreement.

## GOALPOST / RESPONSE

The administration presents Witkoff and Kushner as carrying a concrete peace proposal and says the mission may produce progress. Publication of the proposal, completed meetings in Moscow and Kyiv, verified adherence to the capital pause, a broader ceasefire, agreed territorial and security terms, and sustained reductions in attacks are the tests.

## MAYBE / THEREFORE

Maybe the short pause creates protected space for consequential diplomacy, or it may be a narrow accommodation for the envoys that leaves incompatible war aims and combat unchanged. Therefore the record confirms the U.S. mission and reciprocal capital-specific pledges—not a nationwide ceasefire, verified compliance, agreed peace framework or end to hostilities.


## SOURCES

- [Reuters — Witkoff and Kushner arrive in Moscow for Ukraine talks](https://www.reuters.com/world/europe/putins-envoy-dmitriev-meet-witkoff-kushner-upon-their-arrival-moscow-sources-say-2026-09-05/) — independent reporting on the U.S. mission, planned Putin and Zelenskyy meetings, undisclosed proposal and unresolved negotiating positions
- [Associated Press — Russia and Ukraine announce limited capitals strike pause during U.S. mission](https://apnews.com/article/russia-ukraine-war-kushner-witkoff-visit-36a991feaff241bb8f24857ac159202a) — independent reporting on the reciprocal capital-specific pause, envoys' arrival and continued fighting outside the arrangement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
