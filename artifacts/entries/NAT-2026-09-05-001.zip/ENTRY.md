# U.S.-mediated Ukraine talks advance to a dated localized Oleshky pause

**Entry ID:** NAT-2026-09-05-001
**Date:** September 5–October 23, 2026
**Checked:** 2026-10-23 6:01 PM EDT
**Evidence state:** official announcement plus Reuters reporting with named Russian and Ukrainian confirmation; October 27 start and humanitarian tasks announced, implementation and effects unresolved
**Review state:** current-standard-reviewed

Russia and Ukraine specified an October 27 start for a localized humanitarian pause and announced November technical talks; implementation, compliance and any wider ceasefire remained unresolved.

## THE FACTS

- U.S. envoys Steve Witkoff and Jared Kushner arrived in Moscow on September 5 for talks aimed at reviving negotiations over Russia's war in Ukraine. Reuters and Associated Press reported that Russian envoy Kirill Dmitriev met them on arrival and that a meeting with Russian President Vladimir Putin was planned.
- President Trump said the envoys were carrying a proposal to end the war, but the United States had not disclosed its terms. Ukrainian President Volodymyr Zelenskyy said the envoys planned to travel to Kyiv on Sunday after the Moscow meetings; that visit had not occurred by cutoff.
- Kremlin spokesperson Dmitry Peskov said Putin ordered no strikes on Kyiv for three days beginning at midnight, tying the order to the planned U.S. visit. Zelenskyy said Ukraine was prepared to refrain from strikes on Moscow through Monday and expected reciprocal restraint regarding Kyiv.
- The pledges were limited to the two capitals rather than a nationwide ceasefire. Associated Press reported continued Russian attacks elsewhere in Ukraine, including five deaths at an industrial facility in Dnipropetrovsk, and additional casualties and damage during overnight strikes.
- Reuters reported that Russian and Ukrainian positions remained far apart. Russia continued to demand territorial concessions and abandonment of Ukraine's NATO ambitions, while Ukraine rejected terms it regarded as surrender. No agreed framework, verified compliance mechanism, territorial settlement, security guarantee or cessation of frontline combat was public by the prior cutoff.
- The envoys then held a closed-door meeting with Putin for more than three hours. Kremlin aide Yuri Ushakov called it constructive, frank and useful and said economic projects were also discussed, but neither side announced a major development. A White House official told Reuters that next steps would be announced in the coming weeks.
- On September 6, Witkoff and Kushner traveled to Kyiv and met Zelenskyy and senior Ukrainian officials in their first official visit to Ukraine as U.S. negotiators. Reuters and Associated Press observed the visit. After roughly three hours of initial talks and a working lunch, Witkoff called the discussion substantive, important and encouraging, while Zelenskyy said Ukraine sought a just peace and durable security guarantees.
- Further talks with British, French and German national-security advisers were planned later that day. Fighting continued outside the two capitals, including reported casualties in Ukraine and a Ukrainian strike on the Ryazan refinery. No proposal text, nationwide ceasefire, territorial settlement, security guarantee or verified compliance mechanism was announced by cutoff.
- After the envoys left Kyiv and the capital-specific pause expired, Russia resumed missile and drone attacks on September 8. Reuters and Associated Press reported at least five civilians killed and roughly 25 or more wounded in Kyiv, along with damage to residential and public buildings; strikes and casualties were also reported elsewhere in Ukraine and Russia.
- Zelenskyy said the U.S. envoys had presented decent or very good ideas and that further coordination was planned. That positive assessment did not include a published proposal, agreed territorial terms, security guarantees, verified nationwide pause or ceasefire; the renewed Kyiv attacks demonstrate that the visit-specific restraint did not become broader or durable.
- On October 21, after another Witkoff-Putin meeting, Putin agreed to resume U.S.-mediated technical talks with Ukraine, potentially in Abu Dhabi on or after November 10. Reuters reported that the proposed round would focus on postwar security guarantees, while the Kremlin said it was not fully satisfied and the parties' war aims remained far apart. The announced future talks did not establish a ceasefire, accepted framework or implemented security guarantee.
- On October 23, the White House announced that Russia and Ukraine had agreed to a temporary localized pause in military activity around Oleshky to permit humanitarian aid and civilian evacuation. A named Ukrainian negotiator confirmed that a ceasefire and humanitarian corridors were forthcoming, and the Kremlin later confirmed the agreement.
- The White House said the pause would begin October 29 and credited mediation by First Lady Melania Trump, but the Kremlin said the militaries were still working out implementation dates. By cutoff the pause was agreed and announced, not yet implemented or independently measured; it did not extend to a nationwide ceasefire or settle broader war terms.
- Later on October 23, Reuters reported that Russian and Ukrainian officials both specified October 27 as the start date. Russian General Staff chief Valery Gerasimov said the pause would begin at 4 a.m. local time, while Ukraine's ombudsman said the operation would include road demining, food deliveries and evacuations. November technical talks were also announced. These details superseded the earlier public date conflict, but the pause still had not begun by cutoff.

## SIGNIFICANCE

The parties moved from a mutually confirmed but date-disputed announcement to a shared operational start date and named humanitarian tasks. The agreement remains geographically narrow and unimplemented at cutoff; it is not a nationwide ceasefire or peace settlement.

## GOALPOST / RESPONSE

The administration credits its mediation and says the pause will enable aid and evacuation. The tests are the October 27 start, safe demining and corridors, delivered food, completed evacuations, compliance by both militaries, November talks and any expansion beyond Oleshky.

## MAYBE / THEREFORE

Maybe a dated, task-specific pause protects civilians and builds confidence for wider negotiations, or fighting and logistics may still prevent effective implementation. Therefore the record confirms an agreed October 27 start and announced humanitarian operations—not yet an implemented, durable or nationwide ceasefire.


## SOURCES

- [Reuters — Witkoff and Kushner arrive in Moscow for Ukraine talks](https://www.reuters.com/world/europe/putins-envoy-dmitriev-meet-witkoff-kushner-upon-their-arrival-moscow-sources-say-2026-09-05/) — independent reporting on the U.S. mission, planned Putin and Zelenskyy meetings, undisclosed proposal and unresolved negotiating positions
- [Associated Press — Russia and Ukraine announce limited capitals strike pause during U.S. mission](https://apnews.com/article/russia-ukraine-war-kushner-witkoff-visit-36a991feaff241bb8f24857ac159202a) — independent reporting on the reciprocal capital-specific pause, envoys' arrival and continued fighting outside the arrangement
- [Reuters — U.S. envoys meet Zelenskyy in Kyiv after Moscow talks](https://www.reuters.com/business/aerospace-defense/us-envoys-make-first-kyiv-visit-amid-ukraine-war-peace-push-2026-09-06/) — independent reporting on the completed Moscow and Kyiv meetings, public descriptions and absence of an announced breakthrough
- [Associated Press — Witkoff and Kushner hold Kyiv talks after meeting Putin](https://apnews.com/article/russia-ukraine-war-witkoff-kushner-zelenskyy-putin-44bba3b57b480560d9f48dba7d28534e) — independent observed reporting on the envoys' first official Kyiv visit, the parties' statements and continuing fighting
- [Reuters — Russia resumes Kyiv strikes after U.S. envoys leave](https://www.reuters.com/world/europe/russian-ballistic-missiles-hit-kyiv-us-envoys-leave-2026-09-08/) — independent reporting on the expiration of the capital-specific pause, renewed attacks and reported casualties
- [Associated Press — Kyiv attacked after U.S. envoys present peace ideas](https://apnews.com/article/russia-ukraine-war-kyiv-missiles-drones-attacks-fd634a6786462bc95b7dfefc97d2331e) — independent reporting on renewed strikes, casualties and Zelenskyy's assessment that U.S. ideas had not produced a breakthrough
- [Reuters — Putin agrees to resume U.S.-mediated technical Ukraine talks](https://www.reuters.com/world/europe/putin-hosts-trump-envoy-new-ukraine-peace-talks-frees-us-citizen-held-russia-2026-10-21/) — independent reporting on the announced future technical talks, security-guarantee focus and unresolved war aims
- [White House — localized Oleshky ceasefire announcement](https://www.whitehouse.gov/briefings-statements/2026/10/first-lady-melania-trump-secures-ceasefire-between-russia-and-ukraine-localized-to-oleshky/) — official statement announcing a temporary localized pause for aid and evacuation
- [Reuters — Ukraine confirms forthcoming Oleshky humanitarian pause](https://www.reuters.com/world/europe/melania-trump-secures-oleshky-ceasefire-between-russia-ukraine-white-house-says-2026-10-23/) — independent reporting with named Ukrainian confirmation of the localized agreement
- [Reuters — Kremlin confirms Oleshky agreement while timing remains under negotiation](https://www.reuters.com/world/europe/kremlin-confirms-oleshky-ceasefire-says-working-with-ukraine-evacuation-timing-2026-10-23/) — independent reporting with named Russian confirmation and implementation caveat
- [Reuters — Russia and Ukraine specify October 27 Oleshky pause and November talks](https://www.reuters.com/world/europe/russia-ukraine-agree-ceasefire-embattled-town-hold-peace-talks-next-month-2026-10-23/) — independent reporting with named Russian and Ukrainian implementation details

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
