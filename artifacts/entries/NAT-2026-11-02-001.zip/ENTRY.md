# Labor publishes final PBM compensation-disclosure rule

**Entry ID:** NAT-2026-11-02-001
**Date:** October 29–November 2, 2026
**Checked:** 2026-11-02 12:07 AM EST
**Evidence state:** official Federal Register final rule and Department of Labor release, corroborated by independent health-policy reporting; finalization, publication, scope and future dates are documented, while compliance, litigation and cost outcomes remain prospective
**Review state:** current-standard-reviewed

The rule requires large self-insured employer plans’ pharmacy-benefit vendors to disclose compensation, spread pricing and rebate flows, but its savings projection remains unmeasured.

## THE FACTS

- The Department of Labor finalized its pharmacy benefit manager disclosure rule on October 29, and the Federal Register published it on November 2 as 91 FR 69092–69196 (RIN 1210-AB37). The regulation is effective January 4, 2027 and applies to plan years beginning on or after July 1, 2027; publication and finalization are complete, but the requirements are not yet applicable.
- The rule uses ERISA’s service-provider prohibited-transaction exemption to require covered PBMs, affiliated brokers and consultants serving large self-insured employer group health plans to disclose direct and indirect compensation. The required information includes manufacturer rebates and payments, spread-pricing compensation, pharmacy recoupments and other arrangements; plans receive disclosures before contracting or renewal, continuing reports and at least annual audit rights.
- The Labor Department projects as much as $22 billion in undiscounted prescription-drug savings over ten years, reasoning that employers can use compensation data to negotiate. That figure is the agency’s prospective regulatory estimate, not measured savings, and the rule does not itself prove that lower retained PBM compensation or lower participant costs will result.
- Independent reporting says the final rule covers fewer plans than the original proposal and does not directly cap PBM prices, spread compensation or retained manufacturer rebates. The Pharmaceutical Care Management Association called the requirements duplicative and burdensome and warned that they could raise costs or reduce competition; those are attributed industry claims, not established outcomes.

## SIGNIFICANCE

The final rule creates a new federal disclosure and audit framework for a consequential part of employer drug spending, while delaying applicability until mid-2027. Its accountability test is whether plans receive usable, accurate compensation data and whether competition, retained fees and participant costs change after compliance begins—not whether a model projects savings before implementation.

## GOALPOST / RESPONSE

The Labor Department says compensation transparency will let plan fiduciaries assess reasonableness, negotiate harder and lower costs, and it presents the rule as complementary to Congress’s 2026 PBM reporting law. The PBM trade association says a second system is redundant, costly and especially burdensome for smaller firms. Both positions are preserved; neither substitutes for post-implementation cost and compliance evidence.

## MAYBE / THEREFORE

Maybe the disclosures and audit rights will improve bargaining and expose compensation that plans could not previously evaluate; maybe compliance costs, market concentration or redesigned fee structures will blunt the benefit. Therefore the record establishes a finalized and published transparency rule with future effective and applicability dates—not implementation, verified savings, reduced drug prices or a finding that every disclosed payment is improper.


## SOURCES

- [Federal Register — Improving Transparency Into Pharmacy Benefit Manager Fee Disclosure, final rule](https://www.govinfo.gov/content/pkg/FR-2026-11-02/html/2026-22306.htm) — primary final rule; 91 FR 69092–69196, RIN 1210-AB37
- [Department of Labor — PBM compensation-disclosure final rule announcement](https://www.dol.gov/index.php/newsroom/releases/ebsa/ebsa20261029) — primary agency finalization announcement and projected-impact explanation
- [Axios — New mandates force PBMs to disclose business dealings](https://www.axios.com/2026/10/30/new-mandates-force-pbms-disclose-business-dealings) — independent reporting on final-rule scope, limits and industry response
- [Healthcare Dive — Labor Department finalizes sweeping PBM disclosure rule](https://www.healthcaredive.com/news/pbm-transparency-final-rule-labor-department-employer/873089/) — independent reporting on final-rule requirements, compliance costs and competing responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
