# Labor Department suspends eight firms from permanent labor certification

**Entry ID:** NAT-2026-10-08-001
**Date:** October 8, 2026
**Checked:** 2026-10-08 12:00 PM EDT
**Evidence state:** official White House event listing and named administration announcement independently reported by Reuters and AP; suspension announced as operative, underlying allegations, scope, duration and review unresolved
**Review state:** current-standard-reviewed

Officials said new and pending PERM applications involving Microsoft, Adobe and six large IT services firms would not be processed; the fraud allegations are not adjudicated findings.

## THE FACTS

- Vice President JD Vance and Labor Secretary Keith Sonderling announced that the government was suspending Microsoft, Adobe, Cognizant, Infosys, Tata, Wipro, HCL and Capgemini from the permanent labor certification program. Reuters and Associated Press independently reported the White House news conference.
- Sonderling said the Labor Department would accept no new and process no pending permanent labor certification applications involving the eight firms. The announcement describes an immediate administrative suspension; no inspected company-specific order, duration, appeal procedure or total number of affected applications was public by cutoff.
- PERM certification is generally a prerequisite for an employer to petition for many employment-based green cards and requires a showing that qualified, willing and available U.S. workers are not available for the job. The announced suspension concerns labor certification; it does not by itself revoke existing visas or green cards.
- Vance alleged that Microsoft and outsourcing firms had abused visa programs to replace or undercut U.S. workers. Those are administration allegations and a stated enforcement rationale, not adjudicated fraud findings. Reuters and AP reported no immediate Microsoft response by cutoff.

## SIGNIFICANCE

The suspension moves the administration's visa-fraud campaign from general directives into company-specific processing consequences that can delay or block employment-based permanent-residence sponsorship. Its reach and legality depend on formal notices, case handling and review rights that were not yet public.

## GOALPOST / RESPONSE

The administration says the action protects American workers from fraudulent or abusive sponsorship. Company-specific notices, affected-case counts, factual findings, appeals, court review, employer responses and later hiring and wage evidence are the tests.

## MAYBE / THEREFORE

Maybe targeted suspensions will deter labor-certification abuse and protect domestic applicants, or broad processing freezes may affect compliant petitions before wrongdoing is established. Therefore officials announced and began a company-specific processing suspension; the record does not establish fraud findings, permanent exclusion, revoked status or measured labor-market effects.


## SOURCES

- [White House Live — Vice President JD Vance Holds Press Conference on Fighting Visa Fraud](https://www.whitehouse.gov/live/) — official event listing
- [Reuters — U.S. suspends Microsoft and major IT firms from key green-card program](https://www.reuters.com/business/us-suspending-permanent-residency-program-for-microsoft-vance-says-2026-10-08/) — independent reporting
- [AP — Microsoft suspended from green-card program as administration alleges fraud](https://apnews.com/article/h1b-visa-program-vance-microsoft-e7b3a407f822702b269ee277d21343ea) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
