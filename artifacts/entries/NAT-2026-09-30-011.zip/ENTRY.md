# Court stays mass immigration-fine policies while challenge proceeds

**Entry ID:** NAT-2026-09-30-011
**Date:** September 30, 2026 — recovered in October 6 review
**Checked:** 2026-10-06 5:57 AM EDT
**Evidence state:** primary signed 20-page district-court opinion and order plus independent Reuters reporting; preliminary stay granted, final merits, appeal and implementation consequences unresolved
**Review state:** current-standard-reviewed

The preliminary order blocks the challenged expedited process and blanket assessments; it does not erase Congress's fine statutes or finally decide the case.

## THE FACTS

- Judge George O'Toole's September 30 opinion in Maria L. v. Mullin, No. 25-13471, granted the plaintiffs' motion for a stay under Section 705 of the Administrative Procedure Act. The court found a likelihood of success against the June 2025 interim final rule and the alleged blanket policy of assessing fines without individualized findings of willful or voluntary failure to depart.
- The opinion found that the agencies did not use notice-and-comment rulemaking and that the asserted foreign-affairs and procedural-rule exceptions were unlikely to apply. It also identified substantive effects including direct penalty decisions without a prior notice of intent, a response period shortened from 30 to 15 days, and elimination of an in-person interview and some review provisions.
- The named plaintiffs had been assessed hundreds of thousands of dollars and about $1.82 million. The opinion cited record evidence that more than 65,000 penalties totaling roughly $36 billion had been assessed; Reuters separately reported DHS's July statement that more than 103,000 fines totaling about $84 billion had been issued. The different figures reflect different records and observation times and are not treated as one verified current total.
- The government argued that monetary harm could later be remedied and that a stay would impede enforcement. The court concluded the fines and collateral collection consequences could push the plaintiffs into insolvency and said the government could still use the procedures that predated the challenged rule.
- The stay is preliminary relief, not a final judgment vacating the underlying statutory fine authorities, a merits ruling on every constitutional claim or a permanent bar on individually supported penalties. Reuters reported no immediate DHS comment. This is a prior-window recovery keyed to the signed September 30 order, not the October 6 publication date of later reporting.

## SIGNIFICANCE

The order pauses a mass penalty process associated with tens of billions of dollars in agency assessments and requires the government to confront individualized statutory elements and rulemaking procedure before collection can proceed under the challenged approach.

## GOALPOST / RESPONSE

The administration says the streamlined process deters unlawful presence and speeds enforcement of congressionally authorized fines; in court it argued monetary relief remained available later. The final merits judgment, any appeal or stay, revised rulemaking, individualized findings, collection records and due-process outcomes are the tests.

## MAYBE / THEREFORE

Maybe the agencies can prevail on appeal or adopt lawful procedures that support individualized penalties, or the court may ultimately set the policies aside. Therefore the record establishes a preliminary APA stay of the challenged rule, blanket policy and associated assessments—not repeal of the statutes, cancellation of every fine or final resolution of the lawsuit.


## SOURCES

- [D. Mass. — Maria L. v. Mullin opinion and order staying immigration-fine policies](https://fingfx.thomsonreuters.com/gfx/legaldocs/xmvjwbkwlpr/10052026fines.pdf) — primary 20-page court opinion and order (Reuters-hosted copy of docket document 113)
- [Reuters — court stays Trump administration migrant-fine policies](https://www.reuters.com/legal/government/us-judge-blocks-trump-policy-fining-migrants-up-18-million-2026-10-06/) — independent court reporting linked to the signed opinion

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
