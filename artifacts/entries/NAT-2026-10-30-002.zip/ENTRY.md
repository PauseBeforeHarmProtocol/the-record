# Judge temporarily restores notice and rescheduling protections for children’s asylum interviews

**Entry ID:** NAT-2026-10-30-002
**Date:** October 30, 2026
**Checked:** 2026-10-31 6:02 AM EDT
**Evidence state:** original filed ECF54 inspected for operative scope and government arguments; Reuters corroboration; ordered interim APA stay/TRO, compliance and final merits unverified
**Review state:** current-standard-reviewed

Original order recovered from the prior queue: interim relief, not an asylum grant or final merits judgment.

## THE FACTS

- On October 30, U.S. District Judge Brendan A. Hurson granted a temporary restraining order and Administrative Procedure Act stay in The Door v. Edlow, No. 8:26-cv-04326-BAH. The order stays USCIS policies shortening notice for unaccompanied children’s asylum interviews and requiring exceptional circumstances to reschedule. Reuters independently reported the temporary block.
- The order requires USCIS to generate written interview notices at least 21 days before the interview and promptly send them to applicants and counsel. It restores rescheduling once as a matter of course and again for good cause, with consideration of counsel’s availability, preparation and evidence gathering, the child’s ability to attend, and inadequate notice. Defendants must report compliance steps within 48 hours.
- The court found likely success on contrary-to-law claims concerning existing evidence-submission regulations, children’s specialized procedural needs and access to counsel. Those are preliminary findings, not a final adjudication of every challenge. The opinion expressly does not address the separate detained-docket deadline policy because the TRO motion did not seek to restrain it.
- The order expires at noon November 13 unless the court orders otherwise. It does not grant asylum, decide an individual child’s eligibility or establish completed agency compliance. No compliance report or subsequent appellate order was inspected in this run.

## SIGNIFICANCE

Interview scheduling can determine whether children and their lawyers have a practical opportunity to prepare and submit evidence. The court temporarily restores procedural safeguards while litigation continues; protection on paper and actual agency compliance remain separate questions.

## GOALPOST / RESPONSE

As summarized in the original opinion, the government defended USCIS’s operational judgment in scheduling, argued that child-sensitive interviewing already addressed specialized needs, disputed reviewable final agency action, and invoked the statutory exceptional-circumstances standard for missed interviews. The court distinguished advance rescheduling from sanctions for failure to appear and found substantive sensitivity insufficient without procedural accommodation. Prompt adjudication remains a legitimate objective, but must satisfy the governing protections.

## MAYBE / THEREFORE

Maybe faster scheduling reduces backlogs and a later court accepts parts of the government’s legal defense. Therefore this record establishes only the temporary stay and ordered restoration of prior procedures; compliance evidence, any extension or appeal, and the merits decision must be checked before claiming durable relief or measured benefits.


## SOURCES

- [D. Maryland — The Door v. Edlow, ECF 54 temporary restraining order and APA stay](https://media.nilc.org/2026/10/Temporary-Restraining-Order.pdf) — primary filed order, No. 8:26-cv-04326-BAH; operative pp.20–21 and analysis pp.11–14,17 inspected; counsel-hosted original
- [Reuters — Judge temporarily blocks fast-tracked children’s asylum interview policies](https://www.reuters.com/legal/government/us-judge-blocks-trump-policies-fast-tracking-childrens-asylum-cases-2026-10-30/) — independent court reporting; retrieved report text corroborates temporary relief and November 13 expiration, not implementation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
