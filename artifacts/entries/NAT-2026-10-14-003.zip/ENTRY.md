# Social Security sets automatic 3.6% cost-of-living adjustment for 2027

**Entry ID:** NAT-2026-10-14-003
**Date:** October 14, 2026
**Checked:** 2026-10-14 11:55 AM EDT
**Evidence state:** primary SSA benefit and threshold determination plus independent Reuters context; adjustment announced under statutory formula, individual net effects unresolved
**Review state:** current-standard-reviewed

The statutory CPI-W formula raises benefits for about 76 million people; the result is an automatic benefit determination, not a discretionary presidential increase.

## THE FACTS

- The Social Security Administration announced a 3.6% cost-of-living adjustment for 2027. The increase begins with January 2027 benefits for nearly 72 million Social Security beneficiaries and with December 31, 2026 payments for about 7.3 million Supplemental Security Income recipients; some people receive both programs.
- SSA explains that federal law sets the adjustment from the increase in the Consumer Price Index for Urban Wage Earners and Clerical Workers between the relevant third-quarter averages. Reuters reported that CPI-W rose 3.9% over the year in September and averaged about a 3.6% increase across July, August and September.
- SSA also set the 2027 maximum amount of earnings subject to Social Security tax at $192,300, the earnings limit for workers below full retirement age at $25,560, and the limit for people reaching full retirement age during 2027 at $67,920. These are related statutory thresholds, not the monthly benefit amount for every recipient.
- The 2027 COLA is higher than the 2.8% adjustment for 2026. Because Medicare premium changes were not yet available on the inspected SSA page, the announcement does not establish every beneficiary's net payment increase or whether the adjustment will fully offset a particular household's costs.

## SIGNIFICANCE

The determination changes federal cash benefits for roughly 76 million people and related payroll-tax and earnings thresholds. It also mechanically transmits measured inflation into federal outlays, while individual purchasing power depends on personal spending patterns, taxes, premiums and other deductions.

## GOALPOST / RESPONSE

SSA says the automatic formula is intended to protect benefit purchasing power from inflation. Tests include correct notices and payments, final Medicare premiums and deductions, the accuracy of the CPI-W calculation, beneficiary-level net payments and subsequent real purchasing power.

## MAYBE / THEREFORE

Maybe the 3.6% adjustment broadly preserves purchasing power, or beneficiaries concentrated in faster-rising housing, energy or medical costs may still fall behind after deductions. Therefore SSA set the statutory 2027 adjustment and thresholds—not a discretionary Trump benefit increase or proof that every recipient will be 3.6% better off in real terms.


## SOURCES

- [SSA — 2027 Social Security and SSI cost-of-living adjustment](https://www.ssa.gov/cola/) — primary agency benefit, tax-base and earnings-limit determination
- [Reuters — 3.6% Social Security increase for 2027](https://www.reuters.com/world/us/us-retirees-receive-36-social-security-increase-2027-2026-10-14/) — independent reporting on statutory benefit adjustment and CPI-W basis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
