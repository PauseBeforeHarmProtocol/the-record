# FTC sues to block Covetrus's $3.5 billion acquisition of MWI

**Entry ID:** NAT-2026-11-13-008
**Date:** November 13, 2026
**Checked:** 2026-11-14 12:08 AM EST
**Evidence state:** Primary FTC filing announcement, independent Reuters reporting and the transaction party's public response; lawsuit filed, merits and remedy unresolved
**Review state:** current-standard-reviewed

The federal complaint, joined by 13 state attorneys general, alleges that combining the two veterinary-supply distributors would reduce competition; no court has yet resolved the merits or blocked the deal permanently.

## THE FACTS

- The Federal Trade Commission filed a federal lawsuit seeking to block Covetrus Inc. and its owners, Clayton, Dubilier & Rice LLC and TPG Inc., from acquiring MWI Veterinary Supply Inc. from Cencora Inc. in a transaction valued at $3.5 billion.
- The complaint alleges that Covetrus and MWI are each other's closest competitors in veterinary-clinic distribution and that the combination would increase concentration, reduce price and service competition and raise costs for clinics and pet owners. Those are filed allegations, not adjudicated findings.
- The Commission voted 2-0 to authorize staff to seek a permanent injunction. The complaint was filed in the U.S. District Court for the Southern District of New York and joined by the attorneys general of Arizona, Arkansas, California, Colorado, Maine, Michigan, Minnesota, Nebraska, New York, North Carolina, Ohio, Oregon and Texas.
- Covetrus said the FTC relies on a narrow and outdated view of the market, argued that clinics can buy through manufacturers, other distributors, online marketplaces and retailers, and said it is prepared to defend the transaction in court.
- The filing begins an enforcement case; it does not itself constitute a final injunction, an adjudication that the transaction violates antitrust law or a completed divestiture. The acquisition therefore remains proposed and contested at cutoff.

## SIGNIFICANCE

The case is a formal national antitrust challenge involving the two largest distributors identified by the agency in a market that supplies veterinary clinics. Its consequence depends on judicial findings and relief, so the filing should not be described as a completed block.

## GOALPOST / RESPONSE

The enforcement result can be evaluated through the court's market-definition and competitive-effects findings, any injunction or settlement, transaction status, clinic purchasing conditions, prices and service levels. The FTC's allegations and Covetrus's claimed alternative channels remain competing positions until tested against evidence.

## MAYBE / THEREFORE

Maybe the merger would eliminate unusually strong head-to-head competition and raise clinic costs, or the broader supply channels identified by Covetrus may constrain the combined company. Therefore the record establishes a filed FTC and multistate challenge—not a merits judgment, a permanent block or proof of future price effects.


## SOURCES

- [FTC — complaint challenging Covetrus acquisition of MWI Veterinary Supply](https://www.ftc.gov/news-events/news/press-releases/2026/11/ftc-sues-block-veterinary-supplies-distributor-covetruss-35-billion-acquisition-rival-mwi) — primary enforcement announcement identifying the filed complaint, parties, transaction, alleged markets, vote, court and state plaintiffs
- [Reuters — FTC sues to block Cencora's $3.5 billion sale of MWI to Covetrus](https://www.investing.com/news/stock-market-news/us-ftc-sues-to-block-cencoras-35-billion-sale-of-veterinary-unit-to-covetrus-5026197) — independent reporting on the filed antitrust challenge and alleged consumer-cost consequences
- [Covetrus — response to FTC challenge of proposed MWI merger](https://www.prnewswire.com/news-releases/covetrus-issues-statement-on-ftc-decision-to-challenge-proposed-merger-with-mwi-animal-health-302939180.html) — transaction party response disputing the FTC market definition and stating an intent to defend the transaction

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
