# Hegseth announces signed U.S.–Venezuela military-cooperation agreement

**Entry ID:** NAT-2026-11-18-003
**Date:** November 18, 2026
**Checked:** 2026-11-18 6:21 PM EST
**Evidence state:** independent Associated Press and Reuters reporting on Hegseth's public announcement and Venezuelan state-television footage; signed agreement announced, with text and implementation details unavailable
**Review state:** current-standard-reviewed

Defense Secretary Pete Hegseth announced that the United States and Venezuela signed a military-cooperation agreement covering training and intelligence sharing; the agreement text, authorities, funding and implementation schedule were not published in the material reviewed.

## THE FACTS

- Associated Press and Reuters reported that Defense Secretary Pete Hegseth, during a November 18 visit to Caracas, said the United States and Venezuela had signed or reached a new agreement to reestablish military cooperation.
- Hegseth said the arrangement covers joint training, intelligence sharing and other military cooperation. He also referred to more defense equipment and capabilities, but the inspected sources did not publish the agreement text, a detailed equipment list, a timetable or implementing orders.
- Venezuelan acting President Delcy Rodríguez said the cooperation would strengthen military training and help confront common threats. Venezuelan state television showed the two officials together; the broadcast establishes what was said and shown, not whether either government's broader claims are independently correct.
- Hegseth framed the partnership as supporting action against drug-trafficking groups and regional security. No inspected source established appropriations, obligations, transfers, deployed joint operations, completed training, an oversight mechanism or measured outcomes by cutoff.

## SIGNIFICANCE

A signed framework restarting training and intelligence ties is a material shift in the U.S. relationship with Venezuela and could affect force assistance, intelligence handling, counter-drug operations and congressional oversight. Publicly available details remain sparse, so the record distinguishes the announced agreement from any funded or operational implementation.

## GOALPOST / RESPONSE

The administration says renewed cooperation will support joint action against drug trafficking, professionalize Venezuela's military and protect both countries from common threats. The tests are publication of the agreement and legal authorities, congressional notifications and appropriations, named commands and oversight, training and intelligence-sharing records, equipment transfers, human-rights safeguards, operational results and independently measured security outcomes.

## MAYBE / THEREFORE

Maybe the signed framework produces bounded, accountable cooperation against shared threats, or opaque implementation may expand U.S. entanglement and support forces with unresolved accountability risks. Therefore the evidence establishes an announced signed military-cooperation agreement and its stated scope—not published terms, funded implementation, completed transfers, joint operations or measured results.


## SOURCES

- [US and Venezuela sign a deal to reestablish military ties, Hegseth says in visit to Caracas](https://apnews.com/article/e02dd6173e575c644a37dd417d84296d) — independent reporting on Hegseth's public announcement, stated agreement scope and Venezuelan state-television footage
- [Hegseth, in Caracas, announces U.S.-Venezuela military partnership agreement](https://www.reuters.com/world/americas/us-defense-secretary-hegseth-vows-boost-venezuela-military-cooperation-2026-11-18/) — independent reporting on the announced agreement, training and intelligence-sharing scope, and both governments' explanations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
