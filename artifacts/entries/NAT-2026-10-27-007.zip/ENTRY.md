# DOJ sues Anne Arundel school board over parental access and student gender policies

**Entry ID:** NAT-2026-10-27-007
**Date:** October 27, 2026
**Checked:** 2026-10-28 1:20 AM EDT
**Evidence state:** Original 31-page complaint: caption, opening allegations, count headings and prayer inspected; DOJ release and independent Reuters reporting with district response. Filed/pending; October 27 recovery, not an action first occurring after the current cutoff opened.
**Review state:** current-standard-reviewed

The eight-count federal complaint seeks declarations and injunctions under FERPA and PPRA; the district denies violating either law.

## THE FACTS

- The United States filed an eight-count complaint against the Board of Education of Anne Arundel County in Maryland federal court on October 27, case 1:26-cv-04499-CJC. The stamped original establishes a filed enforcement case, not a judicial finding.
- DOJ alleges that the district’s Regulation JQ-RA and handling of student names, pronouns, gender information and education records violate parental rights under the Family Educational Rights and Privacy Act and Protection of Pupil Rights Amendment. These are disputed legal and factual allegations; this record does not reproduce the complaint’s account of an individual minor.
- The complaint requests declarations of violations and an injunction against noncompliant policies and practices, with record-review and correction procedures and parental-consent or opt-out protections for specified student inquiries. Requested relief is not an issued injunction, a verified funding cutoff or an implemented nationwide school rule.
- DOJ describes the action as protecting parents’ access to records and participation in decisions concerning their children. Reuters reports that the district disputes the allegations, maintains it complies with FERPA and PPRA, and says litigation followed good-faith discussions.

## SIGNIFICANCE

The filing uses federal enforcement power to contest how a public school system handles student information and parental access. Its reach and consequences depend on the statutes, record and court decisions, not DOJ’s announcement alone.

## GOALPOST / RESPONSE

DOJ’s strongest case is that parents have enforceable access, correction and consent rights that district practices cannot override. The district’s documented response is that it complies with both laws. Actual policy text, the factual record and judicial interpretation are the tests.

## MAYBE / THEREFORE

Maybe the case enforces valid parental-record rights, or an overbroad interpretation intrudes on lawful student-privacy practices. Therefore this is a disputed enforcement filing, not proof of illegal conduct, medical treatment, established harm or a new national mandate.


## SOURCES

- [United States v. Board of Education of Anne Arundel County, No. 1:26-cv-04499-CJC, complaint](https://www.justice.gov/crt/media/1468906/dl) — primary court filing
- [Justice Department announces Anne Arundel parental-rights lawsuit](https://www.justice.gov/opa/pr/justice-department-sues-stop-secret-gender-transitions-anne-arundel-county-public-schools) — primary agency enforcement announcement
- [U.S. Justice Department sues Maryland school district over transgender policies](https://www.investing.com/news/politics-news/us-justice-department-sues-maryland-school-district-over-transgender-policies-4977306) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
