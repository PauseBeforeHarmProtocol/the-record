# Court declines immediate block of Trump's second birthright-citizenship order

**Entry ID:** NAT-2026-08-28-007
**Date:** August 6–28, 2026
**Checked:** 2026-09-02 12:00 AM EDT
**Evidence state:** signed executive order, official Federal Register publication, current State Department passport instructions, and Reuters review of draft guidance plus courtroom reporting; draft implementation mechanism reported, final guidance and application unresolved
**Review state:** current-standard-reviewed

The judge denied emergency relief on procedural grounds while a reported State Department draft showed how passport applications could be used to implement the still-contested order.

## THE FACTS

- Executive Order 14418, signed August 6 after the Supreme Court invalidated Trump's broader 2025 order, directs federal agencies not to recognize citizenship for specified U.S.-born children when neither parent is a citizen and a parent falls within categories involving alien-enemy status, foreign-government employment, alleged commercial birth tourism or citizenship fraud, or birth in a territory where statute does not confer citizenship.
- The order instructs the State and Homeland Security departments to issue implementation guidance within 30 days and asserts that the listed categories fall outside the Supreme Court's birthright-citizenship rule. Agencies had not issued final public guidance by the August 28 hearing.
- U.S. District Judge Deborah Boardman declined to issue a temporary restraining order because the plaintiffs' existing case did not yet plead a challenge to the August 6 order. She allowed them to supplement the complaint and set expedited briefing.
- Boardman questioned the asserted exceptions but did not decide their constitutionality. Justice Department lawyers argued that relief was premature before implementation guidance expected by September 5; the procedural denial leaves the order formally unblocked for now but does not resolve the merits or guarantee implementation.
- Reuters reviewed draft State Department guidance that would require parents applying for a child's passport to submit evidence of their own citizenship or immigration status so the department could assess whether Executive Order 14418 applies. The draft described categories involving foreign-government employment, fraud or a commercial transaction to obtain citizenship, and alien-enemy status.
- The State Department confirmed only the administration's policy objective and did not publish the draft as final guidance. Current public passport instructions still treat a qualifying U.S. birth certificate as primary citizenship evidence and do not establish that the reported parental-document requirement was operative by cutoff.

## SIGNIFICANCE

The order is a narrower executive attempt to define constitutional citizenship after the administration lost at the Supreme Court. The reported passport draft supplies the first concrete implementation mechanism and could shift a new documentary burden to parents while the order's legality remains contested.

## GOALPOST / RESPONSE

The administration says the Supreme Court recognized jurisdictional exceptions and that the order targets fraud, foreign officials and hostile actors outside the constitutional rule. Challengers say it invents exceptions the decision did not authorize. Publication and scope of final guidance, form changes, staff instructions, passport adjudications, the amended complaint, preliminary-injunction briefing and merits rulings are the tests.

## MAYBE / THEREFORE

Maybe final guidance will use parental evidence only to identify narrow, recognized exceptions and prevent fraud, or it may burden many families and implement categories courts later reject. Therefore the record reports a reviewed draft and a procedural court ruling—not final passport policy, proof that the document requirement is already in use, a merits judgment or a lawful denial of citizenship to any identified child.


## SOURCES

- [White House — Executive Order 14418 on citizenship recognition](https://www.whitehouse.gov/presidential-actions/2026/08/continuing-to-protect-the-meaning-and-value-of-american-citizenship/) — primary signed executive order identifying additional claimed exceptions to birthright citizenship
- [Federal Register — Executive Order 14418](https://www.federalregister.gov/documents/2026/08/11/2026-16403/continuing-to-protect-the-meaning-and-value-of-american-citizenship) — official published presidential document
- [Reuters — judge declines immediate block of second birthright-citizenship order](https://www.reuters.com/world/us-judge-wont-immediately-block-trumps-newest-order-limiting-birthright-2026-08-28/) — independent courtroom reporting on the procedural denial, expedited amendment, and pending guidance
- [Reuters — draft passport guidance for second birthright-citizenship order](https://www.reuters.com/legal/government/trump-birthright-curbs-may-prompt-us-passport-checks-parents-2026-09-01/) — independent document review of proposed State Department parental-evidence requirements, with agency response and litigation context
- [State Department — current passport citizenship-evidence instructions](https://travel.state.gov/en/passports/apply/help/citizenship-evidence.html) — primary public guidance establishing the passport evidence requirements displayed before final EO 14418 implementation guidance

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
