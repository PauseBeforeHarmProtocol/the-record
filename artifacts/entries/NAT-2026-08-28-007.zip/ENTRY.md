# Court preliminarily blocks Trump's second birthright-citizenship order

**Entry ID:** NAT-2026-08-28-007
**Date:** August 6–September 2, 2026
**Checked:** 2026-09-09 12:01 PM EDT
**Evidence state:** primary executive order, Federal Register materials, Maryland district-court opinion, Reuters and Associated Press reporting, and the September 9 DHS interim final rule; rule operative for later births, class injunction and broader merits unresolved
**Review state:** current-standard-reviewed

A Maryland judge barred agencies from denying citizenship to members of the certified class while the case proceeds; implementation guidance may still be prepared.

## THE FACTS

- Executive Order 14418, signed August 6 after the Supreme Court invalidated Trump's broader 2025 order, directs federal agencies not to recognize citizenship for specified U.S.-born children when neither parent is a citizen and a parent falls within categories involving alien-enemy status, foreign-government employment, alleged commercial birth tourism or citizenship fraud, or birth in a territory where statute does not confer citizenship.
- The order instructs the State and Homeland Security departments to issue implementation guidance within 30 days and asserts that the listed categories fall outside the Supreme Court's birthright-citizenship rule. Agencies had not issued final public guidance by the August 28 hearing.
- U.S. District Judge Deborah Boardman declined to issue a temporary restraining order because the plaintiffs' existing case did not yet plead a challenge to the August 6 order. She allowed them to supplement the complaint and set expedited briefing.
- Boardman questioned the asserted exceptions but did not decide their constitutionality. Justice Department lawyers argued that relief was premature before implementation guidance expected by September 5; the procedural denial leaves the order formally unblocked for now but does not resolve the merits or guarantee implementation.
- Reuters reviewed draft State Department guidance that would require parents applying for a child's passport to submit evidence of their own citizenship or immigration status so the department could assess whether Executive Order 14418 applies. The draft described categories involving foreign-government employment, fraud or a commercial transaction to obtain citizenship, and alien-enemy status.
- The State Department confirmed only the administration's policy objective and did not publish the draft as final guidance. Current public passport instructions still treat a qualifying U.S. birth certificate as primary citizenship evidence and do not establish that the reported parental-document requirement was operative by cutoff.
- On September 2, U.S. District Judge Deborah Boardman granted a classwide preliminary injunction. She found Executive Order 14418 almost certainly unconstitutional as applied to children in the certified class because the Supreme Court had already held that children born in the United States to parents unlawfully or temporarily present are citizens at birth.
- The injunction bars the State, Homeland Security and Social Security agencies and people acting with them from enforcing the order against class members or interfering with, denying or failing to recognize their citizenship. It does not enjoin subsection 2(d), which the court found does not threaten class members, or section 3(b), so agencies may still issue public implementation guidance.
- The order is preliminary and appealable, remains subject to modification or dissolution and does not constitute a final merits judgment. The administration may seek relief after guidance issues; by cutoff no appellate court had stayed the injunction.
- DHS then published an interim final rule on September 9, effective retroactively on September 4 for children born on or after that date. The rule expands the regulatory category from accredited foreign diplomatic officers to specified foreign-government, embassy, consular and immune international-organization employees. When neither parent is a U.S. citizen, DHS says a U.S.-born child of a covered employee is outside Fourteenth Amendment citizenship and may voluntarily register as a lawful permanent resident; otherwise applicable alien-registration duties remain. Children born before September 4 remain governed by the rules in place at birth.
- DHS invoked the Administrative Procedure Act's foreign-affairs exemption and good-cause exception to bypass prior notice and a delayed effective date, while accepting comments through October 5. The rule itself acknowledges that State Department determinations require fact-specific legal analysis for some immunity categories. Its publication implements one part of the August 6 order outside the enjoined class to the extent lawful; it does not lift the Maryland injunction, finally resolve the constitutional scope of birthright citizenship or establish how many children are affected.

## SIGNIFICANCE

The preliminary injunction blocks the order for the certified class, while the interim rule operationalizes a narrower foreign-government-employment category for later births and expands it beyond accredited diplomats. That combination creates immediate status and registration consequences outside the enjoined class while constitutional and administrative-law review remain available.

## GOALPOST / RESPONSE

The administration says covered children fall outside Fourteenth Amendment jurisdiction and that rapid action protects reciprocal treatment of U.S. personnel abroad; the Maryland court found the broader order almost certainly unconstitutional for its certified class. The tests are case-specific State Department determinations, USCIS decisions, passport or Social Security denials, the comment record, motions concerning the injunction, appellate rulings and a final merits judgment.

## MAYBE / THEREFORE

Maybe the rule permissibly modernizes the settled diplomatic-officer exception and gives affected children a practical residence pathway, or its broader employee categories may exceed that exception and impose uncertain status on people born in the United States. Therefore DHS has made the September 4 rule operative for later births, but it has not lifted the class injunction, established the rule's ultimate constitutionality or shown its population-level effects.


## SOURCES

- [White House — Executive Order 14418 on citizenship recognition](https://www.whitehouse.gov/presidential-actions/2026/08/continuing-to-protect-the-meaning-and-value-of-american-citizenship/) — primary signed executive order identifying additional claimed exceptions to birthright citizenship
- [Federal Register — Executive Order 14418](https://www.federalregister.gov/documents/2026/08/11/2026-16403/continuing-to-protect-the-meaning-and-value-of-american-citizenship) — official published presidential document
- [Reuters — judge declines immediate block of second birthright-citizenship order](https://www.reuters.com/world/us-judge-wont-immediately-block-trumps-newest-order-limiting-birthright-2026-08-28/) — independent courtroom reporting on the procedural denial, expedited amendment, and pending guidance
- [Reuters — draft passport guidance for second birthright-citizenship order](https://www.reuters.com/legal/government/trump-birthright-curbs-may-prompt-us-passport-checks-parents-2026-09-01/) — independent document review of proposed State Department parental-evidence requirements, with agency response and litigation context
- [State Department — current passport citizenship-evidence instructions](https://travel.state.gov/en/passports/apply/help/citizenship-evidence.html) — primary public guidance establishing the passport evidence requirements displayed before final EO 14418 implementation guidance
- [U.S. District Court for the District of Maryland — birthright-citizenship preliminary-injunction opinion](https://storage.courtlistener.com/recap/gov.uscourts.mdd.574698/gov.uscourts.mdd.574698.181.0.pdf) — primary memorandum opinion finding Executive Order 14418 likely unconstitutional as applied to the certified class and defining the scope of preliminary relief
- [Reuters — judge preliminarily blocks Trump's second birthright-citizenship order](https://www.reuters.com/world/us-judge-blocks-trumps-newest-order-limiting-birthright-citizenship-2026-09-02/) — independent legal reporting on the classwide preliminary injunction and the agencies covered by the order
- [Associated Press — judge blocks Trump's second birthright-citizenship order](https://apnews.com/article/birthright-citizenship-immigration-trump-blocked-69de0a404602a6e648b35f6a852c833d) — independent reporting on the classwide preliminary injunction, the administration's prematurity argument and the order's practical effect
- [Federal Register — lawful permanent residence and citizenship rule for children of foreign government employees](https://www.federalregister.gov/documents/2026/09/09/2026-18345/registration-of-lawful-permanent-residence-for-children-born-to-foreign-government-employees-in-the) — primary interim final rule, effective September 4, expanding the foreign-government-employee category and the related voluntary permanent-residence pathway

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
