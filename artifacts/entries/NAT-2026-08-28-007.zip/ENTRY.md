# Court declines immediate block of Trump's second birthright-citizenship order

**Entry ID:** NAT-2026-08-28-007
**Date:** August 6–28, 2026
**Checked:** 2026-08-28 6:08 PM EDT
**Evidence state:** signed executive order and official Federal Register publication plus independent Reuters courtroom reporting; order issued, implementation guidance pending, emergency motion denied without a merits ruling
**Review state:** current-standard-reviewed

The judge denied emergency relief on procedural grounds, allowed an amended challenge, and did not approve the order's constitutionality.

## THE FACTS

- Executive Order 14418, signed August 6 after the Supreme Court invalidated Trump's broader 2025 order, directs federal agencies not to recognize citizenship for specified U.S.-born children when neither parent is a citizen and a parent falls within categories involving alien-enemy status, foreign-government employment, alleged commercial birth tourism or citizenship fraud, or birth in a territory where statute does not confer citizenship.
- The order instructs the State and Homeland Security departments to issue implementation guidance within 30 days and asserts that the listed categories fall outside the Supreme Court's birthright-citizenship rule. Agencies had not issued final public guidance by the August 28 hearing.
- U.S. District Judge Deborah Boardman declined to issue a temporary restraining order because the plaintiffs' existing case did not yet plead a challenge to the August 6 order. She allowed them to supplement the complaint and set expedited briefing.
- Boardman questioned the asserted exceptions but did not decide their constitutionality. Justice Department lawyers argued that relief was premature before implementation guidance expected by September 5; the procedural denial leaves the order formally unblocked for now but does not resolve the merits or guarantee implementation.

## SIGNIFICANCE

The order is a narrower executive attempt to define constitutional citizenship after the administration lost at the Supreme Court. The first hearing leaves it temporarily without an injunction for pleading reasons, creating a short implementation window while a renewed challenge is prepared.

## GOALPOST / RESPONSE

The administration says the Supreme Court recognized jurisdictional exceptions and that the new order targets categories outside the constitutional rule, especially fraud, foreign officials, and hostile actors. Challengers say the order invents exceptions the decision did not authorize. The amended complaint, implementation guidance, preliminary-injunction briefing, merits rulings, agency document practices, and treatment of affected newborns are the tests.

## MAYBE / THEREFORE

Maybe final guidance will construe the categories narrowly enough to avoid many conflicts, or courts may hold that one or more categories exceed the Constitution and the Supreme Court's decision. Therefore the record says emergency relief was denied on procedural posture—not that the judge upheld the order or that citizenship has already been lawfully denied to any identified child.


## SOURCES

- [White House — Executive Order 14418 on citizenship recognition](https://www.whitehouse.gov/presidential-actions/2026/08/continuing-to-protect-the-meaning-and-value-of-american-citizenship/) — primary signed executive order identifying additional claimed exceptions to birthright citizenship
- [Federal Register — Executive Order 14418](https://www.federalregister.gov/documents/2026/08/11/2026-16403/continuing-to-protect-the-meaning-and-value-of-american-citizenship) — official published presidential document
- [Reuters — judge declines immediate block of second birthright-citizenship order](https://www.reuters.com/world/us-judge-wont-immediately-block-trumps-newest-order-limiting-birthright-2026-08-28/) — independent courtroom reporting on the procedural denial, expedited amendment, and pending guidance

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
