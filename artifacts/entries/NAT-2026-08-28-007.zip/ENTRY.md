# Court preliminarily blocks Trump's second birthright-citizenship order

**Entry ID:** NAT-2026-08-28-007
**Date:** August 6–September 2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** primary executive order, Federal Register publication and Maryland district-court opinion plus Reuters and Associated Press legal reporting; enforcement preliminarily enjoined for the certified class, guidance and merits litigation unresolved
**Review state:** current-standard-reviewed

A Maryland judge barred agencies from denying citizenship to members of the certified class while the case proceeds; implementation guidance may still be prepared.

## THE FACTS

- Executive Order 14418, signed August 6 after the Supreme Court invalidated Trump's broader 2025 order, directs federal agencies not to recognize citizenship for specified U.S.-born children when neither parent is a citizen and a parent falls within categories involving alien-enemy status, foreign-government employment, alleged commercial birth tourism or citizenship fraud, or birth in a territory where statute does not confer citizenship.
- The order instructs the State and Homeland Security departments to issue implementation guidance within 30 days and asserts that the listed categories fall outside the Supreme Court's birthright-citizenship rule. Agencies had not issued final public guidance by the August 28 hearing.
- U.S. District Judge Deborah Boardman declined to issue a temporary restraining order because the plaintiffs' existing case did not yet plead a challenge to the August 6 order. She allowed them to supplement the complaint and set expedited briefing.
- Boardman questioned the asserted exceptions but did not decide their constitutionality. Justice Department lawyers argued that relief was premature before implementation guidance expected by September 5; the procedural denial leaves the order formally unblocked for now but does not resolve the merits or guarantee implementation.
- Reuters reviewed draft State Department guidance that would require parents applying for a child's passport to submit evidence of their own citizenship or immigration status so the department could assess whether Executive Order 14418 applies. The draft described categories involving foreign-government employment, fraud or a commercial transaction to obtain citizenship, and alien-enemy status.
- The State Department confirmed only the administration's policy objective and did not publish the draft as final guidance. Current public passport instructions still treat a qualifying U.S. birth certificate as primary citizenship evidence and do not establish that the reported parental-document requirement was operative by cutoff.
- On September 2, U.S. District Judge Deborah Boardman granted a classwide preliminary injunction. She found Executive Order 14418 almost certainly unconstitutional as applied to children in the certified class because the Supreme Court had already held that children born in the United States to parents unlawfully or temporarily present are citizens at birth.
- The injunction bars the State, Homeland Security and Social Security agencies and people acting with them from enforcing the order against class members or interfering with, denying or failing to recognize their citizenship. It does not enjoin subsection 2(d), which the court found does not threaten class members, or section 3(b), so agencies may still issue public implementation guidance.
- The order is preliminary and appealable, remains subject to modification or dissolution and does not constitute a final merits judgment. The administration may seek relief after guidance issues; by cutoff no appellate court had stayed the injunction.

## SIGNIFICANCE

The preliminary injunction changes the order's status from awaiting implementation to blocked for the certified class and applies the Supreme Court's June citizenship holding to Trump's narrower second order. The classwide remedy protects affected children while litigation continues, but it is not a final merits judgment and does not foreclose appeal or later modification.

## GOALPOST / RESPONSE

The administration argued that relief was premature before implementation guidance and says the order targets categories outside the Supreme Court's citizenship rule. The court found the order almost certainly unconstitutional as applied to children the Supreme Court already held are citizens at birth. Appellate rulings, any published guidance, motions to modify the injunction, document denials outside the class and a final merits judgment are the tests.

## MAYBE / THEREFORE

Maybe an appellate court will narrow the classwide relief or later guidance will identify lawful applications outside the certified class, or the injunction may remain in place because the listed categories sweep in children the Supreme Court already recognized as citizens. Therefore the record states that Executive Order 14418 is preliminarily blocked for the certified class—not finally invalidated in every application—and that agencies may prepare guidance but may not deny class members' citizenship while the order remains effective.


## SOURCES

- [White House — Executive Order 14418 on citizenship recognition](https://www.whitehouse.gov/presidential-actions/2026/08/continuing-to-protect-the-meaning-and-value-of-american-citizenship/) — primary signed executive order identifying additional claimed exceptions to birthright citizenship
- [Federal Register — Executive Order 14418](https://www.federalregister.gov/documents/2026/08/11/2026-16403/continuing-to-protect-the-meaning-and-value-of-american-citizenship) — official published presidential document
- [Reuters — judge declines immediate block of second birthright-citizenship order](https://www.reuters.com/world/us-judge-wont-immediately-block-trumps-newest-order-limiting-birthright-2026-08-28/) — independent courtroom reporting on the procedural denial, expedited amendment, and pending guidance
- [Reuters — draft passport guidance for second birthright-citizenship order](https://www.reuters.com/legal/government/trump-birthright-curbs-may-prompt-us-passport-checks-parents-2026-09-01/) — independent document review of proposed State Department parental-evidence requirements, with agency response and litigation context
- [State Department — current passport citizenship-evidence instructions](https://travel.state.gov/en/passports/apply/help/citizenship-evidence.html) — primary public guidance establishing the passport evidence requirements displayed before final EO 14418 implementation guidance
- [U.S. District Court for the District of Maryland — birthright-citizenship preliminary-injunction opinion](https://storage.courtlistener.com/recap/gov.uscourts.mdd.574698/gov.uscourts.mdd.574698.181.0.pdf) — primary memorandum opinion finding Executive Order 14418 likely unconstitutional as applied to the certified class and defining the scope of preliminary relief
- [Reuters — judge preliminarily blocks Trump's second birthright-citizenship order](https://www.reuters.com/world/us-judge-blocks-trumps-newest-order-limiting-birthright-citizenship-2026-09-02/) — independent legal reporting on the classwide preliminary injunction and the agencies covered by the order
- [Associated Press — judge blocks Trump's second birthright-citizenship order](https://apnews.com/article/birthright-citizenship-immigration-trump-blocked-69de0a404602a6e648b35f6a852c833d) — independent reporting on the classwide preliminary injunction, the administration's prematurity argument and the order's practical effect

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
