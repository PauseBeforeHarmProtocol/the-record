# Trump names Adam Telle acting Army secretary

**Entry ID:** NAT-2026-09-03-007
**Date:** September 3, 2026
**Checked:** 2026-09-03 11:59 PM EDT
**Evidence state:** primary presidential post plus independent Reuters and Associated Press reporting; acting appointment announced, reason for predecessor's departure and long-term effects unresolved
**Review state:** current-standard-reviewed

The appointment places the Army's former civil-works chief in its top civilian role after Dan Driscoll's departure; no permanent nominee was announced.

## THE FACTS

- President Trump announced on Truth Social at 6:37 p.m. EDT September 3 that Assistant Secretary of the Army for Civil Works Adam Telle would become acting secretary of the Army effective immediately.
- Reuters and Associated Press independently reported the appointment. The change follows Dan Driscoll's departure from the Army's top civilian post.
- Reuters and AP described reported tension between Driscoll and Defense Secretary Pete Hegseth. The administration did not publicly give a reason for Driscoll's departure, so the reported dispute is not presented as an established cause.
- The announcement installs an acting official; it is not a Senate confirmation, a nomination for a permanent term or evidence of any resulting Army policy or performance change.

## SIGNIFICANCE

The secretary of the Army oversees the service's civilian administration, budget and modernization under the defense secretary. An immediate acting appointment preserves formal leadership continuity while leaving the duration, permanent succession and policy consequences unresolved.

## GOALPOST / RESPONSE

Trump said Telle would serve effectively and emphasized his prior civil-works role. A formal acting-service record, any permanent nomination, Senate action, tenure length, issued directives, budget choices and measurable Army outcomes are the tests.

## MAYBE / THEREFORE

Maybe Telle's appointment is an ordinary continuity measure after a voluntary departure, or the unexplained transition may reflect deeper leadership conflict. Therefore the record confirms Trump's immediately effective acting appointment and Driscoll's departure—not the reason for that departure, a permanent confirmation or any change in Army results.


## SOURCES

- [Donald Trump — Adam Telle acting Army secretary announcement](https://truthsocial.com/@realDonaldTrump/117209499032712444) — primary presidential statement establishing what Trump announced, not independent evidence for claims about the appointment or its effects
- [Reuters — Trump appoints Adam Telle acting Army secretary](https://www.reuters.com/world/us/trump-appoints-adam-telle-acting-us-army-secretary-2026-09-03/) — independent reporting on the acting appointment and leadership transition
- [Associated Press — Trump names Adam Telle acting Army secretary](https://apnews.com/article/trump-army-secretary-adam-telle-driscoll-hegseth-ab235fbfd006506d4e6d52311f0e7002) — independent reporting on the appointment, Telle's prior role and Driscoll's departure

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
