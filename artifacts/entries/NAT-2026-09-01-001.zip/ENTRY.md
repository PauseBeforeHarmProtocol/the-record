# Transportation agencies finalize revised federal environmental-review rules

**Entry ID:** NAT-2026-09-01-001
**Date:** September 1, 2026
**Checked:** 2026-09-01 6:04 AM EDT
**Evidence state:** primary joint final rule with effective date, comment summary, agency responses and changes from the interim framework; rule effective, project-level consequences unmeasured
**Review state:** current-standard-reviewed

The joint final rule makes technical changes while largely retaining the agencies' July 2025 interim NEPA framework; it took effect immediately on September 1.

## THE FACTS

- The Department of Transportation, Federal Highway Administration, Federal Railroad Administration and Federal Transit Administration issued a joint final rule revising their National Environmental Policy Act procedures, effective September 1, 2026.
- The rule finalizes the July 3, 2025 interim final rule with what the agencies describe as minor technical changes. It removes references to rescinded Council on Environmental Quality regulations and incorporates statutory and judicial changes including the 2023 BUILDER Act, the Infrastructure Investment and Jobs Act and the Supreme Court's Seven County decision.
- The final text raises monetary thresholds for certain categorical exclusions from less than $5 million in federal funds or $30 million total estimated cost to less than $6 million or $35 million. The agencies received 1,991 comments, including 244 unique submissions.
- Commenters argued that the framework could reduce public input and insufficiently protect wildlife, Tribal interests and treaty rights. The agencies said the procedures retain public participation, consultation and analysis proportionate to each project's likely effects.
- Because most provisions had already been operating under the 2025 interim rule, publication is a finalization and limited revision—not evidence that every change began on September 1 or that projects have already become faster, cheaper or environmentally safer.

## SIGNIFICANCE

The rule supplies the durable procedural framework for environmental review across major highway, rail and transit programs. Its practical effect will depend on how agencies apply narrower federal-review boundaries and categorical exclusions to individual projects, and on ensuing litigation and project data.

## GOALPOST / RESPONSE

The administration says the changes align transportation reviews with statute and Supreme Court precedent, focus analysis on reasonably foreseeable effects and reduce delay while preserving required participation and consultation. Critics warn that narrower procedures and exclusions may conceal or shift environmental and community costs. Project-level review times, exclusion use, public participation records, consultation outcomes, court rulings, project costs and environmental results are the tests.

## MAYBE / THEREFORE

Maybe the revised procedures will remove duplicative work while preserving meaningful review, or they may shorten analysis in ways that leave material effects or affected communities underexamined. Therefore the record confirms an immediately effective final procedural rule, largely continuing a 2025 interim framework—not universal exemption from NEPA, elimination of public input or proven changes in project speed, cost or environmental harm.


## SOURCES

- [Federal Register — DOT agencies finalize NEPA regulations](https://www.federalregister.gov/documents/2026/09/01/2026-17904/national-environmental-policy-act-regulations) — primary final rule describing the immediately effective environmental-review procedures, comment record and changes from the 2025 interim rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
