# Pentagon temporarily withdraws detailed testosterone-screening guidance

**Entry ID:** NAT-2026-09-02-012
**Date:** July 15–September 3, 2026
**Checked:** 2026-09-03 11:59 PM EDT
**Evidence state:** primary July Defense Department directive plus Reuters reporting on the September 2 publication and September 3 temporary rescission; detailed pathways withdrawn, broader mandate and interim guidance continue, replacement text and outcomes unresolved
**Review state:** corrected

The department removed its September 2 clinical pathways for updates one day after publication; the broader July mandate and interim guidance remain in effect.

## THE FACTS

- Defense Secretary Pete Hegseth's July 15 memorandum directed mandatory testosterone-deficiency screening as part of periodic health assessments for active-duty and reserve personnel age 30 and older and ordered health officials to issue implementation guidance.
- On September 2, the Pentagon published detailed clinical pathways that it said were immediately effective. They described questionnaire and blood-test screening for men age 30 and older and sex-specific evaluation and treatment pathways.
- By September 3, the Pentagon and Defense Health Agency had removed the memo and accompanying statement. A U.S. official told Reuters the September 2 draft was temporarily rescinded to allow updates and said interim guidance remains in effect.
- The temporary rescission means the specific September 2 pathways are not currently operative. It does not rescind Hegseth's July mandate, identify every requirement in the continuing interim guidance or establish when revised clinical guidance will appear.
- The Pentagon says screening is intended to improve health and readiness. Doctors cited by Reuters said universal testing lacks evidence of combat-readiness benefit and could produce overtreatment, while one specialist said appropriate safeguards could identify underlying health conditions. Uptake, treatment, adverse effects and readiness outcomes remain unmeasured.

## SIGNIFICANCE

The one-day reversal interrupts implementation of the detailed clinical pathways and leaves service members and clinicians without the public specifications briefly announced as immediate policy. The broader screening direction remains, so the action is a temporary guidance withdrawal rather than abandonment of the program.

## GOALPOST / RESPONSE

The department says the draft needs updates while interim guidance continues. The strongest response remains that universal testing could create false positives or overtreatment without demonstrated readiness gains. A published replacement, the text of interim requirements, clinical safeguards, screening and treatment data, adverse effects, fertility outcomes, readiness measures and independent review are the tests.

## MAYBE / THEREFORE

Maybe temporary withdrawal will improve safeguards before implementation, or it may reflect policy instability around a medically contested mandate. Therefore the record confirms that the detailed September 2 guidance was removed and temporarily rescinded—not that the July mandate ended, that no screening continues or that either benefits or harms have been measured.


## SOURCES

- [Department of Defense — health and human performance optimization memorandum](https://media.defense.gov/2026/Jul/15/2003961654/-1/-1/1/HEALTH%20AND%20HUMAN%20PERFORMANCE%20OPTIMIZATION%20TO%20ENHANCE%20MILITARY%20READINESS%20OSD004430-26%20RES%20FINAL.PDF) — primary directive requiring testosterone-deficiency screening for active-duty and reserve personnel age 30 and older and ordering implementation guidance
- [Reuters — Pentagon issues immediate testosterone-screening clinical guidance](https://www.reuters.com/business/healthcare-pharmaceuticals/us-pentagon-issues-clinical-guidelines-troop-testosterone-screening-start-2026-09-02/) — independent reporting on the implemented clinical pathways, sex-specific screening details and medical-evidence concerns
- [Reuters — Pentagon temporarily rescinds testosterone-screening clinical guidance](https://www.reuters.com/business/healthcare-pharmaceuticals/pentagon-temporarily-rescinding-guidance-testosterone-screening-us-troops-2026-09-03/) — independent reporting based on removed Pentagon materials and an attributed U.S. official statement; detailed guidance rescinded, interim guidance remains

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
