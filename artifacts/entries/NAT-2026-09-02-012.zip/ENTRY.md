# Pentagon implements standardized testosterone-screening clinical pathways

**Entry ID:** NAT-2026-09-02-012
**Date:** July 15–September 2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** primary July Defense Department directive plus Reuters reporting on the September 2 clinical guidance; screening pathways implemented immediately, participation and health or readiness outcomes not yet measured
**Review state:** current-standard-reviewed

Immediate guidance operationalizes mandatory screening for men 30 and older and sets sex-specific treatment pathways; improved readiness has not been demonstrated.

## THE FACTS

- Defense Secretary Pete Hegseth's July 15 memorandum directed mandatory testosterone-deficiency screening as part of periodic health assessments for active-duty and reserve personnel age 30 and older and ordered health officials to issue implementation guidance.
- On September 2, the Pentagon issued detailed clinical guidance effective immediately. Reuters reported that men age 30 and older will receive mandatory blood testing, while younger men may be tested on request or when clinicians identify warning signs.
- For women, the guidance does not require routine testosterone blood testing but calls for screening for fatigue and disrupted menstrual cycles associated with hormonal dysregulation, low energy availability and relative energy deficiency. It describes off-label testosterone treatment for postmenopausal women with unusually low sexual desire.
- The Pentagon says standardized screening and treatment pathways will support health and military readiness. Doctors cited by Reuters warned that universal testing could prompt unnecessary or harmful treatment and said evidence that it improves combat readiness is limited. The guidance implements clinical processes; it does not establish uptake, outcomes or safety.

## SIGNIFICANCE

The guidance converts a broadly announced mandate into an operational military-health program affecting a large population of service members. It creates measurable screening and treatment consequences, while the benefit-risk balance remains an empirical question rather than a demonstrated readiness gain.

## GOALPOST / RESPONSE

The Pentagon says earlier identification and management of hormonal and energy-availability problems will improve performance, resilience and readiness. The strongest response is that professional guidelines generally focus testing on symptoms and confirmed deficiency and that population screening may increase false positives or overtreatment. Screening completion, repeat-confirmation rates, diagnoses, treatment uptake, adverse effects, fertility outcomes, readiness measures and independent review are the tests.

## MAYBE / THEREFORE

Maybe standardized pathways will identify clinically important deficiencies and improve health for some service members, or broad testing may medicalize normal variation and expose people to unnecessary treatment without readiness benefit. Therefore the record confirms immediate implementation guidance and mandatory testing for the specified population—not that treatment is mandatory, universally beneficial or proven to improve combat readiness.


## SOURCES

- [Department of Defense — health and human performance optimization memorandum](https://media.defense.gov/2026/Jul/15/2003961654/-1/-1/1/HEALTH%20AND%20HUMAN%20PERFORMANCE%20OPTIMIZATION%20TO%20ENHANCE%20MILITARY%20READINESS%20OSD004430-26%20RES%20FINAL.PDF) — primary directive requiring testosterone-deficiency screening for active-duty and reserve personnel age 30 and older and ordering implementation guidance
- [Reuters — Pentagon issues immediate testosterone-screening clinical guidance](https://www.reuters.com/business/healthcare-pharmaceuticals/us-pentagon-issues-clinical-guidelines-troop-testosterone-screening-start-2026-09-02/) — independent reporting on the implemented clinical pathways, sex-specific screening details and medical-evidence concerns

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
