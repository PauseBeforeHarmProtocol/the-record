# Pentagon resumes mandatory testosterone screening after pause

**Entry ID:** NAT-2026-09-02-012
**Date:** July 15–September 17, 2026
**Checked:** 2026-09-18 5:59 AM EDT
**Evidence state:** primary July Defense Department directive plus Reuters reporting on publication, temporary rescission and September 17 resumption; screening again effective, revised public guidance and outcomes unresolved
**Review state:** current-standard-reviewed

The department says screening for service members age 30 and older is again effective immediately; revised clinical guidance was not public by cutoff.

## THE FACTS

- Defense Secretary Pete Hegseth's July 15 memorandum directed mandatory testosterone-deficiency screening as part of periodic health assessments for active-duty and reserve personnel age 30 and older and ordered health officials to issue implementation guidance.
- On September 2, the Pentagon published detailed clinical pathways that it said were immediately effective. They described questionnaire and blood-test screening for men age 30 and older and sex-specific evaluation and treatment pathways.
- By September 3, the Pentagon and Defense Health Agency had removed the memo and accompanying statement. A U.S. official told Reuters the September 2 draft was temporarily rescinded to allow updates and said interim guidance remained in effect.
- On September 17, the Pentagon said the mandatory screening program would proceed effective immediately after the pause. Reuters reported that the department did not specify how the guidance had changed, and revised clinical text was not publicly available by cutoff.
- The Pentagon says screening is intended to improve health and readiness. Doctors cited by Reuters said testing without symptoms can create false positives and inappropriate treatment, including fertility risks, while appropriate evaluation can identify underlying conditions. Uptake, treatment, adverse effects and readiness outcomes remain unmeasured.

## SIGNIFICANCE

The program has moved from a temporary guidance withdrawal back to implementation, but the public still lacks the revised clinical specifications needed to compare safeguards and obligations. The action affects military health screening nationwide without yet establishing benefit or harm.

## GOALPOST / RESPONSE

The Pentagon says the program will improve service-member health and readiness. The strongest medical response is that universal testing can generate false positives and overtreatment without demonstrated readiness gains. Published revised guidance, clinical safeguards, screening and treatment data, adverse effects, fertility outcomes and measured readiness are the tests.

## MAYBE / THEREFORE

Maybe revised implementation will identify genuine health conditions with adequate safeguards, or the resumed mandate may expose asymptomatic personnel to unnecessary testing and treatment. Therefore the record establishes that screening is again ordered to proceed—not what changed during the pause or that benefits or harms have been measured.


## SOURCES

- [Department of Defense — health and human performance optimization memorandum](https://media.defense.gov/2026/Jul/15/2003961654/-1/-1/1/HEALTH%20AND%20HUMAN%20PERFORMANCE%20OPTIMIZATION%20TO%20ENHANCE%20MILITARY%20READINESS%20OSD004430-26%20RES%20FINAL.PDF) — primary directive requiring testosterone-deficiency screening for active-duty and reserve personnel age 30 and older and ordering implementation guidance
- [Reuters — Pentagon issues immediate testosterone-screening clinical guidance](https://www.reuters.com/business/healthcare-pharmaceuticals/us-pentagon-issues-clinical-guidelines-troop-testosterone-screening-start-2026-09-02/) — independent reporting on the implemented clinical pathways, sex-specific screening details and medical-evidence concerns
- [Reuters — Pentagon temporarily rescinds testosterone-screening clinical guidance](https://www.reuters.com/business/healthcare-pharmaceuticals/pentagon-temporarily-rescinding-guidance-testosterone-screening-us-troops-2026-09-03/) — independent reporting based on removed Pentagon materials and an attributed U.S. official statement; detailed guidance rescinded, interim guidance remains
- [Reuters — Pentagon resumes mandatory testosterone screening after pause](https://www.reuters.com/business/healthcare-pharmaceuticals/pentagon-proceed-with-controversial-testosterone-testing-after-pause-2026-09-17/) — independent reporting based on an effective-immediately Pentagon statement and named medical experts

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
