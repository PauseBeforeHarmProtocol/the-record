# Federal judge orders prison bureau to reinstate union agreement while case proceeds

**Entry ID:** NAT-2026-09-29-012
**Date:** September 29, 2026
**Checked:** 2026-10-01 12:04 AM EDT
**Evidence state:** primary federal court order plus independent Reuters reporting; preliminary injunction issued and immediate reinstatement ordered, agency compliance, final merits and appeal unresolved
**Review state:** current-standard-reviewed

The preliminary order restores the correctional-officers' collective-bargaining agreement for its remaining term; it is not a final merits judgment on the broader executive order.

## THE FACTS

- U.S. District Judge Vernon Oliver granted a preliminary injunction and Administrative Procedure Act relief in AFGE Council of Prison Locals v. Federal Bureau of Prisons, No. 3:25-cv-1907, on September 29.
- The order preliminarily set aside and enjoined the bureau's termination of the union's collective-bargaining agreement and subsidiary agreements and required their immediate reinstatement for the remaining contractual term.
- The court found the union likely to succeed on its APA challenge and described the bureau's stated national-security rationale as pretextual on the record before it. Those are preliminary findings, not a final merits judgment.
- Reuters reported that the agreement covers roughly 30,000 federal prison employees. The bureau and Justice Department retained the ability to appeal or continue litigating, and broader challenges to Executive Order 14251 were not resolved by this order.
- No final judgment, completed appeal, verified agency-compliance record, bargaining outcome or measured effect on prison safety, staffing or costs was established in the inspected sources by the cutoff.

## SIGNIFICANCE

The injunction immediately restores negotiated procedures for a large federal correctional workforce and limits one agency's implementation of the administration's union exclusions. Its reach and durability remain bounded by the preliminary posture and the specific agreement.

## GOALPOST / RESPONSE

The administration argues certain federal labor agreements can impede national-security and operational flexibility. The court found the bureau's explanation likely unlawful and pretextual at this stage; the union says bargaining protections support safety and fair management. Appellate review, the final merits record, agency compliance and measured workplace outcomes are the tests.

## MAYBE / THEREFORE

Maybe the order preserves lawful labor protections without impairing prison operations, or later merits and appellate review may narrow or reverse it. Therefore the record establishes immediate preliminary reinstatement—not final invalidation of the executive order or permanent bargaining rights.


## SOURCES

- [AFGE Council of Prison Locals v. BOP preliminary-injunction order](https://fingfx.thomsonreuters.com/gfx/legaldocs/klpyrdxjxvg/EMPLOYMENT_BARGAINING_PRISONS_decision.pdf) — primary court order, No. 3:25-cv-1907, ECF 72
- [Reuters — judge reinstates prison-system collective-bargaining agreement](https://www.reuters.com/legal/government/us-prison-agency-must-reinstate-union-bargaining-contract-us-judge-rules-2026-09-30/) — independent reporting on preliminary injunction and response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
