# OFAC sanctions ten individuals and one entity in alleged North Korean IT-worker schemes

**Entry ID:** NAT-2026-10-28-002
**Date:** October 28, 2026
**Checked:** 2026-10-28 12:10 PM EDT
**Evidence state:** Original SDN update and Treasury designation release, with Reuters corroboration. Implemented restrictions; underlying allegations and effects remain attributed.
**Review state:** current-standard-reviewed

Administrative designations target facilitators and FFTDC; no criminal conviction or measured revenue loss is inferred.

## THE FACTS

- On October 28, OFAC listed ten individuals and the First Financial and Technical Development Center under its North Korea sanctions program. Treasury invokes Executive Orders 13687 and 13722 for different targets.
- Treasury alleges the networks obtain employment through false identities and move earnings for North Korean weapons programs. Its release describes facilitators and workers in North Korea and Russia. Alleged financial flows are agency assertions, not adjudicated guilt or independently audited amounts in this record.
- Covered U.S.-jurisdiction property is blocked and U.S.-person transactions are generally prohibited absent authorization or exemption. Reuters corroborates the action and reports no immediate response from North Korea’s UN mission. The record establishes designations, not amounts actually frozen or revenue prevented.

## SIGNIFICANCE

This uses financial restrictions against overseas labor and payment networks, separate from the existing record of criminal arrests and laptop-farm seizures.

## GOALPOST / RESPONSE

Treasury’s strongest explanation is protecting businesses and disrupting revenue for prohibited weapons programs, in coordination with international partners. Actual enforcement and independently measured disruption remain the tests.

## MAYBE / THEREFORE

Maybe designations disrupt facilitators, or replacement identities and payment channels reduce their impact. Therefore the supported event is an implemented sanctions action, not a conviction, verified shutdown of all networks or measured weapons-funding reduction.


## SOURCES

- [North Korea and DRC-related SDN additions](https://ofac.treasury.gov/recent-actions/20261028) — primary sanctions list update
- [Treasury sanctions facilitators of DPRK IT-worker schemes](https://home.treasury.gov/news/press-releases/sb0669/) — primary designation announcement
- [U.S. sanctions North Korean IT-worker network](https://www.reuters.com/world/asia-pacific/us-issues-new-north-korea-related-sanctions-2026-10-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
