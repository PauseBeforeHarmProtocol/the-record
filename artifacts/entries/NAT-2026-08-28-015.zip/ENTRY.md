# Trump requests Washington monuments and a five-year exhibit as Smithsonian leadership transition continues

**Entry ID:** NAT-2026-08-28-015
**Date:** August 28–September 11, 2026
**Checked:** 2026-09-12 12:01 AM EDT
**Evidence state:** direct Trump posts, prior Interior letter and Smithsonian announcement plus Reuters; requests and retirement confirmed, institutional adoption and physical changes unverified
**Review state:** current-standard-reviewed

Trump called for two Washington statues, a multiyear exhibition and a new Center for American Heroes; no Smithsonian approval, procurement or installation was established.

## THE FACTS

- An August 28 letter from Interior Secretary Doug Burgum and White House Domestic Policy Council Director Vince Haley threatened support relationships with the Smithsonian under its current leadership, including artifact loans, procurement assistance and discretionary grants. It alleged discriminatory practices and requested talks; those allegations are not adjudicated findings.
- On September 8, Smithsonian Secretary Lonnie Bunch announced retirement by the end of the calendar year. The Regents said they would announce an acting secretary and conduct a national successor search; the announcement did not identify a replacement.
- Reuters, attributing the account to Bunch’s New York Times interview, reported that he denied White House pressure caused his departure while acknowledging the strain of the job. The sequence alone does not establish dismissal or coercion.
- The inspected announcements do not establish a specific grant cutoff, artifact withdrawal, procurement cancellation or implemented government-wide suspension. The prior formal threat remains distinct from an actual funding action.
- On September 11, Trump asked the Smithsonian to install the 11-foot George Washington statue displayed at the Freedom 250 race in Flag Hall and dedicate it on Constitution Day, September 17. He also requested a five-year Washington exhibition extending through February 22, 2032 and a 30-foot 'Washington Colossus' to replace the museum's 'Infinity' sculpture.
- In a second post, Trump criticized the Smithsonian's Center for Restorative History and associated programs and called for a Center for American Heroes. The posts establish his requests and characterization of the institution; they do not independently establish his claims about Smithsonian programming or that the institution accepted the proposed changes.
- No public Board of Regents approval, Smithsonian commitment, contract, appropriation, removal of 'Infinity,' statue installation or exhibit opening was established by cutoff. The requests remain distinct from an implemented museum decision and from the earlier administration threat to federal support relationships.

## SIGNIFICANCE

The detailed content and installation requests sharpen the administration's attempt to shape a congressionally established cultural institution during a pending leadership transition. They create a concrete test of institutional independence but are not proof that Trump controls Smithsonian exhibits or that any physical change occurred.

## GOALPOST / RESPONSE

Trump presents the requests as restoring celebratory national history and honoring George Washington; the Smithsonian has previously emphasized scholarly independence and an orderly succession. Regents decisions, curatorial review, appropriations, contracts, installations, exhibit labels and any support withdrawals are the tests.

## MAYBE / THEREFORE

Maybe a president's high-profile requests produce a popular commemoration through ordinary Smithsonian review, or the prior support threat and leadership transition may make the requests coercive in practice. Therefore the archive records specific presidential pressure and proposed content—not approved exhibits, completed construction, removed art or proven control of the institution.


## SOURCES

- [Interior Department — administration letter to Smithsonian Board of Regents](https://www.doi.gov/media/document/department-interior-letter-smithsonian-institution) — primary administration letter formally threatening agency-support withdrawals and requesting leadership talks
- [Reuters — administration threatens to withdraw federal-agency support from Smithsonian](https://www.reuters.com/legal/government/trump-administration-threatens-cut-federal-agencies-support-smithsonian-2026-09-03/) — independent reporting on the letter, prior Smithsonian response and unresolved implementation
- [Smithsonian — Secretary Lonnie G. Bunch III announces retirement](https://www.si.edu/newsdesk/releases/smithsonian-secretary-lonnie-g-bunch-iii-announces-retirement) — primary retirement and succession-process announcement; departure planned by calendar-year end
- [Reuters — Smithsonian chief Lonnie Bunch announces departure](https://www.reuters.com/world/us/smithsonian-chief-lonnie-bunch-announces-departure-2026-09-08/) — independent reporting including attribution to Bunch’s New York Times interview denying White House pressure caused his departure
- [Donald Trump Truth Social post — Smithsonian Washington statue and exhibition requests](https://truthsocial.com/@realDonaldTrump/117255718355537976) — primary presidential social-media statement
- [Donald Trump Truth Social post — Smithsonian exhibit and Center for American Heroes requests](https://truthsocial.com/@realDonaldTrump/117255720319253709) — primary presidential social-media statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
