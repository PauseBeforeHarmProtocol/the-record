# Smithsonian announces Bunch’s retirement after administration support threat

**Entry ID:** NAT-2026-08-28-015
**Date:** August 28–September 8, 2026
**Checked:** 2026-09-08 6:02 PM EDT
**Evidence state:** primary Smithsonian announcement and Interior letter publication plus Reuters; retirement announced, replacement and support withdrawals unverified
**Review state:** current-standard-reviewed

A year-end leadership transition is announced; Bunch denies White House pressure caused his departure, and a support cutoff is not established.

## THE FACTS

- An August 28 letter from Interior Secretary Doug Burgum and White House Domestic Policy Council Director Vince Haley threatened support relationships with the Smithsonian under its current leadership, including artifact loans, procurement assistance and discretionary grants. It alleged discriminatory practices and requested talks; those allegations are not adjudicated findings.
- On September 8, Smithsonian Secretary Lonnie Bunch announced retirement by the end of the calendar year. The Regents said they would announce an acting secretary and conduct a national successor search; the announcement did not identify a replacement.
- Reuters, attributing the account to Bunch’s New York Times interview, reported that he denied White House pressure caused his departure while acknowledging the strain of the job. The sequence alone does not establish dismissal or coercion.
- The inspected announcements do not establish a specific grant cutoff, artifact withdrawal, procurement cancellation or implemented government-wide suspension. The prior formal threat remains distinct from an actual funding action.

## SIGNIFICANCE

The announced succession creates a new governance decision during an existing dispute over federal support and historical interpretation. It does not establish that the administration has gained control over museum content.

## GOALPOST / RESPONSE

The administration presents its pressure as restoring mission and nondiscrimination. Bunch says he will continue defending institutional integrity, and the Regents promise a stable transition. Successor selection, support decisions and exhibit changes are the tests.

## MAYBE / THEREFORE

Maybe an ordinary retirement and orderly succession occur during a political dispute; alternatively, the dispute may shape later governance choices. Therefore record the announced transition and Bunch’s denial without claiming Trump fired him or secured the changes he sought.


## SOURCES

- [Interior Department — administration letter to Smithsonian Board of Regents](https://www.doi.gov/media/document/department-interior-letter-smithsonian-institution) — primary administration letter formally threatening agency-support withdrawals and requesting leadership talks
- [Reuters — administration threatens to withdraw federal-agency support from Smithsonian](https://www.reuters.com/legal/government/trump-administration-threatens-cut-federal-agencies-support-smithsonian-2026-09-03/) — independent reporting on the letter, prior Smithsonian response and unresolved implementation
- [Smithsonian — Secretary Lonnie G. Bunch III announces retirement](https://www.si.edu/newsdesk/releases/smithsonian-secretary-lonnie-g-bunch-iii-announces-retirement) — primary retirement and succession-process announcement; departure planned by calendar-year end
- [Reuters — Smithsonian chief Lonnie Bunch announces departure](https://www.reuters.com/world/us/smithsonian-chief-lonnie-bunch-announces-departure-2026-09-08/) — independent reporting including attribution to Bunch’s New York Times interview denying White House pressure caused his departure

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
