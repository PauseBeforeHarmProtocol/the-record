# Administration formally threatens to withdraw agency support from Smithsonian

**Entry ID:** NAT-2026-08-28-015
**Date:** August 28–September 2, 2026
**Checked:** 2026-09-03 6:02 AM EDT
**Evidence state:** primary Interior Department publication of the administration letter plus independent Reuters reporting and the Smithsonian secretary's reported response to prior accusations; threat and meeting demand issued, specific agency withdrawals and legal findings absent
**Review state:** current-standard-reviewed

Interior and the White House said agencies should not keep lending artifacts, enabling procurement or making discretionary grants under current leadership; no specific cutoff had been implemented by review time.

## THE FACTS

- Interior Secretary Doug Burgum and White House Domestic Policy Council Director Vince Haley sent the Smithsonian's Board of Regents a letter under Executive Order 14416 saying the administration had concluded that action was necessary to redirect the institution.
- The letter alleged that Smithsonian diversity practices may violate anti-discrimination law, asked institution leaders to meet with the administration and said federal agencies could not in good conscience continue supporting the Smithsonian under current leadership through measures such as artifact loans, procurement assistance and discretionary grants.
- Reuters reported the letter on September 2 after earlier Atlantic coverage. It describes a formal threat and negotiating position, not a published government-wide suspension order; no specific agency action, grant amount, procurement cancellation, artifact withdrawal or appropriations cutoff was identified by the review cutoff.
- Smithsonian Secretary Lonnie Bunch had rejected a prior White House characterization of the National Museum of American History as anti-American and politically extreme. The Smithsonian had no immediate response to the new letter, while historians and civil-rights advocates warned that the pressure could distort acknowledgement of slavery and other parts of U.S. history.

## SIGNIFICANCE

The letter escalates presidential pressure on a congressionally established national museum and research institution by tying cultural-content and employment demands to potentially broad federal support relationships. Its practical and legal effect depends on whether agencies issue operative directives and whether Congress, the Regents or courts constrain them.

## GOALPOST / RESPONSE

The administration says the Smithsonian has departed from its statutory mission, engaged in discriminatory practices and promoted an anti-American narrative, and it presents agency support as leverage for reform. The strongest response is that political control over historical interpretation can suppress independent scholarship and public acknowledgement of slavery and discrimination. Written agency directives, identified grants or loans, procurement changes, Regents' actions, congressional oversight, legal challenges and exhibit revisions are the tests.

## MAYBE / THEREFORE

Maybe the confrontation will produce lawful governance and employment reforms without compromising scholarly independence, or threatened support withdrawals may become viewpoint-based coercion that damages collections, research and public access. Therefore the record confirms a formal administration threat and demand for talks—not a completed government-wide cutoff, a proven legal violation by the Smithsonian or an adjudicated entitlement to dictate museum content.


## SOURCES

- [Interior Department — administration letter to Smithsonian Board of Regents](https://www.doi.gov/media/document/department-interior-letter-smithsonian-institution) — primary administration letter formally threatening agency-support withdrawals and requesting leadership talks
- [Reuters — administration threatens to withdraw federal-agency support from Smithsonian](https://www.reuters.com/legal/government/trump-administration-threatens-cut-federal-agencies-support-smithsonian-2026-09-03/) — independent reporting on the letter, prior Smithsonian response and unresolved implementation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
