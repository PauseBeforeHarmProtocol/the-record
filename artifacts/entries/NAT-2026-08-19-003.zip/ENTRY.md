# IRS proposes refundable-credit limits and drafts filer-status questions

**Entry ID:** NAT-2026-08-19-003
**Date:** August 19–September 17, 2026
**Checked:** 2026-10-01 12:04 PM EDT
**Evidence state:** primary proposed regulation, Treasury announcement and IRS draft forms, plus independent reporting; proposal and draft design confirmed, final requirements and outcomes unresolved
**Review state:** current-standard-reviewed

The proposal and draft forms would verify eligibility for portions of four refundable credits; neither the regulation nor the forms were final filing requirements.

## THE FACTS

- Treasury and the IRS proposed REG-119882-25 to treat the refunded portion of the earned income, additional child, American opportunity and adoption credits as federal public benefits under the 1996 welfare law and to bar payment of those portions to people who are not U.S. citizens, nationals or qualified aliens. Comments were due October 5 and a public hearing was scheduled for October 14.
- The draft 2026 Form 1040 asks whether the filer—and a spouse on a joint return—is a U.S. citizen, U.S. national or an alien lawfully authorized to work in the United States at filing time.
- Draft Schedule 3-A applies only to filers claiming one of the four listed refundable credits. It calculates a proposed federal-public-benefit amount and asks whether the taxpayer or spouse is a citizen, national or qualified alien for that amount.
- Both forms prominently say they are drafts and not for filing, remain subject to OMB approval and can change before final release. The proposal and drafts therefore do not establish a final 2026 filing obligation or a completed denial of credits.
- Treasury says the approach enforces statutory limits on federal public benefits. Associated Press reporting identified concerns that the status question could deter filing or expand immigration-related use of tax information; those are prospective risks, not measured filing or enforcement outcomes.

## SIGNIFICANCE

The proposal would connect refundable-credit administration to an immigration-status eligibility framework and the draft Form 1040 would place a status question on the main individual return. Because both the rule and forms remained nonfinal, the material consequence is a formal proposal and documented draft design, not yet an implemented nationwide filing or enforcement result.

## GOALPOST / RESPONSE

Treasury says the proposal prevents payment of federal public benefits to ineligible recipients and protects public funds. The tests are the final regulation and OMB-approved forms, instructions defining the categories, data-use safeguards, implementation dates, processing outcomes, error rates and measured effects on eligible and ineligible claimants.

## MAYBE / THEREFORE

Maybe final verification reduces payments the administration considers statutorily ineligible, or it may produce privacy, compliance and chilling effects beyond the affected refundable portions. Therefore the established action is a proposed rule plus draft—not-for-filing forms—not a final citizenship test for all tax liability, a completed denial of benefits or proof of fraud.


## SOURCES

- [IRS Internal Revenue Bulletin 2026-38 — REG-119882-25](https://www.irs.gov/irb/2026-38_IRB) — primary proposed regulation and public notice
- [Treasury — proposal on refundable tax credits as federal public benefits](https://home.treasury.gov/news/press-releases/sb0608) — primary agency announcement and policy rationale
- [IRS — draft 2026 Form 1040](https://www.irs.gov/pub/irs-dft/f1040--dft.pdf) — primary draft tax form; not for filing
- [IRS — draft 2026 Schedule 3-A, Federal Public Benefit](https://www.irs.gov/pub/irs-dft/f1040s3a--dft.pdf) — primary draft tax schedule; not for filing
- [Associated Press — IRS draft adds citizenship and work-authorization question](https://apnews.com/article/b610a373e2da062f6f7a5cba794b4759) — independent reporting on draft tax forms, proposal and criticism

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
