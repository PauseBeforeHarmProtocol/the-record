# EPA proposes revised gasoline-distribution emissions compliance procedures

**Entry ID:** NAT-2026-09-28-004
**Date:** September 25–28, 2026
**Checked:** 2026-09-28 12:30 AM EDT
**Evidence state:** primary EPA proposed rule, 91 FR 61175–61200; publicly filed September 25 and published September 28; proposal only, comments through November 12
**Review state:** current-standard-reviewed

The proposal changes monitoring and testing provisions while retaining numerical emission limits and existing compliance dates; comments close November 12.

## THE FACTS

- EPA's September 28 proposal, filed for public inspection September 25, reconsiders specified provisions of its 2024 gasoline-distribution standards under 40 CFR part 63 subparts R and BBBBBB and part 60 subpart XXa. Comments are due November 12; no final amendment is established by this proposal.
- Proposed changes include a capital-expenditure threshold for certain modification determinations, leak-monitoring clarifications, alternative thermal-oxidation compliance options, and a six-hour rather than three-hour rolling average for vapor-recovery concentration limits.
- EPA says it is not proposing new emission limits or changes to the 2024 rule's compliance dates. It proposes clarification of initial equipment-leak monitoring deadlines and seeks comment on timing; industry's request for an extension is not an extension granted.
- EPA estimates annual area-source compliance savings of $713,400 under one thermal-oxidation option or $565,800 under the other, in 2024 dollars, and expects no air-quality or overall health effect. These are agency projections contingent on finalization, not measured savings or independently established environmental outcomes.

## SIGNIFICANCE

A formal national proposal changes how affected fuel-distribution facilities demonstrate compliance. Unchanged numerical limits do not alone establish that different monitoring procedures will produce identical real-world results.

## GOALPOST / RESPONSE

EPA presents the revisions as practical compliance improvements and cost savings without weakening emission-limit stringency. Comments, the final text, monitoring results, compliance findings and measured emissions will test that expectation.

## MAYBE / THEREFORE

Maybe the revisions will simplify compliance without increasing emissions, or longer averaging periods and altered monitoring may affect detection and control in practice. Therefore the record describes proposed procedures and attributed forecasts, without asserting finalized requirements, realized savings or environmental harm.


## SOURCES

- [EPA proposes revised gasoline-distribution emissions compliance procedures](https://www.govinfo.gov/content/pkg/FR-2026-09-28/pdf/2026-19774.pdf) — primary EPA proposed rule, 91 FR 61175–61200; publicly filed September 25 and published September 28; proposal only, comments through November 12

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
