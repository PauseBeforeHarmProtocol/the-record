# White House withdraws Heidi Overton's FDA nomination

**Entry ID:** NAT-2026-11-17-004
**Date:** November 17, 2026
**Checked:** 2026-11-18 12:06 AM EST
**Evidence state:** independent Associated Press and Reuters reporting, including White House confirmation to AP, plus the official Senate committee vote notice; nomination withdrawn, formal Senate status update and replacement unresolved at cutoff
**Review state:** current-standard-reviewed

The administration pulled Overton's nomination before a scheduled Senate committee vote; no replacement nomination or confirmed permanent commissioner was public by cutoff.

## THE FACTS

- The White House withdrew Dr. Heidi Overton's nomination to be commissioner of the Food and Drug Administration on November 17. Associated Press reported that the White House confirmed the withdrawal; Reuters independently reported the decision through three people familiar with it.
- The Senate Health, Education, Labor and Pensions Committee had scheduled a November 18 vote on Overton's nomination, PN1273-17. The committee's public nomination page still listed the September hearing as the last action at cutoff, so the archive does not claim that a formal withdrawal message had already been posted to the Senate record.
- AP reported that Overton faced questions from senators about scientific independence, vaccine policy, abortion policy and flavored e-cigarettes. Reuters reported that administration officials doubted she had enough Republican support; the exact mix of reasons remained disputed rather than independently adjudicated.
- Outgoing committee chair Bill Cassidy said he believed Overton could have won confirmation and attributed the withdrawal to disagreements over commitments sought by anti-abortion Republicans. That named response conflicts with the insufficient-support explanation reported by Reuters and is preserved as a competing account, not a settled finding.
- No reviewed White House announcement named a replacement by cutoff. AP and Reuters reported that Kyle Diamantas remained acting FDA commissioner; the withdrawal therefore ended this nomination without filling the Senate-confirmed leadership position or resolving the agency's pending policy and management questions.

## SIGNIFICANCE

The action changes the leadership path for the federal agency that regulates drugs, vaccines, food, tobacco and medical products. It is a completed nomination withdrawal with immediate institutional consequences, while the replacement, duration of acting leadership and policy effects remain unresolved.

## GOALPOST / RESPONSE

The administration's reported explanation is that Overton lacked sufficient Senate support, while Cassidy offered a different account centered on requested abortion-policy commitments. The tests are a formal Senate withdrawal status, a new nomination, committee and floor action, continued acting-service legality, FDA leadership continuity and measurable regulatory or staffing consequences.

## MAYBE / THEREFORE

Maybe the withdrawal will allow a replacement with broader Senate and scientific support, or it may prolong acting leadership and policy uncertainty at FDA. Therefore the White House ended Overton's pending nomination before the committee vote—not filled the office, established a single undisputed reason, or determined the next commissioner's policies.


## SOURCES

- [White House pulls FDA nominee Heidi Overton after wavering support from Senate Republicans](https://apnews.com/article/15d9c3978ed4f77657900cc2c327d375) — independent reporting with White House confirmation and named Senate response
- [Trump withdraws Heidi Overton as nominee to lead Food and Drug Administration, sources say](https://www.reuters.com/legal/litigation/trump-withdraws-heidi-overton-nominee-lead-food-drug-administration-sources-say-2026-11-18/) — independent reporting corroborated by a separate outlet
- [Next week: Senate HELP Committee to vote on labor, education and health nominations](https://www.help.senate.gov/rep/newsroom/press/next-week-senate-help-committee-to-vote-on-labor-education-health-nominations) — primary congressional schedule and nomination notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
