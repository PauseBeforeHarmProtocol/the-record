# Treasury sanctions three Turkey-based entities under Iran authority

**Entry ID:** NAT-2026-09-04-007
**Date:** September 4, 2026
**Checked:** 2026-09-04 12:00 PM EDT
**Evidence state:** primary OFAC designation notice and general-license announcement plus independent Reuters reporting; sanctions implemented, downstream effects unmeasured
**Review state:** current-standard-reviewed

OFAC added an investment bank, portfolio manager and leasing company to the sanctions list while licensing wind-down transactions; economic and diplomatic effects remain unmeasured.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Golden Global Yatirim Bankasi Anonim Sirketi, Golden Global Portfoy Yonetimi Anonim Sirketi and Golden Global Varlik Kiralama Anonim Sirketi to the Specially Designated Nationals list on September 4 under Iran-related Executive Order 13902 authority.
- OFAC's notice identifies all three entities as based in Turkey and links the portfolio-management and leasing companies to Golden Global Investment Bank. Designation generally blocks property subject to U.S. jurisdiction and restricts U.S.-person transactions under the applicable sanctions rules.
- OFAC simultaneously issued Iran General License CC authorizing the wind-down of transactions involving persons blocked on September 4. The public action did not report seized assets, penalties, account closures or a measured change in Iranian financing.
- Reuters placed the action within Treasury Secretary Scott Bessent's announced campaign to intensify economic pressure and push Iran back toward negotiations. No Iranian policy change or renewed agreement resulted by cutoff.

## SIGNIFICANCE

The listings extend the administration's Iran pressure campaign into Turkey's financial sector during an active conflict. Their practical effect depends on correspondent banking, asset exposure, enforcement, Turkish responses and whether the restrictions change Iranian financing or negotiating behavior.

## GOALPOST / RESPONSE

Treasury says repeated financial sanctions will constrain Iran and force it back to negotiations. Blocked-property reports, transaction and correspondent-bank changes, enforcement actions, Iranian financial indicators, Turkish government response, humanitarian spillovers and diplomatic developments are the tests.

## MAYBE / THEREFORE

Maybe the designations will close a meaningful financing channel, or targeted entities may have little U.S. exposure and activity may shift to other intermediaries. Therefore the record establishes implemented listings and a wind-down license—not quantified asset blocking, successful financial isolation or a negotiating concession.


## SOURCES

- [OFAC — Iran-related Turkish entity designations and General License CC](https://ofac.treasury.gov/recent-actions/20260904) — primary sanctions notice listing three Turkey-based entities and authorizing wind-down transactions
- [Reuters — Treasury sanctions three Turkey-based entities over Iran links](https://www.reuters.com/world/middle-east/us-targets-turkish-entities-with-iran-related-sanctions-2026-09-04/) — independent reporting on the implemented listings, wind-down license and administration pressure campaign

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
