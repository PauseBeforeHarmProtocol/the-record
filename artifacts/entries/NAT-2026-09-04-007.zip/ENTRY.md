# Treasury expands Iran sanctions through aviation and proxy-network actions

**Entry ID:** NAT-2026-09-04-007
**Date:** September 4–10, 2026
**Checked:** 2026-09-10 11:59 PM EDT
**Evidence state:** primary OFAC notices, licenses, Federal Register rule and September 10 Treasury release plus Reuters and AP reporting; legal actions implemented, underlying allegations and downstream effects qualified
**Review state:** current-standard-reviewed

OFAC added proxy-support networks, a $1.43 million settlement and a stricter licensing policy; blocked assets and behavioral effects remain unmeasured.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Golden Global Yatirim Bankasi Anonim Sirketi, Golden Global Portfoy Yonetimi Anonim Sirketi and Golden Global Varlik Kiralama Anonim Sirketi to the Specially Designated Nationals list on September 4 under Iran-related Executive Order 13902 authority.
- OFAC's notice identifies all three entities as based in Turkey and links the portfolio-management and leasing companies to Golden Global Investment Bank. Designation generally blocks property subject to U.S. jurisdiction and restricts U.S.-person transactions under the applicable sanctions rules.
- OFAC simultaneously issued Iran General License CC authorizing the wind-down of transactions involving persons blocked on September 4. The public action did not report seized assets, penalties, account closures or a measured change in Iranian financing.
- Reuters placed the action within Treasury Secretary Scott Bessent's announced campaign to intensify economic pressure and push Iran back toward negotiations. No Iranian policy change or renewed agreement resulted by cutoff.
- On September 8, OFAC added an individual and numerous Iranian airlines, aviation-support companies, cargo providers and other entities to the sanctions list. The primary notice identifies entities in Iran and foreign intermediaries in countries including Turkey, the United Arab Emirates, Kazakhstan and Malaysia.
- OFAC also suspended Iran General License J-1, issued Iran General License DD for winding down specified civil-aviation and other transactions previously authorized under the Iran regulations, and issued Counter Terrorism General License 37 for winding down transactions involving specified people blocked on September 8.
- Reuters described 36 new sanctions and reported that Treasury sought to isolate Mahan Air and related procurement routes; Associated Press described the action as targeting more than two dozen aviation-sector entities and preserved Treasury's accusation that some supported weapons, personnel or illicit-cargo movement. The public evidence establishes listings and licenses, not the truth of every alleged activity, blocked-asset totals, grounded flights or a resulting Iranian policy change.
- The September 10 Federal Register final rule specifies that, effective September 8, OFAC indefinitely stayed 31 CFR 560.522, 560.528 and 560.529, covering certain overflight payments, the aircraft-safety licensing policy, and bunkering and emergency repairs; General License J-1 was also suspended. This clarifies the scope of the already-recorded September 8 action, not a second sanctions action on September 10.
- On September 10, OFAC designated networks it said supported Kata'ib Hizballah and Lebanese Hizballah, including four named Kata'ib Hizballah commanders or members and entities and individuals in Iraq, Lebanon, the United Arab Emirates and elsewhere. The listings are implemented sanctions; the underlying support and sanctions-evasion descriptions are Treasury allegations rather than adjudicated criminal findings.
- Treasury also announced that an individual agreed to pay $1,427,230 to settle potential civil liability for services to an Iranian software company, receipt of Iranian-origin dividends and acquisition of Iranian real property. OFAC characterized the apparent violations as egregious and not voluntarily self-disclosed; a civil settlement does not itself establish a criminal conviction.
- OFAC updated its Iran licensing policy to a presumption of denial except where required by law or in limited life, limb and environmental-safety circumstances, and said it immediately began denying the vast majority of outstanding Iran-related specific-license requests.
- The release explains that blocked property and entities owned 50% or more by designated persons are generally restricted. It did not publish total assets blocked, completed account closures, humanitarian or aviation effects, proxy-funding reductions or a change in Iranian policy by cutoff.

## SIGNIFICANCE

The September 10 action extends the campaign beyond banking and aviation into proxy-support and cash-and-gold networks, while tightening access to specific licenses and announcing a substantial civil settlement. The legal restrictions are implemented; financial isolation, civilian effects and diplomatic or military behavior changes remain unmeasured.

## GOALPOST / RESPONSE

Treasury says the actions will cut proxy financing, dismantle sanctions-evasion networks and increase pressure on Iran. Blocked-asset reports, license outcomes, enforcement, independently verified funding disruption, civilian effects and observable changes in proxy or Iranian conduct are the tests; designation allegations are not criminal verdicts.

## MAYBE / THEREFORE

Maybe broader listings and stricter licensing materially constrain financing and logistics, or networks may reroute while lawful civilian activity bears costs without changing state or proxy conduct. Therefore the record establishes implemented designations, a civil settlement and a presumption-of-denial policy—not quantified isolation, proven criminal guilt for every named actor, humanitarian outcomes or a strategic concession.


## SOURCES

- [OFAC — Iran-related Turkish entity designations and General License CC](https://ofac.treasury.gov/recent-actions/20260904) — primary sanctions notice listing three Turkey-based entities and authorizing wind-down transactions
- [Reuters — Treasury sanctions three Turkey-based entities over Iran links](https://www.reuters.com/world/middle-east/us-targets-turkish-entities-with-iran-related-sanctions-2026-09-04/) — independent reporting on the implemented listings, wind-down license and administration pressure campaign
- [OFAC — Iran aviation and counterterrorism designations and general-license actions](https://ofac.treasury.gov/recent-actions/20260908) — primary sanctions notice listing designated persons and entities, suspended Iran General License J-1 and new wind-down licenses
- [Reuters — United States issues fresh Iran aviation sanctions](https://www.reuters.com/business/aerospace-defense/us-issues-fresh-iran-related-sanctions-treasury-website-shows-2026-09-08/) — independent reporting on 36 designations, covered aviation networks and the administration's pressure rationale
- [Associated Press — U.S. targets remaining parts of Iran aviation sector](https://apnews.com/article/59b9b99d8dbb6dfbb519af565c995c85) — independent reporting on the implemented aviation-sector sanctions, foreign logistics providers and Treasury's stated explanation
- [Federal Register — Iranian Transactions and Sanctions Regulations, 91 FR 57511](https://www.federalregister.gov/documents/2026/09/10/2026-18461/iranian-transactions-and-sanctions-regulations) — primary final rule; indefinite stay effective September 8
- [Treasury — Operation Economic Outcast sanctions action](https://home.treasury.gov/news/press-releases/sb0626) — primary agency release describing designations, enforcement settlement and licensing policy

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
