# Treasury expands Iran sanctions from Turkish finance into aviation networks

**Entry ID:** NAT-2026-09-04-007
**Date:** September 4–10, 2026
**Checked:** 2026-09-10 11:57 AM EDT
**Evidence state:** primary OFAC notices and licenses plus independent Reuters and Associated Press reporting; the September 4 and 8 sanctions actions are implemented, while underlying allegations and downstream financial, aviation and diplomatic effects remain unmeasured
**Review state:** current-standard-reviewed

OFAC followed three Turkey-based financial listings with broad airline, intermediary and licensing actions; blocked assets, aviation disruption and diplomatic effects remain unmeasured.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Golden Global Yatirim Bankasi Anonim Sirketi, Golden Global Portfoy Yonetimi Anonim Sirketi and Golden Global Varlik Kiralama Anonim Sirketi to the Specially Designated Nationals list on September 4 under Iran-related Executive Order 13902 authority.
- OFAC's notice identifies all three entities as based in Turkey and links the portfolio-management and leasing companies to Golden Global Investment Bank. Designation generally blocks property subject to U.S. jurisdiction and restricts U.S.-person transactions under the applicable sanctions rules.
- OFAC simultaneously issued Iran General License CC authorizing the wind-down of transactions involving persons blocked on September 4. The public action did not report seized assets, penalties, account closures or a measured change in Iranian financing.
- Reuters placed the action within Treasury Secretary Scott Bessent's announced campaign to intensify economic pressure and push Iran back toward negotiations. No Iranian policy change or renewed agreement resulted by cutoff.
- On September 8, OFAC added an individual and numerous Iranian airlines, aviation-support companies, cargo providers and other entities to the sanctions list. The primary notice identifies entities in Iran and foreign intermediaries in countries including Turkey, the United Arab Emirates, Kazakhstan and Malaysia.
- OFAC also suspended Iran General License J-1, issued Iran General License DD for winding down specified civil-aviation and other transactions previously authorized under the Iran regulations, and issued Counter Terrorism General License 37 for winding down transactions involving specified people blocked on September 8.
- Reuters described 36 new sanctions and reported that Treasury sought to isolate Mahan Air and related procurement routes; Associated Press described the action as targeting more than two dozen aviation-sector entities and preserved Treasury's accusation that some supported weapons, personnel or illicit-cargo movement. The public evidence establishes listings and licenses, not the truth of every alleged activity, blocked-asset totals, grounded flights or a resulting Iranian policy change.
- The September 10 Federal Register final rule specifies that, effective September 8, OFAC indefinitely stayed 31 CFR 560.522, 560.528 and 560.529, covering certain overflight payments, the aircraft-safety licensing policy, and bunkering and emergency repairs; General License J-1 was also suspended. This clarifies the scope of the already-recorded September 8 action, not a second sanctions action on September 10.

## SIGNIFICANCE

The listings and license suspensions broaden economic pressure across financial, aviation and support services, including previously authorized overflight, aircraft-safety and maritime-service channels. Their breadth makes civilian access and safety as well as sanctions effectiveness relevant oversight questions; actual service disruption, blocked assets and diplomatic effects remain unmeasured.

## GOALPOST / RESPONSE

OFAC cites attacks on partners, disruption of energy markets, alleged weapons-program reconstitution, monetization of Hormuz and support for proxies as reasons to suspend these authorizations. Those are the administration’s stated grounds, not independently established findings in this notice. Licensing decisions, wind-down compliance, maintenance and maritime access, enforcement, humanitarian effects and verified diplomatic concessions are the tests.

## MAYBE / THEREFORE

Maybe closing financial and service channels reduces support for Iranian state and military logistics, or counterparties may reroute while restrictions burden civilian safety and commerce without changing state conduct. Therefore the record establishes implemented listings and specified license and policy suspensions effective September 8—not quantified isolation, grounded fleets, proven underlying allegations or a negotiating concession.


## SOURCES

- [OFAC — Iran-related Turkish entity designations and General License CC](https://ofac.treasury.gov/recent-actions/20260904) — primary sanctions notice listing three Turkey-based entities and authorizing wind-down transactions
- [Reuters — Treasury sanctions three Turkey-based entities over Iran links](https://www.reuters.com/world/middle-east/us-targets-turkish-entities-with-iran-related-sanctions-2026-09-04/) — independent reporting on the implemented listings, wind-down license and administration pressure campaign
- [OFAC — Iran aviation and counterterrorism designations and general-license actions](https://ofac.treasury.gov/recent-actions/20260908) — primary sanctions notice listing designated persons and entities, suspended Iran General License J-1 and new wind-down licenses
- [Reuters — United States issues fresh Iran aviation sanctions](https://www.reuters.com/business/aerospace-defense/us-issues-fresh-iran-related-sanctions-treasury-website-shows-2026-09-08/) — independent reporting on 36 designations, covered aviation networks and the administration's pressure rationale
- [Associated Press — U.S. targets remaining parts of Iran aviation sector](https://apnews.com/article/59b9b99d8dbb6dfbb519af565c995c85) — independent reporting on the implemented aviation-sector sanctions, foreign logistics providers and Treasury's stated explanation
- [Federal Register — Iranian Transactions and Sanctions Regulations, 91 FR 57511](https://www.federalregister.gov/documents/2026/09/10/2026-18461/iranian-transactions-and-sanctions-regulations) — primary final rule; indefinite stay effective September 8

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
