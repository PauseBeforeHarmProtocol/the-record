# Trump notifies Congress that Rwanda and South Africa will lose AGOA preferences

**Entry ID:** NAT-2026-11-02-002
**Date:** November 2, 2026
**Checked:** 2026-11-02 6:09 PM EST
**Evidence state:** official USTR notification announcement and eligibility rationale, independently corroborated by Associated Press and Reuters; notice and future effective date documented, implementation, country responses and economic outcomes not yet measured
**Review state:** current-standard-reviewed

The completed notification announces termination from the duty-free program on January 1, 2027; the trade change is scheduled, not yet in force.

## THE FACTS

- The Office of the U.S. Trade Representative announced on November 2 that President Trump notified Congress and the governments of Rwanda and South Africa of his intent to terminate their eligibility for African Growth and Opportunity Act trade preferences as of January 1, 2027. The notification and announced decision are complete; duty-free treatment had not yet ended at the cutoff.
- USTR says its annual interagency review found both governments engaged in practices inconsistent with AGOA eligibility. It identified trade and investment barriers, rule-of-law, political-pluralism, worker-rights, human-rights and national-security or foreign-policy concerns for Rwanda; for South Africa it identified trade barriers, corruption and national-security or foreign-policy concerns. The announcement did not provide a transaction-level evidentiary record for every stated concern.
- Associated Press and Reuters independently reported the scheduled suspension. AP explains that AGOA has offered eligible African countries duty-free U.S. access for specified products since 2000 and that countries may regain eligibility after meeting the criteria. Reuters reports South Africa was the program’s largest beneficiary, with about $1.7 billion in 2025 exports under AGOA; that is reported trade context, not a forecast of the suspension’s net economic effect.
- South African officials had said they were preparing for a negative review while remaining open to dialogue and would not surrender sovereignty to U.S. demands. USTR says the administration is working with partners toward compliance. Those are the strongest documented response and reinstatement path; no reinstatement terms, completed tariff collections, measured price effect or Rwandan government response was verified by cutoff.

## SIGNIFICANCE

The notification schedules a material change in U.S. tariff treatment for two national trading partners and can affect exporters, U.S. importers and bilateral relations. Its implementation and impact must be measured after January 1 through customs treatment, trade flows, prices, employment and any reinstatement process rather than treating the announcement as an already collected tariff.

## GOALPOST / RESPONSE

The administration says annual eligibility review found persistent noncompliance involving trade barriers and governance, rights or foreign-policy criteria and says it is seeking corrective steps. South Africa says it is open to dialogue but rejects demands it views as infringing sovereignty. Those positions do not independently prove each predicate or forecast the policy’s effects.

## MAYBE / THEREFORE

Maybe suspending preferences will create leverage for eligibility reforms, or it may disrupt trade without producing the requested policy changes and may shift commerce elsewhere. Therefore the record establishes formal notice of a January 1, 2027 termination decision—not present-day suspension, completed tariff collection, a quantified economic outcome or permanent exclusion from AGOA.


## SOURCES

- [USTR — Trump notifies Congress of intent to terminate Rwanda and South Africa from AGOA](https://ustr.gov/about/policy-offices/press-office/press-releases/2026/october/ambassador-greer-issues-statement-president-trumps-intent-terminate-rwanda-and-south-africa-agoa) — primary formal trade-preference announcement and eligibility-review statement
- [AP — Trump administration will cut South Africa and Rwanda from AGOA](https://apnews.com/article/5b18b1db8995fec67b28b9680d9d8424) — independent report on notification, effective date, program scope and responses
- [Reuters — U.S. to suspend South Africa and Rwanda from duty-free trade access](https://malaysia.news.yahoo.com/us-suspend-south-africa-rwanda-170206342.html) — independent report on announced AGOA suspension and eligibility grounds

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
