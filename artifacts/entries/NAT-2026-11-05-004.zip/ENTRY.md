# Trump designates the Oval Office complex a national monument

**Entry ID:** NAT-2026-11-05-004
**Date:** November 5, 2026
**Checked:** 2026-11-06 12:07 AM EST
**Evidence state:** signed White House proclamation corroborated by Associated Press and Reuters; designation established and management work ordered, implementation and durability pending
**Review state:** current-standard-reviewed

The signed proclamation creates preservation-management duties for four West Wing rooms while retaining presidential authority to redecorate and make ordinary operational changes.

## THE FACTS

- President Trump signed an Antiquities Act proclamation establishing the Oval Office National Monument. Its boundaries include the Oval Office (Room 110), the Outer Oval Office (Rooms 106 and 108) and the Cabinet Room (Room 105).
- The proclamation directs the Interior secretary, through the National Park Service, to develop and implement a management plan; require documentation, review and consideration of alternatives before substantial alteration or demolition; evaluate proposed changes for consistency with the monument's national significance; and coordinate with White House preservation advisers.
- The text expressly preserves presidential authority to redecorate, select furnishings and make ordinary operational or security modifications that do not substantially impair the historic structure. It also says it does not alter existing White House exemptions under the National Historic Preservation Act or diminish Congress's authority over federal property.
- Trump told reporters that major modifications would require congressional approval. Associated Press noted that the proclamation itself contains no such approval requirement and could be reversed by a successor; Reuters independently reported the signing and Trump's statement. No management plan, congressional ratification or tested enforcement outcome was established by cutoff.

## SIGNIFICANCE

The proclamation uses Antiquities Act authority to place four working White House rooms under a monument-management framework and creates procedural duties before major structural change. Its practical durability is uncertain because ordinary presidential changes remain allowed and a successor, Congress or a court could alter the framework.

## GOALPOST / RESPONSE

The administration says the designation will preserve the rooms' historic character for future generations. The operative tests are the management plan, documented review of any major alteration, treatment by Congress and courts, and whether later presidents keep, modify or revoke the designation—not claims that the text makes every change impossible.

## MAYBE / THEREFORE

Maybe the designation creates a durable preservation check on demolition or substantial alteration, or its retained presidential flexibility and reversibility may make the protection largely procedural. Therefore the signed designation and management directions are established; congressional ratification, an absolute bar on changes and long-term preservation effects are not.


## SOURCES

- [White House — proclamation establishing the Oval Office National Monument](https://www.whitehouse.gov/presidential-actions/2026/11/establishment-of-the-oval-office-national-monument/) — primary signed proclamation under the Antiquities Act defining the monument and preservation-management directions
- [Associated Press — Oval Office national-monument proclamation and limits](https://apnews.com/article/168f569a40f9594d0a836a16923d3f61) — independent reporting on the signed proclamation, retained presidential flexibility and reversibility
- [Reuters — Trump signs Oval Office and Cabinet Room national-monument document](https://malaysia.news.yahoo.com/trump-says-oval-office-become-212350732.html) — independent wire report on the signing and Trump's separate congressional-approval statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
