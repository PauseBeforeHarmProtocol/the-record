# Trump renews request for a $350 billion defense reconciliation bill

**Entry ID:** NAT-2026-11-12-008
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:06 PM EST
**Evidence state:** Primary Trump statement, Senate Budget documents and Senator Kennedy statement, with independent CSIS procedural analysis; proposal renewed, legislative and spending implementation incomplete
**Review state:** current-standard-reviewed

The president urged Senate leaders to move the administration’s defense package, but Congress had not adopted the necessary resolution, released bill text or appropriated the money by cutoff.

## THE FACTS

- At 12:24:53 p.m. EST on November 12, Trump published a Truth Social post calling on Senate Republican leaders to move immediately on a $350 billion military reconciliation bill. The post establishes that he renewed the request; it does not enact spending or independently verify the claims used to support it.
- A Senate Budget Committee fact sheet says the administration requested $1.5 trillion in total fiscal 2027 defense funding, including $350 billion through reconciliation. The committee’s August resolution was described as a budget blueprint that could unlock later reconciliation legislation, not as the final spending law.
- Senator John Kennedy publicly urged Republicans on November 11 to pursue a reconciliation bill of at least $200 billion and said the process could begin the following week. His proposal and Trump’s larger request did not identify enacted accounts or a final legislative text.
- Center for Strategic and International Studies analysis said House and Senate budget-resolution versions contemplated only $60 billion in reconciliation instructions for defense, that the Senate had not voted on its resolution and that committees would still have to compile and pass legislation under a tight schedule.
- By the final cutoff, no adopted Senate budget resolution, reconciled bill text, enacted appropriation or obligation of the requested $350 billion was located. The evidence status is an announced and renewed formal presidential request, not ordered or implemented spending.

## SIGNIFICANCE

A $350 billion reconciliation package would be a major expansion of defense funding and would use a fast-track process that limits the filibuster. The difference between the administration’s request and the smaller congressional instructions, plus the incomplete budget process, makes legislative status central to assessing fiscal and military consequences.

## GOALPOST / RESPONSE

Trump says immediate defense investment is needed; congressional proponents say reconciliation can strengthen readiness and support service members. The tests are an adopted budget resolution, committee instructions, public bill text and scoring, account-level allocations, Senate and House passage, presidential signature, obligations, procurement milestones and independently measured readiness or security outcomes.

## MAYBE / THEREFORE

Maybe Congress will assemble a package approaching the president’s request, or procedural and intraparty constraints may reduce or defeat it. Therefore the record establishes a renewed $350 billion presidential proposal and an active congressional pathway—not enacted funding, a completed appropriation, a military order or measured readiness improvement.


## SOURCES

- [Trump Truth Social post requesting a $350 billion military reconciliation bill](https://truthsocial.com/@realDonaldTrump/117604633389956053) — primary presidential statement
- [FY 2027 Budget Resolution: Defense Fact Sheet](https://www.budget.senate.gov/imo/media/doc/pbr_fy27_defense_fact_sheet.pdf) — primary congressional document
- [Chairman Johnson Introduces FY27 Budget Resolution](https://www.budget.senate.gov/chairman/newsroom/press/chairman-johnson-introduces-fy27-budget-resolution-to-unlock-legislation-to-secure-elections-protect-servicemembers-support-americans/) — primary congressional release
- [Kennedy urges Republicans to pass a reconciliation bill](https://www.kennedy.senate.gov/2026/11/11/kennedy-urges-republicans-to-pass-a-reconciliation-bill-if-we-fail-we-fail-but-at-least-we-will-have-tried/) — primary congressional statement
- [FY 2027 Defense Funding: Potential Post-Midterm Outcomes](https://www.csis.org/analysis/fy-2027-defense-funding-potential-post-midterm-outcomes) — independent analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
