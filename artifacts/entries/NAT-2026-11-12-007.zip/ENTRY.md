# HHS funds ibogaine groundwork and opens rapid-acting mental-health research network

**Entry ID:** NAT-2026-11-12-007
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:06 PM EST
**Evidence state:** Primary HHS award and funding-opportunity announcement corroborated by Associated Press and Reuters reporting; awards announced, clinical authorization and effectiveness not established
**Review state:** current-standard-reviewed

The department awarded up to $4.9 million for regulatory and manufacturing work and announced a separate $20 million research opportunity, without authorizing patient treatment or an ibogaine trial.

## THE FACTS

- HHS announced awards of up to $4.9 million over five years to teams led by Mark Cuban Cost Plus Drug Company and Beond for regulatory, manufacturing and scientific groundwork related to possible ibogaine treatment for post-traumatic stress disorder.
- HHS explicitly said the awards do not fund patient treatment or human-subject research and do not authorize a clinical trial. Ibogaine is not FDA-approved for PTSD, so the action is research preparation rather than an approved therapy or measured treatment result.
- The agency also opened a separate $20 million Notice of Funding Opportunity for a Rapid-Acting Treatments for Mental Health Conditions network, with award selections expected in summer 2027. The notice is a funding opportunity, not a completed award.
- HHS said ibogaine can cause serious and potentially fatal heart-rhythm problems and that the funded work will address dose selection, safety, product standardization and regulatory requirements. The awardees plan to make research data openly available.
- HHS framed the initiative as an effort to accelerate promising approaches for veterans and others with severe mental-health conditions. Independent AP and Reuters reporting described both the federal support and the drug’s safety and regulatory limits.

## SIGNIFICANCE

The awards move federal psychedelic-drug policy from advocacy toward funded regulatory and manufacturing preparation, while the explicit limits matter: no patient has been treated under these awards and efficacy remains unproved. The separate network could broaden rapid-acting treatment research, but its grants have not yet been selected.

## GOALPOST / RESPONSE

HHS says the work may create a rigorous pathway for rapid-acting treatments while protecting safety. The tests are published protocols and manufacturing standards, FDA-authorized trials, independent safety monitoring, enrollment and adverse-event data, peer-reviewed outcomes, transparent costs and conflicts, and eventual evidence that benefits exceed cardiac and other risks.

## MAYBE / THEREFORE

Maybe the preparatory work will support a safe, testable ibogaine trial and a useful wider research network, or safety, manufacturing and efficacy problems may prevent clinical use. Therefore the record shows limited research awards and an open funding opportunity—not FDA approval, an authorized ibogaine trial, patient treatment or demonstrated PTSD benefit.


## SOURCES

- [HHS Advances Ibogaine PTSD Research and Rapid-Acting Mental Health Treatments](https://www.hhs.gov/press-room/hhs-advances-ibogaine-ptsd-research-rapid-acting-mental-health-treatments.html) — primary government release
- [US government funds ibogaine research for PTSD treatments](https://apnews.com/article/abe4a325930898ba2de42fea3a6ad4c2) — independent reporting
- [US to fund new research into psychedelic drug ibogaine for veterans with PTSD](https://www.reuters.com/legal/litigation/us-fund-new-research-into-psychedelic-drug-ibogaine-veterans-with-ptsd-2026-11-12/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
