# DOJ and Education settle UNC civil-rights investigations

**Entry ID:** NAT-2026-10-19-006
**Date:** October 19, 2026
**Checked:** 2026-10-19 6:00 PM EDT
**Evidence state:** official DOJ announcement describing the voluntary settlement's university-wide terms and closure of federal matters; agreement announced and monitoring period specified, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The voluntary university-wide agreement adds antisemitism controls, race-blind admissions and benefits rules, quarterly reporting and federal monitoring through 2028.

## THE FACTS

- The Justice and Education departments entered a voluntary settlement agreement with the University of North Carolina at Chapel Hill resolving an 18-month Justice Department compliance review and 18 active Education Department investigations under Title VI.
- Through December 31, 2028, UNC agreed to maintain policies addressing unlawful antisemitism, establish a Title VI coordinator, cover Jewish and Israeli students in its nondiscrimination policy, investigate complaints, train students and employees, add law-enforcement resources when warranted and prohibit identity-concealing face masks.
- UNC also agreed to maintain race-blind admissions, refrain from using race or analyzing racial data to alter student-body composition, avoid race-conscious bridge or pipeline partnerships, and apply race-blind rules to scholarships, financial aid, benefits and programming. It must appoint a Merit & Civil Rights Administrator and report relevant complaints quarterly.
- The administration says the agreement protects Jewish students and merit-based opportunity. The settlement is voluntary, keeps UNC eligible for federal funding and closes the identified federal matters; compliance, campus safety, admissions practices, speech effects and student outcomes remain to be measured.

## SIGNIFICANCE

The settlement imposes university-wide operational and reporting duties across admissions, scholarships, programming, campus discipline and protest-related security while ending 19 federal matters without litigation. Its effects reach beyond a single complaint and will depend on implementation, legal boundaries and monitoring through 2028.

## GOALPOST / RESPONSE

The administration says the agreement enforces Title VI, protects Jewish and Israeli students and restores color-blind treatment. Published policies, training records, complaint handling, admissions and aid practices, enforcement consistency, campus-safety evidence, protected-speech impacts and federal monitoring reports are the tests.

## MAYBE / THEREFORE

Maybe the agreement improves responses to unlawful harassment and prevents race discrimination, or broad restrictions on data, programs, masks and campus discipline may create implementation or speech disputes. Therefore UNC accepted binding monitoring and policy duties and the federal matters closed—not that every underlying allegation was adjudicated or that discrimination and antisemitism have already ended.


## SOURCES

- [Justice Department — UNC civil-rights settlement announcement](https://www.justice.gov/opa/pr/justice-department-announces-settlement-ending-antisemitism-and-race-discrimination-unc) — primary joint-agency account of the voluntary university-wide settlement and its terms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
