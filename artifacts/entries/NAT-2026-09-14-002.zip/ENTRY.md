# States and cities sue to block DHS's broader public-charge rule

**Entry ID:** NAT-2026-09-14-002
**Date:** September 14, 2026
**Checked:** 2026-09-14 11:58 AM EDT
**Evidence state:** primary Federal Register final rule and independent Reuters reporting of filed litigation; rule final with future effective date, allegations pending and no judicial relief established
**Review state:** current-standard-reviewed

Two lawsuits challenge a final rule scheduled to take effect September 18; filing the cases did not itself suspend the rule or decide their allegations.

## THE FACTS

- Reuters reported that 23 states and the District of Columbia filed one federal lawsuit in Manhattan and six cities and counties filed another, seeking to block the Department of Homeland Security's final public-charge rule before its September 18 effective date.
- The July 20 final rule rescinds the 2022 framework and restores broader case-by-case discretion in deciding whether certain applicants are likely to become primarily dependent on the government. It applies to covered admission applications made, and adjustment filings postmarked or submitted electronically, on or after September 18.
- Under the rule, receipt of means-tested public benefits on or after the effective date—including Medicaid and SNAP—may be considered in the totality of circumstances. Receipt alone is not outcome-determinative, and benefits received by family members generally are not considered unless those family members are themselves applying.
- The plaintiffs allege that DHS exceeded its authority, violated the Administrative Procedure Act and created unclear standards likely to chill lawful benefit use. Those are pleaded claims, not judicial findings. Reuters reported that DHS did not immediately respond to a request for comment.
- DHS says the 2022 rule was unduly restrictive, that the new framework better advances congressional intent and self-reliance, and that it does not change anyone's eligibility for public benefits. No injunction or merits ruling was identified by cutoff.

## SIGNIFICANCE

The litigation tests how far the executive branch may expand a consequential immigration-admissibility standard and whether the rule's discretion and benefit factors are adequately bounded. The scheduled effective date creates immediate planning consequences, but litigation alone does not halt implementation.

## GOALPOST / RESPONSE

DHS says the rule restores lawful discretion and promotes self-sufficiency without changing benefit eligibility. The challengers allege unlawful expansion and chilling effects. Injunction decisions, merits rulings, agency guidance, adjudication patterns, benefit-usage data and appellate review are the tests.

## MAYBE / THEREFORE

Maybe courts uphold a broader but individualized inquiry, or they may find that the rule exceeds statutory authority or is inadequately reasoned. Therefore the record establishes a final rule and two filed challenges—not an injunction, final invalidation, automatic denial based on one benefit or a proven nationwide chilling effect.


## SOURCES

- [Federal Register — Public Charge Ground of Inadmissibility final rule](https://www.federalregister.gov/documents/2026/07/20/2026-14539/public-charge-ground-of-inadmissibility) — primary final rule defining scope, factors, applicability and September 18 effective date
- [Reuters — states and cities sue to block Trump public-charge rule](https://www.reuters.com/legal/government/states-cities-sue-block-trump-immigration-rule-public-benefits-2026-09-14/) — independent legal reporting of two filed challenges, plaintiffs' allegations and procedural posture

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
