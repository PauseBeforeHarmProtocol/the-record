# MARAD immediately modernizes federal ship-financing rules

**Entry ID:** NAT-2026-08-28-004
**Date:** August 28, 2026
**Checked:** 2026-08-28 6:03 AM EDT
**Evidence state:** MARAD interim final rule in the Federal Register; regulatory revision implemented August 28, comments and later final-rule changes remain possible
**Review state:** current-standard-reviewed

The interim final Title XI rule cuts the application fee, restructures other charges, updates credit safeguards, and removes 14 of 34 regulatory sections.

## THE FACTS

- The Maritime Administration made an interim final revision to the federal Vessel and Shipyard Financing Program effective August 28, with public comments due October 27. Title XI provides full-faith-and-credit loan guarantees for U.S.-flag vessel construction and U.S. shipyard modernization.
- MARAD rewrote the regulations to implement statutory changes and current federal-credit practices, correct citations, move detailed terms into published application and loan documents, establish a way to prioritize applications for expedited review, and remove obsolete authorities such as financing for export vessels. Fourteen of the prior 34 regulatory sections were removed.
- The rule reduces the application fee from $5,000 to $1,000 and restructures the former investigation fee as a commitment fee, which MARAD says will lower upfront costs for larger projects. It also incorporates Office of Management and Budget credit safeguards intended to reduce taxpayer risk from borrower default.
- MARAD invoked the Administrative Procedure Act's good-cause exception to skip advance notice and make the rule immediately effective, saying the changes codify existing processes, statutes, and government-wide fiscal practices rather than impose new substantive public duties. The agency is nevertheless taking comments and says a later final rule may differ.

## SIGNIFICANCE

The rule changes access, pricing, processing, and risk controls for a federal loan-guarantee program that can shape domestic vessel construction and shipyard investment. Immediate effectiveness gives applicants lower entry costs now, while moving some terms from regulation into agency documents can also affect transparency and future administrative flexibility.

## GOALPOST / RESPONSE

MARAD says the 1978-era rules were obsolete, slowed applicants, and did not reflect modern credit standards; the lower fees and clearer process should improve participation and protect taxpayers. The countervailing question is whether immediate implementation and relocation of terms reduce public input or durable constraints. Application volumes, processing times, defaults, subsidy costs, loan terms, comments, and the final rule are the tests.

## MAYBE / THEREFORE

Maybe the revision is mainly overdue administrative housekeeping that makes a national ship-financing tool easier to use, or fee changes and off-code loan terms may materially redistribute access and agency discretion. Therefore the record reports an immediately effective interim final rule—not new appropriations, awarded guarantees, financed vessels, or demonstrated savings.


## SOURCES

- [MARAD — Vessel and Shipyard Financing regulatory revision](https://www.federalregister.gov/documents/2026/08/28/2026-17636/vessel-and-shipyard-financing-regulatory-revision) — primary immediately effective interim final Title XI financing rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
