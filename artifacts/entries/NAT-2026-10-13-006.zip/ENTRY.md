# CVS agrees to $315 million opioid-prescription settlement and DEA safeguards

**Entry ID:** NAT-2026-10-13-006
**Date:** October 13, 2026
**Checked:** 2026-10-13 5:56 PM EDT
**Evidence state:** primary Justice Department settlement announcement and terms plus independent Associated Press reporting and company response; civil resolution agreed, allegations not adjudicated and outcomes unmeasured
**Review state:** current-standard-reviewed

The civil resolution settles federal allegations without a liability finding and adds monitoring, reporting and prescriber-review requirements.

## THE FACTS

- CVS Pharmacy and related entities agreed to pay $315 million to resolve federal Controlled Substances Act and False Claims Act allegations covering October 17, 2013 through December 2, 2025. The Justice Department says CVS filled invalid controlled-substance prescriptions and sought federal-program payment for many of them.
- The settlement also includes a DEA memorandum requiring a hotline for employees and the public, proactive monitoring of pharmacy dispensing patterns and a process to evaluate prescribers suspected of illegal prescribing. The civil resolution implements payment and compliance obligations.
- The government alleged prescriptions lacked a legitimate medical purpose, included dangerous quantities, early fills and so-called trinity combinations, and that corporate metrics, staffing and warning-system policies contributed. Those are allegations only; Justice says there has been no determination of liability.
- CVS told Associated Press that its pharmacists are trained in safe and appropriate medication use, that it has implemented best-in-class programs, that it strongly disagrees with the lawsuit's claims and that the settlement admits no wrongdoing. Compliance performance and effects on unlawful dispensing have not yet been measured.

## SIGNIFICANCE

The settlement converts a long-running federal case into a large monetary resolution and prospective nationwide controls at a major pharmacy chain. It is a concrete enforcement outcome, but it does not adjudicate the allegations or establish that the required safeguards will reduce improper dispensing.

## GOALPOST / RESPONSE

Justice and DEA say the payment and monitoring safeguards protect patients and federal programs and strengthen controlled-substance compliance. Tests include payment, hotline operation, prescriber reviews, identified and prevented unlawful fills, federal-program recoveries, independent compliance findings and overdose or prescribing trends attributable to the measures.

## MAYBE / THEREFORE

Maybe the settlement's monitoring and reporting duties correct systemic dispensing weaknesses, or they may chiefly close disputed historical litigation without producing measurable safety gains. Therefore CVS accepted money and compliance obligations while denying wrongdoing—not a court finding that every allegation was true or proof of future effectiveness.


## SOURCES

- [Justice Department — CVS $315 million controlled-substance and false-claims settlement](https://www.justice.gov/opa/pr/cvs-agrees-pay-315m-illegally-filling-unlawful-opioid-prescriptions-and-submitting-false) — primary enforcement announcement and settlement terms
- [Associated Press — CVS agrees to $315 million opioid-prescription settlement](https://apnews.com/article/justice-department-cvs-opioids-40516dbb8534543be1c119b8b7772266) — independent settlement reporting and company response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
