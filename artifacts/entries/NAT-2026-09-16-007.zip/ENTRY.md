# Scientists file class action challenging NIH grant-screening system

**Entry ID:** NAT-2026-09-16-007
**Date:** September 16, 2026
**Checked:** 2026-09-17 12:01 PM EDT
**Evidence state:** plaintiff counsel case page plus independently inspected Reuters report; filed proposed class action, allegations unproven
**Review state:** current-standard-reviewed

Researchers challenge alleged viewpoint screening; the new filing is not a ruling or restored funding.

## THE FACTS

- Plaintiff counsel announced a September 16 proposed class action challenging NIH grant screening against administration-disfavored terms. The defendants include NIH, HHS and the U.S. DOGE Service.
- Counsel describes terminated, delayed or rewritten grants across dementia, HIV and other research. Reuters identifies the Northern District of California venue and reports the complaint’s allegation of 235 screening keywords. These remain allegations, not adjudicated findings.
- Reuters reported no immediate NIH or HHS response. In related disputes the administration says its changes prioritize sound science. No relief restoring grants or certifying this proposed class was established in the inspected material.

## SIGNIFICANCE

The case challenges screening across a funding system rather than only one award. Grant-level evidence will matter to both legality and consequences.

## GOALPOST / RESPONSE

The administration’s stated scientific-quality rationale must be assessed alongside plaintiffs’ viewpoint-discrimination claim. Government filings, screening criteria, award notices and court orders are the next evidence tests.

## MAYBE / THEREFORE

Maybe lawful priority setting explains particular decisions, or disclosed records substantiate prohibited viewpoint screening. Therefore a filed challenge and attributed researcher accounts are established—not a constitutional judgment or measured nationwide health harm.


## SOURCES

- [Protect Democracy — NIH grant-screening class-action case page](https://protectdemocracy.org/work/protecting-researchers-from-illegal-viewpoint-discrimination-by-the-government/) — plaintiff counsel case page identifying parties, complaint and asserted facts
- [Reuters — scientists challenge NIH grant screening](https://www.reuters.com/legal/government/scientists-challenge-us-nih-grant-screening-unconstitutional-2026-09-16/) — independent litigation reporting based on the filed complaint and party responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
