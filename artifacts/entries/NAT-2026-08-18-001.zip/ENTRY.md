# Agriculture Department proposes rescinding the Roadless Rule

**Entry ID:** NAT-2026-08-18-001
**Date:** August 18, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** official proposed rule described in independent reporting; public comment pending

The proposal would remove national restrictions on roadbuilding and timber harvest across nearly 59 million acres of national forest.

## THE FACTS

- The Agriculture Department proposed rescinding the 2001 Roadless Area Conservation Rule, which generally limits road construction, reconstruction, and timber harvesting in designated national-forest areas.
- The affected inventory covers nearly 59 million acres—about 30% of the National Forest System. The proposal would return more decisions to local forest managers and remained open for public comment through September 21.
- The administration says the change would improve wildfire management and local flexibility. Environmental groups say new roads can increase ignition risk, habitat fragmentation, logging, and long-term maintenance costs.

## SIGNIFICANCE

Rescission would replace one nationwide conservation floor with case-by-case management across an area larger than many states. Because this is a proposal, the accountability record must track comments, the final rule, litigation, and any later roads or timber projects rather than treating rescission as complete.

## GOALPOST / RESPONSE

The administration describes the rule as an obstacle to active forest management and economic use. Opponents argue that roadless protections preserve drinking water, habitat, recreation, and fire resilience. Those competing claims can be tested against the final rule's analysis and project-level outcomes.


## SOURCES

- [Reuters — proposal to rescind the Roadless Rule](https://www.reuters.com/legal/litigation/trump-administration-moves-rescind-rule-that-protects-millions-forest-acres-2026-08-18/) — independent reporting on an official proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
