# Trump orders Lake Ontario renamed ‘Lake America’ for U.S. federal use

**Entry ID:** NAT-2026-08-27-007
**Date:** August 27–September 14, 2026
**Checked:** 2026-09-14 11:59 PM EDT
**Evidence state:** signed White House order, implemented GNIS change, primary NWS phased-implementation notice, private-platform confirmations, independent reporting and Trump’s preserved post; federal rollout underway, completion and international acceptance unestablished
**Review state:** current-standard-reviewed

The federal name change reached NWS products through a phased implementation notice; the rollout remains incomplete and cannot bind Canada or international users.

## THE FACTS

- President Trump signed an executive order directing the Interior secretary and the U.S. Board on Geographic Names to rename Lake Ontario as ‘Lake America’ within 30 days, update the Geographic Names Information System, remove federal GNIS references to Lake Ontario, and guide federal agencies to use the new name in maps, contracts, documents, and communications.
- By August 30, Google said the Geographic Names Information System had formally changed the federal name. Google Maps then began showing ‘Lake America’ to U.S. users, ‘Lake Ontario’ to Canadian users, and both names elsewhere, consistent with Google's stated practice of following official government sources.
- By September 2, Associated Press independently confirmed that Apple Maps also showed ‘Lake America’ to U.S. users while continuing to show ‘Lake Ontario’ in Canada and elsewhere. Apple did not provide AP an explanation. President Trump cited the Apple label in a Truth Social post and described the change as complete, ratified and binding; the post proves that he made that statement, not that Canada or an international authority ratified the name.
- The order and GNIS change do not bind Canada, international bodies, New York State, private mapmakers, or other nonfederal users. Google and Apple's adoptions are voluntary platform decisions, not legal ratification of the order. Reuters reported that about 52% of the lake’s surface area is in Canada.
- The White House says the name honors U.S. protection, economic reliance, Coast Guard icebreaking, and nearly $4 billion in U.S. Great Lakes investment over the last decade. Canadian Prime Minister Mark Carney and New York Governor Kathy Hochul said they would continue to call it Lake Ontario, and the Wendat Nation’s Grand Chief criticized the erasure of the name’s Indigenous origin.
- On September 14, NWS Public Information Statement 26-69 said the agency was implementing Executive Order 14422 across online maps, weather products, websites and other materials. NWS described the rollout as phased, said it would avoid operational disruption and would issue service-change notices as needed. Trump later linked a report about the change on Truth Social; that post proves he published the statement, while the NWS notice independently establishes the agency action.

## SIGNIFICANCE

The federal database change now reaches operational weather maps, forecasts, websites and other NWS materials as well as two dominant private map platforms. That expands day-to-day federal usage without expanding the order’s legal reach or demonstrating Canadian or international acceptance.

## GOALPOST / RESPONSE

The administration says U.S. protection, investment, history and economic interests justify federal recognition as Lake America, and Trump points to platform and agency adoption as validation. The strongest response is that the lake is shared with Canada, its existing name has Indigenous roots and U.S. federal nomenclature cannot establish an internationally accepted name. Completion of NWS service changes, operational disruptions, costs, Canadian and state usage, private-platform practices and any litigation or diplomacy are the tests.

## MAYBE / THEREFORE

Maybe repeated labels in federal weather products and U.S.-market maps will normalize the new name domestically, or parallel federal and international naming may persist. Therefore the record now establishes a signed directive, GNIS change and phased NWS implementation—not completed conversion of every weather product, international ratification or authority to rename the lake for Canada.


## SOURCES

- [White House — executive order renaming Lake Ontario as Lake America for federal use](https://www.whitehouse.gov/presidential-actions/2026/08/honoring-the-american-history-of-the-great-lakes-and-renaming-lake-ontario-as-lake-america/) — primary signed executive order and federal implementation directive
- [Reuters — Trump orders federal Lake America name amid Canada trade dispute](https://www.reuters.com/world/us/trump-signs-order-rename-lake-ontario-lake-america-2026-08-27/) — independent reporting on the order's federal-only scope, geography, and Canadian, state, and Indigenous responses
- [Reuters — Google Maps adopts location-dependent Lake America labels](https://www.reuters.com/world/us/google-maps-will-show-lake-america-us-not-lake-ontario-2026-08-30/) — independent reporting on the implemented GNIS change, Google's map-label policy and continuing Canadian usage
- [CBS News — Google confirms GNIS-based Lake America map update](https://www.cbsnews.com/news/lake-america-trump-order-google-maps-lake-ontario/) — independent reporting quoting Google's implementation statement and describing the federal naming process
- [Associated Press — Apple Maps adopts Lake America for U.S. users](https://apnews.com/article/apple-lake-ontario-america-google-14abb66fe0ecfa05bffd42fb083dc70d) — independent confirmation of Apple's location-dependent label and the continued Lake Ontario label outside the United States
- [Donald Trump Truth Social post about Apple Maps and Lake America](https://truthsocial.com/@realDonaldTrump/posts/117203256670423247) — primary evidence that Trump published the statement; not independent verification of its legal or factual claims
- [National Weather Service — implementation of updated naming conventions under EO 14422](https://forecast.weather.gov/product.php?site=NWS&issuedby=WSH&product=PNS&format=txt&version=2&glossary=0) — primary Public Information Statement 26-69 announcing phased updates to maps, products, websites and materials
- [Hearst Connecticut Media — NWS begins Lake America product updates](https://www.ctinsider.com/weather/article/lake-ontario-lake-america-noaa-weather-maps-22431324.php) — independent reporting of phased NWS implementation and limits on federal usage
- [Donald Trump Truth Social post linking NWS Lake America report](https://truthsocial.com/@realDonaldTrump/117272909637512817) — primary evidence only that Trump published the linked statement; underlying implementation independently verified

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
