# Trump orders Lake Ontario renamed ‘Lake America’ for U.S. federal use

**Entry ID:** NAT-2026-08-27-007
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 PM EDT
**Evidence state:** signed White House executive order plus independent Reuters reporting on scope and responses; federal directive ordered, GNIS and agency implementation pending
**Review state:** current-standard-reviewed

The signed order gives Interior and the Board on Geographic Names 30 days to change federal maps and records; it does not control Canadian, international, state, or private usage.

## THE FACTS

- President Trump signed an executive order directing the Interior secretary and the U.S. Board on Geographic Names to rename Lake Ontario as ‘Lake America’ within 30 days, update the Geographic Names Information System, remove federal GNIS references to Lake Ontario, and guide federal agencies to use the new name in maps, contracts, documents, and communications.
- The order took effect as a presidential directive on August 27, but the federal database change remained due within 30 days at the checked time. It does not bind Canada, international bodies, New York State, private mapmakers, or other nonfederal users; Reuters reported that about 52% of the lake’s surface area is in Canada.
- The White House says the name honors U.S. protection, economic reliance, Coast Guard icebreaking, and nearly $4 billion in U.S. Great Lakes investment over the last decade. Canadian Prime Minister Mark Carney and New York Governor Kathy Hochul said they would continue to call it Lake Ontario, and the Wendat Nation’s Grand Chief criticized the erasure of the name’s Indigenous origin.

## SIGNIFICANCE

The order uses federal naming authority to alter official U.S. treatment of a shared international landmark during a trade dispute with Canada. Its direct legal effect is limited to the federal government, but it creates administrative costs, tests the symbolic reach of presidential authority, and can deepen diplomatic and Indigenous-relations tensions.

## GOALPOST / RESPONSE

The administration says the United States’ protection, investment, history, and economic stake justify federal recognition as Lake America. The strongest response is that the lake is shared with Canada, its existing name has Indigenous roots, and federal nomenclature cannot establish an internationally accepted name. GNIS implementation, agency compliance, costs, Canadian and state usage, treaty or diplomatic effects, and any legal challenge are the tests.

## MAYBE / THEREFORE

Maybe the change will remain largely symbolic outside federal documents, or repeated federal use may gradually influence private maps and public language. Therefore the record reports a signed and binding federal directive with implementation due within 30 days—not a power to rename the lake for Canada or the world and not a completed GNIS update at the checked time.


## SOURCES

- [White House — executive order renaming Lake Ontario as Lake America for federal use](https://www.whitehouse.gov/presidential-actions/2026/08/honoring-the-american-history-of-the-great-lakes-and-renaming-lake-ontario-as-lake-america/) — primary signed executive order and federal implementation directive
- [Reuters — Trump orders federal Lake America name amid Canada trade dispute](https://www.reuters.com/world/us/trump-signs-order-rename-lake-ontario-lake-america-2026-08-27/) — independent reporting on the order's federal-only scope, geography, and Canadian, state, and Indigenous responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
