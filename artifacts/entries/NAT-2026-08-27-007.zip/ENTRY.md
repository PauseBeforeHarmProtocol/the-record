# Trump orders Lake Ontario renamed ‘Lake America’ for U.S. federal use

**Entry ID:** NAT-2026-08-27-007
**Date:** August 27–30, 2026
**Checked:** 2026-08-30 12:03 PM EDT
**Evidence state:** signed White House executive order, Google's on-record GNIS-based implementation statement, CBS reporting, and independent Reuters reporting; federal GNIS change implemented and one private platform adopted location-dependent labels
**Review state:** current-standard-reviewed

The federal GNIS name change is now implemented, and Google adopted location-dependent map labels; Canadian, international, state, and private usage remains outside the order's control.

## THE FACTS

- President Trump signed an executive order directing the Interior secretary and the U.S. Board on Geographic Names to rename Lake Ontario as ‘Lake America’ within 30 days, update the Geographic Names Information System, remove federal GNIS references to Lake Ontario, and guide federal agencies to use the new name in maps, contracts, documents, and communications.
- By August 30, Google said the Geographic Names Information System had formally changed the federal name. Google Maps then began showing ‘Lake America’ to U.S. users, ‘Lake Ontario’ to Canadian users, and both names elsewhere, consistent with Google's stated practice of following official government sources.
- The order and GNIS change do not bind Canada, international bodies, New York State, private mapmakers, or other nonfederal users. Google's adoption is a voluntary platform decision, not a legal consequence of the order. Reuters reported that about 52% of the lake’s surface area is in Canada.
- The White House says the name honors U.S. protection, economic reliance, Coast Guard icebreaking, and nearly $4 billion in U.S. Great Lakes investment over the last decade. Canadian Prime Minister Mark Carney and New York Governor Kathy Hochul said they would continue to call it Lake Ontario, and the Wendat Nation’s Grand Chief criticized the erasure of the name’s Indigenous origin.

## SIGNIFICANCE

The completed federal database change now affects official U.S. records and has already influenced a major private map platform. Its legal effect remains limited to the federal government, but the platform adoption expands its practical visibility while leaving international acceptance unresolved.

## GOALPOST / RESPONSE

The administration says the United States’ protection, investment, history, and economic stake justify federal recognition as Lake America. The strongest response is that the lake is shared with Canada, its existing name has Indigenous roots, and federal nomenclature cannot establish an internationally accepted name. Agency compliance, costs, other mapmakers' choices, Canadian and state usage, treaty or diplomatic effects, and any legal challenge are the tests.

## MAYBE / THEREFORE

Maybe location-dependent digital labels will make the change familiar in the United States, or users outside federal systems may continue treating Lake Ontario as the controlling international name. Therefore the record reports a signed directive and implemented U.S. GNIS change that Google voluntarily reflected—not authority to rename the lake for Canada or the world and not universal private adoption.


## SOURCES

- [White House — executive order renaming Lake Ontario as Lake America for federal use](https://www.whitehouse.gov/presidential-actions/2026/08/honoring-the-american-history-of-the-great-lakes-and-renaming-lake-ontario-as-lake-america/) — primary signed executive order and federal implementation directive
- [Reuters — Trump orders federal Lake America name amid Canada trade dispute](https://www.reuters.com/world/us/trump-signs-order-rename-lake-ontario-lake-america-2026-08-27/) — independent reporting on the order's federal-only scope, geography, and Canadian, state, and Indigenous responses
- [Reuters — Google Maps adopts location-dependent Lake America labels](https://www.reuters.com/world/us/google-maps-will-show-lake-america-us-not-lake-ontario-2026-08-30/) — independent reporting on the implemented GNIS change, Google's map-label policy and continuing Canadian usage
- [CBS News — Google confirms GNIS-based Lake America map update](https://www.cbsnews.com/news/lake-america-trump-order-google-maps-lake-ontario/) — independent reporting quoting Google's implementation statement and describing the federal naming process

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
