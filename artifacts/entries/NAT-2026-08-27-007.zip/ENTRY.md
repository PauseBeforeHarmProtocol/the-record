# Trump orders Lake Ontario renamed ‘Lake America’ for U.S. federal use

**Entry ID:** NAT-2026-08-27-007
**Date:** August 27–September 2, 2026
**Checked:** 2026-09-02 6:02 PM EDT
**Evidence state:** signed White House executive order, Google's on-record GNIS-based implementation statement, independent Reuters and Associated Press reporting, and Trump's preserved Truth Social statement; federal GNIS change and two private U.S.-market label changes implemented, international acceptance unestablished
**Review state:** current-standard-reviewed

The federal GNIS name change is implemented, and Google and Apple now use location-dependent labels; neither private platform choice makes the name binding on Canada or internationally.

## THE FACTS

- President Trump signed an executive order directing the Interior secretary and the U.S. Board on Geographic Names to rename Lake Ontario as ‘Lake America’ within 30 days, update the Geographic Names Information System, remove federal GNIS references to Lake Ontario, and guide federal agencies to use the new name in maps, contracts, documents, and communications.
- By August 30, Google said the Geographic Names Information System had formally changed the federal name. Google Maps then began showing ‘Lake America’ to U.S. users, ‘Lake Ontario’ to Canadian users, and both names elsewhere, consistent with Google's stated practice of following official government sources.
- By September 2, Associated Press independently confirmed that Apple Maps also showed ‘Lake America’ to U.S. users while continuing to show ‘Lake Ontario’ in Canada and elsewhere. Apple did not provide AP an explanation. President Trump cited the Apple label in a Truth Social post and described the change as complete, ratified and binding; the post proves that he made that statement, not that Canada or an international authority ratified the name.
- The order and GNIS change do not bind Canada, international bodies, New York State, private mapmakers, or other nonfederal users. Google and Apple's adoptions are voluntary platform decisions, not legal ratification of the order. Reuters reported that about 52% of the lake’s surface area is in Canada.
- The White House says the name honors U.S. protection, economic reliance, Coast Guard icebreaking, and nearly $4 billion in U.S. Great Lakes investment over the last decade. Canadian Prime Minister Mark Carney and New York Governor Kathy Hochul said they would continue to call it Lake Ontario, and the Wendat Nation’s Grand Chief criticized the erasure of the name’s Indigenous origin.

## SIGNIFICANCE

The completed federal database change now affects official U.S. records and has influenced two dominant private map platforms. Those location-dependent labels expand the name's practical visibility without expanding the order's legal reach or demonstrating Canadian or international acceptance.

## GOALPOST / RESPONSE

The administration says the United States’ protection, investment, history, and economic stake justify federal recognition as Lake America, and Trump now points to Apple Maps as validation. The strongest response is that the lake is shared with Canada, its existing name has Indigenous roots, and federal nomenclature or private U.S.-market labels cannot establish an internationally accepted name. Agency compliance, costs, platform practices, Canadian and state usage, treaty or diplomatic effects, and any legal challenge are the tests.

## MAYBE / THEREFORE

Maybe repeated U.S.-only digital labels will make the new name familiar domestically, or users outside federal systems may continue treating Lake Ontario as the controlling international name. Therefore the record reports a signed directive, implemented U.S. GNIS change and voluntary Google and Apple label changes—not international ratification, authority to rename the lake for Canada or proof that Trump's broader claim is binding.


## SOURCES

- [White House — executive order renaming Lake Ontario as Lake America for federal use](https://www.whitehouse.gov/presidential-actions/2026/08/honoring-the-american-history-of-the-great-lakes-and-renaming-lake-ontario-as-lake-america/) — primary signed executive order and federal implementation directive
- [Reuters — Trump orders federal Lake America name amid Canada trade dispute](https://www.reuters.com/world/us/trump-signs-order-rename-lake-ontario-lake-america-2026-08-27/) — independent reporting on the order's federal-only scope, geography, and Canadian, state, and Indigenous responses
- [Reuters — Google Maps adopts location-dependent Lake America labels](https://www.reuters.com/world/us/google-maps-will-show-lake-america-us-not-lake-ontario-2026-08-30/) — independent reporting on the implemented GNIS change, Google's map-label policy and continuing Canadian usage
- [CBS News — Google confirms GNIS-based Lake America map update](https://www.cbsnews.com/news/lake-america-trump-order-google-maps-lake-ontario/) — independent reporting quoting Google's implementation statement and describing the federal naming process
- [Associated Press — Apple Maps adopts Lake America for U.S. users](https://apnews.com/article/apple-lake-ontario-america-google-14abb66fe0ecfa05bffd42fb083dc70d) — independent confirmation of Apple's location-dependent label and the continued Lake Ontario label outside the United States
- [Donald Trump Truth Social post about Apple Maps and Lake America](https://truthsocial.com/@realDonaldTrump/posts/117203256670423247) — primary evidence that Trump published the statement; not independent verification of its legal or factual claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
