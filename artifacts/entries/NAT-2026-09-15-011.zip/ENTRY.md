# Justice Department charges five alleged Russian intelligence network members

**Entry ID:** NAT-2026-09-15-011
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:29 AM EDT
**Evidence state:** primary Justice Department charging announcement plus Reuters reporting; formal charges filed, all defendants reported at large, allegations unproven, and the mismatched purported-indictment attachment excluded
**Review state:** current-standard-reviewed

The indictment alleges terrorism financing and two murder-for-hire plots; all five defendants remained at large and the allegations were unproven.

## THE FACTS

- The Justice Department announced federal charges against five people it described as members of a Russian intelligence services network. All five were charged with conspiracy to finance terrorism, and three were additionally charged with conspiracy to commit murder for hire.
- DOJ alleged that the network surveilled targets and offered payments of $40,000 and $25,000 in separate plots. Those allegations come from the charging case and have not been proved at trial.
- Reuters reported that all five defendants remained at large. The charging announcement therefore establishes an initiated federal prosecution, not arrests, extraditions, guilty pleas, convictions or completed disruption of the alleged network.
- The defendants are presumed innocent unless proved guilty. No defense response, evidentiary hearing, trial record or judicial finding resolving the government's allegations was public by cutoff.
- DOJ's press page linked an item labeled as the indictment, but the retrieved attachment resolved to an unrelated department equal-employment-opportunity policy. The archive therefore used the press release and Reuters report, not that mismatched attachment, and does not claim independent inspection of the indictment text.

## SIGNIFICANCE

The charges represent a formal U.S. counterintelligence and counterterrorism response to alleged Russian-directed violence on American soil. Their evidentiary and operational significance remains contingent because the defendants were at large and the underlying allegations had not been tested in court.

## GOALPOST / RESPONSE

DOJ says the prosecution protects U.S. residents from foreign intelligence-directed violence and terrorism financing. Arrests or extraditions, a correctly published indictment, discovery, defense responses, judicial rulings, pleas or trials and evidence about command links and disrupted capability are the tests.

## MAYBE / THEREFORE

Maybe later proceedings substantiate a coordinated Russian intelligence network and disrupt it, or the evidence and attribution may be narrowed or contested. Therefore the record establishes filed charges and the government's allegations—not guilt, custody, a proven Kremlin command chain, successful prevention of every plot or a completed prosecution.


## SOURCES

- [Justice Department — five alleged Russian intelligence network members charged](https://www.justice.gov/opa/pr/members-russian-intelligence-services-network-charged-conspiring-finance-terrorism-and) — primary charging announcement; allegations are unproven and the linked indictment attachment was not used because it resolved to an unrelated DOJ EEO policy
- [Reuters — U.S. charges five people in alleged Russian-backed murder plots](https://www.reuters.com/legal/government/us-charges-5-people-alleged-russian-backed-murder-plots-2026-09-16/) — independent reporting on the filed charges, alleged payments and defendants' at-large status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
