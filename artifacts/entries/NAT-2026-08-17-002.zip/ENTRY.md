# Interior proposes a 67-million-acre seabed-mining auction near the Northern Mariana Islands

**Entry ID:** NAT-2026-08-17-002
**Date:** August 17, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** official proposed auction described in independent reporting; no leases awarded
**Review state:** current-standard-reviewed

The proposed December lease sale would open exploration and potential development in U.S. Pacific waters; it has not yet been finalized.

## THE FACTS

- The Interior Department's Marine Minerals Administration proposed a December 16 competitive lease auction covering about 67 million acres of seabed east and west of the Northern Mariana Islands.
- The proposed leases would allow exploration and potential development of critical-mineral deposits used in batteries, electronics, and defense technologies.
- The agency said it would consider comments from the territory's governor before deciding whether to proceed. Governor David Apatang had requested more information about environmental effects, and environmental groups say deep-sea ecosystem risks remain insufficiently understood.

## SIGNIFICANCE

This would commit a vast marine area to a new extractive industry before the environmental consequences are well characterized. Territorial consultation, federal authority, lease terms, and ecosystem monitoring are therefore part of the decision—not afterthoughts to it.

## GOALPOST / RESPONSE

The administration frames seabed mining as supply-chain and national-security policy that can reduce dependence on foreign critical minerals. Supporters have not yet demonstrated that the proposed sale's economic and security benefits outweigh ecological uncertainty or that consultation will materially shape the final decision.

## MAYBE / THEREFORE

Maybe a lease sale could diversify critical-mineral supply, and exploration could generate information before any development decision. Therefore the proposal should be evaluated on separate tracks: documented contributions to supply security and economics; the adequacy and responsiveness of territorial consultation; baseline and ongoing ecological measurement; and whether lease terms prevent or remedy harm. No benefit claim cancels an unmeasured environmental risk.


## SOURCES

- [Reuters — proposed seabed-mining auction near Northern Mariana Islands](https://www.reuters.com/legal/litigation/us-proposes-seabed-mining-auction-off-northern-mariana-islands-2026-08-17/) — independent reporting on an official proposed auction

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
