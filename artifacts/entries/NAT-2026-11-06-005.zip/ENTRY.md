# DOJ closes Fox–Roku antitrust investigation as $22 billion acquisition completes

**Entry ID:** NAT-2026-11-06-005
**Date:** November 6, 2026
**Checked:** 2026-11-07 12:07 PM EST
**Evidence state:** primary DOJ antitrust closing statement and commitments plus independent Reuters and Washington Post reporting on completion; investigation closed and transaction completed, future conduct and competitive effects unresolved
**Review state:** current-standard-reviewed

The Antitrust Division found substantial competitive harm unlikely and recorded three-year platform commitments; the public statement does not establish a consent decree or measured post-merger compliance.

## THE FACTS

- DOJ's Antitrust Division said it investigated Fox's approximately $22 billion acquisition of Roku, issued second requests and examined competition among free, ad-supported streaming providers and whether Fox could use control of Roku's platform to disadvantage rival content.
- The division concluded that entry by other free, ad-supported streaming providers and Roku's dependence on broad content made a substantial risk of harm unlikely. It closed the investigation while saying it would continue evaluating competition and could act if facts or circumstances change.
- DOJ said Fox committed for at least three years to continue carrying non-Fox content, avoid discrimination against non-Fox content in search, provide data products on commercially reasonable terms and maintain contractual data firewalls. The inspected statement did not identify a filed consent decree, penalty schedule or independent monitor, so enforceability and compliance remain to be tested.
- Reuters and The Washington Post reported that Fox completed the cash-and-stock acquisition on November 6. Reuters reported that Roku's platform reached more than 100 million households. Completion establishes the ownership change, not whether the commitments prevent discrimination or preserve competition over time.

## SIGNIFICANCE

The closure allowed a major media company to acquire a leading connected-TV platform and a large advertising-distribution channel without a government challenge. The competitive consequences depend on platform conduct, entry, data access, carriage, advertising markets and the practical force of Fox's commitments.

## GOALPOST / RESPONSE

DOJ says platform switching, new entry and Roku's need for broad content make competitive harm unlikely; Fox says Roku will remain open and neutral. The tests are carriage and search treatment, data terms, firewall compliance, platform switching, advertising prices, entry, complaints and any renewed enforcement.

## MAYBE / THEREFORE

Maybe Roku's commercial incentives and Fox's commitments preserve an open platform, or vertical ownership may create subtler advantages that emerge after the review closes. Therefore DOJ closed the investigation and the acquisition completed—not that future discrimination is impossible or that the commitments have already been tested.


## SOURCES

- [DOJ Antitrust Division — closing of Fox–Roku merger investigation](https://www.justice.gov/opa/pr/statement-department-justice-antitrust-division-closing-its-investigation-merger-fox-and) — primary antitrust investigation closing statement and company commitments
- [Reuters — Fox completes $22 billion Roku acquisition](https://www.reuters.com/legal/transactional/fox-completes-22-billion-roku-deal-expand-digital-reach-2026-11-06/) — independent reporting on transaction completion, value and platform reach
- [Washington Post — Fox closes Roku deal after DOJ investigation](https://www.washingtonpost.com/business/2026/11/06/fox-closes-22b-deal-buy-roku-transaction-that-will-remake-streaming/) — independent reporting on closing, DOJ review and Fox commitments

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
