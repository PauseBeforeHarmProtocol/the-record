# Justice Department sues four states over in-state tuition laws

**Entry ID:** NAT-2026-08-27-008
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 PM EDT
**Evidence state:** DOJ announcement and four filed federal complaints; lawsuits filed and relief requested, state responses and judicial rulings pending
**Review state:** current-standard-reviewed

The filed complaints seek to block tuition and financial-aid provisions in Arizona, New Mexico, Oregon, and Washington; no court has ruled on the new cases.

## THE FACTS

- The Justice Department filed four federal lawsuits against Arizona, New Mexico, Oregon, and Washington, challenging state laws and regulations that provide in-state tuition or financial assistance to some students who are not lawfully present in the United States. The complaints were filed court actions, but their factual and legal claims had not been adjudicated at the checked time.
- The United States asks the courts to declare the challenged provisions unlawful and enjoin their enforcement. DOJ argues that the state benefits conflict with federal restrictions and disadvantage U.S. citizens who do not qualify for the same rates or assistance; the state policies remain in effect unless a court orders otherwise or the states change them.
- DOJ says these filings bring its total number of state in-state-tuition challenges to 21 and cites favorable orders in five earlier cases. That total describes lawsuits filed by the administration, not 21 final judgments or 21 laws already invalidated.

## SIGNIFICANCE

The coordinated filings expand a nationwide federal litigation campaign against state higher-education benefits for undocumented students. The cases test the boundary between federal immigration law and state control of tuition and aid, with potential consequences for students, public colleges, state budgets, and similarly structured laws elsewhere.

## GOALPOST / RESPONSE

DOJ says Congress barred states from offering immigration-status-based postsecondary benefits that are unavailable to U.S. citizens and that injunctions are necessary to enforce federal supremacy. States and policy supporters have argued in related cases that eligibility is based on state residence or school attendance and can also be available to U.S. citizens meeting the same criteria. Pleadings, state responses, preliminary relief, merits rulings, appeals, and enrollment and aid effects are the tests.

## MAYBE / THEREFORE

Maybe the new complaints will produce settlements or injunctions like some earlier cases, or courts may distinguish the four states’ eligibility rules and reject some or all federal claims. Therefore the record counts four filed lawsuits and preserves DOJ’s 21-case total as its litigation tally—not as proof that the challenged policies are unconstitutional or already blocked.


## SOURCES

- [Justice Department — four lawsuits challenging state in-state tuition laws](https://www.justice.gov/opa/pr/department-justice-files-complaints-against-arizona-new-mexico-oregon-and-washington) — official litigation announcement, requested relief, and administration explanation
- [United States v. Arizona — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459406/dl?inline=) — primary federal court complaint
- [United States v. New Mexico — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459386/dl?inline=) — primary federal court complaint
- [United States v. Oregon — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459396/dl?inline=) — primary federal court complaint
- [United States v. Washington — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459401/dl?inline=) — primary federal court complaint

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
