# Justice Department expands in-state-tuition litigation campaign to Penn State

**Entry ID:** NAT-2026-08-27-008
**Date:** August 27–November 5, 2026
**Checked:** 2026-11-05 12:05 PM EST
**Evidence state:** original Penn State complaint and DOJ announcement, alongside the earlier four filed complaints; litigation filed and relief requested, response and judicial ruling pending
**Review state:** current-standard-reviewed

A filed complaint challenges Penn State's undocumented-student tuition policy; DOJ counts 27 cases, but the new allegations and requested injunction have not been adjudicated.

## THE FACTS

- The Justice Department filed four federal lawsuits against Arizona, New Mexico, Oregon, and Washington, challenging state laws and regulations that provide in-state tuition or financial assistance to some students who are not lawfully present in the United States. The complaints were filed court actions, but their factual and legal claims had not been adjudicated at the checked time.
- The United States asks the courts to declare the challenged provisions unlawful and enjoin their enforcement. DOJ argues that the state benefits conflict with federal restrictions and disadvantage U.S. citizens who do not qualify for the same rates or assistance; the state policies remain in effect unless a court orders otherwise or the states change them.
- DOJ says these filings bring its total number of state in-state-tuition challenges to 21 and cites favorable orders in five earlier cases. That total describes lawsuits filed by the administration, not 21 final judgments or 21 laws already invalidated.
- On November 5, DOJ filed United States v. Pennsylvania State University and its Board of Trustees, Civil Action No. 26-cv-6000, in the Middle District of Pennsylvania. The complaint alleges that Penn State's undocumented-student policy makes some undocumented Pennsylvania residents eligible for in-state tuition while out-of-state U.S. citizens pay nonresident rates, and seeks declaratory and permanent injunctive relief under 8 U.S.C. sections 1621 and 1623. These are filed allegations and requested remedies, not a court ruling.
- DOJ says the Penn State filing brings its in-state-tuition litigation total to 27 and cites favorable orders in Texas, Kentucky, Oklahoma, Nebraska, Illinois and Kansas. That is the department's campaign tally and characterization of prior outcomes; it does not mean 27 final judgments or that Penn State's policy has already been blocked. No Penn State answer or court order in the new case was located by cutoff.

## SIGNIFICANCE

The new institutional complaint extends a nationwide federal campaign from state statutes and regulations to a public university policy. It could affect Penn State students and other institutions with similar rules, but legal consequences depend on the university's response, the court's interpretation and any injunction or settlement.

## GOALPOST / RESPONSE

DOJ argues that federal law bars residence-based postsecondary benefits for people not lawfully present unless the same benefit is available to U.S. citizens regardless of residence. Policy supporters have argued in related cases that eligibility rules can be based on school attendance or other criteria available to citizens. The Penn State answer, factual record, preliminary relief, merits ruling and appeals are the tests.

## MAYBE / THEREFORE

Maybe the Penn State case produces an injunction consistent with some earlier rulings, or the university may show factual or legal distinctions that defeat some or all claims. Therefore the archive records a filed 27th challenge and requested relief—not an adjudicated violation, an effective injunction or a completed policy change.


## SOURCES

- [Justice Department — four lawsuits challenging state in-state tuition laws](https://www.justice.gov/opa/pr/department-justice-files-complaints-against-arizona-new-mexico-oregon-and-washington) — official litigation announcement, requested relief, and administration explanation
- [United States v. Arizona — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459406/dl?inline=) — primary federal court complaint
- [United States v. New Mexico — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459386/dl?inline=) — primary federal court complaint
- [United States v. Oregon — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459396/dl?inline=) — primary federal court complaint
- [United States v. Washington — filed in-state tuition complaint](https://www.justice.gov/opa/media/1459401/dl?inline=) — primary federal court complaint
- [DOJ — complaint filed against Penn State over in-state tuition policy](https://www.justice.gov/opa/pr/department-justice-files-complaint-against-pennsylvania-state-university-challenging-its) — primary filed-action announcement and administration legal position
- [United States v. Pennsylvania State University — complaint](https://www.justice.gov/opa/media/1470386/dl?inline=) — primary filed federal complaint, Civil Action No. 26-cv-6000

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
