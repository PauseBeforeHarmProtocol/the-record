# DHS says Ukraine and Sudan TPS protections remain in place pending formal notices

**Entry ID:** NAT-2026-10-19-004
**Date:** October 19, 2026
**Checked:** 2026-10-19 12:02 PM EDT
**Evidence state:** on-record DHS statement as independently reported by Reuters, with prior Federal Register notices establishing the expiring designation periods; continuation announced, formal duration and final decisions unresolved
**Review state:** current-standard-reviewed

The department confirmed continued protection for roughly 240,000 Ukrainian registrants and an estimated 6,800 Sudanese holders, while the duration and final designation decisions remain unsettled.

## THE FACTS

- A Department of Homeland Security spokesperson told Reuters that Temporary Protected Status protections for Ukraine and Sudan remain in place and that formal announcements will be made at the appropriate time. The statement confirms current protection but does not itself supply a new Federal Register termination, redesignation or long-term extension notice.
- Reuters reported that approximately 240,000 Ukrainian registrants and an estimated 6,800 Sudanese status holders are affected. TPS can protect eligible holders from removal and authorize work, subject to registration and statutory conditions; the report did not establish permanent status.
- Prior Federal Register notices had extended both designations through October 19, 2026. Because no reviewed formal notice supplied a final duration or disposition by the cutoff, the archive records DHS's announced continuation and preserves the unresolved timing rather than assigning an unverified new expiration date.
- The administration has ended or narrowed TPS for several other nationalities while defending those decisions as enforcement of temporary statutory limits. Here DHS's on-record position is that Ukraine and Sudan protections continue for now; eligibility, registration, later notices and litigation may still change individual or program status.

## SIGNIFICANCE

The statement prevents an immediate lapse for large Ukrainian and smaller Sudanese protected populations and preserves work and removal protections while DHS decides the programs' next legal stage. Uncertainty remains because the department had not published the formal duration, rationale or registration mechanics.

## GOALPOST / RESPONSE

DHS says the protections remain in place and formal announcements will follow. Federal Register notices, stated statutory findings, duration, registration and employment-authorization guidance, individual notices, litigation and actual continuity of work and removal protection are the tests.

## MAYBE / THEREFORE

Maybe the delay reflects required review while protection continues, or it may prolong uncertainty for holders and employers. Therefore DHS announced that Ukraine and Sudan TPS remains operative for now—not permanent status, a verified multi-year extension or a final decision on either designation.


## SOURCES

- [Reuters — DHS says Ukraine and Sudan TPS protections remain in place](https://www.reuters.com/legal/government/us-says-immigrants-ukraine-sudan-can-keep-protected-status-now-2026-10-19/) — independent reporting quoting DHS on current protected-status treatment and pending formal notices
- [Federal Register — Extension of Ukraine Temporary Protected Status](https://www.federalregister.gov/documents/2025/01/17/2025-00771/extension-of-the-designation-of-ukraine-for-temporary-protected-status) — primary prior designation notice establishing the Ukraine TPS period and statutory framework
- [Federal Register — Extension of Sudan Temporary Protected Status](https://www.federalregister.gov/documents/2025/01/17/2025-00770/extension-of-the-designation-of-sudan-for-temporary-protected-status) — primary prior designation notice establishing the Sudan TPS period and statutory framework

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
