# DOJ arrests government contractor in alleged national-defense leak to journalist

**Entry ID:** NAT-2026-10-23-005
**Date:** October 23, 2026
**Checked:** 2026-10-24 11:57 AM EDT
**Evidence state:** primary DOJ announcement and filed FBI probable-cause affidavit, independently corroborated by Reuters with defense-response status; arrest and criminal complaint implemented, allegations unadjudicated
**Review state:** current-standard-reviewed

A criminal complaint alleges five disclosures tied to published reporting; the affidavit establishes only probable cause, and no indictment or conviction existed by cutoff.

## THE FACTS

- The Justice Department announced that the FBI arrested Ian A. Brinksman, 42, after searching his Washington residence and charged him by criminal complaint in the Eastern District of Virginia with unlawfully transmitting national-defense information under 18 U.S.C. § 793(d). A complaint is an allegation supported by a probable-cause finding, not an indictment or conviction.
- The 13-page FBI affidavit alleges that Brinksman held Top Secret/Sensitive Compartmented Information access while working for a U.S. government agency and later as a contractor. It cites classified-database logs, badge records, phone records and emails to allege that he accessed five reports outside his duties before a romantic partner published articles containing similar information. Those assertions and the classification determinations remain prosecutorial evidence, not adjudicated facts.
- Reuters independently reported the arrest and identified the journalist as Aída Chávez, publisher of the Capital & Empire newsletter. Reuters said Brinksman's federal public defender declined to comment and that Chávez, Deloitte and the State Department had not immediately responded; the affidavit names the recipient only as 'Individual 1.'
- Justice Department, FBI and CIA leaders described the case as national-security and counterintelligence enforcement and promised continued prosecution of leaks. By cutoff, the inspected record established no grand-jury indictment, plea, trial evidence, judicial finding on the alleged disclosures, sentence or measured national-security harm.

## SIGNIFICANCE

The case is an implemented Espionage Act prosecution involving an intelligence contractor and published journalism, making both national-security enforcement and source-reporting implications material. Its complaint posture, however, means the government's narrative has not yet been tested through indictment, adversarial discovery or trial.

## GOALPOST / RESPONSE

The administration says unauthorized disclosures expose intelligence sources, operations and personnel and warrant the full weight of prosecution. The tests are any grand-jury indictment, detention and discovery rulings, classification and intent evidence, defense response, trial or dismissal, appellate review and independently documented harm—not the arrest announcement alone.

## MAYBE / THEREFORE

Maybe access, communications and publication timing will support a knowing transmission case, or adversarial review may expose innocent explanations, classification disputes or evidentiary gaps. Therefore the supported conclusion is that a contractor was arrested and faces an active criminal complaint alleging unlawful transmission—not that every asserted disclosure occurred, that the recipient committed a crime, that an indictment exists or that Brinksman is guilty.


## SOURCES

- [Justice Department — U.S. government contractor arrested for alleged national-defense leak](https://www.justice.gov/opa/pr/us-government-contractor-arrested-allegedly-leaking-national-defense-information) — official charging announcement; allegations not adjudicated
- [U.S. v. Brinksman — affidavit supporting criminal complaint and arrest warrant](https://www.justice.gov/opa/media/1468496/dl?inline=) — primary 13-page probable-cause affidavit; allegations not adjudicated
- [Reuters — U.S. accuses contractor of leaking classified information to journalist](https://www.reuters.com/world/us/us-accuses-government-contractor-leaking-classified-info-girlfriends-substack-2026-10-24/) — independent national-security and court reporting with defense-response status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
