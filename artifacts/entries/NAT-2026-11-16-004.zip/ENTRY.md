# Survey measures 9% fall in international-student totals at responding institutions

**Entry ID:** NAT-2026-11-16-004
**Date:** November 16, 2026
**Checked:** 2026-11-16 12:08 PM EST
**Evidence state:** IIE survey of 809 responding institutions, Associated Press reporting and a separately labeled NAFSA/JB International economic estimate; measured respondent trends, not a full census or single-cause finding
**Review state:** current-standard-reviewed

The Fall 2026 snapshot found declines across undergraduate, graduate and practical-training populations; institutions cited visa processing and travel restrictions alongside cost and global competition.

## THE FACTS

- The Institute of International Education's Fall 2026 snapshot found a 9% year-over-year decline in total international students, including Optional Practical Training participants, across 809 responding U.S. institutions in the 2026–27 academic year. IIE says the respondents are a subset of nearly 3,000 institutions and that the full picture will come in Open Doors 2027.
- Respondents reported declines of 3% among undergraduates, 15% among graduate students, 6% among OPT participants and 15% among students entering their institution for the first time. These are survey measurements at participating institutions, not national administrative counts of every student.
- Among institutions reporting declines, 88% cited the visa application process, 70% travel restrictions, 60% enrollment in other countries and 45% cost. Those are multi-select institutional explanations and do not establish that any one administration policy caused the full measured change.
- Associated Press placed the results in the context of administration visa and higher-education policies while also reporting global competition and the price of U.S. education. The record therefore treats policy as a material reported factor rather than sole causation.
- NAFSA and JB International estimated that Fall 2026 international-student economic contributions fell by $2.4 billion and that more than 31,000 jobs were lost relative to their baseline. That model uses IIE and other data and is an advocacy-group estimate, not audited federal outlays, revenue or employment counts.

## SIGNIFICANCE

The survey supplies a timely, measured outcome across the student pipeline, including the practical-training population targeted by recent administration proposals and enforcement. It indicates national educational and economic consequences while preserving uncertainty about coverage, causal shares and model-based dollar effects.

## GOALPOST / RESPONSE

Administration policies are intended to strengthen screening, program integrity and U.S. labor protections. Outcomes should be judged through full Open Doors and SEVIS counts, visa processing and refusal data, institution-level enrollment, OPT participation, documented fraud or security findings, tuition and research effects and independently validated economic measures—not the snapshot or advocacy estimate alone.

## MAYBE / THEREFORE

Maybe tighter screening explains a material share of the decline and improves program integrity, or visa friction may be diverting legitimate students, talent and revenue without measured security gains. Therefore responding institutions recorded broad declines and cited multiple factors; the evidence does not prove a complete national count, sole causation or the exact modeled economic loss.


## SOURCES

- [Institute of International Education — Fall 2026 international-student snapshot](https://opendoorsdata.org/wp-content/uploads/2026/11/IIE_Fall-Snapshot_2026_Key-Findings_2026.pdf) — primary survey key findings from 809 responding institutions; preliminary subset, not a full census
- [Associated Press — international-student enrollment decline](https://apnews.com/article/a34e862e97509e25b93d9f2234234416) — independent reporting on IIE measurements, institutional explanations and administration-policy context
- [NAFSA and JB International — Fall 2026 economic-impact estimate](https://www.nafsa.org/about/about-nafsa/international-students-contributed-399-billion-us-economy-2025-2026-fall-2026) — advocacy-group economic estimate based on IIE snapshot and other data; not an audited federal measure

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
