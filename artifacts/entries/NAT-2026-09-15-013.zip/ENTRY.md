# Top House Democrat places informal hold on planned $2.8 billion Israel bomb sale

**Entry ID:** NAT-2026-09-15-013
**Date:** September 15, 2026
**Checked:** 2026-09-16 5:58 PM EDT
**Evidence state:** primary Meeks statement plus independent Reuters and Associated Press reporting; proposed package and informal hold are established, while final notification, approval, contracting and delivery remain pending
**Review state:** current-standard-reviewed

Gregory Meeks declined to clear the 40,000-bomb package during informal review; the administration could still submit formal notice or invoke an emergency exception.

## THE FACTS

- Reuters and Associated Press independently reported that the Trump administration plans a $2.8 billion package for Israel containing 20,000 MK 84 and 20,000 BLU-117 2,000-pound bombs. Their initial reports relied on separate unnamed U.S. officials or people familiar with the plan, so the package remains a corroborated proposal rather than a public final instrument.
- On September 16, House Foreign Affairs Committee Ranking Member Gregory Meeks announced that he would not clear the sale during the customary informal congressional review. His primary statement cited unresolved concerns about civilian protection and compliance with U.S. and international law.
- Meeks's hold delays or opposes informal clearance but does not permanently block the executive branch. Reuters and AP reported that the secretary of state could proceed to formal notification and could use a statutory emergency determination; neither step had occurred for this package by cutoff.
- Associated Press reported that most of the package would be financed through U.S. foreign military financing. That describes the reported funding plan and potential taxpayer exposure, not a new appropriation, executed contract, completed transfer or delivery schedule.
- The administration supports arms transfers as strengthening Israel's defense. Meeks said he remains committed to Israeli security but lacks sufficient assurance about lawful use in Gaza and Lebanon. No public DSCA notice, final approval, contract, delivery or end-use record for this package existed by cutoff.

## SIGNIFICANCE

The informal hold adds a concrete congressional obstacle and documented legal and civilian-harm concerns to a major proposed weapons package. It does not terminate the sale because the administration retains formal-notification and emergency pathways, leaving approval, financing, conditions and delivery unresolved.

## GOALPOST / RESPONSE

The administration frames continued arms support as strengthening Israel's defense; Meeks says assurances on lawful use and civilian protection are insufficient. The tests are a State Department or DSCA notice, any emergency determination, congressional resolutions, final approval, contracts, financing obligations, deliveries, end-use monitoring and measured effects.

## MAYBE / THEREFORE

Maybe the informal hold produces stronger safeguards, revision or delay, or the administration may override it through formal or emergency procedures and advance the package substantially as reported. Therefore the record confirms Meeks's refusal to clear a corroborated proposal—not cancellation, final approval, an executed contract, delivery or proof of future use.


## SOURCES

- [Reuters — administration plans $2.8 billion munitions sale to Israel](https://www.reuters.com/world/us/trump-administration-plans-28-billion-munitions-sale-israel-sources-say-2026-09-15/) — independent reporting based on a U.S. official; informal congressional communication is reported and the package is not treated as final or implemented
- [Associated Press — pending $2.8 billion Israel weapons package](https://apnews.com/article/trump-israel-weapons-sales-gaza-eb48cb7ecf773ffc472fbafc995aef2a) — independent reporting based on two U.S. officials and a person familiar; package not final and Congress informally notified
- [House Foreign Affairs Committee minority — Meeks hold on proposed Israel bomb sale](https://democrats-foreignaffairs.house.gov/2026/9/meeks-places-hold-on-trump-administration-s-2-8-billion-bomb-sale-to-israel) — primary congressional statement announcing refusal to clear the proposed sale during informal review
- [Reuters — Gregory Meeks objects to proposed Israel bomb sale](https://www.reuters.com/world/middle-east/top-democrat-us-house-committee-says-he-will-not-support-israel-bomb-sale-2026-09-16/) — independent reporting on the informal congressional hold and limits on its legal effect
- [Associated Press — informal hold on proposed Israel bomb sale](https://apnews.com/article/5ced4aac47eb08d9d949af296cf79ebc) — independent reporting on the congressional review stage and possible emergency override

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
