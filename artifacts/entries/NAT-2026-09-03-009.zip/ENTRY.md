# FCC asks court to dismiss Disney challenge to early ABC license reviews

**Entry ID:** NAT-2026-09-03-009
**Date:** April 28–September 3, 2026
**Checked:** 2026-09-03 11:59 PM EDT
**Evidence state:** primary FCC orders and government court filing plus independent Associated Press and Reuters reporting; early reviews and litigation active, merits and license outcomes unresolved
**Review state:** current-standard-reviewed

The government is defending an unusual early-renewal proceeding covering eight ABC stations; no license has been revoked, denied or referred for a hearing.

## THE FACTS

- The FCC's Media Bureau ordered Disney's eight company-owned ABC stations on April 28 to file renewal applications years before their ordinary renewal dates, saying early review was essential to an investigation of possible Communications Act, FCC-rule and unlawful-discrimination violations.
- ABC filed all eight applications May 28. The FCC accepted them for filing May 29 and established docket MB 26-131; the notice says the licenses remain effective while the proceedings are pending.
- Disney and ABC sued in federal district court August 18, alleging the early reviews were retaliation and coercion that violated the First Amendment. Those are plaintiff allegations, not adjudicated findings.
- On September 3, the FCC and Justice Department asked the district court to dismiss the case, arguing among other things that the court lacks jurisdiction and that stopping the reviews would obstruct investigation of alleged unlawful discrimination. The filing is government advocacy, not a ruling.
- Reuters reported the FCC had not called licenses for early review in more than 50 years and that the order followed repeated Trump demands that ABC lose licenses over disliked programming. FCC Chair Brendan Carr said no decision had been made on a hearing referral. A hearing on Disney's case was set for October 5, with the FCC agreeing to 48 hours' notice before any referral order.

## SIGNIFICANCE

Using broadcast-license review during a presidential campaign against network programming creates a consequential test of agency enforcement authority, nondiscrimination oversight and editorial freedom. Even without revocation, an extraordinary early review can impose process costs and pressure on federally licensed speakers.

## GOALPOST / RESPONSE

The FCC says it is investigating serious discrimination allegations and applying broadcasters' statutory public-interest obligations; Disney says the process is retaliatory punishment for protected programming. The dismissal ruling, jurisdiction, administrative record, any hearing designation, factual findings, license dispositions, appellate review and evidence of consistent treatment across broadcasters are the tests.

## MAYBE / THEREFORE

Maybe the early reviews are a lawful way to investigate workplace discrimination and public-interest compliance, or their timing and surrounding presidential threats may support Disney's retaliation theory. Therefore the record confirms the unusual early-renewal process, Disney's lawsuit and the government's dismissal request—not discrimination by ABC, unconstitutional retaliation, a court ruling or loss of any station license.


## SOURCES

- [FCC — order calling eight Disney-owned ABC licenses for early renewal](https://docs.fcc.gov/public/attachments/DA-26-416A1.pdf) — primary agency order directing early renewal filings during an ongoing investigation
- [FCC — public notice accepting ABC early-renewal applications](https://docs.fcc.gov/public/attachments/DA-26-541A1.pdf) — primary agency notice documenting eight filings, the investigation and renewal procedures
- [Associated Press — Disney and ABC challenge FCC early-license review](https://apnews.com/article/8c379d4d4dc90e97a8ef57371f203bfa) — independent reporting on the lawsuit, retaliation allegations and FCC position
- [FCC and Justice Department — motion to dismiss Disney ABC license-review lawsuit](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/r.OXntUtlMDc/v0) — primary government filing presenting the jurisdictional and merits arguments against preliminary relief
- [Reuters — FCC asks court to reject Disney lawsuit over ABC station licenses](https://www.reuters.com/world/fcc-asks-court-reject-disney-lawsuit-over-station-licenses-2026-09-03/) — independent reporting on the government's dismissal request, early-review history and pending court schedule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
