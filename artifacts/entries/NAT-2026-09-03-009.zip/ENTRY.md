# FCC pressure reaches candidate interviews while ABC license reviews remain active

**Entry ID:** NAT-2026-09-03-009
**Date:** April 28–September 12, 2026
**Checked:** 2026-09-13 12:00 AM EDT
**Evidence state:** primary FCC orders and government court filing plus independent Associated Press and Reuters reporting; interview distribution changed, early reviews and litigation active, penalties, merits and license outcomes unresolved
**Review state:** current-standard-reviewed

ABC moved a Democratic Senate candidate's Kimmel interview to YouTube amid FCC equal-time pressure; no station license has been revoked, denied or referred for a hearing.

## THE FACTS

- The FCC's Media Bureau ordered Disney's eight company-owned ABC stations on April 28 to file renewal applications years before their ordinary renewal dates, saying early review was essential to an investigation of possible Communications Act, FCC-rule and unlawful-discrimination violations.
- ABC filed all eight applications May 28. The FCC accepted them for filing May 29 and established docket MB 26-131; the notice says the licenses remain effective while the proceedings are pending.
- Disney and ABC sued in federal district court August 18, alleging the early reviews were retaliation and coercion that violated the First Amendment. Those are plaintiff allegations, not adjudicated findings.
- On September 3, the FCC and Justice Department asked the district court to dismiss the case, arguing among other things that the court lacks jurisdiction and that stopping the reviews would obstruct investigation of alleged unlawful discrimination. The filing is government advocacy, not a ruling.
- Reuters reported the FCC had not called licenses for early review in more than 50 years and that the order followed repeated Trump demands that ABC lose licenses over disliked programming. FCC Chair Brendan Carr said no decision had been made on a hearing referral. A hearing on Disney's case was set for October 5, with the FCC agreeing to 48 hours' notice before any referral order.
- On September 10, Jimmy Kimmel said ABC would publish his interview with Texas Democratic Senate candidate James Talarico on YouTube rather than broadcast it because of FCC equal-time exposure. Associated Press and Reuters reported the distribution change; neither reported a formal FCC penalty arising from the interview.
- Carr said on September 12 that Republican Senator Ted Cruz's ESPN interview fell outside the equal-time statute because ESPN is a cable service and Cruz was not a legally qualified candidate in the 2026 election. Reuters reported the explanation after the FCC warning concerning Talarico; Cruz separately said the FCC should not act as a ‘speech police.’

## SIGNIFICANCE

The documented move from network broadcast to an online-only interview shows that FCC enforcement posture can alter nationally distributed political programming before any formal penalty. Combined with extraordinary early license review, that creates a consequential test of election-law administration, agency consistency and editorial freedom.

## GOALPOST / RESPONSE

The FCC says the equal-time statute applies to legally qualified candidates on broadcast stations, not cable appearances by noncandidates, and says its ABC reviews enforce nondiscrimination and public-interest duties. Disney and critics describe the surrounding process as coercive and retaliatory. The statutory treatment of comparable candidates and platforms, any actual complaint or penalty, the dismissal ruling, hearing designation, factual findings, license dispositions and appellate review are the tests.

## MAYBE / THEREFORE

Maybe the different treatment follows the statute's candidate and broadcast boundaries, or the broader pattern may chill disfavored political interviews even without formal sanctions. Therefore the record confirms a changed ABC distribution decision, Carr's stated distinction and still-active license proceedings—not an equal-time violation, selective-enforcement finding, unconstitutional retaliation or loss of any license.


## SOURCES

- [FCC — order calling eight Disney-owned ABC licenses for early renewal](https://docs.fcc.gov/public/attachments/DA-26-416A1.pdf) — primary agency order directing early renewal filings during an ongoing investigation
- [FCC — public notice accepting ABC early-renewal applications](https://docs.fcc.gov/public/attachments/DA-26-541A1.pdf) — primary agency notice documenting eight filings, the investigation and renewal procedures
- [Associated Press — Disney and ABC challenge FCC early-license review](https://apnews.com/article/8c379d4d4dc90e97a8ef57371f203bfa) — independent reporting on the lawsuit, retaliation allegations and FCC position
- [FCC and Justice Department — motion to dismiss Disney ABC license-review lawsuit](https://assets.bwbx.io/documents/users/iqjWHBFdfxIU/r.OXntUtlMDc/v0) — primary government filing presenting the jurisdictional and merits arguments against preliminary relief
- [Reuters — FCC asks court to reject Disney lawsuit over ABC station licenses](https://www.reuters.com/world/fcc-asks-court-reject-disney-lawsuit-over-station-licenses-2026-09-03/) — independent reporting on the government's dismissal request, early-review history and pending court schedule
- [Reuters — ABC moves Kimmel interview with Senate candidate online amid FCC equal-time pressure](https://www.reuters.com/world/us/abcs-jimmy-kimmel-says-senate-candidate-interview-will-not-air-network-2026-09-10/) — independent reporting on the changed distribution, the FCC equal-time position and ABC's lack of a public response
- [Associated Press — Kimmel interview with Senate candidate moves to YouTube amid FCC equal-time concerns](https://apnews.com/article/d3b6ccd636d8b94bd9485e7082438046) — independent reporting on the broadcast decision, equal-time posture and FCC commissioner response
- [Reuters — Carr says Cruz ESPN interview falls outside FCC equal-time rule](https://www.reuters.com/world/us/republican-senators-tv-interview-passes-muster-with-fccs-carr-even-though-2026-09-13/) — independent reporting carrying the FCC chair's named statutory explanation and a senator's criticism

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
