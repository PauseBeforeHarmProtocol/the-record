# U.S. and Japan agree on missile-production cooperation and Japanese AMRAAM facility

**Entry ID:** NAT-2026-10-28-005
**Date:** October 28, 2026
**Checked:** 2026-10-30 6:06 AM EDT
**Evidence state:** Primary Japanese defense-ministry meeting summary plus AP; agreement announced, construction, appropriations, production and effectiveness not established
**Review state:** current-standard-reviewed

Official meeting summary establishes an agreement, not an operating plant, completed deliveries or a newly appropriated amount.

## THE FACTS

- Japan’s Defense Ministry says Koizumi and Hegseth agreed at their October 28 meeting in Cebu to establish an AMRAAM final-assembly and inspection facility in Japan and to share technical information needed to increase SM-3 Block IIA production. The summary places these measures within Operation Supercharge defense-equipment cooperation.
- AP independently reported the facility agreement from Koizumi’s announcement. Its account describes Hegseth’s rationale as deterring coercion while avoiding unnecessary escalation. Neither the inspected official summary nor the report establishes a completed factory, deliveries, an achieved production rate or a specified new U.S. appropriation.
- This October 28 bilateral agreement is distinct from the September 28 provisional Raytheon contract tracked in NAT-2026-09-28-009. That contract’s ceiling is not evidence that this Japanese facility has been funded or built. The earlier event date is preserved as a recovered lead, not presented as an October 30 action.

## SIGNIFICANCE

The agreement adds a concrete allied production pathway to defense-industrial cooperation. Whether it increases usable supply or reduces vulnerabilities depends on financing, technical-transfer terms, construction, qualification and delivered output.

## GOALPOST / RESPONSE

The ministers frame cooperation as strengthening deterrence and response. Hegseth’s strongest stated case is credible defense without needless escalation. Budget authority, implementation milestones, actual output and independent security assessment remain the tests.

## MAYBE / THEREFORE

Maybe a Japanese assembly and inspection capability will diversify supply and accelerate missile availability, or industrial, licensing and funding constraints will delay it. Therefore the agreed cooperation is documented, while completed capacity, spending and net security benefits remain unverified.


## SOURCES

- [Japan Ministry of Defense — October 28 Japan–U.S. defense ministerial meeting](https://www.mod.go.jp/en/article/2026/10/8dbc5c2ef47ef3843a13f3bb48dc6b00fff7ba03.html) — primary official meeting summary; full operative text inspected
- [AP — U.S. and Japan agree on Japanese joint missile-production facility](https://www.opb.org/article/2026/10/29/us-and-japan-agree-to-establish-a-japanese-facility-for-joint-missile-production/) — independent reporting; full AP article inspected on OPB, same AP origin as apnews
- [Pentagon awards Raytheon provisional $20.7 billion AMRAAM contract](https://www.reuters.com/business/aerospace-defense/pentagon-awards-rtxs-raytheon-207-billion-contract-amraam-missiles-amid-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
