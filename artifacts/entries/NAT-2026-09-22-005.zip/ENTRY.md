# CMS immediately pauses new federal Marketplace broker registrations

**Entry ID:** NAT-2026-09-22-005
**Date:** September 22, 2026
**Checked:** 2026-09-22 12:02 PM EDT
**Evidence state:** complete primary interim final rule and moratorium notice plus Reuters reporting on the agency's implemented cancellation and broker-screening claims and the trade group's response; lifecycle and scope documented, contested reasons and outcomes unresolved
**Review state:** current-standard-reviewed

An interim final rule and concurrent moratorium pause specified new broker registrations through February 1, 2027; CMS separately reported August policy cancellations and broker exclusions, but the agency's fraud and savings estimates are not adjudicated findings.

## THE FACTS

- CMS issued an interim final rule with comment period, effective September 22, codifying HHS authority to impose temporary moratoria on specified agent and broker registrations in federally facilitated health-insurance Exchanges. Comments are due November 21, 2026.
- CMS concurrently imposed a moratorium through February 1, 2027, unless modified earlier, on Plan Year 2027 registration by agents and brokers who lacked Plan Year 2026 Exchange agreements. The moratorium does not apply to registration on state-based Exchanges and does not remove every currently registered broker.
- CMS said immediate action was needed to address unauthorized enrollment, misuse of personal information and other noncompliance while it builds program-integrity safeguards. The agency estimated about 19,000 new agents and brokers otherwise would have registered during the period; that is an agency projection, not a measured fraud count.
- Reuters reported that CMS said it canceled 315,000 policies covering about 760,000 people in August because of unverified citizenship or immigration status and suspected improper enrollments, and issued notices affecting 569 brokers whose application patterns it called statistically implausible. The cancellations and notices are implemented administrative actions; the reasons, projected $6.6 billion exposure and claimed $2.2 billion savings remain agency characterizations rather than adjudicated liability or independently measured net savings.
- The National Association of Benefits and Insurance Professionals said a blanket moratorium could reduce access to legitimate enrollment help and urged targeted safeguards. No court ruling, completed comment review, coverage-outcome study or independently verified savings result existed by cutoff.

## SIGNIFICANCE

The action immediately changes who can newly register to assist consumers on federal-platform Exchanges and accompanies a large reported cancellation and broker-screening campaign. It may reduce unauthorized enrollments, but it also can constrain enrollment assistance and coverage; the rule's legality, targeting and net effects remain open.

## GOALPOST / RESPONSE

CMS says advance notice would let bad actors accelerate registrations and that the pause is needed while stronger safeguards are installed. Broker representatives argue targeted enforcement would better protect legitimate assistance. Comments, implementation data, restored or contested coverage, broker appeals, litigation, fraud findings, enrollment access and audited fiscal effects are the tests.

## MAYBE / THEREFORE

Maybe the temporary pause prevents a measurable wave of unauthorized enrollment while preserving enough legitimate help, or it may block new compliant brokers and increase coverage barriers without validating the agency's estimates. Therefore CMS implemented a defined, temporary federal-platform registration moratorium and reported cancellation and screening actions—not proven broker fraud across the affected population, a final post-comment rule or independently measured savings.


## SOURCES

- [Federal Register public inspection — CMS temporary moratorium on specified Marketplace broker registrations](https://public-inspection.federalregister.gov/2026-19493.pdf) — primary interim final rule with comment period and concurrent implemented moratorium (FR Doc. 2026-19493)
- [Reuters — CMS reports Marketplace cancellations and broker-registration moratorium](https://www.reuters.com/legal/government/us-says-it-canceled-315000-obamacare-policies-last-month-2026-09-22/) — independent reporting on implemented administrative actions, agency estimates and industry response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
