# Judge dismisses Harvard admissions-record enforcement suit without prejudice

**Entry ID:** NAT-2026-11-02-003
**Date:** November 2, 2026
**Checked:** 2026-11-03 12:08 AM EST
**Evidence state:** inspected primary district-court order plus DOJ's original filing rationale and independent Reuters/Courthouse News reports; procedural disposition and non-findings preserved precisely
**Review state:** current-standard-reviewed

The court found that Education and DOJ had not adequately completed statutory notice and voluntary-compliance prerequisites; it did not decide the discrimination allegations or whether Harvard ultimately must produce records.

## THE FACTS

- U.S. District Judge Myong Joun dismissed United States v. President and Fellows of Harvard College, No. 1:26-cv-10844-MJJ, without prejudice on November 2. The inspected 10-page order is a threshold procedural ruling, not a merits judgment on alleged admissions discrimination.
- The court held that the Education Department and Justice Department had not adequately established the required notice and voluntary-compliance steps before seeking judicial enforcement. Because the defects may be cured, dismissal without prejudice permits a properly supported renewed action; it does not permanently bar the investigation.
- The order expressly did not decide whether Harvard discriminated, whether the requested material falls within lawful investigative authority or whether Harvard may ultimately be compelled to produce it. DOJ's February filing had alleged that Harvard unlawfully withheld race-related admissions documents; those allegations remain unadjudicated.
- Reuters and Courthouse News independently reported the ruling. Education Department spokesperson Ellen Keast said Harvard has a history of discrimination, criticized the decision as shielding the university and said the administration would continue seeking compliance. That is the strongest located administration response, not a court finding or proof that the procedural prerequisites have now been met.

## SIGNIFICANCE

The ruling stops this enforcement suit in its current form and requires the administration to satisfy statutory process before returning to court. It is material institutional oversight of an education-civil-rights investigation, while leaving the underlying discrimination dispute and any future records obligation unresolved.

## GOALPOST / RESPONSE

The administration says the records are necessary to enforce federal civil-rights law and says it will continue pressing Harvard. Harvard prevailed on the threshold process. The tests are completed notice and voluntary-compliance steps, a refiled action, any narrower demand, later production order and adjudicated discrimination findings—not the dismissed complaint alone.

## MAYBE / THEREFORE

Maybe the agencies can cure the procedural defects and obtain relevant records, or further review may narrow or reject the demand. Therefore the current established result is dismissal without prejudice for unmet prerequisites—not vindication of Harvard's admissions practices, a permanent bar on investigation or proof that the requested records must be produced.


## SOURCES

- [District of Massachusetts — order dismissing admissions-record enforcement suit without prejudice](https://www.courthousenews.com/wp-content/uploads/2026/11/judge-dismisses-harvard-case-doj.pdf) — primary 10-page order in United States v. President and Fellows of Harvard College, No. 1:26-cv-10844-MJJ, ECF 44
- [Justice Department — suit seeking Harvard admissions records](https://www.justice.gov/opa/pr/justice-department-sues-harvard-university-withholding-race-related-admissions-documents) — primary administration filing announcement and stated discrimination-enforcement rationale
- [Reuters — judge dismisses Harvard admissions-data case](https://www.reuters.com/world/us-judge-dismisses-trump-administrations-harvard-admissions-probe-case-2026-11-02/) — independent report on the procedural dismissal and administration response
- [Courthouse News — judge tosses DOJ suit over Harvard admissions data](https://courthousenews.com/judge-tosses-dojs-suit-against-harvard-over-race-related-admissions-data/) — independent court report and link to the primary order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
