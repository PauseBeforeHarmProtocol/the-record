# FinCEN withdraws proposed crypto-mixing and unhosted-wallet reporting rules

**Entry ID:** NAT-2026-10-06-002
**Date:** October 6, 2026
**Checked:** 2026-10-06 6:08 PM EDT
**Evidence state:** two primary Federal Register withdrawal notices and agency announcement; withdrawals implemented, downstream effects unmeasured
**Review state:** current-standard-reviewed

The agency ended two pending proposals effective October 6; it did not repeal an existing final rule or end illicit-finance monitoring.

## THE FACTS

- FinCEN withdrew, effective October 6, its 2023 proposal to identify international convertible-virtual-currency mixing as a class of transactions of primary money-laundering concern and impose a special reporting measure. The proposal never became a final rule.
- FinCEN also withdrew its 2020 proposal that would have required reports for certain convertible-virtual-currency or legal-tender-digital-asset transactions above $10,000 and records and identity verification for certain transactions above $3,000 involving unhosted or certain foreign-hosted wallets.
- The mixing notice says the breadth of the proposed definition could have captured legitimate activity, chilled innovation and imposed significant burdens. FinCEN said it will continue monitoring illicit use and may pursue future targeted measures; withdrawal is not a finding that mixing presents no money-laundering risk.
- FinCEN framed both withdrawals as part of a fit-for-purpose and deregulatory agenda. The action removes the pending proposals but does not by itself establish how compliance costs, privacy, innovation or illicit-finance outcomes will change.

## SIGNIFICANCE

The withdrawals end two long-pending federal proposals that would have expanded transaction reporting in the digital-asset sector. They narrow the immediate regulatory path while leaving existing anti-money-laundering duties and future targeted action intact.

## GOALPOST / RESPONSE

FinCEN says the broad proposals risked burdening legitimate activity and were not fit for purpose, while maintaining that it will monitor illicit finance. Compliance costs, enforcement outcomes and any narrower replacement measures are the tests.

## MAYBE / THEREFORE

Maybe withdrawal avoids overbroad surveillance and compliance burdens, or it may reduce information available against illicit finance. Therefore the two proposals are withdrawn, while the balance of benefits, enforcement effects and any future targeted rules is not yet measured.


## SOURCES

- [FinCEN announces withdrawals of proposed digital-asset rules](https://www.fincen.gov/news/news-releases/fincen-announces-withdrawals-proposed-digital-asset-related-rules) — primary agency announcement
- [FinCEN withdrawal of proposed CVC mixing special measure](https://www.federalregister.gov/documents/2026/10/06/2026-20429/proposal-of-special-measure-regarding-convertible-virtual-currency-mixing-as-a-class-of-transactions) — primary Federal Register withdrawal notice
- [FinCEN withdrawal of unhosted-wallet transaction proposal](https://www.federalregister.gov/documents/2026/10/06/2026-20430/requirements-for-certain-transactions-involving-convertible-virtual-currency-or-digital-assets) — primary Federal Register withdrawal notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
