# Justice Department reports 354 arrests in multinational dark-web operation

**Entry ID:** NAT-2026-11-12-009
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:06 PM EST
**Evidence state:** Primary Justice Department and Europol releases with consistent aggregate totals; arrests and seizures announced, individual guilt and long-term effectiveness unresolved
**Review state:** current-standard-reviewed

Operation TorNado produced announced arrests and seizures across multiple countries, while individual charges remain allegations and the aggregate does not yet measure durable market or overdose effects.

## THE FACTS

- The Justice Department announced that Operation TorNado, conducted from May 2025 through October 2026 with Europol and international partners, resulted in 354 arrests worldwide, including 132 in the United States.
- DOJ reported seizures exceeding $234 million in cash and cryptocurrency, 5.7 metric tons of drugs, 38 pill presses and 209 firearms. These are law-enforcement aggregates announced by participating authorities, not final forfeiture judgments or convictions in every case.
- DOJ said U.S. prosecutions span more than 20 federal districts and that investigations remain ongoing. Charges and complaint allegations are not findings of guilt, and defendants retain the presumption of innocence unless proved guilty.
- Europol separately reported the same 354-arrest total and described coordinated action against dark-web vendors and buyers. The intergovernmental release corroborates the operation’s scope while relying on participating agencies for national case results.
- The releases did not provide a measured estimate of the operation’s effect on overdose deaths, fentanyl availability, replacement marketplaces or long-term trafficking capacity.

## SIGNIFICANCE

The operation is a material implemented multinational enforcement action with unusually large announced seizures and a substantial U.S. component. Its scale is distinct from proof that every prosecution will succeed or that the dark-web opioid market has been durably reduced.

## GOALPOST / RESPONSE

DOJ says coordinated investigations can disrupt anonymous trafficking networks and seize criminal proceeds. The tests are public charging documents, convictions and dismissals, final forfeitures, validated drug and firearm inventories, marketplace displacement, replacement activity, availability and price measures, overdose outcomes and transparent accounting of international attribution.

## MAYBE / THEREFORE

Maybe the arrests and seizures will produce durable network disruption and successful prosecutions, or vendors and marketplaces may rapidly reconstitute while some cases fail. Therefore the record establishes announced multinational enforcement results and ongoing U.S. prosecutions—not guilt in every case, final forfeiture or proven long-term reduction in fentanyl harm.


## SOURCES

- [International Law Enforcement Operation Targeting Opioid and Fentanyl Traffickers on the Dark Web](https://www.justice.gov/opa/pr/international-law-enforcement-operation-targeting-opioid-and-fentanyl-traffickers-dark-web) — primary government release
- [354 dark web vendors and buyers arrested in Europol-coordinated global crackdown](https://www.europol.europa.eu/media-press/newsroom/news/354-dark-web-vendors-and-buyers-arrested-in-europol-coordinated-global-crackdown) — primary intergovernmental release

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
