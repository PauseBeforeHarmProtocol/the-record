# DOJ settles servicemember mortgage-benefit allegations with Village Capital

**Entry ID:** NAT-2026-10-19-007
**Date:** October 19, 2026
**Checked:** 2026-10-19 6:00 PM EDT
**Evidence state:** executed DOJ-Village Capital settlement and DOJ announcement; four-year obligations and minimum monetary relief verified, final recipient count, payments and compliance outcomes unresolved
**Review state:** current-standard-reviewed

The executed four-year agreement requires at least $425,000 in compensation, a $79,380 penalty, credit corrections, policy changes and training.

## THE FACTS

- The Justice Department and Village Capital & Investment LLC executed a four-year settlement resolving federal allegations that the VA-loan servicer violated the Servicemembers Civil Relief Act on at least 41 mortgage accounts and retaliated against borrowers who sought interest-rate benefits.
- DOJ alleged that Village Capital failed to reduce qualifying pre-service mortgage interest to 6% retroactive to military orders, failed to lower payments by the forgiven interest, misrepresented some existing rates, accelerated principal and falsely reported some borrowers as delinquent to the Department of Veterans Affairs.
- Village Capital agreed to deposit at least $425,000 for affected servicemembers, pay a $79,380 civil penalty, identify additional affected accounts, correct inaccurate credit reporting, revise policies, train covered employees and report complaints. Individual compensation includes improper amounts plus at least $500 or three times that amount, whichever is larger.
- The parties said they settled to avoid the delay, uncertainty and expense of litigation. The agreement resolves specified federal allegations without a court merits judgment and allows DOJ compliance review and enforcement during its four-year term.

## SIGNIFICANCE

The settlement creates direct monetary, credit-reporting and compliance remedies for military borrowers and establishes ongoing federal supervision of a VA-mortgage servicer. The minimum fund can grow if review identifies additional eligible accounts.

## GOALPOST / RESPONSE

DOJ says the agreement will vindicate servicemembers' statutory protections and deter unlawful lending practices. The final affected-account count, compensation delivered, credit corrections, policy approval, employee training, complaint reporting and compliance findings are the tests.

## MAYBE / THEREFORE

Maybe the agreement fully identifies and compensates affected military families and prevents recurrence, or later review may reveal gaps in payments, corrections or compliance. Therefore the company accepted enforceable relief to resolve DOJ allegations—not that a court adjudicated liability or that every affected account has already been found and paid.


## SOURCES

- [Justice Department — Village Capital SCRA settlement announcement](https://www.justice.gov/opa/pr/va-home-loan-servicer-village-capital-pay-over-500000-violating-servicemembers-rights) — primary announcement of the mortgage-servicing settlement and alleged conduct
- [United States and Village Capital & Investment — executed SCRA settlement agreement](https://www.justice.gov/crt/media/1466881/dl) — primary executed settlement instrument establishing relief, monitoring and enforcement terms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
