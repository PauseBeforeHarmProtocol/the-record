# Trump formalizes Canadian-goods procurement restriction directive

**Entry ID:** NAT-2026-09-08-005
**Date:** September 8, 2026
**Checked:** 2026-09-17 12:01 PM EDT
**Evidence state:** primary September 8 post and Reuters plus signed September 16 memorandum; ordered, product-level implementation unverified
**Review state:** current-standard-reviewed

A signed September 16 memorandum follows the earlier post; product-level removals remain unverified.

## THE FACTS

- On September 8 at 4:29:29 PM EDT, Trump published a direction for GSA, working with USTR, to take steps to remove Canadian-origin products from GSA’s Multiple Award Schedules unless Canada restores what he calls full and fair reciprocity. Reuters independently reported the direction.
- The post identifies neither an effective date nor a product-level implementation schedule. The reviewed evidence establishes the direction, not completed delisting, cancelled contracts or a government-wide ban.
- On September 16 Trump signed a memorandum directing OMB and USTR, working with the Federal Acquisition Regulatory Council, to identify Canadian-origin items in federal civil procurement and take legally permitted removal or nonavailability steps where warranted.
- The memorandum also directs notices of domestic alternatives, progress updates and USTR monitoring of conditions that could justify restoring access. Implementation remains subject to law and available appropriations; the instrument does not enumerate completed product removals.

## SIGNIFICANCE

The signed instrument advances the earlier public direction into a formal interagency instruction. Supplier exclusions and purchasing costs still depend on implementation.

## GOALPOST / RESPONSE

Trump argues Canadian procurement preferences deny reciprocity. That is the administration’s rationale, not an independently audited market assessment. Agency notices, actual exclusions, restoration decisions and procurement costs are the tests.

## MAYBE / THEREFORE

Maybe targeted restrictions secure reciprocal access, or they raise costs without concessions. Therefore the record establishes a signed instruction with legal limits, not a completed government-wide ban or measured benefit.


## SOURCES

- [Donald Trump — direction concerning Canadian-origin products in GSA schedules](https://truthsocial.com/@realDonaldTrump/117237309084360726) — primary publication of a presidential direction; factual claims inside the post are not independently established
- [Reuters — Trump directs steps to remove Canadian goods from GSA schedules](https://www.reuters.com/business/trump-directs-gsa-take-steps-remove-canadian-goods-agency-lists-2026-09-08/) — independent reporting confirming the public direction, not completed procurement removals
- [White House — Restoring Reciprocity in Government Procurement](https://www.whitehouse.gov/presidential-actions/2026/09/restoring-reciprocity-in-government-procurement/) — primary signed presidential memorandum; implementation conditional on law and agency action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
