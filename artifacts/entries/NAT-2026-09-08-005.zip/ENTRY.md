# Trump directs GSA and USTR to seek removal of Canadian goods from procurement schedules

**Entry ID:** NAT-2026-09-08-005
**Date:** September 8, 2026
**Checked:** 2026-09-08 6:02 PM EDT
**Evidence state:** primary presidential post plus Reuters; directed/announced, implementation unverified
**Review state:** current-standard-reviewed

A public presidential direction names agencies and a procurement mechanism; actual removals remain unverified.

## THE FACTS

- On September 8 at 4:29:29 PM EDT, Trump published a direction for GSA, working with USTR, to take steps to remove Canadian-origin products from GSA’s Multiple Award Schedules unless Canada restores what he calls full and fair reciprocity. Reuters independently reported the direction.
- The post identifies neither an effective date nor a product-level implementation schedule. The reviewed evidence establishes the direction, not completed delisting, cancelled contracts or a government-wide ban.

## SIGNIFICANCE

Federal purchasing access is a distinct form of trade leverage. Implementation could affect suppliers and public purchasing, but the affected contract value and costs are not yet measured.

## GOALPOST / RESPONSE

Trump argues Canada unfairly excludes U.S. firms from procurement. That allegation and his aggregate spending claim are not independently verified here. Agency instruments, legal authority, exceptions, contract changes and Canadian responses are the tests.

## MAYBE / THEREFORE

Maybe a targeted procurement measure yields reciprocal access, or it increases purchasing costs without concessions. Therefore this record establishes a public direction to act, not an implemented exclusion or demonstrated trade benefit.


## SOURCES

- [Donald Trump — direction concerning Canadian-origin products in GSA schedules](https://truthsocial.com/@realDonaldTrump/117237309084360726) — primary publication of a presidential direction; factual claims inside the post are not independently established
- [Reuters — Trump directs steps to remove Canadian goods from GSA schedules](https://www.reuters.com/business/trump-directs-gsa-take-steps-remove-canadian-goods-agency-lists-2026-09-08/) — independent reporting confirming the public direction, not completed procurement removals

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
