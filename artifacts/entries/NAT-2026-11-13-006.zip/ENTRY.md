# Johnson Controls companies agree to $5 million federal cybersecurity settlement

**Entry ID:** NAT-2026-11-13-006
**Date:** November 13, 2026
**Checked:** 2026-11-13 6:03 PM EST
**Evidence state:** Primary Justice Department settlement announcement identifying parties, payment, allegation period, agencies and cases; payment agreement established, liability adjudication and remediation outcomes not established
**Review state:** current-standard-reviewed

The payment resolves False Claims Act allegations concerning security controls on federal contracts; it is a settlement of allegations, not an adjudicated liability finding.

## THE FACTS

- Johnson Controls, Johnson Controls Fire Protection LP and Johnson Controls Security Solutions LLC agreed to pay $5 million to resolve Justice Department allegations that they violated the False Claims Act by failing to comply with cybersecurity requirements in federal contracts and subcontracts.
- DOJ said the alleged conduct ran from January 2018 through August 2025 and involved work for NASA and the Departments of Defense, Energy and Justice. The allegations concerned access controls, required System Security Plans and plans of action and milestones for identified deficiencies.
- The settlement resolves two whistleblower cases: United States ex rel. Kelly Vance v. Johnson Controls, Inc., No. 1:24-cv-2500 in the Northern District of Georgia, and United States ex rel. David Thomas v. Johnson Controls International PLC, No. 1:26-cv-448 in the District of Columbia.
- The settlement provides an $850,000 relator share to Kelly Vance. The inspected announcement did not state that a court adjudicated the underlying allegations or quantify a verified breach, loss, exploitation event or corrective-security outcome.
- DOJ framed the resolution as enforcement of contractor cybersecurity promises and protection of sensitive government information. No separate transaction-specific public response from Johnson Controls was located in the material reviewed by cutoff; the companies' agreement to pay does not by itself prove every allegation.

## SIGNIFICANCE

The settlement is an implemented federal recovery tied to cybersecurity obligations across multiple sensitive agencies and shows the administration using False Claims Act enforcement for contractor security compliance. Its evidentiary scope remains the agreed resolution, not a judicial finding about each alleged failure or actual compromise.

## GOALPOST / RESPONSE

The administration and contractors can demonstrate effectiveness through disclosed remediation, validated security plans, closed milestones, independent audits, agency acceptance, future compliance and evidence of reduced exposure. The payment should remain distinct from any later liability finding, breach attribution or measured security improvement.

## MAYBE / THEREFORE

Maybe the settlement reflects meaningful enforcement that corrects persistent contractor-security gaps, or it may resolve litigation without showing whether the controls are now effective. Therefore the record establishes a $5 million agreement resolving specified allegations—not an adjudication that every allegation was true, proof of an exploited breach or proof that remediation is complete.


## SOURCES

- [Justice Department — Johnson Controls and subsidiaries agree to $5 million cybersecurity False Claims Act settlement](https://www.justice.gov/usao-ndga/pr/johnson-controls-inc-and-two-subsidiaries-agree-pay-5-million-settle-federal-fraud) — primary federal settlement announcement identifying the payment, allegation period, agencies and qui tam cases

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
