# DHS uses customs summonses to seek journalists', unions' and nonprofits' records

**Entry ID:** NAT-2026-08-29-002
**Date:** February–August 29, 2026
**Checked:** 2026-08-30 6:02 AM EDT
**Evidence state:** primary federal order denying related warrants, primary Justice Department filing and filed DHS summons exhibit, plus an independent Guardian investigation with company responses and named legal specialists; summonses issued and some records produced, ultimate statutory legality unresolved
**Review state:** current-standard-reviewed

Federal filings document administrative demands issued without prior judicial approval after a magistrate rejected related warrants; no court has finally ruled the summons practice unlawful.

## THE FACTS

- On February 24, a federal magistrate denied five Homeland Security search-warrant applications tied to the Cities Church prosecution. The court found that none established probable cause, criticized requests for broad YouTube subscriber and account information, and said one cited video appeared to be paradigmatic political speech protected by the First Amendment.
- Federal filings and summons exhibits later disclosed that DHS used administrative summonses under 19 U.S.C. 1509, a customs-records statute, to seek information without prior judicial approval. The Guardian reported that DHS served Google with a summons for YouTube information less than a month after withdrawing its rejected warrant requests; Google did not comply because DHS had not shown a customs connection.
- According to court papers reviewed by The Guardian, T-Mobile complied with a separate demand and supplied six months of journalist Georgia Fort's telephone metadata, encompassing records for more than 10,000 calls and text messages. The reporting also identified demands involving other media accounts and financial records of unions and nonprofits; the disclosed records do not establish that every recipient was a criminal suspect or charged entity.
- A Justice Department opposition filing confirms that the investigation used 19 U.S.C. 1509(a) summonses and argues that defense requests for broader investigative-policy material were speculative, overbroad or immaterial. Elsewhere in the litigation, the government argued that the statute reaches potential crimes administered by the former Customs Service and is not limited to collection of duties and taxes.
- Companies may resist an administrative summons and require the government to seek court enforcement. Some challenged summonses have been withdrawn, and no final judicial decision located by cutoff held this use of Section 1509 lawful or unlawful. DHS and DOJ declined The Guardian's request for additional comment.

## SIGNIFICANCE

The filings document the executive branch using a customs administrative-demand power to obtain or seek communications and financial metadata about journalists and civic organizations without first securing a warrant. The practice may expose sources and associational networks while shifting the burden and cost of judicial review to companies and targets.

## GOALPOST / RESPONSE

The government says Section 1509 authorizes records demands for potential crimes administered by Customs-derived DHS authorities and that the requests supported a legitimate investigation into possible interference with federal personnel. The lawful statutory scope, relevance to charged conduct, notice to affected users, company compliance, internal approvals, total number of summonses, Inspector General review, and any enforcement or suppression ruling are the tests.

## MAYBE / THEREFORE

Maybe the statute lawfully reaches these investigations, the demands sought metadata rather than message content, and company resistance supplies a practical safeguard. Therefore the record documents issued administrative summonses and one reported production of telephone metadata—not an adjudicated finding of unlawful surveillance, proof that every demand targeted protected speech, or proof that every company complied.


## SOURCES

- [The Guardian — DHS uses customs summonses to seek journalists', unions' and nonprofits' records](https://www.theguardian.com/us-news/2026/aug/29/trump-dhs-1509-summons-records-journalists-nonprofits) — independent investigation based on federal court filings, summons exhibits, company responses and named former officials and legal specialists
- [District of Minnesota — order denying five search-warrant applications](https://storage.courtlistener.com/recap/gov.uscourts.mnd.232141/gov.uscourts.mnd.232141.1.0_2.pdf) — primary federal court order finding no probable cause for account and device searches tied to the Cities Church prosecution
- [United States v. Armstrong — government opposition addressing administrative summonses](https://storage.courtlistener.com/recap/gov.uscourts.mnd.231106/gov.uscourts.mnd.231106.589.0.pdf) — primary Justice Department filing confirming use of 19 U.S.C. 1509(a) summonses and stating the government's discovery and authority positions
- [United States v. Armstrong — DHS 19 U.S.C. 1509 summons exhibit](https://storage.courtlistener.com/recap/gov.uscourts.mnd.231106/gov.uscourts.mnd.231106.612.7.pdf) — primary filed administrative-summons exhibit documenting the asserted records-demand authority

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
