# Groups sue over BLM approval of Gate Canyon oil-truck road

**Entry ID:** NAT-2026-10-06-005
**Date:** April 2026–October 6, 2026
**Checked:** 2026-10-09 12:03 AM EDT
**Evidence state:** primary federal complaint, official BLM cultural-resource background and independent Reuters reporting; approval challenged, allegations unadjudicated and construction status unresolved
**Review state:** current-standard-reviewed

The federal complaint challenges an April road approval that would widen, pave and blast through a culturally and environmentally sensitive Utah canyon; no court has yet ruled on the allegations.

## THE FACTS

- Nine Mile Canyon Coalition, Southern Utah Wilderness Alliance and the Center for Biological Diversity filed a 50-page complaint on October 6 in the U.S. District Court for the District of Utah challenging BLM's April 2026 approval of Duchesne County's Gate Canyon Road project.
- The proposed project would widen, straighten and pave an existing dirt route, including blasting cliff walls, to create an alternative truck route serving the Uinta Basin oil fields. The complaint alleges that the affected cliffs contain at least 47 historic sites, including inscriptions associated with Black Army Buffalo Soldiers and European-American freighters and pioneers.
- The complaint alleges violations of NEPA, the National Historic Preservation Act, the Endangered Species Act, the Federal Land Policy and Management Act and the Administrative Procedure Act. It asks the court to set aside the approval; those claims are allegations and no injunction or merits ruling had issued by cutoff.
- BLM describes nearby Nine Mile Canyon as a 46-mile cultural landscape with more than 1,000 rock-art sites and over 10,000 images. Reuters reported that Interior declined comment because of pending litigation.

## SIGNIFICANCE

The suit places a judicial check on an implemented federal approval whose construction consequences could be difficult to reverse. It also tests how accelerated energy-infrastructure decisions account for cultural resources, threatened species and public participation.

## GOALPOST / RESPONSE

The project proponents seek a safer, more direct oil-truck route; the plaintiffs say BLM rushed review and understated irreversible harms. The administrative record, any stay or injunction, consultation evidence, endangered-species analysis, route alternatives, construction status and final merits ruling are the tests.

## MAYBE / THEREFORE

Maybe fuller review will show the road can proceed with mitigation, or the record may reveal legal defects requiring a new route or vacatur. Therefore a federal approval and a detailed challenge exist; the complaint does not establish that blasting has begun, that the alleged violations are proven or that the project has been stopped.


## SOURCES

- [Nine Mile Canyon Coalition v. Kenczka — Gate Canyon complaint](https://suwa.org/wp-content/uploads/Gate-Canyon-Complaint-10.6.26.pdf) — primary court complaint; allegations not adjudicated
- [BLM — Nine Mile Canyon visitor and cultural-resource background](https://www.blm.gov/visit/nine-mile-canyon) — official agency background page
- [Reuters — Gate Canyon road-approval lawsuit](https://www.reuters.com/business/environment/us-sued-over-plan-blast-utah-canyon-inscribed-by-19th-century-buffalo-soldiers-2026-10-09/) — independent reporting of the filed federal complaint and agency response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
