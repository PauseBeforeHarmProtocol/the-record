# Trump signs five-year tick-borne disease program reauthorization

**Entry ID:** NAT-2026-09-30-006
**Date:** September 30, 2026
**Checked:** 2026-10-01 12:04 AM EDT
**Evidence state:** White House signing notice, enrolled legislation and official CBO cost estimate plus sponsor explanation; statute enacted, appropriations and measured outcomes unresolved
**Review state:** current-standard-reviewed

The statute authorizes $30 million annually through fiscal 2030 for regional centers and state capacity; those authorizations do not themselves appropriate or spend the money.

## THE FACTS

- President Trump signed S. 2398, the Kay Hagan Tick Act reauthorization, into law on September 30, 2026, after Congress passed the enrolled bill.
- The law reauthorizes specified federal tick-borne disease programs through fiscal year 2030 and authorizes $10 million annually for regional centers of excellence and $20 million annually for state health-department capacity.
- Congressional Budget Office estimated $101 million in discretionary outlays over fiscal years 2026–2030 and $49 million after 2030, assuming future appropriations. The statute's authorizations are not proof that Congress appropriated or agencies spent those amounts.
- Supporters say the measure sustains surveillance, prevention, research and clinical capacity for Lyme and other tick-borne diseases. It is a separate statutory action from Trump's September 29 executive order directing a Washington-area mosquito and tick campaign.
- No reauthorization-specific appropriation ledger, grant award, implementation result or measured disease-outcome effect was established in the inspected sources by the cutoff.

## SIGNIFICANCE

The law supplies a multi-year statutory framework for regional and state capacity against a growing public-health problem. Its practical reach depends on annual appropriations, grant execution and whether funded programs improve surveillance, prevention and treatment outcomes.

## GOALPOST / RESPONSE

The administration and sponsors say continued federal coordination and state capacity will reduce the burden of tick-borne disease. The strongest response is fiscal and evaluative: authorization does not guarantee funding, and program effectiveness must be measured. Appropriations, awards, geographic coverage, surveillance quality and disease outcomes are the tests.

## MAYBE / THEREFORE

Maybe sustained authorized funding strengthens prevention and care, or future appropriations and implementation may fall short of the statutory framework. Therefore the record establishes a signed five-year reauthorization and authorized amounts—not $150 million already appropriated or spent, or a demonstrated health result.


## SOURCES

- [White House — S. 2398 signed into law](https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-s-2398-signed-into-law/) — official bill-signing announcement
- [Enrolled S. 2398 — Kay Hagan Tick Act reauthorization](https://www.govinfo.gov/content/pkg/BILLS-119s2398enr/pdf/BILLS-119s2398enr.pdf) — official enrolled legislation
- [CBO cost estimate for S. 2398](https://www.cbo.gov/publication/62048) — official cost estimate
- [Collins — Kay Hagan Tick Act signed into law](https://www.collins.senate.gov/newsroom/signed-into-law-kay-hagan-tick-reauthorization-act-authored-by-senator-collins) — sponsor announcement and administration rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
