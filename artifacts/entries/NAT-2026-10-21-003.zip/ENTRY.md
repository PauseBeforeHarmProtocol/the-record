# Justice and Agriculture departments announce first nationwide SNAP-fraud enforcement surge

**Entry ID:** NAT-2026-10-21-003
**Date:** September 1–October 21, 2026
**Checked:** 2026-10-21 5:56 PM EDT
**Evidence state:** primary Justice Department enforcement summary identifying participating offices, case stages and aggregate intended-loss figures; no independent audit of the aggregate, recoveries or deterrent effect was located by cutoff
**Review state:** current-standard-reviewed

Federal and state prosecutors grouped actions against more than 40 defendants and reported nearly $45 million in intended losses, including nearly $42 million involving SNAP; the release combines allegations with guilty pleas and sentences.

## THE FACTS

- The Justice Department, Agriculture Department and USDA Office of Inspector General announced the first National USDA Benefits and Program Fraud Enforcement Surge, covering actions from September 1 through October 21. DOJ said its Fraud Division, 13 U.S. attorneys’ offices and the Utah attorney general participated in actions against more than 40 defendants.
- DOJ reported nearly $45 million in intended federal losses across the listed matters, including nearly $42 million involving Supplemental Nutrition Assistance Program benefits and one crop-insurance case. These are the department’s aggregate figures, not an independent audit or a measure of recovered money.
- The release identifies ten notable case groups spanning indictments, complaints, an information, guilty pleas and sentencings. Its largest listed matter is an indictment alleging approximately $29.7 million in losses from stolen EBT account information; charges and complaints remain allegations, while admitted conduct, sentences and restitution orders have different evidentiary status.
- Attorney General Todd Blanche and Agriculture Secretary Brooke Rollins said the coordinated effort was intended to disrupt fraud networks, protect benefit recipients and taxpayers, and continue under the administration’s broader fraud task force. The release does not establish how much loss the surge prevented, how much money will be recovered or whether national SNAP fraud changed as a result.

## SIGNIFICANCE

The announcement documents a coordinated, implemented federal-state enforcement initiative rather than a proposal, but it packages cases at different procedural stages and uses intended-loss totals. Its practical effectiveness will depend on adjudications, restitution, recoveries, victim reimbursement and measured program-integrity outcomes.

## GOALPOST / RESPONSE

The administration says the surge will protect low-income families and taxpayers by disrupting fraud networks and prosecuting offenders. The tests are docketed case outcomes, conviction and dismissal rates, restitution and recoveries, victim benefit restoration, repeat-loss rates and independently reported SNAP fraud trends.

## MAYBE / THEREFORE

Maybe coordinated national case selection and cross-agency investigations will deter organized benefit theft, or the aggregate announcement may primarily repackage existing cases without changing national fraud rates. Therefore the record establishes a first announced nationwide enforcement surge and its reported case mix—not guilt for charged defendants, $42 million recovered or demonstrated program-wide effectiveness.


## SOURCES

- [Justice Department — nationwide USDA benefits and program fraud enforcement surge](https://www.justice.gov/opa/pr/dojs-fraud-division-department-agriculture-and-usda-oig-uncover-nearly-42m-snap-benefit) — primary enforcement summary distinguishing indictments, complaints, pleas and sentencings and reporting aggregate intended losses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
