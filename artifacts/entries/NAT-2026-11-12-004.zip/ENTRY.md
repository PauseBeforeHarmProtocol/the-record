# FDA proposes moving 12 oncology companion-diagnostic categories from class III to class II

**Entry ID:** NAT-2026-11-12-004
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:13 AM EST
**Evidence state:** published FDA proposed order, official PDF and device-center announcement; primary administrative record supports proposal terms and evidence review, with finalization and outcomes unresolved
**Review state:** current-standard-reviewed

The proposed order would replace premarket approval with special controls and 510(k) review for specified immunohistochemistry tests; it is open for comment through January 11.

## THE FACTS

- FDA published a proposed order on November 12 to reclassify 12 product-code categories of immunohistochemistry test systems used with corresponding approved oncology therapies from class III to class II. Comments close January 11, 2027; the reclassification is not final.
- The devices would remain subject to special controls and premarket notification under section 510(k); FDA does not propose exempting them from 510(k). Existing approved devices could remain on the market, while significant modifications would require the applicable submission and review.
- FDA based the proposal on 14 premarket approvals and supplements, scientific literature, adverse-event and recall information, and agency experience. It identified one class III recall, 10 class II recalls and no class I recalls in the reviewed record, and proposed controls for analytical and clinical performance, labeling and risk mitigation.
- FDA says class II controls can provide reasonable assurance of safety and effectiveness while reducing review burden and potentially improving access. Those are the agency's risk and access judgments; no final order, shortened review time, additional test authorization or patient outcome has yet occurred.

## SIGNIFICANCE

Companion diagnostics can determine which cancer patients receive targeted therapies. Changing the review pathway could affect development cost and speed while shifting the evidence and controls used before marketing, making the final special controls and postmarket performance consequential.

## GOALPOST / RESPONSE

FDA says accumulated experience supports class II regulation without sacrificing reasonable assurance of safety and effectiveness. The tests are the final order, special-control compliance, 510(k) review times, submissions, recalls, false-result performance, treatment access and patient outcomes.

## MAYBE / THEREFORE

Maybe the 510(k)-plus-special-controls pathway will preserve test reliability while reducing unnecessary delay, or a less demanding pathway may miss risks previously addressed through premarket approval. Therefore the archive records a data-supported reclassification proposal—not a final downgrade, approval of any new test, demonstrated faster access or measured safety result.


## SOURCES

- [FDA — oncology immunohistochemistry test-system reclassification proposal](https://www.federalregister.gov/documents/2026/11/12/2026-23005/hematology-and-pathology-devices-reclassification-of-immunohistochemistry-test-systems-for-use-with-a-corresponding-approved-oncology-therapeutic-product) — primary proposed order; class III-to-II reclassification and special controls
- [Federal Register PDF — oncology IHC reclassification proposal](https://www.govinfo.gov/content/pkg/FR-2026-11-12/pdf/2026-23005.pdf) — official PDF of proposed reclassification order and evidence review
- [FDA CDRH — new news and updates](https://www.fda.gov/medical-devices/medical-devices-news-and-events/cdrh-new-news-and-updates) — primary device-center announcement of proposed reclassification

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
