# USDA launches $8 billion Harvest Fuel Relief Program

**Entry ID:** NAT-2026-10-19-008
**Date:** October 19–23, 2026
**Checked:** 2026-10-23 11:59 AM EDT
**Evidence state:** official USDA announcement plus independent Reuters reporting with a named USDA administrator; program, funding and post-election timetable announced, while rates, disbursement and effectiveness remain unresolved
**Review state:** current-standard-reviewed

USDA said payments will begin after the November 3 election, likely near year-end, while exact rates, eligibility details and final disbursement remain pending.

## THE FACTS

- The Agriculture Department announced an $8 billion Harvest Fuel Relief Program to provide one-time support to eligible farmers for modeled losses during the 2026 harvest season; USDA said the funds are available under the Commodity Credit Corporation Charter Act and the Farm Service Agency will administer the program.
- USDA said its uniform formula will use FSA planted-acre data, Economic Research Service production-cost estimates and World Agricultural Supply and Demand Estimates yields and prices. Crop-insurance participation is not required.
- USDA said payment rates for Title I commodities are expected in November, while eligibility and payment methodology for other eligible commodities will be announced later. The application period, final recipient count, obligations and disbursements were not established by the cutoff.
- Reuters independently reported the $8 billion announcement after Trump's Kansas campaign rally and described the program as one-time support intended to offset high diesel and other farm-input costs; the report did not establish that payments had been distributed.
- On October 23, USDA Farm Service Agency Administrator Richard Fordyce said disbursements would begin after the November 3 election, with exact timing still unclear and payments likely near year-end. He said the department had enough Commodity Credit Corporation funding; no recipient had been paid under the program by cutoff.
- Reuters reported that USDA plans to model payments using average fuel consumption or expenditures by commodity and that the program would raise estimated 2026 federal farm payments to a record $55.4 billion, from a prior expectation above $47 billion. Those are program-design and aggregate estimates, not completed disbursements or measured relief.

## SIGNIFICANCE

USDA has now supplied a post-election timetable and a fuel-cost modeling approach for the $8 billion program, making implementation more specific while confirming that payments have not begun. The projected record federal support is fiscal context, not evidence of recipient outcomes.

## GOALPOST / RESPONSE

The administration says the formula will provide timely, targeted and proportional relief. Published commodity rates, eligibility and application terms, actual obligations and post-election disbursements, recipient distribution and measured farm-finance outcomes are the tests.

## MAYBE / THEREFORE

Maybe the modeled payments reach producers in time to ease verified fuel-cost stress, or year-end timing and averaged formulas may miss immediate or uneven losses. Therefore the record establishes an announced post-election payment plan and projected aggregate—not that $8 billion has been distributed or losses have been offset.


## SOURCES

- [USDA — Harvest Fuel Relief Program announcement](https://www.usda.gov/about-usda/news/press-releases/2026/10/19/trump-administration-announces-8-billion-harvest-fuel-relief-program) — primary program announcement and implementation framework
- [Reuters — U.S. launches $8 billion farmer support program](https://www.reuters.com/world/us/us-launch-8-billion-support-program-farmers-offset-diesel-costs-trump-says-2026-10-20/) — independent reporting and implementation context
- [Reuters — USDA says $8 billion farm-aid payments will follow the election](https://www.reuters.com/business/energy/trump-administrations-8-billion-diesel-aid-farmers-will-arrive-after-election-2026-10-23/) — independent reporting quoting USDA on timing, formula design and aggregate payment estimates

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
