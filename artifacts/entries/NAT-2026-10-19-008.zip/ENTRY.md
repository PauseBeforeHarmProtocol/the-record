# USDA launches $8 billion Harvest Fuel Relief Program

**Entry ID:** NAT-2026-10-19-008
**Date:** October 19, 2026
**Checked:** 2026-10-19 11:59 PM EDT
**Evidence state:** official USDA program announcement plus independent Reuters reporting; program and funding availability announced, payment rates, applications, disbursement and effectiveness unresolved
**Review state:** current-standard-reviewed

The one-time Commodity Credit Corporation program was announced for 2026 harvest losses; payment rates, eligibility details and applications remain pending.

## THE FACTS

- The Agriculture Department announced an $8 billion Harvest Fuel Relief Program to provide one-time support to eligible farmers for modeled losses during the 2026 harvest season; USDA said the funds are available under the Commodity Credit Corporation Charter Act and the Farm Service Agency will administer the program.
- USDA said its uniform formula will use FSA planted-acre data, Economic Research Service production-cost estimates and World Agricultural Supply and Demand Estimates yields and prices. Crop-insurance participation is not required.
- USDA said payment rates for Title I commodities are expected in November, while eligibility and payment methodology for other eligible commodities will be announced later. The application period, final recipient count, obligations and disbursements were not established by the cutoff.
- Reuters independently reported the $8 billion announcement after Trump's Kansas campaign rally and described the program as one-time support intended to offset high diesel and other farm-input costs; the report did not establish that payments had been distributed.

## SIGNIFICANCE

The announcement commits a material $8 billion federal agricultural-support program through the Commodity Credit Corporation, but the practical distribution and effect depend on later rates, eligibility rules, applications, obligations and payments.

## GOALPOST / RESPONSE

The administration says the formula will provide timely, targeted and proportional relief during harvest. Published commodity rates, eligibility and application terms, obligations, disbursements, recipient distribution and measured farm-finance outcomes are the tests.

## MAYBE / THEREFORE

Maybe the program cushions verified harvest and fuel-cost losses, or later formula, timing and coverage decisions may leave important gaps. Therefore USDA announced and authorized a one-time $8 billion program—not that $8 billion has already been paid or that farm losses and diesel costs have been offset.


## SOURCES

- [USDA — Harvest Fuel Relief Program announcement](https://www.usda.gov/about-usda/news/press-releases/2026/10/19/trump-administration-announces-8-billion-harvest-fuel-relief-program) — primary program announcement and implementation framework
- [Reuters — U.S. launches $8 billion farmer support program](https://www.reuters.com/world/us/us-launch-8-billion-support-program-farmers-offset-diesel-costs-trump-says-2026-10-20/) — independent reporting and implementation context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
