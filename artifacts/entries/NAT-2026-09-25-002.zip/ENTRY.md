# Postal Service immediately revises NEPA procedures

**Entry ID:** NAT-2026-09-25-002
**Date:** September 25, 2026
**Checked:** 2026-09-25 11:59 AM EDT
**Evidence state:** primary Federal Register interim final rule; effective September 25, 2026, comments pending and project-level outcomes unmeasured
**Review state:** current-standard-reviewed

An interim final rule keeps core environmental-review requirements in regulation, moves internal procedures to a handbook and revises categorical exclusions.

## THE FACTS

- The U.S. Postal Service issued an interim final rule effective September 25 revising its National Environmental Policy Act procedures after statutory changes, recent Supreme Court decisions and the Council on Environmental Quality's rescission of government-wide regulations. Comments are due October 26.
- The rule retains definitions, environmental-review duties, categorical exclusions and emergency procedures in the Code of Federal Regulations while moving internal administrative procedures to a separate Postal Service handbook.
- USPS added or revised categorical exclusions for actions including routine vehicle replacements and some processing-network optimizations, property uses and operational changes. A categorical exclusion applies only when the action fits the listed class and no extraordinary circumstance may make environmental effects significant.
- The rule authorizes alternative arrangements for immediate emergency response while requiring consultation with the Council on Environmental Quality for emergency actions with reasonably foreseeable significant effects. It changes procedure; it does not itself approve a particular facility closure, vehicle purchase or network project.

## SIGNIFICANCE

The rule immediately changes how a nationwide federal operator screens projects for environmental review, including which routine actions may avoid a full environmental assessment or impact statement.

## GOALPOST / RESPONSE

USPS says the revision conforms its process to current law and reduces unnecessary procedure while retaining review for significant effects. Project-level categorical-exclusion use, extraordinary-circumstance findings, environmental assessments, litigation and measured processing time are the tests.

## MAYBE / THEREFORE

Maybe the revised exclusions will speed low-impact operational decisions, or they may narrow public review for projects with cumulative local effects. Therefore the rule changes screening procedures now; it does not establish the environmental impact of any specific Postal Service action.


## SOURCES

- [National Environmental Policy Act Implementing Procedures](https://www.govinfo.gov/content/pkg/FR-2026-09-25/pdf/2026-19720.pdf) — primary interim final rule; 91 FR 61020; effective September 25, 2026; comments due October 26, 2026

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
