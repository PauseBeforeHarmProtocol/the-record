# State coalition sues over corporate ownership-reporting exemptions

**Entry ID:** NAT-2026-10-27-006
**Date:** October 27, 2026
**Checked:** 2026-10-28 12:47 AM EDT
**Evidence state:** Original stamped complaint and Minnesota litigant announcement, with Reuters reporting and the administration’s earlier rationale. Filed/pending; high confidence in filing and requested relief. Earlier-date recovery, not an action first occurring after the current window opened.
**Review state:** current-standard-reviewed

The Oregon filing challenges Treasury’s exemptions and seeks to stop a data purge; no injunction, rule reversal or completed deletion is established.

## THE FACTS

- On October 27, twenty states and the District of Columbia filed No. 6:26-cv-02359-MTK in federal court in Oregon against Treasury, FinCEN and other federal officials. The caption establishes 21 plaintiffs; this record does not adopt a conflicting news report’s state count.
- The complaint challenges exemptions for domestic companies and U.S. owners of foreign companies under the Corporate Transparency Act, including the August 2026 final rule and March 2025 interim rule. Plaintiffs allege the administration exceeded its authority and undermined ownership transparency. These are allegations, not judicial findings.
- Plaintiffs request declarations and vacatur of the challenged actions and an injunction or stay against an announced purge of ownership data. The inspected filing does not establish completed deletion, an issued injunction or reversal of the exemptions.
- Reuters independently reported the challenge. Treasury did not answer its comment request; Reuters recounts Secretary Scott Bessent’s August explanation that the rule reduces reporting burdens for law-abiding businesses without sacrificing national security.

## SIGNIFICANCE

The dispute tests executive authority to exempt companies from a statutory transparency system and the preservation of information used against illicit finance. The lawsuit itself does not prove increased crime, unlawful conduct or national-security harm.

## GOALPOST / RESPONSE

Bessent’s documented prior rationale is lower business-reporting burdens without compromising security, not a fresh response to this suit. Statutory authority, the administrative record, retained data, court decisions and measured enforcement consequences are the tests.

## MAYBE / THEREFORE

Maybe the exemptions lawfully remove disproportionate burdens, or they exceed statutory authority and diminish useful transparency. Therefore the supported event is a filed challenge and requested preservation relief, not a court finding or proven illicit-finance outcome.


## SOURCES

- [State coalition complaint challenging Corporate Transparency Act exemptions, No. 6:26-cv-02359-MTK](https://www.ag.state.mn.us/Office/Communications/2026/docs/02359_Corporate-Transparency-Act_Complaint.pdf) — primary court filing
- [Attorney General announces challenge to ownership-reporting exemptions](https://www.ag.state.mn.us/Office/Communications/2026/10/27_Corporate-Transparency-Act.asp) — primary litigant statement
- [Trump administration sued over rollback of corporate ownership reporting rules](https://www.investing.com/news/stock-market-news/trump-administration-sued-over-rollback-of-corporate-ownership-reporting-rules-4977180) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
