# Trump releases election-security files and orders investigations

**Entry ID:** NAT-2026-07-19-001
**Date:** July 16–17, 2026
**Checked:** 2026-07-19 08:15 AM EDT
**Evidence state:** official document release, prior Intelligence Community assessment, and independent reporting; no altered vote totals established

The White House published declassified material after a prime-time address, while the released record did not establish that foreign actors altered 2020 vote totals.

## THE FACTS

- President Trump delivered a prime-time address on July 16 and the White House published collections of declassified and other government records concerning election-system vulnerabilities, Chinese acquisition of voter data, a Michigan registration investigation, and noncitizens on voter rolls.
- The White House says Chinese actors obtained data associated with roughly 220 million voter records and that intelligence officials suppressed important reporting. Its July 17 response also says the president was identifying ongoing vulnerabilities rather than claiming that a past election outcome was changed.
- Reuters reported that the released material did not establish altered votes and contrasted the president’s claims with the March 2021 Intelligence Community assessment, which found no indication that a foreign actor attempted to alter a technical aspect of the 2020 voting process. The White House directed the intelligence and law-enforcement agencies to investigate its suppression allegations and urged Congress to pass the SAVE America Act.

## SIGNIFICANCE

This combines presidential declassification authority, election-security policy, criminal-investigation demands, and midterm legislation in one public action. The accountability test is whether the released files support each claim made about them, whether investigations follow ordinary evidentiary rules, and whether federal action respects the primary role of state and local election administrators.

## GOALPOST / RESPONSE

The administration says the disclosure is about serious vulnerabilities, foreign acquisition of voter data, and alleged suppression—not proof that vote totals were changed. That distinction should be preserved. It also means future claims must be measured against the documents actually released, the prior Intelligence Community assessment, and any independently reviewable investigative findings.


## SOURCES

- [Reuters — Trump election-security address and declassified files](https://www.reuters.com/legal/government/with-midterms-deck-trump-deliver-primetime-speech-election-security-2026-07-16/) — independent reporting and document review
- [White House — election-integrity document collection](https://www.whitehouse.gov/election-integrity/) — official document-release portal and administration claims
- [White House — response on election-interference files](https://www.whitehouse.gov/releases/2026/07/setting-the-record-straight-president-trump-declassifies-intel-on-foreign-election-interference-deep-state-coverup/) — official administration statement
- [ODNI — foreign threats to the 2020 U.S. federal elections](https://www.dni.gov/index.php/newsroom/reports-publications/reports-publications-2021/3521-intelligence-community-assessment-on-foreign-threats-to-the-2020-u-s-federal-elections) — primary declassified Intelligence Community assessment

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
