# State signs Los Tiguerones terrorist designations as Rubio announces Ecuador security package

**Entry ID:** NAT-2026-09-09-003
**Date:** August 3–September 10, 2026
**Checked:** 2026-09-09 6:01 PM EDT
**Evidence state:** signed State Department determinations plus independent reporting on announced assistance
**Review state:** current-standard-reviewed

The FTO designation was scheduled to take effect September 10; the funding requests and equipment transfers remained announced rather than completed.

## THE FACTS

- Secretary of State Marco Rubio signed Foreign Terrorist Organization and Specially Designated Global Terrorist determinations for the Ecuadorian group Los Tiguerones on August 3. The notices were filed for public inspection September 9 and scheduled for September 10 publication; the FTO notice expressly says it takes effect upon publication, so it was not yet operative at this record’s cutoff.
- The signed SDGT determination states the administration’s finding that Los Tiguerones committed, attempted, risked committing or trained for terrorist acts threatening U.S. nationals or U.S. security, foreign policy or economic interests. The notice establishes the government’s legal determination, not independent proof of each underlying allegation.
- During a September 9 visit to Ecuador, Rubio said the administration would seek $45 million in additional security funding and announced a $10 million initiative addressing illegal gold mining, recruitment and illicit finance. Reuters and AP also reported announced plans to provide a 110-foot Coast Guard cutter and five interceptor boats.
- The $45 million remained a planned funding request, and the record does not treat the announced money as appropriated or disbursed, the additional vessels as delivered, or the designations as proof of reduced trafficking or violence.

## SIGNIFICANCE

The signed designations create a new sanctions, immigration and material-support framework around a named Ecuadorian gang once effective, while the assistance package would deepen U.S.–Ecuador security cooperation. The operational, legal, fiscal and human-rights effects remain unmeasured.

## GOALPOST / RESPONSE

Rubio described Ecuador as a leading partner and said cooperative operations can align with partner-country law while targeting traffickers. The strongest counterpoint is that terrorist labels and expanded security support can carry broad financial, criminal and force-related consequences. Publication, funding action, transfer records, target evidence, prosecutions, oversight and measured security outcomes are the tests.

## MAYBE / THEREFORE

Maybe coordinated designations and targeted equipment can help Ecuador disrupt violent trafficking networks without repeating unilateral U.S. force practices, or the labels and assistance may expand coercive tools without adequate safeguards. Therefore the record establishes signed determinations and announced assistance—not an effective FTO designation before September 10, completed funding or transfers, independently proven allegations, or improved security.


## SOURCES

- [Federal Register public inspection — Los Tiguerones Foreign Terrorist Organization designation](https://www.federalregister.gov/public-inspection/2026-18442/foreign-terrorist-organization-designation-of-los-tiguerones) — primary signed designation filed September 9 and expressly effective upon September 10 publication
- [Federal Register public inspection — Los Tiguerones Specially Designated Global Terrorist determination](https://www.federalregister.gov/public-inspection/2026-18443/specially-designated-global-terrorist-designation-of-los-tiguerones) — primary signed determination filed September 9 and scheduled for September 10 publication
- [Reuters — Rubio announces Ecuador security package and Los Tiguerones designation](https://www.reuters.com/world/americas/rubio-says-he-will-seek-45-million-security-funding-ecuador-2026-09-09/) — independent reporting on announced funding requests, equipment transfers and designation policy
- [Associated Press — Rubio describes joint counternarcotics approach in Ecuador](https://apnews.com/article/133a5eca2b8925dfc1dc0daa1266c73e) — independent reporting on the designation, planned assistance and administration rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
