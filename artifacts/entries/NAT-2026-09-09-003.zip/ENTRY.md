# Los Tiguerones FTO designation takes effect upon Federal Register publication

**Entry ID:** NAT-2026-09-09-003
**Date:** August 3–September 10, 2026
**Checked:** 2026-09-10 11:57 AM EDT
**Evidence state:** published State Department determinations plus retained independent reporting on announced assistance; FTO effective September 10, assistance outcomes unverified
**Review state:** current-standard-reviewed

September 10 publication activates the FTO designation; the separately announced Ecuador assistance is not established as disbursed or delivered.

## THE FACTS

- Secretary of State Marco Rubio signed the Los Tiguerones FTO and SDGT determinations on August 3; both were published September 10 at 91 FR 57675. The FTO notice expressly makes publication its effective trigger, so the FTO designation is now effective. The aliases Los Fenix and Los Igualitos are included.
- The signed SDGT determination states the administration’s finding that Los Tiguerones committed, attempted, risked committing or trained for terrorist acts threatening U.S. nationals or U.S. security, foreign policy or economic interests. The notice establishes the government’s legal determination, not independent proof of each underlying allegation.
- During a September 9 visit to Ecuador, Rubio said the administration would seek $45 million in additional security funding and announced a $10 million initiative addressing illegal gold mining, recruitment and illicit finance. Reuters and AP also reported announced plans to provide a 110-foot Coast Guard cutter and five interceptor boats.
- The $45 million remained a planned funding request, and the record does not treat the announced money as appropriated or disbursed, the additional vessels as delivered, or the designations as proof of reduced trafficking or violence.

## SIGNIFICANCE

The now-effective FTO designation activates the named group’s terrorist-designation framework; the published SDGT determination provides the administration’s sanctions rationale. The separately announced assistance would deepen U.S.–Ecuador security cooperation, but the notices do not establish disbursements, delivered vessels, independently proven underlying allegations or measured security effects.

## GOALPOST / RESPONSE

Rubio described Ecuador as a leading partner and said cooperative operations can align with partner-country law while targeting traffickers. The strongest counterpoint is that terrorist labels and expanded security support can carry broad financial, criminal and force-related consequences. Publication, funding action, transfer records, target evidence, prosecutions, oversight and measured security outcomes are the tests.

## MAYBE / THEREFORE

Maybe coordinated designations and targeted assistance help Ecuador disrupt violent trafficking networks, or expanded coercive tools may operate without adequate safeguards or measurable results. Therefore September 10 publication establishes an effective FTO designation and a published SDGT determination—not completed assistance, proved individual allegations or improved security.


## SOURCES

- [Federal Register public inspection — Los Tiguerones Foreign Terrorist Organization designation](https://www.federalregister.gov/public-inspection/2026-18442/foreign-terrorist-organization-designation-of-los-tiguerones) — primary signed designation filed September 9 and expressly effective upon September 10 publication
- [Federal Register public inspection — Los Tiguerones Specially Designated Global Terrorist determination](https://www.federalregister.gov/public-inspection/2026-18443/specially-designated-global-terrorist-designation-of-los-tiguerones) — primary signed determination filed September 9 and scheduled for September 10 publication
- [Reuters — Rubio announces Ecuador security package and Los Tiguerones designation](https://www.reuters.com/world/americas/rubio-says-he-will-seek-45-million-security-funding-ecuador-2026-09-09/) — independent reporting on announced funding requests, equipment transfers and designation policy
- [Associated Press — Rubio describes joint counternarcotics approach in Ecuador](https://apnews.com/article/133a5eca2b8925dfc1dc0daa1266c73e) — independent reporting on the designation, planned assistance and administration rationale
- [Federal Register — published Los Tiguerones FTO designation, 91 FR 57675](https://www.federalregister.gov/documents/2026/09/10/2026-18442/foreign-terrorist-organization-designation-of-los-tiguerones) — primary published designation
- [Federal Register — published Los Tiguerones SDGT determination, 91 FR 57675](https://www.federalregister.gov/documents/2026/09/10/2026-18443/specially-designated-global-terrorist-designation-of-los-tiguerones) — primary published determination

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
