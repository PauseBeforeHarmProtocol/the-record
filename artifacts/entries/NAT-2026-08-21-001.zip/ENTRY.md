# Education staff recommend ending the ABA's federal law-school accreditation role

**Entry ID:** NAT-2026-08-21-001
**Date:** August 21, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** reported agency staff recommendation; advisory and final decisions pending

The recommendation targets authority the American Bar Association has held since 1952, but it is not the department's final decision.

## THE FACTS

- Education Department career staff recommended removing the American Bar Association as a federally recognized law-school accreditor.
- The staff report questioned the accreditation council's independence and its handling of diversity standards. A bipartisan advisory committee was expected to consider the recommendation in September before a final department decision.
- Loss of federal recognition could affect schools' access to federal student aid and, depending on state rules, graduates' eligibility to sit for bar examinations. No recognition had been revoked as of the checked time.

## SIGNIFICANCE

Federal recognition connects accreditation to student loans, institutional viability, and professional licensing. A change of accreditor can therefore reshape legal education even without Congress changing the underlying statutes.

## GOALPOST / RESPONSE

The administration says the ABA council lacks sufficient independence and mishandled diversity requirements. The ABA says its accreditation process is independent and protects educational quality. The next evidence point is the advisory review and final agency decision, not the staff recommendation alone.


## SOURCES

- [Reuters — Education staff recommend ending ABA law-school oversight](https://www.reuters.com/legal/government/trump-administration-moves-end-attorney-groups-law-school-oversight-2026-08-21/) — independent reporting on a nonfinal agency recommendation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
