# NHTSA finalizes delayed and revised child-restraint side-impact standards

**Entry ID:** NAT-2026-09-09-001
**Date:** September 9, 2026
**Checked:** 2026-09-09 12:01 PM EDT
**Evidence state:** primary NHTSA final rule and regulatory analysis; final rule published, effective October 9 with December compliance dates, projected costs and benefits not independently measured
**Review state:** current-standard-reviewed

The final rule takes effect October 9 and moves the principal compliance date to December 5; projected savings and retained safety benefits are agency estimates.

## THE FACTS

- The National Highway Traffic Safety Administration published a final rule amending Federal Motor Vehicle Safety Standards 213, 213a and 213b for child-restraint systems. The rule takes effect October 9, 2026; the revised principal compliance date for the side-impact standard is December 5, 2026, with one updated-label requirement taking effect December 8. Optional early compliance is permitted.
- The rule exempts school-bus child restraints from FMVSS 213a side-impact testing when they meet specified labeling requirements and from lower-anchor attachments designed for other vehicles. NHTSA says school-bus restraints mount to the seat back or seat pan and that the side-impact test was not designed for school-bus crash conditions.
- NHTSA also removes the twelve-month-old CRABI dummy from forward-facing side-impact testing because those restraints may not be recommended below 12 kilograms, and it revises dummy positioning and incorporated-reference text. The final rule adopts the May 2025 proposal after 15 comments; two manufacturers opposed the compliance delay.
- NHTSA estimates about $2.65 million in consumer cost savings from the delayed date and $1.29 million in annual testing-cost reductions. It projects that most benefits attributed to the 2022 side-impact rule will remain because large manufacturers already certify most products. Those are regulatory estimates, not measured post-rule injury, price, competition or compliance outcomes.

## SIGNIFICANCE

The rule changes when and how federal side-impact requirements apply to child restraints and permanently excludes a school-bus category from tests and hardware requirements NHTSA considers mismatched. It may preserve small-manufacturer participation and reduce costs, while delaying some benefits for products not already compliant.

## GOALPOST / RESPONSE

NHTSA says the revisions align tests and attachments with actual product use, preserve competition and consumer choice and retain most safety benefits. The tests are manufacturer certifications, compliance testing, product availability and price, recalls, crash and injury data, and whether the school-bus exemption or delay produces measurable safety effects.

## MAYBE / THEREFORE

Maybe the revisions remove technically unsuitable tests and avert unnecessary market exits with little safety loss, or delaying and narrowing side-impact coverage may leave some children without benefits expected under the earlier schedule. Therefore the final rule changes binding standards and future compliance dates—not proof of the estimated savings, retained benefits or absence of safety tradeoffs.


## SOURCES

- [Federal Register — final child-restraint side-impact and school-bus standards](https://www.federalregister.gov/documents/2026/09/09/2026-18380/federal-motor-vehicle-safety-standard-no-213a-child-restraint-systems-side-impact-protection-federal) — primary final rule amending FMVSS Nos. 213, 213a and 213b, effective October 9 with later compliance dates

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
