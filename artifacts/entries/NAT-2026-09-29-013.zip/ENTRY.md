# Pentagon halts new civilian tenure appointments at military service academies

**Entry ID:** NAT-2026-09-29-013
**Date:** September 29, 2026
**Checked:** 2026-10-01 12:04 AM EDT
**Evidence state:** stable official memorandum link identified but direct document retrieval blocked, with independent Associated Press and Reuters confirmation; directive issued, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The directive stops new civilian tenure appointments; it does not on its face remove currently tenured faculty, and implementation details remain unsettled.

## THE FACTS

- Defense Secretary Pete Hegseth issued a September 29 memorandum directing the military departments to immediately stop appointing civilians to tenured positions at the U.S. military service academies.
- The official memorandum's stable Defense Department URL was identified, but direct retrieval returned an access block. Associated Press and Reuters independently reported the operative instruction halting new civilian tenure appointments and the administration's warfighting-education rationale.
- Associated Press reported that the directive does not appear to remove current tenured civilian faculty. The record therefore does not characterize existing tenure as revoked.
- Hegseth argues tenure can produce stagnation, complacency and curriculum drift. Faculty and higher-education critics say eliminating future tenure may weaken academic independence and recruitment; the Naval Academy relies heavily on civilian faculty.
- No academy-specific implementation plan, count of affected future positions, completed hiring change, litigation result or measured educational or readiness outcome was established in the inspected sources by the cutoff.

## SIGNIFICANCE

Ending new civilian tenure appointments can materially change recruitment, retention and academic independence at institutions that educate future officers. The actual effect depends on implementing plans and whether fixed-term or other appointments preserve expertise.

## GOALPOST / RESPONSE

The Pentagon says the tenure halt will keep curricula aligned with warfighting and prevent complacency. The strongest response is that tenure protects independent scholarship and helps academies recruit specialized civilian expertise. Service implementation plans, hiring and retention data, accreditation review, litigation and educational and readiness outcomes are the tests.

## MAYBE / THEREFORE

Maybe non-tenure appointments make academy staffing more responsive to mission needs, or the policy may deter qualified faculty and narrow independent teaching. Therefore the record establishes a directive halting new civilian tenure appointments—not removal of existing tenured faculty or a measured change in academy performance.


## SOURCES

- [Defense secretary memorandum — military service academy civilian tenure](https://media.defense.gov/2026/Sep/29/2004008474/-1/-1/1/REFOCUSING-THE-MILITARY-SERVICE-ACADEMIES-ON-WARFIGHTER-EDUCATION.PDF) — official memorandum; stable link identified, direct retrieval blocked
- [Associated Press — Hegseth halts new civilian tenure at service academies](https://apnews.com/article/hegseth-west-point-naval-air-force-academy-f4a185e8253a3af7baec49f0d65cd62e) — independent reporting on directive and scope
- [Reuters — Pentagon academy tenure directive](https://www.reuters.com/world/us/pentagon-chief-set-announce-additional-cuts-senior-officer-positions-2026-09-29/) — independent confirmation of defense memorandum

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
