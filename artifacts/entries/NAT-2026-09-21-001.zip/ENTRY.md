# Community lenders seek emergency order over nearly $300 million in expiring grants

**Entry ID:** NAT-2026-09-21-001
**Date:** September 21, 2026
**Checked:** 2026-09-21 6:01 PM EDT
**Evidence state:** federal docket metadata and complete Reuters reporting with named plaintiff representatives; lawsuit and emergency request filed, government response, judicial disposition, obligation and disbursement unresolved
**Review state:** current-standard-reviewed

A trade group sued Treasury and OMB over fiscal 2025 CDFI funding and sought emergency relief before the September 30 expiration date.

## THE FACTS

- The Freedom Economy Business Association filed Freedom Economy Business Association v. U.S. Department of the Treasury, No. 1:26-cv-03288, in the U.S. District Court for the District of Columbia on September 21. The suit challenges the administration's handling of nearly $300 million appropriated for fiscal 2025 Community Development Financial Institution grants; filing establishes allegations, not unlawful conduct or entitlement to relief.
- The plaintiff says Treasury announced awards on September 15 without identifying recipients or obligating the money, creating a risk that the appropriation will expire on September 30. It asks the court to order Treasury and the Office of Management and Budget to distribute the fiscal 2025 funds and proceed with another $289 million appropriated for fiscal 2026.
- The group requested a temporary restraining order to prevent the government from allowing the fiscal 2025 funds to expire. No emergency order or merits ruling existed by cutoff, and Treasury had not responded to Reuters's request for comment.
- Association representatives said delays caused one lender to close and others to lay off staff, shrink operations or take on debt. Those are attributed claims presented in support of emergency relief; the public record inspected for this release does not independently quantify each institution's loss or establish that federal delay was the sole cause.

## SIGNIFICANCE

The case puts a near-term judicial deadline around congressionally appropriated lending support for underserved communities and tests whether agencies can delay obligation until funds expire. The practical effect depends on emergency relief, actual obligation and later disbursement.

## GOALPOST / RESPONSE

The administration previously characterized some CDFIs as promoting partisan, gender and climate agendas; the lenders deny that characterization and say Congress required distribution. The complaint, government response, appropriation text, award and obligation records, emergency ruling, disbursements and independently measured service effects are the tests.

## MAYBE / THEREFORE

Maybe the court will compel timely obligation, find the plaintiff lacks a legal entitlement, or the agencies may act before a ruling. Therefore a lender association filed suit and requested emergency relief over appropriated funds at risk of expiration—not that the withholding was held unlawful, grants were awarded to named recipients or the claimed downstream losses were proven.


## SOURCES

- [Federal docket listing — Freedom Economy Business Association v. Treasury, No. 1:26-cv-03288](https://www.pacermonitor.com/public/case/66912651/FREEDOM_ECONOMY_BUSINESS_ASSOCIATION_v_UNITED_STATES_DEPARTMENT_OF_THE_TREASURY_et_al) — federal docket metadata
- [Reuters — community lenders sue over expiring CDFI grants](https://www.reuters.com/legal/government/trump-administration-sued-over-withheld-federal-grants-us-community-lenders-2026-09-21/) — independent litigation reporting with named plaintiff representatives

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
