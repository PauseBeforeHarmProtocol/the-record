# GAO finds cost and schedule gaps in air-traffic-control modernization

**Entry ID:** NAT-2026-09-14-001
**Date:** September 14, 2026
**Checked:** 2026-09-14 11:58 AM EDT
**Evidence state:** primary GAO audit and independent Reuters reporting; planning deficiencies measured, final costs, schedule performance and operational outcomes unresolved
**Review state:** current-standard-reviewed

The watchdog found that FAA lacks a complete life-cycle cost estimate and integrated master schedule for its multibillion-dollar replacement effort.

## THE FACTS

- The Government Accountability Office reported that the Federal Aviation Administration launched its Brand New Air Traffic Control System initiative in May 2025. Phase 1 is intended to be complete by December 2028, and Congress appropriated $12.5 billion supporting the initiative, most of it directed to that phase.
- GAO found that FAA had neither a comprehensive life-cycle cost estimate nor an integrated master schedule. The agency's high-level Phase 1 estimate excluded government costs, most operations costs and all Phase 2 costs; 11,389 individual schedules were not integrated, creating a risk that projects at the same site could conflict or disrupt operations.
- FAA reported replacing 2,560 of 5,170 targeted copper-wire connections as of May 2026. Phase 2 was estimated at roughly $10.2 billion excluding facilities, but FAA had not estimated when it would begin or end.
- GAO recommended that FAA produce a comprehensive life-cycle cost estimate and an integrated master schedule. The Department of Transportation partially concurred with both recommendations. Reuters separately reported FAA's estimate that Phase 1 still needed $574 million beyond identified funding; that figure is an agency estimate reported by Reuters, not a GAO appropriation finding.
- The audit identifies planning and funding risks, not a current systemwide safety failure or proof that cost overruns, delays or unmet performance targets have already occurred.

## SIGNIFICANCE

Air-traffic control is safety-critical infrastructure, and an accelerated replacement program without complete cost and schedule baselines makes congressional oversight, sequencing and accountability harder. The audit supplies concrete management tests without treating forecast risks as realized failures.

## GOALPOST / RESPONSE

The administration and FAA say aging systems require urgent modernization and rapid execution. DOT partially concurred with GAO's recommendations. A validated life-cycle estimate, integrated master schedule, sufficient appropriations, completed milestones, operational reliability and independently measured safety and capacity outcomes are the tests.

## MAYBE / THEREFORE

Maybe faster procurement can replace obsolete systems before failures worsen, or incomplete planning may produce conflicts, delays and higher costs. Therefore GAO establishes material cost-estimating and scheduling deficiencies in the modernization program—not that the current air-traffic system is unsafe everywhere or that the forecast problems are inevitable.


## SOURCES

- [GAO — Air Traffic Control Systems: Ambitious New Modernization Effort Needs to Improve Cost and Schedule Planning](https://www.gao.gov/products/gao-26-107992) — primary federal audit of FAA modernization scope, costs, schedules, progress and recommendations
- [Reuters — U.S. lacks identified funding to complete first air-traffic-control modernization phase](https://www.reuters.com/world/us/us-lacks-funding-complete-first-phase-air-traffic-control-reforms-2026-09-14/) — independent reporting of GAO findings, FAA funding estimates and agency response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
