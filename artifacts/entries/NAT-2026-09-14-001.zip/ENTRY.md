# FAA adds tariff and telecom-cost estimates to modernization gaps

**Entry ID:** NAT-2026-09-14-001
**Date:** September 14–21, 2026
**Checked:** 2026-09-21 6:01 PM EDT
**Evidence state:** primary GAO audit plus independent Associated Press and Reuters reporting with named FAA and Transportation officials; planning gaps, cost estimates and a measured dual-connectivity outage documented, root cause, final costs and long-term reliability unresolved
**Review state:** current-standard-reviewed

A failed primary circuit and a severed backup fiber line disrupted Northeast flights, turning modernization gaps into a measured operational failure.

## THE FACTS

- The Government Accountability Office reported that the Federal Aviation Administration launched its Brand New Air Traffic Control System initiative in May 2025. Phase 1 is intended to be complete by December 2028, and Congress appropriated $12.5 billion supporting the initiative, most of it directed to that phase.
- GAO found that FAA had neither a comprehensive life-cycle cost estimate nor an integrated master schedule. The agency's high-level Phase 1 estimate excluded government costs, most operations costs and all Phase 2 costs; 11,389 individual schedules were not integrated, creating a risk that projects at the same site could conflict or disrupt operations.
- FAA reported replacing 2,560 of 5,170 targeted copper-wire connections as of May 2026. Phase 2 was estimated at roughly $10.2 billion excluding facilities, but FAA had not estimated when it would begin or end.
- GAO recommended that FAA produce a comprehensive life-cycle cost estimate and an integrated master schedule. The Department of Transportation partially concurred with both recommendations. Reuters separately reported FAA's estimate that Phase 1 still needed $574 million beyond identified funding; that figure is an agency estimate reported by Reuters, not a GAO appropriation finding.
- The audit identifies planning and funding risks, not a current systemwide safety failure or proof that cost overruns, delays or unmet performance targets have already occurred.
- On September 17, FAA Administrator Bryan Bedford told lawmakers that tariffs were expected to add about $100 million to the more than $12.5 billion modernization effort, largely through radar purchases. Reuters also reported that a government estimate for the telecommunications upgrade rose from $4.75 billion to $5.91 billion. These are current estimates, not final costs or proof that tariffs caused the entire telecom increase.
- On September 21, a primary telecommunications circuit failed at the FAA's Philadelphia air-traffic facility; when systems attempted to switch over, the backup fiber-optic line was found severed. Transportation Secretary Sean Duffy attributed the cut to an Amtrak construction crew, while FAA Administrator Bryan Bedford said the agency was installing a replacement circuit and repairing the fiber. These are named official accounts reported independently by Associated Press and Reuters, not a completed root-cause investigation.
- The failure halted or restricted incoming flights at major New York-area and Philadelphia airports for several hours. Reuters reported more than 5,600 U.S. flight delays or cancellations, including about 1,200 in the New York area, and more than 100 diversions by late afternoon; operations began resuming before repairs were complete. The totals measure same-day disruption, not the eventual repair cost or the portion of every delay caused solely by this outage.

## SIGNIFICANCE

The outage converts GAO's planning warnings and rising telecom estimates into a measured operational failure affecting several major airports. It does not establish that the modernization program as a whole failed, but it exposes the consequence of losing both primary and backup connectivity before replacement work is complete.

## GOALPOST / RESPONSE

FAA says aging systems require urgent replacement and that it stopped traffic until operations could proceed safely. A documented root-cause review, restored redundancy, repair and diversion costs, a validated life-cycle estimate, integrated schedule, completed replacements and sustained reliability and safety data are the tests.

## MAYBE / THEREFORE

Maybe rapid circuit replacement and fiber repair will isolate a rare dual failure, or the incident may reveal broader redundancy, construction-coordination and modernization risks. Therefore the evidence establishes a failed primary circuit, severed backup fiber and thousands of disrupted flights—not a proven systemwide safety failure, final repair cost or completed modernization result.


## SOURCES

- [GAO — Air Traffic Control Systems: Ambitious New Modernization Effort Needs to Improve Cost and Schedule Planning](https://www.gao.gov/products/gao-26-107992) — primary federal audit of FAA modernization scope, costs, schedules, progress and recommendations
- [Reuters — U.S. lacks identified funding to complete first air-traffic-control modernization phase](https://www.reuters.com/world/us/us-lacks-funding-complete-first-phase-air-traffic-control-reforms-2026-09-14/) — independent reporting of GAO findings, FAA funding estimates and agency response
- [Reuters — FAA estimates tariff cost for air-traffic-control modernization](https://www.reuters.com/world/us/faa-sees-100-million-impact-tariffs-air-traffic-control-modernization-plan-2026-09-17/) — independent congressional-hearing reporting of named FAA estimates
- [Associated Press — Northeast flights disrupted by dual FAA telecom failure](https://apnews.com/article/faa-flights-laguardia-newark-jfk-airport-85e2321733ff604f7a5e93ce136945b9) — independent reporting with named FAA and Transportation officials
- [Reuters — dual FAA telecom failure disrupts thousands of flights](https://www.reuters.com/world/us/faa-halts-some-us-east-coast-flights-due-communication-issues-2026-09-21/) — independent operational and disruption reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
