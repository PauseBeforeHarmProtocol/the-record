# FAA adds tariff and telecom-cost estimates to modernization gaps

**Entry ID:** NAT-2026-09-14-001
**Date:** September 14–17, 2026
**Checked:** 2026-09-18 12:00 AM EDT
**Evidence state:** primary GAO audit plus independent Reuters reporting of named FAA estimates; planning deficiencies and current cost estimates documented, final cost, schedule and operational outcomes unresolved
**Review state:** current-standard-reviewed

The agency estimates roughly $100 million in tariff costs, while a telecom-upgrade estimate rose to $5.91 billion; neither is a final life-cycle total.

## THE FACTS

- The Government Accountability Office reported that the Federal Aviation Administration launched its Brand New Air Traffic Control System initiative in May 2025. Phase 1 is intended to be complete by December 2028, and Congress appropriated $12.5 billion supporting the initiative, most of it directed to that phase.
- GAO found that FAA had neither a comprehensive life-cycle cost estimate nor an integrated master schedule. The agency's high-level Phase 1 estimate excluded government costs, most operations costs and all Phase 2 costs; 11,389 individual schedules were not integrated, creating a risk that projects at the same site could conflict or disrupt operations.
- FAA reported replacing 2,560 of 5,170 targeted copper-wire connections as of May 2026. Phase 2 was estimated at roughly $10.2 billion excluding facilities, but FAA had not estimated when it would begin or end.
- GAO recommended that FAA produce a comprehensive life-cycle cost estimate and an integrated master schedule. The Department of Transportation partially concurred with both recommendations. Reuters separately reported FAA's estimate that Phase 1 still needed $574 million beyond identified funding; that figure is an agency estimate reported by Reuters, not a GAO appropriation finding.
- The audit identifies planning and funding risks, not a current systemwide safety failure or proof that cost overruns, delays or unmet performance targets have already occurred.
- On September 17, FAA Administrator Bryan Bedford told lawmakers that tariffs were expected to add about $100 million to the more than $12.5 billion modernization effort, largely through radar purchases. Reuters also reported that a government estimate for the telecommunications upgrade rose from $4.75 billion to $5.91 billion. These are current estimates, not final costs or proof that tariffs caused the entire telecom increase.

## SIGNIFICANCE

The new estimates add concrete cost pressure to GAO's finding that FAA lacks a complete life-cycle baseline and integrated schedule. They improve visibility into particular components without resolving the audit's program-wide planning gaps.

## GOALPOST / RESPONSE

FAA says aging systems require urgent replacement, and Bedford characterized the tariff impact as manageable relative to the program. Tests remain a validated life-cycle estimate, integrated schedule, sufficient appropriations, documented procurement prices, completed milestones and measured safety and capacity outcomes.

## MAYBE / THEREFORE

Maybe accelerated purchases absorb the tariff cost while delivering needed systems, or incomplete baselines may obscure larger overruns and sequencing problems. Therefore the record establishes agency and government estimates—not a final $100 million bill, a tariff-only explanation for the telecom increase or a completed modernization outcome.


## SOURCES

- [GAO — Air Traffic Control Systems: Ambitious New Modernization Effort Needs to Improve Cost and Schedule Planning](https://www.gao.gov/products/gao-26-107992) — primary federal audit of FAA modernization scope, costs, schedules, progress and recommendations
- [Reuters — U.S. lacks identified funding to complete first air-traffic-control modernization phase](https://www.reuters.com/world/us/us-lacks-funding-complete-first-phase-air-traffic-control-reforms-2026-09-14/) — independent reporting of GAO findings, FAA funding estimates and agency response
- [Reuters — FAA estimates tariff cost for air-traffic-control modernization](https://www.reuters.com/world/us/faa-sees-100-million-impact-tariffs-air-traffic-control-modernization-plan-2026-09-17/) — independent congressional-hearing reporting of named FAA estimates

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
