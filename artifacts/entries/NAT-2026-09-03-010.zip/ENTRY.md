# FinCEN imposes enhanced cash-transaction reporting on southwest-border money services

**Entry ID:** NAT-2026-09-03-010
**Date:** September 3–4, 2026
**Checked:** 2026-09-04 6:02 AM EDT
**Evidence state:** primary FinCEN Geographic Targeting Order; effective with transition and injunction limitations, results unmeasured
**Review state:** current-standard-reviewed

Covered businesses in specified Texas and New Mexico ZIP codes must report $1,000-to-$10,000 currency transactions under an effective six-month order, subject to a transition period and injunction carveout.

## THE FACTS

- FinCEN issued a Geographic Targeting Order effective September 3 through March 1, 2027, requiring covered money-services businesses in specified Texas and New Mexico ZIP codes to report qualifying cash transactions between $1,000 and $10,000.
- Covered businesses generally must verify customer identity, file the required currency transaction report within 30 days and retain related records for five years. Willful or negligent violations can carry existing civil or criminal penalties.
- Businesses newly covered compared with the March 2026 order have until October 3 to comply. The order does not apply where a current injunction still bars FinCEN from applying the March 14, 2025 southwest-border order to the business.
- FinCEN said the targeted reporting will help identify illicit finance connected to cartels and other actors. A report is a financial-intelligence lead, not proof that a customer or business committed a crime, and the order reports no enforcement or disruption result yet.

## SIGNIFICANCE

Lower-threshold reporting can expose cash patterns missed by the ordinary $10,000 currency-reporting threshold, but it also expands collection of identifying financial data about lawful transactions and increases compliance burdens in designated communities.

## GOALPOST / RESPONSE

FinCEN says the order is geographically focused and necessary to combat cartel finance. Filing volume, useful investigative leads, prosecutions, asset seizures, false-positive burden, business closures or displacement, privacy and civil-liberties complaints, injunction changes and a renewal or termination decision are the tests.

## MAYBE / THEREFORE

Maybe targeted lower-threshold reports will reveal otherwise hidden laundering networks, or they may generate large volumes of lawful-customer data while shifting illicit activity elsewhere. Therefore the record establishes an effective reporting order with defined limits—not criminality by reported customers, successful cartel disruption or a permanent national rule.


## SOURCES

- [FinCEN — southwest-border currency-transaction Geographic Targeting Order](https://www.federalregister.gov/documents/2026/09/04/2026-18194/geographic-targeting-order-imposing-recordkeeping-and-reporting-requirements-on-certain-money) — primary effective order imposing enhanced reporting on covered money-services businesses in specified ZIP codes

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
