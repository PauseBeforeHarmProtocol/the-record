# Court vacates and enjoins transgender-related Ryan White funding conditions

**Entry ID:** NAT-2026-11-19-009
**Date:** November 19, 2026
**Checked:** 2026-11-20 7:13 AM EST
**Evidence state:** primary 165-page post-trial opinion and order plus independent Reuters reporting; challenged conditions vacated and permanently enjoined for plaintiff organizational members, with appeal and implementation unresolved
**Review state:** current-standard-reviewed

After trial, a federal judge vacated Ryan White grant conditions and permanently barred their use against plaintiff organizations' members; the ruling does not yet establish appellate finality or program-wide outcomes.

## THE FACTS

- After a September bench trial, U.S. District Judge William Young vacated the challenged Health Resources and Services Administration conditions for Ryan White HIV/AIDS Program grants. The court declared the conditions unconstitutional under the First Amendment and the Fifth Amendment's equal-protection component and contrary to the Ryan White CARE Act.
- The court separately held a Title IX-related condition arbitrary and capricious and permanently enjoined HHS and its agents from imposing the challenged or similar conditions on the plaintiff organizations' members. The stated injunction scope is those associational members, not a finding about every provider or every federal health grant.
- The conditions had required funded providers to use sex-based definitions grounded in biological reality and to avoid activities characterized as social or medical experimentation. They were adopted to implement the administration's policy recognizing two sexes and opposing federal support for what it calls gender ideology.
- Reuters reported that the ruling followed a non-jury trial and that HHS did not immediately respond to its request for comment. The order resolves the trial-court merits and grants permanent relief, but it does not establish whether the government will appeal, whether a stay will issue or how every grant and patient service will change.

## SIGNIFICANCE

The post-trial judgment removes operative federal funding conditions for a national group of Ryan White providers and resolves constitutional and statutory claims at the district-court level. Careful scope language matters because the injunction protects plaintiff organizational members and remains subject to appellate procedure.

## GOALPOST / RESPONSE

The administration framed the conditions as enforcing sex-based statutory definitions and preventing federal support for gender ideology; the court found the conditions unlawful. The tests are any appeal or stay, revised HRSA grant terms, notices to affected recipients, funding and service continuity, compliance, and measured effects on HIV care for transgender patients.

## MAYBE / THEREFORE

Maybe the permanent injunction will preserve comprehensive HIV services for affected providers and patients, or appellate review and implementation disputes may narrow its reach. Therefore the district court vacated the conditions and permanently enjoined their use against plaintiff members; it did not decide every grant, foreclose appeal or measure downstream health outcomes.


## SOURCES

- [American Academy of HIV Medicine v. HHS — opinion and permanent injunction](https://lambdalegal.org/wp-content/uploads/2026/11/Opinion-Order.pdf_8109.pdf) — primary post-trial opinion and order, No. 1:26-cv-12638-WGY, ECF 91
- [Reuters via Investing.com — judge blocks transgender-related Ryan White funding conditions](https://www.investing.com/news/economy-news/judge-blocks-trumps-transgenderrelated-limits-on-hiv-funding-5039623) — independent reporting on the post-trial ruling, program context and absence of an immediate HHS response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
