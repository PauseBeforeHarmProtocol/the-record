# Trump orders saltwater-angling data, permitting and access changes

**Entry ID:** NAT-2026-09-17-010
**Date:** September 17, 2026
**Checked:** 2026-09-20 11:58 PM EDT
**Evidence state:** complete signed White House order; policy and deadlines ordered, implementing rules, systems and measured fishery outcomes pending
**Review state:** current-standard-reviewed

The order directs fisheries-data modernization, regulatory reviews, multi-year permit planning, artificial-reef programs and predator-management steps.

## THE FACTS

- Trump signed a September 17 executive order making marine recreational fishing an explicit consideration in federal ocean, coastal and public-land decisions. Commerce must review selected Magnuson-Stevens National Standards guidelines within 180 days, including how recreational-fishery characteristics and state data enter federal decisions; this prior-window omission records an order, not a completed rule change.
- NOAA must evaluate traditional mail surveys, develop standardized mobile reporting and a modernized data architecture, consider state-data substitution when federal estimates have high error, initiate at least two pilot programs and produce a five-year recreational-fisheries economic-data plan within 180 days.
- Within 30 days, Interior, Agriculture, Commerce and the Army civil-works office must begin steps toward suspending, revising or rescinding rules they find overly burdensome. Agencies must evaluate minimum three-year permits within 60 days and aim for a unified special-use permit portal within one year; the order does not itself rescind a named regulation or issue a permit.
- The order also directs an offshore structures-to-reefs program within 60 days, a shark and pinniped depredation task force and reporting protocol, and review of Sport Fish Restoration fund hurdles. The administration says the changes will improve data, access and coastal economies, but implementation is subject to law and appropriations and no quota, permit, stock or economic result was established by cutoff.

## SIGNIFICANCE

The order could reshape how federal fisheries science, quotas, permitting, offshore structures and predator policy account for recreational fishing. Its broad instructions create consequential implementation choices, but the signed order alone does not validate the administration's data criticisms or establish ecological or economic benefits.

## GOALPOST / RESPONSE

The administration says current federal data and rules unnecessarily restrict recreational access and that mobile reporting, state partnerships and streamlined permits will improve management. Final rules and guidance, survey validation, data quality, portal deployment, permit times, stock assessments, catch limits, safety and environmental outcomes are the tests.

## MAYBE / THEREFORE

Maybe modern reporting and longer permits will improve decisions and reduce administrative cost while sustaining stocks, or weaker safeguards and biased or incomplete self-reporting may undermine conservation. Therefore the order launches reviews, pilots and program deadlines—not a completed survey phaseout, quota change, permit reform or demonstrated fisheries outcome.


## SOURCES

- [White House — Restoring American Saltwater Angling and Recreation executive order](https://www.whitehouse.gov/presidential-actions/2026/09/restoring-american-saltwater-angling-and-recreation/) — primary signed executive order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
