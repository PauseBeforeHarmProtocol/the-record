# Pentagon removes top military planner amid disputed leak allegations and referral

**Entry ID:** NAT-2026-10-28-006
**Date:** October 28–29, 2026
**Checked:** 2026-10-30 12:04 PM EDT
**Evidence state:** named primary Parnell statement plus independent AP and CBS reporting; reported removal and disputed investigation allegations; no original personnel/investigative file or charges retrieved
**Review state:** current-standard-reviewed

AP and CBS report Sylvia’s firing; Parnell confirms an unnamed personnel action and potential DOJ referral, not charges or proof of leaking.

## THE FACTS

- AP and CBS reported that Defense Secretary Pete Hegseth fired Army Lt. Gen. Brett Sylvia from the Joint Staff strategy, plans and policy post on October 28. CBS says several sources confirmed the firing. The reports establish a consequential reported removal of a senior military planner; the original personnel instrument was not retrieved.
- In an October 29 public statement, chief Pentagon spokesman Sean Parnell said an Air Force OSI investigation led to personnel action to protect sensitive information and that the matter, with others, had been referred to DOJ for potential further legal action. He declined details and did not name Sylvia. AP and CBS connect the statement to the firing; the statement itself is not an identification of the subject or an announcement of criminal charges.
- An unnamed Pentagon official accused Sylvia of sharing classified Iran- and Ukraine-war information and failing polygraphs. CBS separately reports two Pentagon sources disputed the accusations while confirming their connection to the firing. AP reported no response from Sylvia, and both outlets describe the Joint Staff withdrawing its initial gratitude statement. No investigative file, polygraph result, criminal charge, guilt finding or admission by Sylvia was inspected; the contested allegations remain allegations.

## SIGNIFICANCE

Removing a top Joint Staff planner and referring a classified-information matter for potential legal action affect military planning, personnel accountability and internal trust. The disputed basis makes transparent process and reliable evidence central; neither a firing nor a referral resolves whether a crime occurred.

## GOALPOST / RESPONSE

Parnell’s strongest stated case is protecting sensitive information, service members and military operations, with investigative confidentiality explaining limited disclosure. The countervailing evidence is CBS’s reporting that two Pentagon sources dispute the accusations. The personnel instrument, investigative findings, defense response and any actual charging decision are the tests.

## MAYBE / THEREFORE

Maybe the removal and referral reflect a substantiated security breach requiring swift action, or disputed evidence and leak-hunting practices may have produced an unjustified personnel action. Therefore a consequential reported firing and an official unnamed referral statement are recorded, while Sylvia’s alleged conduct, guilt, any criminal charge and the reliability of polygraph claims remain unproven.


## SOURCES

- [Sean Parnell — personnel action and DOJ referral statement](https://x.com/SeanParnellASW/status/2115814273322570231) — primary named official statement; does not name the subject
- [AP — Pentagon accuses newly fired general of leaking sensitive information to the media](https://apnews.com/article/general-firing-hegseth-pentagon-leaks-346ce31afab5dfc2cacc5efac502bc6d) — independent reporting; allegations and official statements distinguished
- [CBS News — Hegseth fires the Pentagon’s top military planner](https://www.cbsnews.com/news/hegseth-fires-pentagons-top-military-planner/) — independent reporting; multiple sources and disputed accusations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
