# Russia releases wrongfully detained American Stephen Hubbard

**Entry ID:** NAT-2026-10-21-001
**Date:** October 21, 2026
**Checked:** 2026-10-21 5:55 AM EDT
**Evidence state:** independently confirmed completed release with named U.S. and Russian official attribution; detention history and U.S. wrongful-detention designation reported; release terms and broader diplomatic effects undisclosed
**Review state:** current-standard-reviewed

The completed release occurred during Steve Witkoff's meeting with Vladimir Putin after Trump pressed the case, but no exchange terms or broader diplomatic breakthrough were disclosed.

## THE FACTS

- Russia released 74-year-old American Stephen Hubbard on October 21. President Vladimir Putin said Hubbard was at St. Petersburg's Pulkovo airport, and U.S. envoy Steve Witkoff confirmed the release during his meeting with Putin. Reuters and the Associated Press independently reported the completed release.
- Hubbard, a retired teacher from Michigan, had been detained after Russian forces entered Izyum in April 2022 and was sentenced in a closed trial to nearly seven years on a mercenary charge. His lawyer denied that he fought or had military experience, and the United States had formally designated him wrongfully detained.
- Trump had publicly said he pressed Putin at length to free Hubbard. The Associated Press reported that Witkoff had tried without success to steer Russia and Ukraine toward a settlement. The inspected reporting did not disclose an exchange, concession or other release terms, and it did not establish progress toward a broader settlement of Russia's war in Ukraine.

## SIGNIFICANCE

The release resolves the detention of the only American then officially designated wrongfully detained in Russia and provides a concrete humanitarian result from a direct U.S.-Russia channel. Its broader diplomatic meaning is limited by undisclosed terms and the absence of evidence that the parties narrowed their differences over Ukraine.

## GOALPOST / RESPONSE

The strongest administration case is that Trump's direct request and Witkoff's engagement helped secure an American's freedom. The tests are Hubbard's safe return, disclosure of any exchange or concessions, the handling of other detainees and whether the same channel produces verifiable progress on the war rather than a one-person release alone.

## MAYBE / THEREFORE

Maybe direct presidential and envoy-level diplomacy was decisive in securing Hubbard's release, or Russia may have used a humanitarian case to shape a high-level meeting without changing its wider conduct. Therefore the record establishes a completed release during active diplomacy—not the validity of Russia's conviction, the absence of undisclosed terms or a breakthrough in Ukraine negotiations.


## SOURCES

- [Reuters — Russia releases wrongfully detained American Stephen Hubbard](https://www.reuters.com/legal/litigation/putin-says-russia-has-freed-us-citizen-stephen-hubbard-2026-10-21/) — independent reporting confirming the completed release, detention history and announcement during the Witkoff-Putin meeting
- [Associated Press — Russia releases American Stephen Hubbard during Witkoff-Putin meeting](https://apnews.com/article/russia-american-released-stephen-hubbard-ukraine-witkoff-2c7e34d6606be242ed4a7473e57110c7) — independent reporting confirming the release and attributing the U.S. request and diplomatic context to named officials

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
