# Russia releases wrongfully detained American Stephen Hubbard

**Entry ID:** NAT-2026-10-21-001
**Date:** October 21, 2026
**Checked:** 2026-10-21 11:57 AM EDT
**Evidence state:** independently confirmed completed release with named U.S. and Russian official attribution; presidential no-swap assertion reported but not independently documented; broader diplomatic effects unresolved
**Review state:** current-standard-reviewed

The completed release occurred during Steve Witkoff's meeting with Vladimir Putin after Trump pressed the case, but no exchange terms or broader diplomatic breakthrough were disclosed.

## THE FACTS

- Russia released 74-year-old American Stephen Hubbard on October 21. President Vladimir Putin said Hubbard was at St. Petersburg's Pulkovo airport, and U.S. envoy Steve Witkoff confirmed the release during his meeting with Putin. Reuters and the Associated Press independently reported the completed release.
- Hubbard, a retired teacher from Michigan, had been detained after Russian forces entered Izyum in April 2022 and was sentenced in a closed trial to nearly seven years on a mercenary charge. His lawyer denied that he fought or had military experience, and the United States had formally designated him wrongfully detained.
- Trump said on Truth Social that Hubbard was released at his direct request and asserted that there was no swap and nothing given in return. Reuters reported the attributed statement, but the inspected sources supplied no agreement or independent documentation of release terms. The claim is recorded as the President's statement, not independently verified fact, and the release did not establish a broader Ukraine settlement.

## SIGNIFICANCE

The release resolves the detention of the only American then officially designated wrongfully detained in Russia and provides a concrete humanitarian result from a direct U.S.-Russia channel. The President's no-concession claim narrows the administration's account, but absent disclosed documentation it does not resolve the terms or prove wider diplomatic progress.

## GOALPOST / RESPONSE

The strongest administration case is that Trump's direct request and Witkoff's engagement secured an American's freedom without a swap or concession. The tests are Hubbard's safe return, documentary confirmation of terms, the handling of other detainees and whether the same channel produces verifiable progress on the war.

## MAYBE / THEREFORE

Maybe direct presidential and envoy-level diplomacy secured Hubbard's release without any concession, or undisclosed understandings and Russia's wider strategic use of the meeting may remain. Therefore the record establishes a completed release and preserves the President's attributed no-swap claim—not independent verification of all terms or a breakthrough in Ukraine negotiations.


## SOURCES

- [Reuters — Russia releases wrongfully detained American Stephen Hubbard](https://www.reuters.com/legal/litigation/putin-says-russia-has-freed-us-citizen-stephen-hubbard-2026-10-21/) — independent reporting confirming the completed release, detention history and announcement during the Witkoff-Putin meeting
- [Associated Press — Russia releases American Stephen Hubbard during Witkoff-Putin meeting](https://apnews.com/article/russia-american-released-stephen-hubbard-ukraine-witkoff-2c7e34d6606be242ed4a7473e57110c7) — independent reporting confirming the release and attributing the U.S. request and diplomatic context to named officials
- [Donald Trump Truth Social — Hubbard release terms statement](https://truthsocial.com/@realDonaldTrump/117478460769539937) — primary evidence only that Trump said Hubbard was released at his request and asserted there was no exchange or concession
- [Reuters — Trump says Hubbard release involved no swap or concession](https://www.reuters.com/world/trump-says-russia-has-released-us-citizen-hubbard-prison-2026-10-21/) — independent reporting of the President's attributed statement, without independent verification of undisclosed terms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
