# September payroll growth slows to 29,000 as unemployment rises to 4.2%

**Entry ID:** NAT-2026-10-02-001
**Date:** October 2–11, 2026
**Checked:** 2026-10-11 12:03 PM EDT
**Evidence state:** official BLS labor-market and manufacturing-employment measurements plus independent Reuters and Associated Press reporting; company-specific tariff-cost and layoff accounts are attributed, the administration response is preserved, and national policy causation remains unresolved
**Review state:** current-standard-reviewed

BLS measured 29,000 added jobs and 4.2% unemployment; manufacturing gained 9,000 in September but remained 21,000 jobs below January 2025 as named employers reported tariff-linked input pressure.

## THE FACTS

- The Bureau of Labor Statistics reported that total nonfarm payroll employment increased by an estimated 29,000 in September and that unemployment rose from 4.1% to 4.2%, with 7.1 million people unemployed. BLS described both measures as little changed.
- Labor-force participation was 61.8% and the employment-population ratio was 59.2%, both little changed. Black unemployment increased to 7.0%; long-term unemployment was 1.9 million, or 27.1% of all unemployed people.
- Health care added 17,000 jobs, construction 11,000 and manufacturing 9,000, while BLS said employment in every major industry changed little. Average hourly earnings rose 0.1% for the month and 3.0% over the year.
- BLS revised July payrolls from a gain of 21,000 to a loss of 10,000 and August from 162,000 to 133,000, reducing the two-month total by 60,000. The September estimate remains preliminary and subject to revision.
- Reuters reported that economists had expected 90,000 jobs and described a low-hire, low-fire labor market without evidence of broad layoffs; economists also warned that a late Labor Day can depress the seasonally adjusted September estimate. Associated Press reported that more people entered the labor force and that unemployment remained historically low.
- No specific White House response to the September report was located by the cutoff. The administration's broader economic case emphasizes employment gains and manufacturing investment, but neither the monthly estimates nor independent reporting establish that a particular administration policy caused the September result.
- The BLS manufacturing series measured 12.652 million jobs in September 2026, 21,000 fewer than the 12.673 million recorded in January 2025, even after a 72,000-job rebound from the December 2025 low. That longer horizon qualifies the administration’s factory-boom claim without erasing the recent monthly gains.
- Associated Press reported that Howard Miller closed and laid off nearly 200 workers after imported-part costs compounded preexisting demand problems; Winnebago cut 200 jobs after imported aluminum, steel and electronics costs rose by tens of millions of dollars; and Vornado Air laid off more than 70 factory workers while blaming higher imported-part prices. These are named company and worker accounts, not a nationwide causal estimate, and AP explicitly noted that tariffs are far from the only cause of long-running manufacturing job losses.
- White House spokeswoman Taylor Rogers told AP that a factory boom was underway, citing manufacturing output and nonresidential construction work, and said current factory-construction jobs should produce future manufacturing jobs. Subsequent employment, output, investment, plant openings and closures remain the measurable tests.

## SIGNIFICANCE

The last broad labor-market reading before the midterm election shows markedly slower hiring and large downward revisions while unemployment remains low and layoffs do not appear broad-based. The manufacturing follow-up adds an effectiveness test: factory employment has recovered from late 2025 but remained slightly below January 2025, while some firms describe tariff-driven input costs alongside older demand and industry problems. That mixed record neither proves a broad factory renaissance nor establishes tariffs as the sole cause of individual closures.

## GOALPOST / RESPONSE

The administration says its trade, energy and investment agenda supports employment and that factory construction will produce future manufacturing jobs. BLS shows a 72,000 manufacturing-job recovery from December 2025 but a 21,000 shortfall versus January 2025, while the broader September report showed 29,000 payroll growth and 4.2% unemployment. Revisions, claims, hiring and separations, real wages, participation, manufacturing output, inflation-adjusted investment, announced-versus-open plants, closures and supply-chain substitution are the tests.

## MAYBE / THEREFORE

Maybe September reflects calendar noise in a stable low-hire, low-fire market, and new factories or domestic supply chains may require more time to translate construction into payrolls; some closures also would have occurred without tariffs. Therefore the evidence establishes a preliminary 29,000 payroll gain, 4.2% unemployment and a recent manufacturing rebound that has not yet restored January 2025 employment—plus company-specific tariff pressure, not a recession, factory boom or settled national causal verdict.


## SOURCES

- [Bureau of Labor Statistics — Employment Situation, September 2026](https://www.bls.gov/news.release/archives/empsit_10022026.htm) — primary statistical release
- [Reuters — September job growth slows and unemployment rises](https://www.reuters.com/business/us-job-growth-slows-sharply-september-unemployment-rate-rises-42-2026-10-02/) — independent reporting on labor-market measurements, revisions and interpretation
- [Associated Press — September hiring slows and unemployment ticks higher](https://apnews.com/article/jobs-unemployment-economy-ai-hiring-44b99f9ccbff863888af99402ddf535e) — independent reporting on labor-market measurements and context
- [Bureau of Labor Statistics — national manufacturing employment series through September 2026](https://www.bls.gov/regions/mid-atlantic/data/xg-tables/ro3fx9584.htm) — primary seasonally adjusted employment series
- [Associated Press — factory workers and employers report tariff-linked costs and layoffs](https://apnews.com/article/trump-midterms-factories-tariffs-manufacturing-jobs-layoffs-1584722c00516772822a879e9eeef10f) — independent reporting on named company outcomes, worker accounts, administration response and material causal limits

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
