# September payroll growth slows to 29,000 as unemployment rises to 4.2%

**Entry ID:** NAT-2026-10-02-001
**Date:** October 2, 2026
**Checked:** 2026-10-02 11:56 AM EDT
**Evidence state:** official BLS September Employment Situation plus independent Reuters and Associated Press reporting; measured payroll, unemployment, participation, wage and revision estimates are documented, while estimates remain revisable and causation unresolved
**Review state:** current-standard-reviewed

BLS measured little-changed payrolls and unemployment, revised July and August down by a combined 60,000 jobs, and reported the slowest annual wage growth since May 2021.

## THE FACTS

- The Bureau of Labor Statistics reported that total nonfarm payroll employment increased by an estimated 29,000 in September and that unemployment rose from 4.1% to 4.2%, with 7.1 million people unemployed. BLS described both measures as little changed.
- Labor-force participation was 61.8% and the employment-population ratio was 59.2%, both little changed. Black unemployment increased to 7.0%; long-term unemployment was 1.9 million, or 27.1% of all unemployed people.
- Health care added 17,000 jobs, construction 11,000 and manufacturing 9,000, while BLS said employment in every major industry changed little. Average hourly earnings rose 0.1% for the month and 3.0% over the year.
- BLS revised July payrolls from a gain of 21,000 to a loss of 10,000 and August from 162,000 to 133,000, reducing the two-month total by 60,000. The September estimate remains preliminary and subject to revision.
- Reuters reported that economists had expected 90,000 jobs and described a low-hire, low-fire labor market without evidence of broad layoffs; economists also warned that a late Labor Day can depress the seasonally adjusted September estimate. Associated Press reported that more people entered the labor force and that unemployment remained historically low.
- No specific White House response to the September report was located by the cutoff. The administration's broader economic case emphasizes employment gains and manufacturing investment, but neither the monthly estimates nor independent reporting establish that a particular administration policy caused the September result.

## SIGNIFICANCE

The last broad labor-market reading before the midterm election shows markedly slower hiring and large downward revisions while unemployment remains low and layoffs do not appear broad-based. The measured outcome affects household expectations and Federal Reserve decisions, but one volatile monthly estimate cannot establish a recession or policy causation.

## GOALPOST / RESPONSE

The administration's broader case is that its trade, energy and investment agenda supports domestic employment, while BLS characterizes both payroll and unemployment changes as small and economists cite seasonal volatility and low layoffs. Revisions, unemployment claims, hiring and separation data, real wages, labor-force participation and subsequent monthly reports are the tests.

## MAYBE / THEREFORE

Maybe September reflects calendar-related noise in a stable low-hire, low-fire market, or it may be an early sign that war, trade and borrowing-cost pressures are weakening demand. Therefore the record establishes a 29,000 preliminary payroll gain, 4.2% unemployment and 60,000 in downward revisions—not a recession, mass layoffs or a proven cause.


## SOURCES

- [Bureau of Labor Statistics — Employment Situation, September 2026](https://www.bls.gov/news.release/archives/empsit_10022026.htm) — primary statistical release
- [Reuters — September job growth slows and unemployment rises](https://www.reuters.com/business/us-job-growth-slows-sharply-september-unemployment-rate-rises-42-2026-10-02/) — independent reporting on labor-market measurements, revisions and interpretation
- [Associated Press — September hiring slows and unemployment ticks higher](https://apnews.com/article/jobs-unemployment-economy-ai-hiring-44b99f9ccbff863888af99402ddf535e) — independent reporting on labor-market measurements and context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
