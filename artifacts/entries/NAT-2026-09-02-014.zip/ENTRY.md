# Trump signs stopgap funding law through December 11

**Entry ID:** NAT-2026-09-02-014
**Date:** August 8–September 2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** primary White House signing notice plus Reuters congressional reporting; H.R. 6500 enacted, temporary appropriations and extensions operative, full-year funding unresolved
**Review state:** current-standard-reviewed

H.R. 6500 averts an October 1 funding lapse and extends several programs but leaves all 12 full-year appropriations bills unresolved.

## THE FACTS

- President Trump signed H.R. 6500, the Continuing Appropriations and Extensions Act, 2027, on September 2 after the Senate passed it on August 8 and the House approved it 370–48 on September 1.
- The law continues fiscal year 2027 appropriations for federal agencies through December 11, 2026 and extends authorities for a range of programs, including surface transportation and veterans programs.
- Enactment prevents a funding lapse when the new fiscal year begins October 1. Reuters reported that Congress had not completed any of the 12 regular full-year appropriations bills, so the law postpones rather than resolves those decisions.
- The continuing resolution maintains government operations at specified temporary funding terms. It does not enact full-year appropriations through September 2027, eliminate future shutdown risk after December 11 or resolve broader debt and affordability questions.

## SIGNIFICANCE

The signature is an implemented appropriations action that preserves federal operations through the midterm-election period and shifts the next major funding deadline to December. It reduces immediate shutdown risk while leaving Congress a compressed post-election negotiation over full-year spending.

## GOALPOST / RESPONSE

The administration and congressional supporters say the measure provides continuity and avoids another disruptive shutdown. The strongest response is that another short-term extension delays programmatic choices, reduces planning certainty and leaves the same conflict for December. Agency apportionments, anomalies, program operations, full-year bills and action before December 11 are the tests.

## MAYBE / THEREFORE

Maybe the extension will provide enough time for orderly full-year appropriations after the election, or it may simply move the shutdown risk into a shorter and politically volatile December window. Therefore the record confirms enacted temporary funding and program extensions through December 11—not full-year funding, resolution of all appropriations disputes or proof that no agency disruption will occur.


## SOURCES

- [White House — H.R. 6500 signed into law](https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-6500-signed-into-law/) — primary presidential notice confirming enactment and describing the continuing resolution and program extensions
- [Reuters — Trump signs stopgap funding law through December 11](https://www.reuters.com/legal/government/trump-signs-bill-avert-government-shutdown-before-midterm-elections-2026-09-03/) — independent reporting on enactment, the House and Senate votes and the remaining full-year appropriations deadline

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
