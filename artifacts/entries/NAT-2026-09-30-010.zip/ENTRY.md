# Court dismisses DOJ FACE Act claims against New Jersey protesters with leave to amend

**Entry ID:** NAT-2026-09-30-010
**Date:** September 30,2026 — recovered in October 5 review
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** primary 31-page district-court opinion, original DOJ complaint and Reuters corroboration; claims dismissed without prejudice, amendment and any later merits determination unresolved
**Review state:** current-standard-reviewed

The September 30 opinion found pleading deficiencies; Reuters reported it after the prior cutoff. The dismissal leaves DOJ 30 days to amend and decides no general protest immunity.

## THE FACTS

- Judge Katharine Hayden’s September 30 opinion in United States v. Party for Socialism and Liberation New Jersey, No. 25-cv-16049, dismissed the sole FACE Act claim without prejudice as to each moving defendant and permitted an amended complaint within 30 days of the accompanying order.
- The court required allegations linking each defendant to force, threats of force or physical obstruction intended to interfere with religious exercise. Hostile or disruptive advocacy alone was insufficient; the opinion did not decide the defendants’ broader retaliatory-enforcement theory.
- DOJ’s September 29, 2025 complaint alleged unlawful interference with attendees at a November 2024 synagogue event and sought injunctive relief, statutory damages and civil penalties. Those remain allegations, not findings that the defendants committed violence or obstructed worship.
- This is an explicitly dated prior-window recovery: the primary opinion was filed September 30; Reuters coverage inspected in this review was published October 3 at 03:56 UTC. The later article did not make the ruling an October 2 government action.

## SIGNIFICANCE

The pleading ruling limits this application of federal enforcement power while allowing the government to pursue adequately supported claims. It distinguishes alleged unlawful interference from protected advocacy.

## GOALPOST / RESPONSE

DOJ alleged that the defendants used force, threats and obstruction to prevent lawful religious exercise and sought civil remedies under the FACE Act. A properly amended complaint, any later factual findings and appellate review are the tests; dismissal does not establish that the event was unprotected or every alleged act lawful.

## MAYBE / THEREFORE

Maybe DOJ can cure the pleading defects with facts satisfying the statute. Therefore the claims are dismissed without prejudice, with an amendment opportunity; the opinion neither finally ends enforcement nor establishes broad immunity for protest conduct.


## SOURCES

- [D.N.J. — United States v PSL New Jersey opinion, Document 113](https://newjerseymonitor.com/wp-content/uploads/2026/10/9-30-26-US-v.-West-Orange-protesters.pdf) — primary court opinion (NJ Monitor-hosted copy)
- [DOJ — United States v PSL and AMP original FACE Act complaint](https://www.justice.gov/crt/media/1415491/dl?inline=) — primary government complaint
- [Reuters — FACE Act claims against synagogue protesters dismissed](https://www.reuters.com/legal/government/us-judge-dismisses-doj-lawsuit-that-used-abortion-clinic-access-law-against-2026-10-03/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
