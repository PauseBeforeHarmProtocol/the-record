# Treasury proposes expanded outbound-investment restrictions under COINS Act

**Entry ID:** NAT-2026-10-22-003
**Date:** October 22, 2026
**Checked:** 2026-10-22 6:03 PM EDT
**Evidence state:** official Treasury program notice and Associated Press reporting on proposed scope, countries, threshold and exclusions; final terms and effects remain unresolved
**Review state:** current-standard-reviewed

The notice would extend screening and prohibitions to more technologies and countries of concern; comments are due December 7 and no final rule has issued.

## THE FACTS

- Treasury issued a notice of proposed rulemaking to implement the Comprehensive Outbound Investment National Security Act enacted in December 2025 as Title VIII of the Defense Production Act. The department set a December 7, 2026 public-comment deadline; the proposal has not become a final rule.
- Associated Press reported that the proposal would expand the existing program beyond semiconductors, quantum computing and artificial intelligence to cover areas including hypersonic systems, supercomputing and biotechnology, and would reach countries of concern including China, Russia, North Korea, Cuba and Iran.
- AP reported that the statutory proposal generally applies above a $50,000 transaction threshold and excludes many financial investments, including many stock purchases. Exact coverage, definitions, exemptions and compliance duties remain subject to the notice text, comments and any final rule.
- Treasury says the outbound program is designed to prohibit or require notice of U.S.-person investments that may support military, intelligence, surveillance or cyber capabilities in countries of concern. The department and cited specialists describe capital controls as a national-security tool; the proposal itself does not establish how much capital, technology development or military capability it will change.
- The new rulemaking is a distinct lifecycle stage from Treasury's July 2026 first civil penalty under the earlier program, disclosed in October. That enforcement record remains NAT-2026-10-07-008 and is not counted again here.

## SIGNIFICANCE

If finalized, the proposal would broaden the technologies, jurisdictions and compliance systems covered by U.S. outbound-investment controls. Its legal and economic effects remain contingent on the final text, implementation date, exemptions, enforcement choices and investor responses.

## GOALPOST / RESPONSE

Treasury says the program should prevent U.S. capital and associated benefits from accelerating adversaries' military-relevant capabilities. The tests are final-rule scope, covered and exempt transactions, compliance costs, notifications and prohibitions, enforcement consistency, capital-flow changes and evidence of national-security effect.

## MAYBE / THEREFORE

Maybe broader screening closes material financing channels for sensitive capabilities, or covered parties may restructure transactions while compliance burdens fall on benign investment. Therefore the archive records a formal proposal and comment period—not implemented new restrictions, a completed capital cutoff or measured security gains.


## SOURCES

- [Treasury Department — COINS Act outbound-investment notice of proposed rulemaking](https://home.treasury.gov/policy-issues/international/outbound-investment-program) — official program page documenting the proposed rule, statutory basis and December 7 comment deadline
- [Associated Press — Treasury proposes expanded outbound-investment restrictions](https://apnews.com/article/treasury-china-tech-investments-rule-b742c292ff8eb19e6a4c8cf03d4d66b9) — independent reporting on covered technologies, countries, thresholds, exclusions and proposed status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
