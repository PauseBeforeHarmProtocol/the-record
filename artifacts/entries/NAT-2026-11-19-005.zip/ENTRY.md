# FERC authorizes five natural-gas infrastructure project packages

**Entry ID:** NAT-2026-11-19-005
**Date:** November 19, 2026
**Checked:** 2026-11-19 6:07 PM EST
**Evidence state:** official Commission release and Sabine Pass authorization order plus independent Reuters reporting; federal authorizations issued, implementation and commercial completion unresolved
**Review state:** current-standard-reviewed

The Commission unanimously authorized five project packages, including Sabine Pass expansion, but construction, financing, final investment decisions and service remain future stages.

## THE FACTS

- The Federal Energy Regulatory Commission said it unanimously approved five natural-gas infrastructure project packages on November 19: the Sabine Pass Liquefaction Stage 5 expansion and related Creole Trail and Sabine Crossing facilities; Mountain Valley Pipeline's Boost project; Southeast Virginia Energy Storage; Forza Pipeline; and a Texas Eastern service expansion.
- FERC reported proposed capacities of 600,000 dekatherms per day for MVP Boost, 10,000 dekatherms per day of liquefaction and 1.1 million dekatherms of storage for Southeast Virginia, 750,000 dekatherms per day for the 36-mile Forza line, and 125,000 dekatherms per day of new Texas Eastern firm service.
- The Sabine Pass order authorized three additional liquefaction trains, each designed for about 300 billion cubic feet per year, a 50-billion-cubic-foot-per-year boil-off-gas unit and associated pipeline facilities under Natural Gas Act sections 3 and 7, subject to environmental and other conditions.
- Reuters reported that Cheniere still expected a later final investment decision for the first expansion phase, whose projected capacity exceeds 6 million metric tons per year. Authorization therefore does not establish financing, construction, commissioning, gas delivery or LNG export completion.

## SIGNIFICANCE

The orders are operative federal approvals for a large LNG expansion and multiple interstate gas facilities. Their practical scale is material, but treating authorization as completed infrastructure would overstate the lifecycle stage.

## GOALPOST / RESPONSE

FERC says the authorizations support reliability and infrastructure development; project sponsors describe capacity and commercial benefits. The tests are compliance with order conditions, final investment and financing decisions, permits, construction milestones, cost changes, in-service authorization, delivered capacity, environmental compliance and any litigation.

## MAYBE / THEREFORE

Maybe the approvals will lead to the stated capacity and reliability gains, or financing, litigation, environmental conditions and demand may delay or narrow one or more projects. Therefore FERC authorized five project packages; it did not complete construction, obligate private financing, place facilities in service or measure their eventual economic and environmental effects.


## SOURCES

- [FERC — approvals for five natural-gas infrastructure project packages](https://ferc.gov/news-events/news/ferc-approves-major-gas-infrastructure-facilities-get-american-energy-moving) — primary agency authorization announcement
- [FERC — Sabine Pass liquefaction and pipeline authorization order](https://www.ferc.gov/sites/default/files/2026-11/CP24-75-000.pdf) — primary agency order under Natural Gas Act sections 3 and 7
- [Reuters — regulators approve Cheniere Sabine Pass expansion](https://www.reuters.com/legal/litigation/federal-regulators-approve-chenieres-sabine-pass-expansion-project-2026-11-19/) — independent reporting on agency approval and unresolved investment decision

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
