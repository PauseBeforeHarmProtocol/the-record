# Court permanently bars federal pressure to suppress two ICE-reporting platforms

**Entry ID:** NAT-2026-11-13-013
**Date:** November 13, 2026
**Checked:** 2026-11-14 6:05 AM EST
**Evidence state:** Primary permanent-injunction order and joint federal filing plus Reuters reporting; permanent prospective relief entered by agreement, broader effects and platform restoration unresolved
**Review state:** current-standard-reviewed

DOJ and DHS officials jointly agreed to permanent relief protecting the ICE Sightings–Chicagoland Facebook group and Eyes Up app; the order resolves this case without a merits trial.

## THE FACTS

- U.S. District Judge Jorge L. Alonso converted the preliminary injunction in Rosado v. Blanche, No. 26 C 1532, into a permanent injunction on November 13 after the plaintiffs and the federal defendants filed a joint motion requesting that relief.
- The order bars the defendants, their officers, employees and agents from formally or informally demanding or pressuring Facebook to suppress the ICE Sightings–Chicagoland group, or coercing or threatening Facebook with sanctions for allowing or reinstating it.
- The same order bars equivalent pressure, coercion or threats against Apple concerning Kreisau Group's Eyes Up application. It also requires notice to relevant DOJ and DHS personnel, Meta and Apple, plus written documentation to plaintiffs' counsel within seven days.
- The joint motion was signed on behalf of Attorney General Todd Blanche and Homeland Security Secretary Markwayne Mullin in their official capacities. The permanent order dismisses the plaintiffs' complaint with prejudice and directs entry of final judgment; Reuters reported that DOJ and DHS did not immediately provide a separate comment.
- The order resolves the requested prospective relief by agreement. It does not establish damages, direct Facebook or Apple to restore either platform, or substitute for a trial judgment adjudicating every disputed past fact, although the earlier preliminary-injunction opinion found plaintiffs likely to succeed on their coercion claim.

## SIGNIFICANCE

The permanent injunction imposes an enduring, enforceable limit on two departments' contacts with major platforms about named tools used to document immigration enforcement. Its scope is specific to these plaintiffs and platforms, so it should not be described as a universal rule governing every moderation request.

## GOALPOST / RESPONSE

Compliance can be assessed through the required notices and documentation, any platform restoration decisions, future agency contacts, enforcement or contempt proceedings and related appellate or policy developments. Broader claims about government-platform coordination require separate evidence beyond this case-specific order.

## MAYBE / THEREFORE

Maybe the agreement closes a discrete constitutional dispute and prevents repeated coercion against the two platforms, or similar conflicts may continue outside the order's named scope. Therefore the record establishes a consented permanent injunction and final dismissal—not damages, compelled platform reinstatement or a merits verdict resolving every allegation.


## SOURCES

- [Rosado v. Blanche — order converting preliminary injunction to permanent injunction](https://www.fire.org/sites/default/files/2026/11/Rosado%20Order%20Converting%20Preliminary%20Injunction%20to%20Perm.pdf) — primary court order permanently restricting DOJ and DHS pressure on Facebook and Apple and dismissing claims with prejudice
- [Rosado v. Blanche — joint motion for permanent injunction and dismissal](https://www.fire.org/sites/default/files/2026/11/Rosado%20Motion%20to%20Convert%20Prelim%20to%20Perm%20Injunction.pdf) — primary joint filing documenting the federal defendants' agreement to permanent relief
- [Reuters — government agrees to end pressure over ICE-reporting group and app](https://www.reuters.com/legal/litigation/free-speech-nonprofit-says-us-end-efforts-curb-facebook-group-app-reporting-ice-2026-11-14/) — independent reporting on the permanent injunction, underlying dispute and absence of an immediate agency comment

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
