# Federal judge orders Labor Department to replace unlawful H-2A wage method

**Entry ID:** NAT-2026-08-27-013
**Date:** August 26–27, 2026
**Checked:** 2026-08-28 6:03 AM EDT
**Evidence state:** federal district-court summary-judgment order, underlying Federal Register rule, and independent Reuters reporting; rule held unlawful and remanded without vacatur, replacement and possible backpay pending
**Review state:** current-standard-reviewed

The court remanded the farmworker wage rule without immediately vacating it, ordered a prompt replacement, and preserved possible prospective backpay.

## THE FACTS

- U.S. District Judge Kirk Sherriff held the Labor Department's 2025 interim final methodology for H-2A Adverse Effect Wage Rates unlawful. The court found challenged components arbitrary and capricious and found that DOL lacked good cause to bypass notice and comment for most of them.
- The ruling identifies defects in the two-tier occupation system, a housing adjustment that effectively charges many H-2A workers for housing that the regulations require employers to provide at no cost, and a rule for workers spending more than half their time in higher-paid duties. It orders DOL to promptly produce and publish a lawful replacement methodology.
- The court did not immediately vacate the existing rule because doing so could leave the program without wage floors and cause disruption. It retained jurisdiction, required a status report in two weeks, and ordered DOL to warn employers within seven days that workers may later be owed wage adjustments for the period after that notice if the replacement rates are higher. No backpay amount has yet been awarded.
- DOL had argued that ending the USDA Farm Labor Survey required a new wage data source and that immigration enforcement had created acute agricultural labor shortages. Both sides agreed that remand without immediate vacatur would be appropriate if the court found the rule invalid.

## SIGNIFICANCE

The merits ruling requires the administration to redo a nationwide wage methodology affecting temporary foreign farmworkers, corresponding U.S. workers, and agricultural employers. Its tailored remedy keeps current wage floors in place while creating a prospective backpay risk and judicial oversight of the replacement process.

## GOALPOST / RESPONSE

DOL says the discontinued federal survey and farm-labor shortages required immediate action and a workable new data source. Farmworker plaintiffs say the resulting wage cuts and housing offset violate the statutory duty to prevent H-2A hiring from depressing U.S. wages. The replacement methodology, notice compliance, status reports, final backpay ruling, appeals, and wage effects are the tests.

## MAYBE / THEREFORE

Maybe DOL can promptly cure the procedural and analytic defects without disrupting harvests, or a replacement rule and appeal may produce another extended dispute. Therefore the record reports an unlawful-rule merits holding and compelled reconsideration—not immediate vacatur, restoration of the former survey, or a present award of backpay.


## SOURCES

- [United Farm Workers v. Department of Labor — summary-judgment order](https://fingfx.thomsonreuters.com/gfx/legaldocs/klpyoakrlpg/EMPLOYMENT_H2A_LAWSUIT_decision.pdf) — primary federal merits order holding the H-2A wage methodology unlawful and prescribing remand relief
- [Labor Department — 2025 H-2A adverse-effect wage-rate interim final rule](https://www.federalregister.gov/documents/2025/10/02/2025-19365/adverse-effect-wage-rate-methodology-for-the-temporary-employment-of-h-2a-nonimmigrants-in-non-range) — primary underlying rule reviewed by the federal court
- [Reuters — judge orders Labor Department to redo H-2A farmworker wage changes](https://www.reuters.com/legal/government/us-judge-orders-trump-administration-redo-changes-farmworker-visa-program-2026-08-27/) — independent reporting on the merits order, continuing rule, and possible wage adjustments

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
