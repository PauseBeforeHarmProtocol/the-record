# EPA proposes easing oil-and-gas methane controls and ending third-party leak program

**Entry ID:** NAT-2026-10-27-004
**Date:** October 27, 2026
**Checked:** 2026-10-28 12:01 AM EDT
**Evidence state:** Primary EPA announcement, signed pre-publication cover, fact sheet and process page, with Reuters context. Proposed, not final. High confidence in announced scope; projections unverified. October 27 date-only recovery: precise posting time unknown.
**Review state:** current-standard-reviewed

The signed proposal would revise well-site standards, flaring and leak oversight; it is not a final repeal or measured price reduction.

## THE FACTS

- On October 27, EPA announced a further proposed reconsideration of its 2024 OOOOb/c oil-and-gas standards. Its posted pre-publication notice says Administrator Lee Zeldin signed it that day and that the official Federal Register version is forthcoming.
- EPA proposes different well-site categories, rescinding the Super Emitter Program for certified third-party leak reports, allowing repairs under revised closed-vent requirements, restoring 95%-efficient flaring or other controls for associated gas, and technical monitoring flexibilities.
- EPA projects $45 billion in savings and 210 million additional barrels of oil. These are agency estimates, not achieved savings, delivered production or independently measured consumer-price effects. Reuters independently reported the planned proposal and the administration’s lower-cost rationale.
- The agency plans public comment and a hearing after Federal Register publication. Its materials give inconsistent comment-period lengths, so no exact deadline is asserted here. The inspected documents establish a proposal, not completed termination of the existing rule.

## SIGNIFICANCE

The proposal would change emissions oversight and operators’ compliance choices. That can affect leak detection and pollution control as well as production costs; the final requirements and measured results, not the announcement, determine the balance.

## GOALPOST / RESPONSE

EPA says achievable standards, legal limits and flexibility for small producers can preserve domestic supply and lower costs while protecting health and the environment. That is the strongest administration case; final text, emissions data and realized costs and prices are the tests.

## MAYBE / THEREFORE

Maybe targeted flexibility can reduce disproportionate compliance costs, while weaker detection or controls could allow more emissions. Therefore this is a proposed regulatory change whose costs and environmental effects remain to be tested, not proof of a final repeal or realized energy-price relief.


## SOURCES

- [EPA proposes further oil and gas methane-rule revisions](https://www.epa.gov/newsreleases/epa-proposes-major-new-revisions-burdensome-unworkable-biden-era-oil-and-natural-gas) — primary agency announcement
- [Signed pre-publication proposed reconsideration, RIN 2060-AW73](https://www.epa.gov/system/files/documents/2026-10/san-12726-ong-reconsideration-2-nprm-preamble-20261015-clean.admin_disclaimer.pdf) — primary proposed rule
- [October 2026 oil and gas proposal general fact sheet](https://www.epa.gov/system/files/documents/2026-10/generalfactsheet_o-g_recon2_nprm.pdf) — primary agency fact sheet
- [2026 oil and gas reconsideration actions and comment process](https://www.epa.gov/controlling-air-pollution-oil-and-natural-gas-operations/2026-actions-reduce-burden-oil-and-natural) — primary agency rulemaking page
- [Trump to roll back methane rules in Texas campaign push](https://www.investing.com/news/commodities-news/trump-to-roll-back-methane-rules-in-latest-texas-campaign-push-4976479) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
