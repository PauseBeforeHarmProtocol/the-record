# Federal judge denies preliminary block of contractor DEI order

**Entry ID:** NAT-2026-10-14-006
**Date:** October 14, 2026
**Checked:** 2026-10-14 6:03 PM EDT
**Evidence state:** filed district-court opinion plus independent Reuters reporting and plaintiffs' response; preliminary injunction and stay denied, merits litigation continuing
**Review state:** current-standard-reviewed

The ruling leaves the March order and FAR implementation memo in effect while the case continues; it does not finally resolve every constitutional or APA claim.

## THE FACTS

- U.S. District Judge Adam B. Abelson denied five associations' motion for a preliminary injunction against the March 26 contractor order and for a stay of the Federal Acquisition Regulatory Council implementation memo in National Association of Diversity Officers in Higher Education v. Trump, No. 26-cv-1532-ABA.
- The court held at this preliminary stage that the order's phrase 'disparate treatment based on race or ethnicity' carries the settled meaning of intentional discrimination and that the plaintiffs had not shown unconstitutional applications substantially disproportionate to the order's lawful sweep or a likelihood of success on their Fifth Amendment vagueness claim.
- The opinion read the contract language as applying only to work performed for the government under the specific contract. It noted that enforcement against protected activity outside the contract could support an as-applied challenge and did not decide every remaining APA dispute about the FAR memo.
- Plaintiffs said that limiting construction reassures contractors that the order does not broadly prohibit diversity programs. Reuters reported that the Justice Department did not immediately comment and that a separate challenge by 19 states and the District of Columbia remains pending.

## SIGNIFICANCE

The denial permits the administration's contractor clause and implementation memo to remain operative during litigation while narrowing their judicially accepted reach. It is a preliminary-relief ruling, not a final merits judgment, and later as-applied enforcement or parallel litigation could change the legal position.

## GOALPOST / RESPONSE

The administration frames the order as enforcement against intentional race or ethnicity discrimination, while challengers argue broader application could chill lawful DEI activity and speech. Tests include final merits rulings, actual contract modifications, enforcement confined to contract work, as-applied cases, and outcomes in the states' parallel suit.

## MAYBE / THEREFORE

Maybe the court's narrow construction confines the order to already unlawful conduct, or agencies may apply the clause more broadly and trigger later constitutional challenges. Therefore preliminary relief was denied and the order remains in effect—not final validation of every provision or future enforcement action.


## SOURCES

- [U.S. District Court for the District of Maryland — NADOHE v. Trump memorandum opinion](https://fingfx.thomsonreuters.com/gfx/legaldocs/klvyrbmnxpg/USA_TRUMP_DEI_decision.pdf) — primary filed judicial opinion denying preliminary injunction and stay
- [Reuters — judge declines to block federal-contractor DEI order](https://www.reuters.com/legal/government/us-judge-wont-block-trump-order-targeting-dei-by-federal-contractors-2026-10-14/) — independent reporting on preliminary ruling and parties' responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
