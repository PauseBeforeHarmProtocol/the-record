# Senate rejects cloture on Trump-backed digital-asset market bill

**Entry ID:** NAT-2026-09-15-007
**Date:** September 15, 2026
**Checked:** 2026-09-15 6:02 PM EDT
**Evidence state:** primary U.S. Senate final roll call plus Reuters and Associated Press reporting; cloture on the motion to proceed rejected 49–50, with substantive legislation and possible reconsideration unresolved
**Review state:** current-standard-reviewed

The 49–50 vote blocked the motion to proceed; it was a procedural defeat, not final passage or rejection on the merits.

## THE FACTS

- The Senate rejected cloture on the motion to proceed to H.R. 3633, the Digital Asset Market Clarity Act, by 49–50 on September 15. The official roll call identifies 60 votes as required, so the chamber did not advance to consideration of the bill.
- The result is a completed procedural action, not enactment, a final-passage vote or a merits judgment on every provision. One senator did not vote, and four Republicans joined the no votes; Senator Thom Tillis voted no to preserve the ability to seek reconsideration.
- Reuters and Associated Press described the measure as a broad framework for allocating digital-asset oversight and providing legal rules sought by the industry. Supporters, including the Trump administration and Republican sponsors, said it would provide clarity, consumer protection and U.S. competitiveness; those are policy claims, not measured outcomes.
- Opponents sought stronger ethics restrictions related to elected officials' digital-asset interests and raised money-laundering and financial-stability concerns. Associated Press reported claimed Trump-family crypto revenue while Reuters described intensive industry lobbying; the vote establishes the legislative result, not the truth of every financial or policy allegation advanced in debate.
- The bill remains available for possible reconsideration or later legislation, but Reuters reported little near-term time before the election recess. No digital-asset framework in H.R. 3633 became law through this vote, and existing agency authorities were not repealed by it.

## SIGNIFICANCE

The vote halted a major administration-backed regulatory project despite extensive industry advocacy and presidential support. Because it was cloture on the motion to proceed, the immediate consequence is legislative delay rather than a final Senate position on the bill's substantive framework.

## GOALPOST / RESPONSE

Supporters say a federal framework would clarify jurisdiction, protect consumers and keep activity in the United States; opponents say the proposal needs stronger ethics, anti-money-laundering and stability safeguards. Reconsideration, revised public text, amendment votes, final passage, conference action, presidential signature and measurable enforcement or market effects are the tests.

## MAYBE / THEREFORE

Maybe sponsors can assemble 60 votes after further revisions, or the procedural defeat may defer comprehensive legislation beyond the election. Therefore the record establishes a 49–50 failure to invoke cloture and advance H.R. 3633—not final rejection on the merits, enactment, repeal of current law or proof of the competing economic and ethics claims.


## SOURCES

- [U.S. Senate — Roll Call Vote 234 on H.R. 3633 cloture](https://www.senate.gov/legislative/LIS/roll_call_votes/vote1192/vote_119_2_00234.htm) — primary final roll call rejecting cloture on the motion to proceed, 49–50
- [Reuters — Senate fails to advance digital-asset market bill](https://www.reuters.com/legal/government/us-senate-vote-advancing-landmark-crypto-bill-2026-09-15/) — independent reporting on the completed procedural defeat, policy stakes and near-term prospects
- [Associated Press — Senate blocks cryptocurrency regulation bill](https://apnews.com/article/e3caf262dc138147941787299e5f0a66) — independent reporting on the 49–50 procedural vote, ethics dispute and competing explanations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
