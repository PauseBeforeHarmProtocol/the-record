# Treasury discloses first civil penalty under outbound-investment rules

**Entry ID:** NAT-2026-10-07-008
**Date:** July–October 7, 2026
**Checked:** 2026-10-07 6:04 PM EDT
**Evidence state:** primary Treasury enforcement disclosure plus independent reporting; penalty implemented in July and disclosed October 7
**Review state:** current-standard-reviewed

The $200,000 penalty was issued in July for a missed notification involving a roughly $92,478 investment in a Chinese AI and robotics company.

## THE FACTS

- Treasury disclosed on October 7 that it issued the first civil penalty under the Outbound Investment Security Program in July 2026. The department penalized Amidi LLC $200,000 for failing to notify Treasury about an investment made by a controlled foreign entity; the enforcement action was implemented in July and publicly disclosed later.
- Treasury said Amidi’s Chinese-fund subsidiary invested approximately $92,478 on April 19, 2025 in Shanghai Qiongche Intelligent Technology Company Limited, known as Noematrix, a private Chinese developer of artificial intelligence, robotics and embodied-intelligence technology.
- The program took effect January 2, 2025 and requires notifications for specified investments, while prohibiting other covered U.S.-person transactions involving China, Hong Kong or Macau in quantum computing, artificial intelligence and semiconductors. It also imposes duties concerning controlled foreign entities.
- Treasury said it identified the transaction through regular compliance and market monitoring. The disclosure establishes one penalty and the department’s enforcement position; it does not by itself measure broader compliance or national-security effects. Independent reporting confirmed the first-penalty disclosure.

## SIGNIFICANCE

The first public civil penalty demonstrates that the outbound-investment program has moved from rules to enforcement and shows that controlled foreign subsidiaries are within Treasury’s compliance focus. One case cannot establish the program’s deterrent effect or consistency.

## GOALPOST / RESPONSE

Treasury says enforcement protects U.S. technological leadership and national security. Future notices, penalty guidance, self-disclosures, repeat cases, judicial challenges and evidence about covered capital flows are the tests.

## MAYBE / THEREFORE

Maybe an early penalty produces broad compliance beyond its dollar value, or a single missed-notification case may reveal little about prohibited investment or security outcomes. Therefore Treasury implemented and later disclosed its first OISP civil penalty; program-wide effectiveness remains unmeasured.


## SOURCES

- [Treasury — First Outbound Investment Security Program civil penalty](https://home.treasury.gov/news/press-releases/sb0652) — official enforcement disclosure
- [South China Morning Post — First U.S. outbound-investment penalty](https://www.scmp.com/news/china/diplomacy/article/3370101/us-issues-first-outbound-investment-fine-over-chinese-robotics-ai-deal) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
