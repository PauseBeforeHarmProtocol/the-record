# CDC announces $5.25 million first-year global-health awards

**Entry ID:** NAT-2026-08-27-004
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 AM EDT
**Evidence state:** two published CDC award notices with recipients, approximately $5.25 million in first-year amounts, conditional continuation language, and September 2026 start dates; awards announced, performance and later funding pending
**Review state:** current-standard-reviewed

Four single- or sole-source cooperative agreements fund outbreak detection, field epidemiology, laboratory systems, and pediatric HIV work beginning September 30.

## THE FACTS

- CDC announced four cooperative-agreement awards totaling approximately $5.25 million for federal fiscal year 2026: $2 million each to Vietnam's Administration of Medical Services and Tanzania's National Institute of Medical Research, $500,000 to the ASEAN+3 Field Epidemiology Training Network Foundation, and $750,000 to the Elizabeth Glaser Pediatric AIDS Foundation.
- The first three awards support disease surveillance, outbreak response, emergency management, laboratory and diagnostic capacity, field epidemiology, and public-health workforce development. CDC projects approximately $22.5 million for those three recipients over five years, subject to available funds; future funding for the pediatric-HIV award was not quantified and will be set through continuation.
- The pediatric-HIV award supports work with faith-based and community providers to identify and treat children living with HIV and prevent mother-to-child transmission. All four performance periods are scheduled for September 30, 2026, through September 29, 2031, so the notices announce awards and planned work rather than completed spending or measured outcomes.

## SIGNIFICANCE

The awards commit federal public-health resources to overseas surveillance and care systems intended to protect U.S. and global health. Their single- or sole-source structure and multi-year projections make recipient performance, continued appropriations, outbreak detection, and pediatric treatment outcomes central accountability measures.

## GOALPOST / RESPONSE

CDC says the selected government and regional institutions have unique legal authority and networks for surveillance and cross-border response, and that the pediatric-HIV recipient has specialized delivery capacity. The strongest countervailing questions are whether sole-source selection produces measurable value and whether overseas programs improve early warning and care. Continuation awards, audits, surveillance speed, workforce capacity, outbreak response, pediatric treatment, and transmission data are the tests.

## MAYBE / THEREFORE

Maybe locally embedded recipients can produce faster and more durable capacity than open competition, or future appropriations and execution may fall below the announced plan. Therefore the record reports $5.25 million in first-year awards and a conditional $22.5 million five-year projection for three recipients—not $22.5 million already spent and not a guaranteed five-year total for all four awards.


## SOURCES

- [Federal Register — CDC global disease-surveillance and outbreak-response awards](https://www.federalregister.gov/documents/2026/08/27/2026-17450/notice-of-award-of-a-sole-source-cooperative-agreement-to-fund-vietnam-administration-of-medical) — primary award notice with recipients, first-year amounts, conditional five-year totals, and performance period
- [Federal Register — CDC pediatric-HIV cooperative agreement award](https://www.federalregister.gov/documents/2026/08/27/2026-17449/notice-of-award-of-a-single-source-cooperative-agreement-to-fund-elizabeth-glaser-pediatric-aids) — primary award notice with recipient, first-year amount, purpose, and conditional continuation status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
