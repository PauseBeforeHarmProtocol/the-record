# NYU Langone and UPMC settle federal investigations over youth gender care

**Entry ID:** NAT-2026-09-18-013
**Date:** September 18, 2026
**Checked:** 2026-09-19 6:01 AM EDT
**Evidence state:** DOJ settlement announcement plus independent Reuters reporting; agreements announced and payments specified, allegations denied and no liability determination
**Review state:** current-standard-reviewed

The hospital systems agreed to stop specified care for minors and pay $9.45 million while denying the government's allegations; no liability finding was made.

## THE FACTS

- The Justice Department announced agreements resolving investigations of NYU Langone Health and UPMC over potential federal violations involving gender-related medical care for minors.
- Under the announced agreements, both systems will cease providing puberty blockers, cross-sex hormones and gender-transition surgeries to patients under 18. NYU agreed to pay $8.5 million and UPMC $950,000.
- DOJ said the matters involved alleged billing, False Claims Act and Food, Drug and Cosmetic Act violations, but its announcement states that the claims are allegations only and there was no determination of liability. Both health systems denied all allegations.
- Reuters reported that adult care and pediatric mental-health services would continue and that the systems said settlement avoided prolonged litigation and protected patients and providers. The complete agreements were confidential, limiting independent review of operative details and compliance mechanisms.

## SIGNIFICANCE

The settlements use federal investigative and payment leverage to change care policies at two large health systems, while leaving the government's legal allegations unadjudicated and the complete terms unavailable.

## GOALPOST / RESPONSE

DOJ says the agreements protect children, enforce federal law and safeguard public funds. The hospitals deny wrongdoing and describe settlement as a way to avoid prolonged conflict and privacy risks. Published terms, compliance reports, patient access, health outcomes and any later litigation are the tests.

## MAYBE / THEREFORE

Maybe the agreements reduce unlawful billing or medical risk, or they may restrict individualized care through enforcement pressure without an adjudicated violation. Therefore the systems settled, paid money and agreed to stop specified care for minors—not that the allegations were proved or liability admitted.


## SOURCES

- [DOJ — agreements with NYU and UPMC on pediatric gender care](https://www.justice.gov/opa/pr/doj-secures-agreements-nyu-and-upmc-end-pediatric-gender-affirming-care) — primary settlement announcement
- [Reuters — hospital systems settle federal transgender-care billing probes](https://www.reuters.com/legal/litigation/two-hospital-systems-settle-us-probe-over-transgender-care-billing-95-million-2026-09-18/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
