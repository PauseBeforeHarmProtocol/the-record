# Reflecting Pool is refilled for Trump event while official public closure remains

**Entry ID:** NAT-2026-11-01-002
**Date:** April 3–November 2, 2026
**Checked:** 2026-11-02 6:09 PM EST
**Evidence state:** two primary SAM.gov award notices and an official NPS closure/repair record, corroborated by Reuters and Associated Press reporting; awards and ongoing remediation are documented, while final cost, responsibility and long-term effectiveness remain unresolved; November 2 Reuters event report compared with the still-current original NPS closure determination; refilling is reported, unrestricted public reopening is not established
**Review state:** current-standard-reviewed

Trump presented the refilled pool as reopened, but the current NPS determination still closes the pool, adjacent walkways and medians through November 20.

## THE FACTS

- SAM.gov records show that the National Park Service awarded Reflecting Pool painting contract 140P2026C0028 on April 3 and nano-bubble water-treatment contract 140P2026C0031 on April 13. The award notices cite the unusual-and-compelling-urgency authority in Federal Acquisition Regulation 6.302-2. The reviewed notice pages establish awards and procurement authority, not the project's complete obligations, modifications or final lifecycle cost.
- Reuters reported that the resurfacing work was performed under a $14.7 million no-bid contract and that President Trump announced completion on June 6. Less than two weeks later, Reuters observed peeling paint while the Park Service was also treating algae. These are reported contract and performance facts, not a finding of fraud or a final engineering assessment.
- The National Park Service later extended the pool closure through November 20 after earlier extensions. Its Record of Determination says ongoing work includes repairs, additional water-circulation work, water-quality testing and implementation of a long-term water-treatment plan; it says the closure protects visitors, workers and park resources while heavy machinery is present.
- Associated Press reported on November 1 that the project was almost three months behind schedule and had grown to more than ten times an early public estimate of about $1.5 million. AP also reported that the pool was drained again after algae and peeling followed the June completion announcement. Trump attributed the problem to vandalism, while the U.S. attorney's office had said shoddy workmanship caused the condition at issue in a related prosecution. Those explanations are attributed positions, not a complete adjudication of technical or contractual responsibility.
- Reuters reported that Trump spoke beside the refilled pool on November 2 and presented the project as reopened and improved. The contemporaneously inspected National Park Service determination still says the pool, adjacent walkways and specified medians remain closed to visitor access through 11:59 p.m. November 20 for repairs, circulation work and water-quality testing. A filled pool and presidential event therefore do not by themselves establish unrestricted public reopening; the NPS page had not posted a superseding access determination by cutoff.

## SIGNIFICANCE

The November 2 presentation shows a visible project milestone but not the public-access outcome implied by an unqualified reopening claim. The official closure remains the controlling reviewed access record, so accountability turns on a superseding NPS notice, actual public access, final obligations and durable water-quality performance.

## GOALPOST / RESPONSE

Trump says the renovated pool is reopened and improved and attributes earlier damage to vandalism. NPS says the designated pool area remains unsafe for visitors while repair, circulation and testing work continues through November 20. The two statements address different observable states—water in the pool versus public access—and the official access order remains unsuperseded in the reviewed record.

## MAYBE / THEREFORE

Maybe the refilling and presidential event marked substantial completion while safety or closeout work still required restricted access. Therefore the record establishes a refilled pool used for an official event and a still-published public closure—not full public reopening, final project completion, a complete audited cost or durable treatment effectiveness.


## SOURCES

- [SAM.gov — Lincoln Memorial Reflecting Pool painting contract award](https://sam.gov/opp/b533eb6dcaf24f25b900828720a8b3fa/view?itid=lk_inline_enhanced-template) — primary federal procurement award notice
- [SAM.gov — Lincoln Memorial Reflecting Pool nano-bubble contract award](https://sam.gov/opp/203712c0e9e34f8397271942bcb29960/view?ftag=MSF0951a18) — primary federal procurement award notice
- [Reuters — Paint peels from renovated Reflecting Pool within two weeks](https://www.reuters.com/world/us/paint-is-already-peeling-trumps-renovated-washington-reflecting-pool-2026-06-18/) — independent reporting on contract value and observed performance
- [National Park Service — Record of Determination extending Reflecting Pool closure](https://www.nps.gov/nama/learn/management/rod-reflecting-pool-closure.htm) — primary agency closure and repair-status record
- [Associated Press — Reflecting Pool project remains delayed and over early estimate](https://apnews.com/article/trump-closing-midterm-speech-reflecting-pool-f35133c6e33e87d1a036e3425af21ad6) — independent reporting on project cost, schedule, performance and administration responses
- [Reuters — Trump visits refilled Reflecting Pool before midterms](https://www.reuters.com/legal/government/trump-brushes-aside-tough-midterm-prospects-with-visit-reflecting-pool-2026-11-02/) — independent report on presidential event, project claims and visible project status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
