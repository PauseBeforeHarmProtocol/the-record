# Reflecting Pool repair exceeds early estimate as closures continue

**Entry ID:** NAT-2026-11-01-002
**Date:** April 3–November 1, 2026
**Checked:** 2026-11-01 6:03 PM EST
**Evidence state:** two primary SAM.gov award notices and an official NPS closure/repair record, corroborated by Reuters and Associated Press reporting; awards and ongoing remediation are documented, while final cost, responsibility and long-term effectiveness remain unresolved
**Review state:** current-standard-reviewed

Urgency-based contracts and a June completion claim were followed by peeling, algae, repeated repair work and an NPS closure extended to November 20.

## THE FACTS

- SAM.gov records show that the National Park Service awarded Reflecting Pool painting contract 140P2026C0028 on April 3 and nano-bubble water-treatment contract 140P2026C0031 on April 13. The award notices cite the unusual-and-compelling-urgency authority in Federal Acquisition Regulation 6.302-2. The reviewed notice pages establish awards and procurement authority, not the project's complete obligations, modifications or final lifecycle cost.
- Reuters reported that the resurfacing work was performed under a $14.7 million no-bid contract and that President Trump announced completion on June 6. Less than two weeks later, Reuters observed peeling paint while the Park Service was also treating algae. These are reported contract and performance facts, not a finding of fraud or a final engineering assessment.
- The National Park Service later extended the pool closure through November 20 after earlier extensions. Its Record of Determination says ongoing work includes repairs, additional water-circulation work, water-quality testing and implementation of a long-term water-treatment plan; it says the closure protects visitors, workers and park resources while heavy machinery is present.
- Associated Press reported on November 1 that the project was almost three months behind schedule and had grown to more than ten times an early public estimate of about $1.5 million. AP also reported that the pool was drained again after algae and peeling followed the June completion announcement. Trump attributed the problem to vandalism, while the U.S. attorney's office had said shoddy workmanship caused the condition at issue in a related prosecution. Those explanations are attributed positions, not a complete adjudication of technical or contractual responsibility.

## SIGNIFICANCE

The records document a national public-works project with urgency-based contracting, substantial cost growth relative to the early public estimate, repeat remediation and an extended closure after an announced completion. Accountability now turns on final obligations, contract modifications, warranty or recovery actions, durable water-quality results and the actual reopening date.

## GOALPOST / RESPONSE

The Park Service says the extended closure is needed for public and worker safety and to complete circulation, testing and long-term treatment work. Trump says vandalism caused the damage and has described the renovated pool as an improvement worth showcasing. Those are the strongest documented administration explanations; neither resolves the independently reported cost, schedule and repeat-repair record.

## MAYBE / THEREFORE

Maybe accelerated work for the national anniversary and later third-party damage contributed to the project's difficulties, while contractor performance, design or oversight may also have contributed. Therefore the record establishes urgency-based awards, reported cost escalation, observed early failures and continuing official repair work—not corruption, a final engineering cause, a complete audited cost or proof that every delay was avoidable.


## SOURCES

- [SAM.gov — Lincoln Memorial Reflecting Pool painting contract award](https://sam.gov/opp/b533eb6dcaf24f25b900828720a8b3fa/view?itid=lk_inline_enhanced-template) — primary federal procurement award notice
- [SAM.gov — Lincoln Memorial Reflecting Pool nano-bubble contract award](https://sam.gov/opp/203712c0e9e34f8397271942bcb29960/view?ftag=MSF0951a18) — primary federal procurement award notice
- [Reuters — Paint peels from renovated Reflecting Pool within two weeks](https://www.reuters.com/world/us/paint-is-already-peeling-trumps-renovated-washington-reflecting-pool-2026-06-18/) — independent reporting on contract value and observed performance
- [National Park Service — Record of Determination extending Reflecting Pool closure](https://www.nps.gov/nama/learn/management/rod-reflecting-pool-closure.htm) — primary agency closure and repair-status record
- [Associated Press — Reflecting Pool project remains delayed and over early estimate](https://apnews.com/article/trump-closing-midterm-speech-reflecting-pool-f35133c6e33e87d1a036e3425af21ad6) — independent reporting on project cost, schedule, performance and administration responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
