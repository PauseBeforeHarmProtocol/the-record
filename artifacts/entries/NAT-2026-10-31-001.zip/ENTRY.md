# FBI attributes Binance theft to North Korea and urges transaction blocking

**Entry ID:** NAT-2026-10-31-001
**Date:** October 31, 2026
**Checked:** 2026-11-01 6:04 AM EST
**Evidence state:** Original FBI alert inspected; Reuters and AP corroboration; official attribution and requested mitigation, underlying forensic evidence and results not independently audited
**Review state:** current-standard-reviewed

A published federal cyber alert identifies TraderTraitor; attribution, mitigation requests and recovered money remain different evidence states.

## THE FACTS

- The FBI’s October 31 cyber alert attributes more than $6 billion in virtual assets stolen from Binance on or about October 29 to North Korean activity it calls TraderTraitor. Reuters independently reported the attribution; the alert is an official investigative assessment, not a criminal judgment.
- The FBI says it, the Secret Service and IRS Criminal Investigation observed conversion of stolen assets primarily into Ethereum. It anticipates further laundering through decentralized-finance and instant-swap services, and urges private providers to block transactions linked to listed addresses. This is a mitigation request, not a newly inspected sanctions designation or proof that all funds were frozen or recovered.
- AP reported that Trump, speaking to reporters on October 31, said investigators were still learning about the attack and expressed uncertainty about North Korea’s involvement. That reported presidential response differs from the FBI’s categorical published attribution; it does not establish a formal withdrawal of the alert.

## SIGNIFICANCE

The federal response to a multibillion-dollar theft combines public attribution with a request for industry action. Its effectiveness must be tested through documented freezes, recovery and enforcement, not assumed from issuing an alert.

## GOALPOST / RESPONSE

The FBI presents attribution and transaction blocking as protection against illicit cyber activity. Trump’s reported uncertainty is preserved alongside that position. The alert supplies addresses and an assessment, but not the underlying investigative record or audited recovery results.

## MAYBE / THEREFORE

Maybe investigators can reliably attribute an attack before disclosing sensitive evidence, while public uncertainty warrants further scrutiny. Therefore this record documents the official attribution and mitigation request, not a conviction, a new sanctions order, verified recovery or proof that this administration caused the private exchange’s breach.


## SOURCES

- [FBI Cyber — North Korea Responsible for $6 Billion+ Binance Attack](https://www.fbi.gov/investigate/cyber/alerts/2026/north-korea-responsible-for-6-billion-binance-attack) — primary agency cyber alert; attribution and mitigation request
- [Reuters — FBI links North Korea to Binance theft](https://www.reuters.com/world/fbi-links-north-korea-theft-6-billion-from-binance-2026-10-31/) — independent reporting of official attribution
- [Associated Press — FBI attribution and Trump response](https://www.clickorlando.com/business/2026/10/31/fbi-blames-north-korea-for-stolen-billions-from-binance-in-biggest-hack-in-history/) — independent reporting; named presidential statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
