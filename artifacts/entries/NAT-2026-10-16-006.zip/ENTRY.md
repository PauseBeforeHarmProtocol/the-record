# BIA removes presumption favoring removal-case continuances for pending U visa petitions

**Entry ID:** NAT-2026-10-16-006
**Date:** October 16, 2026
**Checked:** 2026-10-16 11:59 PM EDT
**Evidence state:** published precedential Board of Immigration Appeals decision; holding and case disposition verified, system-wide application and consequences unresolved
**Review state:** current-standard-reviewed

Matter of L. Ramirez overruled Sanchez Sosa and requires the general good-cause balancing test, making long or indeterminate visa availability a reason against delaying removal proceedings.

## THE FACTS

- In precedential Matter of L. Ramirez, the Board of Immigration Appeals held that a person with a prima facie approvable U visa petition has no presumption in favor of a continuance of removal proceedings, overruling Matter of Sanchez Sosa (2012).
- The Board directed immigration judges to apply the general Matter of L-A-B-R- balancing test, focusing on the likelihood and material effect of collateral relief while also weighing diligence, DHS's position, requested length and case history.
- The decision says good cause does not exist when visa availability is too remote and reaffirms that respondents are not entitled to delay completion of removal proceedings pending visa availability. It attributes long U visa waits to the statutory annual cap and demand exceeding supply.
- The Board acknowledged that the respondent appeared prima facie eligible and that approval would materially affect removability, but upheld denial after an open-ended request, years of delay, no evidence of adjudication and DHS opposition.
- The decision governs continuance analysis in immigration adjudication; it does not deny every U visa petition, eliminate case-specific balancing or itself decide USCIS's underlying petition.

## SIGNIFICANCE

Removing the U visa-specific presumption can accelerate removal proceedings for crime victims whose petitions remain pending for years, shifting greater weight to timing, DHS opposition and procedural history while retaining individualized balancing.

## GOALPOST / RESPONSE

The Board emphasizes prompt enforcement and a uniform good-cause standard; U visa applicants rely on continuances so collateral protection can be adjudicated before removal. Immigration-judge application rates, continuance grants and denials, removals before USCIS action, appellate review and U visa processing times are the tests.

## MAYBE / THEREFORE

Maybe the uniform test reduces indefinite delay while preserving relief in strong cases, or it may cause removal before eligible crime victims receive USCIS decisions. Therefore the precedential standard changed and the respondent's appeal was dismissed—not that every pending U visa case must be denied or that the underlying petition was adjudicated.


## SOURCES

- [Board of Immigration Appeals — Matter of L. Ramirez, 30 I&N Dec. 157](https://www.justice.gov/eoir/media/1466591/dl?inline=) — primary precedential administrative decision

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
