# Court vacates added Medicaid medical-frailty limitation, leaves work requirements intact

**Entry ID:** NAT-2026-10-29-003
**Date:** October 29, 2026
**Checked:** 2026-10-29 6:05 PM EDT
**Evidence state:** primary full summary-judgment memorandum/order plus AP; partial vacatur and permanent-injunction direction, no universal invalidation or measured enrollment result
**Review state:** current-standard-reviewed

Partial summary judgment removes an extra exemption hurdle; verification rules and the January implementation deadline remain.

## THE FACTS

- In Massachusetts v. Oz, No. 1:26-cv-12962-RGS, Judge Richard Stearns issued an October 29 summary-judgment memorandum and order holding that CMS could not require people in Congress’s five specified medical-frailty categories also to show inability to satisfy community-engagement requirements. The court directs vacatur of that added language and a permanent injunction against its enforcement.
- The court upheld the challenged twelve-month medical-record lookback and one-self-attestation-per-enrollment restrictions. It granted plaintiff states a six-month enforcement stay concerning medical-frailty determinations, expressly without changing the January 1, 2027 implementation deadline. The work requirements themselves were not struck down.
- The ruling quotes the government’s position that CMS retained definitional discretion and that recent records better reflect current conditions; CMS also argued later verification encourages access to care. The court rejected the additional definitional limit but accepted rationales for the two verification provisions. AP reported no immediate HHS or CMS response; no appeal disposition or measured coverage outcome is established here.

## SIGNIFICANCE

The decision enforces a statutory floor for exemptions while preserving other federal eligibility controls. It changes the implementation rules, not the entire work-requirement statute.

## GOALPOST / RESPONSE

The administration’s strongest case is implementation discretion and reliable current verification. The court accepted that case for two provisions, not for narrowing Congress’s specified categories; compliance, appeals and coverage continuity remain the tests.

## MAYBE / THEREFORE

Maybe narrower verification rules can administer eligibility reliably, or administrative burdens can still exclude eligible people. Therefore the added exemption hurdle is vacated and enjoined, while statutory work requirements, remaining verification rules and actual coverage effects must be distinguished.


## SOURCES

- [District of Massachusetts — medical-frailty summary judgment, Document 147](https://oag.ca.gov/system/files/attachments/press-docs/dkt-147-opinion-msj.pdf) — primary 16-page memorandum and order, complete text inspected; copy hosted by plaintiff California Attorney General
- [AP — partial Medicaid work-exemption ruling](https://abcnews.com/Health/wireStory/judge-blocks-trump-administrations-medicaid-rule-forcing-sick-137684178) — independent reporting, complete article body inspected on ABC News

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
