# Cyclospora outbreak exposes USDA research and FDA inspection-capacity disputes

**Entry ID:** NAT-2026-08-30-002
**Date:** Fiscal 2026–September 8, 2026
**Checked:** 2026-09-08 1:16 AM EDT
**Evidence state:** Reuters account of a Politico investigation with on-record USDA response, primary CDC and FDA outbreak data, and Associated Press inspection-capacity analysis; research continuity disputed, inspection decline measured, outbreak causation not assigned
**Review state:** current-standard-reviewed

The outbreak now carries separate evidence about disputed USDA research continuity and measured gaps in FDA foreign-food inspections; neither establishes a single cause.

## THE FACTS

- USDA told Politico that Congress did not appropriate fiscal 2026 funding for two of its three cyclospora research projects and said the work had not been disrupted and would continue through an orderly transition. Reuters reported that the remaining project was scheduled to move from Maryland to Iowa under the department's broader reorganization; USDA had not published a project-by-project continuity plan by cutoff.
- CDC's August 25 seasonal surveillance reported 17,180 laboratory-confirmed domestically acquired cyclosporiasis cases from May 1 through August 24, plus 922 hospitalizations and two deaths. Those broader figures are not interchangeable with the FDA's outbreak-specific subset and do not establish that federal staffing or research changes caused any illness.
- FDA's August 27 update attributed 10,930 reported illnesses in 17 states to the iceberg-lettuce outbreak. It said most illnesses began before Taylor Farms de Mexico's July 17 recall, onsite inspections and sampling had begun in Mexico, recalled lettuce was no longer on the market, and a July laboratory sample initially described as positive had been reclassified as inconclusive.
- Associated Press found FDA foreign-food-site inspections were down nearly 35% from 2019 and fell 17% in fiscal 2025 to 1,140. The Mexican farm linked to the outbreak had not received an FDA inspection since 2019; inspectors arrived in mid-August, about a month after the recall announcement.
- AP reported that FDA's food-inspection workforce has more than 420 staff, with chronic vacancies of 10% to 15%. Inspectors were not among 3,500 jobs targeted for termination by the Trump administration, but more than half the staff handling travel bookings were eliminated, leaving inspectors with more logistics work. FDA said the investigation continues, that inspections are one part of its import-safety system and that it is studying an appropriate annual inspection target.

## SIGNIFICANCE

The new inspection measurements identify a concrete federal oversight-capacity problem alongside the already disputed research transition. The evidence spans multiple administrations, congressional funding choices and current reorganization and staffing decisions; it supports scrutiny of preparedness and response time, not a claim that one decision caused the outbreak.

## GOALPOST / RESPONSE

USDA says cyclospora research will continue without disruption after Congress omitted funding for two projects. FDA says inspections are one tool among importer oversight, border inspection and sampling, and it is considering a smaller annual target and a one-day inspection pilot to stretch resources. The tests are named successor staff and laboratories, research output, inspection frequency and depth, vacancy and travel burdens, time from recall to site inspection, outbreak-source findings and reductions in illnesses.

## MAYBE / THEREFORE

Maybe targeted sampling, importer controls and shorter inspections can manage risk more efficiently than a simple inspection count, and USDA may transfer specialized research without losing output. Alternatively, persistent vacancies, reduced travel support and a research relocation may weaken detection and prevention. Therefore the record documents measured inspection decline and disputed capacity risks, not proof that current staffing or research changes caused the outbreak or that all federal safeguards failed.


## SOURCES

- [Reuters via MarketScreener — USDA cyclospora projects face shutdown amid funding cuts and relocation](https://www.marketscreener.com/news/usda-cyclospora-research-projects-shelved-amid-funding-cuts-and-relocations-politico-reports-ce7858dcda8df22c) — independent account of Politico's document-based investigation with an on-record USDA response and explicit verification limitations
- [CDC — 2026 Cyclospora case surveillance data](https://www.cdc.gov/cyclosporiasis/cases/index.html) — primary federal surveillance counts and methodology for domestically acquired cyclosporiasis cases
- [FDA — multistate cyclospora outbreak linked to iceberg lettuce](https://www.fda.gov/food/outbreaks-foodborne-illness/investigation-multistate-outbreak-cyclospora-illnesses-iceberg-lettuce-july-2026) — primary outbreak update reporting the case subset, recall, onsite inspection and sampling, and the corrected laboratory result
- [Associated Press — cyclospora outbreak and declining FDA foreign-food inspections](https://apnews.com/article/7eb876d3e37864e8b589aeeff2bca384) — independent evidence review of FDA inspection counts, staffing and travel capacity, the farm inspection chronology and agency response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
