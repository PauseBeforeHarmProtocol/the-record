# USDA cyclospora research projects face shutdown during major outbreak

**Entry ID:** NAT-2026-08-30-002
**Date:** Fiscal 2026–August 30, 2026
**Checked:** 2026-08-30 12:03 PM EDT
**Evidence state:** Reuters account of a Politico investigation with an on-record USDA response, explicitly noting Reuters could not independently verify the staffing report, plus primary CDC surveillance data; two projects defunded, remaining-project continuity disputed and outcome unresolved
**Review state:** current-standard-reviewed

Two projects lost congressional funding and scientists on the remaining project reportedly declined relocation; USDA says the research has not been disrupted and will continue.

## THE FACTS

- Politico reported, and Reuters relayed with explicit inability to independently verify, that two of the Agriculture Department's three cyclospora research projects are being shuttered and the remaining project is scheduled to move from Maryland to Iowa in the fall under the department's broader reorganization.
- A USDA spokesperson told Politico that Congress did not appropriate fiscal 2026 funding for the two Beltsville Agricultural Research Center projects. The spokesperson said none of the research had been disrupted, that it would continue without disruption, and that the Agricultural Research Service was coordinating an orderly transition.
- Politico reported from internal documents and people familiar with the plans that all scientists working on the remaining project had declined to relocate to Iowa and that researchers were retiring or leaving rather than moving or taking reassignment. Reuters could not independently verify those staffing details, and USDA did not publish a project-by-project transition plan by cutoff.
- CDC's August 25 data reported 17,180 laboratory-confirmed domestically acquired cyclosporiasis cases from May 1 through August 24, compared with 1,180 in the same seasonal period of 2025, plus 922 hospitalizations and two deaths. CDC also listed at least 11,844 additional cases needing confirmation or investigation. Those surveillance figures establish the scale of illness, not that the research changes caused the outbreak or affected any individual case.

## SIGNIFICANCE

The reported loss of specialized personnel and projects during an unusually large foodborne-illness season raises a concrete capacity question for parasite detection, source attribution and prevention. Responsibility is divided: Congress withheld funding for two projects, while USDA's relocation plan affects the third, so neither the administration nor Congress alone explains the full reported risk.

## GOALPOST / RESPONSE

USDA says the research has not been disrupted, will continue, and is undergoing an orderly transition after Congress declined to fund two projects. The strongest concern is that expertise may be lost if the remaining scientists do not relocate and replacement capacity is not operating before their departure. Named successor staff, laboratory location and readiness, transferred methods and samples, project milestones, staffing retention, outbreak-source findings, peer-reviewed output, and future appropriations are the tests.

## MAYBE / THEREFORE

Maybe USDA can transfer the work without interruption and the reported departures will not reduce output; alternatively, loss of specialized staff may create a gap even while funding remains on paper. Therefore the record reports a documented funding loss, an announced relocation and a credible report of threatened research capacity—not proof that all cyclospora research has stopped or that the changes caused the 2026 outbreak.


## SOURCES

- [Reuters via MarketScreener — USDA cyclospora projects face shutdown amid funding cuts and relocation](https://www.marketscreener.com/news/usda-cyclospora-research-projects-shelved-amid-funding-cuts-and-relocations-politico-reports-ce7858dcda8df22c) — independent account of Politico's document-based investigation with an on-record USDA response and explicit verification limitations
- [Reuters — USDA announces research and food-safety staff relocation](https://www.reuters.com/world/us/us-farm-agency-move-research-food-safety-staff-washington-2026-04-23/) — independent reporting quoting USDA's announced Beltsville decommissioning and Iowa food-safety relocation rationale
- [CDC — 2026 Cyclospora case surveillance data](https://www.cdc.gov/cyclosporiasis/cases/index.html) — primary federal surveillance counts and methodology for domestically acquired cyclosporiasis cases

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
