# Record Cyclospora outbreak ends while source and federal capacity questions remain

**Entry ID:** NAT-2026-08-30-002
**Date:** Fiscal 2026–September 11, 2026
**Checked:** 2026-09-11 12:02 PM EDT
**Evidence state:** primary FDA closure update plus AP and Reuters reporting, preserving broader surveillance and capacity evidence; outbreak ended, root cause and institutional causation unresolved
**Review state:** current-standard-reviewed

CDC declared the 12,883-case iceberg-lettuce outbreak over, but FDA's investigation and sample analysis remain open and the contamination mechanism is unresolved.

## THE FACTS

- On September 11, CDC declared the multistate outbreak linked epidemiologically to processed iceberg lettuce from Taylor Farms de Mexico over. FDA said recalled products were past their best-by dates and off the market, while its outbreak investigation remained open.
- FDA reported 12,883 outbreak-associated illnesses across 21 states, 570 hospitalizations and two deaths, with the latest illness onset on August 17. Those outbreak-specific figures are distinct from the broader 19,595 laboratory-confirmed U.S. cyclosporiasis cases reported since May 1.
- FDA said onsite inspections and sample collection at central-Mexico growers and a processing facility had ended, but laboratory analysis was pending. AP reported that officials still had not identified how contamination occurred on the scale observed; the false-positive product sample corrected in July remains separate from the epidemiological link and recall.
- USDA previously said cyclospora research would continue without disruption despite Congress not funding two of three projects and plans to move the remaining project from Maryland to Iowa. No project-by-project continuity results were available by cutoff.
- AP previously measured a nearly 35% decline in FDA foreign-food-site inspections from 2019 and a 17% fiscal 2025 decline to 1,140. FDA said inspections are one part of its import-safety system; the evidence does not establish that staffing, travel support, research relocation or inspection counts caused this outbreak.

## SIGNIFICANCE

The official end date and final outbreak count document the largest recorded U.S. multistate cyclosporiasis outbreak while leaving its contamination pathway unresolved. That gap makes inspection and research capacity materially relevant, but it does not prove that a specific federal decision caused the illnesses or that the recall alone produced the decline.

## GOALPOST / RESPONSE

CDC and FDA say the implicated lettuce is no longer available and infections declined enough to close the outbreak; FDA continues the investigation. USDA says research continuity will be preserved, and FDA says inspections are one layer of import oversight. Pending sample results, a root-cause account, prevention measures, future inspection and research output, and later illness rates are the tests.

## MAYBE / THEREFORE

Maybe traceback, recall and product expiration ended exposure despite reduced inspection capacity, or unresolved contamination and resource constraints may leave recurrence risks. Therefore the outbreak is officially ended with 12,883 cases, 570 hospitalizations and two deaths—but the precise contamination mechanism, institutional contribution and prevention effectiveness remain unresolved.


## SOURCES

- [Reuters via MarketScreener — USDA cyclospora projects face shutdown amid funding cuts and relocation](https://www.marketscreener.com/news/usda-cyclospora-research-projects-shelved-amid-funding-cuts-and-relocations-politico-reports-ce7858dcda8df22c) — independent account of Politico's document-based investigation with an on-record USDA response and explicit verification limitations
- [CDC — 2026 Cyclospora case surveillance data](https://www.cdc.gov/cyclosporiasis/cases/index.html) — primary federal surveillance counts and methodology for domestically acquired cyclosporiasis cases
- [FDA — multistate cyclospora outbreak linked to iceberg lettuce](https://www.fda.gov/food/outbreaks-foodborne-illness/investigation-multistate-outbreak-cyclospora-illnesses-iceberg-lettuce-july-2026) — primary outbreak update reporting the case subset, recall, onsite inspection and sampling, and the corrected laboratory result
- [Associated Press — cyclospora outbreak and declining FDA foreign-food inspections](https://apnews.com/article/7eb876d3e37864e8b589aeeff2bca384) — independent evidence review of FDA inspection counts, staffing and travel capacity, the farm inspection chronology and agency response
- [Associated Press — record-setting Cyclospora outbreak ended with origin unresolved](https://apnews.com/article/cyclospora-outbreak-iceberg-lettuce-9b2c348b2f378b7554b2abfbf1780550) — independent public-health reporting
- [Reuters — United States declares largest recorded multistate cyclosporiasis outbreak ended](https://www.reuters.com/business/healthcare-pharmaceuticals/us-declares-end-largest-recorded-cyclosporiasis-outbreak-2026-09-11/) — independent reporting based on federal health data

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
