# Supreme Court leaves administrative-closure restriction in place during appeal

**Entry ID:** NAT-2026-10-27-002
**Date:** October 27, 2026
**Checked:** 2026-10-27 6:11 PM EDT
**Evidence state:** Primary Supreme Court docket and federal opposition, corroborated by Reuters; emergency stay denied, merits unresolved. High confidence in procedural disposition, no outcome estimate.
**Review state:** current-standard-reviewed

The Court denied emergency relief from the Texas consent judgment; it gave no reasons and did not decide the merits.

## THE FACTS

- On October 27, the Supreme Court denied the stay application in City of Baltimore v. Texas, No. 26A500, after Justice Alito referred it to the Court. The docket records the denial without an explanation.
- Reuters reports that the denial leaves in place a June 22 consent judgment invalidating the 2024 administrative-closure regulation. Texas sued and the federal government agreed to the judgment on the same day; litigation over the cities' and Centro Legal de la Raza's attempt to intervene continues.
- Administrative closure removes a removal case from the active docket without resolving it, including while separate immigration relief is pursued. The emergency denial does not itself order any identified person deported or establish a final Supreme Court merits holding.
- In its filed opposition, the Justice Department argued the applicants lacked standing and irreparable harm, and that the regulation permitted indefinite suspensions beyond immigration judges' statutory authority. Applicants argued that the government used aligned litigation to bypass ordinary agency procedures; these are competing litigating positions, not findings made in the unexplained denial.

## SIGNIFICANCE

Leaving the judgment operative restricts a case-management protection while intervention litigation continues. It can affect access to pending relief and local legal-service demands, but the order supplies no reason to infer that the Court endorsed every administration argument.

## GOALPOST / RESPONSE

The administration argues immigration cases should reach decisions rather than remain indefinitely inactive, and that these applicants lack standing to challenge the judgment. The strongest competing case is that closure allows eligible people to finish other relief processes. The appeal, standing decisions, actual case dispositions and access to relief are the tests.

## MAYBE / THEREFORE

Maybe the denial rests on standing or emergency-relief requirements, or the Court sees no basis to disturb the judgment at this stage. Therefore it confirms a stay was denied and the restriction remains operative—not a reasoned merits endorsement, a universal bar to every form of continuance, or completed deportations.


## SOURCES

- [Supreme Court docket 26A500: stay denied](https://www.supremecourt.gov/docket/docketfiles/html/public/26a500.html) — primary court docket
- [Federal respondents oppose stay in Baltimore v. Texas](https://www.supremecourt.gov/DocketPDF/26/26A500/430409/20261022153257048_Baltimore_v_Texas_stay_opp.pdf) — primary litigation brief, party position
- [Supreme Court declines to restore administrative closure during appeal](https://www.investing.com/news/politics-news/us-supreme-court-denies-immigration-judges-the-power-to-shelve-deportation-cases-4976451) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
