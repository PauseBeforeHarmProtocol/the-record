# USDA proposes tighter SNAP time limits and waiver rules

**Entry ID:** NAT-2026-11-10-010
**Date:** November 10, 2026
**Checked:** 2026-11-11 12:02 PM EST
**Evidence state:** Federal Register proposed rule and nonpartisan statutory context; proposed, with comments, finalization, state implementation and participant outcomes unresolved
**Review state:** current-standard-reviewed

The rule would codify statutory eligibility changes and separately narrow how states can seek geographic waivers.

## THE FACTS

- USDA published the proposed rule on November 10, before the prior archive boundary; this release records a retrospective discovery rather than a post-boundary proposal. Comments are due December 10, 2026. It is distinct from USDA’s separately recorded categorical-eligibility proposal.
- The proposal would codify 2025 statutory changes applying the three-month SNAP time limit to adults ages 18 through 64 unless an exception applies, lowering the dependent-child exception to children under 14 and removing temporary exceptions for homeless people, veterans and specified former foster youth while adding statutory Indian exceptions.
- For geographic waivers, the law now generally requires unemployment above 10%, with a 1.5-times-national-rate standard for Alaska and Hawaii. USDA separately proposes recent 12-month data standards, limited exceptional-circumstance alternatives, and a definition of eligible area that would prevent statewide or disparate-county groupings; it also proposes removing “imminently homeless” from SNAP’s homeless definition.
- USDA says the changes implement Congress’s work and self-sufficiency policy and tighten waiver integrity. The notice estimates substantial system, notice and screening work, including 649,936 startup hours for 53 state agencies and 6.16 million ongoing annual burden hours across agencies and individuals. Those estimates do not establish how many people will lose or retain benefits under a final rule.

## SIGNIFICANCE

The proposal would translate enacted SNAP time-limit changes into nationwide administration and add discretionary restrictions on waivers and homelessness definitions. It could affect eligibility, state workload and access, but the final text and participant consequences remain unresolved.

## GOALPOST / RESPONSE

USDA says narrower, data-based waivers will promote work and program integrity. The tests are comments, the final rule, state systems and notices, waiver approvals and denials, benefit terminations, employment outcomes, food insecurity, administrative errors, appeals and litigation.

## MAYBE / THEREFORE

Maybe clearer exceptions and recent labor-market data make SNAP administration more consistent and waivers more targeted, or the combined rules may end benefits for eligible people facing unstable work and limited local jobs. Therefore the record establishes a proposed implementation and waiver framework—not a final rule, a completed cutoff or a measured employment or nutrition outcome.


## SOURCES

- [Federal Register — modification to SNAP work requirements and time-limit waivers](https://www.federalregister.gov/documents/2026/11/10/2026-22944/modification-to-work-requirements-for-able-bodied-adults) — primary proposed rule; complete notice and burden analysis inspected
- [Congressional Research Service — SNAP work requirement and time-limit background](https://www.everycrsreport.com/files/2026-11-04_R42505_48e7f73c63e62171b99cf10728a3a779b1ee6d3b.html) — independent nonpartisan statutory and implementation context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
