# Federal judge vacates Education Department anti-DEI grant directive

**Entry ID:** NAT-2026-09-17-003
**Date:** September 17, 2026
**Checked:** 2026-09-18 12:00 AM EDT
**Evidence state:** complete primary district-court order plus independent Reuters reporting; directive vacated and declared unlawful, individual monetary relief and any appeal unresolved
**Review state:** current-standard-reviewed

The nationwide policy was set aside under the APA; individual payment and termination claims remain outside this court's judgment.

## THE FACTS

- U.S. District Judge Angel Kelley granted the plaintiff states summary judgment, denied the Education Department's cross-motion and vacated in full the February 5, 2025 directive titled ‘Eliminating Discrimination and Fraud in Department Grant Awards.’
- The 70-page order holds that the directive was arbitrary and capricious and contrary to law, including because the department failed to use required notice and comment and acted contrary to the Teacher Quality Partnership and Supporting Effective Educator Development statutes and the General Education Provisions Act.
- The record says the department terminated 104 of 109 TQP and SEED grants under the directive by March 12, 2025, including all 40 grants in the plaintiff states. The department had publicly described more than $600 million in terminated grants; those figures describe the policy's reach, not money restored by this judgment.
- The court had previously held that challenges to individual grant terminations sound in contract and must be brought in the Court of Federal Claims. It declined a permanent injunction as duplicative of vacatur. The order therefore invalidates the directive going forward but does not itself award repayment or automatically reinstate every terminated grant.

## SIGNIFICANCE

Vacatur removes the department-wide policy that drove most TQP and SEED terminations and preserves the ordinary statutory and regulatory framework for future awards. Financial recovery and individual grant status remain separate questions.

## GOALPOST / RESPONSE

The department had said the directive stopped taxpayer funding for divisive ideologies and fraud. The court found the agency's rapid, broad implementation lacked lawful procedure and statutory support. Appeals, Court of Federal Claims outcomes, FY2026 awards and any replacement policy are the next tests; the department gave Reuters no immediate response.

## MAYBE / THEREFORE

Maybe the ruling restores a stable lawful framework for teacher-training grants, or the department may appeal or adopt a narrower policy through proper procedures. Therefore the established result is vacatur and a declaration of unlawfulness—not automatic repayment, final appellate resolution or proof that every terminated project was effective.


## SOURCES

- [U.S. District Court for Massachusetts — order vacating Education Department grant directive](https://fingfx.thomsonreuters.com/gfx/legaldocs/egvbgyomopq/09172026education.pdf) — primary 70-page summary-judgment order in New Jersey v. U.S. Department of Education
- [Reuters — judge vacates Education Department anti-DEI grant policy](https://www.reuters.com/legal/government/us-judge-strikes-down-education-departments-anti-dei-grant-policy-2026-09-17/) — independent court reporting based on the complete order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
