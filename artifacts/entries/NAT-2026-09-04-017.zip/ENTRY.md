# Administration asks Supreme Court to revive SAVE after appellate stay denial

**Entry ID:** NAT-2026-09-04-017
**Date:** September 4–8, 2026
**Checked:** 2026-09-08 6:02 PM EDT
**Evidence state:** primary June opinion and indexed government-application passages plus Reuters and specialist legal reporting; application pending, response ordered, no stay established
**Review state:** current-standard-reviewed

The stay application and a response deadline advance the litigation; neither restores the modified database or resolves its legality.

## THE FACTS

- On September 4, the D.C. Circuit denied a stay of the June judgment blocking modified SAVE. Judges Sri Srinivasan and Robert Wilkins formed the majority; Gregory Katsas dissented. That stay decision did not finally resolve the merits appeal.
- The June district-court opinion found the overhaul violated the Social Security Act, Privacy Act and Administrative Procedure Act. The litigation concerns centralized citizenship and Social Security information and risks to eligible voters, not a finding that every database result is wrong.
- On September 8, the administration applied to the Supreme Court to stay the district-court order. It argues the order unlawfully prevents federal use of Social Security information to answer state citizenship-verification requests. This is an application, not relief granted.
- Democracy Docket reported that Chief Justice John Roberts directed a response by 4 PM EDT on September 15. A briefing deadline does not itself lift the block or decide the merits.
- A separate Florida order had required access for four Republican-led states. The September 8 application does not itself resolve that conflicting-order issue; the D.C. Circuit merits appeal remains pending.

## SIGNIFICANCE

The administration has escalated the existing privacy and election-administration dispute to the Supreme Court shortly before the midterms. Its desired operational change has not been established merely by filing.

## GOALPOST / RESPONSE

The administration says the system protects election integrity and enables required state assistance. Challengers say unlawful data-sharing and unreliable flags threaten privacy and eligible voters. Orders, state access, corrections and documented voter effects are the tests.

## MAYBE / THEREFORE

Maybe lawful, accurate verification can assist states, while incomplete federal data may burden eligible voters. Therefore the record establishes a pending stay request after a divided denial, not restored authority or a final Supreme Court judgment.


## SOURCES

- [League of Women Voters v. DHS — summary-judgment memorandum opinion](https://law.justia.com/cases/federal/district-courts/district-of-columbia/dcdce/1:2025cv03501/285454/111/) — primary court opinion vacating the modified SAVE system and identifying statutory violations and evidentiary limits
- [Reuters — D.C. Circuit declines to lift SAVE-system ban](https://www.reuters.com/legal/government/federal-appeals-court-upholds-ban-trumps-bid-use-citizenship-data-voter-checks-2026-09-05/) — independent reporting on the appellate stay ruling, panel division and operative effect
- [Democracy Docket — D.C. Circuit rejects emergency SAVE-system revival](https://www.democracydocket.com/news-alerts/in-latest-win-for-voters-appeals-court-rejects-bid-to-revive-dhs-voter-purge-database-for-now/) — specialist legal reporting linking the appellate order and describing expedited merits briefing
- [Solicitor General — application to stay the SAVE judgment, No. 26A308](https://www.supremecourt.gov/DocketPDF/26/26A308/423264/20260908101245314_DHS%20v%20League%20of%20Women%20Voters%20Stay%20Application.pdf) — primary stay application; indexed passages inspected, full document retrieval unavailable; no merits ruling inferred
- [Democracy Docket — DOJ seeks Supreme Court stay of SAVE judgment](https://www.democracydocket.com/news-alerts/doj-asks-supreme-court-to-let-it-use-immigration-database-to-purge-state-voter-rolls/) — specialist legal reporting of the application, competing positions and September 15 response deadline
- [Reuters — administration asks Supreme Court to allow voter-verification database](https://www.reuters.com/legal/government/trump-asks-supreme-court-allow-voter-verification-database-blocked-by-judge-2026-09-08/) — independent reporting of the September 8 stay application

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
