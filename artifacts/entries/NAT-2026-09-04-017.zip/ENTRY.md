# D.C. Circuit leaves nationwide SAVE voter-database ban in place during expedited appeal

**Entry ID:** NAT-2026-09-04-017
**Date:** September 4, 2026
**Checked:** 2026-09-05 6:00 PM EDT
**Evidence state:** primary June district-court opinion plus independent Reuters and specialist legal reporting on the September 4 appellate order; stay denied and ban operative, merits, state-access conflict and further review unresolved
**Review state:** current-standard-reviewed

A divided appellate panel refused the administration's emergency request to revive the modified citizenship-check system; the merits appeal continues on an accelerated schedule.

## THE FACTS

- The U.S. Court of Appeals for the District of Columbia Circuit denied the Trump administration's request to stay a June judgment that vacated the modified Systematic Alien Verification for Entitlements system while the government appeals.
- Chief Judge Sri Srinivasan and Judge Robert Wilkins concluded that the government had not met the stringent requirements for a stay. Judge Gregory Katsas dissented. The September 4 ruling therefore keeps the district-court remedy in place but does not finally resolve the merits appeal.
- The June judgment found that the 2025 SAVE overhaul violated the Social Security Act, Privacy Act and Administrative Procedure Act. The modified system added bulk searches, Social Security-number searches and data concerning U.S. citizens to a program historically used to verify eligibility for public benefits and licenses.
- The appellate majority cited two naturalized citizens whose Social Security records still incorrectly identified them as noncitizens and DHS's warning that the data could generate incomplete or false results. Reuters and Democracy Docket reported that inaccurate flags can require eligible voters to prove citizenship and can lead to registration cancellation; the public record does not establish how many voters remain wrongly affected nationwide.
- A separate federal order in Florida had required DHS to restore access for Florida, Iowa, Indiana and Ohio, creating conflicting district-court directives. The D.C. Circuit ordered expedited merits briefing and did not resolve that conflict, the ultimate legality of modified SAVE or any later Supreme Court review.

## SIGNIFICANCE

The ruling prevents immediate nationwide revival of an election-administration database that combined federal citizenship and Social Security information shortly before the midterms. Its operational effect protects the district-court remedy for now, while the split orders and pending merits appeal leave the system's final scope unsettled.

## GOALPOST / RESPONSE

The administration says modified SAVE gives states a practical way to verify voter citizenship and argues that blocking it prevents millions of checks. The courts have emphasized statutory privacy limits, forfeited government arguments and risks from inaccurate records. Expedited briefing, any rehearing or Supreme Court application, DHS compliance, state access, correction procedures and documented voter effects are the tests.

## MAYBE / THEREFORE

Maybe modified SAVE can lawfully improve election-roll accuracy if agencies follow statutory procedures and promptly correct stale records, or mass use of imperfect federal data may expose private information and wrongly burden eligible voters. Therefore the record establishes a divided refusal to lift the ban and an expedited appeal—not final invalidation by the appellate court, proof that every database result is wrong or resolution of the conflicting Florida order.


## SOURCES

- [League of Women Voters v. DHS — summary-judgment memorandum opinion](https://law.justia.com/cases/federal/district-courts/district-of-columbia/dcdce/1:2025cv03501/285454/111/) — primary court opinion vacating the modified SAVE system and identifying statutory violations and evidentiary limits
- [Reuters — D.C. Circuit declines to lift SAVE-system ban](https://www.reuters.com/legal/government/federal-appeals-court-upholds-ban-trumps-bid-use-citizenship-data-voter-checks-2026-09-05/) — independent reporting on the appellate stay ruling, panel division and operative effect
- [Democracy Docket — D.C. Circuit rejects emergency SAVE-system revival](https://www.democracydocket.com/news-alerts/in-latest-win-for-voters-appeals-court-rejects-bid-to-revive-dhs-voter-purge-database-for-now/) — specialist legal reporting linking the appellate order and describing expedited merits briefing

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
