# Supreme Court restores expanded SAVE system pending appeal

**Entry ID:** NAT-2026-09-04-017
**Date:** September 4–25, 2026
**Checked:** 2026-09-25 11:59 AM EDT
**Evidence state:** primary June opinion and government stay application plus Reuters reporting on the Supreme Court's interim order and state-level error evidence; system restored pending appeal, merits and nationwide error rate unresolved
**Review state:** current-standard-reviewed

The justices stayed the district-court block, allowing expanded federal voter-citizenship checks while litigation continues; the order is interim, not a merits judgment.

## THE FACTS

- On September 4, the D.C. Circuit denied a stay of the June judgment blocking modified SAVE. Judges Sri Srinivasan and Robert Wilkins formed the majority; Gregory Katsas dissented. That stay decision did not finally resolve the merits appeal.
- The June district-court opinion found the overhaul violated the Social Security Act, Privacy Act and Administrative Procedure Act. The litigation concerns centralized citizenship and Social Security information and risks to eligible voters, not a finding that every database result is wrong.
- On September 8, the administration applied to the Supreme Court to stay the district-court order. It argues the order unlawfully prevents federal use of Social Security information to answer state citizenship-verification requests. This is an application, not relief granted.
- Democracy Docket reported that Chief Justice John Roberts directed a response by 4 PM EDT on September 15. A briefing deadline does not itself lift the block or decide the merits.
- A separate Florida order had required access for four Republican-led states. The September 8 application does not itself resolve that conflicting-order issue; the D.C. Circuit merits appeal remains pending.
- On September 25, the Supreme Court granted the administration's request to stay the district-court order, restoring states' ability to use Social Security numbers and other federal data in expanded SAVE checks while the appeal proceeds. Reuters reported examples of erroneous noncitizen matches cited by challengers; those local findings do not establish a nationwide error rate. The stay changes current access but is not a final merits judgment.

## SIGNIFICANCE

The Supreme Court's stay changes the system's present operating status shortly before the midterms: states may again use the expanded federal matching process while the appeal proceeds. The order does not validate the system's accuracy or resolve the underlying statutory and privacy claims.

## GOALPOST / RESPONSE

The administration says expanded SAVE protects election integrity and supplies citizenship information states are entitled to request. Challengers point to erroneous flags and privacy risks. The merits appeal, correction rates, state actions, notice and cure procedures, and documented effects on eligible voters are the tests.

## MAYBE / THEREFORE

Maybe federal matching will help states identify some ineligible registrations, while incomplete or stale records may also flag eligible citizens. Therefore the record establishes restored interim authority pending appeal—not a final ruling that modified SAVE is lawful, accurate or outcome-determinative.


## SOURCES

- [League of Women Voters v. DHS — summary-judgment memorandum opinion](https://law.justia.com/cases/federal/district-courts/district-of-columbia/dcdce/1:2025cv03501/285454/111/) — primary court opinion vacating the modified SAVE system and identifying statutory violations and evidentiary limits
- [Reuters — D.C. Circuit declines to lift SAVE-system ban](https://www.reuters.com/legal/government/federal-appeals-court-upholds-ban-trumps-bid-use-citizenship-data-voter-checks-2026-09-05/) — independent reporting on the appellate stay ruling, panel division and operative effect
- [Democracy Docket — D.C. Circuit rejects emergency SAVE-system revival](https://www.democracydocket.com/news-alerts/in-latest-win-for-voters-appeals-court-rejects-bid-to-revive-dhs-voter-purge-database-for-now/) — specialist legal reporting linking the appellate order and describing expedited merits briefing
- [Solicitor General — application to stay the SAVE judgment, No. 26A308](https://www.supremecourt.gov/DocketPDF/26/26A308/423264/20260908101245314_DHS%20v%20League%20of%20Women%20Voters%20Stay%20Application.pdf) — primary stay application; indexed passages inspected, full document retrieval unavailable; no merits ruling inferred
- [Democracy Docket — DOJ seeks Supreme Court stay of SAVE judgment](https://www.democracydocket.com/news-alerts/doj-asks-supreme-court-to-let-it-use-immigration-database-to-purge-state-voter-rolls/) — specialist legal reporting of the application, competing positions and September 15 response deadline
- [Reuters — administration asks Supreme Court to allow voter-verification database](https://www.reuters.com/legal/government/trump-asks-supreme-court-allow-voter-verification-database-blocked-by-judge-2026-09-08/) — independent reporting of the September 8 stay application
- [Supreme Court restores Trump administration's expanded SAVE voter-verification system pending appeal](https://www.reuters.com/world/supreme-court-restores-trumps-mass-voter-verification-system-2026-09-25/) — independent court and implementation reporting; interim stay, not merits judgment

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
