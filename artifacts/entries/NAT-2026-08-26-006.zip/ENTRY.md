# Army awards contingent microreactor contracts worth up to $2.2 billion

**Entry ID:** NAT-2026-08-26-006
**Date:** August 26, 2026
**Checked:** 2026-08-26 5:59 PM EDT
**Evidence state:** Army announcement independently reported with named officials and matching award terms by Reuters and AP; selections and maximum contract value announced, payments contingent and deployment outcomes pending
**Review state:** current-standard-reviewed

Five companies were paired with five bases under the Janus Program; payments depend on technical milestones and the first operating reactor is targeted for September 2028.

## THE FACTS

- The U.S. Army announced awards worth up to $2.2 billion over five years to five companies to own, build, and operate nuclear microreactors at Fort Bragg, Fort Campbell, Fort Hood, Fort Benning, and Fort Drum, according to independent reporting by Reuters and the Associated Press.
- The awards are milestone-based rather than an immediate $2.2 billion expenditure. The Army expects more than 20 reactors across the program and targets the first operating reactor by September 2028; the announced units would provide roughly 1 to 20 megawatts and would supplement, not fully replace, commercial-grid service at the bases.
- Army officials told both outlets that the service, not the Nuclear Regulatory Commission, will license the military reactors while seeking alignment with commercial safety standards. Officials say the program will strengthen base resilience and attract private capital; critics cited by AP question microreactor cost and safety, and waste arrangements remain under development.

## SIGNIFICANCE

The awards move the Janus Program from site and vendor planning into contingent federal contracting at meaningful scale. They also make the Army a regulator and early customer for a technology not yet supplying the U.S. commercial grid, creating measurable cost, safety, schedule, waste, and resilience tests.

## GOALPOST / RESPONSE

The Army says microreactors can provide reliable baseload power when external grids or fuel logistics are vulnerable and can help produce commercially useful designs. Critics say small reactors may remain more expensive than conventional generation and present safety and waste challenges. Milestone payments, licensing records, environmental review, private capital, cost per kilowatt-hour, waste agreements, and the September 2028 deployment target are the evidence tests.

## MAYBE / THEREFORE

Maybe vendor competition and milestone payments will limit taxpayer exposure while producing resilient power and commercially viable designs, or one or more vendors may fail before construction. Therefore the record reports awards of up to $2.2 billion—not money already spent or reactors already built—and preserves the Army-regulation and waste-management uncertainties.


## SOURCES

- [Reuters — Army awards up to $2.2 billion for Janus microreactors](https://www.reuters.com/business/energy/us-army-awards-up-22-billion-five-companies-build-microreactors-bases-2026-08-26/) — independent reporting with named Army official, award terms, vendors, and cost context
- [Associated Press — Army selects five companies for base microreactors](https://apnews.com/article/nuclear-trump-army-microreactors-janus-200edd5fb98b6fe04d029a3c1dba1a4a) — independent reporting with Army announcement, contract conditions, licensing, and safety context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
