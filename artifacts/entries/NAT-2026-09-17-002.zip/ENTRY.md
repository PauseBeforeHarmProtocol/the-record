# U.S. adds eight Cuban enterprises and three officials to sanctions list

**Entry ID:** NAT-2026-09-17-002
**Date:** September 17, 2026
**Checked:** 2026-09-17 6:01 PM EDT
**Evidence state:** primary OFAC target list plus Reuters reporting of official rationale and response; implemented designations, consequences unmeasured
**Review state:** current-standard-reviewed

The new listings cover nickel-sector and military research entities; this is a distinct September 17 action, not a recount of earlier Cuba sanctions.

## THE FACTS

- OFAC's September 17 SDN update added eight Cuban entities and three individuals under the CUBA-EO14404 program. The individuals are Joaquin Francisco Cancio Monteagudo, Julio Hurtado Betancourt and Dioglis Pedrera Arguello.
- The listed enterprises include nickel-sector organizations CEDINIQ, CEPRONIQUEL, SERCONI and Pinares S.A., plus four military research or development centers identified as CIDAI, CID-SIM, CIDNAV and CIDP Grito de Baire. Alternate names in the notice are aliases, not extra targets.
- Reuters reports that Marco Rubio framed the sanctions as targeting an elite-enrichment system. It also records Bruno Rodriguez's earlier warning of lethal sanctions harm and Cuba's rejection of the U.S. national-security characterization. Those are attributed positions, not measured effects of this new action.

## SIGNIFICANCE

The target list reaches both a revenue-producing industrial sector and military research organizations. The official action establishes who was listed, not the value of assets affected or the net civilian impact.

## GOALPOST / RESPONSE

The administration's stated aim is to constrain resources benefiting Cuba's governing elite; Cuba disputes the security premise and emphasizes civilian harm. Assess the action against actual blocked assets, exemptions, commercial changes and independently measured effects.

## MAYBE / THEREFORE

Maybe the listings constrain targeted resources, or costs shift to other counterparties and civilians. Therefore this record establishes the new target-level action without assuming effectiveness or assigning an unmeasured humanitarian toll.


## SOURCES

- [OFAC — Iran and Cuba designations and Belarus deletions, September 17](https://ofac.treasury.gov/recent-actions/20260917) — primary sanctions-list action
- [Reuters — Cuba nickel and military sanctions](https://www.reuters.com/world/americas/us-sanctions-cuban-nickel-reserves-military-enterprises-2026-09-17/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
