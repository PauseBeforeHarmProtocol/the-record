# August trade deficit widens despite tariff policy; year-to-date gap remains smaller

**Entry ID:** NAT-2026-10-06-001
**Date:** October 6, 2026
**Checked:** 2026-10-06 12:04 PM EDT
**Evidence state:** joint official BEA/Census statistical release and report, independently corroborated by Reuters; measured, nominal and subject to revision; policy causation unresolved
**Review state:** current-standard-reviewed

The October 6 official release measures a $105.6 billion monthly deficit; one month does not isolate tariff effects.

## THE FACTS

- BEA and Census released August 2026 trade statistics at 8:30 AM EDT on October 6. The goods-and-services deficit was $105.6 billion, $12.7 billion or 13.7% above revised July’s $92.8 billion.
- Exports rose $4.5 billion to $315.2 billion while imports rose $17.2 billion to $420.8 billion. The goods deficit was $136.6 billion and the services surplus $31.0 billion. These headline values are seasonally adjusted nominal amounts, not adjusted for price changes.
- The official year-to-date comparison points in a different direction: the goods-and-services deficit was $138.2 billion, or 19.9%, smaller than in the same period of 2025. Exports and imports both increased year to date.
- Reuters independently reported the release and described strong domestic demand as context for the import increase. The official statistics establish measured trade flows; they do not identify how much of the change was caused by tariffs, prices, demand or shipment timing.
- In its January 20 accomplishments statement, the White House credited tariff enforcement and reciprocal trade pressure for an earlier deficit decline. That dated explanation is relevant policy context, not an October 6 response or independent proof of tariff effectiveness. No release-specific administration response was located in the inspected material.

## SIGNIFICANCE

The latest monthly measurement tests a central stated objective of the administration’s tariff policy and shows a larger monthly shortfall. The smaller year-to-date gap and the nominal-data limits prevent treating this release alone as proof of overall policy success or failure.

## GOALPOST / RESPONSE

The administration has presented tariff enforcement and reciprocal pressure as tools to reduce the deficit and strengthen domestic production. The strongest favorable frame in this release is the smaller year-to-date shortfall. Sustained real trade flows, domestic capacity, prices, investment and a causal comparison are needed to evaluate that explanation.

## MAYBE / THEREFORE

Maybe the August import increase reflects strong demand or investment while tariff effects develop over a longer period, or it may show continued reliance on foreign goods. Therefore August’s measured deficit widened while the year-to-date deficit remained smaller; the release does not independently establish tariff causation or the final economic outcome.


## SOURCES

- [BEA and Census — August 2026 international trade release](https://www.bea.gov/news/2026/us-international-trade-goods-and-services-august-2026) — primary official statistical release
- [Census — FT-900 August 2026 trade report](https://www.census.gov/foreign-trade/Press-Release/ft900/ft900_2608.pdf) — primary official statistical report
- [Reuters — Record imports widen August trade deficit](https://www.reuters.com/business/us-trade-deficit-widens-august-amid-strong-imports-2026-10-06/) — independent reporting
- [White House — January 20 annual accomplishments statement](https://www.whitehouse.gov/releases/2026/01/365-wins-in-365-days-president-trumps-return-marks-new-era-of-success-prosperity/) — primary administration explanation; retrospective context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
