# Trade-effectiveness record adds IW’s descriptive deficit and investment findings

**Entry ID:** NAT-2026-10-06-001
**Date:** October 6–30, 2026
**Checked:** 2026-10-30 12:04 PM EDT
**Evidence state:** joint official BEA/Census statistical release and report, independently corroborated by Reuters; measured, nominal and subject to revision; policy causation unresolved; original October 30 IW descriptive study and full Reuters corroboration added; statistical-series and causal limits explicit
**Review state:** current-standard-reviewed

The original official trade release is preserved; IW’s later descriptive analysis is not a causal estimate or a replacement for a different statistical series.

## THE FACTS

- BEA and Census released August 2026 trade statistics at 8:30 AM EDT on October 6. The goods-and-services deficit was $105.6 billion, $12.7 billion or 13.7% above revised July’s $92.8 billion.
- Exports rose $4.5 billion to $315.2 billion while imports rose $17.2 billion to $420.8 billion. The goods deficit was $136.6 billion and the services surplus $31.0 billion. These headline values are seasonally adjusted nominal amounts, not adjusted for price changes.
- The official year-to-date comparison points in a different direction: the goods-and-services deficit was $138.2 billion, or 19.9%, smaller than in the same period of 2025. Exports and imports both increased year to date.
- Reuters independently reported the release and described strong domestic demand as context for the import increase. The official statistics establish measured trade flows; they do not identify how much of the change was caused by tariffs, prices, demand or shipment timing.
- In its January 20 accomplishments statement, the White House credited tariff enforcement and reciprocal trade pressure for an earlier deficit decline. That dated explanation is relevant policy context, not an October 6 response or independent proof of tariff effectiveness. No release-specific administration response was located in the inspected material.
- On October 30, IW published Report 46/2026, comparing USITC goods-trade data from January 2024 through August 2026 and BEA annual foreign-direct-investment flows through 2025. It concluded that tariffs had not produced a sustained reduction in the goods deficit and reported changing partner shares. Its roughly $130 billion August goods-series figure is not substituted for the $136.6 billion seasonally adjusted official goods headline already recorded here; the inspected report does not reconcile those series.
- IW reports total inward FDI flows of $248 billion in 2025, 8.2% below 2024 and about 18% below the 2015–2024 average. Manufacturing FDI rose 3.3% year over year to $114 billion but was about 20% below that longer-run average. These are measured financial flows, not announced investment commitments or completed new-factory spending. The report explicitly finds divergent U.S. and German statistics for German investment, and describes robust growth and AI investment alongside weaker aggregate outcomes. Reuters independently reported the findings; this descriptive comparison does not isolate tariff causation.

## SIGNIFICANCE

The new study adds a longer comparison and realized FDI flows to the existing tariff-effectiveness record. Different trade series, annual periods and investment units must remain separate; an outcome during the policy is not an estimate of the outcome caused by the policy.

## GOALPOST / RESPONSE

The administration presents tariffs and investment agreements as ways to reduce trade dependence and rebuild manufacturing. The strongest favorable evidence here is the smaller official year-to-date trade gap, robust growth and AI investment, and the year-over-year manufacturing-FDI increase. Sustained output, realized investment, prices and comparable counterfactual evidence—not pledge totals—test the broader claim. No new report-specific administration response was located.

## MAYBE / THEREFORE

Maybe tariffs and negotiated commitments will attract more production over a longer horizon, while demand, frontloading, energy trade and financial transactions explain near-term flows. Therefore IW documents mixed descriptive outcomes, including lower total 2025 FDI and no sustained goods-deficit reduction in its series; it does not establish a causal tariff effect, reconcile every series or prove all investment promises failed.


## SOURCES

- [BEA and Census — August 2026 international trade release](https://www.bea.gov/news/2026/us-international-trade-goods-and-services-august-2026) — primary official statistical release
- [Census — FT-900 August 2026 trade report](https://www.census.gov/foreign-trade/Press-Release/ft900/ft900_2608.pdf) — primary official statistical report
- [Reuters — Record imports widen August trade deficit](https://www.reuters.com/business/us-trade-deficit-widens-august-amid-strong-imports-2026-10-06/) — independent reporting
- [White House — January 20 annual accomplishments statement](https://www.whitehouse.gov/releases/2026/01/365-wins-in-365-days-president-trumps-return-marks-new-era-of-success-prosperity/) — primary administration explanation; retrospective context
- [IW Report 46/2026 — US midterm elections: Unfulfilled promises](https://www.iwkoeln.de/fileadmin/user_upload/Studien/Report/PDF/2026/IW-Report_2026-US-midterm-elections.pdf) — primary original research report; descriptive economic analysis
- [Reuters — Trump’s tariffs fail to cut US trade deficit, IW report shows](https://kelo.com/2026/10/30/trumps-tariffs-fail-to-cut-us-trade-deficit-iw-report-shows/) — independent reporting; full Reuters syndication inspected

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
