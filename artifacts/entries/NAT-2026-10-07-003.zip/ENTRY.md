# CBP proposes low-value electronic entries and delays mail-process compliance

**Entry ID:** NAT-2026-10-07-003
**Date:** October 7–15, 2026
**Checked:** 2026-10-15 11:59 AM EDT
**Evidence state:** CBP announcement as described in independent Reuters reporting, alongside the primary October proposed rule; compliance date delayed, proposal and operational outcomes unresolved
**Review state:** current-standard-reviewed

CBP’s Entry Type 13 proposal remains pending, while the agency separately moved mandatory compliance for a related international-mail entry process from October 22 to January 20, 2027.

## THE FACTS

- CBP filed a proposed rule for October 8 publication that would require electronic informal entries by or before importation, create Entry Type 13 for qualifying international-mail merchandise valued at $2,500 or less and add shipment and carrier data requirements. The requirements are proposed, not final or implemented.
- Entry Type 13 would generally mirror Entry Type 11 and require a shipper or sender identity and address; carriers would provide the international tracking number. Owners or purchasers could self-file electronically, while a consignee would need a licensed broker acting as importer of record.
- The proposal would require Entry Type 11 and 13 filers to obtain a basic importation and entry bond. A mail article lacking a timely proper entry would not be released and would be deemed voluntarily abandoned after 15 days, after which USPS processing could include return or destruction.
- CBP estimates annualized monetized costs of about $1.099 billion at a 7% discount rate, annualized cost savings of about $969,000 and roughly $30.4 million in increased annual duty revenue. It says fuller data and bonding would improve security, compliance and revenue collection; those benefits are not monetized or measured here.
- CBP announced a 90-day extension of the mandatory compliance date for a new international-mail entry process, from October 22, 2026, to January 20, 2027. Reuters reported that the agency said existing international-mail procedures would not change before the later date.
- The delayed process requires electronic filing and a customs bond for covered postal shipments subject to specified trade duties or partner-agency jurisdiction. The agency said the extension gives importers, brokers and logistics providers more preparation time and reduces disruption while closing gaps used by smugglers.
- Patient and pharmacy groups warned that the process could delay or raise costs for personal prescription orders. CBP's announcement did not mention medicines, and the underlying rule does not create a medicine-specific exemption; the 90-day delay is temporary and does not establish long-term access or price effects.

## SIGNIFICANCE

The delay postpones an imminent operational change for international mail, including shipments that may fall under FDA jurisdiction, while leaving the broader proposed electronic-entry and bonding framework unresolved. It reduces near-term transition risk but does not cancel the policy or settle its consumer, enforcement or small-business effects.

## GOALPOST / RESPONSE

CBP says additional preparation time will reduce disruption and that advance data and bonds will improve enforcement. The January 20 compliance date, final rulemaking, filing error and clearance times, abandoned or returned shipments, enforcement results, medicine access, administrative costs and any further delay are the tests.

## MAYBE / THEREFORE

Maybe the extension gives legitimate shippers enough time to comply without disrupting access, or the same burdens may reappear in January absent technical or policy changes. Therefore mandatory compliance is delayed 90 days—not canceled—and no measured medicine-price, security or smuggling outcome is established.


## SOURCES

- [CBP — Low-value shipments proposed rule](https://public-inspection.federalregister.gov/2026-20650.pdf) — official Federal Register public-inspection proposed rule
- [Reuters — CBP delays international-mail entry compliance by 90 days](https://www.reuters.com/legal/government/us-delays-small-imports-rule-that-raised-alarm-over-prescription-drug-costs-2026-10-15/) — independent reporting of named agency announcement and stakeholder response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
