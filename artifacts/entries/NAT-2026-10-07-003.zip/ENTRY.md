# CBP proposes electronic entries and bonds for low-value shipments

**Entry ID:** NAT-2026-10-07-003
**Date:** October 7, 2026
**Checked:** 2026-10-07 12:18 PM EDT
**Evidence state:** primary CBP/DHS proposed rule; requirements proposed, quantified costs and revenue transfers forecast, outcomes unmeasured
**Review state:** current-standard-reviewed

The proposal covers informal imports valued at $2,500 or less and would create a new Entry Type 13 for international mail.

## THE FACTS

- CBP filed a proposed rule for October 8 publication that would require electronic informal entries by or before importation, create Entry Type 13 for qualifying international-mail merchandise valued at $2,500 or less and add shipment and carrier data requirements. The requirements are proposed, not final or implemented.
- Entry Type 13 would generally mirror Entry Type 11 and require a shipper or sender identity and address; carriers would provide the international tracking number. Owners or purchasers could self-file electronically, while a consignee would need a licensed broker acting as importer of record.
- The proposal would require Entry Type 11 and 13 filers to obtain a basic importation and entry bond. A mail article lacking a timely proper entry would not be released and would be deemed voluntarily abandoned after 15 days, after which USPS processing could include return or destruction.
- CBP estimates annualized monetized costs of about $1.099 billion at a 7% discount rate, annualized cost savings of about $969,000 and roughly $30.4 million in increased annual duty revenue. It says fuller data and bonding would improve security, compliance and revenue collection; those benefits are not monetized or measured here.

## SIGNIFICANCE

The proposal would replace paper-era handling for a high-volume import channel with earlier electronic filing, bonds and stronger abandonment consequences. It could improve enforceability while imposing substantial costs on importers, brokers, carriers and postal operations.

## GOALPOST / RESPONSE

CBP says advance data, tracking-number matching and bonds will improve security, compliance and duty collection. Filing error rates, clearance times, abandoned or returned shipments, enforcement results, administrative cost and small-business effects are the tests.

## MAYBE / THEREFORE

Maybe earlier electronic data and financial security make low-value imports more enforceable, or the burden may disrupt lawful small shipments and postal capacity. Therefore CBP has proposed the system and estimated large compliance costs; no final requirement or measured benefit is established.


## SOURCES

- [CBP — Low-value shipments proposed rule](https://public-inspection.federalregister.gov/2026-20650.pdf) — official Federal Register public-inspection proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
