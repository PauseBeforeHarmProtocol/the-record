# FCC publishes proposal for satellite links to ordinary unlicensed devices

**Entry ID:** NAT-2026-09-08-002
**Date:** August 6–September 8, 2026
**Checked:** 2026-09-08 12:01 AM EDT
**Evidence state:** primary FCC proposed rule and Federal Register publication; adoption, bands and comment schedule documented, final authorization and outcomes pending
**Review state:** current-standard-reviewed

The proposal could let Wi-Fi, Bluetooth and other part 15 devices communicate with satellites in two bands, but no authorization is final or operative.

## THE FACTS

- The Federal Communications Commission adopted a Notice of Proposed Rulemaking on August 6, released it August 7 and published it in the Federal Register on September 8; comments are due November 9 and replies December 7.
- The proposal would add nonfederal mobile-satellite Earth-to-space allocations in the 2400–2483.5 MHz and 5725–5850 MHz bands on an unprotected, non-interference basis, potentially allowing ordinary part 15 devices such as Wi-Fi, Bluetooth, phones, laptops and internet-of-things equipment to transmit to satellites.
- The FCC seeks comment on part 25 licensing, including license-by-rule or blanket licensing, and on communications within spacecraft, during spacewalks and between spacecraft. It did not propose a part 15 space-to-Earth rule change in this notice.
- The Commission said widespread installed devices could produce substantial connectivity and innovation benefits without new hardware, but supplied no quantified benefit estimate. It predicted minimal or no costs while acknowledging interference, certification, international-coordination and compliance questions.
- No final allocation, device authorization, satellite license, service availability, interference result or consumer benefit followed from publication of the proposal.

## SIGNIFICANCE

The proposal could extend satellite connectivity to billions of existing unlicensed devices and reshape access and spectrum use without requiring dedicated satellite hardware. Its practical reach depends on final technical, licensing and interference safeguards that remain open.

## GOALPOST / RESPONSE

The FCC says the approach could unlock connectivity and innovation while protecting incumbents through non-interference rules and technical controls. A final rule, adopted allocations, licensing terms, certified equipment, interference data, service launches, coverage, prices and user outcomes are the tests.

## MAYBE / THEREFORE

Maybe existing unlicensed radios can safely reach satellites and expand connectivity at low incremental cost, or power, interference and international constraints may sharply limit usable services. Therefore the record establishes a formal FCC proposal—not an operative spectrum allocation, authorized consumer service or demonstrated connectivity gain.


## SOURCES

- [Federal Register — Unleashing Unlicensed Spectrum for Direct-to-Device](https://www.federalregister.gov/documents/2026/09/08/2026-18282/unleashing-unlicensed-spectrum-for-direct-to-device) — primary proposed rule, FCC 26-51 and ET Docket No. 26-169, adopted August 6 and published September 8

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
