# Commerce revokes lawn-mower trade-duty orders after no domestic response

**Entry ID:** NAT-2026-08-31-015
**Date:** August 31–September 8, 2026
**Checked:** 2026-09-08 12:01 AM EDT
**Evidence state:** primary Commerce final sunset-review notice in the Federal Register; revocation, statutory basis, product scope and customs treatment documented, market effects unmeasured
**Review state:** current-standard-reviewed

The antidumping and countervailing-duty orders on specified Chinese and Vietnamese mowers are revoked, with covered entries from July 13 onward released from those requirements.

## THE FACTS

- The Commerce Department dated a final sunset-review determination August 31 and made it applicable September 8, revoking antidumping and countervailing-duty orders on specified walk-behind lawn mowers from China and an antidumping order on specified mowers from Vietnam.
- Commerce began the first five-year sunset reviews June 1. AxenTech expressed an intent to participate, then withdrew; no domestic interested party filed the required substantive response by July 1.
- The Tariff Act directs Commerce to revoke an order within 90 days when no domestic interested party responds. The agency said it would instruct Customs and Border Protection to end suspension of liquidation for covered merchandise entered or withdrawn from warehouse on or after July 13, 2026.
- Entries before July 13 remain subject to the prior suspension and cash-deposit requirements and may still be reviewed. The covered scope generally concerns specified internal-combustion walk-behind mowers and parts, not every mower or small engine.
- The notice removes these product-specific trade remedies because the statutory participation condition was unmet; it does not find that dumping or subsidies ended, quantify import, consumer-price or domestic-production effects, or alter unrelated mower or engine orders.

## SIGNIFICANCE

The revocation is an implemented trade-policy change that removes product-specific duties and liquidation holds for covered imports. Its basis was the absence of a qualifying domestic response, so market effects and the underlying dumping or subsidy conditions were not adjudicated in this review.

## GOALPOST / RESPONSE

Commerce presents revocation as the mandatory statutory result of a sunset review with no domestic substantive response. Customs instructions, liquidation and deposits, import volumes, prices, domestic production and employment, and any new trade petitions are the tests.

## MAYBE / THEREFORE

Maybe the absence of domestic participation indicates the orders no longer warrant the cost of continuation, or procedural nonparticipation may say little about current dumping, subsidies or industry vulnerability. Therefore the record establishes revocation for covered post-July 12 entries—not a merits finding that unfair trade ceased or a demonstrated consumer or producer outcome.


## SOURCES

- [Federal Register — Revocation of lawn-mower antidumping and countervailing-duty orders](https://www.federalregister.gov/documents/2026/09/08/2026-18249/certain-walk-behind-lawn-mowers-and-parts-thereof-from-the-peoples-republic-of-china-and-the) — primary final sunset-review notice dated August 31 and applicable September 8

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
