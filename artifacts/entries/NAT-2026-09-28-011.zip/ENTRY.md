# State Department launches Western Hemisphere visa-restriction policy and acts against 27 people

**Entry ID:** NAT-2026-09-28-011
**Date:** September 28, 2026
**Checked:** 2026-09-29 5:58 AM EDT
**Evidence state:** Associated Press reporting quoting the State Department announcement and a named response; policy and first restrictions reported as implemented, individualized evidence and outcomes unverified
**Review state:** current-standard-reviewed

The department announced a regional policy and imposed or prospectively denied visas; its corruption and narcotrafficking assertions are allegations, not adjudicated findings.

## THE FACTS

- The State Department announced on September 28 a new Western Hemisphere visa-restriction policy under Immigration and Nationality Act section 212(a)(3)(C), aimed at current and former foreign officials and family members whom the department alleges undermined democratically elected governments through corruption or narcotrafficking.
- Associated Press reported that the department used the policy immediately against 27 officials, former officials and relatives from Bolivia, Colombia, Ecuador and Peru. The action revoked existing visas for some people and makes others ineligible if they apply; the complete person-by-person status was not public in the inspected material.
- The named targets included Bolivian Attorney General Roger Mariaca. Mariaca called the action political pressure, denied the accusations and defended his record; the department's allegations were not treated as criminal convictions or independently proved conduct.
- Visa restrictions affect entry eligibility, not removal from office, a criminal judgment or a demonstrated anti-corruption outcome. No court ruling or independently measured policy effect existed by cutoff.

## SIGNIFICANCE

The policy creates a regional visa tool and the first reported batch of restrictions under it, extending U.S. leverage over public officials and relatives across four countries while leaving the asserted misconduct and policy effects unresolved.

## GOALPOST / RESPONSE

The administration says the restrictions support democratic governance and the Shield of the Americas initiative by excluding people it alleges enable corruption or narcotrafficking. The complete designations, stated evidence, later additions or removals, litigation, reciprocal action and measured governance effects are the tests.

## MAYBE / THEREFORE

Maybe targeted visa restrictions deter corrupt or anti-democratic conduct, or opaque designations may function as diplomatic pressure without public proof or due process. Therefore the verified action is the announced policy and reported visa restrictions—not adjudication of the department's allegations or proof of improved governance.


## SOURCES

- [AP — U.S. imposes visa restrictions under new Western Hemisphere policy](https://apnews.com/article/7815734706d2e758d14e11ccd8dbd8f3) — independent reporting quoting the State Department announcement and named responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
