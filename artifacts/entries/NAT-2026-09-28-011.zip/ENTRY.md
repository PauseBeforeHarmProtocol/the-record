# State Department expands Western Hemisphere visa restrictions to another 61 officials

**Entry ID:** NAT-2026-09-28-011
**Date:** September 28–October 22, 2026
**Checked:** 2026-10-23 12:00 AM EDT
**Evidence state:** Associated Press reporting quoting the Secretary of State and describing implemented visa restrictions; affected categories and totals reported, individualized evidence and outcomes unverified
**Review state:** current-standard-reviewed

After launching the regional policy and acting against 27 people, the department announced restrictions affecting 40 Bolivians and 21 Colombians; the underlying corruption and narcotrafficking assertions remain allegations.

## THE FACTS

- The State Department announced on September 28 a new Western Hemisphere visa-restriction policy under Immigration and Nationality Act section 212(a)(3)(C), aimed at current and former foreign officials and family members whom the department alleges undermined democratically elected governments through corruption or narcotrafficking.
- Associated Press reported that the department used the policy immediately against 27 officials, former officials and relatives from Bolivia, Colombia, Ecuador and Peru. The action revoked existing visas for some people and makes others ineligible if they apply; the complete person-by-person status was not public in the inspected material.
- The named targets included Bolivian Attorney General Roger Mariaca. Mariaca called the action political pressure, denied the accusations and defended his record; the department's allegations were not treated as criminal convictions or independently proved conduct.
- Visa restrictions affect entry eligibility, not removal from office, a criminal judgment or a demonstrated anti-corruption outcome. No court ruling or independently measured policy effect existed by cutoff.
- On October 22, Secretary of State Marco Rubio announced travel restrictions affecting 61 current and former officials, judges and lawmakers from Bolivia and Colombia, along with covered family members, under the department's Western Hemisphere policy.
- Associated Press reported that the action covered 40 Bolivians, including sitting lawmakers, a former attorney general and judicial and police officials, and 21 Colombians, including a current mayor and former lawmakers. The restrictions revoke current visas where applicable and deny future applications; the inspected report did not publish a complete person-by-person list or individualized evidence.
- Rubio said the targets undermined democratic governments through corruption or narcotrafficking regardless of political affiliation. That statement records the department's rationale; visa restrictions are administrative entry measures, not criminal convictions or adjudicated findings.

## SIGNIFICANCE

The second reported batch expands the policy from 27 people across four countries to 61 additional Bolivian and Colombian officials and relatives, demonstrating continuing use of visa authority while the evidence for individual designations and any deterrent effect remain largely nonpublic.

## GOALPOST / RESPONSE

The administration says the restrictions support democratic governance and regional counternarcotics cooperation. The tests remain complete designations, individualized evidence where law permits disclosure, later additions or removals, reciprocal action and measured governance or trafficking effects.

## MAYBE / THEREFORE

Maybe a broader set of visa restrictions creates meaningful leverage against corruption and narcotrafficking, or opaque designations may function mainly as diplomatic pressure. Therefore the verified development is another implemented restriction batch—not adjudication of the allegations or proof of policy effectiveness.


## SOURCES

- [AP — U.S. imposes visa restrictions under new Western Hemisphere policy](https://apnews.com/article/7815734706d2e758d14e11ccd8dbd8f3) — independent reporting quoting the State Department announcement and named responses
- [Associated Press live report — State Department fellowship restoration and visa restrictions](https://apnews.com/article/7f7b10c7974ed379a11f4c5421f0e62e) — independent reporting quoting State Department and Secretary of State announcements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
