# DOJ sues Lyft over alleged disability-access denials

**Entry ID:** NAT-2026-11-09-002
**Date:** November 9, 2026
**Checked:** 2026-11-10 6:10 AM EST
**Evidence state:** primary DOJ release and retrieved civil complaint plus Reuters and Lyft response; allegations filed, liability and remedies unresolved
**Review state:** current-standard-reviewed

The complaint seeks $53 million for eligible complainants and injunctive relief over alleged ride denials, fees and policy failures; Lyft disputes the allegations and no liability finding had issued.

## THE FACTS

- On November 9, the Justice Department filed United States v. Lyft Inc. in the U.S. District Court for the Northern District of California under Title III of the Americans with Disabilities Act. Filing the civil complaint opens a case; it does not establish liability.
- The complaint alleges Lyft and drivers routinely denied rides to people using service animals or stowable wheelchairs, charged cancellation and other fees after denials, and failed to make reasonable policy modifications, including front-seat access where needed. These are government allegations that must be tested in court.
- DOJ seeks $53 million for people with disabilities who submitted complaints to Lyft or DOJ, an order requiring policy changes and training, and a civil penalty. The requested amount and remedies are not a judgment, settlement, payment or verified class-wide harm finding.
- Reuters reported Lyft disputed DOJ’s allegations, said its policies require drivers to accommodate riders with disabilities and service animals, said violators face permanent deactivation, and said it had cooperated with the department. Compliance and the extent of any violations remain contested.

## SIGNIFICANCE

The federal government is using ADA enforcement against a national rideshare platform and seeking substantial individualized compensation plus operational changes. The case could affect transportation access and platform controls, but consequences depend on evidence, rulings, settlement terms and implementation.

## GOALPOST / RESPONSE

DOJ says people with disabilities must receive equal rideshare access and alleges systemic denials and fees. Lyft says its policies already require accommodation and penalize violators. The tests are the answer, complaint-level evidence, court findings, any settlement or judgment, verified policy changes, enforcement data and rider outcomes.

## MAYBE / THEREFORE

Maybe litigation produces stronger platform controls and compensation for documented discrimination, or Lyft may defeat or narrow the government’s claims. Therefore the record establishes a filed federal ADA complaint and requested relief—not liability, a $53 million award, payment or proof that every complaint was valid.


## SOURCES

- [DOJ — lawsuit alleging Lyft disability discrimination](https://www.justice.gov/opa/pr/justice-department-sues-lyft-denying-rides-passengers-service-dogs-wheelchairs) — primary agency litigation announcement
- [United States v. Lyft Inc. complaint](https://www.justice.gov/crt/media/1423901/dl) — primary civil complaint; full retrieved PDF SHA-256 7a2c3119d329cf0f6a3b14cd23d7991b6c4ef855b836eeed7840b9aafcc15073
- [Reuters — United States sues Lyft over disability-access allegations](https://www.reuters.com/legal/government/us-sues-lyft-alleges-it-denied-rides-passengers-with-service-dogs-wheelchairs-2026-11-09/) — independent reporting including Lyft response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
