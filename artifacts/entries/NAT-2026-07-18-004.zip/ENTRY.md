# Senate defeats House-passed Iran war-powers resolution as conflict continues

**Entry ID:** NAT-2026-07-18-004
**Date:** July 10–November 19, 2026
**Checked:** 2026-11-19 6:07 PM EST
**Evidence state:** presidential-notice reporting, official congressional instrument and Senate vote record, plus independent reporting on the vote and administration response
**Review state:** current-standard-reviewed

The Senate rejected H.Con.Res. 93 by 48–51, leaving the resumed conflict and the administration's disputed War Powers clock theory unchanged.

## THE FACTS

- President Trump sent Congress a letter dated July 10 stating that hostilities against Iran resumed on July 7. The administration treated the renewed action as opening a new 60-day period for military operations without specific congressional authorization.
- The War Powers Resolution generally requires notice within 48 hours and termination of unauthorized hostilities within 60 days. Members of both parties disputed the reset theory, and the House later passed H.Con.Res. 93 directing removal of U.S. forces from hostilities with Iran unless Congress declared war or enacted specific authorization.
- On November 19 the Senate rejected the House-passed concurrent resolution 48–51. The official Senate vote record shows Republicans Susan Collins, Lisa Murkowski and Rand Paul voting for it, Democrat John Fetterman voting against it and Senator Chris Murphy not voting.
- The rejection did not enact a new authorization for use of military force or end the conflict. Reuters reported it was the twenty-first Iran war-powers vote since the war began and that the fighting continued; a prior concurrent resolution had been treated by the administration as nonbinding.
- Trump said the United States was in no rush to make its next decision and would assess what happens after January 1. That statement describes current posture, not a ceasefire, withdrawal order or congressional authorization.

## SIGNIFICANCE

The Senate vote closes the immediate legislative route opened by the House resolution while leaving the underlying constitutional dispute unresolved. It also demonstrates that continued hostilities lack majority support for withdrawal in both chambers, not that Congress affirmatively authorized the war.

## GOALPOST / RESPONSE

The administration says renewed strikes respond to Iranian attacks on commercial shipping and fall within the president's national-security and foreign-policy responsibilities. The concrete tests remain a specific authorization, enacted funding limits, a binding withdrawal measure, a judicial ruling, an implemented ceasefire or verified termination of U.S. hostilities.

## MAYBE / THEREFORE

Maybe senators rejected the resolution because they accept the administration's view of the renewed conflict, or because a concurrent resolution would not bind the president and they preferred other tools. Therefore the Senate defeated the House-passed withdrawal direction; it did not enact an Iran AUMF, settle the War Powers clock, end the fighting or validate every administration legal claim.


## SOURCES

- [Reuters — formal notice that Iran hostilities resumed](https://www.reuters.com/world/us/trump-sends-congress-formal-notice-that-iran-conflict-has-resumed-2026-07-13/) — independent reporting on presidential notice
- [GovInfo — H.Con.Res. 93 as received in the Senate](https://www.govinfo.gov/app/details/BILLS-119hconres93rfs) — primary congressional instrument
- [Senate Periodical Press — Senate rejects H.Con.Res. 93](https://www.periodicalpress.senate.gov/thursday-november-19-2026/) — primary congressional vote record
- [Reuters — Senate rejects resolution curbing Trump Iran war powers](https://www.reuters.com/world/us-senate-rejects-resolution-curbing-trumps-iran-war-powers-2026-11-19/) — independent reporting on congressional vote and conflict status
- [Reuters — Trump says no rush on next Iran decision](https://www.reuters.com/world/trump-says-us-will-see-what-happens-conflict-with-iran-after-january-1-2026-11-19/) — independent reporting on administration response and current posture

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
