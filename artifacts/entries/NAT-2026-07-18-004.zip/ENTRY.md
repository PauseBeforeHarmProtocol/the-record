# Administration tells Congress that Iran hostilities resumed July 7

**Entry ID:** NAT-2026-07-18-004
**Date:** July 10–13, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** independent reporting on the presidential notice and statutory context
**Review state:** current-standard-reviewed

The president’s notice treats renewed strikes as the start of a new 60-day War Powers clock.

## THE FACTS

- President Trump sent Congress a letter dated July 10 stating that hostilities against Iran resumed on July 7.
- The administration views the renewed action as opening a new 60-day period for military operations without specific congressional authorization.
- The War Powers Resolution requires notice within 48 hours and generally requires unauthorized hostilities to end within 60 days. Members of both parties have disputed the administration’s interpretation, and Congress previously passed a resolution directing withdrawal from the conflict.

## SIGNIFICANCE

The notice is not merely procedural. It asserts that an executive branch can terminate and restart the statutory clock around ceasefires and renewed operations, potentially allowing an extended conflict without a new authorization for use of military force.

## GOALPOST / RESPONSE

The administration says renewed strikes respond to Iranian attacks on commercial shipping and are consistent with the president’s responsibility to protect U.S. security and foreign-policy interests. Critics argue that a ceasefire cannot be used to erase months of hostilities or reset Congress’s statutory deadline. The constitutional dispute remains live.

## MAYBE / THEREFORE

Maybe, as the administration argues, Iranian attacks on commercial shipping and renewed U.S. strikes formed a new episode of hostilities rather than a continuation of the prior conflict. Therefore the July 10 letter records the executive’s reset theory, not a settled War Powers result; Congress or a court could authoritatively resolve the dispute, while independent statutory analysis can assess the theory without being mislabeled as a binding determination.


## SOURCES

- [Reuters — formal notice that Iran hostilities resumed](https://www.reuters.com/world/us/trump-sends-congress-formal-notice-that-iran-conflict-has-resumed-2026-07-13/) — independent reporting on presidential notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
