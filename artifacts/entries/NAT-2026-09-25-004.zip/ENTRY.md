# ATF finalizes Safe Explosives Act rules and removes carrier verification steps

**Entry ID:** NAT-2026-09-25-004
**Date:** September 25, 2026
**Checked:** 2026-09-25 11:59 AM EDT
**Evidence state:** primary Federal Register final rule; published September 25 and effective October 26, 2026, with modeled savings and prospective traceability effects
**Review state:** current-standard-reviewed

The final rule closes two 2003 interim proceedings, retains background-check and licensing rules, and ends specified delivery-verification requirements on October 26.

## THE FACTS

- ATF published a final rule effective October 26 that finalizes two interim rules issued in 2003 to implement the Safe Explosives Act, which expanded federal licensing, permitting, prohibited-person and background-check requirements.
- The rule adopts most of the long-operative provisions while clarifying how licensees and permittees report changes in responsible persons and employees authorized to possess explosives.
- ATF removes requirements that common or contract carriers verify and record the identity of the person accepting delivery and rescinds ATF Ruling 2003-5's alternative telephone-confirmation process. Distributors must still verify carrier drivers and retain transaction records, and direct deliveries remain subject to identity checks.
- ATF estimates the removed telephone-verification process will save the industry about 264,498 hours and $12.2 million annually. Those are modeled estimates based on assumed transaction and call patterns, not measured savings.

## SIGNIFICANCE

The rule converts decades-old interim explosives controls into final regulations while making a discrete deregulatory change to third-party delivery verification and reporting.

## GOALPOST / RESPONSE

ATF says the retained licensing and background-check provisions protect public safety and that removing carrier-delivery verification creates savings with only de minimis traceability effects. Delivery records, diversion investigations, compliance findings and measured time and cost savings are the tests.

## MAYBE / THEREFORE

Maybe existing distributor and transaction records preserve traceability while eliminating rarely followed calls, or the removed acceptance check may leave gaps in some deliveries. Therefore the rule finalizes existing controls and removes named procedures; it does not establish the predicted savings or safety effect.


## SOURCES

- [Implementing the Safe Explosives Act](https://www.govinfo.gov/content/pkg/FR-2026-09-25/pdf/2026-19693.pdf) — primary final rule; 91 FR 61074; effective October 26, 2026

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
