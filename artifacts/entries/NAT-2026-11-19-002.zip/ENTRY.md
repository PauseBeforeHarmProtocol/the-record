# Treasury sanctions Comancheros and 'Ndrangheta networks under drug-trafficking authority

**Entry ID:** NAT-2026-11-19-002
**Date:** November 19, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** official Treasury and OFAC notices plus independent Australian reporting; sanctions implemented and wind-down license issued, with downstream disruption and outcomes unmeasured
**Review state:** current-standard-reviewed

OFAC designated the two transnational organizations and additional leaders, facilitators and businesses, while issuing a limited wind-down license through December 18.

## THE FACTS

- OFAC designated the Australia-headquartered Comanchero Outlaw Motorcycle Gang and Italy-based 'Ndrangheta under Executive Order 14059 for drug-trafficking activity or support. The 'Ndrangheta had previously been designated under the Foreign Narcotics Kingpin Designation Act.
- The action also designated Comancheros leaders or facilitators Alexandre Varela Villar, Allan John Norman Meehan, Pasilika Naufahu, Vetekina Naufahu and Marco Francis Coffen, and targeted Toronto-area 'Ndrangheta leaders and facilitators including Angelo and Cosimo Figliomeni, Francesco and Rocco Remo Commisso, Vincenzo DeMaria and Luigi Vescio Sr., plus an associated corporate network.
- Treasury says the organizations support cartel narcotics trafficking and money laundering across multiple regions. Independent Australian reporting described Australian agencies' support for the U.S. investigation; the designations are Treasury determinations, not criminal convictions of every named target.
- The designations block covered property and generally prohibit U.S.-linked transactions. OFAC also issued Illicit Drugs General License 1 authorizing ordinarily necessary wind-down transactions involving listed November 19 targets through 12:01 a.m. EST on December 18, 2026, subject to its conditions.

## SIGNIFICANCE

The network-level action applies U.S. financial restrictions to organizations connecting cartel supply chains with logistics, laundering and overseas distribution. The time-limited wind-down license and absence of measured enforcement outcomes mean legal designation is distinct from dismantlement or reduced drug flows.

## GOALPOST / RESPONSE

Treasury says the action will expose and disrupt networks that help cartels move drugs and launder proceeds. The tests are blocked assets and transactions, compliance and enforcement activity, international prosecutions or seizures, network adaptation, drug-flow measures and any license extension or delisting.

## MAYBE / THEREFORE

Maybe coordinated designations will materially constrain cross-border logistics and finance, or the networks may substitute intermediaries outside U.S. jurisdiction. Therefore OFAC imposed immediate restrictions with a bounded wind-down period—not proof that either organization was dismantled or narcotics supply declined.


## SOURCES

- [Treasury Sanctions Major Drug Trafficking Organizations Supporting Terrorist Cartels](https://home.treasury.gov/news/press-releases/sb0696) — primary OFAC sanctions release identifying the organizations, leaders, facilitators, corporate network and legal authority
- [Counter Narcotics Designations; Cyber-related Designations; Issuance of General Licenses](https://ofac.treasury.gov/recent-actions/20261119) — primary OFAC recent-action notice listing designations and the time-limited wind-down license
- [Comanchero hit with US sanctions over links to Mexican drug cartels](https://www.theaustralian.com.au/nation/comanchero-hit-with-us-sanctions-over-links-to-mexican-drug-cartels/news-story/95886ccaf052e17d7f9d340f5d9e3896) — independent Australian reporting on the U.S. designation and Australian investigative support

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
