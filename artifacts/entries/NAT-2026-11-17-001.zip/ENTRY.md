# Labor Department formally proposes first broad PERM overhaul in two decades

**Entry ID:** NAT-2026-11-17-001
**Date:** November 17, 2026
**Checked:** 2026-11-17 6:31 AM EST
**Evidence state:** complete primary Federal Register proposed rule plus independent Reuters reporting; formally proposed and open for comment, not final, effective or implemented
**Review state:** current-standard-reviewed

The Federal Register proposal would expand U.S.-worker recruitment and layoff safeguards, end Schedule A processing exemptions and strengthen enforcement; comments close January 19, 2027.

## THE FACTS

- The Labor Department published a proposed rule titled Modernizing the Labor Market Test and Improving Protections for U.S. Workers in the PERM Immigrant Visa Program, docket ETA-2026-0133 and RIN 1205-AC29, in the November 17 Federal Register. Comments are due January 19, 2027; the proposal has no effective date and changes no current certification by itself.
- The proposal would end the Schedule A administrative exemption for professional nurses, physical therapists and people of exceptional ability in sciences or arts, requiring those occupations to use the general PERM labor-market test. DOL says the exemptions no longer reflect current labor-market conditions and seeks comment on transition issues.
- DOL proposes broader and more modern recruitment, a two-year layoff safeguard for the same or related occupations, continuing consideration of laid-off U.S. workers, and restrictions affecting third-party placement and staffing arrangements. It also proposes expanded notices, records, electronic processing, audits and enforcement tools.
- DOL describes the rule as the first comprehensive PERM modernization in about 20 years and says stronger recruitment and verification would better protect U.S. workers and program integrity. Reuters independently reported the proposed legal-immigration restrictions and their relationship to October company-specific PERM suspensions.
- The proposal does not prove that particular employers displaced U.S. workers, does not itself deny any pending application and does not establish final costs, processing times or worker outcomes. Those depend on comments, any final text, transition rules, implementation and litigation.

## SIGNIFICANCE

If finalized, the proposal would change how employers across health care, technology and other sectors demonstrate the absence of available U.S. workers before employment-based permanent residence. Its reach is national, while the actual legal and labor-market effects remain unresolved.

## GOALPOST / RESPONSE

DOL’s worker-protection and integrity rationale should be tested against the final rule, transition treatment, recruitment and certification data, processing times, audit and denial reasons, laid-off-worker hiring, employer and hospital staffing effects, costs and court review. Federal Register publication opens the proposal stage; it does not implement the restrictions.

## MAYBE / THEREFORE

Maybe broader recruitment and layoff safeguards will reveal qualified U.S. workers and reduce abuse, or ending shortage-occupation exemptions and adding process may worsen health-care and skilled-worker bottlenecks without improving placement. Therefore DOL has formally proposed a nationwide PERM overhaul for comment—not finalized it, implemented it or demonstrated its effects.


## SOURCES

- [Federal Register — PERM modernization proposed rule, 91 FR 73916](https://www.govinfo.gov/content/pkg/FR-2026-11-17/pdf/2026-23370.pdf) — primary proposed rule, document 2026-23370
- [Reuters — Labor Department proposes PERM overhaul](https://www.reuters.com/legal/litigation/trump-administration-targets-further-limits-skilled-foreign-workers-2026-11-16/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
