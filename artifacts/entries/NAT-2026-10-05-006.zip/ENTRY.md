# EEOC asks court to uphold secrecy over law-firm DEI inquiry records

**Entry ID:** NAT-2026-10-05-006
**Date:** October 5, 2026
**Checked:** 2026-10-06 12:04 PM EDT
**Evidence state:** original filed EEOC/DOJ memorandum and independent Reuters court reporting; summary judgment and withholdings defended, judicial determination pending in inspected material
**Review state:** current-standard-reviewed

An October 5 summary-judgment filing defends confidentiality and other FOIA exemptions; the inspected document is an argument, not a ruling.

## THE FACTS

- On October 5, government lawyers filed Document 20 in Public Citizen v. EEOC, Civil Action 25-4457 (BAH), also addressing the related Maizel FOIA action in the District of Columbia. The memorandum asks the court to grant summary judgment to the EEOC over searches and withheld records related to its law-firm DEI inquiries.
- The requests seek law-firm correspondence, settlement agreements or related records. The EEOC argues that Title VII and FOIA Exemption 3 protect disclosure of whether a particular employer faced a discrimination charge, and that confirming the absence of charges for some firms could identify other firms by elimination.
- The filing says the agency’s earlier public announcement of agreements with four firms did not disclose negotiated terms or whether an agreement resolved a charge. It defends withholdings on that basis and invokes additional FOIA exemptions; these are agency legal arguments, not findings that every withholding is lawful.
- Reuters independently reported the filing on October 6. The inspected primary document establishes the government’s litigation position, not a court order approving secrecy, an independently proven discrimination violation by a firm or a final outcome of the FOIA cases.

## SIGNIFICANCE

The filing asks a court to sustain limits on public scrutiny of a consequential federal inquiry into major law firms. It makes the administration’s disclosure position reviewable while leaving both exemption legality and underlying enforcement outcomes to further evidence.

## GOALPOST / RESPONSE

The strongest agency explanation is that statutory confidentiality protects employers against disclosure of unadjudicated charges and protects the integrity of enforcement and settlement discussions. The court’s exemption-by-exemption analysis, segregability decisions and any ordered release are the tests; the government’s assertion is not the court’s conclusion.

## MAYBE / THEREFORE

Maybe confidentiality is necessary to enforce antidiscrimination law fairly, or excessive withholding may obscure how the inquiry was conducted. Therefore the record establishes a filed request to uphold searches and withholdings, with statutory reasoning stated; it does not establish judicial approval or discrimination findings.


## SOURCES

- [EEOC — Public Citizen / Maizel FOIA summary-judgment memorandum, Document 20](https://fingfx.thomsonreuters.com/gfx/legaldocs/xmpjwbrzevr/Public%20Citizen%20v%20EEOC%20-%2020261005.pdf) — primary filed government memorandum; Reuters-hosted docket copy
- [Reuters — Government seeks to keep law-firm DEI probe records secret](https://www.reuters.com/legal/government/us-seeks-keep-law-firm-dei-probe-records-secret-2026-10-06/) — independent court reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
