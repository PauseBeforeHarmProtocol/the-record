# Trump creates commission to design a proposed U.S. Space Academy

**Entry ID:** NAT-2026-08-28-005
**Date:** August 28, 2026
**Checked:** 2026-08-28 6:08 PM EDT
**Evidence state:** signed White House order, NASA agency confirmation, and independent Reuters reporting; commission established, academy itself proposed and contingent on later decisions
**Review state:** current-standard-reviewed

The signed order starts a 120-day planning process; Congress, appropriations, location, accreditation, and implementation remain unresolved.

## THE FACTS

- Trump signed an order establishing the Presidential Commission on the United States Space Academy, chaired by the NASA administrator and including White House, defense, budget, Air Force, and national-security officials.
- The order describes the academy as a proposed NASA-led federal institution combining technical education, leadership development, discipline, and public-service commitments for military, civil, scientific, and commercial space work.
- The commission must report within 120 days on governance, curriculum, graduate service obligations, admissions, accreditation, location, pilot programs, legislation, funding, and implementation. The order says implementation follows presidential approval, any necessary legislation, and available appropriations.
- NASA and Reuters confirmed the signing. Reuters reported that no location, operating structure, construction plan, or congressional funding had been secured at the checked time, and noted existing Space Force staffing shortages.

## SIGNIFICANCE

The order makes a new federal space academy an organized executive proposal rather than a campaign idea, but it creates a commission—not an operating school. Whether it becomes a durable institution depends on the report, Congress, appropriations, existing service-academy relationships, and NASA's statutory role.

## GOALPOST / RESPONSE

The administration says a larger military, civil, and commercial space enterprise needs a dedicated pipeline of technically trained public-service leaders. Supporters can point to workforce demand and strategic competition; the unanswered questions concern cost, duplication, governance, civilian-military balance, admissions, and whether Congress authorizes the academy. The 120-day report, budget request, legislation, site selection, accreditation, and first admitted class are the tests.

## MAYBE / THEREFORE

Maybe a dedicated academy can fill genuine space-workforce gaps and complement existing institutions, or the commission may recommend a smaller partnership model instead of a new campus. Therefore the record reports a signed planning order and commission—not an established, funded, accredited, staffed, or enrolling academy.


## SOURCES

- [White House — order establishing the Presidential Commission on the United States Space Academy](https://www.whitehouse.gov/presidential-actions/2026/08/establishing-the-united-states-space-academy/) — primary signed presidential order creating a commission and requiring a 120-day report
- [NASA — Space Academy commission announcement](https://www.nasa.gov/news-release/president-trump-signs-executive-order-to-create-us-space-academy/) — primary agency confirmation of the order, commission leadership, and report deadline
- [Reuters — Trump signs order to create a U.S. Space Academy](https://www.reuters.com/business/aerospace-defense/trump-will-sign-order-create-us-space-academy-2026-08-28/) — independent reporting on the signed order, unresolved funding, location, and staffing questions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
