# HUD allocates $255.5 million in fiscal 2026 Housing Trust Fund money

**Entry ID:** NAT-2026-09-04-005
**Date:** September 4, 2026
**Checked:** 2026-09-04 6:02 AM EDT
**Evidence state:** primary HUD allocation notice and agency program overview; allocations announced, expenditure and housing outcomes not established
**Review state:** current-standard-reviewed

The formula notice distributes Fannie Mae and Freddie Mac assessment revenue among states, the District of Columbia and territories; allocations are not completed projects or audited housing outcomes.

## THE FACTS

- HUD published fiscal year 2026 Housing Trust Fund formula allocations totaling $255,516,650.92 for the 50 states, District of Columbia, Puerto Rico and U.S. territories.
- The Housing Trust Fund is financed from a statutory portion of annual assessments on Fannie Mae and Freddie Mac and supports housing for extremely low- and very low-income households. The notice itemizes each jurisdiction's share.
- HUD stated that the Virgin Islands allocation remains subject to an existing suspension and that release would require specified corrective steps. The notice does not say that every allocation has been drawn, obligated to a project or spent.
- The allocation establishes available formula amounts; it does not establish how many homes will be produced or preserved, when projects will finish, who will receive them or what compliance and affordability outcomes will follow.

## SIGNIFICANCE

The national allocation is a concrete federal housing-resource decision for households facing the deepest affordability constraints. Its practical value depends on state plans, project selection, leveraging, construction costs, timing and long-term compliance.

## GOALPOST / RESPONSE

HUD's program purpose is to expand and preserve affordable housing for extremely low- and very low-income households. Approved allocation plans, commitments, draws, project starts and completions, units produced or preserved, tenant incomes, geographic distribution, affordability periods, audit findings and the Virgin Islands suspension are the tests.

## MAYBE / THEREFORE

Maybe predictable formula funding will unlock additional affordable units and preservation investment, or high costs and slow local pipelines may limit its reach. Therefore the record establishes $255.5 million in announced fiscal-year allocations—not universal disbursement, completed housing or measured relief from the affordability shortage.


## SOURCES

- [HUD — fiscal year 2026 Housing Trust Fund allocation notice](https://www.federalregister.gov/documents/2026/09/04/2026-18163/housing-trust-fund-fiscal-year-2026-allocation-notice) — primary allocation notice itemizing $255.5 million among states, the District of Columbia and territories
- [HUD Exchange — Housing Trust Fund program overview](https://www.hudexchange.info/programs/htf/about/) — primary program context on eligible beneficiaries and activities

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
