# OECD publishes revised global-minimum-tax return implementing the U.S. side-by-side framework

**Entry ID:** NAT-2026-09-11-012
**Date:** September 11, 2026
**Checked:** 2026-09-12 12:01 AM EDT
**Evidence state:** primary Treasury release and OECD return; reporting instrument published, country adoption and measured effects unresolved
**Review state:** current-standard-reviewed

The new form lets U.S.-headed groups elect a safe harbor and narrows reporting, but it does not itself enact foreign tax law or establish measured tax and compliance effects.

## THE FACTS

- On September 11, the OECD/G20 Inclusive Framework published a revised 115-page GloBE Information Return for fiscal years beginning on or after December 31, 2025. The document says it incorporates the side-by-side package released in January 2026 and was approved and declassified on September 2.
- The revised return adds a field through which a multinational group can elect the side-by-side safe harbor. Treasury says the election exempts qualifying U.S.-headed groups from the Pillar Two Income Inclusion Rule and Undertaxed Profits Rule while leaving them subject to U.S. global-minimum-tax rules.
- The form removes specified reporting for groups electing the safe harbor and provides a standardized mechanism for local minimum taxes. Treasury says information reported solely for a jurisdiction's local minimum tax is to be disseminated only to that jurisdiction.
- The OECD return is an international reporting instrument, not a U.S. appropriation or a self-executing change to every country's tax code. Treasury acknowledged that participating countries must continue adopting the safe harbor through their normal domestic legislative processes.
- Treasury described the revision as reducing overlapping tax and compliance burdens and protecting incentives including the U.S. research-and-development credit. No independently measured change in company taxes, reporting hours, investment, federal revenue or foreign implementation was published by cutoff.

## SIGNIFICANCE

The return operationalizes a negotiated exemption central to the administration's rejection of the prior global-tax approach, potentially changing multinational reporting and which minimum-tax regime applies. The practical fiscal and investment consequences still depend on domestic adoption, elections and enforcement.

## GOALPOST / RESPONSE

Treasury says the framework protects U.S. tax sovereignty, prevents overlapping taxes and lowers compliance costs. Other governments retain their own legislative processes. Election rates, enacted domestic rules, reported compliance costs, tax collections, disputes and investment behavior are the tests.

## MAYBE / THEREFORE

Maybe the standardized safe-harbor election prevents duplicate taxation and unnecessary reporting without undermining other countries' local minimum taxes, or uneven adoption may create new complexity and shift revenue. Therefore the revised return is a completed reporting instrument for covered fiscal years—not proof of universal domestic enactment, a particular company's eligibility or measured tax, revenue and investment results.


## SOURCES

- [Treasury — revised GloBE Information Return and side-by-side framework](https://home.treasury.gov/news/press-releases/sb0628/) — primary agency release
- [OECD — GloBE Information Return, September 2026](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/09/tax-challenges-arising-from-the-digitalisation-of-the-economy-globe-information-return-september-2026_16d0f09e/0f9da895-en.pdf) — primary international tax instrument

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
