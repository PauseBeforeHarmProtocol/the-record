# Justice Department files third criminal case against James Comey

**Entry ID:** NAT-2026-10-26-002
**Date:** October 26, 2026
**Checked:** 2026-10-26 6:02 PM EDT
**Evidence state:** primary unsealed criminal information independently corroborated by Reuters and Associated Press; two federal charges filed, allegations unadjudicated and dismissal request pending
**Review state:** current-standard-reviewed

Prosecutors used a criminal information rather than a grand-jury indictment to allege that Comey transmitted national-defense information to a reporter in 2016.

## THE FACTS

- A criminal information filed under seal on October 5 and unsealed October 26 in the U.S. District Court for the District of Columbia charges former FBI Director James Comey with conspiring to transmit and transmitting national-defense information. The charging document is an allegation, not evidence of guilt or an adjudicated finding.
- Count One alleges that in October 2016 Comey and co-conspirators used a middleman to direct national-defense information to a reporter whose recipients were not authorized to receive it. Count Two alleges that Comey participated in, aided and abetted, and willfully caused the transmission. The information does not publicly identify the specific material, reporter, middleman or co-conspirators.
- U.S. Attorney Jeanine Ferris Pirro and Assistant U.S. Attorney Bill Miller signed the information. Reuters and Associated Press described the filing as the administration's third criminal case against Comey and reported that prosecutors used the unusual criminal-information procedure rather than seeking a grand-jury indictment.
- Comey said he remains innocent, and his lawyers asked the court to dismiss the case as legally invalid. Those are defense positions, not rulings; no plea, merits decision, trial result or sentence existed by cutoff.
- This filing is a distinct prosecution stage from the earlier 2025 case that was dismissed and the April 2026 seashell-threat case tracked in the legacy archive. It is cross-linked rather than treated as proof of the earlier allegations or as a final resolution of any Comey prosecution.

## SIGNIFICANCE

The filing opens a third criminal prosecution of a former FBI director and uses a charging route that bypasses a grand-jury indictment. That procedure and the national-defense allegations create immediate tests of prosecutorial authority, charging sufficiency and political independence, but the accusations remain unproved.

## GOALPOST / RESPONSE

The Justice Department alleges Comey deliberately caused protected national-defense information to reach an unauthorized reporter. Comey denies wrongdoing and challenges the information's legal validity. The tests are arraignment and plea, the motion to dismiss, disclosure of the alleged information and participants, judicial treatment of the charging procedure, trial evidence and any appellate review.

## MAYBE / THEREFORE

Maybe prosecutors possess evidence that Comey knowingly transmitted protected information, or the unusual procedure and sparse public allegations may fail legal or evidentiary scrutiny. Therefore the supported conclusion is only that DOJ filed and unsealed a two-count criminal information—not that Comey committed the offenses or that the case will survive dismissal.


## SOURCES

- [United States v. Comey — criminal information](https://storage.courtlistener.com/recap/gov.uscourts.dcd.297298/gov.uscourts.dcd.297298.1.0.pdf) — primary unsealed two-count criminal information; allegations are unadjudicated
- [Reuters — Justice Department files third criminal case against James Comey](https://www.reuters.com/world/ex-fbi-director-comey-charged-again-by-us-justice-department-nbc-news-reports-2026-10-26/) — independent reporting on the criminal information, defense response and prosecution history
- [Associated Press — administration attempts third prosecution of James Comey](https://apnews.com/article/comey-trump-fbi-director-prosecution-8479bdbf1bcdeeae313b453a3cd0c544) — independent reporting on the unsealed filing, criminal-information procedure and defense challenge

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
