# Comey prosecution remains unresolved after judge defers dismissal ruling

**Entry ID:** NAT-2026-10-26-002
**Date:** October 26–30, 2026
**Checked:** 2026-10-30 6:11 PM EDT
**Evidence state:** primary unsealed criminal information independently corroborated by Reuters and Associated Press; two federal charges filed, allegations unadjudicated and dismissal request pending; independent AP and ABC October 30 hearing reports; new transcript and underlying evidence not inspected
**Review state:** current-standard-reviewed

McFadden deferred a decision while DOJ pursues an indictment; the charging procedure, limitations period and allegations remain disputed.

## THE FACTS

- A criminal information filed under seal on October 5 and unsealed October 26 in the U.S. District Court for the District of Columbia charges former FBI Director James Comey with conspiring to transmit and transmitting national-defense information. The charging document is an allegation, not evidence of guilt or an adjudicated finding.
- Count One alleges that in October 2016 Comey and co-conspirators used a middleman to direct national-defense information to a reporter whose recipients were not authorized to receive it. Count Two alleges that Comey participated in, aided and abetted, and willfully caused the transmission. The information does not publicly identify the specific material, reporter, middleman or co-conspirators.
- U.S. Attorney Jeanine Ferris Pirro and Assistant U.S. Attorney Bill Miller signed the information. Reuters and Associated Press described the filing as the administration's third criminal case against Comey and reported that prosecutors used the unusual criminal-information procedure rather than seeking a grand-jury indictment.
- Comey said he remains innocent, and his lawyers asked the court to dismiss the case as legally invalid. Those are defense positions, not rulings; no plea, merits decision, trial result or sentence existed by cutoff.
- This filing is a distinct prosecution stage from the earlier 2025 case that was dismissed and the April 2026 seashell-threat case tracked in the legacy archive. It is cross-linked rather than treated as proof of the earlier allegations or as a final resolution of any Comey prosecution.
- On October 30, Judge Trevor McFadden deferred an immediate ruling on Comey’s dismissal motion while prosecutors said they were presenting evidence to a grand jury. AP and ABC independently reported the hearing. Defense lawyers argued that the waiverless criminal information could not preserve a prosecution after the ten-year limitations period; DOJ disputed that position. No new indictment, dismissal or final validation of the procedure was established in the material inspected.
- Prosecutor Dustin Farahnak said the investigation could involve later conduct; this is a litigation assertion, not a new proved offense. When McFadden raised concern about an arrest before indictment, Farahnak assured the court that would not happen. Neither that assurance nor the deferred ruling establishes guilt, a granted immunity, a new arrest order or a final ruling on the time limit. The hearing transcript and newly discussed evidence were not retrieved.

## SIGNIFICANCE

The deferral leaves a consequential prosecution and unusual charging route unresolved while preserving judicial scrutiny. A grand-jury presentation is not a grand-jury vote, and a prosecutor’s account is not independent proof of classified disclosures.

## GOALPOST / RESPONSE

DOJ argues the information preserved time to seek an indictment and later conduct could support timely charges. Comey’s lawyers say that procedure is invalid and leaves him unfairly under threat. The judge has not resolved that dispute; an actual indictment, dismissal ruling and disclosed evidence are the tests.

## MAYBE / THEREFORE

Maybe a grand jury will approve timely, legally sufficient charges, or the information and limitations theory may fail. Therefore the supported development is a deferred dismissal decision and continuing prosecution effort—not an indictment, conviction, approved limitations extension or exoneration.


## SOURCES

- [United States v. Comey — criminal information](https://storage.courtlistener.com/recap/gov.uscourts.dcd.297298/gov.uscourts.dcd.297298.1.0.pdf) — primary unsealed two-count criminal information; allegations are unadjudicated
- [Reuters — Justice Department files third criminal case against James Comey](https://www.reuters.com/world/ex-fbi-director-comey-charged-again-by-us-justice-department-nbc-news-reports-2026-10-26/) — independent reporting on the criminal information, defense response and prosecution history
- [Associated Press — administration attempts third prosecution of James Comey](https://apnews.com/article/comey-trump-fbi-director-prosecution-8479bdbf1bcdeeae313b453a3cd0c544) — independent reporting on the unsealed filing, criminal-information procedure and defense challenge
- [AP — Judge puts off Comey dismissal decision](https://www.click2houston.com/news/politics/2026/10/30/judge-puts-off-decision-in-comey-case-as-justice-department-seeks-new-indictment-against-ex-fbi-head/) — independent courtroom reporting; full updated syndication inspected
- [ABC — Judge warns against pre-indictment Comey raid](https://abcnews.com/US/attorneys-james-comey-return-court-fight-dojs-efforts/story?id=137706147) — independent courtroom reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
