# DEA temporarily places four synthetic opioids in Schedule I

**Entry ID:** NAT-2026-08-27-001
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 AM EDT
**Evidence state:** published DEA temporary scheduling order effective August 27, 2026; legal status implemented for two years, permanent scheduling and measured public-health effects pending
**Review state:** current-standard-reviewed

The two-year order immediately applies Schedule I controls to four orphine compounds after DEA reported 265 forensic encounters and detection of one compound in 49 fatalities.

## THE FACTS

- The Drug Enforcement Administration temporarily placed 5,6-dichloro brorphine, 5,6-dichloro desmethylchlorphine, N-propionitrile chlorphine (cychlorphine), and spirochlorphine in Schedule I effective August 27, 2026. The order lasts through August 27, 2028, with a possible one-year extension while permanent scheduling proceeds.
- The order immediately applies Schedule I registration, security, labeling, inventory, recordkeeping, import-export, quota, and criminal-control requirements. DEA says the four compounds have no currently accepted U.S. medical use and that temporary placement is necessary to avoid an imminent hazard to public safety.
- DEA reported 265 forensic encounters across 21 states: 225 involved N-propionitrile chlorphine, 36 spirochlorphine, and two each of the other compounds. DEA's toxicology program detected N-propionitrile chlorphine in 49 fatalities, often alongside other drugs; detection does not by itself establish that the compound was the sole cause of death. The order cites one published nonfatal overdose involving a mixture of that compound, fentanyl, and xylazine.

## SIGNIFICANCE

The temporary order creates immediate nationwide criminal and regulatory consequences for possession and handling outside authorized channels. It also moves faster than ordinary permanent rulemaking and can affect forensic testing, medical research, and the illicit opioid market before long-term outcome evidence exists.

## GOALPOST / RESPONSE

DEA says receptor data, forensic encounters, online availability, overdose evidence, and the absence of accepted medical use establish an imminent hazard. The strongest countervailing question is whether a temporary Schedule I order reduces supply and deaths without unnecessarily impeding research when many detections involve polysubstance mixtures. Permanent-scheduling evidence, seizure trends, toxicology attribution, overdose rates, research registrations, and market substitution are the tests.

## MAYBE / THEREFORE

Maybe rapid control will disrupt an emerging class before it becomes more widespread, or suppliers may substitute other uncontrolled compounds while researchers face added barriers. Therefore the record reports DEA's legal finding and detection data without treating every co-detected fatality as caused by these compounds or the temporary order as proof of effectiveness.


## SOURCES

- [Federal Register — temporary Schedule I order for four synthetic opioids](https://www.federalregister.gov/documents/2026/08/27/2026-17531/schedules-of-controlled-substances-temporary-placement-of-56-dichloro-brorphine-56-dichloro) — primary temporary scheduling order, legal effect, toxicology detections, and agency rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
