# HUD raises upfront Section 184 Native housing loan-guarantee fees

**Entry ID:** NAT-2026-09-28-003
**Date:** September 25–28, 2026
**Checked:** 2026-09-28 12:30 AM EDT
**Evidence state:** primary HUD notice, 91 FR 61245–61246; publicly filed September 25 and published September 28; effective for new firm commitments October 1
**Review state:** current-standard-reviewed

New firm commitments from October 1 face a 1.5% standard fee; the Skilled Workers demonstration fee becomes 1%, while annual fees stay zero.

## THE FACTS

- HUD's notice, filed September 25 and published September 28, raises the upfront Section 184 loan-guarantee fee from 1.00% to 1.50% for new firm commitments issued on or after October 1, including refinances.
- The upfront fee for new Section 184 Skilled Workers Demonstration Program firm commitments rises from zero to 1.00% on the same date. Annual guarantee fees remain zero; loans already guaranteed are excluded from these increases.
- HUD says the program's strong performance and approximately 3.5% lifetime default rate allow a fee increase to support operation without annual appropriations. That is the agency's stated financing rationale, not independently verified proof that future fees will cover costs or that housing access will be unchanged.

## SIGNIFICANCE

The notice shifts prospective Native housing finance costs toward new borrowers while preserving existing guaranteed loans. It changes a federal financing term rather than reporting a measured change in homeownership.

## GOALPOST / RESPONSE

HUD argues the increase can sustain long-term homeownership opportunities without annual appropriations. Higher upfront charges may affect affordability and participation. Actual guarantee costs, fee receipts, loan volumes and borrower outcomes will test that rationale.

## MAYBE / THEREFORE

Maybe additional fee revenue will sustain the program, or higher upfront costs may reduce access for some eligible borrowers. Therefore the record verifies the scheduled fee changes and exemptions while leaving fiscal sustainability and housing effects unmeasured.


## SOURCES

- [HUD raises upfront Section 184 Native housing loan-guarantee fees](https://www.govinfo.gov/content/pkg/FR-2026-09-28/pdf/2026-19782.pdf) — primary HUD notice, 91 FR 61245–61246; publicly filed September 25 and published September 28; effective for new firm commitments October 1

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
