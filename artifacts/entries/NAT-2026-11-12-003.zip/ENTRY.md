# MSHA proposes changing silica sampling, citations and miner medical surveillance

**Entry ID:** NAT-2026-11-12-003
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:13 AM EST
**Evidence state:** published MSHA proposal and official public-inspection PDF, independent occupational-health reporting and named congressional response; proposal only, with health and cost effects unresolved
**Review state:** current-standard-reviewed

The proposal keeps the 50-microgram exposure limit but changes how compliance is sampled and enforced and narrows parts of medical surveillance; comments run through January 11.

## THE FACTS

- MSHA published a proposed rule on November 12 revising its 2024 respirable-crystalline-silica rule. It retains the permissible exposure limit of 50 micrograms per cubic meter and action level of 25, but it is not final; a hearing is scheduled for December 15 and comments close January 11, 2027.
- The proposal would apply a 21% analytical-error factor when evaluating samples and generally base citations on MSHA samples rather than mine-operator samples. It would replace fixed periodic sampling language with sampling as frequently as necessary under the agency's risk-based approach.
- For medical surveillance, the proposal would make initial examinations voluntary for new metal and nonmetal miners while requiring examinations for miners whom MSHA sampled above the exposure limit; it would also remove a NIOSH chest-X-ray reporting provision. The agency estimates about $28.7 million in annualized cost savings at a 7% discount rate.
- The administration says targeted sampling and mandatory examinations for miners with demonstrated overexposure preserve protection while reducing unnecessary burden. Independent reporting and named senators argue that less routine sampling and narrower surveillance may miss exposure and black-lung disease. The savings, detection and health effects are projections and disputed risks, not measured outcomes.

## SIGNIFICANCE

Silica exposure can cause irreversible lung disease, so the proposed changes affect both how violations are detected and which miners receive mandatory screening. Keeping the numeric limit does not by itself resolve whether the revised sampling and surveillance system is equally protective.

## GOALPOST / RESPONSE

MSHA says the proposal targets resources to demonstrated risk without weakening the exposure limit. Critics say prevention requires regular operator sampling and broad early surveillance. The final rule, sampling frequency, citation rates, examinations, disease detection, compliance costs, miner exposure data and court review are the tests.

## MAYBE / THEREFORE

Maybe risk-based sampling and focused examinations will maintain protection at lower cost, or reduced routine monitoring may delay detection of dangerous exposure and disease. Therefore the archive records a proposed revision—not a lowered numerical exposure limit, completed deregulation, realized savings or measured change in black-lung incidence.


## SOURCES

- [MSHA — respirable crystalline silica and respiratory protection proposed rule](https://www.federalregister.gov/documents/2026/11/12/2026-23048/respirable-crystalline-silica-and-respiratory-protection) — primary proposed rule; exposure sampling, enforcement and medical-surveillance changes
- [Federal Register public-inspection PDF — MSHA silica proposal](https://public-inspection.federalregister.gov/2026-23048.pdf) — official proposed-rule PDF and regulatory analysis
- [FRONTLINE — proposed changes to federal mining silica rule](https://www.pbs.org/wgbh/frontline/article/federal-regulators-mining-safety-black-lung-silica-rule/) — independent reporting on sampling, medical surveillance and black-lung context
- [Safety+Health — MSHA updated silica proposal](https://www.safetyandhealthmagazine.com/msha-set-to-publish-updated-proposed-rule-on-silica/) — independent occupational-safety specialist summary
- [Senators Warner, Kaine and Fetterman — response to silica proposal](https://www.warner.senate.gov/newsroom/press-releases/warner-kaine-fetterman-condemn-trump-vance-administrations-proposed-weakening-of-silica-rule-that-protects-coal-miners-from-black-lung/) — named congressional response criticizing proposed worker-protection changes

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
