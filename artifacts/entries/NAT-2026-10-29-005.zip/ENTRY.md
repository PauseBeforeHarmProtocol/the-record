# FCC votes to restrict non-reciprocal-country device testing after 2028 transition

**Entry ID:** NAT-2026-10-29-005
**Date:** October 29, 2026
**Checked:** 2026-10-29 6:05 PM EDT
**Evidence state:** Reuters full article plus primary Federal Register agenda; adopted action reported, final adopted FCC text and release access denied, future transition not completed implementation
**Review state:** current-standard-reviewed

Reported adopted vote expands the lab restrictions; it does not immediately prohibit all Chinese testing.

## THE FACTS

- Reuters reported that the FCC voted October 29 to bar device-testing laboratories and certification bodies in China and other countries denying reciprocal treatment to U.S. laboratories, with restrictions slated for December 2028. The published Federal Register meeting agenda, Item 4 in ET Docket 24-136, independently documents the proposed reciprocal-economy framework and a December 1, 2028 transition endpoint; the final adopted text was not retrieved.
- Carr said foreign laboratories’ pre-market product access creates security and intellectual-property risks and that only about 4% of testing occurred in U.S. labs versus 82% in China in 2025. These are attributed agency figures and rationale. Reuters reported no immediate Chinese Embassy response. The vote is not evidence of completed testing relocation or measured security improvement.

## SIGNIFICANCE

The adopted vote signals a substantial future market-access change. Transition capacity, final rule text and enforcement matter; current testing is not represented as already terminated.

## GOALPOST / RESPONSE

Carr frames the rule as security, oversight and reciprocity protection. The final instrument, transition implementation and independently measured supply-chain and security effects remain the tests.

## MAYBE / THEREFORE

Maybe shifting certification reduces vulnerabilities, or capacity and compliance costs offset benefits. Therefore the vote and reported future transition are established, but immediate cessation, completed reshoring and net benefits are not.


## SOURCES

- [Federal Register — FCC October 29 meeting notice, Item 4](https://www.govinfo.gov/content/pkg/FR-2026-10-29/pdf/2026-22080.pdf) — primary agenda, Item 4 inspected; prospective text is not proof of the subsequently adopted instrument
- [Reuters — FCC votes on reciprocal-country device testing restriction](https://www.streetinsider.com/Reuters/FCC%2Bvotes%2Bto%2Bban%2Ball%2BChinese%2Blabs%2Bfrom%2Btesting%2BUS%2Belectronics/27255524.html) — independent reporting of adopted vote and December 2028 transition; full article inspected on StreetInsider; final FCC text access denied

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
