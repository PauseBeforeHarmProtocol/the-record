# Judge rejects EPA bid to terminate xAI Clean Air Act citizen suit

**Entry ID:** NAT-2026-10-19-009
**Date:** October 19, 2026
**Checked:** 2026-10-20 11:57 AM EDT
**Evidence state:** district-court opinion and order plus independent Reuters reporting; intervention granted, dismissal request denied, underlying Clean Air Act allegations and other motions unresolved
**Review state:** current-standard-reviewed

The district court let the United States intervene but held that neither the Clean Air Act nor Rule 41 permits it to dismiss the private case over the plaintiffs’ objection.

## THE FACTS

- A federal district judge allowed the United States, acting for the Environmental Protection Agency administrator, to intervene in the NAACP citizen suit against X.AI Corp. and MZX Tech LLC but denied the government’s request to dismiss the case.
- The suit alleges that the companies constructed and operated a gas-fired power plant serving the Colossus data center in Southaven, Mississippi, without required permits. The October 19 order did not decide those allegations, the defendants’ pending dismissal motion or the plaintiffs’ requested preliminary injunction.
- The court held that Federal Rule of Civil Procedure 41 permits a plaintiff to dismiss its own action, not another plaintiff’s case, and that the Clean Air Act gives EPA a right to intervene but no unilateral power to terminate a citizen suit over the citizen plaintiffs’ objection.
- The United States may file a Rule 24(c) pleading by October 23 if it wants to participate. The administration argued that federal regulators have primacy over Clean Air Act enforcement; Reuters independently reported the ruling and that EPA, xAI and the NAACP did not immediately respond to requests for comment.

## SIGNIFICANCE

The ruling preserves a private Clean Air Act enforcement case and rejects the administration’s asserted power to end it after intervening. It is a procedural and statutory-authority decision, not a finding that xAI violated environmental law.

## GOALPOST / RESPONSE

The administration argued that federal enforcement primacy and executive authority permitted dismissal. Its Rule 24(c) pleading, any appeal, later rulings on dismissal or a preliminary injunction, permitting evidence and any final liability or remedy are the tests.

## MAYBE / THEREFORE

Maybe continued citizen-suit litigation provides accountability when regulators decline to enforce, or later merits and permitting evidence may show that the plaintiffs’ claims fail. Therefore the district court rejected the government’s unilateral-dismissal theory and kept the case alive—not that xAI has been found liable or that the ruling is final and nonappealable.


## SOURCES

- [Northern District of Mississippi — opinion and order on EPA intervention and dismissal request](https://fingfx.thomsonreuters.com/gfx/legaldocs/egvbgbxmypq/10313369319.pdf) — primary court order granting intervention and denying unilateral dismissal
- [Reuters — judge rejects administration bid to dismiss xAI Clean Air Act suit](https://www.reuters.com/legal/government/us-judge-rejects-trump-administration-bid-block-naacp-lawsuit-against-musks-xai-2026-10-20/) — independent reporting on the court ruling and party positions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
