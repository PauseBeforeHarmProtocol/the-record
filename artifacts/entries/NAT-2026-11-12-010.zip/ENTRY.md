# State Department accounting says U.S. handled $12.26 billion in Venezuelan resource revenue

**Entry ID:** NAT-2026-11-12-010
**Date:** November 12, 2026
**Checked:** 2026-11-13 6:02 AM EST
**Evidence state:** KPMG/State Department accounting described consistently by Reuters and Associated Press, with the governing White House order inspected directly; aggregate transactions reported, public report copy and transaction-level auditability incomplete
**Review state:** current-standard-reviewed

A KPMG report says nearly 99% of the U.S.-controlled custody account was disbursed by September 30, while redactions and incomplete transaction-level detail limit independent auditability.

## THE FACTS

- Reuters and Associated Press reported on November 12 that the State Department made public a KPMG accounting of the Venezuela Custody Account covering January 3 through September 30. The 53-page report was dated October 29 and transmitted to Congress in early November; a stable State Department copy was not independently retrieved by cutoff.
- The report said the account received $12.26 billion from Venezuelan natural-resource sales, more than $12.1 billion of it from oil, petroleum products and natural gas, with smaller amounts from gold, minerals and fertilizer.
- KPMG reported that $12.11 billion—nearly 99%—had been disbursed and that $168.6 million remained as of September 30. Most disbursements went through Venezuelan foreign-exchange auctions; about $133 million paid vendors directly for services or supplies requested for the interim government.
- The public report redacted the names of 20 oil and gold buyers. It described compliance screening and transaction controls but did not expose every depositor, recipient, exchange rate, rejected transaction or independently reproducible transaction-level ledger.
- Trump's January executive order says the funds remain sovereign property of Venezuela held by the United States in a custodial governmental capacity and permits transfers only as authorized for public, governmental or diplomatic purposes determined by the Secretary of State. The administration says the process supports essential services, macroeconomic stability and reconstruction while applying sanctions and anti-money-laundering controls.

## SIGNIFICANCE

This is the first substantial public accounting of a U.S.-controlled mechanism that handled revenue equal to a major share of Venezuela's public finances after the January intervention. The high disbursement rate supports the administration's custodial description, while U.S. approval authority, redacted counterparties and incomplete transaction detail leave major transparency and sovereignty questions unresolved.

## GOALPOST / RESPONSE

The administration says the custody system is working, returning Venezuelan sovereign funds for public services while reducing corruption and sanctions risk. The tests are publication of the full report and future updates, transaction-level deposits and disbursements with lawful redactions, named control failures and rejected transactions, independent audit access, Venezuelan public accounting, vendor conflicts, exchange-rate terms and measured service, inflation and reconstruction outcomes.

## MAYBE / THEREFORE

Maybe U.S. custody and compliance review protected Venezuelan revenue while quickly returning it for public needs, or concentrated approval power and redacted counterparties may conceal favoritism, leakage or policy leverage. Therefore the record establishes a reported $12.26 billion account and $12.11 billion in disbursements through September 30—not a complete public audit, proof that every payment was proper or proof of economic recovery.


## SOURCES

- [Safeguarding Venezuelan Oil Revenue for the Good of the American and Venezuelan People](https://www.whitehouse.gov/presidential-actions/2026/01/safeguarding-venezuelan-oil-revenue-for-the-good-of-the-american-and-venezuelan-people/) — executive order
- [US handled $12 billion of Venezuela's oil revenues, report says](https://www.reuters.com/business/energy/us-handled-12-billion-venezuelas-oil-revenues-report-says-2026-11-12/) — independent reporting
- [US returns over $12 billion in oil proceeds to Venezuela since Maduro's ouster, report says](https://apnews.com/article/6982bfdc5d64482e3500eea39891f0d1) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
