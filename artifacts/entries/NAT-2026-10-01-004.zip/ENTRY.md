# Treasury and IRS issue first rules for federal scholarship tax credit

**Entry ID:** NAT-2026-10-01-004
**Date:** October 1, 2026
**Checked:** 2026-10-01 6:00 PM EDT
**Evidence state:** Federal Register public-inspection texts, IRS announcement and independent reporting; temporary and proposed rules issued, later effectiveness and outcome evidence pending
**Review state:** current-standard-reviewed

Temporary and proposed regulations begin implementing the 2027 credit for donations to scholarship-granting organizations; most detailed rules remain subject to publication, delayed effectiveness or comment.

## THE FACTS

- Treasury and the IRS placed temporary regulations and a notice of proposed rulemaking for the Federal Scholarship Tax Credit on public inspection October 1, with publication scheduled for October 2. Section 25F, enacted in July 2025, creates a dollar-for-dollar nonrefundable federal credit of up to $1,700 for qualified individual contributions to certified scholarship-granting organizations beginning with 2027 tax years.
- The temporary regulations establish procedures and requirements for participating states and certified scholarship-granting organizations. The public-inspection text says the temporary rules become effective 60 days after Federal Register publication; their issuance does not mean every state has elected to participate or that scholarships were already disbursed.
- The proposed regulations address household-income calculations, eligibility verification, multistate organizations, state certification limits, interactions with state tax credits and carryforwards. The proposal estimates about 96 percent of children in participating states would be eligible under the proposed rules, but eligibility is not the same as receipt of a scholarship.
- Associated Press reported that the program is expected to launch January 1 and could support private-school tuition, homeschooling and other qualified elementary and secondary expenses. It also noted evidence from some state programs that universal eligibility has often benefited students already in private or home schooling and families in affluent areas.
- No national participation count, contribution total, scholarship amount distribution, budget effect or student outcome was measured by the cutoff. Proposed provisions may change after comments, and the temporary rules have a later effective date.

## SIGNIFICANCE

The regulatory package moves the first nationwide federal school-choice tax credit from statutory authorization toward administration and could redirect substantial tax expenditures through state-certified private organizations.

## GOALPOST / RESPONSE

The administration says the program expands family choice and that safe harbors can make it broadly accessible while limiting fraud. The strongest response is that broad eligibility may subsidize families already using private or home schooling and reduce public revenue without demonstrated educational gains. State elections, final rules, participation, distributional data, fiscal cost, audits and student outcomes are the tests.

## MAYBE / THEREFORE

Maybe the credit will expand educational options for lower-income families, or its design may primarily subsidize existing private choices and create uneven access across participating states. Therefore the record establishes issued temporary rules and a formal proposal for 2027—not nationwide participation, paid scholarships or measured student outcomes.


## SOURCES

- [IRS — federal scholarship tax-credit regulatory package](https://www.irs.gov/newsroom/the-trump-administration-advances-the-establishment-of-americas-first-nationwide-school-choice-program) — primary agency announcement summarizing temporary and proposed regulations
- [Federal Register public inspection — Federal Scholarship Tax Credit temporary regulations, TD 10057](https://public-inspection.federalregister.gov/2026-20264.pdf) — primary temporary regulations scheduled for October 2 publication
- [Federal Register public inspection — Federal Scholarship Tax Credit proposed regulations, REG-117199-25](https://public-inspection.federalregister.gov/2026-20277.pdf) — primary notice of proposed rulemaking and public hearing scheduled for October 2 publication
- [Associated Press — federal scholarship tax-credit rules and school-choice program](https://apnews.com/article/federal-scholarship-tax-credit-rules-a015961865d469f2a0839d235a9f4056) — independent reporting on regulatory status, eligibility and policy response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
