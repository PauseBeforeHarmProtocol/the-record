# White House orders approval before agency personnel agree to testify to Congress

**Entry ID:** NAT-2026-11-16-005
**Date:** November 16, 2026
**Checked:** 2026-11-16 6:00 PM EST
**Evidence state:** Axios obtained the memorandum and Associated Press independently confirmed and summarized it; internal approval ordered, compliance with future voluntary requests or subpoenas not yet tested
**Review state:** current-standard-reviewed

A one-page White House Counsel memorandum requires both legal and legislative-affairs approval before executive-branch personnel agree to appear before a congressional committee; its treatment of compulsory process remains untested.

## THE FACTS

- White House Counsel William O. Scharf sent a November 16 memorandum to general counsels of executive departments and agencies directing them to obtain approval from both the White House Office of Legislative Affairs and the Office of White House Counsel before any agency personnel may agree to appear before any congressional committee.
- The one-page directive describes prior notification and approval as an established White House consultation process and says further guidance about other engagements with Congress is forthcoming. It addresses personnel agreeing to appear; the inspected reporting does not establish how the administration will treat a duly issued subpoena, informal staff contact or document demand.
- Axios first reported the memorandum and quoted a White House official saying the administration is ready to engage with Congress and that the process will respect reasonable requests while rejecting what the official called politically motivated, baseless investigations. Associated Press independently confirmed the memorandum and its approval requirement.
- The directive centralizes decisions before agency testimony, but no inspected evidence showed an agency appearance canceled, a committee request denied or a subpoena litigated under the new process by the research cutoff. Its legal and practical effects therefore remain prospective.

## SIGNIFICANCE

Congress relies on agency witnesses to evaluate administration programs, spending and compliance. Requiring two White House offices to approve every agreed appearance gives the presidential staff a new documented control point over that evidence, while the extent of any actual obstruction cannot be inferred before requests are processed.

## GOALPOST / RESPONSE

The administration says centralized consultation will respect legitimate oversight while protecting agencies from politically motivated demands. That claim can be tested through approval times, voluntary appearances, accommodations, refusals, subpoena compliance, privilege assertions, litigation and whether Congress receives timely agency evidence.

## MAYBE / THEREFORE

Maybe a uniform clearance process will coordinate accurate testimony and reduce duplicative demands, or it may delay or constrain congressional access to agency personnel. Therefore the memorandum establishes a mandatory internal approval gate before personnel agree to testify—not a demonstrated refusal to honor compulsory process or proof that congressional oversight has already been blocked.


## SOURCES

- [Axios — White House requires signoff before agency staffers testify to Congress](https://www.axios.com/2026/11/16/exclusive-white-house-requires-signoff-before-agency-staffers-testify-to-congress) — independent reporting based on the one-page White House Counsel memorandum, with named administration response
- [Associated Press — White House approval requirement for administration testimony](https://apnews.com/article/a31165456bf217de16f1c4e646b72bd2) — independent confirmation and summary of the White House Counsel memorandum

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
