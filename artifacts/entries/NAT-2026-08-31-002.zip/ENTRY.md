# NHTSA narrows heavy-vehicle fuel-economy enforcement authority

**Entry ID:** NAT-2026-08-31-002
**Date:** August 31, 2026
**Checked:** 2026-08-31 5:58 AM EDT
**Evidence state:** published NHTSA interpretive rule with applicability date, enforcement statement and explicit limitations, plus Reuters background on the broader heavy-truck rollback and competing projected effects; enforcement interpretation active, replacement standards and outcomes pending
**Review state:** current-standard-reviewed

An immediately applicable interpretation says NHTSA cannot set standalone engine standards and will enforce existing heavy-vehicle rules consistently with that view while a separate rulemaking proceeds.

## THE FACTS

- The National Highway Traffic Safety Administration published an interpretive rule applicable August 31, 2026, stating that its Energy Independence and Security Act authority reaches commercial medium- and heavy-duty vehicles and work trucks as vehicles but not their engines on a standalone basis.
- NHTSA said it will review existing medium- and heavy-duty fuel-economy standards in a separate rulemaking. Pending that process, the agency will exercise enforcement authority over affected standards consistently with the new interpretation.
- The notice does not itself repeal a numerical vehicle standard or establish replacement fuel-economy levels. NHTSA also says the interpretation is not a final agency action under the Administrative Procedure Act and defers cost, benefit and environmental analysis to the future rulemaking.
- The agency argues that the statutory text repeatedly authorizes standards for vehicles rather than component parts and that manufacturers should retain flexibility in meeting vehicle-level requirements. Earlier Reuters reporting on the administration's heavy-truck rollback proposal described industry support for relief as well as projected increases in fuel use, fuel costs and emissions from lower future standards; those projections concern the broader rollback, not measured effects of this interpretive notice alone.

## SIGNIFICANCE

The interpretation changes the agency's present enforcement posture and lays a legal foundation for narrowing a fuel-economy program that has regulated engines as well as complete heavy vehicles. Its concrete economic and environmental consequences remain contingent on the promised standards rulemaking and any court review.

## GOALPOST / RESPONSE

NHTSA says Congress authorized vehicle standards, not separate engine standards, and that the interpretation restores statutory limits and manufacturer flexibility. Supporters of the prior approach argue integrated engine and vehicle rules reduce fuel spending and emissions. The separate rule's proposed numbers, enforcement notices, manufacturer compliance plans, judicial review, fuel consumption, vehicle prices and emissions are the tests.

## MAYBE / THEREFORE

Maybe the interpretation will chiefly reallocate compliance choices within vehicle-level standards without materially reducing efficiency, or it may enable a substantial rollback once NHTSA rewrites the program. Therefore the record documents an immediately applicable legal and enforcement interpretation—not a completed repeal of every heavy-vehicle standard or a measured change in fuel use, prices or emissions.


## SOURCES

- [Federal Register — NHTSA heavy-vehicle fuel-economy interpretation](https://www.federalregister.gov/documents/2026/08/31/2026-17756/resetting-nhtsas-fuel-economy-program-commercial-medium--and-heavy-duty-on-highway-vehicles-and-work) — primary interpretive rule describing immediate applicability, enforcement posture and limits pending separate rulemaking
- [Reuters — administration proposes unwinding heavy-truck fuel-economy rules](https://www.reuters.com/business/autos-transportation/us-propose-unwinding-biden-era-heavy-truck-fuel-economy-rules-2026-01-30/) — independent background on the broader standards rollback, industry response and projected fuel, cost and emissions effects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
