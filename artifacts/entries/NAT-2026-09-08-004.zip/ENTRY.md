# DOE closes loan of up to $1.9 billion for Duane Arnold nuclear restart

**Entry ID:** NAT-2026-09-08-004
**Date:** September 8, 2026
**Checked:** 2026-09-08 11:58 AM EDT
**Evidence state:** primary Department of Energy financing announcement plus independent Reuters reporting; financial close, maximum loan amount, capacity and licensing dependency documented, while disbursement, restart and outcomes remain pending
**Review state:** current-standard-reviewed

The financing is closed, but the 615-megawatt Iowa reactor still requires NRC approvals and is not scheduled to return before 2029.

## THE FACTS

- The Department of Energy's Office of Energy Dominance Financing announced the financial close of a loan of up to $1.9 billion to NextEra Energy to help finance restarting the Duane Arnold Energy Center in Linn County, Iowa.
- The 615-megawatt reactor ceased operations in 2020. DOE expressly states that restart remains pending required Nuclear Regulatory Commission licensing approvals; Reuters reported that NextEra targets an early-2029 return.
- DOE projects that the plant could supply power equivalent to nearly 500,000 homes, create nearly 1,500 construction jobs and support more than 450 operating jobs. Those are administration projections, not completed employment, generation, reliability or price outcomes.
- Reuters reported that Google has a 25-year agreement to buy power from the proposed restart. The agreement and federal loan support a concrete project, but neither proves that licensing, construction and startup will finish on schedule.
- A loan ceiling is not the same as the amount already disbursed or ultimately repaid. The inspected announcement did not provide a disbursement schedule, final project cost, completed NRC approvals or evidence that the plant is producing power.

## SIGNIFICANCE

The financial close commits federal lending capacity to a rare effort to revive a retired U.S. nuclear plant and could add material firm generation if licensing and construction succeed. The scale of public financing makes disbursement, repayment, licensing, cost and performance accountability consequential.

## GOALPOST / RESPONSE

DOE says the restart will advance nuclear leadership, improve reliability, lower electricity costs and support jobs. Actual disbursements, NRC milestones, construction cost and schedule, 2029 startup, capacity and outages, employment, power-delivery terms, electricity prices and loan repayment are the tests.

## MAYBE / THEREFORE

Maybe federal financing and a long-term buyer make a technically viable restart more likely, or licensing, construction and market risks may delay the project or shift costs without delivering the projected benefits. Therefore the record establishes a closed loan of up to $1.9 billion for a restart project—not a fully disbursed sum, licensed restart, operating reactor or demonstrated reliability, price or jobs result.


## SOURCES

- [Department of Energy — $1.9 billion Duane Arnold restart loan closing](https://www.energy.gov/articles/energy-department-closes-19-billion-loan-restart-duane-arnold-nuclear-plant) — primary financing announcement documenting financial close, maximum principal, project capacity, projections and pending NRC approval
- [Reuters — NextEra secures up to $1.9 billion U.S. loan for Duane Arnold restart](https://www.reuters.com/business/energy/nextera-secures-up-19-billion-us-loan-restart-duane-arnold-nuclear-center-2026-09-08/) — independent reporting on the loan closing, proposed 2029 restart, NRC dependency and Google power-purchase agreement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
