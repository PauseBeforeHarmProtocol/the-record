# Trump continues the Executive Order 13224 terrorism emergency for another year

**Entry ID:** NAT-2026-09-11-015
**Date:** September 11–16, 2026
**Checked:** 2026-09-16 5:59 AM EDT
**Evidence state:** primary presidential continuation notice published in the Federal Register; emergency authority continued, with no new target-specific action or effectiveness finding
**Review state:** current-standard-reviewed

The presidential notice extends the emergency beyond September 23, preserving sanctions authority without announcing a new designation, attack finding or operation.

## THE FACTS

- President Trump signed a September 11 notice, published in the Federal Register on September 16, continuing for one year beyond September 23, 2026 the national emergency first declared in Executive Order 13224 concerning persons who commit, threaten to commit or support terrorism.
- The continuation preserves the emergency framework, as amended, that supports blocking and sanctions actions under the International Emergency Economic Powers Act. It does not itself designate a new person or organization, freeze a newly identified asset or authorize a specific military operation.
- The notice says the covered acts and threats continue to pose an unusual and extraordinary threat to U.S. national security, foreign policy and the economy. That is the President's statutory determination; the notice does not publish new incident-level evidence or a quantitative effectiveness assessment.
- The notice transmits the continuation to Congress and directs Federal Register publication. Future designations, removals, licenses, enforcement actions, court rulings and the next annual review remain separate lifecycle events.

## SIGNIFICANCE

The annual continuation keeps a durable post-September 11 financial-sanctions architecture legally active. It preserves substantial executive power while adding no new target-specific evidence, making later use and oversight more informative than the renewal alone.

## GOALPOST / RESPONSE

The administration says the continuing terrorism threat warrants retaining the emergency. New designations and delistings, blocked-property and enforcement data, licenses, judicial review, congressional oversight and evidence of deterrence or unintended effects are the tests.

## MAYBE / THEREFORE

Maybe continued authority remains necessary to disrupt changing terrorist financing networks, or repeated annual renewal may preserve broad emergency power without demonstrating marginal effectiveness. Therefore the record establishes a one-year legal continuation—not a new terrorist plot, designation, asset freeze, military order or measured security result.


## SOURCES

- [Federal Register — continuation of the Executive Order 13224 terrorism national emergency](https://www.federalregister.gov/documents/2026/09/16/2026-19053/continuation-of-the-national-emergency-with-respect-to-persons-who-commit-threaten-to-commit-or) — primary presidential notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
