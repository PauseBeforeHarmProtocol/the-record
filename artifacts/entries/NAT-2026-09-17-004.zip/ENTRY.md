# State approves possible $24.3 billion Saudi F-35 package for review

**Entry ID:** NAT-2026-09-17-004
**Date:** September 17, 2026
**Checked:** 2026-09-18 12:00 AM EDT
**Evidence state:** primary State Department foreign-military-sale notice plus independent Reuters reporting; proposed and notified, not contracted or delivered
**Review state:** current-standard-reviewed

The notified package covers 48 aircraft and related support; it is not a completed contract, delivery or final congressional approval.

## THE FACTS

- The State Department approved a possible foreign military sale to Saudi Arabia valued at an estimated $24.3 billion and sent the package for congressional review.
- The notified package covers 48 F-35 Lightning II aircraft, 49 engines and associated equipment, training and support. The quantities and ceiling value describe a proposed package, not items delivered or a final price paid.
- Congress can review the notification before a sale advances. At cutoff no final contract, aircraft transfer, delivery schedule or completed congressional disposition was established.
- Reuters reported that Saudi Arabia welcomed the approval. The proposed transfer also raises the statutory and regional question of preserving Israel's qualitative military edge; no finding that the package had altered that balance was established.

## SIGNIFICANCE

The notification opens formal consideration of a major advanced-aircraft transfer and a potential long-term security relationship. Its military, fiscal and regional effects depend on congressional review, contracting, configuration, delivery and use.

## GOALPOST / RESPONSE

The State Department says the proposed sale would support U.S. foreign-policy and national-security objectives and improve a major partner's defense capacity. Tests include Congress's disposition, final terms, safeguards, delivery, interoperability and the legally required assessment of Israel's qualitative military edge.

## MAYBE / THEREFORE

Maybe the package strengthens deterrence and interoperability, or it could intensify regional arms competition and oversight concerns. Therefore the verified action is approval and notification of a possible sale—not a consummated $24.3 billion purchase or delivery of 48 aircraft.


## SOURCES

- [State Department — possible Saudi F-35 foreign military sale](https://www.state.gov/releases/bureau-of-political-military-affairs/2026/09/kingdom-of-saudi-arabia-f-35-lightning-ii-joint-strike-fighter-aircraft) — primary congressional-notification summary for a possible foreign military sale
- [Reuters — State Department approves possible $24.3 billion Saudi F-35 package](https://www.reuters.com/business/aerospace-defense/us-state-department-oks-possible-243-billion-military-aircraft-sale-saudi-arabia-2026-09-17/) — independent reporting on the notified possible sale and pending congressional review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
