# Tracker estimates up to $177 billion in federal grant disruptions across every state

**Entry ID:** NAT-2026-09-16-003
**Date:** September 16, 2026
**Checked:** 2026-09-16 12:01 PM EDT
**Evidence state:** Associated Press reporting on a public grant-level tracker and Grant Witness methodology; independently reported aggregate with explicit lifecycle and audit limitations
**Review state:** current-standard-reviewed

AP reported a grant-level tracker covering cancellations, freezes and delays; the aggregate is a changing exposure estimate, not an audited loss or proof that every listed dollar was permanently withheld.

## THE FACTS

- AP reported that the Lost Funds tracker developed by States United Democracy Center and Grant Witness identified up to $177 billion in federal grants canceled, frozen, delayed or otherwise disrupted since the start of Trump's second term, affecting all 50 states and the District of Columbia.
- The groups said health, nutrition, environmental and disaster-relief funding made up the largest categories. California, Texas, New York, Illinois and North Carolina had the highest dollar amounts of interrupted awards in the tracker.
- The project says it builds a grant-level record from USASpending.gov and other public, agency-specific, court and first-hand records, and that it updates classifications as administration actions and litigation change. AP reported the $177 billion as an upper-bound finding rather than an audited permanent-loss total.
- Some listed grants have been challenged in court and some funding actions have been reversed or delayed. The aggregate therefore combines distinct lifecycle states and does not establish that $177 billion was finally rescinded, spent elsewhere or unavailable at the same time.
- AP sought a White House response to the analysis but reported none by publication. The tracker organizations argue the scale exceeds routine transition changes; no comprehensive administration-wide rebuttal or alternative reconciled total was located by cutoff.

## SIGNIFICANCE

The dataset provides a nationwide, grant-level measure of the administration's funding disruptions and their policy concentration. Its breadth is useful for oversight, but the mixed lifecycle states and evolving litigation make the $177 billion an exposure estimate rather than a settled fiscal loss.

## GOALPOST / RESPONSE

The tracker organizations say their public records show unusually broad disruption; the administration has offered program-specific rationales for individual cuts but no reconciled nationwide response to this total. The tests are grant-level status changes, obligation and outlay records, court compliance, restored awards and an independently reproducible aggregate by lifecycle stage.

## MAYBE / THEREFORE

Maybe the tracker captures the practical scale of funding instability better than slower official summaries, or mixed statuses and later reversals may make the headline exceed permanent losses. Therefore the record establishes a documented upper-bound estimate affecting every state—not that every listed dollar was unlawfully withheld, permanently canceled or caused a measured service loss.


## SOURCES

- [Associated Press — analysis finds up to $177 billion in disrupted federal grants](https://apnews.com/article/trump-administration-federal-grants-cuts-edbdf9f49b1235bf38834417ef8dc130) — independent reporting on a reproducible grant-level analysis
- [Grant Witness — federal grant disruption data and methodology](https://grantwitness.org/) — primary project methodology and grant-level dataset description

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
