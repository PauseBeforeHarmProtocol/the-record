# U.S. and China announce AI incident channel and further crisis communications

**Entry ID:** NAT-2026-09-20-001
**Date:** September 20–26, 2026
**Checked:** 2026-09-26 11:57 AM EDT
**Evidence state:** Chinese Foreign Ministry primary readout plus AP reporting on both governments’ September 26 statements, alongside earlier named Treasury announcements; agreements announced, implementation and outcomes unverified
**Review state:** current-standard-reviewed

A Chinese primary readout and AP’s account of both governments’ statements confirm announced AI arrangements and trade continuity; operating protocols and the military memorandum remain pending.

## THE FACTS

- After the September 20 talks, Treasury Secretary Scott Bessent said the United States and China had agreed to establish a formal dialogue on artificial-intelligence safety and an 'incident line' for communication during significant AI events. This is a named U.S. official's account of agreement; no joint text or detailed Chinese public confirmation was available by cutoff.
- Bessent said senior officials would meet again in about two months in Shenzhen and described possible subjects including uncontrollable agents and cyber threats from non-state actors. A future meeting is scheduled diplomatic process, not evidence that a notification system is already operating.
- No published instrument defined an incident threshold, responsible agencies, confidentiality and data-sharing rules, response deadlines, enforcement mechanism or start date. The archive therefore records an attributed bilateral process agreement, not an implemented technical safeguard or tested crisis channel.
- Bessent later said the United States and China had reached a deal extending the trade truce from November 10 through January 10. China's embassy had no immediate comment, and no joint text or implementing tariff instrument was public by cutoff, so the archive records a named U.S. announcement rather than independently confirmed implementation.
- On September 26, China’s Foreign Ministry published a readout agreeing to an AI dialogue, a November exchange and a bilateral AI-incident channel. AP reported corresponding statements from both governments. This supplies Chinese confirmation absent at the earlier cutoff, but no operating protocol or demonstrated use of the channel was inspected.
- The Chinese readout endorsed the trade consultations and instructed implementation; AP reported a two-month truce extension. The readout said the militaries agreed to conclude a crisis-communication memorandum as soon as possible, not that one had already been signed. No implementing tariff instrument or completed military memorandum was retrieved in this review.

## SIGNIFICANCE

Bilateral confirmation strengthens the evidence for an agreed diplomatic process. An incident channel could reduce misunderstandings, while trade continuity could defer escalation; neither is a measured safety or economic outcome.

## GOALPOST / RESPONSE

The governments present continued dialogue, trade consultation and crisis communication as means to stabilize relations. Named implementing agencies, published protocols, the November exchange, tariff instruments and evidence of actual channel operation will test those aims. The U.S. readout was reported by AP but not directly retrieved.

## MAYBE / THEREFORE

Maybe these arrangements will become effective working mechanisms, or unresolved procedures and divergent interests may limit their use. Therefore the record now has bilateral announcement evidence, including an original Chinese readout; it does not establish operational AI safeguards, a signed military memorandum or verified tariff implementation.


## SOURCES

- [Reuters — U.S. proposes AI incident notification mechanism in China talks](https://www.reuters.com/business/finance/us-treasurys-bessent-chinas-he-launch-talks-ai-trade-critical-minerals-2026-09-20/) — independent reporting on completed bilateral talks and named-official proposals
- [Associated Press — U.S. proposes AI security notifications in China talks](https://apnews.com/article/bessent-ai-xi-trump-china-trade-2c7f54f07e755f506d9db9b91df282bd) — independent reporting on completed talks, AI proposal and trade process
- [Reuters — Bessent says U.S. and China agreed to AI dialogue and incident line](https://www.reuters.com/world/asia-pacific/us-china-meet-again-ai-safety-two-months-shenzhen-bessent-says-2026-09-21/) — independent reporting of a named U.S. official's account of the bilateral process agreement and planned Shenzhen meeting
- [Reuters — Bessent says U.S. and China agreed to extend trade truce](https://www.reuters.com/world/china/trump-plans-grand-spectacle-potentially-tense-xi-talks-2026-09-23/) — independent reporting of a named U.S. official's announcement of a trade-truce extension and the absence of immediate Chinese confirmation
- [China and the United States Reach Eight Deliverables and Understandings](https://www.fmprc.gov.cn/eng/xw/zyxw/202609/t20260926_12031663.html) — official readout
- [China and US agree AI safety channel and further trade and military talks](https://krmg.com/2026/09/26/china-and-the-us-agree-to-set-up-a-new-ai-safety-channel-and-to-keep-talking-on-trade-military/) — news report

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
