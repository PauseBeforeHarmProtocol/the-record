# U.S. and China publish trade-board framework alongside announced AI dialogue

**Entry ID:** NAT-2026-09-20-001
**Date:** September 20–27, 2026
**Checked:** 2026-09-27 11:57 PM EDT
**Evidence state:** White House September 27 working procedures and terms, published product-list links and USTR statement, alongside the prior Chinese primary readout and AP reporting; approved recommendations and procedures, not implemented tariff reductions
**Review state:** current-standard-reviewed

Published procedures and approved product lists specify the 30-for-30 process; future tariff reductions still require domestic implementation, and AI operating protocols remain unverified.

## THE FACTS

- After the September 20 talks, Treasury Secretary Scott Bessent said the United States and China had agreed to establish a formal dialogue on artificial-intelligence safety and an 'incident line' for communication during significant AI events. This is a named U.S. official's account of agreement; no joint text or detailed Chinese public confirmation was available at the September 20 announcement; the later Chinese readout is recorded below.
- Bessent said senior officials would meet again in about two months in Shenzhen and described possible subjects including uncontrollable agents and cyber threats from non-state actors. A future meeting is scheduled diplomatic process, not evidence that a notification system is already operating.
- No published instrument defined an incident threshold, responsible agencies, confidentiality and data-sharing rules, response deadlines, enforcement mechanism or start date. The archive therefore records an attributed bilateral process agreement, not an implemented technical safeguard or tested crisis channel.
- Bessent later said the United States and China had reached a deal extending the trade truce from November 10 through January 10. China's embassy had no immediate comment, and no joint text or implementing tariff instrument was public at that September 23 stage, so the archive records a named U.S. announcement rather than independently confirmed implementation.
- On September 26, China’s Foreign Ministry published a readout agreeing to an AI dialogue, a November exchange and a bilateral AI-incident channel. AP reported corresponding statements from both governments. This supplies Chinese confirmation absent at the earlier cutoff, but no operating protocol or demonstrated use of the channel was inspected.
- The Chinese readout endorsed the trade consultations and instructed implementation; AP reported a two-month truce extension. The readout said the militaries agreed to conclude a crisis-communication memorandum as soon as possible, not that one had already been signed. No implementing tariff instrument or completed military memorandum was retrieved in this review.
- On September 27, the White House published trade-board working procedures, terms of reference and recommended product lists. The terms say the principals approved comparably valued lists using 2024 annual bilateral trade values, roughly $30 billion on each side. Future tariff reductions must be determined and implemented through each country's domestic legal processes; these documents do not specify implemented tariff cuts or establish $30 billion in tariff savings.
- The procedures name Bessent, Greer and He Lifeng as principals and call for deputies to meet at least quarterly, subject to adjustment. Greer's September 27 statement presents the recommendations as potential future market access and consumer benefits, not measured results. The published trade procedures do not supply the still-missing AI incident-channel operating protocol.

## SIGNIFICANCE

The published framework makes the trade process and proposed product coverage inspectable. It advances the existing bilateral initiative without demonstrating lower collected duties, completed purchases or operational AI safeguards.

## GOALPOST / RESPONSE

The administration presents the framework as reciprocal trade, improved access for U.S. exporters and benefits for consumers. The documents reserve tariff implementation to domestic processes. Published rates, effective dates, customs instructions, realized trade and purchase data, plus separate AI operating protocols, will test those claims.

## MAYBE / THEREFORE

Maybe the approved lists will lead to effective reciprocal tariff relief, or domestic implementation and compliance disputes may limit it. Therefore the record verifies the published framework and approved lists, while keeping actual tariff changes, savings, purchases and AI operations unverified.

## CORRECTIONS

- **2026-09-28T04:05:16.156650Z** — Date-qualified the earlier absence of Chinese confirmation and tariff text so those historical observations cannot be mistaken for the current evidence state.


## SOURCES

- [Reuters — U.S. proposes AI incident notification mechanism in China talks](https://www.reuters.com/business/finance/us-treasurys-bessent-chinas-he-launch-talks-ai-trade-critical-minerals-2026-09-20/) — independent reporting on completed bilateral talks and named-official proposals
- [Associated Press — U.S. proposes AI security notifications in China talks](https://apnews.com/article/bessent-ai-xi-trump-china-trade-2c7f54f07e755f506d9db9b91df282bd) — independent reporting on completed talks, AI proposal and trade process
- [Reuters — Bessent says U.S. and China agreed to AI dialogue and incident line](https://www.reuters.com/world/asia-pacific/us-china-meet-again-ai-safety-two-months-shenzhen-bessent-says-2026-09-21/) — independent reporting of a named U.S. official's account of the bilateral process agreement and planned Shenzhen meeting
- [Reuters — Bessent says U.S. and China agreed to extend trade truce](https://www.reuters.com/world/china/trump-plans-grand-spectacle-potentially-tense-xi-talks-2026-09-23/) — independent reporting of a named U.S. official's announcement of a trade-truce extension and the absence of immediate Chinese confirmation
- [China and the United States Reach Eight Deliverables and Understandings](https://www.fmprc.gov.cn/eng/xw/zyxw/202609/t20260926_12031663.html) — official readout
- [China and US agree AI safety channel and further trade and military talks](https://krmg.com/2026/09/26/china-and-the-us-agree-to-set-up-a-new-ai-safety-channel-and-to-keep-talking-on-trade-military/) — news report
- [U.S.-China Board of Trade: published framework and recommended product lists](https://www.whitehouse.gov/releases/2026/09/u-s-china-board-of-trade/) — official release
- [Terms of reference for the 30-for-30 framework](https://www.whitehouse.gov/wp-content/uploads/2026/09/Terms-of-Reference-for-30-for-30-Framework.pdf) — primary agreed framework
- [Working procedures for the U.S.-China Board of Trade](https://www.whitehouse.gov/wp-content/uploads/2026/09/US-China-Board-of-Trade-Working-Procedures.pdf) — primary agreed procedures
- [Greer statement on Board of Trade recommendations](https://ustr.gov/about/policy-offices/press-office/press-releases/2026/september/ambassador-greer-issues-statement-announcement-recommendations-us-china-board-trade) — official statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
