# Bessent says U.S.–China AI dialogue and trade-truce extension agreed

**Entry ID:** NAT-2026-09-20-001
**Date:** September 20, 2026
**Checked:** 2026-09-24 12:00 AM EDT
**Evidence state:** Reuters reporting with named Treasury Secretary Scott Bessent, plus earlier Reuters and Associated Press reporting on the completed talks; AI process and trade extension announced by the United States, joint text, Chinese confirmation of the extension, operating rules and implementation absent
**Review state:** current-standard-reviewed

The Treasury secretary said both sides agreed to an AI dialogue, an incident line and a trade-truce extension through January 10; no joint instrument or Chinese confirmation of the extension was public by cutoff.

## THE FACTS

- After the September 20 talks, Treasury Secretary Scott Bessent said the United States and China had agreed to establish a formal dialogue on artificial-intelligence safety and an 'incident line' for communication during significant AI events. This is a named U.S. official's account of agreement; no joint text or detailed Chinese public confirmation was available by cutoff.
- Bessent said senior officials would meet again in about two months in Shenzhen and described possible subjects including uncontrollable agents and cyber threats from non-state actors. A future meeting is scheduled diplomatic process, not evidence that a notification system is already operating.
- No published instrument defined an incident threshold, responsible agencies, confidentiality and data-sharing rules, response deadlines, enforcement mechanism or start date. The archive therefore records an attributed bilateral process agreement, not an implemented technical safeguard or tested crisis channel.
- Bessent later said the United States and China had reached a deal extending the trade truce from November 10 through January 10. China's embassy had no immediate comment, and no joint text or implementing tariff instrument was public by cutoff, so the archive records a named U.S. announcement rather than independently confirmed implementation.

## SIGNIFICANCE

A standing AI dialogue and incident line could reduce misunderstanding, while a two-month trade-truce extension could defer renewed tariff escalation. Both effects remain prospective because the AI rules, joint trade text, tariff schedule and implementation evidence were not public.

## GOALPOST / RESPONSE

Bessent says the dialogue can improve communication during AI incidents and that the trade truce now runs through January 10. Chinese confirmation, a joint readout, named agencies, accepted incident rules, an implementing tariff instrument, the Shenzhen meeting and independently observed operation are the tests.

## MAYBE / THEREFORE

Maybe the announced extension will preserve negotiating space and the AI process will mature into a practical crisis channel, or missing joint terms and divergent interests may limit both arrangements. Therefore a named U.S. official announced an AI dialogue, incident line and trade-truce extension—not a published bilateral accord, independently confirmed tariff implementation or demonstrated safety outcome.


## SOURCES

- [Reuters — U.S. proposes AI incident notification mechanism in China talks](https://www.reuters.com/business/finance/us-treasurys-bessent-chinas-he-launch-talks-ai-trade-critical-minerals-2026-09-20/) — independent reporting on completed bilateral talks and named-official proposals
- [Associated Press — U.S. proposes AI security notifications in China talks](https://apnews.com/article/bessent-ai-xi-trump-china-trade-2c7f54f07e755f506d9db9b91df282bd) — independent reporting on completed talks, AI proposal and trade process
- [Reuters — Bessent says U.S. and China agreed to AI dialogue and incident line](https://www.reuters.com/world/asia-pacific/us-china-meet-again-ai-safety-two-months-shenzhen-bessent-says-2026-09-21/) — independent reporting of a named U.S. official's account of the bilateral process agreement and planned Shenzhen meeting
- [Reuters — Bessent says U.S. and China agreed to extend trade truce](https://www.reuters.com/world/china/trump-plans-grand-spectacle-potentially-tense-xi-talks-2026-09-23/) — independent reporting of a named U.S. official's announcement of a trade-truce extension and the absence of immediate Chinese confirmation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
