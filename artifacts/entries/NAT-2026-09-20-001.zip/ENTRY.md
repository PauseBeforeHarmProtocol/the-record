# Bessent says U.S. and China agreed to formal AI dialogue and incident line

**Entry ID:** NAT-2026-09-20-001
**Date:** September 20, 2026
**Checked:** 2026-09-21 12:01 PM EDT
**Evidence state:** Reuters reporting with named Treasury Secretary Scott Bessent, plus earlier Reuters and Associated Press reporting on the completed talks and public Chinese account; process agreement reported, joint text, operating rules and implementation absent
**Review state:** current-standard-reviewed

The Treasury secretary said both sides agreed to a formal dialogue, an incident line and another meeting in Shenzhen; no joint instrument or operating protocol was public by cutoff.

## THE FACTS

- After the September 20 talks, Treasury Secretary Scott Bessent said the United States and China had agreed to establish a formal dialogue on artificial-intelligence safety and an 'incident line' for communication during significant AI events. This is a named U.S. official's account of agreement; no joint text or detailed Chinese public confirmation was available by cutoff.
- Bessent said senior officials would meet again in about two months in Shenzhen and described possible subjects including uncontrollable agents and cyber threats from non-state actors. A future meeting is scheduled diplomatic process, not evidence that a notification system is already operating.
- No published instrument defined an incident threshold, responsible agencies, confidentiality and data-sharing rules, response deadlines, enforcement mechanism or start date. The archive therefore records an attributed bilateral process agreement, not an implemented technical safeguard or tested crisis channel.
- The sides also discussed the trade truce expiring November 10, but Bessent reported no extension. The earlier 'Board of Trade' product-review discussion still had no published product list, tariff change, legal instrument or timetable by cutoff.

## SIGNIFICANCE

A standing dialogue and incident line could reduce misunderstanding between the two largest AI powers and create a forum for risks that cross borders. The significance is prospective because governance, technical scope and actual use remain undocumented.

## GOALPOST / RESPONSE

Bessent says the dialogue can create shared understandings of AI danger and improve communication during incidents. A joint readout, Chinese confirmation, named agencies, accepted definitions, notification and confidentiality rules, the Shenzhen meeting, operating records and independently observed use are the tests.

## MAYBE / THEREFORE

Maybe the agreed process will mature into a practical crisis channel, or divergent security and technology interests may leave it as periodic diplomacy without operational effect. Therefore Bessent reported agreement on a dialogue, incident line and follow-up meeting—not a published bilateral accord, active notification protocol or demonstrated safety outcome.


## SOURCES

- [Reuters — U.S. proposes AI incident notification mechanism in China talks](https://www.reuters.com/business/finance/us-treasurys-bessent-chinas-he-launch-talks-ai-trade-critical-minerals-2026-09-20/) — independent reporting on completed bilateral talks and named-official proposals
- [Associated Press — U.S. proposes AI security notifications in China talks](https://apnews.com/article/bessent-ai-xi-trump-china-trade-2c7f54f07e755f506d9db9b91df282bd) — independent reporting on completed talks, AI proposal and trade process
- [Reuters — Bessent says U.S. and China agreed to AI dialogue and incident line](https://www.reuters.com/world/asia-pacific/us-china-meet-again-ai-safety-two-months-shenzhen-bessent-says-2026-09-21/) — independent reporting of a named U.S. official's account of the bilateral process agreement and planned Shenzhen meeting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
