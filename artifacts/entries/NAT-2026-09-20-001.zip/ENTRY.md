# U.S. proposes AI incident notifications in China trade talks

**Entry ID:** NAT-2026-09-20-001
**Date:** September 20, 2026
**Checked:** 2026-09-20 11:58 PM EDT
**Evidence state:** independent Reuters and Associated Press reporting with named U.S. officials and public Chinese account; formal proposal reported, acceptance, operative terms and implementation absent
**Review state:** current-standard-reviewed

The completed talks produced formal U.S. AI-security and tariff-process proposals, but no public Chinese acceptance, tariff change or operative agreement.

## THE FACTS

- After concluding talks with Chinese Vice Premier He Lifeng late September 20, Treasury Secretary Scott Bessent said the United States formally proposed an AI national-security incident notification mechanism and a separate AI dialogue with China. Reuters and Associated Press independently reported the proposal; China's publicly reported response was unclear.
- Bessent said the proposed mechanism would let each country notify the other when artificial-intelligence systems produce consequences believed to threaten national security. The proposal was expected to be considered at a future Trump-Xi summit; no published instrument, notification threshold, enforcement rule, data-sharing safeguard or implementation date existed by cutoff.
- U.S. Trade Representative Jamieson Greer said the sides agreed to operationalize a previously discussed 'Board of Trade' that could identify nonsensitive products for possible tariff reductions. No product list, tariff rate change, legal instrument or timetable was announced, and the talks produced no reported breakthrough on critical minerals, aircraft or agricultural purchases.
- The administration framed the talks as constructive progress on risk management and trade. The Chinese state account said AI was discussed but did not publicly confirm acceptance of the U.S. notification proposal; therefore the archive records a formal U.S. proposal and process discussion, not a bilateral agreement or implemented safeguard.

## SIGNIFICANCE

A bilateral AI incident channel could reduce misunderstanding between the two largest powers, while a product-review process could affect tariffs and supply chains. Neither consequence exists yet because key terms, Chinese acceptance and legal implementation remain absent.

## GOALPOST / RESPONSE

The administration says the proposals can manage AI national-security risks and identify nonsensitive trade for possible tariff relief. A joint readout, accepted definitions, notification and confidentiality rules, governance, named products, legal tariff changes, implementation records and independently observed use are the tests.

## MAYBE / THEREFORE

Maybe the proposals will mature into practical crisis communication and limited tariff relief, or disagreement over security, data and trade may leave them as summit agenda items. Therefore the completed talks establish formal U.S. proposals and a claimed process agreement—not Chinese acceptance of the AI mechanism, reduced tariffs or an operating bilateral system.


## SOURCES

- [Reuters — U.S. proposes AI incident notification mechanism in China talks](https://www.reuters.com/business/finance/us-treasurys-bessent-chinas-he-launch-talks-ai-trade-critical-minerals-2026-09-20/) — independent reporting on completed bilateral talks and named-official proposals
- [Associated Press — U.S. proposes AI security notifications in China talks](https://apnews.com/article/bessent-ai-xi-trump-china-trade-2c7f54f07e755f506d9db9b91df282bd) — independent reporting on completed talks, AI proposal and trade process

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
