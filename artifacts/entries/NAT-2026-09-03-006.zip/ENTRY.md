# SEC proposes rescinding investment-adviser pay-to-play rule

**Entry ID:** NAT-2026-09-03-006
**Date:** September 3, 2026
**Checked:** 2026-09-03 6:02 PM EDT
**Evidence state:** primary SEC proposal announcement plus independent Reuters reporting; rescission proposed for comment, existing rule remains operative pending final action
**Review state:** current-standard-reviewed

The proposal would remove the two-year compensated-advisory ban triggered by certain political contributions and related recordkeeping duties; other antifraud and fiduciary rules would remain.

## THE FACTS

- The Securities and Exchange Commission issued a proposal September 3 to rescind Advisers Act Rule 206(4)-5, known as the pay-to-play rule, and eliminate its corresponding recordkeeping requirements.
- The 2010 rule generally prohibits an investment adviser from receiving compensation for advisory services to a government client for two years after the adviser or certain covered associates make a political contribution to specified officials or candidates. The proposal does not itself change the rule while public comment and final agency action remain pending.
- SEC Chairman Paul Atkins said the rule is overly prescriptive, creates operational difficulty and can impose serious consequences for small donations, including contributions made before an employee joins a firm. The Commission said political contributions are more appropriately governed by election law and state or local rules.
- The SEC said Advisers Act antifraud provisions, fiduciary duties, compliance and ethics rules would continue if the proposal becomes final. Rescission therefore would remove a specific federal prophylactic restriction, not all regulation of adviser corruption, conflicts or political contributions.
- The comment period will remain open for 60 days after Federal Register publication. No final rescission, compliance change, enforcement dismissal or measured effect on public-pension contracting had occurred by cutoff.

## SIGNIFICANCE

The proposal would remove a federal rule designed to deter political contributions from influencing the award of public investment business. It could reduce compliance burdens and speech restrictions while shifting more corruption risk to general fiduciary, antifraud and election-law enforcement.

## GOALPOST / RESPONSE

The SEC says the rule produces disproportionate penalties and suppresses political speech while other laws remain available. The final rule, comment record, litigation, adviser contribution policies, public-fund procurement data, enforcement trends and evidence of pay-to-play conduct are the tests.

## MAYBE / THEREFORE

Maybe general antifraud, fiduciary and election-law controls can address misconduct with fewer burdens on lawful donations, or removing the bright-line cooling-off period may make influence harder to detect and deter. Therefore the record establishes a formal rescission proposal—not a repeal, permission to commit fraud or evidence that public investment awards have already changed.


## SOURCES

- [SEC — proposed rescission of investment-adviser pay-to-play rule](https://www.sec.gov/newsroom/press-releases/2026-85-sec-proposes-rescission-political-contribution-rule-investment-advisers) — primary agency proposal to rescind Rule 206(4)-5 and associated recordkeeping requirements
- [Reuters — SEC proposes ending investment-adviser political-contribution rule](https://www.reuters.com/legal/government/sec-proposes-reforms-political-contribution-rule-investment-advisers-2026-09-03/) — independent reporting on the proposed rescission, existing restriction and stated rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
