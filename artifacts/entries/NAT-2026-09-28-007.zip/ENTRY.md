# FAA delays Boeing 737 MAX 10 certification over software issue

**Entry ID:** NAT-2026-09-28-007
**Date:** September 28, 2026
**Checked:** 2026-09-28 5:55 PM EDT
**Evidence state:** named FAA, airline and manufacturer statements reported by Reuters; certification delay and review announced, fix and final approval pending
**Review state:** current-standard-reviewed

The agency says certification will remain on hold until a newly disclosed flight-guidance software issue is resolved and reviewed.

## THE FACTS

- FAA Administrator Bryan Bedford said the agency will hold off certifying Boeing's 737 MAX 10 until a newly disclosed software issue is resolved.
- The issue could prevent access to automated flight guidance during a specific go-around scenario, increasing pilot workload. The FAA plans to convene a Corrective Action Review Board; pilots retain control of the aircraft and no fix date was announced.
- WestJet said it had seen no in-service events related to the software and did not regard the issue as a safety concern. Boeing said it would follow the FAA's process.
- The action delays certification of the MAX 10; it is not a grounding or decertification of other 737 MAX variants, and the record does not infer an accident or operational failure from the identified scenario.

## SIGNIFICANCE

The FAA's hold applies premarket safety review to Boeing's largest MAX variant and can affect airline fleet plans and production timing. Its significance is the certification gate, not evidence that in-service aircraft experienced the scenario.

## GOALPOST / RESPONSE

The FAA says the issue must be resolved before certification, while WestJet says it has not observed related events and Boeing says it will follow the process. The software remedy, review-board findings, certification date, airline delivery schedules and any incident evidence are the tests.

## MAYBE / THEREFORE

Maybe the issue will be corrected through the ordinary certification process without operational consequence, or review may reveal a broader design or human-factors concern. Therefore the record describes a certification delay tied to a specified scenario—not a grounding, crash finding or proof that the software failed in service.


## SOURCES

- [FAA delays Boeing 737 MAX 10 certification over software issue](https://www.reuters.com/world/westjet-said-it-has-not-seen-any-in-service-events-related-software-under-faa-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
