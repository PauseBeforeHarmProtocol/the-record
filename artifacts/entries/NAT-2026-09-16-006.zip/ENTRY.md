# First Circuit stay lets HUD proceed with $1.3 billion homelessness-program set-aside

**Entry ID:** NAT-2026-09-16-006
**Date:** September 16, 2026
**Checked:** 2026-09-17 12:01 PM EDT
**Evidence state:** complete three-page First Circuit order plus Reuters; stay pending appeal
**Review state:** current-standard-reviewed

The appellate stay allows implementation during appeal; it is not a final merits judgment or grant award.

## THE FACTS

- On September 16 the First Circuit granted a stay pending appeal in Nos. 26-1922 and 26-1923, suspending the district-court ruling against HUD’s Continuum of Care funding notice.
- The order concerns a $1.3 billion set-aside for transitional housing and supportive-service-only projects. The panel found HUD likely to prevail on whether the set-aside required notice and comment, and cited the December 1, 2026 award deadline and potential funding gaps.
- The stay permits HUD to proceed while the appeal continues. It neither finally resolves the statutory claim nor establishes completed awards or housing outcomes.
- Reuters reported HUD’s argument that the change will improve results and plaintiffs’ warning of housing losses. Those competing predictions are not measured outcomes.

## SIGNIFICANCE

The order removes an immediate legal barrier to a substantial funding shift; implementation can now precede final judicial resolution.

## GOALPOST / RESPONSE

HUD favors a different housing-and-services mix; plaintiffs defend permanent-housing support. The tests are the merits decision, award ledger, funding gaps and independently measured housing retention.

## MAYBE / THEREFORE

Maybe the stay avoids missed awards, or changing allocations during litigation creates harm later relief cannot repair. Therefore legal permission to proceed is established, not the program’s effectiveness or a displacement count.


## SOURCES

- [First Circuit — Continuum of Care stay pending appeal](https://fingfx.thomsonreuters.com/gfx/legaldocs/myvmromropr/09162026hud.pdf) — primary three-judge order in Nos. 26-1922 and 26-1923
- [Reuters — First Circuit allows HUD homelessness-program overhaul pending appeal](https://www.reuters.com/legal/government/trump-administration-can-proceed-with-homelessness-program-overhaul-us-court-2026-09-16/) — independent court reporting based on the First Circuit order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
