# DOJ and Mount Sinai execute agreement ending specified gender-affirming care for minors

**Entry ID:** NAT-2026-09-04-015
**Date:** September 4, 2026
**Checked:** 2026-09-05 6:00 AM EDT
**Evidence state:** primary DOJ announcement of an executed agreement plus independent Gothamist reporting and a named Mount Sinai response; core commitments confirmed, complete agreement and penalty amount undisclosed, liability and outcomes unresolved
**Review state:** current-standard-reviewed

Mount Sinai agreed to stop puberty blockers, cross-sex hormones and surgeries for minors, pay an undisclosed penalty and dedicate $2 million to care; the agreement is not a liability finding.

## THE FACTS

- The Justice Department announced an executed agreement resolving its investigation into potential federal-law violations involving Mount Sinai Health System's provision of gender-affirming care to minors.
- DOJ said Mount Sinai agreed to stop providing puberty blockers, cross-sex hormones and surgical procedures to minors, pay an undisclosed monetary penalty and dedicate $2 million to free medical care for people experiencing harmful consequences from gender-affirming care received as children.
- The department stated that the resolved claims were allegations only, that no liability determination had been made and that Mount Sinai denied all allegations. The public announcement did not disclose the penalty amount or attach the complete executed agreement.
- Mount Sinai told Gothamist it settled so it would not be compelled to produce highly sensitive patient records to a grand jury and said its purpose was to protect patient privacy and let physicians focus on care. Independent reporting indicates the system had already ended pediatric puberty-blocker and hormone services earlier in 2026.
- DOJ linked the resolution to Trump's January 2025 executive order and its nationwide investigation of possible Food, Drug and Cosmetic Act, False Claims Act and billing violations. The settlement establishes agreed restrictions and financial commitments; it does not establish that the government's allegations were true or that the covered care caused harm in any particular patient.

## SIGNIFICANCE

The agreement converts a federal investigation and subpoena pressure into enforceable institutional commitments affecting medical access, patient privacy and hospital funds at a major New York health system. Its reach and practical effect matter independently of the unresolved underlying allegations.

## GOALPOST / RESPONSE

DOJ says the resolution protects children and provides care to people harmed by prior treatment. Mount Sinai says it settled to protect sensitive patient records and denies liability. The complete agreement, penalty amount, enforcement and reporting terms, patient transfers and continuity of care, use of the $2 million commitment, related court rulings and evidence of patient outcomes are the tests.

## MAYBE / THEREFORE

Maybe the agreement is a lawful resolution that prevents unsafe or improperly billed care while protecting records, or federal investigative pressure may have forced a provider to end lawful treatment without proving wrongdoing. Therefore the record establishes Mount Sinai's commitments, DOJ's allegations and the hospital's privacy rationale and denial—not an admission, judicial finding, verified patient harm or measured health benefit.


## SOURCES

- [Justice Department — agreement with Mount Sinai on pediatric gender-affirming care](https://www.justice.gov/opa/pr/justice-department-secures-agreement-mount-sinai-end-pediatric-gender-affirming-care) — primary agency announcement of an executed resolution, terms, unresolved allegations and denial of liability
- [Gothamist — Mount Sinai explains DOJ gender-care agreement](https://gothamist.com/news/mount-sinai-reaches-deal-with-trump-doj-to-end-gender-affirming-care-for-minors) — independent local reporting with Mount Sinai's stated patient-privacy rationale and settlement context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
