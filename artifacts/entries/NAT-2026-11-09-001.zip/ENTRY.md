# House refers Hegseth impeachment resolution to Judiciary Committee

**Entry ID:** NAT-2026-11-09-001
**Date:** November 9–10, 2026
**Checked:** 2026-11-11 12:05 AM EST
**Evidence state:** primary House notice and roll call, sponsor text, independent Associated Press and Reuters reporting and administration responses; referral passed, allegations unadjudicated and further committee action unresolved
**Review state:** current-standard-reviewed

The 211–204 referral vote halted immediate House consideration without adjudicating the eight articles or exonerating the defense secretary.

## THE FACTS

- On November 9 at 2:04:50 p.m., the House Clerk recorded Representative Thomas Massie’s notice of intent to offer a privileged resolution under House Rule IX seeking to impeach Defense Secretary Peter Hegseth. Notice created a procedural path to consideration; it was not House adoption, impeachment or Senate conviction.
- Massie published a 34-page draft with eight proposed articles alleging war-powers, civilian-harm, extrajudicial-killing, speech-retaliation and other abuses. They remain a member’s formal allegations, not judicial findings or facts established by the House.
- On November 10 at 6:02 p.m. EST, the House voted 211–204 to refer H. Res. 1655 to the Judiciary Committee. The Clerk recorded Republicans 210–1 in favor of referral, Democrats 0–203 and the chamber’s independent member in favor; 18 members did not vote.
- Referral prevented an immediate up-or-down vote on impeachment and effectively stalled the privileged resolution unless the committee or House takes further action. It did not adopt an article, initiate a Senate trial, adjudicate the allegations or establish that Hegseth was exonerated.
- Hegseth called the effort politically motivated and defended the administration’s military actions; Trump attacked Massie and defended Hegseth. Those statements establish the administration’s response, not independent proof that the allegations are false or that the cited operations were lawful.

## SIGNIFICANCE

The House formally disposed of the privileged impeachment attempt by referring it to committee, a material oversight decision that stopped immediate consideration of allegations involving war powers, civilian protection and retaliation. The vote resolved the procedural stage, not Hegseth’s factual or legal liability.

## GOALPOST / RESPONSE

Massie says Hegseth defied statutory and constitutional limits; Hegseth and Trump call the effort political and defend the administration’s security decisions. The tests are Judiciary Committee action, any renewed House vote, underlying operational and legal records, judicial findings and—only if the House impeaches—Senate proceedings.

## MAYBE / THEREFORE

Maybe referral allows the Judiciary Committee to examine the eight articles, or it may function as a way to end the effort without a merits vote. Therefore the record establishes a 211–204 referral and the absence of immediate impeachment—not proven misconduct, dismissal of the allegations on their merits, removal or exoneration.


## SOURCES

- [Rep. Thomas Massie — announcement of privileged Hegseth impeachment resolution](https://massie.house.gov/news/documentsingle.aspx?DocumentID=395863) — primary congressional sponsor statement
- [Draft articles of impeachment against Defense Secretary Peter Hegseth](https://massie.house.gov/uploadedfiles/hegseth_impeachment_articles_11.9.26.pdf) — primary 34-page proposed House resolution; full retrieved PDF SHA-256 d232f6c4be7cd4bd90b7115086d7030d56829166063b189eee912abb294469dc
- [House Clerk — November 9 floor action summary](https://clerk.house.gov/Home/ViewFloorActions) — primary House floor record
- [AP — Massie launches bid to impeach Defense Secretary Hegseth](https://apnews.com/article/f5303cfb626ae2ef7a4a3f660f5519df) — independent reporting on procedure and administration response
- [Donald Trump Truth Social post defending Hegseth and attacking Massie](https://truthsocial.com/@realDonaldTrump/117589581287691662) — primary evidence only that Trump published this response
- [House Clerk — roll call 317 on referral of H. Res. 1655](https://clerk.house.gov/Votes/2026317?Page=1) — primary House roll call recording the 211–204 referral vote and party totals
- [Reuters — House refers Hegseth impeachment resolution to Judiciary Committee](https://www.reuters.com/world/us/us-house-votes-derail-impeachment-defense-secretary-hegseth-2026-11-10/) — independent reporting on the vote, procedural effect and administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
