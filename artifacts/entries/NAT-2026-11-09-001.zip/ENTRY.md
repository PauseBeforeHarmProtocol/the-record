# Massie gives notice of privileged resolution seeking Hegseth’s impeachment

**Entry ID:** NAT-2026-11-09-001
**Date:** November 9, 2026
**Checked:** 2026-11-10 6:10 AM EST
**Evidence state:** primary House floor record, sponsor statement and full draft resolution plus Associated Press and administration response; procedural notice verified, allegations unresolved
**Review state:** current-standard-reviewed

The proposed eight-article resolution alleges war-powers, civilian-harm, speech-retaliation and other abuses; the House had not voted and the allegations were not adjudicated by cutoff.

## THE FACTS

- On November 9 at 2:04:50 p.m., the House Clerk recorded Representative Thomas Massie’s notice of intent to offer a privileged resolution under House Rule IX seeking to impeach Defense Secretary Peter Hegseth. Notice creates a procedural path to consideration; it is not House adoption, impeachment or Senate conviction.
- Massie published a 34-page draft with eight proposed articles. They allege violations of War Powers Resolution sections 2(c), 5(c) and 5(b), disregard of civilian-casualty laws, extrajudicial killings in maritime operations, retaliation against Senator Mark Kelly’s speech, unlawful seizure of Nicolás Maduro and Cilia Flores, and an unauthorized Yemen war. These are a member’s formal allegations, not judicial findings or facts established by House vote.
- Associated Press reported a House vote could occur by midweek. At cutoff, the Clerk’s record showed only the notice of intent; the archive located no House vote, adopted resolution, referral outcome, Senate trial or adjudication of the eight charges.
- Hegseth called the effort politically motivated and defended the Iran campaign as necessary to address Iran’s nuclear threat. Trump published a Truth Social post attacking Massie and defending Hegseth. Those statements establish the administration’s response, not independent proof that the allegations are false or that the cited operations were lawful.

## SIGNIFICANCE

A privileged impeachment resolution can force the House to address formal allegations concerning congressional war powers, civilian protection, executive military authority and retaliation against a senator. The procedural notice is material oversight activity, but it does not itself determine Hegseth’s liability or remove him from office.

## GOALPOST / RESPONSE

Massie says Hegseth defied statutory and constitutional limits across several military operations and retaliated against protected speech. Hegseth and Trump call the effort political and defend the administration’s security decisions. The tests are the final resolution text, House disposition and vote, underlying operational and legal records, any judicial findings and—only if the House impeaches—Senate proceedings.

## MAYBE / THEREFORE

Maybe the privileged process produces a substantive House judgment and new evidence, or the chamber may table or otherwise dispose of the resolution without adjudicating the allegations. Therefore the record establishes formal notice and eight proposed articles—not completed impeachment, proven misconduct, removal or exoneration.


## SOURCES

- [Rep. Thomas Massie — announcement of privileged Hegseth impeachment resolution](https://massie.house.gov/news/documentsingle.aspx?DocumentID=395863) — primary congressional sponsor statement
- [Draft articles of impeachment against Defense Secretary Peter Hegseth](https://massie.house.gov/uploadedfiles/hegseth_impeachment_articles_11.9.26.pdf) — primary 34-page proposed House resolution; full retrieved PDF SHA-256 d232f6c4be7cd4bd90b7115086d7030d56829166063b189eee912abb294469dc
- [House Clerk — November 9 floor action summary](https://clerk.house.gov/Home/ViewFloorActions) — primary House floor record
- [AP — Massie launches bid to impeach Defense Secretary Hegseth](https://apnews.com/article/f5303cfb626ae2ef7a4a3f660f5519df) — independent reporting on procedure and administration response
- [Donald Trump Truth Social post defending Hegseth and attacking Massie](https://truthsocial.com/@realDonaldTrump/117589581287691662) — primary evidence only that Trump published this response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
