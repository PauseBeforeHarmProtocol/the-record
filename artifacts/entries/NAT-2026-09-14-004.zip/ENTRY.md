# EPA announces finalized repeal of federal power-plant greenhouse-gas limits

**Entry ID:** NAT-2026-09-14-004
**Date:** September 14, 2026
**Checked:** 2026-09-14 6:00 PM EDT
**Evidence state:** primary Federal Register proposal plus independent Reuters and Associated Press reporting of the finalized announcement; repeal finalized but publication, effectiveness, litigation and measured outcomes unresolved
**Review state:** current-standard-reviewed

The agency announced a final rollback of existing coal- and gas-plant standards; Federal Register publication and effectiveness were still pending at cutoff.

## THE FACTS

- The Environmental Protection Agency announced on September 14 that it had finalized the repeal of federal greenhouse-gas standards for fossil-fuel-fired power plants. Reuters and Associated Press reported the completed agency announcement; the final regulatory text had not appeared in the Federal Register by cutoff, so the record does not treat the repeal as legally effective yet.
- The rulemaking traces to EPA's June 2025 proposal to repeal the 2015 new-source standards and the 2024 Carbon Pollution Standards for covered new and existing coal- and gas-fired units. The proposal argued that power-sector greenhouse gases do not contribute significantly enough to dangerous air pollution to support regulation under Clean Air Act section 111 and offered alternative technology-based grounds.
- Associated Press reported a separate EPA proposal intended to constrain future federal greenhouse-gas regulation of power plants. That second action remains proposed and is not recorded as a completed legal bar on a future administration.
- EPA said the repeal would reduce industry costs and improve reliability; Associated Press reported the agency's estimate of more than $300 billion in avoided costs. Reuters separately reported Administrator Lee Zeldin citing about $370 million in direct compliance savings. Those figures describe different asserted scopes and are not combined or treated as audited outcomes.
- Environmental and public-health groups said removing the standards would increase climate and health harms, while coal and utility representatives supported relief but emphasized regulatory certainty. The prior 2024 rule projected large emissions and net-benefit gains; none of the competing future cost, reliability, health or emissions forecasts was measured by the cutoff.

## SIGNIFICANCE

The repeal removes the federal power-sector carbon framework built under Clean Air Act section 111 once it becomes effective and changes the compliance path for major stationary emitters. Its legal durability, emissions effects, reliability consequences and actual cost savings remain open and likely to be litigated.

## GOALPOST / RESPONSE

EPA says the standards exceed its authority, impose major costs and impede reliable energy supply. Supporters of the prior rules say carbon controls protect climate and public health. Federal Register publication, effective date, petitions for review, stays, plant investment and retirement decisions, grid reliability, compliance spending and measured emissions are the tests.

## MAYBE / THEREFORE

Maybe the repeal lowers compliance costs and accelerates capacity additions without a material reliability or health tradeoff, or it may increase emissions and damages while producing smaller savings than claimed. Therefore the record establishes a finalized agency announcement with publication and effectiveness pending—not a measured economic benefit, a demonstrated reliability improvement, a final judicial resolution or an already effective prohibition on future regulation.


## SOURCES

- [Federal Register — proposed repeal of greenhouse-gas standards for fossil-fuel-fired power plants](https://www.federalregister.gov/documents/2025/06/17/2025-10991/repeal-of-greenhouse-gas-emissions-standards-for-fossil-fuel-fired-electric-generating-units) — primary proposed-rule record establishing the rulemaking scope, legal theory and standards targeted for repeal
- [Reuters — EPA announces repeal of power-plant carbon limits](https://www.reuters.com/legal/litigation/epa-undo-carbon-emission-limits-power-plants-g20-meeting-2026-09-14/) — independent reporting of the finalized repeal announcement, agency rationale, estimates and responses
- [Associated Press — EPA eliminates greenhouse-gas limits for power plants](https://apnews.com/article/epa-power-plants-trump-coal-gas-climate-cac1c2c75f8656d8eaf5f0a240edae15) — independent reporting of the finalized repeal, pending publication, separate proposal and competing cost and health claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
