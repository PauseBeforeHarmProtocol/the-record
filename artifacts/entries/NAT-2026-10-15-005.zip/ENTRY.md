# Judge preliminarily blocks DHS voter-list disclosures and ballot-segregation demands

**Entry ID:** NAT-2026-10-15-005
**Date:** October 15–November 2, 2026
**Checked:** 2026-11-03 6:09 AM EST
**Evidence state:** Primary case identity and docket entries, independent legal tracker and Reuters reporting on the November 2 preliminary injunction and APA stay; public court-document text was not retrieved, individual eligibility and final merits remain unresolved
**Review state:** current-standard-reviewed

Judge Tanya Chutkan preliminarily barred DOJ and DHS from sending state election officials federal lists purporting to identify noncitizen voters or pressing officials to segregate or withhold ballots; individual SAVE checks remain permitted.

## THE FACTS

- The League of Women Voters, Electronic Privacy Information Center and League of United Latin American Citizens filed League of Women Voters v. DHS, No. 1:26-cv-03602, in the U.S. District Court for the District of Columbia.
- The 42-page complaint alleges DHS obtained and processed statewide voter files from at least 47 states, augmented them with commercially purchased information and directed hundreds of agents to search the records for possible noncitizen registration or voting. Those descriptions are pleaded allegations, not judicial findings.
- Plaintiffs allege the policy violates the Privacy Act, Paperwork Reduction Act and Administrative Procedure Act because DHS lacks statutory authority and did not publish required notices, obtain approvals or limit collection to relevant and necessary information. They seek vacatur, an injunction and deletion or cessation of use of collected voter information.
- Associated Press independently reported the filing and said DHS did not immediately respond. The case is separate from the October 9 vacatur of DOJ’s nationwide voter-list maintenance policy and from litigation over the expanded SAVE system, though all concern the administration’s broader noncitizen-voting initiative.
- On November 2, U.S. District Judge Tanya Chutkan issued preliminary relief in League of Women Voters v. DHS, No. 1:26-cv-03602-TSC. A public docket timeline lists the order and memorandum as filed November 3; Reuters and an independent legal tracker report the ruling was issued November 2. The archive preserves those publication and ruling dates separately.
- The preliminary injunction and 5 U.S.C. § 705 stay bar DOJ and DHS from further disclosure, transmission or release to state or local election officials of lists purporting to identify potential or actual noncitizen voters or registrants, and from asking officials to segregate or withhold ballots based on those lists until citizenship is proven. The reported relief does not bar responses to individual SAVE verification inquiries.
- Reuters reported that Chutkan found the federal data may be unreliable and could disenfranchise lawfully registered voters. That is a preliminary risk assessment supporting interim relief, not a final determination that every listed person is a citizen or that every federal data practice is unlawful.
- The Justice Department argued that its California and Washington letters were part of enforcing the federal ban on noncitizen voting and did not amount to a distinct policy subject to judicial review. The preliminary injunction rejects that position only at this stage; no final merits judgment or appellate disposition was verified by cutoff.

## SIGNIFICANCE

The case has advanced from allegations about a nationwide voter-data program to operative preliminary relief limiting federal disclosure and pressure on state election officials. The order narrows immediate election-administration risk while leaving individual SAVE inquiries, appeals and final merits unresolved.

## GOALPOST / RESPONSE

DOJ says its letters enforce the federal prohibition on noncitizen voting and do not constitute a separately reviewable policy. Plaintiffs say the disclosures violate privacy law and risk disenfranchising citizens. The tests are compliance, any appeal or stay, the accuracy and lawful use of federal matching data, and a final merits judgment—not the preliminary order alone.

## MAYBE / THEREFORE

Maybe targeted federal-state verification can protect lawful ballots without displacing state procedures, while bulk or probabilistic lists can also misidentify citizens and chill valid voting. Therefore the record establishes a preliminary injunction and APA stay against specified list disclosures and ballot demands—not a final finding that every federal match is wrong, a bar on individual SAVE inquiries, or universal immunity from election-law enforcement.


## SOURCES

- [League of Women Voters et al. v. DHS complaint](https://democracyforward.org/wp-content/uploads/2026/10/DHS-voter-files-complaint.pdf) — primary filed complaint
- [Associated Press — DHS voter-data collection lawsuit](https://apnews.com/article/lawsuit-dhs-voter-data-privacy-noncitizens-election-98365a44e96e46de14ad44e62ac7dd70) — independent reporting on filed complaint
- [Reuters — judge blocks voter-list disclosures and ballot-segregation demands](https://www.reuters.com/world/judge-blocks-trump-administration-pressuring-states-over-noncitizen-voting-2026-11-03/) — independent report on the preliminary injunction, competing positions and non-final status
- [Just Security — 2026 midterms election-integrity litigation tracker](https://www.justsecurity.org/162830/2026-midterms-election-integrity-litigation-tracker/) — independent legal tracker identifying the case, November 2 injunction and APA stay scope
- [Power & Politics — League of Women Voters v. DHS docket timeline](https://powerandpolitics.co/case.php?id=41813) — public docket timeline listing the November 3 order and memorandum entries

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
