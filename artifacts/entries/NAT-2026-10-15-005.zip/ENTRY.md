# Civil-rights groups challenge DHS nationwide voter-data collection policy

**Entry ID:** NAT-2026-10-15-005
**Date:** October 15, 2026
**Checked:** 2026-10-15 11:57 PM EDT
**Evidence state:** Filed 42-page federal complaint plus independent Associated Press reporting; collection scope and legal violations are alleged, DHS response and judicial findings pending
**Review state:** current-standard-reviewed

A filed complaint says DHS assembled voter files from at least 47 states and combined them with commercial data without required privacy and paperwork safeguards; the allegations and requested deletion order remain unadjudicated.

## THE FACTS

- The League of Women Voters, Electronic Privacy Information Center and League of United Latin American Citizens filed League of Women Voters v. DHS, No. 1:26-cv-03602, in the U.S. District Court for the District of Columbia.
- The 42-page complaint alleges DHS obtained and processed statewide voter files from at least 47 states, augmented them with commercially purchased information and directed hundreds of agents to search the records for possible noncitizen registration or voting. Those descriptions are pleaded allegations, not judicial findings.
- Plaintiffs allege the policy violates the Privacy Act, Paperwork Reduction Act and Administrative Procedure Act because DHS lacks statutory authority and did not publish required notices, obtain approvals or limit collection to relevant and necessary information. They seek vacatur, an injunction and deletion or cessation of use of collected voter information.
- Associated Press independently reported the filing and said DHS did not immediately respond. The case is separate from the October 9 vacatur of DOJ’s nationwide voter-list maintenance policy and from litigation over the expanded SAVE system, though all concern the administration’s broader noncitizen-voting initiative.

## SIGNIFICANCE

The complaint exposes and directly challenges a claimed nationwide federal voter-data program involving sensitive state and commercial information shortly before the midterm election. If the allegations are sustained, the case could define privacy and statutory limits on federal election-data aggregation; no court has yet done so in this suit.

## GOALPOST / RESPONSE

The administration says cross-checking records helps identify unlawful noncitizen voting; plaintiffs say DHS lacks authority and bypassed privacy and paperwork safeguards. Agency disclosures, a system-of-records notice, answers about data fields and commercial vendors, preservation or deletion orders, and merits rulings are the tests.

## MAYBE / THEREFORE

Maybe DHS can show lawful investigative authority, adequate safeguards and narrower data use than alleged, or the plaintiffs may encounter standing or remedial limits. Therefore a detailed complaint and an independently reported national data-collection claim are documented—not a finding that DHS broke the law, proof of widespread noncitizen voting or a completed deletion remedy.


## SOURCES

- [League of Women Voters et al. v. DHS complaint](https://democracyforward.org/wp-content/uploads/2026/10/DHS-voter-files-complaint.pdf) — primary filed complaint
- [Associated Press — DHS voter-data collection lawsuit](https://apnews.com/article/lawsuit-dhs-voter-data-privacy-noncitizens-election-98365a44e96e46de14ad44e62ac7dd70) — independent reporting on filed complaint

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
