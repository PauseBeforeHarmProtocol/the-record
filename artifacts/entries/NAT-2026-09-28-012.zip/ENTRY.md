# Hegseth directs military cyber and intelligence forces to counter foreign election interference

**Entry ID:** NAT-2026-09-28-012
**Date:** September 22–28, 2026
**Checked:** 2026-09-29 5:58 AM EDT
**Evidence state:** Axios inspection of the September 22 memorandum, named Pentagon response and independent Associated Press confirmation; directive reported, operations and outcomes undisclosed
**Review state:** current-standard-reviewed

The September 22 memorandum prioritizes foreign-threat detection and disruption; it does not order troops to polling places or establish successful operations.

## THE FACTS

- Axios and Associated Press reported on September 28 that Defense Secretary Pete Hegseth signed a September 22 memorandum directing Defense Department intelligence and cyber components to prioritize foreign threats to the 2026 elections.
- Axios reported that the memorandum directs U.S. Cyber Command and combat-support agencies to use intelligence and cyber capabilities to identify, disrupt and neutralize foreign interference; it also calls for Defense Intelligence Enterprise collection and joint cyber operations with the Department of Homeland Security, subject to law and executive direction.
- Chief Pentagon spokesperson Sean Parnell said federal, state and local officials were working with Cyber Command and defense-intelligence teams. The directive does not order National Guard or military personnel to polling places, seize voting equipment or administer elections.
- Military support against foreign election interference predates this memorandum and has been described as an enduring mission. No particular threat attribution, completed cyber operation, prevented attack or measured election-security outcome was disclosed by cutoff.

## SIGNIFICANCE

The directive formally prioritizes Defense Department intelligence, cyber and artificial-intelligence capabilities for the midterm-election threat mission. It expands operational focus without transferring domestic election administration to the military or proving that a specific operation occurred.

## GOALPOST / RESPONSE

The Pentagon says countering malicious foreign cyber actors is an enduring defense mission and that agencies and election officials are coordinating. Public legal guidance, threat notifications, bounded operational reporting, congressional oversight and independently assessed security outcomes are the tests.

## MAYBE / THEREFORE

Maybe the directive improves coordination against genuine foreign threats, or broad classified authorities and limited public detail may heighten concerns about military involvement in election-related activity. Therefore the verified development is a foreign-interference cyber and intelligence directive—not domestic troop deployment, seizure of election systems or demonstrated operational success.


## SOURCES

- [Axios — Hegseth directs Defense Department to counter foreign election interference](https://www.axios.com/2026/09/28/hegseth-elections-security-order) — independent reporting based on the September 22 memorandum with named Pentagon response
- [AP — Hegseth says military cyber forces will guard election systems](https://apnews.com/article/2bfc1417d397db5fda4ad672c0b35ee2) — independent reporting on the Defense Department directive and election-security context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
