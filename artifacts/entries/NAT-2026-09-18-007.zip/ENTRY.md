# Trump announces White House ban on CNN, MS NOW and Politico

**Entry ID:** NAT-2026-09-18-007
**Date:** September 18, 2026
**Checked:** 2026-09-19 12:01 PM EDT
**Evidence state:** Trump's complete retained Truth Social text plus Reuters and two Associated Press reports; announcement and next-day credential enforcement verified, written directive and judicial disposition unresolved
**Review state:** current-standard-reviewed

The announced exclusion was implemented the next morning when reporters' credentials were disabled or confiscated; no written directive or judicial review was public by cutoff.

## THE FACTS

- President Trump posted that he was banning CNN, MS NOW and Politico from the White House 'effective immediately' and said additional news organizations could follow. The post is primary evidence that he announced the exclusion.
- Trump justified the announcement by accusing the outlets of publishing false reports and attacked a past government subscription involving Politico. The accusation and characterization are his stated rationale, not independently established findings of illegality or falsehood.
- Associated Press and Reuters reported that journalists from the three outlets were still working at the White House later Friday afternoon, so the original announcement preceded observed implementation.
- On Saturday morning, Associated Press reported that CNN senior White House reporter Betsy Klein and MS NOW reporter Akayla Gardner were denied entry after their badges were disabled, and that Politico reporter Cheyenne Haslett was denied entry and had her credential confiscated. An MS NOW producer entered while a photographer's badge was also disabled, showing that observed implementation was person-specific rather than a complete documented rule for every employee.
- The three organizations said they would defend their First Amendment rights. No written access directive, judicial ruling, complete credential list or stated duration was public by cutoff.

## SIGNIFICANCE

Disabling and confiscating credentials converts a presidential threat into an implemented access restriction against named national outlets, raising press-access, retaliation and viewpoint-discrimination concerns while the full scope and legal durability remain unresolved.

## GOALPOST / RESPONSE

Trump says the outlets report fiction and should lose access. Credential records, written White House or Secret Service instructions, observed access denials, the scope and duration of any restriction, outlet responses and court review are the tests.

## MAYBE / THEREFORE

Maybe the restriction survives legal challenge or is narrowed to particular credentials, locations or events; it may also be rescinded or enjoined. Therefore named reporters were denied entry and credentials were disabled or confiscated—not that every employee was barred, the outlets' reporting was adjudicated false or the restriction was lawful.


## SOURCES

- [Donald Trump Truth Social post announcing White House press ban](https://truthsocial.com/@realDonaldTrump/117293599348325006) — primary presidential statement
- [Associated Press — Trump announces CNN, MS NOW and Politico White House ban](https://apnews.com/article/bb675679fb10738a51bef90bde6c525a) — independent reporting
- [Reuters — Trump announces media outlets banned from White House](https://www.reuters.com/world/us/trump-bans-media-outlets-cnn-msnow-politico-white-house-2026-09-18/) — independent reporting
- [Associated Press — reporters denied White House access after Trump ban](https://apnews.com/article/trump-ban-ms-now-media-d160e253453229600ce54f8e91351523) — independent on-site reporting and named outlet accounts

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
