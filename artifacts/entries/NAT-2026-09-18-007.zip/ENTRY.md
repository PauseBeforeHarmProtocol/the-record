# Federal judge temporarily blocks White House ban on CNN, MS NOW and Politico

**Entry ID:** NAT-2026-09-18-007
**Date:** September 18–24, 2026
**Checked:** 2026-09-24 6:02 PM EDT
**Evidence state:** Trump's retained posts plus Reuters and Associated Press reporting on the announcement, enforcement, lawsuit, pool response, temporary order, same-day dispute and subsequent restoration; temporary relief and restoration documented, complete order not independently retrieved and appeal and final merits unresolved
**Review state:** current-standard-reviewed

A federal judge ordered immediate restoration of the outlets' passes and barred enforcement for 14 days, finding likely First Amendment and due-process violations; the order is temporary and the merits remain unresolved.

## THE FACTS

- President Trump posted that he was banning CNN, MS NOW and Politico from the White House 'effective immediately' and said additional news organizations could follow. The post is primary evidence that he announced the exclusion.
- Trump justified the announcement by accusing the outlets of publishing false reports and attacked a past government subscription involving Politico. The accusation and characterization are his stated rationale, not independently established findings of illegality or falsehood.
- Associated Press and Reuters reported that journalists from the three outlets were still working at the White House later Friday afternoon, so the original announcement preceded observed implementation.
- On Saturday morning, Associated Press reported that CNN senior White House reporter Betsy Klein and MS NOW reporter Akayla Gardner were denied entry after their badges were disabled, and that Politico reporter Cheyenne Haslett was denied entry and had her credential confiscated. An MS NOW producer entered while a photographer's badge was also disabled, showing that observed implementation was person-specific rather than a complete documented rule for every employee.
- On September 21, CNN, MS NOW and Politico jointly sued Trump and administration officials in the U.S. District Court for the District of Columbia. Reuters and Associated Press reported that the complaint alleges First Amendment viewpoint discrimination and Fifth Amendment due-process violations and seeks a temporary restraining order restoring access. The allegations are not adjudicated findings.
- The case was assigned to U.S. District Judge Timothy Kelly. No temporary restraining order, merits ruling, written access directive, complete credential list or stated duration was public by cutoff.
- Trump responded that the action targets what he calls 'fake news,' not the free press, and described the outlets as a national-security threat. That post is evidence of his stated rationale, not proof that the outlets published falsehoods or created a security threat.
- After CNN was excluded from the traveling television pool, the major television networks suspended participation in White House television-pool operations. Reuters and Associated Press reported the coordinated response; it is an immediate access consequence, not a court ruling or proof that every form of White House coverage stopped.
- On September 24, U.S. District Judge Timothy Kelly issued a 14-day temporary restraining order requiring the administration to return the three outlets' press passes immediately and barring enforcement of the ban while the lawsuit proceeds.
- Reuters reported that Kelly found the outlets likely to succeed on their First Amendment and due-process claims and said the record lacked factual support for the administration's national-security justification. The complete order was not independently retrieved for this update, so the holding is attributed to Reuters and Associated Press reporting rather than described as a final merits judgment.
- Justice Department lawyers argued that White House access is a privilege and that the president may suspend it, and said letters sent after the revocations supplied an adequate explanation. The judge was reported to reject that showing at the temporary-relief stage. The White House did not immediately comment, and no appeal, stay, permanent injunction or final judgment existed by cutoff.
- Hours after the temporary order, CNN, MS NOW and Politico told the court that the administration had not restored their credentials or access and requested an emergency hearing. Reuters and Associated Press reported that the journalists remained unable to enter and that a Secret Service agent confiscated credentials; those are reported compliance facts and party assertions, not a judicial contempt finding.
- The White House did not provide Reuters or Associated Press an immediate explanation for the reported noncompliance. No enforcement order, contempt finding, stay, appeal decision, permanent injunction or final merits judgment existed by the prior cutoff.
- Later September 24, the White House restored the three outlets' credentials and access. A White House official declared that the credential-restoration process began at 7:25 a.m. and that replacement badges reached an entry gate around 9:55 a.m.; after that filing, Judge Kelly denied the outlets' request for an emergency hearing. The restoration resolved the immediate access dispute but did not end the lawsuit, convert the temporary order into a final judgment or establish permanent press-access rules.

## SIGNIFICANCE

The temporary order produced restoration of the three outlets' credentials after a same-day compliance dispute, making the immediate remedy effective. The lawsuit and 14-day order remain temporary, so appeal, written access standards and later rulings still determine the durable press-access rule.

## GOALPOST / RESPONSE

Trump and DOJ say the restriction addresses false reporting and national security and that White House access is a presidential privilege. Kelly found the present record insufficient at the temporary-relief stage, and the White House says it completed restoration that morning. Continued access, resumed pool participation, any appeal or renewed restriction, a preliminary injunction, written procedures and final judgment are the tests.

## MAYBE / THEREFORE

Maybe restoration will remain in place while the parties establish lawful access procedures, or the administration may appeal or impose a revised restriction. Therefore the White House restored the three outlets' credentials after the temporary order—not a permanent access guarantee, final merits judgment or resolution of the constitutional claims.


## SOURCES

- [Donald Trump Truth Social post announcing White House press ban](https://truthsocial.com/@realDonaldTrump/117293599348325006) — primary presidential statement
- [Associated Press — Trump announces CNN, MS NOW and Politico White House ban](https://apnews.com/article/bb675679fb10738a51bef90bde6c525a) — independent reporting
- [Reuters — Trump announces media outlets banned from White House](https://www.reuters.com/world/us/trump-bans-media-outlets-cnn-msnow-politico-white-house-2026-09-18/) — independent reporting
- [Associated Press — reporters denied White House access after Trump ban](https://apnews.com/article/trump-ban-ms-now-media-d160e253453229600ce54f8e91351523) — independent on-site reporting and named outlet accounts
- [Reuters — CNN, MS NOW and Politico sue over White House ban](https://www.reuters.com/world/cnn-ms-now-politico-file-lawsuit-against-trump-administration-over-white-house-2026-09-21/) — independent reporting on the filed federal lawsuit, requested temporary restraining order and unresolved disposition
- [Associated Press — outlets sue over denied White House access](https://apnews.com/article/72f9acf68244ca70e9078d9d3661c722) — independent reporting on the First and Fifth Amendment claims, assigned judge and administration response
- [Donald J. Trump — Truth Social response to press-access dispute](https://truthsocial.com/@realDonaldTrump/117308890736529824) — primary presidential statement; evidence of publication and stated rationale only
- [Reuters — judge temporarily blocks White House media ban](https://www.reuters.com/world/judge-lifts-trumps-white-house-ban-cnn-ms-now-politico-2026-09-24/) — independent legal reporting on the temporary restraining order, parties' arguments and immediate response
- [Associated Press — judge orders restoration of White House access](https://apnews.com/article/trump-media-ban-judge-ruling-cnn-msnow-politico-21605e397fe48f178a4afa037e732c6d) — independent reporting on the temporary restraining order and reported findings
- [Reuters — outlets report White House noncompliance with access order](https://www.reuters.com/world/cnn-politico-ms-now-seek-court-hearing-after-being-barred-white-house-court-2026-09-24/) — independent legal reporting on the outlets' emergency filing and reported continued exclusion
- [Reuters — White House restores CNN, MS NOW and Politico credentials after court order](https://www.reuters.com/business/media-telecom/politico-denied-access-white-house-after-judges-order-news-outlet-says-2026-09-24/) — independent legal reporting containing the White House official's filed restoration timeline and the judge's response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
