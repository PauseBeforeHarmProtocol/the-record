# Trump announces White House ban on CNN, MS NOW and Politico

**Entry ID:** NAT-2026-09-18-007
**Date:** September 18, 2026
**Checked:** 2026-09-18 5:59 PM EDT
**Evidence state:** Trump's complete retained Truth Social text plus independent AP and Reuters reporting; announcement verified, operative implementation not observed by cutoff
**Review state:** current-standard-reviewed

The president said the exclusion was immediate, but reporters from the outlets were still working normally at cutoff and no written access directive was public.

## THE FACTS

- President Trump posted that he was banning CNN, MS NOW and Politico from the White House 'effective immediately' and said additional news organizations could follow. The post is primary evidence that he announced the exclusion.
- Trump justified the announcement by accusing the outlets of publishing false reports and attacked a past government subscription involving Politico. The accusation and characterization are his stated rationale, not independently established findings of illegality or falsehood.
- Associated Press and Reuters reported that journalists from the three outlets were still working at the White House later Friday afternoon. No written access order, revoked credential, Secret Service instruction or observed exclusion had been established by the research cutoff.
- The announcement therefore records a presidential threat to restrict access, not proven implementation. The outlets disputed Trump's characterizations or continued their work; no court or administrative ruling on the announced ban existed at cutoff.

## SIGNIFICANCE

A presidential announcement excluding named national outlets from the White House raises press-access, retaliation and viewpoint-discrimination concerns even before implementation, while the lack of an operative directive makes the immediate practical effect uncertain.

## GOALPOST / RESPONSE

Trump says the outlets report fiction and should lose access. Credential records, written White House or Secret Service instructions, observed access denials, the scope and duration of any restriction, outlet responses and court review are the tests.

## MAYBE / THEREFORE

Maybe the statement becomes an enforced credential ban, or it may remain rhetoric that staff never implement or later narrow. Therefore Trump announced an immediate ban on three outlets—not that access had actually been revoked, that their reporting was adjudicated false or that a lawful exclusion was established.


## SOURCES

- [Donald Trump Truth Social post announcing White House press ban](https://truthsocial.com/@realDonaldTrump/117293599348325006) — primary presidential statement
- [Associated Press — Trump announces CNN, MS NOW and Politico White House ban](https://apnews.com/article/bb675679fb10738a51bef90bde6c525a) — independent reporting
- [Reuters — Trump announces media outlets banned from White House](https://www.reuters.com/world/us/trump-bans-media-outlets-cnn-msnow-politico-white-house-2026-09-18/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
