# Press-access ban remains enjoined while DOJ probes television-pool response

**Entry ID:** NAT-2026-09-18-007
**Date:** September 18–October 13, 2026
**Checked:** 2026-10-14 12:01 AM EDT
**Evidence state:** public federal docket and independent Associated Press reporting on the October 13 preliminary injunction, plus named Justice Department confirmation independently reported by Reuters and AP; interim access relief operative, antitrust inquiry active and neither track finally resolved
**Review state:** current-standard-reviewed

A preliminary injunction keeps CNN, MS NOW and Politico credentials restored while the separate antitrust inquiry into the networks' response remains unresolved.

## THE FACTS

- President Trump posted that he was banning CNN, MS NOW and Politico from the White House 'effective immediately' and said additional news organizations could follow. The post is primary evidence that he announced the exclusion.
- Trump justified the announcement by accusing the outlets of publishing false reports and attacked a past government subscription involving Politico. The accusation and characterization are his stated rationale, not independently established findings of illegality or falsehood.
- Associated Press and Reuters reported that journalists from the three outlets were still working at the White House later Friday afternoon, so the original announcement preceded observed implementation.
- On Saturday morning, Associated Press reported that CNN senior White House reporter Betsy Klein and MS NOW reporter Akayla Gardner were denied entry after their badges were disabled, and that Politico reporter Cheyenne Haslett was denied entry and had her credential confiscated. An MS NOW producer entered while a photographer's badge was also disabled, showing that observed implementation was person-specific rather than a complete documented rule for every employee.
- On September 21, CNN, MS NOW and Politico jointly sued Trump and administration officials in the U.S. District Court for the District of Columbia. Reuters and Associated Press reported that the complaint alleges First Amendment viewpoint discrimination and Fifth Amendment due-process violations and seeks a temporary restraining order restoring access. The allegations are not adjudicated findings.
- The case was assigned to U.S. District Judge Timothy Kelly. No temporary restraining order, merits ruling, written access directive, complete credential list or stated duration was public by cutoff.
- Trump responded that the action targets what he calls 'fake news,' not the free press, and described the outlets as a national-security threat. That post is evidence of his stated rationale, not proof that the outlets published falsehoods or created a security threat.
- After CNN was excluded from the traveling television pool, the major television networks suspended participation in White House television-pool operations. Reuters and Associated Press reported the coordinated response; it is an immediate access consequence, not a court ruling or proof that every form of White House coverage stopped.
- On September 24, U.S. District Judge Timothy Kelly issued a 14-day temporary restraining order requiring the administration to return the three outlets' press passes immediately and barring enforcement of the ban while the lawsuit proceeds.
- Reuters reported that Kelly found the outlets likely to succeed on their First Amendment and due-process claims and said the record lacked factual support for the administration's national-security justification. The complete order was not independently retrieved for this update, so the holding is attributed to Reuters and Associated Press reporting rather than described as a final merits judgment.
- Justice Department lawyers argued that White House access is a privilege and that the president may suspend it, and said letters sent after the revocations supplied an adequate explanation. The judge was reported to reject that showing at the temporary-relief stage. The White House did not immediately comment, and no appeal, stay, permanent injunction or final judgment existed by cutoff.
- Hours after the temporary order, CNN, MS NOW and Politico told the court that the administration had not restored their credentials or access and requested an emergency hearing. Reuters and Associated Press reported that the journalists remained unable to enter and that a Secret Service agent confiscated credentials; those are reported compliance facts and party assertions, not a judicial contempt finding.
- The White House did not provide Reuters or Associated Press an immediate explanation for the reported noncompliance. No enforcement order, contempt finding, stay, appeal decision, permanent injunction or final merits judgment existed by the prior cutoff.
- Later September 24, the White House restored the three outlets' credentials and access. A White House official declared that the credential-restoration process began at 7:25 a.m. and that replacement badges reached an entry gate around 9:55 a.m.; after that filing, Judge Kelly denied the outlets' request for an emergency hearing. The restoration resolved the immediate access dispute but did not end the lawsuit, convert the temporary order into a final judgment or establish permanent press-access rules.
- On September 25, the major television networks resumed White House pool coverage. Reuters reported that CBS was assigned to a White House event and CNN planned coverage at the National Archives after the credentials were restored. The resumption is an observed implementation consequence, not a final court judgment or a guarantee against later restrictions.
- In an update published September 26, AP reported that Friday-night White House guidance replaced CNN with Real America’s Voice for the September 26 Air Force One trip to Knoxville. This records the issued assignment, not independent observation of completed travel or a contempt finding. AP distinguished restored ground passes from disputed pool access; plaintiffs’ lawyer Theodore Boutrous said the temporary order covered the pool, while the White House did not answer AP’s specific request for comment.
- Late September 28, CNN, MS NOW and Politico asked Judge Kelly for a preliminary injunction preserving their White House access until final judgment. The motion is a request for longer interim relief, not an order granting it; the temporary restraining order, its application to pool assignments and the merits remain unresolved.
- On October 10, the Justice Department said its Antitrust Division was investigating ABC, CBS, CNN, Fox News and NBC over their coordinated September suspension of White House television-pool coverage. DOJ spokesperson Emily Covington said group boycotts among commercial competitors can violate the Sherman Act and described the inquiry as an effort to determine whether the networks violated antitrust law. Reuters and Associated Press independently reported the department's statement.
- The five networks had resumed pool coverage after the September 24 credential restoration. No complaint, indictment, civil enforcement action, subpoena, court finding or network violation was public in the material reviewed by cutoff. Reuters reported that the networks did not immediately respond; AP reported that the Committee to Protect Journalists said the inquiry risked intimidating outlets defending press access.
- Late October 13, Judge Timothy Kelly granted a preliminary injunction barring officials other than the president from enforcing the September 18 credential revocations while the case proceeds. Associated Press reported that Kelly found the plaintiffs likely to succeed on First Amendment viewpoint-discrimination and Fifth Amendment due-process claims. Those are preliminary findings supporting interim relief, not a final merits judgment; the court also stated that its ruling did not establish that concerns about media accuracy or genuine classified-information risks are unfounded.

## SIGNIFICANCE

The preliminary injunction extends operative press-access protection beyond the earlier temporary order, while the Justice Department's separate inquiry continues to target the networks' coordinated response to the ban. The parallel tracks create a consequential test of viewpoint neutrality, due process, press independence and antitrust enforcement; neither a final constitutional judgment nor an antitrust violation has been established.

## GOALPOST / RESPONSE

DOJ says it is neutrally testing whether a competitor group boycott violated the Sherman Act; press advocates say the inquiry could intimidate outlets defending access. The tests are the investigation's legal theory and process, any subpoenas or compulsory demands, an enforcement decision, judicial review, network responses, the pending access case and whether pool operations or reporting change.

## MAYBE / THEREFORE

Maybe the networks' coordinated halt presents an ordinary antitrust question and the government can ultimately justify neutral access standards, or the court may find the restrictions retaliatory while the inquiry proves weak. Therefore the record establishes a preliminary injunction and an active DOJ investigation—not a final First Amendment judgment, antitrust violation, charge, complaint or punishment.


## SOURCES

- [Donald Trump Truth Social post announcing White House press ban](https://truthsocial.com/@realDonaldTrump/117293599348325006) — primary presidential statement
- [Associated Press — Trump announces CNN, MS NOW and Politico White House ban](https://apnews.com/article/bb675679fb10738a51bef90bde6c525a) — independent reporting
- [Reuters — Trump announces media outlets banned from White House](https://www.reuters.com/world/us/trump-bans-media-outlets-cnn-msnow-politico-white-house-2026-09-18/) — independent reporting
- [Associated Press — reporters denied White House access after Trump ban](https://apnews.com/article/trump-ban-ms-now-media-d160e253453229600ce54f8e91351523) — independent on-site reporting and named outlet accounts
- [Reuters — CNN, MS NOW and Politico sue over White House ban](https://www.reuters.com/world/cnn-ms-now-politico-file-lawsuit-against-trump-administration-over-white-house-2026-09-21/) — independent reporting on the filed federal lawsuit, requested temporary restraining order and unresolved disposition
- [Associated Press — outlets sue over denied White House access](https://apnews.com/article/72f9acf68244ca70e9078d9d3661c722) — independent reporting on the First and Fifth Amendment claims, assigned judge and administration response
- [Donald J. Trump — Truth Social response to press-access dispute](https://truthsocial.com/@realDonaldTrump/117308890736529824) — primary presidential statement; evidence of publication and stated rationale only
- [Reuters — judge temporarily blocks White House media ban](https://www.reuters.com/world/judge-lifts-trumps-white-house-ban-cnn-ms-now-politico-2026-09-24/) — independent legal reporting on the temporary restraining order, parties' arguments and immediate response
- [Associated Press — judge orders restoration of White House access](https://apnews.com/article/trump-media-ban-judge-ruling-cnn-msnow-politico-21605e397fe48f178a4afa037e732c6d) — independent reporting on the temporary restraining order and reported findings
- [Reuters — outlets report White House noncompliance with access order](https://www.reuters.com/world/cnn-politico-ms-now-seek-court-hearing-after-being-barred-white-house-court-2026-09-24/) — independent legal reporting on the outlets' emergency filing and reported continued exclusion
- [Reuters — White House restores CNN, MS NOW and Politico credentials after court order](https://www.reuters.com/business/media-telecom/politico-denied-access-white-house-after-judges-order-news-outlet-says-2026-09-24/) — independent legal reporting containing the White House official's filed restoration timeline and the judge's response
- [Television networks resume White House pool coverage after credentials restored](https://www.reuters.com/legal/government/tv-networks-resume-coverage-trump-events-cnn-says-2026-09-25/) — independent implementation and consequence reporting
- [White House TV pool resumes but CNN replaced on Air Force One assignment](https://www.news4jax.com/news/politics/2026/09/25/white-house-tv-pool-appears-to-be-back-in-operation-but-cnns-media-analyst-calls-situation-fluid/) — news report
- [CNN, MS NOW and Politico ask judge to extend block on White House ban](https://www.reuters.com/legal/government/cnn-ms-now-politico-ask-judge-extend-block-white-house-ban-2026-09-29/) — independent reporting
- [Reuters — Justice Department investigates White House television pool](https://www.reuters.com/business/media-telecom/justice-department-probes-tv-networks-over-trump-pool-coverage-new-york-times-2026-10-10/) — independent reporting with named Justice Department response
- [Associated Press — DOJ investigates White House television pool](https://apnews.com/article/trump-press-pool-antitrust-687c09a2377e7033c0b452c893c46e12) — independent reporting with named Justice Department response and press-advocacy reaction
- [Cable News Network, Inc. v. Trump docket, No. 1:26-cv-03287](https://www.courtlistener.com/docket/74823502/cable-news-network-inc-v-trump/) — public federal docket for the White House press-access litigation
- [Associated Press — preliminary injunction blocks White House press-access ban](https://apnews.com/article/1a023a8890e8d25d5d293862f4cd47af) — independent court reporting, preliminary findings and government position

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
