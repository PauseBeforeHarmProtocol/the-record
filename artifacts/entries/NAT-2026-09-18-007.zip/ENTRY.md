# Trump announces White House ban on CNN, MS NOW and Politico

**Entry ID:** NAT-2026-09-18-007
**Date:** September 18, 2026
**Checked:** 2026-09-21 6:01 PM EDT
**Evidence state:** Trump's retained posts plus Reuters and Associated Press reporting on the announcement, credential enforcement, filed lawsuit and television-pool suspension; restriction implemented and litigation filed, emergency and merits disposition unresolved
**Review state:** current-standard-reviewed

The outlets sued after reporters' credentials were disabled or confiscated, and television networks suspended pool operations; no emergency or merits ruling existed by cutoff.

## THE FACTS

- President Trump posted that he was banning CNN, MS NOW and Politico from the White House 'effective immediately' and said additional news organizations could follow. The post is primary evidence that he announced the exclusion.
- Trump justified the announcement by accusing the outlets of publishing false reports and attacked a past government subscription involving Politico. The accusation and characterization are his stated rationale, not independently established findings of illegality or falsehood.
- Associated Press and Reuters reported that journalists from the three outlets were still working at the White House later Friday afternoon, so the original announcement preceded observed implementation.
- On Saturday morning, Associated Press reported that CNN senior White House reporter Betsy Klein and MS NOW reporter Akayla Gardner were denied entry after their badges were disabled, and that Politico reporter Cheyenne Haslett was denied entry and had her credential confiscated. An MS NOW producer entered while a photographer's badge was also disabled, showing that observed implementation was person-specific rather than a complete documented rule for every employee.
- On September 21, CNN, MS NOW and Politico jointly sued Trump and administration officials in the U.S. District Court for the District of Columbia. Reuters and Associated Press reported that the complaint alleges First Amendment viewpoint discrimination and Fifth Amendment due-process violations and seeks a temporary restraining order restoring access. The allegations are not adjudicated findings.
- The case was assigned to U.S. District Judge Timothy Kelly. No temporary restraining order, merits ruling, written access directive, complete credential list or stated duration was public by cutoff.
- Trump responded that the action targets what he calls 'fake news,' not the free press, and described the outlets as a national-security threat. That post is evidence of his stated rationale, not proof that the outlets published falsehoods or created a security threat.
- After CNN was excluded from the traveling television pool, the major television networks suspended participation in White House television-pool operations. Reuters and Associated Press reported the coordinated response; it is an immediate access consequence, not a court ruling or proof that every form of White House coverage stopped.

## SIGNIFICANCE

The litigation turns an implemented press-access restriction into an active constitutional dispute, while the television-pool suspension shows an immediate operational consequence beyond the three named outlets. Access remains restricted and independent pooled coverage is disrupted while emergency relief and the merits are unresolved.

## GOALPOST / RESPONSE

Trump says the restriction protects against false reporting and a national-security threat; the outlets say it is viewpoint discrimination imposed without due process. The complaint, government response, emergency order, evidentiary record, written access policy, restoration of pool operations, final judgment and actual restoration or continued denial are the tests.

## MAYBE / THEREFORE

Maybe a court will require restored access, uphold some credential discretion or narrow relief to particular reporters or events; the administration or networks may also alter their positions before judgment. Therefore the outlets filed constitutional claims and networks suspended pool participation—not that the claims have been proven, access was restored or the restriction was held lawful or unlawful.


## SOURCES

- [Donald Trump Truth Social post announcing White House press ban](https://truthsocial.com/@realDonaldTrump/117293599348325006) — primary presidential statement
- [Associated Press — Trump announces CNN, MS NOW and Politico White House ban](https://apnews.com/article/bb675679fb10738a51bef90bde6c525a) — independent reporting
- [Reuters — Trump announces media outlets banned from White House](https://www.reuters.com/world/us/trump-bans-media-outlets-cnn-msnow-politico-white-house-2026-09-18/) — independent reporting
- [Associated Press — reporters denied White House access after Trump ban](https://apnews.com/article/trump-ban-ms-now-media-d160e253453229600ce54f8e91351523) — independent on-site reporting and named outlet accounts
- [Reuters — CNN, MS NOW and Politico sue over White House ban](https://www.reuters.com/world/cnn-ms-now-politico-file-lawsuit-against-trump-administration-over-white-house-2026-09-21/) — independent reporting on the filed federal lawsuit, requested temporary restraining order and unresolved disposition
- [Associated Press — outlets sue over denied White House access](https://apnews.com/article/72f9acf68244ca70e9078d9d3661c722) — independent reporting on the First and Fifth Amendment claims, assigned judge and administration response
- [Donald J. Trump — Truth Social response to press-access dispute](https://truthsocial.com/@realDonaldTrump/117308890736529824) — primary presidential statement; evidence of publication and stated rationale only

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
