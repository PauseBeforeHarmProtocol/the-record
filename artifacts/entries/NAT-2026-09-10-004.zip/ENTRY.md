# DHS proposes removing the 60-day post-employment grace period for specified work visas

**Entry ID:** NAT-2026-09-10-004
**Date:** September 10–11, 2026
**Checked:** 2026-09-11 5:58 AM EDT
**Evidence state:** complete primary proposed rule inspected after formal Federal Register publication; proposal and November 10 comment deadline verified, current grace period unchanged
**Review state:** current-standard-reviewed

The formally published proposal covers eight classifications and dependents; it has not removed the existing grace period.

## THE FACTS

- DHS placed proposed rule USCIS-2026-0364 on public inspection September 10 and formally published it in the Federal Register on September 11. It proposes deleting 8 CFR 214.1(l)(2), the discretionary grace period of up to 60 days after qualifying employment or activity ends.
- The affected classifications are E-1, E-2, E-3, H-1B, H-1B1, L-1, O-1 and TN, together with their dependents. DHS says departure would be required upon cessation of the qualifying employment or activity unless the person is otherwise authorized to remain lawfully.
- Comments are due November 10, 2026. The notice is not a final rule, an effective removal of the current grace period or an individual deportation order.
- DHS acknowledges changing policy and potential reliance interests. Its accounting statement does not estimate annualized monetized costs or benefits and identifies possible employer productivity losses, relocation costs and agency removal-proceeding work.

## SIGNIFICANCE

If finalized, the change would narrow time available after job loss to pursue another lawful employment or immigration option and could affect dependents and employer recruitment. These are prospective institutional consequences, not measured departures or job gains.

## GOALPOST / RESPONSE

DHS argues that ending the grace period better aligns status with qualifying employment and reduces adjudication complexity. It acknowledges worker, employer and community reliance but says its statutory-alignment and administrative goals outweigh those interests. Comments, final text, adjudication workload, mobility and actual costs would test that rationale.

## MAYBE / THEREFORE

Maybe closer alignment between status and employment simplifies administration, or eliminating transition time could disrupt workers, families and recruiting while adding removal costs. Therefore this is a proposed change with stated exceptions and unresolved effects—not immediate cancellation of existing protections or demonstrated benefits to American workers.


## SOURCES

- [DHS — Eliminating the Discretionary 60-day Grace Period, USCIS-2026-0364](https://www.federalregister.gov/documents/2026/09/11/2026-18631/eliminating-the-discretionary-60-day-grace-period) — primary Federal Register proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
