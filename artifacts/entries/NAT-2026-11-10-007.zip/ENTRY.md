# Trump signs Medicare ultralightweight-wheelchair payment law

**Entry ID:** NAT-2026-11-10-007
**Date:** November 10, 2026
**Checked:** 2026-11-11 12:05 AM EST
**Evidence state:** White House signature announcement and primary enrolled statutory text; law enacted, coding implementation and access, cost and health outcomes unresolved
**Review state:** current-standard-reviewed

H.R. 1703 requires separate base codes by 2028 and allows beneficiaries to pay the upgrade difference; implementation and access effects are pending.

## THE FACTS

- The White House announced that President Trump signed H.R. 1703, the Choices for Increased Mobility Act of 2026, into law on November 10. The page was published at 4:03 p.m. EST, before the prior archive boundary; no exact signing time was stated, so this is a same-day retrospective discovery rather than a claimed post-boundary signature.
- The enrolled text requires the Medicare program, by January 1, 2028, to maintain at least two base billing codes for ultralightweight manual wheelchairs: one for titanium or carbon-fiber frames and one for other materials.
- Medicare will pay the otherwise applicable amount for a covered ultralightweight wheelchair, while a supplier may charge a beneficiary the difference for titanium or carbon-fiber construction. The Centers for Medicare & Medicaid Services may require notice before purchase or rental explaining the beneficiary’s potential liability.
- The statute changes future coding and payment choices; it does not establish new codes today, require a beneficiary to buy an upgraded frame, prove lower total costs or measure wheelchair access and health outcomes.

## SIGNIFICANCE

The law creates a nationwide Medicare pathway for distinguishing higher-cost ultralightweight wheelchair materials while permitting beneficiary payment of the upgrade difference. Access, pricing, notice quality and supplier behavior will depend on CMS implementation.

## GOALPOST / RESPONSE

Supporters say separate codes preserve patient choice and access to lighter mobility equipment without making Medicare pay the full upgrade cost. The tests are CMS coding and notice rules, supplier prices, beneficiary out-of-pocket costs, utilization, denials, appeals and mobility outcomes after 2028.

## MAYBE / THEREFORE

Maybe the new coding pathway expands access to equipment that better meets individual mobility needs, or added beneficiary liability may preserve choice mainly for people able to pay. Therefore the record establishes an enacted future payment framework—not current implementation, guaranteed access, lower prices or measured health benefit.


## SOURCES

- [White House — H.R. 997, H.R. 1703, H.R. 1945 and H.R. 7730 signed into law](https://www.whitehouse.gov/briefings-statements/2026/11/congressional-bills-h-r-997-h-r-1703-h-r-1945-and-h-r-7730-signed-into-law/) — primary announcement of presidential signatures and short descriptions
- [GovInfo — enrolled text of H.R. 1703](https://www.govinfo.gov/content/pkg/BILLS-119hr1703enr/html/BILLS-119hr1703enr.htm) — primary enrolled legislation changing Medicare coding and beneficiary-liability rules for ultralightweight manual wheelchairs

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
