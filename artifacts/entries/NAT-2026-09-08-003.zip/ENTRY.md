# Treasury publishes final temporary car-loan-interest deduction rules

**Entry ID:** NAT-2026-09-08-003
**Date:** July 27–September 8, 2026
**Checked:** 2026-09-08 12:01 AM EDT
**Evidence state:** primary Treasury/IRS final regulations and statutory background in the Federal Register; approval, publication, eligibility definitions and effective date documented, uptake and effects unmeasured
**Review state:** current-standard-reviewed

The regulations define eligibility for a deduction of up to $10,000 and lender reporting duties; they take effect November 9 and do not guarantee any taxpayer's savings.

## THE FACTS

- Treasury and the IRS approved final regulations on July 27 and published them September 8 to implement the 2025 law's deduction for qualified passenger-vehicle loan interest and related lender reporting requirements; the regulations take effect November 9.
- For tax years beginning after 2024 and before 2029, qualifying taxpayers may deduct up to $10,000 per return without itemizing for interest on debt incurred after 2024 to buy a new, U.S.-assembled passenger vehicle secured by a first lien.
- The deduction phases down by $200 for each $1,000 or fraction above modified adjusted gross income of $100,000, or $200,000 for a married couple filing jointly. The rules define personal use as expected use by the taxpayer or specified family members more than 50% of the ownership period and generally do not require later reevaluation.
- The regulations treat certain directly related financed costs such as sales taxes, service plans and extended warranties as potentially eligible debt, while excluding unrelated property and services. They also require businesses receiving at least $600 of annual interest on a specified loan to report information to the IRS and borrower.
- The underlying deduction is statutory and already applies to eligible tax years; the final regulations clarify administration. Publication does not establish how many taxpayers will qualify, the average tax reduction, lender compliance costs, vehicle-purchase effects or whether benefits outweigh fiscal cost.

## SIGNIFICANCE

The regulations turn a temporary tax preference enacted in 2025 into detailed nationwide eligibility and reporting rules affecting borrowers, lenders and vehicle sales. Final definitions determine which loans and financed costs receive the benefit, while distributional, fiscal and market effects remain unmeasured.

## GOALPOST / RESPONSE

Treasury says the rules reduce uncertainty and facilitate claims and reporting. Filed returns, deduction uptake and amounts, income distribution, lender error and burden, audit results, federal revenue effects, vehicle prices and U.S.-assembly and purchasing responses are the tests.

## MAYBE / THEREFORE

Maybe clear rules make a congressionally enacted deduction accessible and support U.S.-assembled vehicle purchases, or the benefit may mainly subsidize borrowing that would have occurred anyway while adding reporting costs. Therefore the record establishes final regulations effective November 9—not universal eligibility, a $10,000 tax saving for each borrower or a demonstrated manufacturing or affordability effect.


## SOURCES

- [Federal Register — Car Loan Interest Deduction](https://www.federalregister.gov/documents/2026/09/08/2026-18219/car-loan-interest-deduction) — primary final regulations, TD 10054, approved July 27 and published September 8

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
