# CMS proposes broad Medicare and Medicaid provider deregulation

**Entry ID:** NAT-2026-11-10-011
**Date:** November 5–10, 2026
**Checked:** 2026-11-11 12:02 PM EST
**Evidence state:** Federal Register proposal, CMS fact sheet and independent provider-association summary; proposed, with finalization, savings and patient outcomes unresolved
**Review state:** current-standard-reviewed

The CARE proposal would remove obstetric-training, respiratory-reporting and payment-transparency requirements while revising safety codes.

## THE FACTS

- CMS issued the CARE proposal on November 5 and the Federal Register published it on November 10, both before the prior archive boundary. This release records a retrospective discovery. Comments are due January 11, 2027.
- The proposal would remove recently adopted hospital and critical-access-hospital training and obstetric quality requirements, end ongoing weekly respiratory-illness reporting for long-term-care facilities, remove specified COVID-19 vaccine education and offering requirements, and rescind facility-level Medicaid institutional payment-transparency reporting.
- The proposal also would adopt 2024 fire and health-care-facility code editions with exceptions, allow additional emergency-power sources, remove certain exterior-window and door requirements, and codify waiver authority. CMS estimates about $320 million in average annual savings and more than 3.26 million provider staff hours returned.
- CMS says existing accreditation, professional standards and revised codes can preserve safety while reducing burdens. America’s Essential Hospitals summarized the provider conditions affected. The package is proposed, not final, and the agency’s savings, safety and care-quality effects have not been independently measured.

## SIGNIFICANCE

The 134-page proposal would revise national participation conditions across hospitals, nursing facilities and other Medicare and Medicaid providers, trading specified reporting and training requirements for flexibility and estimated savings. Patient-safety, workforce and transparency effects remain to be tested.

## GOALPOST / RESPONSE

CMS says the changes will return clinical time to patient care without impeding quality. The tests are final provisions, implementation dates, compliance costs, maternal and infection-control measures, emergency readiness, Medicaid payment transparency, accreditation findings and patient outcomes.

## MAYBE / THEREFORE

Maybe removing duplicative requirements lets providers redirect staff time without weakening safety because other standards remain, or rescinding training, reporting and transparency rules may reduce visibility and safeguards. Therefore the record establishes a broad proposed deregulatory package and agency savings estimate—not final repeal, realized savings or proven neutral effects on care quality.


## SOURCES

- [Federal Register — Cutting Administrative Requirements for Excellence in Patient Care proposed rule](https://www.federalregister.gov/documents/2026/11/10/2026-22812/medicare-and-medicaid-programs-cutting-administrative-requirements-for-excellence-in-patient-care) — primary proposed rule; complete notice and impact analysis inspected
- [CMS — CARE proposed-rule fact sheet](https://www.cms.gov/newsroom/fact-sheets/medicare-medicaid-programs-cutting-administrative-requirements-excellence-patient-care-care-cms-3484) — primary agency summary and stated burden estimate
- [America's Essential Hospitals — CMS proposes to reform participation conditions](https://essentialhospitals.org/cms-proposes-to-reform-conditions-of-participation/) — independent provider-association summary of the proposed changes

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
