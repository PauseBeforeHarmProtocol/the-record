# Trump orders conditional mortgage-cost pilots and manufactured-housing review

**Entry ID:** NAT-2026-10-22-001
**Date:** October 22, 2026
**Checked:** 2026-10-22 6:03 PM EDT
**Evidence state:** signed White House executive order plus Reuters reporting on its scope and housing-market context; implementation rules, borrower savings, supply effects and risk outcomes were not available by cutoff
**Review state:** current-standard-reviewed

The signed order directs or conditionally authorizes mortgage-insurance cancellation, nationwide title-risk review and a 180-day factory-built-housing process; savings and housing-supply effects remain unmeasured.

## THE FACTS

- Trump signed an executive order directing the Federal Housing Finance Agency director, if the director makes specified public-interest, enterprise-interest and safety-and-soundness determinations, to have Fannie Mae and Freddie Mac establish a pilot for mortgages originated after the pilot begins. The program would use automated valuations and other data to identify borrowers who appear eligible for proactive mortgage-insurance cancellation.
- Cancellation would still require applicable equity, payment-history, contractual, statutory and safety-and-soundness conditions. The order also tells servicers, where lawful and operationally feasible, to notify potentially eligible borrowers and reduce unnecessary appraisal, documentation and administrative barriers; it does not cancel insurance for every existing borrower.
- The order creates a HUD- and FHFA-led Task Force on Manufactured Housing Innovation and requires recommendations within 180 days on cross-agency standards, reciprocal approvals, federal financing and removal of duplicative reviews. It also calls for evaluation of grant incentives for standardized state and local permitting; those incentives and legislative changes were not enacted by the order.
- FHFA is also directed, subject to its own findings and applicable law, to expand an automated title-review pilot into a nationwide ongoing program for eligible refinance transactions. Reuters reported separate directions to Agriculture and Veterans Affairs to reduce rates on eligible department-backed single-family loans.
- Reuters placed the order against record-low September pending-home sales, declining single-family starts and permits, and mortgage rates above 7 percent. Those market measures predate implementation and do not establish that the order reduced prices, rates, premiums, refinancing costs or construction by cutoff.

## SIGNIFICANCE

The order begins several federal housing-finance and permitting workstreams that could lower transaction costs for eligible borrowers or expand factory-built supply, but key FHFA findings, program rules and task-force recommendations remain ahead. Affordability effects depend on eligibility, adoption, risk controls, rate changes, construction and pass-through to households.

## GOALPOST / RESPONSE

The administration says the measures will reduce mortgage, insurance, title and construction costs while preserving safety, quality and consumer protection. The tests are published eligibility rules, borrower notifications and cancellations, realized fees and rate changes, task-force recommendations, state and local uptake, housing starts and prices, default or title-loss experience, and distribution of benefits.

## MAYBE / THEREFORE

Maybe automated valuation, title review and standardized factory-built approvals remove avoidable costs, or narrow eligibility and local constraints may limit savings while shifting valuation, title or credit risk. Therefore the record establishes a signed order and conditional implementation duties—not universal insurance cancellation, enacted local permitting reform or measured housing affordability gains.


## SOURCES

- [White House — Decreasing Housing Costs for the American People executive order](https://www.whitehouse.gov/presidential-actions/2026/10/decreasing-housing-costs-for-the-american-people/) — signed executive order establishing conditional mortgage-insurance and title-review programs and a manufactured-housing task force
- [Reuters — Trump signs order aimed at reducing single-family housing costs](https://www.reuters.com/world/us/trump-signs-executive-order-aimed-reducing-housing-costs-2026-10-22/) — independent reporting on the signed order, housing-market context and implementation limits

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
