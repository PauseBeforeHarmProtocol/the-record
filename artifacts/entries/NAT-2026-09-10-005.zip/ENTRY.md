# Fifth Circuit rejects constitutional bond-hearing right as Supreme Court reviews statutory dispute

**Entry ID:** NAT-2026-09-10-005
**Date:** September 10–October 23, 2026
**Checked:** 2026-10-23 6:01 PM EDT
**Evidence state:** published en banc Fifth Circuit opinion plus independent Reuters reporting; constitutional habeas relief reversed, separate statutory Supreme Court review pending
**Review state:** current-standard-reviewed

The en banc court reversed habeas relief for three detainees; the separate Supreme Court case concerns statutory interpretation, not this constitutional holding.

## THE FACTS

- On September 10, the Fourth Circuit affirmed habeas relief in the consolidated appeals of Oscar Enrique Lopez Garcia and Juan Jose Rivera, Nos. 25-7044 and 25-7050. Judge Berner wrote for a 2–1 majority joined by Judge Keenan; Judge Rushing dissented.
- The majority held that 8 U.S.C. § 1226 governs these long-resident petitioners, who entered without inspection, rather than mandatory detention under § 1225(b)(2)(A). They must have an opportunity to seek release at a bond hearing pending removal proceedings.
- The opinion describes the administration’s July 2025 shift to interpreting the statute to require detention throughout removal proceedings for people who entered without inspection. The majority relied on statutory text, structure, regulations and constitutional-avoidance principles; the dissent read the statute to mandate detention.
- The ruling affirms relief for these petitioners and establishes Fourth Circuit precedent. Bond-hearing eligibility does not guarantee release, grant lawful immigration status or resolve removal proceedings; the opinion acknowledges a circuit split.
- On October 1, the Supreme Court granted the government's petition for certiorari in Rhoney v. Ricardo Aparecido Barbosa da Cunha, No. 26-104, to review the statutory detention question implicated by the Fourth Circuit's ruling.
- The grant places the dispute on the Court's merits docket. It is not a merits ruling, does not itself stay the Fourth Circuit decision, does not order universal detention or release and does not resolve any person's removal case.
- On October 23, the en banc Fifth Circuit ruled 10–7 in Sosnava Rodriguez v. Vergara that three people detained under 8 U.S.C. § 1225(b)(2)(A) were not constitutionally entitled to individualized dangerousness or flight-risk hearings during removal proceedings. It reversed the district-court judgments and vacated their habeas relief, displacing a July panel ruling that had required hearings within 90 days.
- The constitutional holding governs federal courts in Texas, Louisiana and Mississippi unless altered by later review. Reuters noted that the Supreme Court's separate pending case addresses the statutory detention question, not the Fifth Amendment issue decided here. The ruling does not itself decide any removal case outside the consolidated petitioners or guarantee that the Supreme Court will adopt the same constitutional analysis.

## SIGNIFICANCE

The 10–7 en banc ruling removes a constitutional bond-hearing route in the Fifth Circuit while the Supreme Court considers a related but distinct statutory dispute. It materially narrows detention challenges in a circuit containing major immigration-detention populations without resolving the nationwide statutory question.

## GOALPOST / RESPONSE

The administration says Congress made detention mandatory and no additional constitutional process is due; detainees argue prolonged custody without individualized review permits arbitrary confinement. Rehearing or Supreme Court review, the separate statutory merits decision, detention duration, hearing access and individual case outcomes are the tests.

## MAYBE / THEREFORE

Maybe Congress's mandatory-detention scheme supplies all process constitutionally required for people never lawfully admitted, as the en banc majority held, or prolonged custody may demand individualized review, as the dissenters argued. Therefore the Fifth Circuit has rejected the constitutional hearing claim for these cases—not resolved the separate statutory question nationwide or every future as-applied detention challenge.


## SOURCES

- [Fourth Circuit — Lopez Garcia and Rivera v. Guadian, Nos. 25-7044 and 25-7050](https://www.ca4.uscourts.gov/opinions/257044.P.pdf) — primary published majority and dissenting opinions
- [Supreme Court docket — Rhoney v. Ricardo Aparecido Barbosa da Cunha, No. 26-104](https://www.supremecourt.gov/docket/docketfiles/html/public/26-104.html) — primary docket and certiorari grant
- [Associated Press — Supreme Court takes immigration bond-hearing dispute](https://apnews.com/article/ice-immigration-detention-supreme-court-f8ee63bcb11f1be3d7d6300022f3bc88) — independent reporting on certiorari grant and case posture
- [Fifth Circuit — en banc opinion in Sosnava Rodriguez v. Vergara](https://www.ca5.uscourts.gov/opinions/pub/26/26-50183-CV1.pdf) — primary published en banc judicial opinion
- [Reuters — Fifth Circuit rejects constitutional bond-hearing right](https://www.reuters.com/legal/government/detained-migrants-have-no-constitutional-right-bond-hearings-us-court-rules-2026-10-23/) — independent legal reporting on en banc ruling and jurisdictional consequences

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
