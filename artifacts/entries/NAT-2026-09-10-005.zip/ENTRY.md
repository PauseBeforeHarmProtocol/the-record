# Supreme Court will review Fourth Circuit bond-hearing ruling

**Entry ID:** NAT-2026-09-10-005
**Date:** September 10–October 1, 2026
**Checked:** 2026-10-01 12:04 PM EDT
**Evidence state:** primary Supreme Court docket showing certiorari granted, plus independent case reporting; review granted, merits and remedy unresolved
**Review state:** current-standard-reviewed

The justices granted review of a circuit split over mandatory detention; they did not decide the merits, stay the ruling or order anyone released.

## THE FACTS

- On September 10, the Fourth Circuit affirmed habeas relief in the consolidated appeals of Oscar Enrique Lopez Garcia and Juan Jose Rivera, Nos. 25-7044 and 25-7050. Judge Berner wrote for a 2–1 majority joined by Judge Keenan; Judge Rushing dissented.
- The majority held that 8 U.S.C. § 1226 governs these long-resident petitioners, who entered without inspection, rather than mandatory detention under § 1225(b)(2)(A). They must have an opportunity to seek release at a bond hearing pending removal proceedings.
- The opinion describes the administration’s July 2025 shift to interpreting the statute to require detention throughout removal proceedings for people who entered without inspection. The majority relied on statutory text, structure, regulations and constitutional-avoidance principles; the dissent read the statute to mandate detention.
- The ruling affirms relief for these petitioners and establishes Fourth Circuit precedent. Bond-hearing eligibility does not guarantee release, grant lawful immigration status or resolve removal proceedings; the opinion acknowledges a circuit split.
- On October 1, the Supreme Court granted the government's petition for certiorari in Rhoney v. Ricardo Aparecido Barbosa da Cunha, No. 26-104, to review the statutory detention question implicated by the Fourth Circuit's ruling.
- The grant places the dispute on the Court's merits docket. It is not a merits ruling, does not itself stay the Fourth Circuit decision, does not order universal detention or release and does not resolve any person's removal case.

## SIGNIFICANCE

The certiorari grant makes the statutory detention question a Supreme Court merits case after the Fourth Circuit preserved individualized bond-hearing eligibility for the covered petitioners. It does not itself change the governing rule, create a nationwide result or establish who will ultimately be released.

## GOALPOST / RESPONSE

The government argues that people present without lawful admission remain applicants for admission subject to mandatory detention; the respondents defend the Fourth Circuit's reading that section 1226 permits bond hearings. The tests are the Supreme Court's eventual opinion, any interim stay, implementation in the Fourth Circuit and actual hearing outcomes—not the grant of review alone.

## MAYBE / THEREFORE

Maybe the Court will adopt the government's mandatory-detention reading, or it may preserve individualized bond review for long-resident people in removal proceedings. Therefore the new established fact is Supreme Court review of the circuit split—not a merits reversal, a nationwide detention rule, guaranteed release or an end to removal proceedings.


## SOURCES

- [Fourth Circuit — Lopez Garcia and Rivera v. Guadian, Nos. 25-7044 and 25-7050](https://www.ca4.uscourts.gov/opinions/257044.P.pdf) — primary published majority and dissenting opinions
- [Supreme Court docket — Rhoney v. Ricardo Aparecido Barbosa da Cunha, No. 26-104](https://www.supremecourt.gov/docket/docketfiles/html/public/26-104.html) — primary docket and certiorari grant
- [Associated Press — Supreme Court takes immigration bond-hearing dispute](https://apnews.com/article/ice-immigration-detention-supreme-court-f8ee63bcb11f1be3d7d6300022f3bc88) — independent reporting on certiorari grant and case posture

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
