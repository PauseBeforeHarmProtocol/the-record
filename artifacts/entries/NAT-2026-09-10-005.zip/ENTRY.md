# Fourth Circuit affirms bond-hearing eligibility for two long-resident immigration detainees

**Entry ID:** NAT-2026-09-10-005
**Date:** September 10, 2026
**Checked:** 2026-09-10 5:57 PM EDT
**Evidence state:** primary published appellate majority and dissent inspected; district-court habeas relief affirmed, bond eligibility not automatic release
**Review state:** current-standard-reviewed

A divided panel rejects mandatory no-bond detention for these petitioners; it does not order universal release or end immigration detention.

## THE FACTS

- On September 10, the Fourth Circuit affirmed habeas relief in the consolidated appeals of Oscar Enrique Lopez Garcia and Juan Jose Rivera, Nos. 25-7044 and 25-7050. Judge Berner wrote for a 2–1 majority joined by Judge Keenan; Judge Rushing dissented.
- The majority held that 8 U.S.C. § 1226 governs these long-resident petitioners, who entered without inspection, rather than mandatory detention under § 1225(b)(2)(A). They must have an opportunity to seek release at a bond hearing pending removal proceedings.
- The opinion describes the administration’s July 2025 shift to interpreting the statute to require detention throughout removal proceedings for people who entered without inspection. The majority relied on statutory text, structure, regulations and constitutional-avoidance principles; the dissent read the statute to mandate detention.
- The ruling affirms relief for these petitioners and establishes Fourth Circuit precedent. Bond-hearing eligibility does not guarantee release, grant lawful immigration status or resolve removal proceedings; the opinion acknowledges a circuit split.

## SIGNIFICANCE

The decision limits the administration’s no-bond interpretation in this circuit and preserves individualized consideration for people in the covered circumstances. It increases the importance of subsequent appellate review and actual access to hearings; neither a nationwide end to detention nor aggregate releases are established.

## GOALPOST / RESPONSE

The government argues that people present without lawful admission remain applicants for admission subject to mandatory detention. Rushing’s dissent supports that reading from statutory text, context and history and argues longstanding nonenforcement cannot alter Congress’s command. Subsequent appellate decisions and hearing access, rather than assumptions about automatic release, are the tests.

## MAYBE / THEREFORE

Maybe individualized bond hearings adequately address flight and safety risks while respecting liberty, or higher courts may accept the government’s reading that Congress mandated detention for this category. Therefore the established result is an appellate affirmance of these habeas grants and bond-hearing eligibility—not guaranteed release, an end to removal or a nationwide final resolution.


## SOURCES

- [Fourth Circuit — Lopez Garcia and Rivera v. Guadian, Nos. 25-7044 and 25-7050](https://www.ca4.uscourts.gov/opinions/257044.P.pdf) — primary published majority and dissenting opinions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
