# Judge permanently blocks DOJ immigration conditions on two public-safety grant programs

**Entry ID:** NAT-2026-11-04-001
**Date:** November 4, 2026
**Checked:** 2026-11-04 6:02 PM EST
**Evidence state:** Reuters report of an on-record bench ruling, official DOJ grant notices and a state filing announcement; written ruling or transcript not retrieved
**Review state:** current-standard-reviewed

A reported bench ruling permanently enjoins specified immigration-cooperation conditions; the written order was not retrieved by cutoff.

## THE FACTS

- On November 4, Chief U.S. District Judge John J. McConnell Jr. ruled from the bench for 22 states and the District of Columbia in State of New Jersey et al. v. U.S. Department of Justice et al., No. 1:25-cv-00404 (D.R.I.). Reuters reported that he struck immigration-related conditions from two Justice Department grant programs and permanently enjoined their implementation.
- The ruling covered the Byrne State Crisis Intervention Program and grants administered by the Office of Juvenile Justice and Delinquency Prevention. The challenged terms treated programs as outside scope if they failed to give federal agents access to detained immigrants suspected of unlawful presence or to notify the Department of Homeland Security about releases.
- Reuters reported McConnell said Congress's formula-grant structure constrained DOJ's authority to add the conditions. The written order, hearing transcript and final judgment were not retrieved by cutoff, so the archive records a reported bench ruling and permanent injunction rather than attributing uninspected written findings.
- The ruling did not adjudicate every Justice Department grant condition. Byrne Justice Assistance Grant conditions were outside this dispute because DOJ said earlier first-term injunctions already blocked them, and DOJ had abandoned the original Victims of Crime Act conditions after the states sued.
- DOJ did not respond to Reuters's request for comment after the ruling. Its grant notice framed the conditions as excluding programs that violate or impede federal immigration law; New Jersey Attorney General Jennifer Davenport welcomed the ruling as protecting congressionally authorized public-safety funding.
- No appeal, stay, written merits opinion or post-ruling award-disbursement evidence was located by cutoff. The operative status recorded here is a reported district-court permanent injunction on the two identified programs, subject to later docket and appellate developments.

## SIGNIFICANCE

The ruling limits the administration's attempt to use congressionally structured public-safety grants to obtain state immigration-enforcement cooperation. Its practical reach is important but bounded: it concerns two identified programs and the plaintiff jurisdictions, and the result may change if DOJ appeals or obtains a stay.

## GOALPOST / RESPONSE

DOJ's own funding notice characterized noncooperation with federal immigration enforcement as outside program scope; the department gave Reuters no post-ruling comment. The tests are the written judgment, any appeal or stay, revised award terms and actual grant disbursement—not the bench report alone.

## MAYBE / THEREFORE

Maybe an appeal narrows or stays the injunction, or DOJ identifies narrower conditions authorized by a different statute. Therefore the archive records a reported district-court permanent injunction affecting two programs, not a nationwide invalidation of every immigration-related grant condition or a final appellate resolution.


## SOURCES

- [Reuters — U.S. judge rules DOJ cannot link states' grant funding to immigration enforcement](https://www.reuters.com/legal/government/us-judge-rules-doj-cannot-link-states-grant-funding-immigration-enforcement-2026-11-04/) — independent report of bench ruling, permanent injunction, affected programs, stated reasoning and party responses
- [New Jersey Attorney General — amended challenge to DOJ public-safety grant conditions](https://www.njoag.gov/ag-davenport-co-leads-fight-to-protect-law-enforcement-funding/) — primary state filing announcement describing plaintiffs, challenged programs and requested relief
- [Office of Justice Programs — Byrne State Crisis Intervention Formula Program notice](https://www.ojp.gov/funding/docs/bja-2025-172582.pdf) — primary grant notice stating program goals and challenged immigration-related out-of-scope conditions
- [Office of Justice Programs — legal notices for immigration-related grant conditions](https://www.ojp.gov/funding/explore/legal-notices) — primary agency legal-notice page identifying affected award conditions and prior injunction limits

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
