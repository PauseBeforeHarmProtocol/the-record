# NTSB flight data indicates a late go-around attempt before fatal Miami cargo overrun

**Entry ID:** NAT-2026-09-06-001
**Date:** September 6–9, 2026
**Checked:** 2026-09-09 6:00 AM EDT
**Evidence state:** primary NTSB investigation page plus Reuters and Associated Press reporting on the agency's preliminary briefing; investigation opened and consequences reported, probable cause and corrective action pending
**Review state:** current-standard-reviewed

Five people were killed and five injured; the federal investigation is ongoing and has not determined probable cause.

## THE FACTS

- The National Transportation Safety Board opened investigation DCA26MA352 after 21 Air Flight 7598, a Boeing 767-33A operating a Part 121 cargo flight from San Juan, overran Runway 30 at Miami International Airport on September 6. The agency deployed a go-team and lists the investigation as ongoing.
- Associated Press reported that the aircraft struck a cleaning-service van after leaving the runway, killing five people in the van and injuring five others. By September 8, two injured people were reported in critical condition and one in stable condition; those are reported human consequences, not an NTSB probable-cause determination.
- NTSB's preliminary flight-data account said the main and nose gear touched down at about 158 and 134 knots, respectively; the brakes were then released and throttles increased in a sequence consistent with initiating a go-around, before the throttles returned to idle and braking resumed. Reuters and AP reported no recorded deployment of the speed brakes or thrust reversers. The sequence is preliminary evidence, not a finding about crew fault or the crash's cause.
- Investigators were still reviewing the flight-data and cockpit-voice recorders and planned pilot interviews. AP reported that the aircraft traveled roughly 1,300 feet beyond the runway; Miami had a 1,000-foot runway safety area and no engineered-material arresting system, but the airport met the applicable FAA buffer standard. The final NTSB report and any resulting FAA, airport, carrier or manufacturer action remain pending.

## SIGNIFICANCE

The crash caused five deaths and triggered a major federal transportation-safety investigation. Preliminary recorder data narrows the sequence under review, but safety recommendations, responsibility and systemic implications depend on the completed investigation.

## GOALPOST / RESPONSE

NTSB's role is to determine probable cause and issue safety recommendations, while FAA and the operator may act on identified hazards. The tests are recorder analysis, interviews, wreckage and runway evidence, a preliminary and final report, probable-cause findings, recommendations and any implemented operational, training, aircraft or airport-safety changes.

## MAYBE / THEREFORE

Maybe the late throttle and braking sequence reflects a crew decision central to the overrun, or aircraft, runway, weather and organizational factors may alter that interpretation. Therefore the record establishes the fatal overrun, the reported casualties and preliminary flight-data sequence—not probable cause, negligence or the adequacy of any particular safety system.


## SOURCES

- [NTSB — Miami Boeing 767 cargo overrun investigation DCA26MA352](https://www.ntsb.gov/investigations/Pages/DCA26MA352.aspx) — primary federal investigation page; investigation ongoing and no probable-cause finding
- [Reuters — flight data suggests late go-around consideration before Miami cargo crash](https://www.reuters.com/business/aerospace-defense/evidence-suggests-pilots-considered-aborting-landing-miami-cargo-plane-crash-2026-09-09/) — independent reporting on NTSB's preliminary flight-data briefing; not a final cause finding
- [Associated Press — investigators review fatal Miami cargo-plane overrun](https://apnews.com/article/amazon-cargo-plane-crash-miami-airport-victims-6c23909e94ea2faedd28071749fc00e3) — independent reporting on casualties, flight data, runway conditions and the ongoing investigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
