# NTSB cockpit recording adds speed comments and warnings before fatal Miami cargo overrun

**Entry ID:** NAT-2026-09-06-001
**Date:** September 6–9, 2026
**Checked:** 2026-09-10 12:02 AM EDT
**Evidence state:** primary NTSB investigation page plus Reuters and Associated Press reporting on preliminary recorder briefings; investigation, casualties and recorded sequence documented, probable cause and corrective action pending
**Review state:** current-standard-reviewed

The preliminary recording adds an unstable-approach sequence to the investigation; it does not establish probable cause or individual fault.

## THE FACTS

- The National Transportation Safety Board opened investigation DCA26MA352 after 21 Air Flight 7598, a Boeing 767-33A operating a Part 121 cargo flight from San Juan, overran Runway 30 at Miami International Airport on September 6. The agency lists the investigation as ongoing.
- Associated Press reported that the aircraft struck ground vehicles after leaving the runway, killing five people and injuring five. Those consequences do not establish the cause of the crash.
- NTSB's preliminary flight-data account said the main and nose gear touched down at about 158 and 134 knots; brakes were released and throttles increased in a sequence consistent with a go-around, before throttles returned to idle and braking resumed. Reuters and AP reported no recorded deployment of speed brakes or thrust reversers.
- In a September 9 cockpit-recording update reported by Reuters, one unidentified pilot repeatedly commented that the aircraft was too fast in the final 1 minute 42 seconds, while the other did not give a consistent verbal response. Automated 'sink rate' and 'too low terrain' warnings sounded before touchdown.
- Reuters reported that one pilot called for aborting the landing about 15 seconds after touchdown, followed by increased thrust consistent with a go-around; four seconds later the throttles returned to idle and sounds followed consistent with leaving the paved surface. Investigators interviewed both pilots, but NTSB had not determined why the approach continued or issued a probable-cause finding.

## SIGNIFICANCE

The recording adds evidence about approach stability, cockpit communication and the timing of the attempted go-around in a crash that killed five people. Responsibility, causal weight and any systemic safety implications depend on the full investigation rather than isolated preliminary cues.

## GOALPOST / RESPONSE

NTSB's role is to determine probable cause and issue safety recommendations, while FAA and the operator may act on identified hazards. The tests are authenticated recorder analysis, interviews, wreckage and runway evidence, a preliminary and final report, probable-cause findings, recommendations and any implemented operational, training, aircraft or airport changes.

## MAYBE / THEREFORE

Maybe the speed comments, warnings and late thrust change identify a breakdown in approach and crew coordination, or aircraft, runway, weather and organizational factors may materially change that interpretation. Therefore the record establishes the reported cockpit and flight-data sequence—not negligence, individual blame or probable cause.


## SOURCES

- [NTSB — Miami Boeing 767 cargo overrun investigation DCA26MA352](https://www.ntsb.gov/investigations/Pages/DCA26MA352.aspx) — primary federal investigation page; investigation ongoing and no probable-cause finding
- [Reuters — flight data suggests late go-around consideration before Miami cargo crash](https://www.reuters.com/business/aerospace-defense/evidence-suggests-pilots-considered-aborting-landing-miami-cargo-plane-crash-2026-09-09/) — independent reporting on NTSB's preliminary flight-data briefing; not a final cause finding
- [Associated Press — investigators review fatal Miami cargo-plane overrun](https://apnews.com/article/amazon-cargo-plane-crash-miami-airport-victims-6c23909e94ea2faedd28071749fc00e3) — independent reporting on casualties, flight data, runway conditions and the ongoing investigation
- [Reuters — NTSB cockpit recording details speed comments and warnings before Miami overrun](https://www.reuters.com/business/aerospace-defense/one-pilot-flagged-excessive-speed-before-miami-cargo-crash-ntsb-says-2026-09-09/) — independent reporting on NTSB's preliminary cockpit-voice-recording update; not a probable-cause finding

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
