# Administration launches seafood strategy and $5 billion processing-loan guarantee program

**Entry ID:** NAT-2026-10-23-004
**Date:** October 23, 2026
**Checked:** 2026-10-24 12:02 AM EDT
**Evidence state:** White House, USDA, NOAA and HHS/FDA primary releases plus Associated Press corroboration; strategy and loan availability launched, guidance proposed, import alerts reported, outcome claims unmeasured
**Review state:** current-standard-reviewed

The strategy, loan availability and import-alert actions are active; voluntary origin-label guidance remains draft, and no loan award or industry outcome is yet measured.

## THE FACTS

- The White House and NOAA released the America First Seafood Strategy and launched Seafood.gov. NOAA said the strategy uses existing statutory authorities and programs rather than creating a new spending initiative; it calls for regulatory changes, domestic production and processing, import verification, market access and public messaging.
- USDA said it is making at least $5 billion available through the SPUR Guaranteed Loan Program for meat, poultry and seafood processing. The program offers commercial lenders a 90% federal guarantee, caps an eligible borrower's guaranteed loan at $175 million and may allow a two-year deferral of principal and interest; no loan award, obligation or completed project was documented by cutoff.
- FDA issued draft guidance for a voluntary U.S.-origin seafood label and encouraged comments by December 13 under docket FDA-2026-D-6729. The label guidance is proposed rather than final or mandatory.
- FDA also reported that 46% of products in its latest imported-seafood sampling were short-weighted by as much as 32.8% and that it placed 11 foreign firms on Import Alert. Those figures and enforcement actions are agency-reported; the inspected release did not independently establish the sampling frame, market prevalence or consumer-price effect.
- Associated Press independently confirmed the announced strategy, website, label proposal and $5 billion loan availability. The administration described economic, health and supply-chain benefits, but no production, employment, export, price, safety or sustainability outcome was measured by cutoff.

## SIGNIFICANCE

The package joins a formal federal strategy, a large loan-guarantee channel, proposed labeling and import enforcement across multiple agencies. It can materially influence processing finance and trade oversight, while its benefits and costs depend on actual lending, final guidance, enforcement consistency and measured industry outcomes.

## GOALPOST / RESPONSE

The administration says the package will expand domestic processing, distinguish U.S. seafood, combat unfair imports and improve health and food security. The tests are loan applications and awards, federal exposure and defaults, completed capacity, final labeling guidance, import-alert dispositions, production and prices, labor and environmental compliance, and independently measured consumer or coastal-community effects.

## MAYBE / THEREFORE

Maybe loan guarantees and clearer origin information expand competitive domestic processing, or they may shift credit risk and favor incumbent producers without lowering prices or improving sustainability. Therefore the record establishes a launched strategy, available guarantee program, draft label guidance and reported import alerts—not $5 billion spent, completed facilities, a mandatory label or proven economic and health gains.


## SOURCES

- [White House — America First Seafood Strategy and Seafood.gov fact sheet](https://www.whitehouse.gov/fact-sheets/2026/10/fact-sheet-president-donald-j-trump-announces-the-america-first-seafood-strategy-and-seafood-gov/) — primary administration announcement; prospective benefit claims are not measured outcomes
- [USDA — $5 billion SPUR guaranteed-loan program expansion](https://usda.azureedge.us/about-usda/news/press-releases/2026/10/23/trump-administration-announces-5-billion-spur-guaranteed-loan-program-expand-processing-american) — primary program announcement with guarantee percentage, borrower cap and eligibility terms
- [NOAA — America First Seafood Strategy release](https://www.noaa.gov/news-release/trump-administration-releases-america-first-seafood-strategy) — primary agency strategy description distinguishing existing authorities from new spending
- [HHS/FDA — draft U.S.-origin seafood-label guidance and import sampling enforcement](https://www.hhs.gov/press-room/fda-advances-america-first-seafood-strategy-us-origin-labeling.html) — primary agency announcement of proposed voluntary guidance and reported implemented import-alert action
- [Associated Press — October 23 live national updates](https://apnews.com/article/4b43d8df0f4d7666de64f272f7b81ae7) — independent live reporting on the nursing-home initiative, seafood package, embassy drawdown and presidential remarks

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
