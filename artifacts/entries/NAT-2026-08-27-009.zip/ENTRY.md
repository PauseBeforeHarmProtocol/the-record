# DOJ announces race-discrimination finding against GW medical school admissions

**Entry ID:** NAT-2026-08-27-009
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 PM EDT
**Evidence state:** official DOJ announcement of a completed Civil Rights Division investigation; agency finding announced, supporting record and university response not public by cutoff, settlement or litigation pending
**Review state:** current-standard-reviewed

The Civil Rights Division says its investigation found intentional discrimination in the 2024 and 2025 classes; settlement talks are underway and no court has adjudicated the finding.

## THE FACTS

- The Justice Department’s Civil Rights Division announced an investigative finding that George Washington University School of Medicine and Health Sciences intentionally discriminated by race in admissions to its 2024 and 2025 incoming classes, in violation of Title VI and the Supreme Court’s 2023 Students for Fair Admissions decision. This is an agency finding, not a court judgment.
- DOJ says the school used essay responses and other information to infer race after university guidance barred preferences based on race boxes, and says Black applicants had a significantly higher probability of receiving interviews and higher interview scores than comparable Asian applicants. It also alleges that some Black and Hispanic applicants with lower MCAT scores were admitted over white and Asian applicants.
- DOJ says it is pursuing a voluntary resolution and will sue if negotiations fail. The announcement did not link a findings letter or disclose the underlying admissions data, and no public response from the university was identified by the checked time; the allegations therefore remain disputed and untested in court.

## SIGNIFICANCE

The finding extends the administration’s post-affirmative-action enforcement campaign into medical-school admissions and creates a possible path to negotiated admissions changes, threatened litigation, or federal-funding consequences. Its credibility and impact depend on disclosure of the analysis, the school’s response, and any agreement or judicial review.

## GOALPOST / RESPONSE

DOJ says the school used race proxies to prioritize racial diversity over merit and that Title VI requires race-neutral admissions. The strongest unresolved response is evidentiary: the public announcement did not provide the underlying data or a findings letter, and the university had not publicly answered by the cutoff. A released record, the school’s rebuttal, settlement terms, a complaint, discovery, and a court ruling are the tests.

## MAYBE / THEREFORE

Maybe a fuller record will substantiate DOJ’s statistical and intent findings and produce lawful admissions changes, or missing context and alternative explanations may weaken them. Therefore the record attributes every contested conclusion to DOJ and does not treat an executive-branch finding as an adjudicated violation, a patient-safety finding, or proof about individual applicants.


## SOURCES

- [Justice Department — GW medical-school admissions investigation finding](https://www.justice.gov/opa/pr/justice-department-finds-george-washington-university-medical-school-discriminates-based) — official Civil Rights Division investigative finding and enforcement-status announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
