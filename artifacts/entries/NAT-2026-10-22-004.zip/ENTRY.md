# Trump directs Defense Production Act support for petroleum capacity

**Entry ID:** NAT-2026-10-22-004
**Date:** October 22, 2026
**Checked:** 2026-10-22 6:03 PM EDT
**Evidence state:** signed White House presidential determination plus Reuters reporting on authority, funding context and the absence of named projects; no award, obligation or capacity result was identified
**Review state:** current-standard-reviewed

The determination authorizes the Secretary of War to use Section 303 purchases, commitments and financial instruments for oil production, refining and logistics, without naming a funded project.

## THE FACTS

- Trump signed a presidential determination finding domestic petroleum production, refining and logistics—including exploration, pipelines, storage and marine terminals—essential to national defense and finding that industry cannot provide the needed capacity in time without presidential action because of financing, lead-time, permitting, infrastructure and supply-chain constraints.
- The determination waives specified Section 303 prerequisites and authorizes and directs the Secretary of War to implement it through necessary purchases, purchase commitments and financial instruments. It supersedes inconsistent provisions of prior presidential instruments but does not itself identify a recipient, project, award, obligation or expenditure.
- Reuters reported that the authority can support oil-related activity, pipelines and liquid-fuel storage; Congress had provided $1 billion in Defense Production Act funding for energy-related projects deemed critical to national security. Available authority is not proof that any portion was obligated under this determination by cutoff.
- The document repeats an April 20 petroleum-capacity determination directed to the Energy secretary but gives the implementation direction here to the Secretary of War. It is also distinct from the September 8 delegation order in NAT-2026-09-08-009, which changed general priority and allocation authority without selecting a project or making this Section 303 finding.
- Reuters noted that the memorandum names no project and reported the action amid higher oil and diesel prices and a prior vice-presidential statement about using the Act for a Texas refinery. The record does not infer that the refinery received an award or that the determination increased production, refining capacity or fuel supply.

## SIGNIFICANCE

The determination supplies a presidential finding and waiver needed for Defense Production Act financial support and shifts an implementation channel to the military department. Its practical scale depends on later project selection, contractual terms, appropriations, permitting, construction and production—not the signature alone.

## GOALPOST / RESPONSE

The administration says immediate federal support is necessary to prevent petroleum-capacity shortfalls that could impair defense readiness. The tests are disclosed solicitations, awards and obligations; recipient and project terms; added production, refining, storage or transport capacity; completion schedules; costs; environmental and permitting compliance; and defense-supply outcomes.

## MAYBE / THEREFORE

Maybe targeted DPA financing accelerates genuinely defense-critical bottlenecks, or broad petroleum eligibility may subsidize projects that industry would otherwise finance without producing timely readiness gains. Therefore the record establishes an operative authority and direction—not a named award, spent $1 billion, completed capacity or lower fuel prices.


## SOURCES

- [White House — Defense Production Act determination on petroleum capacity](https://www.whitehouse.gov/presidential-actions/2026/10/presidential-determination-pursuant-to-section-303-of-the-defense-production-act-of-1950-as-amended-on-domestic-petroleum-production-refining-and-logistics-capacity-c139/) — signed presidential determination authorizing Section 303 purchases, commitments and financial instruments
- [Reuters — Trump invokes Defense Production Act for petroleum capacity](https://www.reuters.com/business/energy/trump-invokes-cold-war-era-defense-production-act-oil-production-refining-2026-10-22/) — independent energy-policy reporting on the determination, available funding and absence of named projects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
