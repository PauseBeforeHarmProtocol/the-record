# Trump directs Defense Production Act support for petroleum capacity

**Entry ID:** NAT-2026-10-22-004
**Date:** October 22, 2026
**Checked:** 2026-10-23 11:59 AM EDT
**Evidence state:** signed White House determination, official DOE funding-plan announcement and Reuters context; authority and planned funding documented, with selection, obligation and capacity results unresolved
**Review state:** current-standard-reviewed

DOE separately announced plans for up to $150 million in DPA funding for refinery restart and biofuel capacity, while project selection, awards and obligations remain pending.

## THE FACTS

- Trump signed a presidential determination finding domestic petroleum production, refining and logistics—including exploration, pipelines, storage and marine terminals—essential to national defense and finding that industry cannot provide the needed capacity in time without presidential action because of financing, lead-time, permitting, infrastructure and supply-chain constraints.
- The determination waives specified Section 303 prerequisites and authorizes and directs the Secretary of War to implement it through necessary purchases, purchase commitments and financial instruments. It supersedes inconsistent provisions of prior presidential instruments but does not itself identify a recipient, project, award, obligation or expenditure.
- Reuters reported that the authority can support oil-related activity, pipelines and liquid-fuel storage; Congress had provided $1 billion in Defense Production Act funding for energy-related projects deemed critical to national security. Available authority is not proof that any portion was obligated under this determination by cutoff.
- The document repeats an April 20 petroleum-capacity determination directed to the Energy secretary but gives the implementation direction here to the Secretary of War. It is also distinct from the September 8 delegation order in NAT-2026-09-08-009, which changed general priority and allocation authority without selecting a project or making this Section 303 finding.
- Reuters noted that the memorandum names no project and reported the action amid higher oil and diesel prices and a prior vice-presidential statement about using the Act for a Texas refinery. The record does not infer that the refinery received an award or that the determination increased production, refining capacity or fuel supply.
- In a separate October 22 implementation announcement recovered in this review, the Energy Department said it planned to make up to $150 million in Defense Production Act Title III funding available to restart a U.S. refinery and expand biofuel production capacity. DOE said its selection process was underway and projected millions of additional gallons per day, but did not identify a selected recipient, executed award, obligation or completed capacity.

## SIGNIFICANCE

The determination supplies legal authority and DOE's $150 million plan identifies a concrete funding ceiling and project categories. The announcement remains pre-award: practical scale depends on selection, contract terms, obligation, permitting, restart work and actual production.

## GOALPOST / RESPONSE

The administration says the planned funding will restart refining and expand biofuel output for national defense and energy security. A published solicitation or selection, named recipients, executed awards and obligations, project milestones, added daily output, costs, compliance and defense-supply outcomes are the tests.

## MAYBE / THEREFORE

Maybe targeted DPA financing accelerates genuinely defense-critical capacity, or selected projects may be delayed, subsidize activity that would occur anyway or miss projected output. Therefore the record establishes an operative authority and an announced funding plan of up to $150 million—not a selected award, obligated money, restarted refinery or added production.


## SOURCES

- [White House — Defense Production Act determination on petroleum capacity](https://www.whitehouse.gov/presidential-actions/2026/10/presidential-determination-pursuant-to-section-303-of-the-defense-production-act-of-1950-as-amended-on-domestic-petroleum-production-refining-and-logistics-capacity-c139/) — signed presidential determination authorizing Section 303 purchases, commitments and financial instruments
- [Reuters — Trump invokes Defense Production Act for petroleum capacity](https://www.reuters.com/business/energy/trump-invokes-cold-war-era-defense-production-act-oil-production-refining-2026-10-22/) — independent energy-policy reporting on the determination, available funding and absence of named projects
- [Energy Department — planned $150 million DPA refinery and biofuel funding](https://www.energy.gov/articles/energy-department-use-defense-production-act-funding-restart-american-refinery-and-expand) — official funding-plan announcement with selection still pending

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
