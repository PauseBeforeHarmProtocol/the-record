# Treasury and IRS propose foreign-income deduction-allocation rules under the 2025 tax law

**Entry ID:** NAT-2026-09-11-003
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 AM EDT
**Evidence state:** complete primary proposed rule inspected; statutory implementation formally proposed, final text and fiscal or behavioral effects unresolved
**Review state:** current-standard-reviewed

The proposal interprets statutory changes affecting section 951A income and foreign-derived deduction-eligible income; comments are due November 10.

## THE FACTS

- Treasury and the Internal Revenue Service published proposed regulations on September 11 addressing allocation and apportionment of deductions to foreign-source section 951A category income and to foreign-derived deduction-eligible income. Comments and requests for a public hearing are due November 10, 2026.
- The proposal implements amendments enacted in the 2025 budget reconciliation law for taxable years beginning after December 31, 2025. It would affect taxpayers operating through foreign corporations and domestic corporations claiming a deduction based on foreign-derived deduction-eligible income.
- For foreign tax credit calculations, the underlying statute provides that interest and research-and-experimental expenses are not allocated or apportioned to foreign-source section 951A category income and limits other deductions to those directly allocable to that income; the proposal supplies detailed allocation mechanics.
- Treasury and IRS classified the proposal as non-significant and certified that it would not impose a significant economic impact on a substantial number of small entities beyond the underlying statute. It remains proposed and does not establish a final taxpayer liability, revenue result or behavioral effect.

## SIGNIFICANCE

The mechanics determine how multinational income and deductions enter foreign tax credit limits and a major corporate tax deduction. Small wording choices can materially affect liability, but the final text, revenue effects and taxpayer responses are unresolved.

## GOALPOST / RESPONSE

Treasury and IRS say the proposal faithfully implements Congress's 2025 changes and provides administrable allocation rules without significant new small-entity costs. Comments, final regulations, revenue estimates, audits, litigation and observed tax-planning behavior are the tests.

## MAYBE / THEREFORE

Maybe the rules reduce ambiguity and align deductions with Congress's design, or detailed allocation choices may create new planning opportunities and unequal burdens. Therefore this is a formal tax proposal open to comment—not a final rule, assessed bill, collected revenue or measured economic result.


## SOURCES

- [Treasury and IRS — Allocation of deductions to foreign-source section 951A income and deduction-eligible income](https://www.federalregister.gov/documents/2026/09/11/2026-18645/allocation-and-apportionment-of-deductions-to-foreign-source-section-951a-category-income-and) — primary Federal Register proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
