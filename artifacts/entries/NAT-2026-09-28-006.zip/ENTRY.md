# Administration asks Supreme Court to restore transgender-prison restrictions

**Entry ID:** NAT-2026-09-28-006
**Date:** September 28, 2026
**Checked:** 2026-09-28 5:55 PM EDT
**Evidence state:** two independent reports describing the filed emergency application, lower-court order, appellate stay denial and administration response; Supreme Court disposition pending
**Review state:** current-standard-reviewed

The emergency application seeks to lift an order requiring continued hormone therapy, consideration of surgery and specified social accommodations while litigation proceeds.

## THE FACTS

- The Justice Department filed an emergency Supreme Court application seeking to lift U.S. District Judge Royce Lamberth's order blocking portions of a Bureau of Prisons policy affecting transgender prisoners while litigation proceeds.
- The challenged policy bars gender-affirming surgery and hormone therapy and restricts specified social accommodations while continuing psychiatric services. Lamberth found the policy likely arbitrary and capricious and said the agency appeared to have reverse-engineered its rationale.
- The U.S. Court of Appeals for the D.C. Circuit denied interim relief on September 18. The Supreme Court had not ruled on the new application by cutoff, so the district-court protections remained in place.
- The administration argues that BOP may prioritize mental-health treatment and consider prison security and administration. The filing does not establish that the Supreme Court accepted those arguments or restored the restrictions.

## SIGNIFICANCE

The application moves a federal-prison medical-policy dispute to the Supreme Court's emergency docket. It is a request for interim relief, not a Supreme Court merits ruling or implementation of the contested restrictions.

## GOALPOST / RESPONSE

The administration frames the policy as a medical-priority, security and prison-management judgment. The lower court found the explanation likely legally inadequate. The Supreme Court's response, merits litigation, individual medical decisions and documented health or safety outcomes are the tests.

## MAYBE / THEREFORE

Maybe BOP has legitimate discretion to allocate care and manage security, or the categorical restrictions may lack a reasoned medical and administrative basis. Therefore the record verifies the emergency request and continuing lower-court order without treating either side's medical claims as finally adjudicated.


## SOURCES

- [Trump administration asks Supreme Court to allow restrictions on transgender inmates](https://www.reuters.com/legal/government/trump-administration-asks-supreme-court-allow-restrictions-transgender-inmates-2026-09-28/) — independent reporting
- [Trump administration asks Supreme Court to let prison restrictions on transgender care take effect](https://www.cbsnews.com/news/trump-supreme-court-transgender-inmate-treatments-bureau-of-prisons/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
