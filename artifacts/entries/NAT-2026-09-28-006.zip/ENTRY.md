# Supreme Court leaves transgender-prison protections in place

**Entry ID:** NAT-2026-09-28-006
**Date:** September 28–October 21, 2026
**Checked:** 2026-10-21 11:57 AM EDT
**Evidence state:** Reuters and Associated Press independently reported the Supreme Court's emergency denial, dissent and continuing lower-court order; merits litigation remains unresolved
**Review state:** current-standard-reviewed

The justices denied the administration's emergency request to lift a lower-court order requiring continued care and specified accommodations while the case proceeds.

## THE FACTS

- The Justice Department filed an emergency Supreme Court application seeking to lift U.S. District Judge Royce Lamberth's order blocking portions of a Bureau of Prisons policy affecting transgender prisoners while litigation proceeds.
- The challenged policy bars gender-affirming surgery and hormone therapy and restricts specified social accommodations while continuing psychiatric services. Lamberth found the policy likely arbitrary and capricious and said the agency appeared to have reverse-engineered its rationale.
- The U.S. Court of Appeals for the D.C. Circuit denied interim relief on September 18. On October 21, the Supreme Court denied the Justice Department's emergency application, leaving the district-court protections in place while litigation continues. Justices Clarence Thomas and Samuel Alito dissented.
- The administration argues that BOP may prioritize mental-health treatment and consider prison security and administration. The Supreme Court's unsigned emergency disposition did not decide the case's merits, but it rejected the request to restore the restrictions at this stage.

## SIGNIFICANCE

The denial preserves individualized care and specified accommodations during the litigation and is a concrete loss for the administration on emergency relief. It is not a final merits judgment or a ruling that every requested treatment must be provided.

## GOALPOST / RESPONSE

The administration frames the policy as a medical-priority, security and prison-management judgment. The lower court found the explanation likely legally inadequate, and the emergency request failed. Merits rulings, individual medical decisions and documented health or safety outcomes remain the tests.

## MAYBE / THEREFORE

Maybe BOP has legitimate discretion to allocate care and manage security, or the categorical restrictions may lack a reasoned medical and administrative basis. Therefore the record establishes that the Supreme Court left the lower-court protections in force at the emergency stage—not a final adjudication of every medical claim or prison-policy question.


## SOURCES

- [Trump administration asks Supreme Court to allow restrictions on transgender inmates](https://www.reuters.com/legal/government/trump-administration-asks-supreme-court-allow-restrictions-transgender-inmates-2026-09-28/) — independent reporting
- [Trump administration asks Supreme Court to let prison restrictions on transgender care take effect](https://www.cbsnews.com/news/trump-supreme-court-transgender-inmate-treatments-bureau-of-prisons/) — independent reporting
- [Reuters — Supreme Court leaves transgender-prison protections in place](https://www.reuters.com/world/supreme-court-wont-allow-trump-administration-restrictions-transgender-inmates-2026-10-21/) — independent reporting on the Supreme Court's denial of emergency relief and the continuing lower-court order
- [Associated Press — Supreme Court rejects emergency bid over transgender prisoners](https://apnews.com/article/0b46a5cc302e1c8bcd292d32533e9a35) — independent reporting confirming the Supreme Court disposition, dissent and continuing litigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
