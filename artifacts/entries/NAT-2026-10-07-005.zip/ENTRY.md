# Labor Department schedules 2027 wage increase for legacy federal contracts

**Entry ID:** NAT-2026-10-07-005
**Date:** October 7, 2026
**Checked:** 2026-10-07 12:18 PM EDT
**Evidence state:** primary Wage and Hour Division rate notice; rates announced with future effective date, coverage defined, aggregate effects unmeasured
**Review state:** current-standard-reviewed

The hourly floor will rise to $14.05 and the tipped cash wage to $9.85, 90 days after the notice is published.

## THE FACTS

- The Wage and Hour Division filed a rate notice for October 8 publication announcing that the Executive Order 13658 minimum wage will rise to $14.05 per hour and the tipped-employee cash wage to $9.85 per hour, effective 90 days after publication. The new rates are scheduled, not yet in effect.
- The notice applies only to covered contract types entered from January 1, 2015 through January 29, 2022 that were not renewed or extended on or after January 30, 2022. It does not establish the wage floor for all federal contracts or the general labor market.
- The department calculated the $14.05 rate through the annual inflation adjustment required by Executive Order 13658 and rounded the tipped rate to the nearest five cents after applying the order's 70% formula. The notice implements the pre-existing adjustment mechanism rather than creating a new discretionary program.
- DOL's notice establishes the legal rates and scope but does not quantify the number of workers or contracts affected, employer cost, compliance rate or worker income change. Those implementation and outcome measures remain unreported in the inspected notice.

## SIGNIFICANCE

The notice changes binding pay floors for a defined residual set of federal contracts. The direct effect is narrower than a government-wide or economy-wide wage change, and its practical scale depends on how many qualifying contracts and workers remain.

## GOALPOST / RESPONSE

The statutory mechanism is intended to preserve the purchasing power of the covered wage floor through annual indexing. Correct coverage determinations, payroll compliance, affected-worker counts, enforcement and real-wage change are the tests.

## MAYBE / THEREFORE

Maybe indexing protects workers on older contracts from inflation, or its narrow legacy scope may limit practical reach while raising costs for remaining contractors. Therefore DOL has announced a scheduled formula-based increase for a defined contract cohort; the rates are not yet effective and their aggregate impact is unmeasured.


## SOURCES

- [DOL — 2027 minimum-wage rates for legacy EO 13658 contracts](https://public-inspection.federalregister.gov/2026-20646.pdf) — official Federal Register public-inspection rate notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
