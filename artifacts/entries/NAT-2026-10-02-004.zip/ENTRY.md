# Trump announces $90 Medicare rebates; CMS schedules October payments

**Entry ID:** NAT-2026-10-02-004
**Date:** October 2–3, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** primary White House announcement, CMS eligibility/payment FAQ, retained presidential post and independent Reuters reporting; announced and scheduled, completed disbursement and measured effects unverified in inspected material
**Review state:** current-standard-reviewed

CMS specifies 20.8 million eligible Original Medicare Part B beneficiaries and an October 8 direct-deposit target; the reviewed documents announce future payments rather than establish completed disbursement.

## THE FACTS

- On October 2, the White House announced a one-time $90 payment to help more than 20 million Medicare enrollees with Part B premiums. Reuters independently reported the announcement.
- The White House says the payments will draw on the Medicare Improvement Fund, which Congress supplied with $2 billion for improvements to fee-for-service Medicare. CMS identifies the fund as established in 2008.
- CMS’s October 3 FAQ identifies 20.8 million eligible people in Original Medicare Part B living in the United States; beneficiaries receiving Medicaid premium assistance or paying an income-related adjustment are excluded. Medicare Advantage beneficiaries are not eligible.
- CMS says most recipients should receive a $90 Social Security Administration direct deposit on or around October 8, with some Treasury paper checks later in October. Its payment-status inquiry date is October 15.
- Trump’s original post was published at 10:56:51 PM EDT on October 2, despite its October 3 UTC date. It promises payments but is not evidence of completed deposits; the White House and CMS documents likewise describe scheduled payments.

## SIGNIFICANCE

The announcement commits an existing federal Medicare fund to individual premium relief on a defined national scale. Eligibility exclusions and one-time timing matter: this is a scheduled rebate, with receipt, expenditure and lasting affordability effects still to be measured.

## GOALPOST / RESPONSE

The administration says direct payments return healthcare dollars to beneficiaries and make Medicare more affordable. Actual disbursement totals, timely receipt, eligible-beneficiary coverage, fund accounting and measured premium burden are the tests.

## MAYBE / THEREFORE

Maybe the rebate delivers useful immediate relief, or its limited one-time value and exclusions may leave substantial affordability needs unchanged. Therefore the evidence establishes an announced $90 program with a CMS eligibility and payment schedule; it does not yet establish paid totals or a sustained reduction in Medicare costs.


## SOURCES

- [White House — Medicare Improvement Fund payments announcement](https://www.whitehouse.gov/fact-sheets/2026/10/fact-sheet-president-donald-j-trump-announces-medicare-improvement-fund-payments-for-seniors/) — primary administration announcement; payments scheduled, disbursement not measured
- [CMS — Medicare Improvement Fund Premium Rebate FAQ](https://www.cms.gov/newsroom/fact-sheets/medicare-improvement-fund-premium-rebate-frequently-asked-questions) — primary implementation schedule and eligibility specification
- [Reuters — Trump announces one-time $90 Medicare payments](https://gvwire.com/2026/10/03/trump-says-us-to-send-one-time-90-payment-to-20-million-seniors-enrolled-in-medicare/) — independent reporting; future payments announced
- [Donald Trump — Medicare premium-payment announcement](https://truthsocial.com/@realDonaldTrump/117374727722154598) — primary presidential statement; claims not independently established

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
