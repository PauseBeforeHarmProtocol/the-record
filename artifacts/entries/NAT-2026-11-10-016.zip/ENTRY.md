# EPA renews emergency fuel waivers for Texas, Arizona and Arctic Alaska

**Entry ID:** NAT-2026-11-10-016
**Date:** November 10, 2026
**Checked:** 2026-11-13 6:02 AM EST
**Evidence state:** EPA's public 2026 waiver index and three signed November 10 waiver letters inspected directly; legal scope and dates implemented, actual fuel use, price relief, misfueling and environmental effects unmeasured
**Review state:** current-standard-reviewed

The signed Clean Air Act waivers temporarily relax diesel-sulfur or boutique-gasoline requirements in defined places and equipment classes; supply, price and emissions effects remain unmeasured.

## THE FACTS

- EPA, with Department of Energy concurrence, signed three November 10 Clean Air Act waiver renewals for Texas, Arizona and the part of Alaska above the Arctic Circle. The actions were implemented temporary waivers, not proposed rules, and were discovered retrospectively in this run.
- The Texas action waives the state-plan low-emission diesel standard and federal ultra-low-sulfur diesel requirement through December 3 for certain older highway vehicles and nonroad equipment originally certified for fuel containing up to 500 parts per million sulfur. Newer engines and equipment with particulate filters or catalytic controls remain ineligible.
- The Arizona action waives federal enforcement of the state's Cleaner Burning Gasoline boutique-fuel program through December 6 and allows specified gasoline containing 9% to 15% ethanol to use older ASTM volatility limits. Other federal, state and local fuel requirements remain applicable unless separately waived.
- The Alaska action runs November 14 through December 3 only above the Arctic Circle and permits high-sulfur diesel in pre-1994 highway engines and older nonroad equipment originally certified for it. Equipment requiring ultra-low-sulfur diesel remains subject to that standard.
- EPA said Middle East disruptions, high refinery utilization and below-average fuel inventories created extreme and unusual supply circumstances and that temporary flexibility was in the public interest. The letters do not measure how much fuel the waivers added, the price effect, actual use of higher-sulfur fuel or resulting emissions and equipment impacts.

## SIGNIFICANCE

The renewals use emergency authority to relax emissions-related fuel standards across three geographically distinct markets during a prolonged supply response. Their narrow duration and equipment limits reduce but do not eliminate environmental, misfueling and accountability questions; operational effects must be measured rather than inferred from the waivers themselves.

## GOALPOST / RESPONSE

EPA says the waivers widen available supply and reduce pressure on constrained gasoline and diesel markets while protecting newer emissions-control equipment. The tests are gallons produced or distributed under each waiver, verified eligible equipment use and misfueling incidents, regional inventory and price changes, air-quality and emissions data, equipment damage, extensions and restoration of ordinary standards at expiration.

## MAYBE / THEREFORE

Maybe the limited waivers prevent local shortages with little incremental pollution because use is confined to older compatible equipment and short periods, or repeated renewals may shift unmeasured emissions and equipment risks onto affected communities. Therefore the record establishes three implemented temporary waivers—not quantified supply relief, lower prices, safe use in every case or measured environmental consequences.


## SOURCES

- [2026 fuel waivers](https://www.epa.gov/gasoline-standards/fuel-waivers) — agency action index
- [Emergency Fuel Waiver for TXLED and ULSD Diesel](https://www.epa.gov/system/files/documents/2026-11/fuel-waiver-txled-ulsd-2026-1110.pdf) — signed agency waiver
- [Arizona Cleaner Burning Gasoline Waiver](https://www.epa.gov/system/files/documents/2026-11/fuel-waiver-az-2026-0110.pdf) — signed agency waiver
- [Emergency Fuel Waiver for Arctic Diesel](https://www.epa.gov/system/files/documents/2026-11/fuel-waiver-alaska-arctic-2026-1110.pdf) — signed agency waiver

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
