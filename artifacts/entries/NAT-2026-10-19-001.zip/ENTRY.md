# Labor Department rule ending federal merit-staffing mandate takes effect

**Entry ID:** NAT-2026-10-19-001
**Date:** October 19, 2026
**Checked:** 2026-10-19 6:03 AM EDT
**Evidence state:** published Department of Labor final rule and agency implementation notice; rule implemented, legal and administrative scope verified, state adoption and service outcomes unresolved
**Review state:** current-standard-reviewed

States may choose alternative staffing models for Wagner-Peyser Employment Service programs, while federal performance, civil-rights, unemployment-eligibility and farmworker safeguards remain.

## THE FACTS

- A Department of Labor final rule took effect on October 19, removing 20 CFR 652.215 and its requirement that states use state merit-system employees to deliver Wagner-Peyser Employment Service programs.
- The rule permits, but does not require, states to use alternative staffing models. Labor says states remain responsible for federal performance standards, civil-rights and nondiscrimination requirements, program-integrity safeguards and applicable grant conditions.
- The rule does not alter existing state collective-bargaining agreements or require conversion of merit staff to at-will employees or contractors. State merit staff must continue making determinations and redeterminations affecting unemployment-compensation eligibility.
- Labor retained migrant and seasonal farmworker outreach, complaint, monitor-advocate and agricultural job-order safeguards. State Monitor Advocates must remain state employees, though they no longer must be merit staff.
- Labor said it concluded the Wagner-Peyser Act does not authorize a blanket federal merit-staffing mandate and that flexibility could improve efficiency. The rule also acknowledged insufficient data for a comprehensive cost-benefit analysis, removed a mandatory evaluation of staffing models and said future studies remain possible.
- An agency implementation notice tells states that choose a different model to submit a WIOA state-plan modification and complete consultation and public-comment steps before implementation. The rule's effect is therefore a new option, not evidence that any state has already outsourced services or improved outcomes.

## SIGNIFICANCE

The rule changes the federal staffing floor for a nationwide public employment-service system and allows states to reorganize who delivers job-placement and related services. Its practical consequence depends on state choices, labor agreements, plan approvals, oversight and measured service outcomes.

## GOALPOST / RESPONSE

Labor says state flexibility will permit more efficient and responsive service delivery without weakening federal accountability or worker protections. State-plan modifications, staffing conversions, procurement terms, worker transitions, service access, processing times, job-placement outcomes, complaints, farmworker compliance, costs and federal monitoring are the tests.

## MAYBE / THEREFORE

Maybe alternative staffing lets states integrate services and direct more resources to job seekers, or it may reduce expertise, independence and accountability without the evaluation the rule removed. Therefore the federal merit-staffing mandate has ended and states gained an option—not a requirement to privatize, proof that any state has changed models, or evidence of better or worse outcomes.


## SOURCES

- [Federal Register — Wagner-Peyser Act Employment Service Staffing final rule](https://www.federalregister.gov/documents/2026/08/20/2026-16982/wagner-peyser-act-employment-service-staffing) — primary final rule establishing the effective date, legal change, retained safeguards and agency analysis
- [Department of Labor TEN 02-26 — Wagner-Peyser staffing implementation notice](https://www.dol.gov/agencies/eta/advisories/ten-no-02-26) — primary implementation guidance for state workforce agencies and WIOA plan changes

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
