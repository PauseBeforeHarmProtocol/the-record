# Treasury sanctions 46 targets tied to global scam networks

**Entry ID:** NAT-2026-11-05-001
**Date:** November 5, 2026
**Checked:** 2026-11-05 6:08 PM EST
**Evidence state:** primary Treasury and OFAC records, independently corroborated by Recorded Future News; designations implemented, alleged conduct not adjudicated and outcomes pending
**Review state:** current-standard-reviewed

The implemented action blocks a Prince Group support network and one alleged Malaysian scam operator; Treasury's criminal descriptions remain allegations and outcomes are unmeasured.

## THE FACTS

- Treasury's Office of Foreign Assets Control designated four individuals and 41 entities that it says support the previously sanctioned Prince Group transnational criminal organization, plus one Malaysian individual accused of managing an Africa-based scam network. The November 5 action therefore covers 46 targets.
- OFAC designated 45 targets under the transnational-criminal-organization authority and one under cyber-sanctions authority. Property and interests in property subject to U.S. jurisdiction are blocked, U.S. persons are generally prohibited from transactions absent authorization, and entities owned 50% or more by blocked persons are also blocked even if not separately listed.
- Treasury alleges the Prince Group network helped manage offshore structures, conceal beneficial ownership, facilitate commercial activity and evade prior sanctions connected to cyber-enabled fraud, money laundering and human trafficking. Recorded Future News independently reported the action and noted Prince Group's prior rejection of criminal accusations; the designations are executive sanctions, not criminal convictions of every listed person or entity.
- No reviewed evidence quantified newly blocked assets, established completed forfeitures, measured fraud losses prevented, or showed that the designated network ceased operating.

## SIGNIFICANCE

The action extends sanctions from an already designated organization to a broad corporate and financial support layer across jurisdictions. It creates immediate compliance consequences but does not adjudicate Treasury's allegations or demonstrate that scams, trafficking or laundering were reduced.

## GOALPOST / RESPONSE

Treasury says the designations dismantle infrastructure that lets scam networks conceal assets and victimize Americans; Prince Group previously denied criminal accusations. Asset reports, license and enforcement records, criminal proceedings, victim-loss data, network disruption and recurrence are the tests.

## MAYBE / THEREFORE

Maybe blocking the support network will disrupt access to finance and reduce victimization, or actors may reorganize through new entities and jurisdictions. Therefore 46 sanctions targets and their legal blocking consequences are confirmed—not criminal liability for every allegation, quantified seizures or proven effectiveness.


## SOURCES

- [Treasury — global scam-network and Prince Group support-network sanctions](https://home.treasury.gov/news/press-releases/sb0683) — primary sanctions announcement identifying 46 targets, authorities and blocking consequences
- [OFAC — November 5 cyber/TCO and Cuba designations and Cuba sector determination](https://ofac.treasury.gov/recent-actions/20261105) — primary sanctions action notice and sector determination
- [Recorded Future News — U.S. issues more sanctions against Prince Group scam-center affiliates](https://therecord.media/us-issues-more-sanctions-against-prince-group-scammers) — independent cybersecurity reporting on the designations and Prince Group response history

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
