# DOJ says first Alien Terrorist Removal Court respondent was deported after waiver

**Entry ID:** NAT-2026-09-11-007
**Date:** September 11, 2026
**Checked:** 2026-09-11 12:02 PM EDT
**Evidence state:** AP report citing Justice Department and defense statements, with Reuters court-record background; removal reported implemented, allegations and constitutional merits unresolved
**Review state:** current-standard-reviewed

The consent-based removal ends the court's first case without a merits test of the government's classified allegations or the defense's constitutional objections.

## THE FACTS

- Associated Press reported on September 11 that the Justice Department said Nazira Haji Zada had been deported after she waived rights to challenge her detention and agreed to removal. AP said the timing and destination were not immediately clear.
- The administration arrested Haji Zada, a lawful permanent resident, in July and brought the first case ever filed in the Alien Terrorist Removal Court, a five-judge body Congress created in 1996 for removal proceedings involving people the government classifies as alien terrorists.
- Justice Department and FBI materials alleged that Haji Zada supported Islamic State and concealed family radicalization connected to a foiled 2024 Election Day attack plot. Reuters reported during the July hearing that she had not been criminally charged; her son and son-in-law had pleaded guilty in related cases.
- Her lawyers argued that reliance on evidence withheld as classified denied due process and said her consent should not be read as endorsing the court's legitimacy. The administration said it used a lawful national-security tool; the consent resolution produced no merits ruling on either position.

## SIGNIFICANCE

The first completed removal through a previously unused statutory court marks an implemented expansion of the administration's immigration and national-security machinery. Because the respondent consented, the proceeding did not resolve how the tribunal's classified-evidence process would withstand constitutional review.

## GOALPOST / RESPONSE

The administration says people who support terrorism have no place in the United States and that Congress authorized this specialized process. The defense says withholding the government's evidence violates due process. Future contested cases, disclosed records, appellate review and procedural safeguards are the tests.

## MAYBE / THEREFORE

Maybe consent avoided a prolonged proceeding for both sides, or the prospect of a classified-evidence tribunal may have shaped the decision without testing its legality. Therefore DOJ's reported result is an implemented deportation after waiver—not a criminal conviction, judicial validation of the allegations or a constitutional endorsement of the court.


## SOURCES

- [Associated Press — first Alien Terrorist Removal Court respondent deported after waiver](https://apnews.com/article/terrorism-court-justice-department-afghan-39bd2b9ef8874b0ffddcef9efdf4ec5f) — independent reporting citing Justice Department and defense statements
- [Reuters — first Alien Terrorist Removal Court case and hearing](https://www.reuters.com/legal/government/first-case-secretive-us-court-meant-deport-alleged-terrorists-2026-07-30/) — independent legal reporting with court-record review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
