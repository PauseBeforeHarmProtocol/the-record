# Treasury adds Iran-related sanctions authority to Russia's VTB Bank

**Entry ID:** NAT-2026-09-14-005
**Date:** September 14, 2026
**Checked:** 2026-09-14 6:00 PM EDT
**Evidence state:** primary Treasury designation announcement and independent Reuters reporting; designation implemented, alleged conduct and downstream effectiveness not adjudicated or measured
**Review state:** current-standard-reviewed

OFAC designated the already sanctioned Russian bank under an Iran executive order, increasing secondary-sanctions exposure for foreign institutions.

## THE FACTS

- On September 14, the Treasury Department's Office of Foreign Assets Control designated VTB Bank Public Joint Stock Company under Executive Order 13902 for operating in Iran's financial sector. VTB had already been designated under Russia-related authorities in 2022 and 2025; the new action adds an Iran-related legal basis rather than first placing the bank under U.S. sanctions.
- The designation blocks VTB property and interests in property within U.S. jurisdiction, generally prohibits transactions involving them by U.S. persons absent authorization or exemption, and also reaches entities owned 50% or more by blocked persons under OFAC's rules.
- Treasury alleged that VTB opened offices in Iran, established correspondent relationships with sanctioned Iranian financial institutions, worked to move billions in frozen Iranian assets and created a ruble-rial settlement system. Those are the government's stated factual bases for designation, not findings from an adjudicated criminal case.
- Treasury warned that foreign financial institutions knowingly conducting significant transactions for VTB may face correspondent-account restrictions or other secondary sanctions. Reuters independently reported the new designation and noted that VTB was already excluded from the dollar system under prior Russia sanctions.
- Treasury framed the action as part of Operation Economic Outcast and said it aims to sever revenue and procurement channels supporting Iran and its proxies. The designation does not by itself establish that the alleged transfers occurred in the stated amount, that all foreign banks will end VTB relationships or that the sanctions will change Iranian policy.

## SIGNIFICANCE

Adding an Iran authority to an already heavily sanctioned Russian bank broadens the legal and secondary-sanctions risk around Russia-Iran finance. Its practical effect depends on counterparties' behavior, enforcement, licensing and whether the targeted channels can be replaced.

## GOALPOST / RESPONSE

Treasury says the action will isolate Iran's financial enablers and raise the cost of dealing with VTB. Blocked-property reports, correspondent withdrawals, enforcement cases, licenses, transaction and trade data, replacement channels, delisting petitions and observable changes in Iranian financing are the tests.

## MAYBE / THEREFORE

Maybe the added designation deters foreign institutions and disrupts Russia-Iran settlement channels, or existing isolation and alternative payment routes may limit its marginal effect. Therefore the record establishes a new OFAC designation and its legal consequences—not adjudicated proof of every Treasury allegation or measured success in changing VTB, Russian or Iranian behavior.


## SOURCES

- [Treasury — Operation Economic Outcast sanctions VTB Bank under Iran authority](https://home.treasury.gov/news/press-releases/sb0629) — primary OFAC designation announcement, legal authority, alleged conduct and sanctions implications
- [Reuters — U.S. imposes Iran-related sanctions on Russia's VTB Bank](https://www.reuters.com/world/middle-east/us-imposes-iran-related-sanctions-russias-vtb-2026-09-14/) — independent reporting of the designation, Treasury allegations and existing Russia-related sanctions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
