# Financial disclosures report Trump gave $155,000 to four White House aides

**Entry ID:** NAT-2026-09-08-008
**Date:** September 8, 2026
**Checked:** 2026-09-08 11:58 PM EDT
**Evidence state:** three independent reports describing administration-released financial disclosures plus the primary White House salary report; gifts reported and salaries documented, underlying annual disclosure PDFs unavailable in the inspected archive, purpose and legality disputed and unadjudicated
**Review state:** current-standard-reviewed

The aides disclosed holiday cash gifts from Trump; whether federal salary-supplementation or gift rules were violated remains disputed and unadjudicated.

## THE FACTS

- Financial disclosure forms released by the administration and reviewed by the Washington Post, Associated Press and Wall Street Journal report that Trump gave $45,000 holiday cash gifts to Natalie Harp, Margo Martin and Chamberlain Harris and $20,000 to Walt Nauta, a total of $155,000. The publications describe gifts made last Christmas; the underlying forms were not directly available in the inspected public archive by cutoff.
- The White House's July 2026 salary report to Congress lists Harp, Martin and Harris at $150,000 annually and Nauta at $175,000. The reported gifts therefore equal 30% of each woman's annual salary and about 11% of Nauta's, but the disclosures do not by themselves establish a quid pro quo, an official-duty payment or a legal violation.
- A named former White House ethics lawyer told the Post the gifts appeared to violate the federal salary-supplementation statute. A second former Office of Government Ethics official said the available facts did not make a violation clear, while warning that large superior-to-subordinate gifts could create indebtedness. The White House said Trump has a longstanding Christmas-gift practice, that the gifts were unrelated to official duties and that they were permissible under relevant legal and ethical standards. No enforcement finding or court ruling was reported by cutoff.

## SIGNIFICANCE

Large personal payments from a president to current subordinates create unusual conflict-of-interest and independence questions even when disclosed and described as holiday gifts. The key legal and ethical issue is purpose and connection to official service, which the available public evidence does not resolve.

## GOALPOST / RESPONSE

The White House says the gifts follow a longstanding personal practice, were unrelated to government duties and are lawful. The tests are the complete signed disclosure forms, dates and funding source, ethics advice or recusals, treatment under gift and salary-supplementation rules, any Office of Government Ethics or inspector-general review and any administrative or judicial finding.

## MAYBE / THEREFORE

Maybe the payments were lawful personal holiday gifts with no effect on official judgment, or their scale and employment relationship may create a prohibited salary supplement or practical pressure on recipients. Therefore the disclosures support that $155,000 in gifts was reported—not a proven quid pro quo, established statutory violation or exoneration under ethics law.


## SOURCES

- [Washington Post — financial disclosures report Trump cash gifts to four aides](https://www.washingtonpost.com/politics/2026/09/08/trump-gave-45000-cash-gifts-natalie-harp-two-other-close-aides/) — independent reporting based on administration-released financial disclosures, with competing named ethics analysis and White House response
- [Associated Press — Trump holiday gifts to White House aides](https://apnews.com/article/59b8b7e2cee39f9cd4933b0a9a1d8585) — independent reporting confirming disclosed gift amounts, recipients, salaries and administration response
- [Wall Street Journal — Trump gifted three aides $45,000 each](https://www.wsj.com/politics/policy/trump-gifted-natalie-harp-two-other-aides-45-000-each-last-christmas-a4ccdbfc) — independent reporting based on administration-released disclosure forms; publication occurred before the preserved cutoff
- [White House — 2026 annual personnel salary report to Congress](https://www.whitehouse.gov/wp-content/uploads/2026/07/2026-Annual-Report-to-Congress-on-White-House-Staff.pdf) — primary salary and position report for White House personnel

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
