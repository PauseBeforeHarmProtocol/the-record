# CFTC settles White House speech-information trading case

**Entry ID:** NAT-2026-08-28-011
**Date:** December 2025–August 28, 2026
**Checked:** 2026-08-29 12:05 AM EDT
**Evidence state:** primary CFTC enforcement release and consent order plus independent Reuters and Associated Press reporting; civil settlement implemented, no criminal adjudication
**Review state:** current-standard-reviewed

A former teleprompter operator agreed to disgorgement, a civil penalty, and a three-year trading ban; the consent order is civil, not a criminal conviction.

## THE FACTS

- The Commodity Futures Trading Commission filed and settled charges against Gabriel Perez, a former White House teleprompter operator, over event-contract trades made from December 2025 through February 2026.
- The CFTC order found that Perez misappropriated material nonpublic information obtained through his federal employment about subjects Trump would mention in public speeches and used it to trade presidential-mention contracts on the Kalshi prediction market.
- Perez agreed to disgorge $107,539.02, pay a $65,000 civil monetary penalty, cease and desist, and accept a three-year ban from CFTC-regulated markets. The agency said the reduced penalty reflected exemplary cooperation and credited KalshiEX for substantial assistance.
- Perez was no longer a federal employee by the settlement. The White House had previously called the conduct a disgrace; the settlement materials did not announce criminal charges or establish that other White House personnel participated.

## SIGNIFICANCE

The order applies federal commodities law to alleged misuse of privileged government information in political prediction markets. It documents concrete financial and market-access consequences while leaving separate questions about White House information controls and broader event-contract surveillance.

## GOALPOST / RESPONSE

The CFTC says the settlement protects market integrity and that Perez's cooperation materially aided the case. The White House condemned the conduct, and Kalshi assisted the investigation. Payment records, compliance with the trading ban, any employment-control changes, additional enforcement, and evidence of similar trading are the tests.

## MAYBE / THEREFORE

Maybe the case reflects an isolated employee violation resolved through cooperation, or it may reveal a wider control weakness as political event markets expand. Therefore the record reports a settled CFTC civil order and agency findings—not a criminal conviction, judicial trial finding, or proof of systemic White House trading misconduct.


## SOURCES

- [CFTC — order settling prediction-market trading charges against Gabriel Perez](https://www.cftc.gov/PressRoom/PressReleases/9289-26) — primary civil enforcement order and agency findings accepted in settlement
- [Reuters — CFTC fines former White House aide over speech-information trades](https://www.reuters.com/legal/government/cftc-fines-former-white-house-aide-172000-trading-trump-speech-information-2026-08-29/) — independent reporting on the settled civil enforcement action and White House response
- [Associated Press — former White House teleprompter operator settles CFTC case](https://apnews.com/article/white-house-teleprompter-gambling-kalshi-535e252b20f39ab414f93d806758c626) — independent reporting on the event-contract trades, settlement, and cooperation credit

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
