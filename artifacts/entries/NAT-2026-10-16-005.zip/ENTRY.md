# EPA announces $109 million WIFIA loan for Honolulu desalination plant

**Entry ID:** NAT-2026-10-16-005
**Date:** October 16, 2026
**Checked:** 2026-10-16 11:59 PM EDT
**Evidence state:** primary EPA loan announcement; amount, borrower, purpose and projected capacity verified, financing details, construction and outcomes unresolved
**Review state:** current-standard-reviewed

The federal loan is intended to finance a seawater reverse-osmosis facility projected to supply 1.7 million gallons per day; construction, delivery and aquifer effects remain future tests.

## THE FACTS

- EPA announced a $109 million Water Infrastructure Finance and Innovation Act loan to the Honolulu Board of Water Supply for design and construction of a large-scale seawater reverse-osmosis desalination plant serving parts of Oahu.
- EPA projects the facility will produce 1.7 million gallons of water per day and reduce pressure on groundwater aquifers. Those figures are agency projections, not measured post-construction output or ecological outcomes.
- The announcement identifies a federal loan rather than a grant. The inspected release did not provide a disbursement schedule, total project cost, interest rate, repayment terms, construction milestones or completed environmental outcome.
- EPA presents WIFIA as a financing tool for local water infrastructure and ties the loan to its national water-infrastructure initiative. The Board's implementation, permits, financing close, construction and operating performance remain the tests.

## SIGNIFICANCE

The loan is a material federal infrastructure financing commitment supporting a new drinking-water source in an aquifer-constrained island system, while leaving delivery and performance dependent on later local and federal implementation.

## GOALPOST / RESPONSE

EPA says the project will improve supply reliability and protect groundwater by bringing 1.7 million gallons per day online. Loan closing and disbursements, permits, construction, cost and schedule, actual output, energy use, water quality, repayment and measured aquifer effects are the tests.

## MAYBE / THEREFORE

Maybe federal financing enables a durable additional water source, or cost, energy, permitting and operating constraints may reduce the projected benefit. Therefore EPA announced a $109 million loan for a defined project—not a completed plant, disbursed total or measured water-supply outcome.


## SOURCES

- [EPA — $109 million Honolulu desalination WIFIA loan](https://www.epa.gov/newsreleases/epa-announces-109-million-wifia-loan-increase-water-supply-reliability-honolulu-hawaii) — primary agency loan announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
