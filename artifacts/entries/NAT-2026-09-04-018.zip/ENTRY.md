# Guyana receives six Cuban and Afghan nationals removed from the United States

**Entry ID:** NAT-2026-09-04-018
**Date:** September 4–5, 2026
**Checked:** 2026-09-05 6:00 PM EDT
**Evidence state:** Associated Press reporting based on named Guyanese officials and government descriptions; arrival and stated arrangement documented, individual U.S. files, consent, legal review, costs and outcomes undisclosed
**Review state:** current-standard-reviewed

The first implemented transfer under a one-year third-country arrangement places six people in temporary Guyanese status proceedings rather than permanent resettlement.

## THE FACTS

- Guyana's government said six Cuban and Afghan nationals removed from the United States arrived on September 4 under the Trump administration's third-country deportation program.
- Foreign Secretary Robert Persaud told the Associated Press that Guyana vetted the group, found no criminal background and understood that the removals were primarily for immigration issues. The individuals' names, U.S. case files, notice records and consent documentation were not public by cutoff.
- Persaud said the arrangement followed months of negotiation, lasts one year and does not provide permanent resettlement. Guyana had received no request for an additional group by the time of his statement.
- Authorities described the transfer as part of an Assisted Voluntary Return Program administered by the International Organization for Migration. The six people will remain in Guyana while their immigration status is determined and may later return to their countries of origin or move elsewhere. The public reporting does not establish whether each person voluntarily chose Guyana or what protection review preceded the U.S. removal.
- Guyana said it would not bear housing or support costs. No public document identified the total U.S. expenditure, detailed support terms, legal instruments or final destination and protection outcome for any of the six people.

## SIGNIFICANCE

The arrival moves the Guyana arrangement from negotiation to implementation and expands the administration's use of countries with which deportees may have no citizenship ties. Temporary status, onward-movement uncertainty and undisclosed individual process make post-transfer safeguards and responsibility consequential.

## GOALPOST / RESPONSE

The governments present the arrangement as vetted, temporary and supported through IOM, with no permanent-resettlement or Guyanese cost obligation. Individual notice and consent records, U.S. protection screening, the bilateral instrument, IOM terms, funding, legal status decisions, living conditions and final destinations are the tests.

## MAYBE / THEREFORE

Maybe a small, vetted and internationally administered transfer gives people a safer temporary pathway when direct return is not feasible, or the voluntary-program label may obscure removals to a country they did not choose and uncertain onward protection. Therefore the record confirms the arrival of six people and Guyana's stated temporary terms—not individual consent, criminality, legal compliance, permanent resettlement or final outcomes.


## SOURCES

- [Associated Press — first six U.S. third-country deportees arrive in Guyana](https://apnews.com/article/guyana-deportations-us-trump-2f6cac6453d237c695486cf377c41bf8) — independent reporting based on named Guyanese officials about the implemented transfer and temporary arrangement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
