# Justice Department defers Sue Mi Terry prosecution for one year

**Entry ID:** NAT-2026-10-13-010
**Date:** October 13, 2026
**Checked:** 2026-10-14 12:01 AM EDT
**Evidence state:** public federal docket identification plus Associated Press review of filed agreement documents and defense response; prosecution deferred, dismissal conditional and merits unadjudicated
**Review state:** current-standard-reviewed

The filed agreement calls for dismissal if the former CIA analyst complies with its conditions; it is neither an acquittal nor a conviction on the foreign-agent charges.

## THE FACTS

- Federal prosecutors entered a one-year deferred-prosecution agreement with former CIA analyst Sue Mi Terry in the Southern District of New York. Associated Press reported from the filed documents that the government will dismiss the case if she remains out of legal trouble and satisfies the agreement's conditions.
- Terry was charged in 2024 with conspiring to act as an unregistered agent of South Korea and failing to register under the Foreign Agents Registration Act. She pleaded not guilty and maintained her innocence; the deferred agreement does not adjudicate the charges on the merits.
- The agreement includes a statement of facts in which Terry acknowledged sharing notes from an off-the-record 2022 meeting with Secretary of State Antony Blinken with a South Korean intelligence officer and accepting handbags and coats valued at about $9,245. Prosecutors said the disposition served the interests of both parties but did not provide a fuller public explanation.
- The prosecution is paused rather than immediately dismissed. Compliance, any alleged breach and the promised dismissal after one year remain future procedural stages.

## SIGNIFICANCE

The agreement materially changes the posture of a nationally significant foreign-agent prosecution: trial and immediate adjudication are replaced by conditional deferral and potential dismissal. The acknowledged conduct supplies evidence, but the arrangement does not convert disputed charges into convictions or explain the full prosecutorial calculus.

## GOALPOST / RESPONSE

Justice says the agreement serves the interests of the parties, while Terry's defense says it reflects a fair resolution. Tests include compliance with the conditions, an eventual dismissal filing, any breach litigation and fuller disclosure of the government's reasons or policy implications for comparable foreign-agent cases.

## MAYBE / THEREFORE

Maybe conditional dismissal proportionately resolves evidentiary and public-interest concerns while securing an acknowledgment of conduct, or it may leave unclear why serious foreign-agent charges were not taken to trial. Therefore DOJ formally deferred the case for one year—not acquitted Terry, obtained a conviction or already dismissed the indictment.


## SOURCES

- [Associated Press — Justice Department enters deferred-prosecution agreement with Sue Mi Terry](https://apnews.com/article/4709ee1e35a8f2647eb536f6ebbb3921) — independent reporting based on filed court documents, agreement terms and defense response
- [United States v. Terry docket, No. 1:24-cr-00427](https://www.drdocket.com/case/united-states-v-terry-nysd-2024) — public federal docket identifying the case and procedural history; October 13 agreement terms independently reported from filed documents

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
