# Justice Department defers Sue Mi Terry prosecution for one year

**Entry ID:** NAT-2026-10-13-010
**Date:** October 13, 2026
**Checked:** 2026-10-14 6:03 AM EDT
**Evidence state:** public federal docket identification plus Associated Press and Reuters review of filed agreement documents and defense response; prosecution deferred under travel and contact conditions, dismissal conditional and merits unadjudicated
**Review state:** current-standard-reviewed

The filed agreement calls for dismissal if the former CIA analyst complies with its conditions; it is neither an acquittal nor a conviction on the foreign-agent charges.

## THE FACTS

- Federal prosecutors entered a one-year deferred-prosecution agreement with former CIA analyst Sue Mi Terry in the Southern District of New York. Associated Press reported from the filed documents that the government will dismiss the case if she remains out of legal trouble and satisfies the agreement's conditions.
- Terry was charged in 2024 with conspiring to act as an unregistered agent of South Korea and failing to register under the Foreign Agents Registration Act. She pleaded not guilty and maintained her innocence; the deferred agreement does not adjudicate the charges on the merits.
- The agreement includes a statement of facts in which Terry acknowledged sharing notes from an off-the-record 2022 meeting with Secretary of State Antony Blinken with a South Korean intelligence officer and accepting handbags and coats valued at about $9,245. Prosecutors said the disposition served the interests of both parties but did not provide a fuller public explanation.
- The prosecution is paused rather than immediately dismissed. Compliance, any alleged breach and the promised dismissal after one year remain future procedural stages.
- Reuters reported from the filed notice that the one-year conditions include restrictions on Terry's travel and contacts with the South Korean government. It also reported that she admitted no wrongdoing but acknowledged assistance to South Korean intelligence officers, 19 restaurant meals and $37,000 in payments to a Korea-policy program she ran, in addition to the previously reported luxury goods.

## SIGNIFICANCE

The agreement materially changes the posture of a nationally significant foreign-agent prosecution: trial and immediate adjudication are replaced by conditional deferral and potential dismissal. The added filing details show concrete restrictions and acknowledged interactions and benefits, but the arrangement does not convert disputed charges into convictions or explain the full prosecutorial calculus.

## GOALPOST / RESPONSE

Justice says the agreement serves the interests of the parties, while Terry's defense says it reflects a fair resolution and maintains that she committed no wrongdoing. Tests include compliance with the travel and contact restrictions, an eventual dismissal filing, any breach litigation and fuller disclosure of the government's reasons or policy implications for comparable foreign-agent cases.

## MAYBE / THEREFORE

Maybe conditional dismissal proportionately resolves evidentiary and public-interest concerns while securing restrictions and acknowledgments, or it may leave unclear why serious foreign-agent charges were not taken to trial. Therefore DOJ formally deferred the case for one year under specified conditions—not acquitted Terry, obtained a conviction, secured an admission of wrongdoing or already dismissed the indictment.


## SOURCES

- [Associated Press — Justice Department enters deferred-prosecution agreement with Sue Mi Terry](https://apnews.com/article/4709ee1e35a8f2647eb536f6ebbb3921) — independent reporting based on filed court documents, agreement terms and defense response
- [United States v. Terry docket, No. 1:24-cr-00427](https://www.drdocket.com/case/united-states-v-terry-nysd-2024) — public federal docket identifying the case and procedural history; October 13 agreement terms independently reported from filed documents
- [Reuters — Sue Mi Terry deferred-prosecution terms and conditions](https://www.reuters.com/legal/government/us-drop-south-korea-intelligence-case-against-ex-cia-analyst-2026-10-14/) — independent reporting based on the filed four-page deferred-prosecution notice and defense response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
