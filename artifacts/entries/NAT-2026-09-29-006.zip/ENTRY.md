# DHS finalizes higher EB-5 immigrant-investor fees

**Entry ID:** NAT-2026-09-29-006
**Date:** September 29, 2026
**Checked:** 2026-09-29 11:57 PM EDT
**Evidence state:** primary DHS and USCIS final rule filed for public inspection; fees finalized for future effectiveness, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The final rule raises several major petition and regional-center fees, adds integrity-related charges and takes effect 60 days after September 30 publication.

## THE FACTS

- U.S. Citizenship and Immigration Services filed a final EB-5 Immigrant Investor Program fee rule on September 29. The rule is scheduled for September 30 publication and takes effect 60 days later; as of cutoff the fees were finalized but not yet implemented.
- The rule implements fee provisions of the EB-5 Reform and Integrity Act of 2022, including a technology fee and regional-center integrity fees and penalties, and recalculates charges to recover program costs.
- Examples in the final rule raise the Form I-526 standalone petition fee from $3,675 to $7,615 and the initial I-526E fee from $3,675 to $7,850. The initial I-956 regional-center application rises from $17,795 to $44,115 and Form I-956F from $17,795 to $42,675, while some amendment and annual-statement fees decline.
- USCIS estimated a weighted average increase of about 70.7 percent, or $2,945.90, across roughly 16,600 annual filings and said the prior schedule left an estimated $48.4 million annual cost-recovery gap.
- Finalization does not establish how filing volume, processing times, fraud detection, litigation or investor access will change after the effective date.

## SIGNIFICANCE

The rule materially changes the price of access to the federal immigrant-investor program and the resources available for its administration and integrity work, with potential consequences for applicants, regional centers and program participation.

## GOALPOST / RESPONSE

DHS and USCIS say the fees are needed to recover program costs, support timely processing and implement statutory integrity measures. Collections, filing volume, processing times, audit and enforcement activity, fee-waiver availability, litigation and program outcomes are the tests.

## MAYBE / THEREFORE

Maybe higher and better-targeted fees improve staffing, processing and integrity controls, or the increases may deter applicants and concentrate access without delivering faster or safer adjudication. Therefore the record establishes a final fee schedule with a future effective date—not collected revenue, shorter processing times or improved program integrity.


## SOURCES

- [Federal Register — EB-5 Immigrant Investor Program Fee Rule](https://www.federalregister.gov/d/2026-20016) — official final rule filed for public inspection; effective 60 days after September 30 publication

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
