# Navy and Anduril announce outcome-contingent submarine-component facility deal

**Entry ID:** NAT-2026-10-06-004
**Date:** October 6, 2026
**Checked:** 2026-10-06 6:08 PM EDT
**Evidence state:** independent AP and USNI reporting; reported contract and investment commitments, performance and payment outcomes prospective
**Review state:** current-standard-reviewed

Reporting describes up to $2.9 billion in federal commitments and $3.7 billion in private investment; delivery and milestone payments remain prospective.

## THE FACTS

- AP and USNI News reported that the Navy and Anduril announced a deal for Arsenal-2, a submarine-component manufacturing facility at Sparrows Point near Baltimore. Initial planned output includes torpedo tubes and other submarine components.
- The reports describe up to $2.9 billion in federal contract commitments contingent on demonstrated production outcomes and $3.7 billion in private investment by Anduril. These are announced ceilings and commitments, not proof that all federal or private funds have been spent.
- The project is projected to create about 3,100 direct jobs and increase labor hours available to the submarine industrial base by about 15%. Those are forecasts; the inspected material does not establish completed hiring, production volume, schedule recovery or unit-cost results.
- The administration presents the arrangement as a way to expand a bottlenecked submarine industrial base by tying public payments to output. A government contract document, payment schedule and equity terms were not retrieved in this run, so reported terms are not extended beyond the two independent accounts.

## SIGNIFICANCE

The arrangement could add material industrial capacity for a high-priority naval program and uses an outcome-contingent public commitment alongside unusually large private capital. Its value depends on delivered components, timing, cost and accountability.

## GOALPOST / RESPONSE

The administration says the model expands production capacity while paying against demonstrated results. Facility completion, accepted components, milestone payments, workforce levels, schedule gains and total public cost are the tests.

## MAYBE / THEREFORE

Maybe the risk-sharing structure accelerates a constrained supply chain, or projections may not translate into timely, affordable output. Therefore a major facility and contingent funding arrangement were announced and independently reported; full spending, job creation, production gains and any government equity interest are not established here.


## SOURCES

- [AP — Navy and Anduril announce submarine-component facility](https://apnews.com/article/trump-baltimore-moore-submarines-midterms-1cacc864be999e71ef8bcf9b15e21cda) — independent reporting
- [USNI News — Anduril to build submarine-component facility](https://news.usni.org/2026/10/06/anduril-to-build-submarine-component-facility) — independent defense reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
