# Reuters review finds D.C. Guard deployment seldom involved in criminal cases

**Entry ID:** NAT-2026-08-19-001
**Date:** August 19, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** independent court-record, deployment, geographic, and budget analysis; causation not established
**Review state:** current-standard-reviewed

The evidence check compares a 4,500-troop deployment and its projected cost with court records and the neighborhoods bearing most lethal violence.

## THE FACTS

- Reuters reported that roughly 4,500 National Guard troops were deployed in Washington, compared with about 3,200 Metropolitan Police Department officers.
- A Reuters review found soldiers mentioned in 1.3% of D.C. criminal cases during the deployment and found them concentrated in wealthier, whiter areas rather than neighborhoods accounting for 82% of the city's murders.
- The administration projected deployment costs of about $1.4 billion through 2029. Guard personnel also performed patrol, transit, monument, and beautification duties, so criminal-case involvement is only one measure of activity.

## SIGNIFICANCE

This is an outcome audit, not merely a record of an order. It tests whether the scale, placement, mission, and cost of a military presence correspond to the public-safety problem cited to justify it.

## GOALPOST / RESPONSE

The White House credits the broader federal operation with lower crime and cleaner public spaces. Reuters noted that attribution is difficult because federal agents and local police operated at the same time. A causal claim therefore requires transparent baselines, geographic data, mission logs, and costs—not visibility alone.

## MAYBE / THEREFORE

Maybe Guard patrol, transit, monument, and beautification work produced benefits that criminal-case mentions cannot capture, while simultaneous federal and local policing prevents clean attribution. Therefore the deployment’s public-safety claim rises or falls with transparent crime baselines, geographic data, mission logs, and its projected costs—not the 1.3% figure alone.


## SOURCES

- [Reuters — review of the D.C. National Guard deployment's crime role](https://www.reuters.com/world/us/trump-put-thousands-soldiers-washingtons-streets-they-seldom-stop-crime-2026-08-19/) — independent data and court-record analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
