# DHS proposes $70,000 initial fee for international-student practical training

**Entry ID:** NAT-2026-10-07-002
**Date:** October 7, 2026
**Checked:** 2026-10-07 12:18 PM EDT
**Evidence state:** primary ICE/DHS proposed rule; formally proposed for future publication, costs and transfers projected, outcomes unmeasured
**Review state:** current-standard-reviewed

The proposal would charge schools $30,000 for subsequent OPT recommendations; no fee is yet in effect.

## THE FACTS

- ICE filed a proposed rule for October 8 publication that would require a Student and Exchange Visitor Program-certified school to pay $70,000 when first recommending an F-1 student for Optional Practical Training and $30,000 for any subsequent OPT recommendation. The proposal is not a final rule and the fees are not yet in effect.
- DHS estimates annualized transfers from schools to the federal government of $12.896 billion under a 7% discount rate, with an $8.803 billion to $16.988 billion range. It estimates primary annualized monetized costs of $4.122 billion and a ten-year present value of $29.0 billion at 7%; those are agency projections, not measured outcomes.
- The initial regulatory-flexibility analysis identifies 2,478 affected SEVP-certified institutions, estimates 1,389 are small entities and says the proposal would have a significant economic impact on a substantial number of small entities. The rule would allow funding from students, employers or third parties, but the school would remain responsible for payment.
- DHS says the fees would deter fraud and abuse, encourage school oversight and protect U.S. workers. The agency did not monetize the claimed benefits; public comments are due 30 days after publication for the policy and 60 days for the information collection.

## SIGNIFICANCE

The proposal would attach unusually large federal charges to a nationwide student-work program and could materially change school recommendations, student access and employer recruitment. Effects depend on whether it is finalized, who ultimately bears the cost and how participation changes.

## GOALPOST / RESPONSE

DHS says the price signal will curb misuse, improve institutional oversight and protect U.S. workers. Final-rule terms, participation by school and student, fraud findings, labor-market effects, administrative cost and litigation outcomes are the tests.

## MAYBE / THEREFORE

Maybe a high fee deters abusive or weakly supervised placements, or it may broadly suppress legitimate training and shift costs to students and employers without proving fraud reduction. Therefore DHS has proposed—not imposed—the fees, while its quantified costs and transfers are forecasts and its benefits remain unmonetized.


## SOURCES

- [ICE — Optional Practical Training fee proposed rule](https://public-inspection.federalregister.gov/2026-20660.pdf) — official Federal Register public-inspection proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
