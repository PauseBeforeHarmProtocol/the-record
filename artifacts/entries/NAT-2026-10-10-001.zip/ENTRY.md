# National Park Service begins major East Potomac tree-removal phase

**Entry ID:** NAT-2026-10-10-001
**Date:** October 10, 2026
**Checked:** 2026-10-10 6:02 PM EDT
**Evidence state:** Associated Press eyewitness reporting and named Interior/NPS statements plus Washington Post reporting on the federal filing and project posture; initial removal implemented, wider tree count planned, broader redesign not finalized
**Review state:** current-standard-reviewed

Crews began an initial 169-tree phase at the public golf course; the agency says it is historic-landscape maintenance, while the larger redesign remains unfinalized and contested.

## THE FACTS

- Associated Press observed National Park Service crews beginning tree removal at East Potomac Golf Links on October 10. The agency said 169 trees would be removed starting Saturday, another 90 later, and more than 500 trees classified as noncontributing to the historic landscape could ultimately be removed.
- The Interior Department said the work implements a seven-year-old plan to address overgrowth, restore historic views and preserve healthy trees that are contributing historic features, including healthy historic cherry trees. The agency said the public course would remain open, although individual holes may close temporarily.
- The Washington Post reported that NPS continued to call the broader Trump-backed redesign a potential project and had not released a final design, cost, funding plan or closure schedule. The report said 20 to 50 temporary workers and additional funding accelerated the tree work, but the filing did not identify the workers or funding source and amount. The linked court filing could not be retrieved in this review, so those filing details remain attributed to the two independent reports.
- The administration says the tree work is maintenance that would proceed independently of any redesign and does not change holes, routing, greens, bunkers or landforms. Plaintiffs in the pending preservation lawsuit argue preliminary work is already implementing the larger redevelopment; residents have also raised public-access, fee and open-space concerns. No inspected ruling had stopped this phase by cutoff.

## SIGNIFICANCE

This is an implemented physical change to federally managed public land, not merely Trump's earlier redesign proposal. The distinction between independent maintenance and the first stage of a championship-course redevelopment matters for historic-preservation review, judicial oversight, public access and spending accountability; the broader project's design, funding and legal outcome remain unresolved.

## GOALPOST / RESPONSE

Interior and NPS say the work follows a longstanding overgrowth plan, protects healthy contributing trees, restores historic views and leaves the course open. The tests are the final tree count and condition assessments, identified funding and workforce, preservation-consultation record, effects on public access and fees, any final redesign, and court findings about whether the work is genuinely independent maintenance.

## MAYBE / THEREFORE

Maybe the removal is overdue landscape maintenance that would occur regardless of Trump's golf-course proposal, as NPS says, or it may function as an incremental step toward that redevelopment, as plaintiffs argue. Therefore the archive records the observed start of the tree-removal phase and its disclosed scope—not completion of all 529 possible removals, approval of a final golf-course redesign, elimination of public access or a court finding that the work is unlawful.


## SOURCES

- [Associated Press — NPS begins East Potomac tree-removal phase](https://apnews.com/article/trump-golf-course-trees-east-potomac-e13bd9c369ea4ebc3b95675a22865fb7) — independent eyewitness reporting with named agency response
- [The Washington Post — East Potomac filing and tree-removal plan](https://www.washingtonpost.com/sports/2026/10/09/more-than-500-trees-may-be-removed-dc-golf-course-trump-wants-redesign/) — independent reporting on federal filing, project scope and unresolved funding

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
