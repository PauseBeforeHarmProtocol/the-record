# National Park Service begins major East Potomac tree-removal phase

**Entry ID:** NAT-2026-10-10-001
**Date:** October 10, 2026
**Checked:** 2026-10-12 6:07 PM EDT
**Evidence state:** Associated Press eyewitness and hearing reporting, Reuters hearing and order reporting, named Interior/NPS statements, and Washington Post reporting on the federal filing; removals implemented, further cutting temporarily halted, wider redesign not finalized and merits unresolved
**Review state:** current-standard-reviewed

Crews removed roughly 500 trees before a federal judge temporarily halted further cutting and ordered testimony about the urgency, notice and chain of command.

## THE FACTS

- Associated Press observed National Park Service crews beginning tree removal at East Potomac Golf Links on October 10. The agency said 169 trees would be removed starting Saturday, another 90 later, and more than 500 trees classified as noncontributing to the historic landscape could ultimately be removed.
- The Interior Department said the work implements a seven-year-old plan to address overgrowth, restore historic views and preserve healthy trees that are contributing historic features, including healthy historic cherry trees. The agency said the public course would remain open, although individual holes may close temporarily.
- The Washington Post reported that NPS continued to call the broader Trump-backed redesign a potential project and had not released a final design, cost, funding plan or closure schedule. The report said 20 to 50 temporary workers and additional funding accelerated the tree work, but the filing did not identify the workers or funding source and amount. The linked court filing could not be retrieved in this review, so those filing details remain attributed to the two independent reports.
- The administration says the tree work is maintenance that would proceed independently of any redesign and does not change holes, routing, greens, bunkers or landforms. Plaintiffs in the pending preservation lawsuit argue preliminary work is already implementing the larger redevelopment; residents have also raised public-access, fee and open-space concerns.
- On October 12, U.S. District Judge Ana Reyes temporarily stopped further tree removal. Reuters reported that her Sunday order paused cutting until Tuesday morning; after a Monday hearing, Associated Press reported a 24-hour order that could be extended to 14 days. Reyes said the government's failure to provide notice had damaged its credibility, ordered officials to explain the holiday-weekend urgency and scheduled another hearing for testimony from Interior deputy chief of staff Greg Wischer. The pause is interim process relief, not a merits judgment that the maintenance or broader redesign is unlawful.

## SIGNIFICANCE

This is an implemented and partly irreversible physical change to federally managed public land that moved into emergency judicial oversight after roughly 500 trees were reported removed. The distinction between independent maintenance and the first stage of a championship-course redevelopment matters for historic-preservation review, court notice, public access and spending accountability; the temporary pause preserves process while the broader project's design, funding and legal merits remain unresolved.

## GOALPOST / RESPONSE

Interior and NPS say the work follows a 2019 landscape plan, improves safety, restores historic views and remains independent of the conceptual redesign. The immediate tests are compliance with the temporary stop, Wischer's testimony, any written extension or contempt process and the court's merits rulings; longer-term tests remain the final tree count and assessments, identified funding and workforce, preservation consultation, public-access effects and any final redesign.

## MAYBE / THEREFORE

Maybe the cutting was legitimate, urgent landscape maintenance performed with inadequate notice, as the government maintains, or it may function as an incremental redevelopment step that bypassed expected judicial scrutiny, as plaintiffs argue. Therefore the archive records the completed removals and enforceable temporary pause—not a final ruling that the work was unlawful, restoration of removed trees, approval or rejection of the broader redesign, or a contempt finding.


## SOURCES

- [Associated Press — NPS begins East Potomac tree-removal phase](https://apnews.com/article/trump-golf-course-trees-east-potomac-e13bd9c369ea4ebc3b95675a22865fb7) — independent eyewitness reporting with named agency response
- [The Washington Post — East Potomac filing and tree-removal plan](https://www.washingtonpost.com/sports/2026/10/09/more-than-500-trees-may-be-removed-dc-golf-course-trump-wants-redesign/) — independent reporting on federal filing, project scope and unresolved funding
- [Associated Press — judge orders temporary halt to East Potomac tree cutting](https://apnews.com/article/trump-golf-course-dc-judge-fdf4667378e21a8bd7fced6a80258ec8) — independent courtroom reporting, named official testimony and interim-order context
- [Reuters — judge temporarily blocks further East Potomac tree removal](https://www.reuters.com/legal/litigation/judge-blasts-trumps-doj-over-inexcusable-tree-removal-dc-golf-course-2026-10-12/) — independent court reporting on the temporary order, notice dispute and administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
