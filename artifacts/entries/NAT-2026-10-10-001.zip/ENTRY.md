# Federal judge preliminarily enjoins further East Potomac tree removal

**Entry ID:** NAT-2026-10-10-001
**Date:** October 10–26, 2026
**Checked:** 2026-10-26 11:59 PM EDT
**Evidence state:** primary 70-page D.D.C. preliminary-injunction opinion and order, independent Associated Press and Reuters reporting, and Trump's reviewed appeal statement; additional tree damage enjoined and notice ordered, with final merits, appeal filing, funding and project implementation unresolved
**Review state:** current-standard-reviewed

A federal judge found plaintiffs likely to prove unlawful NEPA segmentation, barred additional tree damage and required ten business days' notice before irreversible work; Trump announced an appeal.

## THE FACTS

- Associated Press observed National Park Service crews beginning tree removal at East Potomac Golf Links on October 10. The agency said 169 trees would be removed starting Saturday, another 90 later, and more than 500 trees classified as noncontributing to the historic landscape could ultimately be removed.
- The Interior Department said the work implements a seven-year-old plan to address overgrowth, restore historic views and preserve healthy trees that are contributing historic features, including healthy historic cherry trees. The agency said the public course would remain open, although individual holes may close temporarily.
- The Washington Post reported that NPS continued to call the broader Trump-backed redesign a potential project and had not released a final design, cost, funding plan or closure schedule. The report said 20 to 50 temporary workers and additional funding accelerated the tree work, but the filing did not identify the workers or funding source and amount. The linked court filing could not be retrieved in this review, so those filing details remain attributed to the two independent reports.
- The administration says the tree work is maintenance that would proceed independently of any redesign and does not change holes, routing, greens, bunkers or landforms. Plaintiffs in the pending preservation lawsuit argue preliminary work is already implementing the larger redevelopment; residents have also raised public-access, fee and open-space concerns.
- On October 12, U.S. District Judge Ana Reyes temporarily stopped further tree removal. Reuters reported that her Sunday order paused cutting until Tuesday morning; after a Monday hearing, Associated Press reported a 24-hour order that could be extended to 14 days. Reyes said the government's failure to provide notice had damaged its credibility, ordered officials to explain the holiday-weekend urgency and scheduled another hearing for testimony from Interior deputy chief of staff Greg Wischer. The pause is interim process relief, not a merits judgment that the maintenance or broader redesign is unlawful.
- On October 13, Reyes extended the halt through October 26. Her order also requires the government to give the court and plaintiffs three business days’ written advance notice before any irreparable modification to a permanent form or feature of the East Potomac Golf Course. This remains interim process relief while the underlying preservation case continues, not a merits ruling that the work or wider redesign is unlawful.
- On October 18, Trump published a conceptual plan image and said Interior Secretary Doug Burgum and National Park Service Director Jessica Fazio had developed a plan for East Potomac. He announced that the course would close November 15, that restoration work would begin that day, that reopening was expected in approximately 15 months and that the course would remain open to the public after completion. The publication establishes an announced plan and schedule; it does not establish that the closure or wider reconstruction has begun.
- Associated Press and The Washington Post reported that the announcement advances the redevelopment beyond its earlier conceptual description, while the cost and funding source remained undisclosed. The October 26 halt and advance-notice requirement remained in force, and litigation activity was still pending. Trump's stated hope that the course could host major championships is an aspiration, not a tournament award or governing-body commitment.
- On October 26, U.S. District Judge Loren AliKhan issued a 70-page preliminary injunction after finding the challengers likely to show that the East Potomac golf-course plan was final agency action and that the government unlawfully segmented environmental review under the National Environmental Policy Act. A likelihood finding at the preliminary stage is not a final merits judgment.
- The order preliminarily bars the National Park Service and contractors from removing, cutting, pruning or otherwise damaging additional trees and requires ten business days' written notice before other irreversible project modifications while the case proceeds. It also ordered the government to show cause by October 28 why a preservation order should not issue; the injunction does not itself cancel the announced redevelopment or supply a funding determination.
- The court said public presidential statements about the scope and purpose of the work conflicted with some sworn agency and Justice Department descriptions. Associated Press and Reuters independently reported the order and competing positions. That evidentiary tension informed preliminary relief but does not establish intentional deception or resolve all factual disputes.
- Trump then published that Interior would immediately appeal and ask the D.C. Circuit for relief, calling the notice requirement unconstitutional. The post is primary evidence that he made the statement; by the cutoff, the reviewed sources did not establish that an appeal or stay had been filed or granted, and the November 15 closure remained announced rather than implemented.

## SIGNIFICANCE

The preliminary injunction converts an emergency pause into enforceable prospective limits and a notice obligation after roughly 500 trees had already been removed. It is a material judicial finding that the challengers are likely to succeed on a NEPA segmentation claim, while leaving final merits, funding, preservation consultation, closure, construction and public-access outcomes unresolved.

## GOALPOST / RESPONSE

Interior, NPS and Trump say the project restores safety, historic views and a public course, and Trump says the notice requirement is unconstitutional. The immediate tests are compliance with the injunction, the October 28 preservation response, any filed appeal or stay and the district court's final merits decision. Longer-term tests remain a disclosed funding source and cost, preservation and environmental compliance, any actual November 15 closure, construction progress, reopening terms, fees and public access.

## MAYBE / THEREFORE

Maybe the government can show on appeal or a fuller record that the work is divisible and lawfully reviewed, or the preliminary findings may lead to redesign, delay or further injunctions. Therefore the archive records an operative preliminary injunction and an announced appeal—not a final NEPA judgment, a filed or successful appeal, cancellation of the project, secured funding or implementation of the November closure.


## SOURCES

- [Associated Press — NPS begins East Potomac tree-removal phase](https://apnews.com/article/trump-golf-course-trees-east-potomac-e13bd9c369ea4ebc3b95675a22865fb7) — independent eyewitness reporting with named agency response
- [The Washington Post — East Potomac filing and tree-removal plan](https://www.washingtonpost.com/sports/2026/10/09/more-than-500-trees-may-be-removed-dc-golf-course-trump-wants-redesign/) — independent reporting on federal filing, project scope and unresolved funding
- [Associated Press — judge orders temporary halt to East Potomac tree cutting](https://apnews.com/article/trump-golf-course-dc-judge-fdf4667378e21a8bd7fced6a80258ec8) — independent courtroom reporting, named official testimony and interim-order context
- [Reuters — judge temporarily blocks further East Potomac tree removal](https://www.reuters.com/legal/litigation/judge-blasts-trumps-doj-over-inexcusable-tree-removal-dc-golf-course-2026-10-12/) — independent court reporting on the temporary order, notice dispute and administration response
- [Associated Press — East Potomac work halt extended through October 26](https://apnews.com/article/trump-golf-course-04410cbb0deaa1ee77bfc7154b784201) — independent courtroom reporting and order details
- [Donald Trump Truth Social post — East Potomac redevelopment plan](https://truthsocial.com/@realDonaldTrump/117462306089931035) — primary presidential publication establishing the announcement, not independent verification of implementation
- [Associated Press — Trump publishes East Potomac golf-course redevelopment plan](https://apnews.com/article/trump-east-potomac-golf-course-ef8daa134bb6c7c08fd528d98aa3e77f) — independent reporting on the announced plan, court status and unresolved funding
- [The Washington Post — East Potomac plan advances beyond conceptual stage](https://www.washingtonpost.com/sports/2026/10/18/trump-share-plan-overhaul-east-potomac-golf-links/) — independent reporting on the announced plan, unresolved funding and pending litigation
- [D.D.C. — National Parks Conservation Association v. Burgum preliminary injunction](https://storage.courtlistener.com/recap/gov.uscourts.dcd.289401/gov.uscourts.dcd.289401.103.0.pdf) — primary preliminary-injunction memorandum opinion and order
- [Reuters — judge preliminarily blocks additional East Potomac tree removal](https://www.reuters.com/legal/government/judge-extends-block-trump-plans-renovate-washington-golf-course-2026-10-27/) — independent reporting on the preliminary injunction and announced appeal
- [Associated Press — East Potomac preliminary injunction](https://apnews.com/article/trump-golf-course-east-potomac-f1fafe7da7796e24b2b0626bc9f9ba42) — independent reporting on the order, factual record and administration response
- [Donald Trump Truth Social post — East Potomac appeal statement](https://truthsocial.com/@realDonaldTrump/117510783769373145) — primary evidence that Trump published an appeal announcement; underlying claims require independent verification

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
