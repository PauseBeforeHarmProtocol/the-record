# DOJ reports prospective East Potomac closure plan under existing injunction

**Entry ID:** NAT-2026-10-10-001
**Date:** October 10–October 28, 2026
**Checked:** 2026-10-29 12:07 AM EDT
**Evidence state:** AP and independent FOX 5 reports of court filings plus retained presidential post and inspected attached photos; original new notice/lease and appellate instruments unavailable. Prior original injunction and correction retained.
**Review state:** corrected

A reported court notice sets out planned submission and closure dates; neither construction nor closure is treated as completed.

## THE FACTS

- Associated Press observed National Park Service crews beginning tree removal at East Potomac Golf Links on October 10. The agency said 169 trees would be removed starting Saturday, another 90 later, and more than 500 trees classified as noncontributing to the historic landscape could ultimately be removed.
- The Interior Department said the work implements a seven-year-old plan to address overgrowth, restore historic views and preserve healthy trees that are contributing historic features, including healthy historic cherry trees. The agency said the public course would remain open, although individual holes may close temporarily.
- The Washington Post reported that NPS continued to call the broader Trump-backed redesign a potential project and had not released a final design, cost, funding plan or closure schedule. The report said 20 to 50 temporary workers and additional funding accelerated the tree work, but the filing did not identify the workers or funding source and amount. The linked court filing could not be retrieved in this review, so those filing details remain attributed to the two independent reports.
- The administration says the tree work is maintenance that would proceed independently of any redesign and does not change holes, routing, greens, bunkers or landforms. Plaintiffs in the pending preservation lawsuit argue preliminary work is already implementing the larger redevelopment; residents have also raised public-access, fee and open-space concerns.
- On October 12, U.S. District Judge Ana Reyes temporarily stopped further tree removal. Reuters reported that her Sunday order paused cutting until Tuesday morning; after a Monday hearing, Associated Press reported a 24-hour order that could be extended to 14 days. Reyes said the government's failure to provide notice had damaged its credibility, ordered officials to explain the holiday-weekend urgency and scheduled another hearing for testimony from Interior deputy chief of staff Greg Wischer. The pause is interim process relief, not a merits judgment that the maintenance or broader redesign is unlawful.
- On October 13, Reyes extended the halt through October 26. Her order also requires the government to give the court and plaintiffs three business days’ written advance notice before any irreparable modification to a permanent form or feature of the East Potomac Golf Course. This remains interim process relief while the underlying preservation case continues, not a merits ruling that the work or wider redesign is unlawful.
- On October 18, Trump published a conceptual plan image and said Interior Secretary Doug Burgum and National Park Service Director Jessica Fazio had developed a plan for East Potomac. He announced that the course would close November 15, that restoration work would begin that day, that reopening was expected in approximately 15 months and that the course would remain open to the public after completion. The publication establishes an announced plan and schedule; it does not establish that the closure or wider reconstruction has begun.
- Associated Press and The Washington Post reported that the announcement advances the redevelopment beyond its earlier conceptual description, while the cost and funding source remained undisclosed. The October 26 halt and advance-notice requirement remained in force, and litigation activity was still pending. Trump's stated hope that the course could host major championships is an aspiration, not a tournament award or governing-body commitment.
- On October 26, U.S. District Judge Ana C. Reyes signed a 70-page memorandum opinion granting preliminary injunctive relief after finding the challengers likely to show final agency action and unlawful segmentation of environmental review under NEPA. This is a preliminary likelihood finding, not a final merits judgment. The earlier attribution to Loren AliKhan was incorrect.
- The order preliminarily bars the National Park Service and contractors from removing, cutting, pruning or otherwise damaging additional trees and requires ten business days' written notice before other irreversible project modifications while the case proceeds. It also ordered the government to show cause by October 28 why a preservation order should not issue; the injunction does not itself cancel the announced redevelopment or supply a funding determination.
- The court said public presidential statements about the scope and purpose of the work conflicted with some sworn agency and Justice Department descriptions. Associated Press and Reuters independently reported the order and competing positions. That evidentiary tension informed preliminary relief but does not establish intentional deception or resolve all factual disputes.
- Trump then published that Interior would immediately appeal and ask the D.C. Circuit for relief, calling the notice requirement unconstitutional. The post is primary evidence that he made the statement; at the October 27 evidence cutoff, the reviewed sources did not establish that an appeal or stay had been filed or granted, and the November 15 closure remained announced rather than implemented. Original appellate filings and any stay remain uninspected in this correction review.
- Associated Press reported that DOJ filed a notice October 28 stating NPS would submit Tom Fazio’s rendering to the National Capital Planning Commission on October 30 and close East Potomac Park south of Buckeye Drive, including the course, on November 15. AP also reported a new operator lease arrangement. These are reported filing contents and prospective dates, not completed closure, approval, funding or construction. The original new notice and lease were not retrieved. FOX 5 independently reported Interior’s written acknowledgement that it was developing the closure plan.
- Later October 28, Trump published a safety-based demand for immediate driving-range closure, promised an affordable public course and said he would hold Judge Ana C. Reyes responsible for injuries or deaths. The post and ten visually inspected photographs establish what he published, not a professional safety determination, independently verified injury or a new court order. The photographs’ capture dates and locations were not independently authenticated.

## SIGNIFICANCE

The reported filing narrows the earlier gap between presidential announcements and agency descriptions by setting out an agency timetable in court. It does not dissolve the existing injunction or settle preservation, safety, cost and public-access disputes.

## GOALPOST / RESPONSE

Trump and the agencies frame the project as safety, modernization and affordable public recreation. His photographs are evidence of his presentation, not an engineering inspection or a basis to assign legal responsibility to the judge. Original notice and lease terms, compliance with the injunction, planning review, appropriations, fees and actual closure/reopening remain the tests.

## MAYBE / THEREFORE

Maybe a compliant renovation can improve safety and public access, or the stated timetable and access promises will change under legal and funding constraints. Therefore this update records a reported prospective agency plan and presidential response—not implemented closure, final project approval, secured funding, an appellate stay or verified safety liability.

## CORRECTIONS

- **2026-10-28T16:10:45Z** — Corrected the October 26 opinion’s author from Loren AliKhan to Ana C. Reyes after inspecting Document 103 cover, opening relief description and page 70 signature in DC Preservation League v. Department of Interior, 1:26-cv-00477-ACR. Corrected source caption; original entry and source metadata retained. No new appeal/stay outcome inferred.


## SOURCES

- [Associated Press — NPS begins East Potomac tree-removal phase](https://apnews.com/article/trump-golf-course-trees-east-potomac-e13bd9c369ea4ebc3b95675a22865fb7) — independent eyewitness reporting with named agency response
- [The Washington Post — East Potomac filing and tree-removal plan](https://www.washingtonpost.com/sports/2026/10/09/more-than-500-trees-may-be-removed-dc-golf-course-trump-wants-redesign/) — independent reporting on federal filing, project scope and unresolved funding
- [Associated Press — judge orders temporary halt to East Potomac tree cutting](https://apnews.com/article/trump-golf-course-dc-judge-fdf4667378e21a8bd7fced6a80258ec8) — independent courtroom reporting, named official testimony and interim-order context
- [Reuters — judge temporarily blocks further East Potomac tree removal](https://www.reuters.com/legal/litigation/judge-blasts-trumps-doj-over-inexcusable-tree-removal-dc-golf-course-2026-10-12/) — independent court reporting on the temporary order, notice dispute and administration response
- [Associated Press — East Potomac work halt extended through October 26](https://apnews.com/article/trump-golf-course-04410cbb0deaa1ee77bfc7154b784201) — independent courtroom reporting and order details
- [Donald Trump Truth Social post — East Potomac redevelopment plan](https://truthsocial.com/@realDonaldTrump/117462306089931035) — primary presidential publication establishing the announcement, not independent verification of implementation
- [Associated Press — Trump publishes East Potomac golf-course redevelopment plan](https://apnews.com/article/trump-east-potomac-golf-course-ef8daa134bb6c7c08fd528d98aa3e77f) — independent reporting on the announced plan, court status and unresolved funding
- [The Washington Post — East Potomac plan advances beyond conceptual stage](https://www.washingtonpost.com/sports/2026/10/18/trump-share-plan-overhaul-east-potomac-golf-links/) — independent reporting on the announced plan, unresolved funding and pending litigation
- [D.D.C. — DC Preservation League v. Department of Interior, 1:26-cv-00477-ACR, Document 103 memorandum opinion](https://storage.courtlistener.com/recap/gov.uscourts.dcd.289401/gov.uscourts.dcd.289401.103.0.pdf) — primary preliminary-injunction memorandum opinion
- [Reuters — judge preliminarily blocks additional East Potomac tree removal](https://www.reuters.com/legal/government/judge-extends-block-trump-plans-renovate-washington-golf-course-2026-10-27/) — independent reporting on the preliminary injunction and announced appeal
- [Associated Press — East Potomac preliminary injunction](https://apnews.com/article/trump-golf-course-east-potomac-f1fafe7da7796e24b2b0626bc9f9ba42) — independent reporting on the order, factual record and administration response
- [Donald Trump Truth Social post — East Potomac appeal statement](https://truthsocial.com/@realDonaldTrump/117510783769373145) — primary evidence that Trump published an appeal announcement; underlying claims require independent verification
- [AP — DOJ notice confirms prospective East Potomac plan and closure](https://www.clickondetroit.com/news/politics/2026/10/29/justice-department-announces-trump-plans-for-golf-course-are-in-the-works-course-will-close-nov-15/) — independent report quoting filed notice; original new notice not retrieved
- [FOX 5 DC — Interior acknowledges developing East Potomac closure plan](https://www.fox5dc.com/news/interior-dept-moves-toward-november-closure-east-potomac-golf-course-court-battle-intensifies) — independent report of filing and competing public-access positions
- [Trump — East Potomac safety rationale and statement blaming Judge Reyes](https://truthsocial.com/@realDonaldTrump/117521895212942057) — primary publication only; photographs not independent safety assessment

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
