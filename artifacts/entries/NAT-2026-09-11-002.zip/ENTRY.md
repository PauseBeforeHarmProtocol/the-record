# State Department continues Cyprus defense-trade eligibility through fiscal 2027

**Entry ID:** NAT-2026-09-11-002
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 AM EDT
**Evidence state:** complete primary final rule inspected; one-year policy suspension finalized, individual licenses and material outcomes not established
**Review state:** current-standard-reviewed

The October 1 rule suspends Cyprus's proscribed-destination status for one year; licenses remain case-specific and no sale or delivery is authorized by the rule alone.

## THE FACTS

- The State Department published a final rule on September 11, effective October 1, 2026, suspending the Republic of Cyprus's status as a proscribed destination under the International Traffic in Arms Regulations from October 1, 2026 through September 30, 2027.
- The rule continues a policy in effect since October 1, 2022 and covers exports, reexports, retransfers, temporary imports and brokering involving Cyprus, subject to ordinary licensing requirements and available exemptions.
- The Secretary of State certified on July 10 that Cyprus met annual statutory conditions concerning anti-money-laundering and financial oversight cooperation and denying Russian military vessels port access for refueling and servicing.
- The suspension allows case-by-case consideration of otherwise eligible defense trade. It is not a blanket arms-transfer approval, contract, appropriation, shipment or finding that every proposed transaction satisfies U.S. law and policy.

## SIGNIFICANCE

Continuing the suspension keeps a NATO-adjacent Eastern Mediterranean partner eligible for licensed U.S. defense trade while conditioning the policy on annual financial-integrity and Russian-port-access findings. Actual military capability, regional-security effects and transaction volumes remain unmeasured.

## GOALPOST / RESPONSE

The State Department says Cyprus met Congress's statutory conditions and that the continued suspension serves U.S. defense-trade policy. Issued licenses, completed transfers, end-use monitoring, future certifications and regional-security evidence are the tests.

## MAYBE / THEREFORE

Maybe continued eligibility strengthens cooperation and deters Russian military access, or expanded trade could add regional tension without producing the claimed benefits. Therefore the rule continues eligibility for case-by-case licensing for one year—not a completed weapons sale, guaranteed approval or measured security outcome.


## SOURCES

- [State Department — Cyprus defense-trade policy under ITAR](https://www.federalregister.gov/documents/2026/09/11/2026-18630/amendment-to-the-international-traffic-in-arms-regulations-prohibited-exports-imports-and-sales-to) — primary Federal Register final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
