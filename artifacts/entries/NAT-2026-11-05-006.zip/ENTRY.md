# DOJ legal opinion says current magnet-school grant implementation is largely unconstitutional

**Entry ID:** NAT-2026-11-05-006
**Date:** November 5, 2026
**Checked:** 2026-11-06 6:10 AM EST
**Evidence state:** primary OLC opinion, DOJ release and Education program description, with ideologically aligned independent reporting used only as publication corroboration; legal interpretation published, downstream grant actions unresolved
**Review state:** current-standard-reviewed

The Office of Legal Counsel concluded that Education may fund only narrowly tailored remedies for identified illegal discrimination; the opinion does not itself cancel the 60 active grants or constitute a court judgment.

## THE FACTS

- The Justice Department's Office of Legal Counsel published a 37-page opinion concluding that the Education Department's current implementation of the Magnet Schools Assistance Program uses race-conscious criteria that trigger strict scrutiny and, in most applications described, do not satisfy it.
- OLC concluded that Education may make grants only when the funded measure is narrowly tailored to remedy specific, identified illegal discrimination. It rejected generalized racial balancing or diversity as sufficient justification under its reading of Supreme Court precedent.
- The opinion says the program had 60 active grants in 18 states: 52 supporting voluntary plans and eight associated with court-ordered plans. Education's program page describes MSAP as supporting desegregation and magnet-school development.
- The opinion is a formal executive-branch legal interpretation and DOJ announced it as binding administration guidance. It does not itself identify canceled grants, recoup funds, amend the statute, or create a judicial ruling; implementation steps and effects on individual awards were not established by cutoff.

## SIGNIFICANCE

The opinion materially narrows the administration's asserted legal authority for race-conscious federal magnet-school grants and may affect active and future awards across multiple states. Its immediate evidence is a formal legal interpretation, not proof that grants were terminated or that a court adopted the analysis.

## GOALPOST / RESPONSE

DOJ says federal aid cannot be conditioned on unconstitutional race-based criteria and permits only narrowly tailored remedies for identified discrimination. The tests are Education Department directives, grant modifications or cancellations, notices to recipients, litigation and court treatment, and measured changes in school access and segregation.

## MAYBE / THEREFORE

Maybe Education can revise awards around specific remedial findings without ending the program, or implementation and litigation may substantially reduce funded desegregation plans. Therefore OLC has issued a consequential formal interpretation limiting current implementation—not canceled all active grants, invalidated the statute or obtained a court judgment.


## SOURCES

- [DOJ OLC — constitutionality of the Magnet Schools Assistance Program](https://www.justice.gov/olc/media/1470461/dl) — primary 37-page formal legal opinion on current MSAP implementation and strict scrutiny
- [DOJ — federal education aid cannot be tied to unconstitutional race-based criteria](https://www.justice.gov/opa/pr/justice-department-says-federal-education-aid-cannot-be-tied-unconstitutional-race-based) — primary department release summarizing the OLC opinion and administration legal rationale
- [Education Department — Magnet Schools Assistance Program](https://www.ed.gov/grants-and-programs/grants-birth-grade-12/school-and-community-improvement-grants/magnet-schools-assistance-program-msap) — primary program page describing MSAP's statutory and grant purpose
- [The Federalist — report on DOJ Magnet Schools Assistance Program opinion](https://thefederalist.com/2026/11/05/exclusive-doj-stops-race-based-funding-for-federal-student-aid/) — independent but ideologically aligned reporting on publication and stated implications of the OLC opinion

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
