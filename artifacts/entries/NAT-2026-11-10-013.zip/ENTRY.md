# HUD publishes department-wide headquarters and field reorganization plan

**Entry ID:** NAT-2026-11-10-013
**Date:** November 10, 2026
**Checked:** 2026-11-11 12:02 PM EST
**Evidence state:** Primary HUD Federal Register notice and independent stakeholder summary; announced and scheduled, with implementation, personnel and service effects unresolved
**Review state:** current-standard-reviewed

The notice consolidates program, legal, technology and administrative structures after staff departures while promising no office closures or relocations.

## THE FACTS

- HUD published its reorganization notice and statutory cost-benefit analysis on November 10, before the prior archive boundary; this release records a retrospective discovery. Field-office changes subject to the statute may begin about 90 days after publication, with phased implementation through fiscal 2027.
- The plan would consolidate public-housing and voucher functions, centralize fair-housing enforcement management, unify headquarters and field counsel under program-based chains, restructure technology and acquisition offices, reduce authorized human-capital executive positions and realign numerous other divisions.
- HUD says staffing is almost 35% below historical levels after voluntary departures. The notice states that the plan does not close offices, relocate staff or reduce current staffing and expects no immediate quantifiable savings, although duties and reporting lines may change.
- HUD says consolidation will improve consistency and service using current resources; the National Association of Development Organizations described the department-wide schedule and staffing-loss rationale. Actual reorganizations, personnel effects, service access, enforcement consistency, costs and savings have not yet been measured.

## SIGNIFICANCE

The plan would alter how a major housing and civil-rights agency manages grants, vouchers, fair-housing enforcement, legal work, technology and field operations after substantial attrition. Formal notice is complete, but implementation and public-service effects are pending.

## GOALPOST / RESPONSE

HUD says the new structure will reduce silos and preserve service without closures or relocations. The tests are final organizational charts, staffing and grade actions, office access, complaint and grant-processing times, enforcement patterns, audit findings, costs, savings and congressional oversight.

## MAYBE / THEREFORE

Maybe consolidating functions lets a smaller workforce maintain service and improve consistency, or centralization may reduce regional expertise, access and independent checks without delivering measurable savings. Therefore the record establishes a published reorganization plan and statutory waiting period—not completed implementation, staff neutrality or improved HUD performance.


## SOURCES

- [Federal Register — HUD headquarters and field operating-model reorganization notice](https://www.federalregister.gov/documents/2026/11/10/2026-22838/notice-of-intent-to-reorganize-hud-and-revise-headquarters-and-field-operating-model) — primary notice of intent and statutory cost-benefit analysis
- [NADO — HUD issues department-wide reorganization notice](https://www.nado.org/department-of-housing-and-urban-development-issue-notice-of-intent-to-reorganize-agency-and-revise-headquarters-and-field-operating-model/) — independent stakeholder summary of the notice and implementation schedule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
