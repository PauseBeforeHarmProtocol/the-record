# OMB orders phased Login.gov expansion across public services

**Entry ID:** NAT-2026-08-31-008
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** primary six-page OMB memorandum M-26-18 with scope, exceptions, policy requirements and deadlines, plus the White House implementation framing; mandate issued, agency migration and outcomes pending
**Review state:** current-standard-reviewed

Memorandum M-26-18 makes Login.gov the default government sign-on for most authenticated public-facing services, with inventories due in 60 days and broad deployment due within two years.

## THE FACTS

- Office of Management and Budget Director Russell Vought issued Memorandum M-26-18, directing agencies to offer Login.gov as a sign-on option for in-scope public-facing websites used by individuals acting for themselves. For services requiring identity verification, agencies generally must use Login.gov unless it does not meet user-base, risk-profile or operational requirements.
- The policy does not cover sites accessed solely by organizations or people acting for a business, government or another individual, though agencies may extend Login.gov to them. The statutory mandate and specified deployment deadlines do not apply to the Department of War, intelligence-community elements or national-security systems.
- Agencies may retain other identity solutions for needs Login.gov cannot fully meet or to avoid burdening significant user populations, but must phase out solutions outside those categories, promote Login.gov as the default for new accounts it can serve and periodically reassess alternatives.
- The memo requires an inventory of authenticated public websites within 60 days, digital-identity risk reviews within 240 days, Login.gov deployment for OMB-designated High Impact Service Provider sites within one year and deployment across all existing in-scope sites within two years. An agency missing a deployment deadline must submit a personally certified notice from its head to OMB and specified congressional committees.
- The memo also directs agencies to monitor pass rates, abandonment, completion time, fraud, security and privacy outcomes, and encourages reuse of previously verified credentials and user-consented information subject to law and privacy safeguards. Issuance begins a phased mandate; it does not mean every federal service already uses one account or shares information across agencies.

## SIGNIFICANCE

A government-wide default can reduce repeated account creation and identity checks, lower duplicative verification costs and improve security at scale. It also concentrates more public-service access in a common identity platform, making accessibility, privacy, outage resilience, fraud controls and lawful data reuse consequential implementation questions.

## GOALPOST / RESPONSE

OMB says a consistent government-operated platform will make services easier, cheaper and more secure while preserving risk-based exceptions. The strongest concern is that identity-proofing failures or central-platform problems could block access across multiple services or increase privacy and security consequences. Agency inventories, exception notices, deployment reports, pass and abandonment rates, fraud incidents, privacy assessments, outages, cost data and user complaints are the tests.

## MAYBE / THEREFORE

Maybe phased migration and permitted alternatives will deliver a simpler sign-on without excluding users, or centralization may shift rather than eliminate verification burdens and create a larger common point of failure. Therefore the record documents an operative OMB mandate with future milestones and exceptions—not a completed universal account, cross-agency data merger or measured improvement in access, cost or security.


## SOURCES

- [OMB Memorandum M-26-18 — Scaling Use of Login.gov](https://www.whitehouse.gov/wp-content/uploads/2026/08/M-26-18-Scaling-Use-of-Login.gov-to-Deliver-a-Universal-Sign-on-for-Public-Services.pdf) — primary government-wide memorandum with scope, exceptions, identity-policy requirements, metrics and phased deadlines
- [White House — universal Login.gov sign-on fact sheet](https://www.whitehouse.gov/fact-sheets/2026/08/fact-sheet-delivering-a-universal-sign-on-for-public-services/) — primary administration explanation of the Login.gov mandate's intended service, cost, security and user-experience benefits

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
