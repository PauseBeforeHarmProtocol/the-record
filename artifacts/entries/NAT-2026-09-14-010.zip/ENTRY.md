# Accenture agrees to $25 million federal settlement over employment-practice allegations

**Entry ID:** NAT-2026-09-14-010
**Date:** September 14, 2026
**Checked:** 2026-09-15 12:31 AM EDT
**Evidence state:** complete signed Justice Department settlement agreement and official press release, plus independent Reuters reporting and Accenture response; settlement signed, payment due, allegations unresolved and no liability admitted
**Review state:** current-standard-reviewed

The signed False Claims Act agreement resolves allegations about federal-contractor certifications; Accenture denied discrimination and liability, and payment remained due.

## THE FACTS

- The United States, Accenture Federal Services, Accenture plc and Accenture LLP signed a civil settlement requiring a $25 million payment, including $11.627 million identified as restitution, plus 4% annual interest from September 9. The agreement requires electronic payment within 14 days of its effective date; the record does not claim the money had been received by cutoff.
- The United States alleged that, from 2017 through the agreement’s effective date, Accenture Federal Services knowingly submitted false federal-contract claims or certifications while considering race or sex in hiring and promotion decisions and allocating associated costs to government contracts. These are government allegations resolved by agreement, not judicial findings.
- The government also alleged that Accenture restricted eligibility for some training, mentoring, leadership-development and educational programs based on race or sex. The settlement states that Accenture denies the covered conduct and that the agreement is neither an admission by Accenture nor a concession by the United States that its claims were unfounded.
- Conditioned on receipt of the settlement amount, the United States releases specified civil and administrative monetary claims for the covered conduct. The agreement reserves criminal liability, tax claims, suspension or debarment and other administrative remedies, Equal Employment Opportunity Commission charges, individual liability and claims involving conduct outside the covered period.
- Accenture told Reuters it cooperated with the review and chose settlement to avoid the cost and resource demands of prolonged litigation. The agreement also treats specified government-contract costs as unallowable and preserves repayment and audit mechanisms; it does not establish criminal guilt, a merits judgment or that every diversity, equity and inclusion program is unlawful.

## SIGNIFICANCE

The agreement uses False Claims Act and federal-contract certification authority to impose a substantial monetary obligation over alleged race- and sex-conscious employment practices. It is a concrete enforcement action and compliance signal, while its no-admission resolution leaves the factual and legal merits unadjudicated.

## GOALPOST / RESPONSE

The Justice Department says federal contractors must compete and make employment decisions on merit without race or sex discrimination. Accenture denies the alleged conduct and says it settled to avoid prolonged litigation. Receipt of payment, treatment of unallowable costs, audits, suspension or debarment decisions, EEOC action, contested-court rulings and measured employment outcomes are the tests.

## MAYBE / THEREFORE

Maybe the settlement deters unlawful preferences and improves contractor compliance, or broad enforcement theories may chill lawful outreach and opportunity programs without clarifying the legal boundary. Therefore the record establishes a signed $25 million civil settlement and payment obligation—not an admission, a judicial liability finding, criminal guilt, a universal ban on diversity programs or a measured change in hiring outcomes.


## SOURCES

- [United States–Accenture settlement agreement](https://www.justice.gov/opa/media/1461181/dl) — primary signed ten-page civil settlement agreement; payment, releases, denials and reserved claims
- [Justice Department — Accenture agrees to pay $25 million](https://www.justice.gov/opa/pr/accenture-agrees-pay-25m-resolve-alleged-employment-discrimination-violations) — official announcement and allegation summary; claims are allegations with no determination of liability
- [Reuters — Accenture to pay $25 million to settle U.S. allegations over DEI](https://www.reuters.com/legal/government/accenture-pay-25-million-settle-us-government-allegations-over-dei-2026-09-15/) — independent reporting of signed settlement, allegations and Accenture response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
