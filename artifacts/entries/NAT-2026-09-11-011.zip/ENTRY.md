# Federal judge stays OPM's executive-order essay question for civil-service applicants

**Entry ID:** NAT-2026-09-11-011
**Date:** September 11, 2026
**Checked:** 2026-09-12 12:01 AM EDT
**Evidence state:** filed district-court opinion plus Reuters; question and preliminary stay confirmed, final merits and appeal unresolved
**Review state:** current-standard-reviewed

The preliminary APA stay suspends the question while litigation continues; the judge denied a separate hiring-decisions injunction and did not enter a final merits judgment.

## THE FACTS

- On September 11, U.S. District Judge George O'Toole granted in part a request by three public-employee unions challenging an Office of Personnel Management question used in federal civil-service applications. Under Administrative Procedure Act section 705, he stayed implementation and use of the question during the litigation.
- The question asks applicants how they would advance the president's executive orders and policy priorities, to identify one or two orders or initiatives significant to them, and to explain how they would implement them. OPM's May 2025 Merit Hiring Plan generally required the four-question essay set for public competitive-service postings at GS-5 and above, subject to stated exceptions and agency exemptions.
- The court found the unions likely to succeed in showing that applicants reasonably read the question as seeking personal political views, that the government had not identified a legitimate need to inquire into political beliefs for the covered career jobs, and that the question was not narrowly tailored. Those are preliminary likelihood findings, not final adjudications.
- OPM guidance said responses were optional, would not be scored, must comply with merit-system rules and could not be used as an ideological litmus test. The court concluded that the guidance did not change how a reasonable applicant could understand the question's plain language.
- The judge denied the unions' separate request to preliminarily enjoin OPM from considering answers or nonanswers in individual hiring decisions, finding that remedy would not redress the injury they alleged and that they lacked standing to seek it. The order therefore stays the question itself but is not a final judgment, a damages award or a categorical ruling on every hiring decision.

## SIGNIFICANCE

The order temporarily halts a government-wide hiring device that a federal court found likely to burden protected political expression. Its split remedy matters: the question is stayed, but the court did not finally decide the case or enjoin every use of applicant responses through the separately requested theory.

## GOALPOST / RESPONSE

OPM says the essays help assess commitment to public service and implementation while remaining optional, unscored and nonpolitical. The unions say the question functions as a loyalty test. Merits proceedings, any appeal, revised guidance, actual vacancy forms and documented hiring decisions are the tests.

## MAYBE / THEREFORE

Maybe the question can be rewritten or administered as a neutral work-planning prompt, or its reference to personally significant presidential policies may continue to chill applicants and politicize career hiring. Therefore the court's September 11 action is recorded as a temporary APA stay based on likely success—not a final constitutional judgment, a universal hiring injunction or proof that a named applicant was rejected for political beliefs.


## SOURCES

- [District of Massachusetts — AFGE v. Kupor opinion and order](https://democracyforward.org/wp-content/uploads/2026/09/86-2026-09-11-Judge-George-A.-OToole-Jr-ORDER-entered.-OPINION-AND.pdf) — primary judicial opinion
- [Reuters — judge blocks OPM executive-order essay question](https://www.reuters.com/legal/government/us-judge-blocks-trump-administrations-loyalty-question-job-applicants-2026-09-12/) — independent legal reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
