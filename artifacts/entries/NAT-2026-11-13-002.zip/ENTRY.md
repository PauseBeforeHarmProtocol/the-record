# Hassan opens inquiry into DHS's $495.6 million Minnesota detention-facility purchase

**Entry ID:** NAT-2026-11-13-002
**Date:** November 13, 2026
**Checked:** 2026-11-13 12:05 PM EST
**Evidence state:** Primary CoreCivic transaction release plus Reuters and Washington Post reporting on the dated Senate preservation letters and responses; transaction and inquiry established, valuation and misconduct questions unresolved
**Review state:** current-standard-reviewed

The Senate homeland-security ranking member requested preservation of procurement records after DHS bought a 1,600-bed facility from CoreCivic; the inquiry raises valuation and influence questions but has not established wrongdoing.

## THE FACTS

- Senator Maggie Hassan, the ranking Democrat on the Senate Homeland Security and Governmental Affairs Committee, opened a formal inquiry into the Department of Homeland Security's purchase of the 1,600-bed Prairie Correctional Facility in Appleton, Minnesota. Letters dated November 11 to DHS and CoreCivic requested preservation and production of records; the inquiry was made public November 13.
- CoreCivic announced on August 5 that DHS paid $495.6 million for Prairie as part of a two-facility, $734 million transaction. CoreCivic said it expected to continue operating both facilities under existing ICE management contracts.
- Hassan's office questioned why the federal price was far above a reported $75 million offer Minnesota declined. Her concerns about stewardship, improper influence and corruption are investigative questions and allegations, not findings.
- CoreCivic said Prairie is a specialized property, an independent appraiser was used, renovations were reflected in the valuation and the prior $75 million state offer was not an appraisal or replacement-cost estimate.
- Reuters and The Washington Post reported that DHS and ICE did not provide an immediate transaction-specific response. A DHS general-counsel statement addressing the broader wave of Democratic inquiries called them political shenanigans and said the department was prepared to respond.

## SIGNIFICANCE

The inquiry subjects a major detention-capacity acquisition to congressional scrutiny over price, procurement and continuing private operation. It creates a formal oversight record but does not by itself prove overpayment, favoritism, corruption or an unlawful sale.

## GOALPOST / RESPONSE

The administration and CoreCivic can substantiate the purchase by producing the appraisal, alternatives analysis, renovation and replacement-cost assumptions, procurement approvals, conflict checks, management-contract terms and capacity projections. The inquiry should distinguish market value, replacement cost and the terms of the rejected state offer, and identify any legal or procurement violation with documentary evidence.

## MAYBE / THEREFORE

Maybe the price reflected a renovated, specialized 1,600-bed property and rapid federal capacity needs, or the records may show weak competition, inflated assumptions or improper influence. Therefore the record establishes the $495.6 million purchase and a formal congressional preservation-and-production inquiry—not a finding of corruption, unlawful procurement or overpayment.


## SOURCES

- [Democratic US senator probes CoreCivic sale of ICE facility in Minnesota](https://www.reuters.com/world/us/democratic-us-senator-probes-corecivic-sale-ice-facility-minnesota-2026-11-13/) — independent reporting
- [Democrats target costly DHS prison purchase as part of broad immigration probes](https://www.washingtonpost.com/politics/2026/11/13/democrats-target-costly-dhs-prison-purchase-part-broad-immigration-probes/) — independent reporting
- [CoreCivic sells two facilities to Department of Homeland Security for $734 million](https://corecivic.gcs-web.com/node/25546) — company transaction release

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
