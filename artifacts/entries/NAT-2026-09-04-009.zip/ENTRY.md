# NHTSA opens Tesla Cybercab self-certification investigation

**Entry ID:** NAT-2026-09-04-009
**Date:** September 4, 2026
**Checked:** 2026-09-04 12:00 PM EDT
**Evidence state:** primary NHTSA enforcement announcement plus independent Reuters reporting; formal investigation open, no merits or remedy determination
**Review state:** current-standard-reviewed

The Audit Query examines how Tesla certified a driverless vehicle without traditional controls under existing safety standards; it is an investigation, not a noncompliance finding or recall.

## THE FACTS

- The National Highway Traffic Safety Administration opened Audit Query AQ26002 after Tesla commercially deployed Cybercab vehicles in Austin, Texas, to examine the company's self-certification that the vehicles comply with all applicable Federal Motor Vehicle Safety Standards.
- NHTSA said the inquiry will assess the technical data and processes Tesla used for a vehicle without traditional human controls, including whether the company treated particular safety-standard requirements as inapplicable. The agency emphasized that current standards remain in force while it pursues eight related rulemakings.
- Reuters reported that the audit covers about 1,000 Cybercab vehicles. The United States generally allows manufacturers to self-certify compliance, while a separate exemption route for noncompliant vehicles is capped at 2,500 vehicles annually.
- Tesla did not respond to Reuters' request for comment. NHTSA had not issued a noncompliance finding, stop-use order, civil penalty, recall or exemption decision by cutoff.

## SIGNIFICANCE

The inquiry tests whether existing safety law can govern a commercially deployed automated vehicle designed without steering wheels, pedals or mirrors while federal standards are still being rewritten. Its outcome could shape both public-road deployment and the boundary between innovation policy and safety enforcement.

## GOALPOST / RESPONSE

NHTSA says it supports automated-vehicle innovation but must confirm compliance with existing law. Tesla has promoted Cybercab as a scalable driverless service. The audit file, Tesla's certification analysis and data, any information request, defect or noncompliance finding, corrective action, exemption filing, rulemaking, crash record and judicial review are the tests.

## MAYBE / THEREFORE

Maybe Tesla has a defensible standards interpretation for a vehicle without human controls, or the self-certification may rely on inapplicability claims that NHTSA rejects. Therefore the record establishes an opened federal Audit Query following deployment—not proven illegality, a safety defect, a recall or approval of Cybercab's compliance.


## SOURCES

- [NHTSA — Tesla Cybercab self-certification Audit Query](https://www.nhtsa.gov/press-releases/investigation-tesla-cybercab-self-certification) — primary federal enforcement announcement opening an investigation into compliance with existing vehicle safety standards
- [Reuters — NHTSA opens Cybercab compliance probe after Austin deployment](https://www.reuters.com/legal/litigation/musk-pushes-regulatory-limits-with-teslas-cybercab-robotaxi-service-2026-09-04/) — independent reporting on the investigation, deployment scale, self-certification framework and unresolved compliance questions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
