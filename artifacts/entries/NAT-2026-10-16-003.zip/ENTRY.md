# U.S. lifts restrictions on new Mexican flights from Mexico City airports

**Entry ID:** NAT-2026-10-16-003
**Date:** October 16, 2026
**Checked:** 2026-10-16 6:01 PM EDT
**Evidence state:** Reuters reporting on implemented DOT action and corrected source attribution, with prior primary U.S. and Mexican government records establishing the restrictions and remediation framework
**Review state:** current-standard-reviewed

The Transportation Department removed restrictions that had blocked Mexican airlines from opening new U.S. service from AIFA and AICM. The action reopens the application pathway but does not itself approve, schedule or operate a new route.

## THE FACTS

- Reuters reported, citing a joint statement from Mexico’s foreign-affairs and transportation ministries, that the U.S. Department of Transportation lifted restrictions preventing Mexican airlines from launching new U.S. flights from Felipe Ángeles International Airport and Benito Juárez International Airport. Reuters corrected its initial attribution so the statement is not misdescribed as a joint U.S.–Mexico release.
- DOT imposed the restrictions in October 2025, revoking or blocking 13 current or planned routes after concluding that Mexico had not honored fair-access obligations under the bilateral air-transport agreement.
- In May 2026, U.S. and Mexican officials announced a preliminary aviation understanding addressing slot access at AICM and the treatment of AIFA within the metropolitan airport system. Mexican agencies said the October 16 decision followed that cooperation and compliance work.
- The lifting is an implemented removal of a federal constraint. It makes new applications possible but does not identify a carrier, approve a particular route, establish a start date or show that an additional flight has operated.

## SIGNIFICANCE

The decision reverses a major enforcement step in the bilateral aviation dispute and restores a pathway for Mexican carriers to expand U.S. service from both Mexico City airports. Its practical effect depends on carrier applications, slot access, safety approvals and actual service.

## GOALPOST / RESPONSE

DOT’s earlier position was that sanctions were necessary to enforce fair market access; both governments later presented the May framework as a technical path to compliance. Published revocation terms, route applications and approvals, reciprocal slot access, new schedules, passenger capacity and operated flights are the tests.

## MAYBE / THEREFORE

Maybe the restored application pathway increases competition and connectivity, or operational and commercial constraints may limit new service despite removal of the federal barrier. Therefore the restrictions were lifted; no specific new route or flight is counted as approved or operating.


## SOURCES

- [Reuters — U.S. lifts restrictions on new Mexican flights from Mexico City airports](https://www.reuters.com/world/us/us-lifts-restrictions-new-mexican-flights-capitals-airports-2026-10-16/) — independent reporting on implemented U.S. transportation action and corrected statement attribution
- [Transportation Department — restrictions on 13 Mexican-carrier routes](https://www.transportation.gov/briefing-room/trumps-transportation-secretary-sean-duffy-slashes-13-mexican-carrier-routes-us) — primary agency release describing the restrictions later lifted
- [Transportation Department — preliminary U.S.–Mexico aviation understanding](https://www.transportation.gov/briefing-room/trumps-transportation-secretary-sean-duffy-preliminary-aviation-understanding) — primary agency release on the bilateral remediation framework
- [Mexico SICT — bilateral aviation measures](https://www.gob.mx/sict/prensa/mexico-y-estados-unidos-acuerdan-medidas-para-fortalecer-el-transporte-aereo-bilateral-425268) — primary Mexican government release on the bilateral remediation framework

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
