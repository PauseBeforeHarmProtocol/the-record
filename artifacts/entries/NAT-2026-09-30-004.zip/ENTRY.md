# Justice Department files misconduct complaint over Minnesota judges' interviews

**Entry ID:** NAT-2026-09-30-004
**Date:** September 30, 2026
**Checked:** 2026-09-30 6:04 PM EDT
**Evidence state:** official Justice Department release and attached complaint plus independent Associated Press reporting; complaint filed, allegations unadjudicated
**Review state:** current-standard-reviewed

The complaint asks the Eighth Circuit to investigate at least seven federal judges and seeks recusals in Homeland Security cases; no misconduct finding or recusal order had issued.

## THE FACTS

- The Justice Department filed a September 30 judicial-misconduct complaint asking the Judicial Council of the U.S. Court of Appeals for the Eighth Circuit to investigate at least seven Minnesota federal judges over comments reported in New York Times interviews about immigration-enforcement litigation.
- The department publicly named Judge and former Chief Judge Patrick Schiltz and Judge John Tunheim and referred to other district judges. It alleged that the comments improperly addressed pending or impending cases and created an appearance of prejudice against the administration.
- The complaint asks that the judges be recused from matters involving the Department of Homeland Security. A Justice Department filing is an accusation and request for review; it is not a misconduct adjudication, disciplinary order or recusal ruling.
- Associated Press reported that the interviews discussed the surge of immigration cases associated with Operation Metro Surge, emergency hearings and pressure on the court. Schiltz and the court said the judges acted within ethics rules, citing February Committee on Codes of Conduct guidance permitting advocacy for the rule of law and judicial independence. The judges' descriptions of workload and courtroom effects do not by themselves establish how any pending case was or will be decided.
- No judicial-council finding, discipline, ordered recusal or appellate merits ruling on the complaint existed by the cutoff.

## SIGNIFICANCE

The filing escalates conflict between the executive branch and federal judges handling immigration cases and could affect public confidence, judicial speech and case assignments. Its institutional significance does not convert the department's allegations into findings.

## GOALPOST / RESPONSE

The Justice Department says public commentary on pending immigration litigation violated judicial-conduct rules and supports investigation and recusal. Schiltz and the court say the judges acted within ethics rules and cite guidance permitting advocacy for the rule of law and judicial independence. The judiciary's misconduct process—not the department's filing—must determine whether particular comments crossed the line. The Eighth Circuit's disposition, any recusal orders, identified cases and disciplinary findings are the tests.

## MAYBE / THEREFORE

Maybe independent review will find that particular comments created an impermissible appearance of bias, or the complaint may be rejected as an attempt to chill accurate discussion of court administration. Therefore the record establishes a filed executive-branch misconduct complaint—not judicial wrongdoing, discipline or disqualification.


## SOURCES

- [Justice Department — judicial-misconduct complaint concerning Minnesota judges](https://www.justice.gov/opa/pr/justice-department-files-judicial-misconduct-complaint-alleging-mn-judges-made-improper-and) — official filing announcement with attached complaint; allegations not adjudicated
- [Associated Press — DOJ files complaint against Minnesota federal judges](https://apnews.com/article/3c3494b118b1202ca1cc91ab548e9c6c) — independent reporting on complaint, interview context and unresolved adjudication

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
