# Supreme Court stays White House ballroom construction injunction

**Entry ID:** NAT-2026-08-31-005
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** primary 5–4 Supreme Court stay opinion and dissent, corroborated by AP and Reuters reporting, plus Trump's Truth Social characterization; construction may proceed during review, legality and final disposition unresolved
**Review state:** current-standard-reviewed

A 5–4 emergency ruling lets above-ground work continue while the government pursues Supreme Court review; the Court expressly did not decide whether the project is lawful.

## THE FACTS

- In National Park Service v. National Trust for Historic Preservation, No. 26A203, the Supreme Court granted the administration's application to stay a preliminary injunction that had largely barred above-ground construction of the new East Wing and ballroom while allowing the below-ground military installation and strictly necessary protective work.
- The unsigned 5–4 opinion said the government was likely to prevail in showing that the National Trust lacked Article III standing, likely would suffer irreparable harm from a halt, and had the stronger balance of equities. The majority relied in part on declarations from national-security officials that described the above- and below-ground work as an integrated project.
- The Court expressly said it was not deciding the legality of the East Wing project. The stay lasts through a timely certiorari petition and terminates automatically if review is denied or when the Court sends down judgment if review is granted. The underlying lawsuit and the government's contemplated petition therefore remain unresolved.
- Chief Justice John Roberts dissented with Justices Sotomayor, Kagan and Jackson. Roberts wrote that construction was likely unlawful because 40 U.S.C. § 8106 requires express congressional authority for a structure on federal grounds in Washington and Congress had supplied no such authorization; he concluded that the Trust's member had a sufficient aesthetic injury for standing.
- Trump then wrote on Truth Social that the Court had ruled for the project without any further contingency, doubt or threat. That is the administration's public characterization, not the order's legal effect: the order is a stay pending possible further Supreme Court proceedings and expressly reserves the project's legality.

## SIGNIFICANCE

The order removes the immediate judicial barrier to above-ground construction, allowing a rapidly advancing project to continue while the challenge proceeds. At the same time, the majority's standing ruling and Roberts's separation-of-powers dissent leave the central question—whether the executive may build the project without express congressional authorization—undecided.

## GOALPOST / RESPONSE

The administration says a single integrated ballroom and military complex is necessary for national security and that stopping construction would impair protective operations, delay secure facilities and create structural risks. The National Trust says the executive is racing construction ahead of judicial review without authority from Congress. A certiorari petition, the Court's disposition, further lower-court proceedings, congressional authorization or appropriations, construction milestones and any final merits judgment are the tests.

## MAYBE / THEREFORE

Maybe the standing defect will ultimately end this plaintiff's case without any court reaching the project's legality, or another plaintiff, Congress or later merits review may produce a different legal test. Therefore the record treats the August 31 action as an emergency stay that permits construction to continue—not as final approval of the ballroom, a merits holding that the project is lawful, or removal of every future contingency.


## SOURCES

- [Supreme Court — National Park Service v. National Trust stay opinion](https://www.supremecourt.gov/opinions/25pdf/26a203_2b8e.pdf) — primary 5–4 stay opinion and dissent expressly distinguishing construction relief from a merits ruling on legality
- [Associated Press — Supreme Court lets White House ballroom construction continue](https://apnews.com/article/trump-white-house-ballroom-supreme-court-6b9434af0a2dbeffa0ca19f5cdf7d775) — independent reporting on the stay, voting alignment, procedural posture, construction status and unresolved legality
- [Reuters — Supreme Court stays White House ballroom injunction](https://www.reuters.com/world/supreme-court-lets-trumps-white-house-ballroom-construction-continue-now-2026-08-31/) — independent reporting on the 5–4 stay, standing rationale, national-security argument and Roberts dissent
- [Donald Trump Truth Social post characterizing the ballroom ruling](https://truthsocial.com/@realDonaldTrump/117192227146628279) — primary evidence only that Trump published his no-further-contingency characterization, not independent proof of its legal accuracy

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
