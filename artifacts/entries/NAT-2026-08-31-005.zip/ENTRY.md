# East Wing replacement and White House ballroom proceed under Supreme Court stay

**Entry ID:** NAT-2026-08-31-005
**Date:** September 2025–September 13, 2026
**Checked:** 2026-09-13 5:59 PM EDT
**Evidence state:** primary White House project page and eleven labeled renderings, Trump's publication record, and the primary 5–4 Supreme Court stay opinion corroborated by AP and Reuters; plans and administration funding claims published, construction permitted during review, visual post asset unavailable, legality and final financing unresolved
**Review state:** current-standard-reviewed

The administration says the 90,000-square-foot, 650-seat project is privately funded and publishes eleven renderings; construction may proceed, but legality and congressional authority remain unresolved.

## THE FACTS

- The White House project page says the new State Ballroom will add approximately 90,000 square feet with seating for 650, replace the East Wing, stand apart from the main White House while mirroring its architectural design, and incorporate required Secret Service security measures. It identifies McCrery Architects as lead designer, Clark Construction as construction lead and AECOM as engineering overseer.
- The same official page publishes eleven named interior and exterior renderings and says construction commenced in September 2025. It describes the project as costing $250 million and funded by Trump and other donors. Those are administration plan, status and financing claims; the page does not disclose a complete donor list, binding gift instruments, audited expenditures or a congressional appropriation.
- On September 13, Trump posted that the ballroom was being built and was a gift from him and other donors with no taxpayer construction dollars. The retained text establishes that he published those claims. Its attached image returned HTTP 403 during review, so the archive makes no visual finding from that asset and relies on the accessible official White House rendering page for the existence and labels of the plans.
- In National Park Service v. National Trust for Historic Preservation, No. 26A203, the Supreme Court granted the administration's application to stay a preliminary injunction that had largely barred above-ground construction of the new East Wing and ballroom while allowing the below-ground military installation and strictly necessary protective work.
- The unsigned 5–4 opinion said the government was likely to prevail in showing that the National Trust lacked Article III standing, likely would suffer irreparable harm from a halt, and had the stronger balance of equities. The majority relied in part on declarations from national-security officials that described the above- and below-ground work as an integrated project.
- The Court expressly said it was not deciding the legality of the East Wing project. The stay lasts through a timely certiorari petition and terminates automatically if review is denied or when the Court sends down judgment if review is granted. The underlying lawsuit and the government's contemplated petition therefore remain unresolved.
- Chief Justice John Roberts dissented with Justices Sotomayor, Kagan and Jackson. Roberts wrote that construction was likely unlawful because 40 U.S.C. § 8106 requires express congressional authority for a structure on federal grounds in Washington and Congress had supplied no such authorization; he concluded that the Trust's member had a sufficient aesthetic injury for standing.
- Trump wrote on August 31 that the Court had ruled for the project without any further contingency, doubt or threat. That is the administration's public characterization, not the order's legal effect: the order is a stay pending possible further Supreme Court proceedings and expressly reserves the project's legality.

## SIGNIFICANCE

The record now preserves the East Wing replacement, architectural plans, scale, team and funding claims alongside the litigation rather than reducing the event to the emergency stay. The project can advance while review continues, but private-funding assertions do not answer the separate statutory and constitutional question of who may authorize construction on federal grounds.

## GOALPOST / RESPONSE

The administration says a privately funded, classically designed ballroom and integrated military complex are needed for major state events and national security, and that stopping construction would cause delay and structural risk. The National Trust says the executive is racing construction ahead of review without congressional authority. Published design changes, contracts, donor and expenditure records, construction milestones, congressional authorization or appropriations, a certiorari petition and final merits disposition are the tests.

## MAYBE / THEREFORE

Maybe private gifts and the standing defect allow the project to finish without taxpayer construction spending or a court reaching legality, or security work, federal operations and future modifications may create public costs and a viable congressional or judicial challenge. Therefore the record confirms the administration's published plans and funding claims and a stay allowing work to continue—not an audited all-private financing finding, final congressional authorization, final judicial approval or verification of the inaccessible Truth Social image.


## SOURCES

- [Supreme Court — National Park Service v. National Trust stay opinion](https://www.supremecourt.gov/opinions/25pdf/26a203_2b8e.pdf) — primary 5–4 stay opinion and dissent expressly distinguishing construction relief from a merits ruling on legality
- [Associated Press — Supreme Court lets White House ballroom construction continue](https://apnews.com/article/trump-white-house-ballroom-supreme-court-6b9434af0a2dbeffa0ca19f5cdf7d775) — independent reporting on the stay, voting alignment, procedural posture, construction status and unresolved legality
- [Reuters — Supreme Court stays White House ballroom injunction](https://www.reuters.com/world/supreme-court-lets-trumps-white-house-ballroom-construction-continue-now-2026-08-31/) — independent reporting on the 5–4 stay, standing rationale, national-security argument and Roberts dissent
- [Donald Trump Truth Social post characterizing the ballroom ruling](https://truthsocial.com/@realDonaldTrump/117192227146628279) — primary evidence only that Trump published his no-further-contingency characterization, not independent proof of its legal accuracy
- [White House — East Wing expansion plan and ballroom renderings](https://www.whitehouse.gov/about-the-white-house/the-white-house/) — primary administration project page listing eleven named ballroom renderings, stated dimensions, capacity, project team, construction status and private-funding claim
- [Donald Trump Truth Social post — ballroom construction and funding claim](https://truthsocial.com/@realDonaldTrump/117265397440548141) — primary evidence only that Trump published the construction and no-taxpayer-funding claims; attached image was unavailable for direct review and supplies no independent proof

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
