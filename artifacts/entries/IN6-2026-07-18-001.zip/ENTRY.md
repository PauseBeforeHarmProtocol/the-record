# Shreve votes yes on permanent daylight saving time and firearm-retailer code restrictions

**Entry ID:** IN6-2026-07-18-001
**Date:** July 14, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** primary House roll calls and Congress.gov bill summaries
**Review state:** current-standard-reviewed

Two House passage votes provide new, primary-source additions to the IN‑6 voting record.

## THE FACTS

- Rep. Jefferson Shreve voted “Yea” on H.R. 139, the Sunshine Protection Act. The bill would make daylight saving time the permanent standard; the House passed it 308–117.
- Shreve also voted “Yea” on H.R. 1181, the Protecting Privacy in Purchases Act. The bill prohibits payment-card networks from requiring merchant category codes that distinguish firearms retailers from general-merchandise or sporting-goods retailers; the House passed it 221–201.
- These are House passage votes. Neither vote, by itself, establishes final enactment.

## SIGNIFICANCE

The first vote affects the clock observed year-round in Indiana and nationwide. The second places Shreve on the side of preventing firearm-specific merchant coding, a policy supporters frame as purchase privacy and opponents may evaluate through financial-monitoring and gun-policy lenses.

## GOALPOST / RESPONSE

Bill titles can obscure operative text. The Record therefore states what each bill does, records the exact vote, and separates passage in one chamber from becoming law.

## MAYBE / THEREFORE

Maybe permanent daylight saving time offers a stable year-round clock, and barring firearm-specific merchant codes protects lawful purchase privacy rather than obstructing legitimate monitoring. Therefore Shreve’s votes establish those policy choices, not their success: Senate action and enactment come first, followed by separate evidence on timekeeping, commerce, and safety and on privacy and financial monitoring.


## SOURCES

- [House Clerk Roll Call 238 — Sunshine Protection Act](https://clerk.house.gov/Votes/2026238) — primary official vote record
- [Congress.gov — H.R. 139 Sunshine Protection Act](https://www.congress.gov/bill/119th-congress/house-bill/139) — primary bill text and CRS summary
- [House Clerk Roll Call 240 — Protecting Privacy in Purchases Act](https://clerk.house.gov/Votes/2026240) — primary official vote record
- [Congress.gov — H.R. 1181 Protecting Privacy in Purchases Act](https://www.congress.gov/bill/119th-congress/house-bill/1181) — primary bill text and CRS summary

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
