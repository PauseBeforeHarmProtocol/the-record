# U.S. expands Cuba sanctions to new sectors and foreign suppliers

**Entry ID:** NAT-2026-09-03-003
**Date:** September 3–November 5, 2026
**Checked:** 2026-11-05 6:08 PM EST
**Evidence state:** primary OFAC action notice and State fact sheet, independently corroborated by Reuters and Associated Press; designations and sector determination implemented, future sector targets and outcomes unresolved
**Review state:** current-standard-reviewed

A published sector determination and ten new targets expand the implemented campaign; blocked assets, behavioral change and civilian effects remain unmeasured.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Fidel Ernesto Castro Calis and five Cuban entities to the Specially Designated Nationals list on September 3 under Executive Order 14404. The listings took effect that day.
- The entities are Banco Exterior de Cuba; oil companies Comercial Cupet and Empresa de Servicios Comandante Rene Ramos Latour, also known as Nicarotec; petroleum importer ABAPET; and nickel importer CEXNI. The action blocks property and interests in property subject to U.S. jurisdiction and generally bars U.S.-person transactions absent authorization.
- OFAC simultaneously issued amended Cuba General License 4A, which authorizes specified transactions involving third-country diplomatic and consular missions in Cuba. The amendment means the action was not an undifferentiated ban on every transaction involving the newly listed institutions.
- The State Department said the designations target financial channels and resource enterprises that benefit Cuba's governing elite. Reuters reported that Cuba's foreign minister rejected the U.S. rationale and blamed U.S. policy for the country's crisis; those competing policy claims do not alter the legal fact of the listings.
- On September 4, the U.S. Embassy in Havana issued a health alert saying it had noted a significant increase in diarrheal illness across Cuba associated with continuing degradation of water and energy infrastructure. The alert said the degradation affects water supply, food storage and temperature control and advised travelers and residents to take precautions with water and perishable food.
- Reuters reported that the administration's nine-month restriction on fuel shipments has contributed to sharper power cuts and complicated refrigeration and sanitation, while U.N.-appointed experts had warned that tightened U.S. sanctions increased the risk of disease outbreaks. The embassy alert is a formal U.S. risk observation, not a population surveillance report: it does not publish a case count, identify pathogens, allocate causal shares among sanctions and Cuba's longstanding infrastructure problems, or measure the September 3 designations' effects.
- On September 29, OFAC filed an abbreviated Cuba Sanctions Regulations final rule for September 30 publication and immediate effectiveness. The new 31 CFR part 516 implements Executive Order 14404 in regulatory form; OFAC said it expects to supplement the abbreviated regulations later with additional guidance, definitions, general licenses and other provisions.
- On October 2, the Coast Guard disclosed that it had stopped the vessel Grace on September 5 between Cuba and Mexico, boarded it, and escorted it to Mexico. The agency said the vessel was carrying fuel to Cuba and using tactics associated with the dark fleet; Mexican inspection personnel confirmed large quantities of fuel in ballast tanks and containers believed to hold illicit fuel.
- The Coast Guard statement did not disclose the fuel quantity, evidence establishing Cuba as the destination, legal authority for the interdiction, ownership, charges, forfeiture or final disposition. The disclosure establishes an implemented enforcement action within the wider fuel restriction, not that every agency characterization or suspected container was judicially proven.
- No public evidence by cutoff established changed Cuban government behavior, asset amounts blocked, the interdiction's legal outcome, or a recipient-level humanitarian effect from the listings, regulatory framework or intercepted shipment.
- On November 5, OFAC designated eight entities and two individuals and identified five vessels as blocked property under the Cuba sanctions program. State said the targets included Cuban state enterprises and China-based suppliers accused of supporting military, surveillance, technology, shipping and revenue networks. The blocking action took effect upon designation; the stated underlying conduct remains the administration's allegation unless independently adjudicated.
- The Secretary of State also issued a determination authorizing sanctions against persons who operate in Cuba's electronics, manufacturing, marine or technology sectors. The determination creates a sanctions basis; it does not automatically designate every participant in those sectors, and future target-level action still requires an agency determination.
- Reuters and Associated Press independently corroborated the action and reported the administration's position that it was targeting resources reserved for the governing elite. AP also described the worsening energy crisis and continuing international opposition to the embargo; those conditions do not by themselves establish the incremental effect of the November 5 measures.
- No public evidence by cutoff quantified property blocked by the new designations, established a completed transaction denial beyond the legal prohibitions, measured a change in Cuban government conduct, or separated the new action's humanitarian effects from the wider embargo, fuel restrictions and Cuba's longstanding infrastructure failures.

## SIGNIFICANCE

The November 5 determination expands the legal reach of the Cuba program beyond named targets by making four economic sectors sanctionable, while the ten implemented designations add foreign suppliers and vessels to the existing campaign. That broadens compliance and secondary-risk consequences without proving coercive success or isolating civilian effects.

## GOALPOST / RESPONSE

The administration says the measures deny military and governing elites access to technology, shipping and revenue while preserving pressure for political change; Cuba and embargo critics attribute severe civilian hardship in part to U.S. restrictions. Target-level follow-on designations, blocked-asset totals, transaction records, licensing, power and health data, humanitarian access and observable policy change are the tests.

## MAYBE / THEREFORE

Maybe sector authority and supplier designations will close evasion channels while licenses contain spillovers, or they may widen economic harm without changing government conduct. Therefore the archive records a published sanctions basis, ten implemented designations and five blocked vessels—not sanctions on every firm in the four sectors, quantified assets, measured humanitarian impact or regime change.


## SOURCES

- [OFAC — Cuba-related designations and General License 4A](https://ofac.treasury.gov/recent-actions/20260903) — primary sanctions action listing one individual and five entities and issuing an amended general license
- [State Department — further sanctions on Cuban elites and state entities](https://www.state.gov/releases/office-of-the-spokesperson/2026/09/further-sanctions-on-cubas-elites-financial-channels-and-resource-exploitation-apparatus-fact-sheet) — primary administration fact sheet stating the designations and policy rationale
- [Reuters — United States sanctions Raul Castro's grandson and Cuban companies](https://www.reuters.com/world/americas/us-slaps-new-sanctions-raul-castros-grandson-cuban-companies-2026-09-03/) — independent reporting on the implemented listings, administration rationale, Cuban response and humanitarian context
- [U.S. Embassy Havana — health alert on increased diarrheal illness](https://cu.usembassy.gov/health-alert-u-s-embassy-havana-cuba-september-4-2026/) — primary official health alert linking increased illness to degraded water and energy infrastructure
- [Reuters — U.S. Embassy warns of infrastructure-linked illness in Cuba](https://www.reuters.com/legal/government/us-embassy-issues-health-alert-cuba-amid-oil-blockade-sanctions-2026-09-05/) — independent reporting on the health alert, fuel restrictions, power cuts and competing humanitarian and administration frames
- [Federal Register — Cuba Sanctions Regulations](https://www.federalregister.gov/d/2026-19977) — official final rule filed for public inspection; effective September 30
- [Reuters — Coast Guard discloses interception of Cuba-bound fuel vessel](https://www.reuters.com/business/energy/us-coast-guard-intercepts-cargo-boat-carrying-fuel-bound-cuba-nyt-reports-2026-10-02/) — independent reporting quoting official Coast Guard statement
- [OFAC — November 5 cyber/TCO and Cuba designations and Cuba sector determination](https://ofac.treasury.gov/recent-actions/20261105) — primary sanctions action notice and sector determination
- [State Department — further Cuba military-support and illicit-revenue sanctions fact sheet](https://www.state.gov/releases/office-of-the-spokesman/2026/11/further-sanctions-on-the-cuban-regimes-foreign-military-support-and-illicit-revenue-networks-fact-sheet/) — primary administration fact sheet describing implemented designations and published sector determination
- [Reuters — U.S. issues new Cuba sanctions and targets additional economic sectors](https://www.reuters.com/world/americas/us-issues-new-cuba-sanctions-takes-aim-sectors-cuban-economy-2026-11-05/) — independent reporting on implemented sanctions, sector determination and administration rationale
- [Associated Press — U.S. escalates Cuba economic campaign and targets China-based suppliers](https://apnews.com/article/93e6ce1f2cf83f2f4f74842babf694c6) — independent reporting on implemented sanctions, determination, Cuban conditions and competing context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
