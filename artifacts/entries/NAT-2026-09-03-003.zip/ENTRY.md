# Treasury codifies Cuba sanctions as Coast Guard discloses fuel interdiction

**Entry ID:** NAT-2026-09-03-003
**Date:** September 3–October 2, 2026
**Checked:** 2026-10-02 11:56 AM EDT
**Evidence state:** primary OFAC action and final rule, State Department and Embassy material, and Reuters reporting quoting the Coast Guard's October 2 disclosure; listings and regulations implemented and one ship-level interdiction disclosed, while legal authority, cargo quantity, disposition, causal effects and policy outcomes remain unresolved
**Review state:** current-standard-reviewed

OFAC's listings and regulatory framework are now joined by a disclosed Coast Guard interdiction of a Cuba-bound fuel vessel; the quantity, legal disposition and incremental humanitarian effects remain unresolved.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Fidel Ernesto Castro Calis and five Cuban entities to the Specially Designated Nationals list on September 3 under Executive Order 14404. The listings took effect that day.
- The entities are Banco Exterior de Cuba; oil companies Comercial Cupet and Empresa de Servicios Comandante Rene Ramos Latour, also known as Nicarotec; petroleum importer ABAPET; and nickel importer CEXNI. The action blocks property and interests in property subject to U.S. jurisdiction and generally bars U.S.-person transactions absent authorization.
- OFAC simultaneously issued amended Cuba General License 4A, which authorizes specified transactions involving third-country diplomatic and consular missions in Cuba. The amendment means the action was not an undifferentiated ban on every transaction involving the newly listed institutions.
- The State Department said the designations target financial channels and resource enterprises that benefit Cuba's governing elite. Reuters reported that Cuba's foreign minister rejected the U.S. rationale and blamed U.S. policy for the country's crisis; those competing policy claims do not alter the legal fact of the listings.
- On September 4, the U.S. Embassy in Havana issued a health alert saying it had noted a significant increase in diarrheal illness across Cuba associated with continuing degradation of water and energy infrastructure. The alert said the degradation affects water supply, food storage and temperature control and advised travelers and residents to take precautions with water and perishable food.
- Reuters reported that the administration's nine-month restriction on fuel shipments has contributed to sharper power cuts and complicated refrigeration and sanitation, while U.N.-appointed experts had warned that tightened U.S. sanctions increased the risk of disease outbreaks. The embassy alert is a formal U.S. risk observation, not a population surveillance report: it does not publish a case count, identify pathogens, allocate causal shares among sanctions and Cuba's longstanding infrastructure problems, or measure the September 3 designations' effects.
- On September 29, OFAC filed an abbreviated Cuba Sanctions Regulations final rule for September 30 publication and immediate effectiveness. The new 31 CFR part 516 implements Executive Order 14404 in regulatory form; OFAC said it expects to supplement the abbreviated regulations later with additional guidance, definitions, general licenses and other provisions.
- On October 2, the Coast Guard disclosed that it had stopped the vessel Grace on September 5 between Cuba and Mexico, boarded it, and escorted it to Mexico. The agency said the vessel was carrying fuel to Cuba and using tactics associated with the dark fleet; Mexican inspection personnel confirmed large quantities of fuel in ballast tanks and containers believed to hold illicit fuel.
- The Coast Guard statement did not disclose the fuel quantity, evidence establishing Cuba as the destination, legal authority for the interdiction, ownership, charges, forfeiture or final disposition. The disclosure establishes an implemented enforcement action within the wider fuel restriction, not that every agency characterization or suspected container was judicially proven.
- No public evidence by cutoff established changed Cuban government behavior, asset amounts blocked, the interdiction's legal outcome, or a recipient-level humanitarian effect from the listings, regulatory framework or intercepted shipment.

## SIGNIFICANCE

The disclosed interdiction moves the administration's Cuba fuel restriction from a general sanctions framework to a documented ship-level enforcement action during severe shortages and blackouts. The action may constrain supply, but undisclosed authority, quantity and disposition prevent treating it as a completed forfeiture or measured policy success.

## GOALPOST / RESPONSE

The administration says the sanctions and interdiction deny resources to Cuban elites and dark-fleet actors; Cuba says U.S. restrictions are themselves a major cause of civilian hardship and rejects the threat rationale. Boarding records, legal authority, cargo measurement, ownership, charges, disposition, fuel and electricity availability, humanitarian access and any government policy change are the tests.

## MAYBE / THEREFORE

Maybe target-level sanctions and vessel interdiction will constrain illicit fuel channels while licenses limit collateral effects, or the wider restrictions may deepen infrastructure and health harms without changing government conduct. Therefore the record confirms the listings, regulatory framework, embassy warning and one disclosed interdiction—not judicial proof of illicit cargo, a completed forfeiture, quantified supply effect, successful coercion or regime change.


## SOURCES

- [OFAC — Cuba-related designations and General License 4A](https://ofac.treasury.gov/recent-actions/20260903) — primary sanctions action listing one individual and five entities and issuing an amended general license
- [State Department — further sanctions on Cuban elites and state entities](https://www.state.gov/releases/office-of-the-spokesperson/2026/09/further-sanctions-on-cubas-elites-financial-channels-and-resource-exploitation-apparatus-fact-sheet) — primary administration fact sheet stating the designations and policy rationale
- [Reuters — United States sanctions Raul Castro's grandson and Cuban companies](https://www.reuters.com/world/americas/us-slaps-new-sanctions-raul-castros-grandson-cuban-companies-2026-09-03/) — independent reporting on the implemented listings, administration rationale, Cuban response and humanitarian context
- [U.S. Embassy Havana — health alert on increased diarrheal illness](https://cu.usembassy.gov/health-alert-u-s-embassy-havana-cuba-september-4-2026/) — primary official health alert linking increased illness to degraded water and energy infrastructure
- [Reuters — U.S. Embassy warns of infrastructure-linked illness in Cuba](https://www.reuters.com/legal/government/us-embassy-issues-health-alert-cuba-amid-oil-blockade-sanctions-2026-09-05/) — independent reporting on the health alert, fuel restrictions, power cuts and competing humanitarian and administration frames
- [Federal Register — Cuba Sanctions Regulations](https://www.federalregister.gov/d/2026-19977) — official final rule filed for public inspection; effective September 30
- [Reuters — Coast Guard discloses interception of Cuba-bound fuel vessel](https://www.reuters.com/business/energy/us-coast-guard-intercepts-cargo-boat-carrying-fuel-bound-cuba-nyt-reports-2026-10-02/) — independent reporting quoting official Coast Guard statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
