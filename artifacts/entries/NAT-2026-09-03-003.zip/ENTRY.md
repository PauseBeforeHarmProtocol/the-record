# Treasury implements new Cuba sanctions on one person and five entities

**Entry ID:** NAT-2026-09-03-003
**Date:** September 3, 2026
**Checked:** 2026-09-03 6:02 PM EDT
**Evidence state:** primary OFAC action and State Department fact sheet plus independent Reuters reporting; listings implemented, asset effects, enforcement and policy outcomes unresolved
**Review state:** current-standard-reviewed

OFAC added Raul Castro's grandson, a Cuban bank and four state-linked resource companies to its sanctions list while amending a diplomatic-transactions license.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Fidel Ernesto Castro Calis and five Cuban entities to the Specially Designated Nationals list on September 3 under Executive Order 14404. The listings took effect that day.
- The entities are Banco Exterior de Cuba; oil companies Comercial Cupet and Empresa de Servicios Comandante Rene Ramos Latour, also known as Nicarotec; petroleum importer ABAPET; and nickel importer CEXNI. The action blocks property and interests in property subject to U.S. jurisdiction and generally bars U.S.-person transactions absent authorization.
- OFAC simultaneously issued amended Cuba General License 4A, which authorizes specified transactions involving third-country diplomatic and consular missions in Cuba. The amendment means the action was not an undifferentiated ban on every transaction involving the newly listed institutions.
- The State Department said the designations target financial channels and resource enterprises that benefit Cuba's governing elite. Reuters reported that Cuba's foreign minister rejected the U.S. rationale and blamed U.S. policy for the country's crisis; those competing policy claims do not alter the legal fact of the listings.
- No public evidence by cutoff established changed Cuban government behavior, asset amounts blocked, enforcement actions, or measurable humanitarian or political effects from the new designations.

## SIGNIFICANCE

The implemented listings expand U.S. financial restrictions to a member of the Castro family and state-linked banking, petroleum and nickel entities during a severe Cuban energy and humanitarian crisis. Their practical reach depends on assets, counterparties, licensing and enforcement rather than designation alone.

## GOALPOST / RESPONSE

The administration says the sanctions deny resources to Cuban elites and entities exploiting the country's economy; Cuba says U.S. restrictions are themselves a major cause of hardship and rejects the threat rationale. Blocked-property reports, license use, enforcement cases, financial flows, energy availability, humanitarian indicators and any policy change are the tests.

## MAYBE / THEREFORE

Maybe the targeted listings will constrain elite financial channels while the diplomatic license limits collateral effects, or they may deepen economic strain without changing government conduct. Therefore the record confirms one individual and five entities were legally listed and a related license was amended—not the amount of assets blocked, successful coercion, regime change or a measured humanitarian outcome.


## SOURCES

- [OFAC — Cuba-related designations and General License 4A](https://ofac.treasury.gov/recent-actions/20260903) — primary sanctions action listing one individual and five entities and issuing an amended general license
- [State Department — further sanctions on Cuban elites and state entities](https://www.state.gov/releases/office-of-the-spokesperson/2026/09/further-sanctions-on-cubas-elites-financial-channels-and-resource-exploitation-apparatus-fact-sheet) — primary administration fact sheet stating the designations and policy rationale
- [Reuters — United States sanctions Raul Castro's grandson and Cuban companies](https://www.reuters.com/world/americas/us-slaps-new-sanctions-raul-castros-grandson-cuban-companies-2026-09-03/) — independent reporting on the implemented listings, administration rationale, Cuban response and humanitarian context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
