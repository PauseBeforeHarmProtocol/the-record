# Treasury implements Cuba sanctions as embassy warns of infrastructure-linked illness

**Entry ID:** NAT-2026-09-03-003
**Date:** September 3, 2026
**Checked:** 2026-09-05 12:00 AM EDT
**Evidence state:** primary OFAC action, State Department fact sheet and U.S. Embassy health alert plus independent Reuters reporting; listings implemented and infrastructure-linked risk officially observed, case totals, causal allocation, enforcement and policy outcomes unresolved
**Review state:** current-standard-reviewed

OFAC's new listings took effect while the U.S. Embassy separately warned of increased diarrheal illness associated with degraded water and energy infrastructure; the alert does not quantify cases or isolate the sanctions' effect.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control added Fidel Ernesto Castro Calis and five Cuban entities to the Specially Designated Nationals list on September 3 under Executive Order 14404. The listings took effect that day.
- The entities are Banco Exterior de Cuba; oil companies Comercial Cupet and Empresa de Servicios Comandante Rene Ramos Latour, also known as Nicarotec; petroleum importer ABAPET; and nickel importer CEXNI. The action blocks property and interests in property subject to U.S. jurisdiction and generally bars U.S.-person transactions absent authorization.
- OFAC simultaneously issued amended Cuba General License 4A, which authorizes specified transactions involving third-country diplomatic and consular missions in Cuba. The amendment means the action was not an undifferentiated ban on every transaction involving the newly listed institutions.
- The State Department said the designations target financial channels and resource enterprises that benefit Cuba's governing elite. Reuters reported that Cuba's foreign minister rejected the U.S. rationale and blamed U.S. policy for the country's crisis; those competing policy claims do not alter the legal fact of the listings.
- On September 4, the U.S. Embassy in Havana issued a health alert saying it had noted a significant increase in diarrheal illness across Cuba associated with continuing degradation of water and energy infrastructure. The alert said the degradation affects water supply, food storage and temperature control and advised travelers and residents to take precautions with water and perishable food.
- Reuters reported that the administration's nine-month restriction on fuel shipments has contributed to sharper power cuts and complicated refrigeration and sanitation, while U.N.-appointed experts had warned that tightened U.S. sanctions increased the risk of disease outbreaks. The embassy alert is a formal U.S. risk observation, not a population surveillance report: it does not publish a case count, identify pathogens, allocate causal shares among sanctions and Cuba's longstanding infrastructure problems, or measure the September 3 designations' effects.
- No public evidence by cutoff established changed Cuban government behavior, asset amounts blocked, enforcement actions, or a recipient-level humanitarian effect from the September 3 designations.

## SIGNIFICANCE

The implemented listings expand U.S. financial restrictions to a member of the Castro family and state-linked banking, petroleum and nickel entities during a severe Cuban energy and humanitarian crisis. The later U.S. health alert adds official evidence that infrastructure degradation is coinciding with increased illness, while still leaving the new designations' incremental effects and the broader crisis's causal allocation unresolved.

## GOALPOST / RESPONSE

The administration says the sanctions deny resources to Cuban elites and entities exploiting the country's economy; Cuba says U.S. restrictions are themselves a major cause of hardship and rejects the threat rationale. Blocked-property reports, license use, enforcement cases, financial flows, fuel and electricity availability, water-service data, diagnosed case surveillance, humanitarian access and any government policy change are the tests.

## MAYBE / THEREFORE

Maybe the targeted listings will constrain elite financial channels while the diplomatic license limits collateral effects, or the wider fuel restrictions may deepen infrastructure and health harms without changing government conduct. Therefore the record confirms the listings, the license amendment and the embassy's infrastructure-linked illness warning—not the number or cause of individual illnesses, the September 3 action's incremental effect, successful coercion or regime change.


## SOURCES

- [OFAC — Cuba-related designations and General License 4A](https://ofac.treasury.gov/recent-actions/20260903) — primary sanctions action listing one individual and five entities and issuing an amended general license
- [State Department — further sanctions on Cuban elites and state entities](https://www.state.gov/releases/office-of-the-spokesperson/2026/09/further-sanctions-on-cubas-elites-financial-channels-and-resource-exploitation-apparatus-fact-sheet) — primary administration fact sheet stating the designations and policy rationale
- [Reuters — United States sanctions Raul Castro's grandson and Cuban companies](https://www.reuters.com/world/americas/us-slaps-new-sanctions-raul-castros-grandson-cuban-companies-2026-09-03/) — independent reporting on the implemented listings, administration rationale, Cuban response and humanitarian context
- [U.S. Embassy Havana — health alert on increased diarrheal illness](https://cu.usembassy.gov/health-alert-u-s-embassy-havana-cuba-september-4-2026/) — primary official health alert linking increased illness to degraded water and energy infrastructure
- [Reuters — U.S. Embassy warns of infrastructure-linked illness in Cuba](https://www.reuters.com/legal/government/us-embassy-issues-health-alert-cuba-amid-oil-blockade-sanctions-2026-09-05/) — independent reporting on the health alert, fuel restrictions, power cuts and competing humanitarian and administration frames

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
