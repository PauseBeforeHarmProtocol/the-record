# U.S. sanctions the International Criminal Court as an institution

**Entry ID:** NAT-2026-10-09-001
**Date:** October 9, 2026
**Checked:** 2026-10-09 11:56 AM EDT
**Evidence state:** official State Department announcement plus independent Reuters and Associated Press reporting; institution-wide sanctions announced and implemented with wind-down and licensed exceptions, effects unresolved
**Review state:** current-standard-reviewed

The action blocks the court's U.S.-jurisdiction property and restricts transactions, with a six-month wind-down and targeted licenses; the court says it will continue operating.

## THE FACTS

- Secretary of State Marco Rubio announced on October 9 that the United States was sanctioning the International Criminal Court itself under the existing ICC sanctions program. Associated Press reported that the action blocks property the institution may hold in U.S. jurisdiction and gives U.S. companies and people six months to wind down business with the court.
- Reuters reported that the administration immediately issued four general licenses covering specified telecommunications, software, pension-payment and ICC-detainee transactions. Those authorizations limit particular effects; they do not negate the institution-wide sanctions action.
- The action materially broadens the administration's prior person-specific sanctions against ICC judges, prosecutors and staff. Reuters reported that U.S. sanctions generally force banks, insurers and software providers to stop dealing with a blocked entity, while the court had already begun changing software, banking and insurance arrangements in anticipation.
- Rubio said the administration was protecting Americans and U.S. sovereignty from a court whose jurisdiction it rejects and said the sanctions were structured to permit negotiations. The ICC called the action an attempt to obstruct justice and said it would continue its investigations and prosecutions; operational effects remain to be measured.

## SIGNIFICANCE

Blocking the court as an institution moves beyond sanctions on named officials and can affect the financial, insurance and technology services needed to operate an international tribunal. It also increases friction with allied states that are ICC members and may seek to shield the court from U.S. restrictions.

## GOALPOST / RESPONSE

The administration says the sanctions will stop the ICC from threatening Americans and compel member states to address U.S. objections. The effective wind-down, service-provider conduct, allied countermeasures, court operations, case activity and any negotiated change are the tests.

## MAYBE / THEREFORE

Maybe the wind-down period and licenses produce leverage for a negotiated jurisdictional accommodation, or allied protections and substitute providers may let the court continue with limited disruption. Therefore the United States implemented institution-wide sanctions with defined exceptions—not proof that the ICC has been dismantled, stopped a case or lost the ability to operate.


## SOURCES

- [Department of State — Imposing Sanctions on the International Criminal Court](https://www.state.gov/releases/office-of-the-spokesman/2026/10/imposing-sanctions-on-the-international-criminal-court-2/) — official sanctions announcement
- [Reuters — U.S. imposes sanctions on the International Criminal Court](https://www.reuters.com/world/us-imposes-sanctions-international-criminal-court-hours-after-former-judge-wins-2026-10-09/) — independent reporting of institution-wide sanctions, licenses and responses
- [Associated Press — U.S. sanctions the International Criminal Court](https://apnews.com/article/us-icc-trump-rubio-4ea3555403e3c695d8f81dc473515d9b) — independent reporting of institution-wide sanctions and responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
