# U.S. sanctions the International Criminal Court as an institution

**Entry ID:** NAT-2026-10-09-001
**Date:** October 9, 2026
**Checked:** 2026-10-14 11:56 PM EDT
**Evidence state:** official State Department announcement, filed Southern District of New York opinion, and independent Reuters, Associated Press and Guardian reporting; institution-wide sanctions implemented with exceptions and a limited plaintiff-specific preliminary injunction, final merits and wider effects unresolved
**Review state:** current-standard-reviewed

The institution-wide sanctions remain generally operative, but a federal judge preliminarily barred enforcement against named rights-group plaintiffs for specified protected services.

## THE FACTS

- Secretary of State Marco Rubio announced on October 9 that the United States was sanctioning the International Criminal Court itself under the existing ICC sanctions program. Associated Press reported that the action blocks property the institution may hold in U.S. jurisdiction and gives U.S. companies and people six months to wind down business with the court.
- Reuters reported that the administration immediately issued four general licenses covering specified telecommunications, software, pension-payment and ICC-detainee transactions. Those authorizations limit particular effects; they do not negate the institution-wide sanctions action.
- The action materially broadens the administration's prior person-specific sanctions against ICC judges, prosecutors and staff. Reuters reported that U.S. sanctions generally force banks, insurers and software providers to stop dealing with a blocked entity, while the court had already begun changing software, banking and insurance arrangements in anticipation.
- Rubio said the administration was protecting Americans and U.S. sovereignty from a court whose jurisdiction it rejects and said the sanctions were structured to permit negotiations. The ICC called the action an attempt to obstruct justice and said it would continue its investigations and prosecutions; operational effects remain to be measured.
- In DAWN v. Trump, No. 26-cv-5957, the Southern District of New York on October 13 granted a preliminary injunction in substantial part. The court found the plaintiffs likely to succeed on their claim that applying the executive order's services prohibition to their specified research, advice, training, presentations and related advocacy for ICC personnel violates the First Amendment.
- The order is plaintiff-specific and preliminary. It bars defendants other than the President from enforcing IEEPA penalties against the named plaintiffs for the conduct addressed in the complaint and opinion; it denied a facial invalidation, an injunction against the President and a universal injunction. The institutional sanctions, financial restrictions and enforcement against nonplaintiffs therefore were not generally vacated.
- The Guardian reported that the administration declined to comment on pending litigation and reiterated its position that ICC action against Americans threatens U.S. sovereignty. That litigation posture preserves the administration's strongest stated rationale while leaving appeal and final merits unresolved.

## SIGNIFICANCE

Blocking the court as an institution moves beyond sanctions on named officials and can affect the financial, insurance and technology services needed to operate an international tribunal. The new injunction protects specified First Amendment activity by the plaintiffs without removing the broader sanctions regime, creating a consequential but narrow judicial limit.

## GOALPOST / RESPONSE

The administration says the sanctions will stop the ICC from threatening Americans and protect U.S. sovereignty. The tests now include appellate and final merits outcomes in DAWN, enforcement against nonplaintiffs, the effective wind-down, service-provider conduct, allied countermeasures, court operations, case activity and any negotiated change.

## MAYBE / THEREFORE

Maybe the injunction will protect a wider practical channel for U.S.-based ICC advocacy or be narrowed on appeal, while the remaining sanctions may still disrupt financial and operational services. Therefore the record now includes a plaintiff-specific preliminary First Amendment limit—not universal invalidation, repeal of the institution-wide sanctions or a final merits judgment.


## SOURCES

- [Department of State — Imposing Sanctions on the International Criminal Court](https://www.state.gov/releases/office-of-the-spokesman/2026/10/imposing-sanctions-on-the-international-criminal-court-2/) — official sanctions announcement
- [Reuters — U.S. imposes sanctions on the International Criminal Court](https://www.reuters.com/world/us-imposes-sanctions-international-criminal-court-hours-after-former-judge-wins-2026-10-09/) — independent reporting of institution-wide sanctions, licenses and responses
- [Associated Press — U.S. sanctions the International Criminal Court](https://apnews.com/article/us-icc-trump-rubio-4ea3555403e3c695d8f81dc473515d9b) — independent reporting of institution-wide sanctions and responses
- [S.D.N.Y. — DAWN v. Trump preliminary-injunction opinion and order](https://storage.courtlistener.com/recap/gov.uscourts.nysd.668333/gov.uscourts.nysd.668333.40.0.pdf) — primary filed judicial opinion granting plaintiff-specific preliminary relief
- [Guardian — judge blocks ICC-sanctions enforcement against rights-group plaintiffs](https://www.theguardian.com/us-news/2026/oct/14/judge-trump-icc-sanctions-gaza-war-crimes) — independent reporting on limited preliminary injunction and administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
