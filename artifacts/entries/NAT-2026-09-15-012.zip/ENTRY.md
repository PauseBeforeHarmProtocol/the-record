# State Department notifies Congress of $52 million military-aid shift

**Entry ID:** NAT-2026-09-15-012
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:29 AM EDT
**Evidence state:** Associated Press reporting on a formal State Department congressional notification and attributed department response; $52 million planned for reprogramming, with allocations, disbursement and outcomes unresolved
**Review state:** current-standard-reviewed

The planned reprogramming moves foreign military financing from four European and Middle Eastern countries to Panama, Peru, Ecuador and Colombia; disbursement was not established.

## THE FACTS

- The State Department notified Congress that it would reprogram $52 million in foreign military financing from Slovakia, North Macedonia, Tunisia and Iraq to Panama, Peru, Ecuador and Colombia, Associated Press reported.
- Foreign military financing supplies U.S. taxpayer funds that recipient governments use to purchase equipment from American defense contractors. The congressional notification establishes a formal planned allocation change, not completed procurement, delivery or disbursement to every recipient.
- The department said the funds would combat narcoterrorism, support security around the Panama Canal and prevent adversaries from establishing strategic footholds in the Western Hemisphere. Those are the administration's stated policy and threat rationales, not measured results of the reprogramming.
- Associated Press reported that assistance for Tunisia, Iraq, North Macedonia and Slovakia would be reduced rather than eliminated. The exact remaining allocations and country-by-country shares of the $52 million were not public by cutoff.
- The shift followed Secretary of State Marco Rubio's regional visit and fits the administration's stated prioritization of the Western Hemisphere. Public evidence did not yet establish congressional objections, transfer dates, contracts, equipment, recipient conditions or security outcomes.

## SIGNIFICANCE

The formal notification redirects finite security-assistance resources from NATO members and Middle Eastern partners toward the administration's Western Hemisphere priorities. It documents an allocation decision, while the operational and diplomatic consequences remain unmeasured.

## GOALPOST / RESPONSE

The administration says the shift will combat narcoterrorism, secure the Panama Canal and counter hostile footholds. Congressional responses, final country allocations, obligations and disbursements, contracts, delivered equipment, conditions, audits and measurable security or diplomatic effects are the tests.

## MAYBE / THEREFORE

Maybe the reprogramming better matches current regional threats without materially weakening prior recipients, or the reductions could create capability and alliance costs that exceed the benefits. Therefore the record establishes a $52 million congressional notification and intended country shift—not completed disbursement, elimination of prior assistance, delivered equipment or proven security gains.


## SOURCES

- [Associated Press — State Department shifts $52 million in military financing](https://apnews.com/article/foreign-military-financing-trump-rubio-c92157ab38b809a9faef9fa19be50cf7) — independent reporting on the formal congressional notification and attributed State Department rationale; disbursement and remaining country allocations unresolved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
