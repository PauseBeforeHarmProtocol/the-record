# Justice Department sues Ohio court over restrictions on federal courthouse arrests

**Entry ID:** NAT-2026-08-25-002
**Date:** August 25, 2026
**Checked:** 2026-08-25 6:00 PM EDT
**Evidence state:** filed federal complaint and DOJ announcement, with independent confirmation of the filing; allegations pending judicial review

The filed complaint challenges a Franklin County rule that generally requires a judicial warrant for civil arrests at or near the courthouse.

## THE FACTS

- The Justice Department filed a federal lawsuit against the Franklin County Municipal Court, its presiding judge, and its security director over Local Rule 2.10.
- The rule generally bars civil arrests of people attending court proceedings or conducting lawful court business in the courthouse and its curtilage, except arrests under a judicial warrant. DOJ's complaint says federal immigration law permits some arrests under administrative warrants or without a warrant and asks the court to declare the local rule invalid and enjoin enforcement.
- The complaint was filed on August 25 in the Southern District of Ohio. It is an allegation and request for relief; no court ruling on the rule's validity had issued at the checked time.

## SIGNIFICANCE

The case is part of the administration's broader effort to invalidate state and local limits on immigration enforcement. Its outcome could affect courthouse access, federal arrest practices, local judicial administration, and the boundary between federal supremacy and a court's authority to protect proceedings.

## GOALPOST / RESPONSE

DOJ argues that courthouse arrests can reduce flight and safety risks and that Rule 2.10 conflicts with federal arrest authority. The municipal court's rule states that courts must safeguard unimpeded judicial functions and disclaims any construction that violates federal law. The evidence test is the defendants' response and the court's treatment of preemption, intergovernmental immunity, safety, and access-to-justice claims.

## MAYBE / THEREFORE

Maybe the rule will be construed narrowly enough to coexist with federal law, or a court will find that judicial-warrant limits impermissibly regulate federal officers. Therefore the record treats this as filed litigation, not as proof that the Ohio rule is unlawful or that DOJ has prevailed.


## SOURCES

- [Justice Department — lawsuit challenging Franklin County courthouse-arrest rule](https://www.justice.gov/opa/pr/justice-department-files-lawsuit-stop-ohio-courts-unlawful-obstruction-federal-law) — official administration announcement and explanation
- [United States v. Franklin County Municipal Court — filed complaint](https://www.justice.gov/d9/2026-08/fcmc_complaint-filed.pdf) — primary federal court filing
- [Fox News — DOJ files challenge to Ohio courthouse-arrest restriction](https://www.foxnews.com/politics/doj-sues-stop-ohio-court-blocking-courthouse-arrests) — independent reporting confirming the filed action and disputed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
