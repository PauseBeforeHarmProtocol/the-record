# Trump orders expanded hunting access and related federal reforms

**Entry ID:** NAT-2026-09-17-009
**Date:** September 17, 2026
**Checked:** 2026-09-20 11:58 PM EDT
**Evidence state:** complete signed White House order; directives and deadlines ordered, implementing rules, access changes and measured outcomes pending
**Review state:** current-standard-reviewed

The order sets deadlines for hunting at two monuments, broader federal-land access proposals, river-lottery changes and school-program guidance.

## THE FACTS

- Trump signed an executive order on September 17 directing Interior, within 90 days, to allow hunting of species not listed under the Endangered Species Act in Castle Mountains National Monument and Craters of the Moon National Monument and Preserve. The signed order is restored as a prior-window omission; it does not show that hunting access changed on signature.
- Within 180 days, Defense, Interior, Agriculture and Commerce must propose policy or regulatory changes that generally allow hunting unless a local closure is justified, improve access and infrastructure, encourage qualified volunteers and assistive technology, and permit traditional lead ammunition and tackle, subject to law. National parks and other national monuments are excluded from that general instruction.
- The order also directs Agriculture to begin reforming high-demand Forest Service river lotteries within 60 days, Interior to propose migratory-game-bird process rules within 90 days, Labor and Education to clarify school funding for archery and hunter education within 90 days, and agencies to support game-population, wild-game donation and veterans' recreation programs.
- The administration says federal overreach and inconsistent access policies reduced hunting opportunities and that expanded access will support conservation. The order supplies deadlines and direction but no completed rule, site-specific season, appropriation, lead-exposure assessment, participation result or wildlife-population outcome by cutoff.

## SIGNIFICANCE

The order initiates a broad shift toward presumptive hunting and fishing access across federal lands and directs changes touching wildlife management, lead ammunition, school programs and public-land infrastructure. The practical conservation, health and access consequences depend on agency implementation and site-level evidence.

## GOALPOST / RESPONSE

The administration says hunters and anglers finance and perform conservation and that regulatory reform will restore access while protecting wildlife. Published agency actions, monument access rules, environmental and health analyses, participation data, habitat and game-population outcomes, and any litigation are the tests.

## MAYBE / THEREFORE

Maybe expanded, locally managed access will strengthen conservation funding and public participation without harming protected resources, or broader presumptions and lead-use changes may create ecological or public-health costs not resolved by the order. Therefore the evidence establishes signed instructions and deadlines—not completed nationwide access, finalized regulations or measured conservation results.


## SOURCES

- [White House — Reinvigorating America's Hunting Heritage executive order](https://www.whitehouse.gov/presidential-actions/2026/09/reinvigorating-americas-hunting-heritage/) — primary signed executive order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
