# Federal judge vacates DOJ's nationwide voter-list maintenance policy

**Entry ID:** NAT-2026-10-09-004
**Date:** March 2025–October 9, 2026
**Checked:** 2026-10-09 5:57 PM EDT
**Evidence state:** 78-page federal-court opinion plus independent Reuters and Guardian reporting; nationwide DOJ policy vacated at district-court level, administration reviewing and appellate status unresolved
**Review state:** current-standard-reviewed

The district court found the policy unauthorized, arbitrary and contrary to privacy and paperwork laws; DOJ said it was reviewing the decision, and further litigation remains possible.

## THE FACTS

- U.S. District Judge Sparkle Sooknanan's October 9 memorandum opinion describes a Justice Department policy, adopted in response to Executive Order 14248, that sought complete unredacted voter lists from 49 states and the District of Columbia, shared cooperating states' data with DHS, compared it with the SAVE citizenship database and urged states to remove people flagged as ineligible. The opinion says at least 18 states supplied unredacted lists.
- The court granted the plaintiffs partial summary judgment, denied DOJ's cross-motion and set aside and vacated the Voter List Maintenance Policy. It held that the statutes DOJ invoked did not authorize the policy, that it was arbitrary and capricious under the Administrative Procedure Act, and that it violated the Privacy Act and Paperwork Reduction Act.
- The opinion states that the policy had removed U.S. citizens from voter rolls and risked disenfranchising more, while emphasizing that the ruling does not prevent lawful federal support for state list maintenance or states' own lawful maintenance. Reuters reported that DOJ said it was reviewing the decision; no appeal or stay of this October 9 judgment had been located by cutoff.
- Reuters reported that DOJ had demanded unredacted voter rolls from nearly every state, sued 30 states and the District of Columbia after refusals, and had lost 26 cases without a win. The opinion distinguishes this policy case from separate litigation over DHS's expanded SAVE database, whose earlier district-court judgment the Supreme Court stayed in September; the October 9 policy vacatur is the operative ruling recorded here unless a later court changes it.

## SIGNIFICANCE

The ruling removes a nationwide federal mechanism that combined sensitive state voter data with federal citizenship records shortly before the midterm election. It also sets a statutory and privacy limit on using civil-rights enforcement authority for a broad voter-eligibility dragnet while leaving lawful state maintenance and narrower federal investigations available.

## GOALPOST / RESPONSE

The administration says the project supports accurate rolls and enforcement against ineligible voting; the court said Congress left list maintenance with states and that DOJ used unreliable data without lawful authority or required safeguards. Any stay, appeal, revised policy, deletion or continued use of acquired data, state removal reversals and the effect on eligible voters are the tests.

## MAYBE / THEREFORE

Maybe an appellate court will narrow or reverse the ruling, or DOJ may design a lawful, targeted information-sharing process with adequate accuracy and privacy controls. Therefore the district court vacated the nationwide policy on multiple statutory grounds—not a ruling that voter-list maintenance is forbidden, not a final appellate judgment and not proof that every state removal was unlawful.


## SOURCES

- [Common Cause v. U.S. Department of Justice — memorandum opinion](https://storage.courtlistener.com/recap/gov.uscourts.dcd.291580/gov.uscourts.dcd.291580.51.0_1.pdf) — primary federal-court opinion
- [Reuters — judge rules DOJ voter-roll policy unlawful](https://www.reuters.com/world/us-judge-rules-justice-department-use-voter-rolls-unlawful-2026-10-09/) — independent reporting of the court ruling and administration response
- [The Guardian — federal judge vacates DOJ voter-list policy](https://www.theguardian.com/us-news/2026/oct/09/federal-judge-rules-against-trump-push-state-voter-rolls) — independent reporting with direct link to the court opinion

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
