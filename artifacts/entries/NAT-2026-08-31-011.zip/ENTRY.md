# Federal judge blocks New York's $75 billion climate-superfund law

**Entry ID:** NAT-2026-08-31-011
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** Reuters reporting linked to the court filing and describing the district court's preemption holding, corroborated by the federal case record and DOJ's filed position; enforcement blocked at district-court stage, appellate status unresolved
**Review state:** current-standard-reviewed

A district court held the state law preempted by federal law and barred enforcement; the ruling is a trial-court judgment subject to appeal, not a nationwide Supreme Court rule.

## THE FACTS

- Chief U.S. District Judge Brenda Sannes ruled that New York may not enforce its 2024 Climate Change Superfund Act, which sought $75 billion over 25 years from major fossil-fuel producers to finance climate-adaptation projects.
- Reuters reported that the court found the state measure preempted by federal law. Sannes reasoned that the Clean Air Act assigns federal authority over carbon-dioxide emissions and that New York's global-emissions compensation scheme conflicted with the need for a uniform national rule affecting energy, environmental, foreign-policy and national-security interests.
- The ruling arose from challenges by 22 Republican-led states and industry groups, while the Trump administration had separately sued New York and moved for summary judgment to declare the same law invalid. The result advances the administration's stated policy of challenging state climate laws it characterizes as energy-policy overreach.
- The court's decision prevents enforcement of New York's law at the district-court stage. It does not repeal the Clean Air Act, decide every state climate policy, invalidate Vermont's separate statute or establish a final rule immune from appeal.
- New York enacted the law to shift climate-adaptation costs from taxpayers to companies associated with historic global emissions. The state's appellate response and the final scope of injunctive relief were not established by cutoff.

## SIGNIFICANCE

The judgment disables a $75 billion state financing mechanism and may influence similar state polluter-pay laws, while strengthening the administration's effort to centralize greenhouse-gas regulation at the federal level. Its durability and reach depend on appeal and on how other courts treat different statutes and factual records.

## GOALPOST / RESPONSE

The administration and allied challengers say states cannot regulate or assign liability for worldwide emissions in a field requiring uniform federal and international policy. New York says the law is a cost-recovery program for adaptation rather than an emissions regulation and makes major contributors pay instead of taxpayers. The written judgment, any stay, notice of appeal, Second Circuit review, implementation activity and rulings on comparable laws are the tests.

## MAYBE / THEREFORE

Maybe the preemption reasoning will be affirmed and narrow the space for state climate-compensation programs, or an appellate court may reverse, narrow the injunction or distinguish other laws. Therefore the record reports an operative district-court ruling barring New York's law—not a final nationwide resolution of climate liability, a Supreme Court holding or proof that state adaptation costs no longer exist.


## SOURCES

- [Reuters — federal judge blocks New York climate-superfund law](https://www.reuters.com/world/new-york-cannot-enforce-75-billion-climate-superfund-law-us-judge-rules-2026-08-31/) — independent legal reporting on the district court's Clean Air Act preemption ruling and injunction
- [Climate Litigation Database — United States v. New York docket and filings](https://www.climatecasechart.com/document/united-states-v-new-york_e0ca) — independent case docket documenting the federal challenge, parties, claims and procedural history
- [DOJ — summary-judgment motion against New York Climate Change Superfund Act](https://www.justice.gov/opa/pr/justice-department-files-motion-summary-judgment-challenge-new-yorks-climate-change) — primary administration filing announcement stating the federal challenge, requested relief and administration rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
