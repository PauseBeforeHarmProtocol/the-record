# ICE orders trained-only vehicle stops and bars high-speed pursuits

**Entry ID:** NAT-2026-10-02-002
**Date:** October 2, 2026
**Checked:** 2026-10-02 11:56 AM EDT
**Evidence state:** Associated Press direct review of the internal memorandum and on-record ICE response; guidance is reported as issued and operative, while the full document, implementation data and outcomes are not public
**Review state:** current-standard-reviewed

An internal Enforcement and Removal Operations memo obtained by Associated Press requires trained officers, body cameras, marked warning equipment and no pursuit of vehicles that refuse to stop; ICE says vehicle arrests continue.

## THE FACTS

- Associated Press obtained an ICE Enforcement and Removal Operations memorandum dated September 30 and signed by executive associate director Marcos D. Charles. It directs officers not to pursue vehicles that fail to pull over under any circumstances and instead to record vehicle information for follow-up investigation.
- The guidance requires vehicle stops to be conducted by officers who completed one of five specified training courses. Untrained officers may participate only in a support role as passengers and may not drive involved vehicles.
- Field offices must ensure stop vehicles have lights and sirens that identify them as law-enforcement vehicles when activated, and every officer at a vehicle stop must wear and activate a body camera. Pinning vehicles and using tire-deflation devices remain permitted only for specially trained officers.
- ICE told Associated Press that leadership sometimes issues guidance reminders, said vehicle stops and arrests continue, and described the memo as replacing or amending earlier directives. The agency response confirms the operational context but does not make the full internal document public.
- The policy followed multiple ICE vehicle-stop shootings. Associated Press reported more than a dozen agent shootings since the prior year, including at least four deaths; those incident totals provide context, not a finding that every shooting violated policy or that the new guidance has already reduced harm.
- The archive previously withheld a single-source report about the nonpublic memo. Associated Press's direct review, detailed operative provisions and on-record ICE response now clear the credible-investigation threshold; compliance, discipline, stop volume, pursuits and safety outcomes remain unmeasured.

## SIGNIFICANCE

The memo imposes concrete, agency-wide safety and training conditions on a high-risk immigration-enforcement tactic after fatal encounters, while preserving vehicle stops and coercive techniques for trained officers. Its effect depends on field compliance, supervision and accountability rather than issuance alone.

## GOALPOST / RESPONSE

ICE says the guidance is a safety reminder and that vehicle stops and immigration arrests continue. Training rosters, body-camera activation, pursuit reports, stop and shooting data, internal discipline, court findings and public release of the complete memo are the tests.

## MAYBE / THEREFORE

Maybe the training, equipment, camera and no-pursuit rules will reduce dangerous escalations, or uneven compliance and continued pinning tactics may limit the change. Therefore the record establishes issued internal guidance and operative restrictions—not publication of the full memo, universal compliance or measured reduction in injuries and deaths.


## SOURCES

- [Associated Press — ICE vehicle-stop and pursuit guidance](https://apnews.com/article/ice-officers-car-chases-vehicle-stops-training-ded50fcee99efab90e55e580250ba2ab) — independent direct review of internal agency memorandum with on-record agency response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
