# Document review finds evidence supporting detained man's disputed U.S. citizenship

**Entry ID:** NAT-2026-10-27-001
**Date:** October 27, 2026
**Checked:** 2026-10-27 6:00 AM EDT
**Evidence state:** federal habeas docket identifying the parties, detention challenge and sealed supporting exhibits, plus an Associated Press investigation that independently reviewed a paternity record and summarized filed records and the government's response; detention implemented, citizenship and legality unresolved
**Review state:** current-standard-reviewed

ICE has held Phillip James since January while seeking his removal, although an AP investigation found a Florida birth record, prior U.S. passports and other records supporting his citizenship claim; DHS disputes the claim and the courts have not resolved it.

## THE FACTS

- Associated Press published an investigation at 7:08 a.m. UTC on October 27 reporting that immigration authorities have detained Phillip James, also known as Felibi Siagha-Coke, since January 5 while seeking to remove him to Jamaica. AP found documents supporting his lawyers' and mother's claim that he was born in Florida, but citizenship remains disputed and no court had adjudicated the claim by cutoff.
- The public docket in James v. English, No. 3:26-cv-01225 (N.D. Ind.), shows that his lawyers filed a federal habeas petition on August 19. The docket identifies sealed exhibits including a birth certificate, a State Department passport-revocation letter, Florida court records, communications with Jamaican authorities and medical reports. A pending petition and listed exhibits establish the dispute and evidence submitted, not that every factual claim in them is true.
- AP reported that it independently obtained a 1988 Florida paternity record matching the birth certificate's date, parents and residence. It also reported that James held a U.S. passport issued in 2008 and obtained a replacement in 2023, while criminal-case records listed him as a U.S. citizen. Those records materially support the citizenship claim but do not substitute for a judicial determination.
- DHS told AP that the birth certificate used for the passport was fraudulent, but AP reported that the department supplied no supporting evidence. Jamaican authorities told James' lawyers they had no record of his birth or citizenship there. Medical experts who evaluated him attributed his repeated Jamaican-birth assertions to paranoid schizophrenia and described him as an unreliable historian, according to reports filed in court.
- An immigration judge ordered James removed to Jamaica in April; his lawyers are appealing to the Board of Immigration Appeals and asking the federal court to release him. DHS denied that ICE detains U.S. citizens and said people in removal proceedings receive due process. The government has not acknowledged error, and the habeas and immigration proceedings remained unresolved at cutoff.

## SIGNIFICANCE

The investigation documents a nearly ten-month detention in which government records, prior passports and independently checked court records point in a different direction from the identity on which removal proceedings rely. The case tests how ICE handles citizenship evidence and serious mental illness when an individual's own statements conflict with documentary records.

## GOALPOST / RESPONSE

DHS says the birth certificate was fraudulent, maintains that James is not a U.S. citizen and argues that the citizenship question belongs in immigration proceedings; it also says detainees receive due process. The tests are production and authentication of the underlying identity records, the Board of Immigration Appeals decision, the federal habeas ruling, any release or removal action and whether the government substantiates its fraud allegation.

## MAYBE / THEREFORE

Maybe additional government evidence will substantiate DHS's fraud allegation, or the documentary record may establish that ICE detained a U.S. citizen after relying on statements shaped by mental illness. Therefore the supported conclusion is that a strong, independently reviewed documentary record now supports James' disputed citizenship claim while ICE continues detention—not that citizenship or government misconduct has been finally adjudicated.


## SOURCES

- [N.D. Indiana — James v. English habeas docket](https://dockets.justia.com/docket/indiana/inndce/3%3A2026cv01225/129408) — primary federal docket identifying the detention challenge and supporting exhibits filed under seal
- [Associated Press — documents support detained man's disputed U.S. citizenship claim](https://apnews.com/article/ice-immigration-wrongful-detention-indiana-3109797bea2b2102e130a82691d634af) — independent investigation based on court filings, public records, independently obtained paternity record and government response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
