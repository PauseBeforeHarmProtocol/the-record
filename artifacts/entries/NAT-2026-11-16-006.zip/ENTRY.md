# HHS finalizes HIPAA changes for faster record access and care coordination

**Entry ID:** NAT-2026-11-16-006
**Date:** November 16, 2026
**Checked:** 2026-11-16 6:00 PM EST
**Evidence state:** HHS announcement and fact sheet plus complete Federal Register public-inspection final rule; finalized and scheduled for publication, effective and compliance dates still prospective
**Review state:** current-standard-reviewed

HHS finalized shorter health-record access deadlines, specified electronic access through personal health apps, broadened care-coordination permissions and removed several notice and contracting burdens; the rule is not yet effective.

## THE FACTS

- HHS's Office for Civil Rights issued a final rule modifying the HIPAA Privacy Rule. The public-inspection copy is scheduled for Federal Register publication on November 19; HHS says the rule becomes effective 60 days after publication and regulated entities generally must comply 180 days after the effective date.
- The rule reduces the maximum initial response period for an individual's protected-health-information access request from 30 to 15 calendar days, while retaining one extension of no more than 30 calendar days. It also reduces identity-verification burdens and changes the permissible fee structure, including circumstances in which electronic copies must be free and requirements for advance fee information.
- When a covered entity can produce electronic protected health information in the requested form and format, the rule clarifies access through a personal health application. It also implements an individual's right to direct transmission of an electronic health-record copy to a designated person.
- For care coordination, the rule clarifies health-plan uses and disclosures and expressly permits disclosures to social-services agencies, community organizations, home- and community-based-services providers and similar health-related service organizations for individual-level coordination and case management.
- The rule removes the good-faith written acknowledgment requirement for receipt of a Notice of Privacy Practices, permits disclosures to telecommunications-relay-service assistants without treating the provider as a business associate, and expands mission-readiness disclosures to Public Health Service and NOAA commissioned personnel. HHS frames the changes as faster patient control, better coordination and lower administrative burden; outcomes have not yet been measured.

## SIGNIFICANCE

The rule changes operational access duties and disclosure permissions across the national health system. Faster access may materially help patients and caregivers, while expanded electronic and coordination pathways also make implementation quality, identity controls and downstream data handling consequential tests.

## GOALPOST / RESPONSE

HHS's access and burden claims can be tested after compliance through response times, complaint and enforcement data, fees, app-based delivery success and security incidents, coordination outcomes, regulated-entity costs and whether disclosures remain appropriately limited. Promulgation is not implementation or measured benefit.

## MAYBE / THEREFORE

Maybe faster deadlines and app access will give patients practical control and improve coordination, or implementation burdens and third-party app risks may limit those gains. Therefore HHS has finalized nationwide privacy-rule changes with future effective and compliance dates—not demonstrated faster access, lower costs or improved care outcomes.


## SOURCES

- [HHS OCR — HIPAA Privacy Rule final-rule announcement](https://www.hhs.gov/press-room/hhs-issues-new-final-rule-modernize-hipaa-privacy-rule-support-coordinated-care-individual-engagement-reduce-regulatory-burdens.html) — primary agency final-rule announcement and administration rationale
- [HHS OCR — HIPAA Privacy Rule final-rule fact sheet](https://www.hhs.gov/hipaa/for-professionals/privacy/changes-support-coordinated-care-individual-engagement-reduce-regulatory-burdens-final-rule.html) — primary agency fact sheet with access, coordination, burden, effective-date and compliance-date provisions
- [Federal Register public-inspection copy — HIPAA Privacy Rule changes](https://public-inspection.federalregister.gov/2026-23429.pdf) — primary complete final rule scheduled for November 19 publication; SHA-256 03e5ebe7e5b03532361d2023afe584c80992e445e4820af8211bb1ea5713b318

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
