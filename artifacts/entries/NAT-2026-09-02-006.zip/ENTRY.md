# DOE authorizes emergency PJM generation as heat wave strains regional grids

**Entry ID:** NAT-2026-09-02-006
**Date:** September 1–2, 2026
**Checked:** 2026-09-02 11:57 AM EDT
**Evidence state:** primary Department of Energy emergency order and independent Reuters reporting of PJM and MISO operational conditions; authority implemented, dispatch extent and outcomes unresolved
**Review state:** current-standard-reviewed

The temporary order permits specified emergency dispatch through September 8; grid alerts document elevated risk, not a confirmed rotating blackout.

## THE FACTS

- At PJM Interconnection's request, the Department of Energy issued Order 202-26-4-1 under Federal Power Act section 202(c), effective September 1 through 11:59 p.m. EDT on September 8.
- The order directs PJM to dispatch specified generating units as needed and authorizes certain backup generation as a last resort before or during an Energy Emergency Alert Level 3, subject to the order's reporting and operating conditions.
- Reuters reported that PJM declared a maximum-generation emergency alert on September 2 and asked generators on planned outages to report whether they could return. The Midcontinent Independent System Operator projected demand of about 121 gigawatts, below its 127.1-gigawatt record, while increasing reserve preparations.
- The order and alerts establish emergency authority and operational strain. No confirmed rotating blackout, complete reliability outcome, consumer-cost effect or emissions total resulting from the order was public by cutoff.

## SIGNIFICANCE

The order shows the administration using temporary federal emergency power to keep additional generation available during extreme demand across the largest U.S. regional grids. The need for emergency dispatch is a concrete reliability signal, while its benefits and costs depend on actual use, outages avoided, fuel and emissions effects and later grid investment.

## GOALPOST / RESPONSE

DOE and PJM say temporary dispatch flexibility is needed to maintain reliability during extreme heat and tight reserves. Critics may argue repeated emergency orders can mask inadequate planning, transmission or capacity and shift environmental and operating costs outside ordinary rules. Dispatch logs, reserve margins, forced outages, customer interruptions, costs, emissions and after-action reliability reviews are the tests.

## MAYBE / THEREFORE

Maybe the temporary authority will provide prudent insurance and prevent outages without material side effects, or it may reveal deeper capacity and transmission problems while imposing costs or emissions that are not yet measured. Therefore the record confirms an operative one-week emergency order and elevated grid alerts—not that a blackout occurred, that every authorized unit ran or that the order solved the region's long-term reliability needs.


## SOURCES

- [DOE — PJM emergency order 202-26-4-1](https://www.energy.gov/ceser/federal-power-act-section-202c-pjm-interconnection-llc-pjm-order-no-202-26-41) — primary Federal Power Act section 202(c) order authorizing emergency generation dispatch through September 8
- [Reuters — heat wave stresses PJM and MISO electric grids](https://www.reuters.com/business/energy/blackout-risk-rises-heat-wave-stresses-largest-us-electric-grids-2026-09-02/) — independent reporting of grid emergency alerts, demand forecasts and the absence of a confirmed rotating outage by cutoff

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
