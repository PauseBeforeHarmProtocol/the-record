# Court temporarily blocks publication of university foreign-donor identities

**Entry ID:** NAT-2026-10-01-006
**Date:** October 1–2, 2026
**Checked:** 2026-10-02 5:57 PM EDT
**Evidence state:** primary district-court opinion and temporary restraining order plus Reuters reporting with the Education Department's on-record response; temporary relief ordered, final merits unresolved
**Review state:** current-standard-reviewed

A federal judge barred the Education Department for 28 days from publishing names or identifying information for institutions that had not already disclosed it; the order is temporary, not a final merits ruling.

## THE FACTS

- In Association of American Universities v. U.S. Department of Education, No. 1:26-cv-03438, U.S. District Judge Tanya Chutkan granted a temporary restraining order on October 1 preventing the department from publishing names or identifying information of colleges and universities that had not already made their foreign-donor reporting information public.
- The order lasts 28 days. It set an October 13 deadline for the government’s opposition and an October 20 reply deadline, preserving the parties’ positions while the court considers further relief.
- The court found the university associations likely to succeed on their Administrative Procedure Act claim that the publication decision was arbitrary and capricious, and found likely irreparable harm sufficient for temporary relief. Those are preliminary findings, not a final judgment that the policy is unlawful.
- Education Department spokesperson Ellen Keast said the lawsuit was an attempt to avoid accountability for funding from malign foreign actors, said Americans deserve transparency and said the department would continue to fight. The order does not prevent disclosure of information already public or decide the ultimate scope of federal reporting authority.

## SIGNIFICANCE

The order temporarily limits an administration transparency initiative at the point where disclosure could cause irreversible identification. It preserves confidentiality for covered institutions while litigation proceeds, but does not permanently bar publication or invalidate the foreign-donor reporting regime.

## GOALPOST / RESPONSE

The Education Department argues that identifying institutions serves accountability and transparency about foreign influence; the associations argue the publication decision departed from lawful process and would cause irreparable harm. The written administrative record, briefing, any preliminary injunction, appeal, final judgment and later publication practices are the tests.

## MAYBE / THEREFORE

Maybe the government will justify the disclosure decision on a fuller record or narrow the publication plan, or the court may extend relief after additional briefing. Therefore the record establishes a 28-day temporary restraint and preliminary APA findings—not a final merits ruling or permanent secrecy for foreign-donor reports.


## SOURCES

- [U.S. District Court for the District of Columbia — Association of American Universities v. Department of Education temporary restraining order](https://fingfx.thomsonreuters.com/gfx/legaldocs/jnvwoaorevw/10022026education.pdf) — primary judicial opinion and temporary restraining order
- [Reuters — judge blocks publication of university foreign-donor identities](https://www.reuters.com/legal/government/us-judge-blocks-trump-administration-publishing-names-universities-foreign-2026-10-02/) — independent reporting on temporary restraining order and administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
