# Court reinstates judicially appointed Seattle U.S. attorney

**Entry ID:** NAT-2026-10-01-002
**Date:** October 1, 2026
**Checked:** 2026-10-01 6:00 PM EDT
**Evidence state:** two independent reports describing the bench ruling and party positions; preliminary injunction granted, appeal announced and final merits unresolved
**Review state:** current-standard-reviewed

A preliminary injunction holds that the president could not unilaterally remove Roger Rogoff from a court appointment; the Justice Department says it will seek a stay and appeal.

## THE FACTS

- Chief U.S. District Judge Stanley Bastian granted Roger Rogoff a preliminary injunction on October 1 and ruled that Rogoff remained the lawful U.S. attorney for the Western District of Washington. The order reinstated access to the office and barred federal defendants from recognizing another person as the district’s U.S. attorney while the injunction remains in force.
- Seventeen active and senior district judges had unanimously appointed Rogoff on July 15 after the temporary appointment expired without a Senate-confirmed successor. President Trump removed Rogoff less than an hour after he took the oath.
- Bastian concluded that the governing statute authorizes a judicial appointee to serve until the vacancy is filled through presidential nomination and Senate confirmation and does not give the president unilateral removal authority over that appointment. This is a preliminary district-court ruling, not a final appellate resolution of presidential removal power.
- The Justice Department said it disagreed, would seek an immediate stay and would appeal. Trump has nominated Pete Serrano for the office, but the inspected reporting did not establish Senate confirmation by the cutoff.

## SIGNIFICANCE

The injunction is the first reported successful challenge by a judicially appointed U.S. attorney whom the administration removed and directly tests statutory and constitutional limits on using temporary personnel arrangements to control federal prosecutorial offices.

## GOALPOST / RESPONSE

The administration argues that the president retains ultimate removal authority over executive officers and says it will seek a stay and appeal. The operative tests are the written injunction, compliance, any stay, appellate disposition, and confirmation of a successor—not the administration’s asserted power alone.

## MAYBE / THEREFORE

Maybe the ruling will remain a narrow, temporary reading of one appointment statute, or appellate courts may use the case to set a broader limit on presidential removal of judicial appointees. Therefore the established result is Rogoff’s preliminary reinstatement and protected access—not a final nationwide rule or completed appeal.


## SOURCES

- [Associated Press — court reinstates judicially appointed Seattle U.S. attorney](https://apnews.com/article/rogoff-us-attorney-seattle-trump-096b29af640d3ccc764f3405d2073804) — independent reporting on preliminary injunction, case posture and administration response
- [Reuters — judge restores court-appointed Seattle federal prosecutor](https://www.reuters.com/world/us-judge-restores-court-appointed-top-federal-prosecutor-trump-fired-seattle-2026-10-01/) — independent reporting on bench ruling, injunction and Justice Department appeal position

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
