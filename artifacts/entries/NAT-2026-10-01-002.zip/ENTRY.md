# Ninth Circuit pauses judicially appointed Seattle prosecutor’s reinstatement

**Entry ID:** NAT-2026-10-01-002
**Date:** October 1–4, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** October 4 primary Ninth Circuit order and October 2 DOJ emergency motion, plus Reuters corroboration; administrative stay granted, substantive stay and merits unresolved
**Review state:** current-standard-reviewed

An October 4 administrative stay suspends Rogoff’s preliminary reinstatement while the appeals court considers the government’s stay request; removal authority remains undecided.

## THE FACTS

- Chief U.S. District Judge Stanley Bastian granted Roger Rogoff a preliminary injunction on October 1 and ruled that Rogoff remained the lawful U.S. attorney for the Western District of Washington. The order reinstated access to the office and barred federal defendants from recognizing another person as the district’s U.S. attorney while the injunction remains in force.
- Seventeen active and senior district judges had unanimously appointed Rogoff on July 15 after the temporary appointment expired without a Senate-confirmed successor. President Trump removed Rogoff less than an hour after he took the oath.
- Bastian concluded that the governing statute authorizes a judicial appointee to serve until the vacancy is filled through presidential nomination and Senate confirmation and does not give the president unilateral removal authority over that appointment. This is a preliminary district-court ruling, not a final appellate resolution of presidential removal power.
- The Justice Department said it disagreed, would seek an immediate stay and would appeal. Trump has nominated Pete Serrano for the office, but the inspected reporting did not establish Senate confirmation by the cutoff.
- On October 4, the Ninth Circuit granted the government an administrative stay in Rogoff v. Trump, No. 26-6445, suspending his preliminary reinstatement. The one-page order expressly says the temporary stay preserves the status quo while the substantive stay motion is considered and does not decide the appeal’s merits.
- In its October 2 emergency motion, DOJ argued that 28 U.S.C. 541(c) makes all U.S. attorneys removable by the president and that preventing removal would impair executive accountability. Those are the government’s statutory and constitutional arguments, not holdings of the appellate court.

## SIGNIFICANCE

The interim appellate order changes who may lead the office while preserving the unresolved dispute over presidential removal of judicial appointees. It pauses the district court’s practical remedy without reversing its reasoning on the merits.

## GOALPOST / RESPONSE

DOJ argues that presidential removal authority over executive prosecutors follows from 28 U.S.C. 541(c) and constitutional accountability. The substantive stay ruling, appeal, compliance and confirmation of a successor will determine the operative authority; the administrative stay supplies no merits endorsement.

## MAYBE / THEREFORE

Maybe continuity during appeal avoids disruptive changes in prosecutorial leadership while the court resolves the legal dispute. Therefore Rogoff’s reinstatement is temporarily stayed, but neither the president’s claimed removal power nor the district court’s contrary interpretation is finally resolved.


## SOURCES

- [Associated Press — court reinstates judicially appointed Seattle U.S. attorney](https://apnews.com/article/rogoff-us-attorney-seattle-trump-096b29af640d3ccc764f3405d2073804) — independent reporting on preliminary injunction, case posture and administration response
- [Reuters — judge restores court-appointed Seattle federal prosecutor](https://www.reuters.com/world/us-judge-restores-court-appointed-top-federal-prosecutor-trump-fired-seattle-2026-10-01/) — independent reporting on bench ruling, injunction and Justice Department appeal position
- [Ninth Circuit — Rogoff administrative stay, No. 26-6445, Dkt. 11.1](https://www.courthousenews.com/wp-content/uploads/2026/10/rogoff-vs-trump-ninth-circuit.pdf) — primary court order (CNS-hosted copy)
- [DOJ — Rogoff emergency stay motion, No. 26-6445, Dkt. 9.1](https://www.courthousenews.com/wp-content/uploads/2026/10/rogoff-vs-trump-emergency-appeal.pdf) — primary government court filing (CNS-hosted copy)
- [Reuters — Appeals court pauses reinstatement of fired Seattle prosecutor](https://www.reuters.com/legal/government/appeals-court-pauses-reinstatement-fired-seattle-federal-prosecutor-2026-10-04/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
