# Trump signs water, seafood-origin and employee-ownership laws

**Entry ID:** NAT-2026-10-15-008
**Date:** October 15, 2026
**Checked:** 2026-10-16 5:57 AM EDT
**Evidence state:** primary White House signing announcement; enactment implemented, downstream agency implementation and outcomes not yet measured
**Review state:** current-standard-reviewed

The President signed three separate bills affecting Crow Tribe water projects, seafood-origin testing and ERISA valuation of closely held stock. The enactments are complete; agency implementation and practical effects remain to be measured.

## THE FACTS

- The White House announced that President Trump signed S. 240, S. 283 and S. 2403 into law on October 15. The signing is a completed legal action; the three laws remain separate policy subjects and are not combined into one outcome measure.
- S. 240, the Crow Tribe Water Rights Settlement Amendments Act of 2025, amends the 2010 settlement to provide more flexibility for completing specified water projects on the Crow Tribe reservation in Montana.
- S. 283, the Illegal Red Snapper and Tuna Enforcement Act, requires the Department of Commerce to develop a standard chemical-analysis methodology for identifying seafood country of origin.
- S. 2403, the Retire through Ownership Act, amends ERISA to define adequate consideration for certain closely held stock. The signing announcement does not itself measure changes in employee ownership, transaction pricing or enforcement.

## SIGNIFICANCE

The signing converts three congressional measures into federal law, creating concrete implementation duties and legal standards across tribal water infrastructure, seafood traceability and employee-stock transactions. Their value depends on project delivery, method validation, agency guidance and market behavior rather than enactment alone.

## GOALPOST / RESPONSE

The strongest case for the laws is that they remove project constraints, improve seafood-origin enforcement and give employee-ownership transactions clearer valuation rules. Implementing guidance, deadlines, appropriations, completed water projects, validated origin tests, enforcement results, transaction volume and participant outcomes are the tests.

## MAYBE / THEREFORE

Maybe the laws accelerate infrastructure, deter mislabeled imports and reduce uncertainty in employee-stock transactions, or implementation may expose technical, funding and compliance limits. Therefore all three bills were signed into law; successful execution and benefits have not yet been measured.


## SOURCES

- [White House — S. 240, S. 283 and S. 2403 signed into law](https://www.whitehouse.gov/briefings-statements/2026/10/congressional-bills-s-240-s-283-and-s-2403-signed-into-law/) — primary presidential signing announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
