# DOT announces Monday finalization of lower light-vehicle fuel-economy standards

**Entry ID:** NAT-2026-09-26-001
**Date:** September 26, 2026
**Checked:** 2026-09-26 5:57 PM EDT
**Evidence state:** signed NHTSA notice of proposed rulemaking with numerical standards and modeled effects, Trump's primary publication and named-official Reuters reporting on expected September 28 finalization; announcement verified, final rule text and implementation absent at cutoff
**Review state:** current-standard-reviewed

Trump said he approved the standards and DOT officials said the rule would be finalized September 28; no final rule text, signature, publication or effective date was public by cutoff.

## THE FACTS

- Trump wrote on September 26 that he had approved new fuel-economy standards. Reuters reported that Transportation Secretary Sean Duffy said the standards would be unveiled Monday, September 28, and that DOT officials described Monday as the expected finalization date.
- The operative text available at cutoff remained NHTSA's December 2025 notice of proposed rulemaking for passenger cars and light trucks in model years 2022 through 2031. That proposal projected a roughly 34.5-mile-per-gallon fleetwide average for model year 2031, compared with 50.4 mpg under the prior standards, and proposed ending intermanufacturer credit trading beginning in model year 2028.
- Reuters reported DOT's own proposal estimates: about $930 less in average upfront vehicle cost, roughly 100 billion additional gallons of fuel consumed through 2050, about $185 billion in additional fuel spending and approximately 5% more carbon-dioxide emissions. These are modeled projections, not measured outcomes of a final rule.
- The administration says lower standards will improve consumer choice, affordability and vehicle-fleet renewal. Former Transportation Secretary Pete Buttigieg responded that lower standards would make drivers pay more at the pump and weaken U.S. clean-technology competitiveness. No final regulatory text, signature, Federal Register publication, effective date or implementation evidence was located by the cutoff.

## SIGNIFICANCE

The announcement advances a major vehicle-cost, fuel-use and climate policy from proposal toward final action, but the legal and practical change depends on the final instrument. The proposal's own modeling identifies a tradeoff between lower upfront prices and substantially higher lifetime fuel use, spending and emissions.

## GOALPOST / RESPONSE

The administration frames the rollback as affordability, safety and consumer choice rather than an electric-vehicle mandate. The strongest response is that lower purchase prices may be offset by higher fuel costs and emissions. The final text, regulatory analysis, publication and effective dates, manufacturer compliance plans, litigation, vehicle prices, fuel consumption and emissions are the tests.

## MAYBE / THEREFORE

Maybe the final rule will materially lower vehicle purchase prices and let manufacturers better match consumer demand, or higher lifetime fuel spending and weaker efficiency incentives may outweigh those gains. Therefore the record treats September 26 as an announced finalization following an existing proposal—not as a published, effective or implemented final rule, and not as proof of any projected savings, fuel use or emissions outcome.


## SOURCES

- [SAFE Vehicles Rule III for Model Years 2022–2031 Passenger Cars and Light Trucks — notice of proposed rulemaking](https://www.nhtsa.gov/sites/nhtsa.gov/files/2025-12/CAFE-NPRM-2031-MY-PC-LT-2025-SIGNED.pdf) — primary proposed rule and regulatory-impact estimates
- [Trump says he approved new fuel-economy standards](https://truthsocial.com/@realDonaldTrump/117338936999613227) — primary presidential statement; evidence that the statement was published, not an independently operative rule
- [US to finalize sharply lower vehicle fuel economy standards](https://www.reuters.com/world/trump-says-he-approved-fuel-economy-standards-ending-biden-ev-mandate-2026-09-26/) — independent reporting on announced finalization timing, proposal terms and agency estimates

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
