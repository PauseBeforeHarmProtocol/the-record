# NHTSA finalizes lower light-vehicle fuel-economy standards

**Entry ID:** NAT-2026-09-26-001
**Date:** September 26–28, 2026
**Checked:** 2026-09-28 5:55 PM EDT
**Evidence state:** signed NHTSA final rule and DOT release, with independent Reuters context; finalization verified, publication/effectiveness and modeled outcomes still pending
**Review state:** current-standard-reviewed

The signed rule sets a projected 34.9-mpg model-year-2031 fleet average and ends intermanufacturer credit trading beginning with model year 2028.

## THE FACTS

- NHTSA released a final rule signed September 25 that revises passenger-car and light-truck fuel-economy standards for model years 2022 through 2031. The agency projects a 34.9-mile-per-gallon industry fleet average for model year 2031.
- The rule ends intermanufacturer credit trading beginning with model year 2028 and changes specified vehicle-classification provisions beginning with model year 2030. It was submitted for Federal Register publication and states that it will take effect 60 days after publication; no publication or effective date was inferred at the cutoff.
- DOT projects that the final standards will reduce the upfront cost of an average new vehicle by about $1,300 and produce $138 billion in savings over five years. Those figures are agency modeling, not measured consumer savings or transaction prices.
- NHTSA also projects that faster turnover to newer vehicles will avoid about 1,900 fatalities and 300,000 serious injuries through 2050. The final rule does not itself demonstrate those outcomes, and Reuters reported the separate agency estimate that manufacturer technology costs would fall by $60.6 billion through 2031.

## SIGNIFICANCE

The final signed instrument changes the legal compliance baseline for a major national vehicle market. It replaces an announced finalization with a completed agency rule while leaving publication, effective date, litigation, manufacturer behavior and real-world prices, fuel use, emissions and safety outcomes unresolved.

## GOALPOST / RESPONSE

The administration says lower standards will make new vehicles more affordable, accelerate fleet turnover and improve safety. The strongest response is that lower efficiency can shift cost from purchase price to fuel use and weaken emissions reductions. Federal Register publication, manufacturer compliance plans, vehicle prices, fuel spending, fleet turnover, crashes and emissions are the tests.

## MAYBE / THEREFORE

Maybe lower standards will reduce acquisition costs and speed replacement of older vehicles, or lifetime fuel costs and emissions may outweigh those gains. Therefore the record now identifies a signed final rule with modeled benefits—not an already effective standard or proof of lower prices, savings, deaths avoided or injuries prevented.


## SOURCES

- [Final Rule: Corporate Average Fuel Economy Standards for Passenger Cars and Light Trucks for Model Years 2022–2031](https://www.nhtsa.gov/document/cafe-2022-2031-final-rule) — final rule
- [President Trump & Transportation Secretary Duffy Finalize Freedom Means Affordable Cars Standards](https://www.transportation.gov/briefing-room/president-trump-transportation-secretary-duffy-finalize-freedom-means-affordable-cars) — agency release
- [US finalizes lower fuel-economy standards and projects manufacturer cost reductions](https://www.reuters.com/business/autos-transportation/us-says-gm-tech-costs-will-decline-by-204-billion-through-2031-because-lower-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
