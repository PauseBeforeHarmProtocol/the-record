# Justice Department sues Kansas City, Kansas schools over transgender-student policy

**Entry ID:** NAT-2026-09-01-009
**Date:** September 1, 2026
**Checked:** 2026-09-01 6:02 PM EDT
**Evidence state:** primary Justice Department filing announcement corroborated and contextualized by Reuters; lawsuit filed, allegations unproven and judicial outcome pending
**Review state:** current-standard-reviewed

The filed complaint alleges violations of two federal parental-records laws; the district had not answered and no court had found the policy unlawful by cutoff.

## THE FACTS

- The Justice Department's Civil Rights Division and the U.S. Attorney for the District of Kansas filed a federal lawsuit against Kansas City, Kansas Public Schools concerning its policy for supporting transgender students.
- DOJ alleges that district staff may develop and implement student transition plans without parental knowledge or consent and that the policy violates the Family Educational Rights and Privacy Act and the Protection of Pupil Rights Amendment.
- The department called the case the first lawsuit of its kind and said it followed Department of Education efforts to obtain compliance. Reuters independently confirmed the filing and reported that the Kansas City school district did not immediately respond to a request for comment.
- The complaint is an allegation initiating litigation. No answer, evidentiary hearing, injunction, merits ruling, funding termination or final remedial order existed by cutoff.
- Reuters placed the filing within a broader administration campaign involving transgender policies in schools and efforts to obtain medical records concerning transgender youth, some of which courts have blocked. Those other actions are context, not findings in this case.

## SIGNIFICANCE

The lawsuit uses federal civil-rights enforcement to challenge how a local school system handles transgender students and parental access to information. A ruling could affect school policies beyond Kansas, but the complaint alone neither proves a statutory violation nor establishes a nationwide rule.

## GOALPOST / RESPONSE

DOJ says federal law protects parents' access and consent rights and that schools may not conceal sensitive plans. The district had not supplied a public response by cutoff; a likely countercase will concern the policy's actual text, student privacy, safety and whether the cited statutes authorize DOJ's requested relief. The complaint, answer, district records, injunction proceedings, merits findings, appeal and any funding action are the tests.

## MAYBE / THEREFORE

Maybe the evidence will show that the district unlawfully withheld records or conducted covered evaluations without consent, or the court may find that DOJ has overstated the policy, the statutes or its authority. Therefore the record confirms a filed federal lawsuit and accurately attributes its allegations—not proven misconduct, a judicial ban on transition-support policies or a final nationwide parental-rights rule.


## SOURCES

- [Justice Department — lawsuit against Kansas City, Kansas Public Schools](https://www.justice.gov/opa/pr/justice-department-sues-kansas-city-kansas-public-schools-stop-secret-gender-transitions) — primary agency announcement establishing the filed case, statutory allegations and requested intervention
- [Reuters — DOJ sues Kansas school district over transgender-student policy](https://www.reuters.com/legal/government/us-sues-kansas-school-district-aiding-transgender-students-transitions-2026-09-01/) — independent reporting confirming the filing, allegations, procedural state and lack of an immediate district response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
