# State Department approves possible $800 million helicopter sale to Iraq

**Entry ID:** NAT-2026-08-31-013
**Date:** August 31, 2026
**Checked:** 2026-09-01 6:04 AM EDT
**Evidence state:** primary State Department foreign-military-sale notice corroborated by Reuters; possible sale approved and notified, contracting, expenditure, delivery and outcomes pending
**Review state:** current-standard-reviewed

The foreign-military-sale approval authorizes a proposed package of Bell helicopters and equipment to proceed through the congressional process; it is not a signed contract, expenditure or delivery.

## THE FACTS

- The State Department approved a possible Foreign Military Sale to Iraq with an estimated value of $800 million and transmitted the required certification to Congress.
- The requested package includes Bell 412EPX and Bell 407M helicopters, associated weapons, equipment, training and support. Reuters identified Bell Textron of Fort Worth, Texas, as the proposed principal contractor.
- The administration said the sale would support Iraqi capability and U.S. foreign-policy and national-security objectives. Approval establishes a ceiling and permits the case to advance; it does not show that Congress completed review, Iraq accepted final terms, a contract was signed, money was spent or aircraft were delivered.
- Final value and quantities may be lower depending on requirements, budget authority and signed agreements. No operational outcome or regional-security effect can be measured before contracting, delivery, training and use.

## SIGNIFICANCE

An $800 million military-sales approval could deepen the U.S.-Iraq security relationship and materially equip Iraqi aviation forces, while directing potential work to a U.S. manufacturer. The distinction between approval and execution matters because the transaction can still change, be delayed or never reach its announced ceiling.

## GOALPOST / RESPONSE

The administration says the package would strengthen a partner's ability to address current and future threats without changing the regional military balance. Contract notices, congressional review, a signed letter of offer and acceptance, appropriated or transferred funds, final quantities, delivery schedules, training, end-use monitoring and operational results are the tests.

## MAYBE / THEREFORE

Maybe the approved package will proceed substantially as described and improve Iraqi aviation capacity, or negotiations, funding, congressional scrutiny and implementation constraints may reduce or delay it. Therefore the record confirms State Department approval of a possible sale valued at up to $800 million—not a completed purchase, federal expenditure, manufacturer revenue, aircraft delivery or demonstrated security outcome.


## SOURCES

- [State Department — possible Bell 412 and Bell 407M helicopter sale to Iraq](https://www.state.gov/releases/bureau-of-political-military-affairs/2026/08/iraq-bell-412-and-bell-407m-helicopters/) — primary foreign-military-sale notice identifying the requested equipment, estimated value and stated policy rationale
- [Reuters — U.S. approves possible $800 million helicopter sale to Iraq](https://www.reuters.com/business/aerospace-defense/us-approves-military-sale-helicopters-iraq-800-million-2026-08-31/) — independent reporting on the State Department approval, estimated ceiling and proposed principal contractor

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
