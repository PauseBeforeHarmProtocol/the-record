# CMS finalizes 2027 home-health payments and broader Medicare enrollment enforcement

**Entry ID:** NAT-2026-11-04-004
**Date:** November 4, 2026
**Checked:** 2026-11-05 12:07 AM EST
**Evidence state:** CMS final-rule fact sheet, press-release explanation and Federal Register public-inspection record, corroborated by an AHA policy summary
**Review state:** current-standard-reviewed

The rule projects a net home-health payment increase while making revocations retroactive and widening enrollment enforcement authorities.

## THE FACTS

- On November 4, CMS issued the CY 2027 Home Health Prospective Payment System final rule, CMS-1844-F. It went on public inspection that day and is scheduled for Federal Register publication November 9. This same-day action occurred before the prior archive cutoff and is recorded as a disclosed backfill discovered and inspected in this run.
- CMS estimates aggregate Medicare payments to home-health agencies will rise 2.4%, or $415 million, compared with 2026. That estimate combines a 2.1% payment update and a projected 0.3% fixed-dollar-loss effect while the rule separately applies a temporary 3.0% reduction to the 2027 base rate tied to earlier Patient-Driven Groupings Model behavior assumptions.
- The rule makes all Medicare enrollment revocations retroactive to the date noncompliance began and adds or expands grounds for enrollment denial or revocation. It also extends some license and program-suspension consequences to owners and managing employees and allows action against certain hospices, home-health agencies and DMEPOS suppliers that fail reenrollment and survey or accreditation requirements after specified ownership changes.
- CMS projects the broader enrollment provisions will save about $82 million annually. That figure is an agency estimate; no post-implementation recovery, fraud reduction, beneficiary-access or due-process outcome has yet been measured.
- CMS also clarified that skilled palliative care can be covered under the existing home-health benefit when eligibility rules are met, while stressing that the rule creates no new benefit. It shortened an OASIS quality-data submission deadline from 135 to 45 days, which CMS says can reduce public-reporting lag by up to three months; CMS reports that about 98% of agencies already submit within 45 days.

## SIGNIFICANCE

The rule affects national home-health reimbursement and gives CMS broader, partly retroactive enrollment-enforcement tools across Medicare provider types. The net payment projection does not show how individual agencies fare, and the enforcement savings and access consequences remain unmeasured.

## GOALPOST / RESPONSE

CMS says retroactive revocations and expanded denial grounds will recover improper payments, deter fraud and protect beneficiaries while preserving access through case-specific review. The tests are actual recoveries, error and appeal rates, provider exits, beneficiary access and quality-reporting timeliness—not the $82 million projection alone.

## MAYBE / THEREFORE

Maybe targeted enforcement removes high-risk providers without disrupting care, or retroactivity produces disputes and access losses in concentrated markets; individual agencies may also experience results unlike the aggregate 2.4% estimate. Therefore the archive records finalized payment and enrollment policy, not proven savings, fraud reduction or uniform provider gains.


## SOURCES

- [CMS — CY 2027 Home Health Prospective Payment System final rule fact sheet](https://www.cms.gov/newsroom/fact-sheets/calendar-year-cy-2027-home-health-prospective-payment-system-final-rule-cms-1844-f) — primary final-rule fact sheet and agency explanation of payment, enrollment and quality provisions
- [Federal Register public inspection — CMS-1844-F home health final rule](https://www.federalregister.gov/public-inspection/2026-22750/calendar-year-2027-home-health-prospective-payment-system-rate-update-requirements-for-the-hh) — primary public-inspection final-rule and scheduled-publication record
- [AHA — CMS finalizes provider-enrollment changes and 2.4% home-health increase](https://wecarewevote.aha.org/node/712316) — stakeholder summary corroborating payment and provider-enrollment provisions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
