# Liberia agrees to receive up to 1,200 U.S. third-country deportees

**Entry ID:** NAT-2026-08-20-001
**Date:** August 20, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** Liberian official confirmation and independent reporting; agreement implementation began
**Review state:** current-standard-reviewed

The agreement extends the administration's third-country deportation program, beginning with 20 people and accompanied by $5 million in U.S. support.

## THE FACTS

- A Liberian official said Liberia agreed to accept up to 1,200 people deported by the United States over 12 months even when they are not Liberian nationals.
- The first flight carried 20 people, including Venezuelan and Cuban nationals. The United States awarded Liberia $5 million described as migration-management support.
- Liberia said the deportees would be treated as guests who could leave or seek asylum. U.S. law can bar removal to a country where a person is likely to be tortured, making individual screening and onward movement material safeguards.

## SIGNIFICANCE

Third-country removal separates deportation from return to a person's country of citizenship and shifts custody, safety, and legal responsibility to a government with which the person may have no prior connection. The agreement's scale and funding make oversight of consent, screening, detention, asylum access, and outcomes necessary.

## GOALPOST / RESPONSE

The administration describes third-country agreements as a tool for enforcing removal orders when direct return is difficult. That enforcement rationale does not eliminate non-refoulement obligations or establish that every receiving-country arrangement provides durable legal status and safety.

## MAYBE / THEREFORE

Maybe third-country agreements are a practical way to execute removal orders when direct return is difficult, and Liberia says recipients will be treated as guests who may leave or seek asylum. Therefore implementation must be tested person by person, beginning with the first 20, for torture screening, asylum access, freedom of movement, onward movement, durable legal status, and safety.


## SOURCES

- [Reuters — Liberia third-country deportation agreement](https://www.reuters.com/world/africa/venezuelans-cubans-among-deportees-liberia-under-trump-deal-official-says-2026-08-20/) — independent reporting with Liberian official confirmation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
