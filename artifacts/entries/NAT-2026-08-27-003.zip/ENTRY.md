# EPA preliminarily finds trans-1,2-dichloroethylene poses unreasonable human-health risk

**Entry ID:** NAT-2026-08-27-003
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 AM EDT
**Evidence state:** published EPA notice and draft-evaluation summary under TSCA; preliminary unreasonable-risk finding open to comment and peer review, final determination and risk-management action pending
**Review state:** current-standard-reviewed

The draft TSCA evaluation covers worker, consumer, general-population, fenceline-community, and environmental exposures; comments close October 26.

## THE FACTS

- EPA published a draft Toxic Substances Control Act risk evaluation that preliminarily finds trans-1,2-dichloroethylene poses an unreasonable risk to human health, driven primarily by certain evaluated conditions of use. The finding is draft, not final, and the notice does not itself restrict manufacture or use.
- The chemical is used as a solvent, degreaser, cleaning agent, surface modifier, processing aid, and propellant. EPA evaluated inhalation and dermal exposures for workers, indirect workplace exposure, consumer use, general-population and fenceline-community exposure, and acute and chronic environmental risks; it says the chemical is expected to persist in air and water but not sorb to soil.
- Comments are due October 26, 2026, and EPA is seeking additional information about workplace controls, protective equipment, vapor-degreasing facilities, manufacturing frequency, and exposure assumptions. A Scientific Advisory Committee on Chemicals peer review and public comments will precede the final evaluation, which would determine whether TSCA risk management is required.

## SIGNIFICANCE

The draft is a formal evidence-based federal finding that can lead to restrictions or other risk-management rules for a chemical used in industrial and consumer products. The open technical questions mean the scope of any affected uses and protections remains unsettled.

## GOALPOST / RESPONSE

EPA says the draft uses the best available science and weight of the evidence without considering costs or non-risk factors. Manufacturers and users may argue that exposure assumptions understate existing controls or protective equipment, while worker and community advocates may argue the analysis misses real-world exposures. Peer review, submitted monitoring data, the final risk determination, and any later risk-management rule are the tests.

## MAYBE / THEREFORE

Maybe better workplace-control data will narrow the preliminary finding, or peer review may confirm broader risk than current practice recognizes. Therefore the record labels the conclusion preliminary and does not convert a draft risk evaluation into a ban, final hazard determination, or measured illness count.


## SOURCES

- [Federal Register — draft TSCA risk evaluation for trans-1,2-dichloroethylene](https://www.federalregister.gov/documents/2026/08/27/2026-17478/trans-12-dichloroethylene-draft-risk-evaluation-under-the-toxic-substances-control-act-tsca-notice) — primary notice of a preliminary unreasonable-risk finding and public-comment process

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
