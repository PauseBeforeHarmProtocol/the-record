# Federal noncitizen-voting push produces cases but no identified broad pattern

**Entry ID:** NAT-2026-09-15-003
**Date:** September 15–October 1, 2026
**Checked:** 2026-10-01 12:04 PM EDT
**Evidence state:** independent review of federal and state records and named official statements; charges, investigations, confirmed ballots, convictions and election effects remain separately measured
**Review state:** current-standard-reviewed

New charging totals and state examples document isolated cases and enforcement growth while preserving the distinction among investigations, registrations, ballots, charges and election effects.

## THE FACTS

- Reuters reviewed federal court filings and identified five defendants in separate Miami and Madison cases arguing for the first time that the 1996 Voting by Aliens statute is unconstitutional because states, rather than Congress, set voter qualifications. The motions seek dismissal before trials scheduled from October 5 through December 14; they are defense arguments, not merits rulings.
- The statute makes noncitizen voting in federal elections punishable by up to one year in prison and a $100,000 fine. The defendants are accused of violations, and the archive does not treat the accusations as convictions or independently determine intent.
- The Justice Department argues that Congress may protect federal election integrity and legislate on immigration, and compares the statute with federal laws against repeat voting and foreign-national campaign contributions. Former Solicitor General Paul Clement, appointed to advise one Miami court, concluded that Congress likely lacked authority but called the question not entirely clear-cut.
- Reuters found 129 people charged under the statute during its 30-year history and reported that the typical defendant was a lawful permanent resident with community ties who said they mistakenly believed they could vote. Before Trump's second term, many cases ended in guilty pleas and fines around $150; the administration's push to deport noncitizen voters materially increases potential consequences.
- A sixth defendant's dismissal motion was denied on September 9, and his trial began September 14. That ruling does not resolve the other five challenges, establish widespread noncitizen voting or determine the constitutionality of every application of the statute.
- In a separate September 23 investigation, Reuters reviewed official state records, court records and local reporting and found that more than 30,000 self-declared noncitizens may have been mistakenly added to voter rolls since 2000 because of software or clerical errors across 12 states. Reuters described the nationwide tally as a first and said the numbers are inexact and subject to revision.
- Reuters could not determine how many of those people cast ballots. Experts told the outlet the registrations were too few relative to more than 170 million registered voters to affect national elections. New Jersey reported about 6,600 mistaken registrations; Iowa's initial list of more than 2,000 later shrank to 277, and state officials said 35 noncitizens cast counted ballots among more than 1.6 million voters in 2024.
- The reviewed cases pointed principally to state motor-voter software and processing failures rather than an organized scheme. One election expert said proof-of-citizenship rules would not prevent errors in which applicants correctly identified themselves as noncitizens but the system registered them anyway. The White House said the registrations showed elections had been compromised and cited 11 announced arrests since May; that response does not establish coordinated or outcome-changing voting.
- A separate Reuters review published September 23 found that federal prosecutors charged about 20 people under the Voting by Aliens law during September—about 13 percent of all prosecutions under that law since its 1996 enactment. A Justice Department spokesperson said 32 people had been charged in the prior four weeks with noncitizen voting and related offenses.
- Those September figures measure charges, not convictions, confirmed ballots or election effects. Acting Deputy Attorney General Trent McCotter said the cases refuted claims that noncitizen voting never occurs; the small number and unresolved cases do not by themselves establish widespread, coordinated or outcome-changing voting.
- On October 1, the Justice Department announced charges against 10 people in Minnesota after a review covering roughly 8.5 million ballots. The charges are accusations and do not establish 8.5 million suspect ballots, convictions or an outcome-changing pattern.
- Deputy Attorney General Todd Blanche said the department had about 90 election-misconduct cases, including roughly 50 alleged noncitizen-voting matters, but said officials had not identified a pattern. Investigation and charging totals remain distinct from proven ballots and convictions.
- The Associated Press reported that Nevada officials investigating a federal list of about 1,500 names found no registered noncitizens in that list. In Maricopa County, Arizona, officials flagged about 60 registrations and prosecutors charged eight people; neither example established coordinated or outcome-changing voting.
- Homeland Security cited about 1,600 voter-fraud investigations and more than 300,000 additional names under review. Those agency figures describe investigative workload or referrals, not validated noncitizen ballots, criminal findings or election effects.

## SIGNIFICANCE

The administration has expanded federal investigation and prosecution of noncitizen voting, but the reviewed evidence still separates a small number of charged cases from millions of ballots and from broader claims about election outcomes. The emerging record can test both enforcement claims and whether administrative safeguards are proportionate to measured incidence.

## GOALPOST / RESPONSE

The administration says prosecutions and investigations are needed for accountability and public trust, and officials cite additional pending cases. Election administrators and outside reviewers distinguish investigations and registration errors from confirmed ballots and changed outcomes. The tests are dispositions, validated audits, proven ballots, intent findings, system fixes and measurable election effects—not investigation or referral totals alone.

## MAYBE / THEREFORE

Maybe a larger investigative pipeline will uncover additional unlawful voting, or it may mainly resolve isolated mistakes and false positives without revealing an organized pattern. Therefore the record now establishes increased federal enforcement, ten Minnesota charges and several bounded state examples—not convictions in every case, a nationwide coordinated scheme, 300,000 illegal ballots or an election-changing effect.


## SOURCES

- [Reuters — noncitizen-voting prosecutions and constitutional challenges](https://www.reuters.com/legal/government/noncitizens-accused-illegal-us-voting-challenge-trumps-authority-prosecute-them-2026-09-15/) — independent court-filing review and 30-year federal prosecution analysis
- [Reuters — state errors and noncitizen voter registrations](https://www.reuters.com/legal/government/thirty-thousand-mistakes-how-red-blue-states-added-non-citizens-us-voter-rolls-2026-09-23/) — independent records review and nationwide data analysis
- [Reuters — noncitizen-voting prosecution surge](https://www.reuters.com/legal/government/trump-ramps-up-noncitizen-voting-prosecutions-ahead-midterms-2026-09-23/) — independent court-record review and named Justice Department statements
- [Associated Press — federal noncitizen-voting enforcement review](https://apnews.com/article/homeland-security-justice-department-midterms-noncitizen-voting-09b8391612fc87676267a254c55eaee8) — independent records review and reporting on charges, investigations and outcomes

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
