# Federal noncitizen-voting push produces cases but no identified broad pattern

**Entry ID:** NAT-2026-09-15-003
**Date:** September 15–October 15, 2026
**Checked:** 2026-10-15 11:59 AM EDT
**Evidence state:** Reuters review of Nevada public records and on-record interviews, layered onto prior DOJ letters, court records and election-administration reporting; seven subpoenas documented, underlying eligibility findings and political motive unresolved
**Review state:** current-standard-reviewed

DOJ's 48-hour California demand escalates the federal noncitizen-voting push before the midterms, while the supplied list and any affected ballots remain unverified and unadjudicated.

## THE FACTS

- Reuters reviewed federal court filings and identified five defendants in separate Miami and Madison cases arguing for the first time that the 1996 Voting by Aliens statute is unconstitutional because states, rather than Congress, set voter qualifications. The motions seek dismissal before trials scheduled from October 5 through December 14; they are defense arguments, not merits rulings.
- The statute makes noncitizen voting in federal elections punishable by up to one year in prison and a $100,000 fine. The defendants are accused of violations, and the archive does not treat the accusations as convictions or independently determine intent.
- The Justice Department argues that Congress may protect federal election integrity and legislate on immigration, and compares the statute with federal laws against repeat voting and foreign-national campaign contributions. Former Solicitor General Paul Clement, appointed to advise one Miami court, concluded that Congress likely lacked authority but called the question not entirely clear-cut.
- Reuters found 129 people charged under the statute during its 30-year history and reported that the typical defendant was a lawful permanent resident with community ties who said they mistakenly believed they could vote. Before Trump's second term, many cases ended in guilty pleas and fines around $150; the administration's push to deport noncitizen voters materially increases potential consequences.
- A sixth defendant's dismissal motion was denied on September 9, and his trial began September 14. That ruling does not resolve the other five challenges, establish widespread noncitizen voting or determine the constitutionality of every application of the statute.
- In a separate September 23 investigation, Reuters reviewed official state records, court records and local reporting and found that more than 30,000 self-declared noncitizens may have been mistakenly added to voter rolls since 2000 because of software or clerical errors across 12 states. Reuters described the nationwide tally as a first and said the numbers are inexact and subject to revision.
- Reuters could not determine how many of those people cast ballots. Experts told the outlet the registrations were too few relative to more than 170 million registered voters to affect national elections. New Jersey reported about 6,600 mistaken registrations; Iowa's initial list of more than 2,000 later shrank to 277, and state officials said 35 noncitizens cast counted ballots among more than 1.6 million voters in 2024.
- The reviewed cases pointed principally to state motor-voter software and processing failures rather than an organized scheme. One election expert said proof-of-citizenship rules would not prevent errors in which applicants correctly identified themselves as noncitizens but the system registered them anyway. The White House said the registrations showed elections had been compromised and cited 11 announced arrests since May; that response does not establish coordinated or outcome-changing voting.
- A separate Reuters review published September 23 found that federal prosecutors charged about 20 people under the Voting by Aliens law during September—about 13 percent of all prosecutions under that law since its 1996 enactment. A Justice Department spokesperson said 32 people had been charged in the prior four weeks with noncitizen voting and related offenses.
- Those September figures measure charges, not convictions, confirmed ballots or election effects. Acting Deputy Attorney General Trent McCotter said the cases refuted claims that noncitizen voting never occurs; the small number and unresolved cases do not by themselves establish widespread, coordinated or outcome-changing voting.
- On October 1, the Justice Department announced charges against 10 people in Minnesota after a review covering roughly 8.5 million ballots. The charges are accusations and do not establish 8.5 million suspect ballots, convictions or an outcome-changing pattern.
- Deputy Attorney General Todd Blanche said the department had about 90 election-misconduct cases, including roughly 50 alleged noncitizen-voting matters, but said officials had not identified a pattern. Investigation and charging totals remain distinct from proven ballots and convictions.
- The Associated Press reported that Nevada officials investigating a federal list of about 1,500 names found no registered noncitizens in that list. In Maricopa County, Arizona, officials flagged about 60 registrations and prosecutors charged eight people; neither example established coordinated or outcome-changing voting.
- Homeland Security cited about 1,600 voter-fraud investigations and more than 300,000 additional names under review. Those agency figures describe investigative workload or referrals, not validated noncitizen ballots, criminal findings or election effects.
- On October 1, U.S. District Judge David Leibowitz dismissed the federal charge against Chelsea Cox after ruling that the 1996 Voting by Aliens law was unconstitutional as applied because states set voter qualifications. The ruling applies to Cox and does not bind judges in roughly 45 other pending cases; the Justice Department had argued that Congress could legislate against foreign election interference and had not announced its next step by the reporting cutoff.
- On October 13, acting Deputy Attorney General R. Trent McCotter gave California officials 48 hours to review a federal list of people DOJ said it believed were likely noncitizens who had been sent mail ballots. Reuters reviewed the letter and reported that DOJ supplied Los Angeles County a password-protected thumb drive; the number of names was not disclosed in the reviewed report.
- The letter demanded that California stop sending ballots to listed people until citizenship was confirmed, segregate returned ballots from listed voters and not tabulate already returned ballots until status was determined. DOJ threatened to seek emergency relief if the state did not comply, and a department spokesperson confirmed the letter and defended legal action to protect election integrity. The demands and federal characterizations are not court orders, verified noncitizen findings or proof that any listed person voted unlawfully.
- A Reuters review of Nevada public records found that the Justice Department delivered seven subpoenas to Secretary of State Cisco Aguilar's office between June 16 and September 2 seeking voter information. The subpoenas establish compulsory investigative activity; they do not establish that any named registrant was a noncitizen or voted unlawfully.
- Aguilar said his office had found no evidence that people flagged by the administration were noncitizens and alleged that the subpoenas were intended to weaken his reelection campaign. DOJ said it does not confirm or comment on grand-jury subpoenas and did not address the motive allegation; the archive records Aguilar's claim as an allegation, not a finding.
- DHS said at least 2,000 names on an initial Nevada list of 16,000 were noncitizens. Reuters reported that Nevada officials said the 185 cases discussed with DHS matched citizens in state records and that the federal government had not supplied credible contrary evidence. Those conflicting on-record claims remain unresolved and do not establish a validated statewide count.

## SIGNIFICANCE

The administration has moved from investigations, prosecutions and short-deadline state demands to documented grand-jury subpoenas directed at a battleground state’s chief election office. The compulsory process is material, but the reviewed record still separates federal assertions and political-motive allegations from verified eligibility findings, charges arising from these subpoenas or an outcome-changing pattern.

## GOALPOST / RESPONSE

DOJ and the White House say the campaign protects election integrity; Nevada officials say federal lists are unsupported and the process burdens election administration. The subpoena text and returns, validated person-level findings, charging decisions, state corrections, judicial supervision, notice and process for affected voters, and measurable election effects are the tests.

## MAYBE / THEREFORE

Maybe the subpoenas uncover specific registration or voting violations requiring enforcement, or incomplete federal matching may burden a state office and wrongly flag citizens during an election. Therefore seven Nevada subpoenas and conflicting federal-state claims are documented; motive, list accuracy, unlawful votes and any broader pattern remain unproven.


## SOURCES

- [Reuters — noncitizen-voting prosecutions and constitutional challenges](https://www.reuters.com/legal/government/noncitizens-accused-illegal-us-voting-challenge-trumps-authority-prosecute-them-2026-09-15/) — independent court-filing review and 30-year federal prosecution analysis
- [Reuters — state errors and noncitizen voter registrations](https://www.reuters.com/legal/government/thirty-thousand-mistakes-how-red-blue-states-added-non-citizens-us-voter-rolls-2026-09-23/) — independent records review and nationwide data analysis
- [Reuters — noncitizen-voting prosecution surge](https://www.reuters.com/legal/government/trump-ramps-up-noncitizen-voting-prosecutions-ahead-midterms-2026-09-23/) — independent court-record review and named Justice Department statements
- [Associated Press — federal noncitizen-voting enforcement review](https://apnews.com/article/homeland-security-justice-department-midterms-noncitizen-voting-09b8391612fc87676267a254c55eaee8) — independent records review and reporting on charges, investigations and outcomes
- [Reuters — judge dismisses Cox case after finding federal noncitizen-voting law unconstitutional](https://www.reuters.com/world/us-judge-finds-law-criminalizing-noncitizen-voting-unconstitutional-2026-10-01/) — independent reporting quoting and describing district-court ruling and party positions
- [Reuters — DOJ gives California 48 hours to review alleged noncitizen-voter list](https://www.reuters.com/world/us-justice-department-threatens-california-over-alleged-noncitizen-voters-letter-2026-10-14/) — independent reporting based on a reviewed Justice Department letter and on-record DOJ confirmation
- [Reuters — seven DOJ subpoenas to Nevada election chief](https://www.reuters.com/legal/government/seven-subpoenas-engulf-nevada-election-chief-key-midterm-battle-2026-10-15/) — independent records review and on-record interviews

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
