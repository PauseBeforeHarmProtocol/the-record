# Noncitizen-voting prosecutions face first constitutional challenges as deportation stakes rise

**Entry ID:** NAT-2026-09-15-003
**Date:** September 15, 2026
**Checked:** 2026-09-15 12:00 PM EDT
**Evidence state:** Reuters review of federal court filings and a 30-year charging analysis with the Justice Department's arguments and a court-appointed expert report; prosecutions and constitutional questions remain pending
**Review state:** current-standard-reviewed

Reuters identified five pending challenges and only 129 charges under the 1996 statute in 30 years; charges and constitutional arguments remain unresolved.

## THE FACTS

- Reuters reviewed federal court filings and identified five defendants in separate Miami and Madison cases arguing for the first time that the 1996 Voting by Aliens statute is unconstitutional because states, rather than Congress, set voter qualifications. The motions seek dismissal before trials scheduled from October 5 through December 14; they are defense arguments, not merits rulings.
- The statute makes noncitizen voting in federal elections punishable by up to one year in prison and a $100,000 fine. The defendants are accused of violations, and the archive does not treat the accusations as convictions or independently determine intent.
- The Justice Department argues that Congress may protect federal election integrity and legislate on immigration, and compares the statute with federal laws against repeat voting and foreign-national campaign contributions. Former Solicitor General Paul Clement, appointed to advise one Miami court, concluded that Congress likely lacked authority but called the question not entirely clear-cut.
- Reuters found 129 people charged under the statute during its 30-year history and reported that the typical defendant was a lawful permanent resident with community ties who said they mistakenly believed they could vote. Before Trump's second term, many cases ended in guilty pleas and fines around $150; the administration's push to deport noncitizen voters materially increases potential consequences.
- A sixth defendant's dismissal motion was denied on September 9, and his trial began September 14. That ruling does not resolve the other five challenges, establish widespread noncitizen voting or determine the constitutionality of every application of the statute.

## SIGNIFICANCE

The cases pair a long-standing federal criminal law with a new enforcement consequence—deportation—and could clarify the division of election authority between Congress and the states before the midterms. Reuters' 30-year count also provides an empirical scale against which claims of widespread noncitizen voting can be tested.

## GOALPOST / RESPONSE

The administration says the federal statute validly protects election integrity and rests independently on Congress's immigration authority. The defendants say voter qualification is reserved to states. The tests are the complete district-court rulings, any convictions or dismissals, appellate review, charging and removal records, and verified incidence data—not allegations or campaign claims alone.

## MAYBE / THEREFORE

Maybe courts will uphold a narrow federal prohibition as election-integrity or immigration legislation, or they may find Congress exceeded its authority even though every state requires citizenship. Therefore the record establishes five pending constitutional challenges, one separate denial, 129 charges over 30 years and increased deportation exposure—not widespread illegal voting, guilt in the pending cases or a controlling constitutional ruling.


## SOURCES

- [Reuters — noncitizen-voting prosecutions and constitutional challenges](https://www.reuters.com/legal/government/noncitizens-accused-illegal-us-voting-challenge-trumps-authority-prosecute-them-2026-09-15/) — independent court-filing review and 30-year federal prosecution analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
