# Noncitizen-voting prosecutions face constitutional challenges as data traces registration errors

**Entry ID:** NAT-2026-09-15-003
**Date:** September 15–23, 2026
**Checked:** 2026-09-23 5:57 PM EDT
**Evidence state:** Reuters reviews of federal court filings, charging records, state official records, court records and local reporting, plus named Justice Department statements; charges, convictions, ballot incidence, causal claims and constitutional questions remain separately bounded or unresolved
**Review state:** current-standard-reviewed

Reuters identified five pending constitutional challenges, more than 30,000 mistaken registrations since 2000 and a September enforcement surge; charges, confirmed ballots and election effects remain distinct measures.

## THE FACTS

- Reuters reviewed federal court filings and identified five defendants in separate Miami and Madison cases arguing for the first time that the 1996 Voting by Aliens statute is unconstitutional because states, rather than Congress, set voter qualifications. The motions seek dismissal before trials scheduled from October 5 through December 14; they are defense arguments, not merits rulings.
- The statute makes noncitizen voting in federal elections punishable by up to one year in prison and a $100,000 fine. The defendants are accused of violations, and the archive does not treat the accusations as convictions or independently determine intent.
- The Justice Department argues that Congress may protect federal election integrity and legislate on immigration, and compares the statute with federal laws against repeat voting and foreign-national campaign contributions. Former Solicitor General Paul Clement, appointed to advise one Miami court, concluded that Congress likely lacked authority but called the question not entirely clear-cut.
- Reuters found 129 people charged under the statute during its 30-year history and reported that the typical defendant was a lawful permanent resident with community ties who said they mistakenly believed they could vote. Before Trump's second term, many cases ended in guilty pleas and fines around $150; the administration's push to deport noncitizen voters materially increases potential consequences.
- A sixth defendant's dismissal motion was denied on September 9, and his trial began September 14. That ruling does not resolve the other five challenges, establish widespread noncitizen voting or determine the constitutionality of every application of the statute.
- In a separate September 23 investigation, Reuters reviewed official state records, court records and local reporting and found that more than 30,000 self-declared noncitizens may have been mistakenly added to voter rolls since 2000 because of software or clerical errors across 12 states. Reuters described the nationwide tally as a first and said the numbers are inexact and subject to revision.
- Reuters could not determine how many of those people cast ballots. Experts told the outlet the registrations were too few relative to more than 170 million registered voters to affect national elections. New Jersey reported about 6,600 mistaken registrations; Iowa's initial list of more than 2,000 later shrank to 277, and state officials said 35 noncitizens cast counted ballots among more than 1.6 million voters in 2024.
- The reviewed cases pointed principally to state motor-voter software and processing failures rather than an organized scheme. One election expert said proof-of-citizenship rules would not prevent errors in which applicants correctly identified themselves as noncitizens but the system registered them anyway. The White House said the registrations showed elections had been compromised and cited 11 announced arrests since May; that response does not establish coordinated or outcome-changing voting.
- A separate Reuters review published September 23 found that federal prosecutors charged about 20 people under the Voting by Aliens law during September—about 13 percent of all prosecutions under that law since its 1996 enactment. A Justice Department spokesperson said 32 people had been charged in the prior four weeks with noncitizen voting and related offenses.
- Those September figures measure charges, not convictions, confirmed ballots or election effects. Acting Deputy Attorney General Trent McCotter said the cases refuted claims that noncitizen voting never occurs; the small number and unresolved cases do not by themselves establish widespread, coordinated or outcome-changing voting.

## SIGNIFICANCE

The September charging surge shows an abrupt expansion in enforcement of a rarely used federal law while constitutional challenges and potential deportation consequences remain pending. Reuters' separate records review supplies an inexact scale for registration errors and reinforces why registrations, charges, convictions, confirmed ballots and election effects must be measured separately.

## GOALPOST / RESPONSE

The administration says the statute protects election integrity and that the new cases disprove claims that noncitizen voting never occurs. Defendants challenge Congress's authority, while election officials and experts distinguish administrative errors and isolated cases from coordinated or outcome-changing voting. The tests are complete court rulings, case dispositions, validated state audits, confirmed ballots, registration-system fixes, removal records and measured election effects—not registration or charging totals alone.

## MAYBE / THEREFORE

Maybe the errors and prosecution surge reveal gaps that warrant targeted safeguards and enforcement, or the sparse and often administrative pattern may undermine claims of a coordinated, election-changing scheme. Therefore the record establishes five pending constitutional challenges, a September charging surge and a Reuters-verified but inexact tally of more than 30,000 mistaken registrations since 2000—not convictions in every new case, 30,000 illegal ballots, widespread coordinated voting, changed election outcomes or a final constitutional ruling.


## SOURCES

- [Reuters — noncitizen-voting prosecutions and constitutional challenges](https://www.reuters.com/legal/government/noncitizens-accused-illegal-us-voting-challenge-trumps-authority-prosecute-them-2026-09-15/) — independent court-filing review and 30-year federal prosecution analysis
- [Reuters — state errors and noncitizen voter registrations](https://www.reuters.com/legal/government/thirty-thousand-mistakes-how-red-blue-states-added-non-citizens-us-voter-rolls-2026-09-23/) — independent records review and nationwide data analysis
- [Reuters — noncitizen-voting prosecution surge](https://www.reuters.com/legal/government/trump-ramps-up-noncitizen-voting-prosecutions-ahead-midterms-2026-09-23/) — independent court-record review and named Justice Department statements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
