# Noncitizen-voting prosecutions face constitutional challenges as data traces registration errors

**Entry ID:** NAT-2026-09-15-003
**Date:** September 15–23, 2026
**Checked:** 2026-09-23 12:34 PM EDT
**Evidence state:** Reuters reviews of federal court filings, 30 years of prosecutions, state official records, court records and local reporting; charges, ballot incidence, causal claims and constitutional questions remain bounded or unresolved
**Review state:** current-standard-reviewed

Reuters identified five pending challenges and 129 charges in 30 years; a separate records review found more than 30,000 mistaken registrations since 2000, with actual voting and election impact not established.

## THE FACTS

- Reuters reviewed federal court filings and identified five defendants in separate Miami and Madison cases arguing for the first time that the 1996 Voting by Aliens statute is unconstitutional because states, rather than Congress, set voter qualifications. The motions seek dismissal before trials scheduled from October 5 through December 14; they are defense arguments, not merits rulings.
- The statute makes noncitizen voting in federal elections punishable by up to one year in prison and a $100,000 fine. The defendants are accused of violations, and the archive does not treat the accusations as convictions or independently determine intent.
- The Justice Department argues that Congress may protect federal election integrity and legislate on immigration, and compares the statute with federal laws against repeat voting and foreign-national campaign contributions. Former Solicitor General Paul Clement, appointed to advise one Miami court, concluded that Congress likely lacked authority but called the question not entirely clear-cut.
- Reuters found 129 people charged under the statute during its 30-year history and reported that the typical defendant was a lawful permanent resident with community ties who said they mistakenly believed they could vote. Before Trump's second term, many cases ended in guilty pleas and fines around $150; the administration's push to deport noncitizen voters materially increases potential consequences.
- A sixth defendant's dismissal motion was denied on September 9, and his trial began September 14. That ruling does not resolve the other five challenges, establish widespread noncitizen voting or determine the constitutionality of every application of the statute.
- In a separate September 23 investigation, Reuters reviewed official state records, court records and local reporting and found that more than 30,000 self-declared noncitizens may have been mistakenly added to voter rolls since 2000 because of software or clerical errors across 12 states. Reuters described the nationwide tally as a first and said the numbers are inexact and subject to revision.
- Reuters could not determine how many of those people cast ballots. Experts told the outlet the registrations were too few relative to more than 170 million registered voters to affect national elections. New Jersey reported about 6,600 mistaken registrations; Iowa's initial list of more than 2,000 later shrank to 277, and state officials said 35 noncitizens cast counted ballots among more than 1.6 million voters in 2024.
- The reviewed cases pointed principally to state motor-voter software and processing failures rather than an organized scheme. One election expert said proof-of-citizenship rules would not prevent errors in which applicants correctly identified themselves as noncitizens but the system registered them anyway. The White House said the registrations showed elections had been compromised and cited 11 announced arrests since May; that response does not establish coordinated or outcome-changing voting.

## SIGNIFICANCE

The cases pair a long-standing federal criminal law with a new enforcement consequence—deportation—and could clarify the division of election authority between Congress and the states before the midterms. Reuters' separate records review provides a nationwide but inexact scale for registration errors and shows why registrations, confirmed ballots, prosecutions and election effects must be measured separately. The reviewed evidence supports correcting administrative systems while testing, rather than presuming, claims of coordinated or outcome-changing voting.

## GOALPOST / RESPONSE

The administration says the federal statute validly protects election integrity and that the mistaken registrations show elections have been compromised. The defendants challenge Congress's authority, while election officials and experts distinguish administrative registration errors from coordinated or outcome-changing voting. The tests are complete court rulings, validated state audits, confirmed ballots and prosecutions, registration-system fixes, removal records and measured election effects—not registration totals or campaign claims alone.

## MAYBE / THEREFORE

Maybe the errors and prosecutions reveal gaps that warrant targeted safeguards, or their sparse, administrative pattern may undermine claims of a coordinated, election-changing scheme. Therefore the record establishes five pending constitutional challenges, 129 federal charges in 30 years and a Reuters-verified but inexact tally of more than 30,000 mistaken registrations since 2000—not widespread coordinated voting, 30,000 illegal ballots, changed election outcomes or a final constitutional ruling.


## SOURCES

- [Reuters — noncitizen-voting prosecutions and constitutional challenges](https://www.reuters.com/legal/government/noncitizens-accused-illegal-us-voting-challenge-trumps-authority-prosecute-them-2026-09-15/) — independent court-filing review and 30-year federal prosecution analysis
- [Reuters — state errors and noncitizen voter registrations](https://www.reuters.com/legal/government/thirty-thousand-mistakes-how-red-blue-states-added-non-citizens-us-voter-rolls-2026-09-23/) — independent records review and nationwide data analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
