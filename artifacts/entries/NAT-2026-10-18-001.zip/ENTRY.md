# Zelenskyy says U.S. restored missile-warning intelligence after interruption

**Entry ID:** NAT-2026-10-18-001
**Date:** October 18, 2026
**Checked:** 2026-10-18 12:02 PM EDT
**Evidence state:** Zelenskyy's direct televised statement as independently reported by Reuters and Associated Press; restoration reported by Ukraine, prior U.S. denial preserved, scope, duration, authorization and cause unresolved
**Review state:** current-standard-reviewed

Ukraine's president said intelligence sharing had been blocked and was later restored; Trump had said earlier that sharing continued, and no U.S. directive or operational record was located.

## THE FACTS

- Speaking on NBC's Meet the Press, Ukrainian President Volodymyr Zelenskyy said U.S.-Ukraine intelligence sharing had been interrupted and later “de-blocked” by the American side. Reuters and Associated Press independently reported his statement that the sharing now works; both accounts attribute the operational claim to Zelenskyy rather than to a published U.S. order.
- Reuters reported that Ukraine relies on U.S. intelligence to detect fast-moving Russian ballistic missiles. The reported restoration therefore concerns a concrete defensive function, but the reviewed sources did not establish the exact start and end times, systems, geographic coverage or whether other intelligence categories were affected.
- Trump had said earlier in the week that Washington was still sharing intelligence even as Ukrainian officials said some Russian strikes arrived without warning. No U.S. directive, activity log or on-record U.S. operational confirmation was located by the cutoff, so the archive records Zelenskyy's reported interruption-and-restoration account and the administration's conflicting description, not a proven full cutoff or an established cause.

## SIGNIFICANCE

Ballistic-missile launch warning can affect civilian alerts, air-defense response and force protection during an active war. A temporary loss and restoration would demonstrate consequential U.S. operational leverage over Ukraine, but the disagreement over whether sharing stopped makes scope, duration, authorization and classification central to accountability.

## GOALPOST / RESPONSE

Zelenskyy says the blocked sharing was restored and now works; Trump says sharing continued. Verification requires an on-record U.S. account or operational records identifying what data changed, when, under whose authority and whether warning performance was restored across the relevant systems. Further tests include subsequent Ukrainian warning performance and any congressional or inspector-general review.

## MAYBE / THEREFORE

Maybe the episode was a short, narrow interruption or a differently categorized technical restriction that each side described accurately from its perspective, rather than a complete intelligence cutoff. Therefore the archive records a reported restoration of missile-warning intelligence and the unresolved U.S.-Ukraine factual conflict—not that all intelligence stopped, that the White House ordered it, or that every affected capability has been fully restored.


## SOURCES

- [Reuters — Zelenskyy says U.S. restored intelligence sharing after a pause](https://www.reuters.com/legal/government/us-resumes-intelligence-sharing-with-ukraine-after-pause-zelenskiy-says-2026-10-18/) — independent reporting of an attributed Ukrainian presidential statement; U.S. action not independently confirmed
- [Associated Press — Zelenskyy says U.S.-Ukraine intelligence sharing resumed](https://apnews.com/article/russia-ukraine-war-energy-diesel-trump-f813d3725b8b5f23958a68a95729fd0d) — independent reporting of an attributed Ukrainian presidential statement and unresolved U.S. position

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
