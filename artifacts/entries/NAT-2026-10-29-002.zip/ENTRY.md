# Genomics-company import restrictions take effect under forced-labor law

**Entry ID:** NAT-2026-10-29-002
**Date:** October 29, 2026
**Checked:** 2026-10-29 12:01 PM EDT
**Evidence state:** DHS-authored distributed release plus Reuters; effective legal presumption, underlying allegations disputed; direct list and Federal Register original not inspected
**Review state:** current-standard-reviewed

Three listed companies face a rebuttable import presumption; government allegations and company denials remain distinct.

## THE FACTS

- DHS announced the addition of BGI Genomics, MGI Tech and Shenzhen BGI Technology to the UFLPA Entity List. Its distributed release specifies October 29 as the effective date for CBP’s rebuttable presumption against their goods; Reuters reported the October 28 announcement. This record preserves the announcement/effective-date distinction.
- DHS attributes the action to alleged involvement in Xinjiang genetic surveillance and forced-labor programs. These are agency determinations, not criminal convictions or independently established findings in this record.
- Reuters reported that MGI Tech and BGI Group denied forced-labor involvement and described U.S. business as limited. BGI Genomics did not immediately respond. No shipment-level detention, successful rebuttal or measured reduction in abuse is established here.

## SIGNIFICANCE

The listing changes market-access rules for named companies. Its practical reach depends on customs enforcement and supply-chain tracing, not simply the number listed.

## GOALPOST / RESPONSE

DHS says the restrictions enforce trade law and protect persecuted minorities and fair competition. Companies dispute the allegations; enforcement records and review proceedings can test the agency’s case.

## MAYBE / THEREFORE

Maybe the restrictions reduce exposure to coercive supply chains, or supply substitutions limit their effect. Therefore the legal presumption is documented, but guilt, business losses and human-rights improvements are not inferred.


## SOURCES

- [DHS — three genomics companies added to UFLPA list (distributed release)](https://www.einpresswire.com/article/953037021/under-president-trump-dhs-blocks-chinese-genomics-companies-linked-to-forced-labor) — government-authored release distributed by EIN; direct entity-list page access denied; announced October 28, effective October 29
- [Reuters — genomics import restrictions and company denials](https://www.reuters.com/world/china/us-bans-imports-three-chinese-genomics-companies-citing-forced-labor-2026-10-28/) — independent reporting; complete article body inspected

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
