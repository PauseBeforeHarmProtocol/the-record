# Trump reduces Bears Ears and Grand Staircase–Escalante by more than 90%

**Entry ID:** NAT-2026-07-18-003
**Date:** July 13, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** primary proclamations, official fact sheet, and independent reporting
**Review state:** current-standard-reviewed

The proclamations shrink the two Utah national monuments to 121,100 and 181,500 acres, respectively.

## THE FACTS

- President Trump signed proclamations reducing Bears Ears National Monument from roughly 1.36 million acres to 121,100 acres and Grand Staircase–Escalante from roughly 1.87 million acres to 181,500 acres.
- The White House says surrounding lands will become available for multiple-use management, including grazing, timber harvest, infrastructure, resource development, and motorized recreation.
- Bears Ears contains cultural and archaeological sites sacred to multiple Tribal nations. Environmental advocates announced plans to challenge the reductions in court.

## SIGNIFICANCE

The action again places presidential Antiquities Act authority, Tribal consultation, conservation, and extractive land use in direct conflict. Because earlier reductions were later reversed, the durability of the boundaries is likely to depend on litigation and future administrations.

## GOALPOST / RESPONSE

The administration calls the reductions “rightsizing” and argues the Antiquities Act requires the smallest area compatible with protecting specific objects. Opponents describe the same action as opening protected landscapes and culturally significant lands to development. The acreage change is not disputed; the legal and stewardship judgment is.

## MAYBE / THEREFORE

Maybe the reduced boundaries still protect the specific objects identified under the administration’s Antiquities Act interpretation while allowing lawful multiple use outside them. Therefore the acreage reduction is established, but its legality and conservation effect must be judged through litigation, Tribal consultation, subsequent leasing or development, and documented effects on cultural and natural resources.


## SOURCES

- [Reuters — reductions to two Utah national monuments](https://www.reuters.com/world/us/trump-slashes-size-two-utah-national-monuments-2026-07-13/) — independent reporting
- [White House fact sheet — Utah national monuments](https://www.whitehouse.gov/fact-sheets/2026/07/fact-sheet-president-donald-j-trump-modifies-two-national-monuments-restoring-sensible-land-management/) — official administration statement
- [Presidential proclamation — Bears Ears](https://www.whitehouse.gov/presidential-actions/2026/07/modifying-the-bears-ears-national-monument/) — primary official document
- [Presidential proclamation — Grand Staircase–Escalante](https://www.whitehouse.gov/presidential-actions/2026/07/modifying-the-grand-staircase-escalante-national-monument/) — primary official document

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
