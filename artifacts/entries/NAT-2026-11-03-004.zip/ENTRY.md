# Trump announces plan to end U.S. military aid to Israel after 2026

**Entry ID:** NAT-2026-11-03-004
**Date:** November 3, 2026
**Checked:** 2026-11-03 6:16 PM EST
**Evidence state:** On-record presidential announcement independently reported by AP, Reuters and ABC, with CRS context; no implementing instrument, Israeli confirmation or congressional funding action located
**Review state:** current-standard-reviewed

Trump said grants would end while weapons sales continue; no implementing instrument, Israeli confirmation or congressional funding action was located by cutoff.

## THE FACTS

- In a November 3 Fox & Friends interview, President Trump said the United States would stop providing roughly $4 billion a year in military aid to Israel after 2026 and would continue selling weapons. Associated Press, Reuters and ABC News independently reported the on-record statement.
- The statement is a presidential policy announcement, not an implemented cutoff. No executive instrument, State Department notice, budget amendment or congressional appropriations action carrying it out was located by cutoff.
- The current ten-year memorandum of understanding covers fiscal years 2019 through 2028 and contemplates $38 billion in assistance—$33 billion in Foreign Military Financing and $5 billion for missile defense—subject to congressional appropriations. The announcement therefore conflicts in timing with an existing framework that continues beyond 2026.
- Associated Press reported that Congress has a major role and that weapons already approved or in the delivery pipeline would not vanish with a future grant cutoff. Ending new grant assistance would not be the same as ending arms sales or completing all existing deliveries.
- Trump said he and Prime Minister Benjamin Netanyahu had agreed on the change and framed it as Israel becoming independent. AP reported no immediate Netanyahu comment; the archive treats Trump's description as his claim, not independently confirmed bilateral agreement.
- The interview occurred before the prior 1:13 PM EST source boundary, but AP and ABC confirmation and source inspection entered this run's active review window. Both the statement time and later verification stage are preserved rather than backdating implementation.

## SIGNIFICANCE

Ending annual grant military assistance would be a major change in the U.S.–Israel security relationship and in congressional budgeting. The announcement creates policy and planning risk, but its legal, fiscal and operational effect remains contingent on formal executive proposals, Congress and existing agreements and deliveries.

## GOALPOST / RESPONSE

Trump says Israel can become independent while buying U.S. weapons and says Netanyahu agreed. The tests are an official bilateral statement, the fiscal 2027 and 2028 budget and appropriations process, any amended memorandum, Foreign Military Financing obligations and actual deliveries—not the interview announcement alone.

## MAYBE / THEREFORE

Maybe the statement begins a negotiated transition from grants to sales, or Congress and the existing memorandum may preserve some assistance beyond 2026. Therefore a consequential presidential policy announcement is verified; a completed cutoff, binding bilateral agreement, canceled appropriation or ended weapons relationship is not.


## SOURCES

- [AP — Trump says U.S. military aid to Israel will end](https://apnews.com/article/trump-israel-military-aid-hardware-5cad93330300b2d45a9665d5eccb2ab2) — independent reporting on the presidential announcement, existing aid agreement and congressional role
- [Reuters — Trump says U.S. funding to Israel will stop at end of 2026](https://www.marketscreener.com/news/trump-says-us-will-stop-4-billion-in-funding-to-israel-at-end-of-2026-ce785fdedb80fe26) — independent reporting on the on-record presidential announcement
- [ABC News — Trump says Israel military aid will end this year](https://abcnews.com/Politics/trump-israel-aid-end-year-citing-political-reasons/story?id=137809564) — independent reporting and interview context
- [Congressional Research Service — U.S. foreign aid to Israel](https://www.congress.gov/crs_external_products/RL/PDF/RL33222/RL33222.51.pdf?pubDate=20250907) — primary congressional research context on the FY2019–FY2028 memorandum and appropriations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
