# Fannie Mae and Freddie Mac directed to approve all lenders for VantageScore

**Entry ID:** NAT-2026-09-03-008
**Date:** April 22–September 3, 2026
**Checked:** 2026-09-03 11:59 PM EDT
**Evidence state:** primary FHFA implementation page and Pulte directive plus independent Reuters reporting; approval expansion ordered, lender adoption and mortgage-market effects unmeasured
**Review state:** current-standard-reviewed

Federal Housing director Bill Pulte expanded the interim VantageScore 4.0 rollout beyond its first 50 lenders; actual lender adoption and mortgage effects remain unmeasured.

## THE FACTS

- Federal Housing director Bill Pulte said September 3 that Fannie Mae and Freddie Mac's initial VantageScore rollout had 50 lenders delivering loans and directed the enterprises, effective immediately, to approve all lenders to use VantageScore.
- FHFA's April implementation page says approved lenders may choose Classic FICO or VantageScore 4.0 for individual loans during an interim phase. Before the September directive, lenders not yet approved for VantageScore were told to continue using Classic FICO.
- VantageScore is jointly owned by Equifax, Experian and TransUnion. Reuters reported that the administration describes the expansion as competition for FICO and part of an effort to reduce homebuying costs.
- Pulte separately said the government was seriously considering bi-merge credit reporting and stronger solutions. That statement is prospective: no new bi-merge rule or final technical standard was identified by cutoff.
- The directive expands approval eligibility; it does not establish that every lender is technically ready, that every loan will use VantageScore, or that borrower access, prices, approval rates or default performance have changed.

## SIGNIFICANCE

Fannie Mae and Freddie Mac shape a large share of U.S. mortgage underwriting. Opening the alternative score to all lenders could change competition, borrower evaluation and implementation costs, but the practical effects depend on voluntary lender use, enterprise controls and loan performance.

## GOALPOST / RESPONSE

The administration says broader model competition can lower costs and improve risk assessment while preserving safety and soundness. Lender approvals and adoption, score distribution, pricing, approval and denial rates, fair-lending analysis, defaults, repurchases, implementation costs and any final bi-merge decision are the tests.

## MAYBE / THEREFORE

Maybe broader VantageScore access will recognize additional payment histories and reduce dependence on one model, or it may shift market power without improving affordability or risk prediction. Therefore the record confirms an immediately announced direction to approve all lenders for the interim option—not universal use, completed technical implementation or measured consumer benefit.


## SOURCES

- [FHFA — credit-score modernization and interim VantageScore phase](https://www.fhfa.gov/policy/credit-scores) — primary agency background describing approved-model policy, lender approval limits and implementation status
- [Bill Pulte — directive to approve all lenders for VantageScore](https://x.com/pulte/status/2095672962422562893) — primary statement announcing the immediately effective direction to Fannie Mae and Freddie Mac
- [Reuters — Fannie Mae and Freddie Mac directed to approve VantageScore for all lenders](https://www.reuters.com/business/us-official-directs-fannie-mae-freddie-mac-approve-vantagescore-all-lenders-2026-09-04/) — independent reporting on the directive, initial 50-lender rollout and administration rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
