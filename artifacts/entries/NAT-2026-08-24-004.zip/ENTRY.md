# United States delists Syria and waives remaining chemical-weapons sanctions

**Entry ID:** NAT-2026-08-24-004
**Date:** August 24–September 16, 2026
**Checked:** 2026-09-16 5:59 AM EDT
**Evidence state:** formal State Department and Federal Register actions, plus independent Reuters reporting on the earlier delisting; legal restrictions were removed, while transaction-level implementation and outcomes remain unestablished
**Review state:** current-standard-reviewed

A new national-security waiver removes the remaining arms-sales and military-financing restrictions, but does not itself approve a sale, financing award or transfer.

## THE FACTS

- The State Department formally removed Syria from the list of state sponsors of terrorism after the 45-day congressional review triggered by Trump's July 8 notification. The administration also removed the Nusrah Front designation as a Specially Designated Global Terrorist organization; Cuba, Iran and North Korea remained on the state-sponsor list.
- The state-sponsor designation had carried restrictions on U.S. foreign assistance, defense exports and sales, dual-use items and certain financial transactions. Broader Syria sanctions had already been terminated in July 2025, while targeted sanctions on designated individuals and groups remained separate.
- A Federal Register notice published September 16 says the President had waived all Syria sanctions under the Chemical and Biological Weapons Control and Warfare Elimination Act in June 2025 except restrictions on arms sales and arms-sales financing. On August 20, 2026, the Under Secretary of State determined that waiving those remaining restrictions was essential to U.S. national security.
- The September 16 notice makes the additional waiver effective and covers the statutory termination of arms-export licenses and sales plus foreign military financing for Syria. The determination does not itself approve a particular sale, issue an export license, obligate financing, execute a contract or document a delivery.
- Targeted sanctions, export-control licensing decisions and other legal authorities remain distinct. No public transaction-level implementation record or independently measured reform outcome accompanied the waiver by cutoff.

## SIGNIFICANCE

The combined delisting and additional waiver remove major legal and compliance barriers to aid, finance, investment and possible future security transactions with Syria. The newest action expands the available policy channel into arms sales and military financing, while leaving every specific transaction and its conditions for separate review.

## GOALPOST / RESPONSE

The administration says engagement recognizes positive steps by President Ahmed al-Sharaa's government and that waiving the remaining restrictions is essential to U.S. national security. Specific licenses, congressional notifications, financing obligations, contracts, deliveries, end-use controls, counterterrorism cooperation, rights conditions and targeted enforcement are the tests.

## MAYBE / THEREFORE

Maybe the expanded waiver supports stabilization, reconstruction and security cooperation while targeted controls preserve leverage, or it may expose new diversion, human-rights and regional risks. Therefore the record establishes an effective legal waiver and earlier delisting—not an approved arms transfer, disbursed military financing, completed reform or proof that future transactions will satisfy U.S. interests.


## SOURCES

- [Reuters — U.S. formally removes Syria from terrorism-sponsor list](https://www.reuters.com/world/middle-east/us-removes-syrias-designation-state-sponsor-terrorism-2026-08-24/) — independent reporting on a formal State Department and Treasury action
- [Federal Register — waiver of remaining Syria chemical-weapons sanctions](https://www.federalregister.gov/documents/2026/09/16/2026-18918/waiver-of-sanctions-on-syria-under-the-chemical-and-biological-weapons-control-and-warfare) — primary sanctions-waiver determination

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
