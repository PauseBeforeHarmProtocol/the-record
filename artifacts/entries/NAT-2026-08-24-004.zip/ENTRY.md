# United States formally removes Syria from the state-sponsors-of-terrorism list

**Entry ID:** NAT-2026-08-24-004
**Date:** August 24, 2026
**Checked:** 2026-08-24 5:58 PM EDT
**Evidence state:** formal State Department and Treasury action after congressional review, independently reported by Reuters

The delisting took effect after a 45-day congressional review, removing a major legal and compliance barrier to assistance, finance, and investment.

## THE FACTS

- The State Department formally removed Syria from the list of state sponsors of terrorism after the 45-day congressional review triggered by Trump's July 8 notification.
- The administration also removed the Nusrah Front designation as a Specially Designated Global Terrorist organization. Cuba, Iran, and North Korea remained on the state-sponsor list.
- The state-sponsor designation had carried restrictions on U.S. foreign assistance, defense exports and sales, dual-use items, and certain financial transactions. Broader Syria sanctions had already been terminated in July 2025, while targeted sanctions on designated individuals and groups remained separate.

## SIGNIFICANCE

The formal delisting removes a distinct legal and compliance deterrent that persisted after broader Syria sanctions ended, potentially expanding banking, investment, aid, and reconstruction activity. It also transfers more of the accountability burden to targeted sanctions and continuing monitoring of Syria's conduct.

## GOALPOST / RESPONSE

Secretary of State Marco Rubio said the action recognized positive steps and commitments by President Ahmed al-Sharaa's government to distance Syria from international terrorism. Syrian officials say the designation was the last major obstacle to investment. Future counterterrorism cooperation, targeted enforcement, rights conditions, and financial flows will test those claims.


## SOURCES

- [Reuters — U.S. formally removes Syria from terrorism-sponsor list](https://www.reuters.com/world/middle-east/us-removes-syrias-designation-state-sponsor-terrorism-2026-08-24/) — independent reporting on a formal State Department and Treasury action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
