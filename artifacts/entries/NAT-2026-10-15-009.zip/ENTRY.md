# Fifth Circuit vacates FCC contribution factor over USAC authority

**Entry ID:** NAT-2026-10-15-009
**Date:** October 15, 2026
**Checked:** 2026-10-16 5:57 AM EDT
**Evidence state:** filed Fifth Circuit opinion via Justia plus independent Reuters reporting; ruling issued, remedy vacates the fourth-quarter 2025 factor and remands, effective date and subsequent review unresolved
**Review state:** current-standard-reviewed

The court held that Congress did not specifically authorize the FCC to create USAC, vacated the fourth-quarter 2025 contribution factor and remanded. The FCC says it is reviewing options; the ruling does not take immediate effect.

## THE FACTS

- In Consumers' Research v. FCC, No. 25-60535, the Fifth Circuit held that the FCC violated the Government Corporation Control Act because Congress did not specifically authorize it to establish the Universal Service Administrative Company.
- The court granted the petition for review, vacated the fourth-quarter 2025 universal-service contribution factor and remanded to the FCC. That stated remedy is narrower and more precise than treating every Universal Service Fund program as immediately terminated.
- Reuters reported that the fund draws about $9 billion annually and supports low-income and rural consumers, tribal lands, schools, libraries and rural health facilities. Those scale and beneficiary descriptions explain the stakes but do not alter the judgment's operative language.
- The FCC said it was considering all available options and that the order would not take effect for at least two months. Further agency, en banc, congressional or Supreme Court action remained unresolved at cutoff.

## SIGNIFICANCE

The ruling creates a major statutory-authority problem for the private corporation that calculates contributions and administers a nationwide communications subsidy system. Its practical reach depends on the mandate, further review and whether the FCC or Congress supplies a lawful replacement structure.

## GOALPOST / RESPONSE

The petitioners' position is that an unauthorized corporation cannot set mandatory contribution inputs; the FCC emphasizes the decision's delayed effect and is reviewing options. The mandate, rehearing or stay proceedings, any Supreme Court review, congressional authorization, replacement administration and continuity of supported services are the tests.

## MAYBE / THEREFORE

Maybe the ruling forces a prompt statutory or administrative fix without service interruption, or it may destabilize contribution collection and support programs if no valid structure is established. Therefore the court vacated one quarterly contribution factor and rejected the FCC's authority to create USAC; it did not order an immediate nationwide shutdown of every subsidized service.


## SOURCES

- [Fifth Circuit — Consumers' Research v. FCC opinion](https://law.justia.com/cases/federal/appellate-courts/ca5/25-60535/25-60535-2026-10-15.html) — primary appellate opinion mirror; No. 25-60535
- [Reuters — Fifth Circuit ruling on FCC universal-service administrator](https://www.reuters.com/legal/government/us-appeals-court-invalidates-federal-9-billion-telecom-subsidy-fund-2026-10-16/) — independent reporting on ruling, program scale and FCC response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
