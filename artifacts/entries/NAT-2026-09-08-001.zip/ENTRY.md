# BLM proposes 60-day pathway for qualifying Alaska petroleum sites

**Entry ID:** NAT-2026-09-08-001
**Date:** September 8, 2026
**Checked:** 2026-09-08 12:01 AM EDT
**Evidence state:** primary BLM proposed rule and Federal Register publication; streamlined criteria and comment schedule documented, while the programmatic EIS, final rule, permits and outcomes remain pending
**Review state:** current-standard-reviewed

The proposal would use predefined project and mitigation criteria to accelerate approvals in the National Petroleum Reserve; it is not a permit or final rule.

## THE FACTS

- The Bureau of Land Management proposed a rule creating a streamlined decision process for qualifying oil and gas production sites and associated rights-of-way in the National Petroleum Reserve in Alaska; comments are due November 9.
- A project would generally need to be within 25 miles of permanent oil-and-gas infrastructure, use specified common components and remain within the design envelope and mitigation measures analyzed in a programmatic environmental impact statement still under development.
- For a complete qualifying application, BLM proposes to issue an approval, conditional approval or denial within 60 days and generally conduct no additional project-level National Environmental Policy Act analysis beyond the programmatic review.
- The proposal covers pads, roads, wells, pipelines and related infrastructure while retaining listed conditions for subsistence consultation, wildlife, spill prevention, construction and operations.
- BLM says standardized review could reduce delay and cost and increase production and revenue. The agency also acknowledges that more development or fewer design features could increase disturbance, subsistence-resource and public-safety costs; no permits, production, revenue or environmental effects result from the proposal itself.

## SIGNIFICANCE

A fixed 60-day pathway and reliance on programmatic review could materially change the speed and depth of project-level federal scrutiny across a major Arctic petroleum reserve. Whether predefined safeguards adequately address site-specific risks is unresolved.

## GOALPOST / RESPONSE

BLM says predefined criteria can make permitting predictable and efficient while preserving mitigation and consultation. A completed environmental impact statement, final rule, eligible applications, decision times, additional review, permits, production, revenue, spills, wildlife and subsistence outcomes are the tests.

## MAYBE / THEREFORE

Maybe repetitive projects near existing infrastructure can be responsibly reviewed once at a programmatic level, or site-specific Arctic and subsistence risks may not fit a standardized envelope. Therefore the record establishes a proposed 60-day permitting pathway—not a final process, approved production site, waived environmental law or measured benefit or harm.


## SOURCES

- [Federal Register — National Petroleum Reserve in Alaska Production Site Development](https://www.federalregister.gov/documents/2026/09/08/2026-18261/national-petroleum-reserve-in-alaska-production-site-development) — primary proposed rule, RIN 1004-AF57 and docket BLM-2026-0133

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
