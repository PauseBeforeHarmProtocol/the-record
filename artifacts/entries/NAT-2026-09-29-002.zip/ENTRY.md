# Trump orders federal mosquito and tick reduction campaign in Washington

**Entry ID:** NAT-2026-09-29-002
**Date:** September 29, 2026
**Checked:** 2026-09-29 5:56 PM EDT
**Evidence state:** signed executive order; campaign, targets and agency deadlines ordered, appropriations, product approvals, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The signed order sets 2028 population-reduction targets and directs regulatory and research actions; the targets are goals, not measured results.

## THE FACTS

- President Trump signed an executive order directing Interior, Agriculture, EPA and GSA, in coordination with HHS, to develop and implement a Washington, D.C., campaign against invasive mosquitoes and ticks within 60 days.
- The order sets goals of reducing invasive mosquito populations by 90% and tick populations by 50% on covered federal lands by 2028. It calls for habitat remediation, host-reservoir control, advanced technologies and consultation with the District of Columbia; the percentages are targets, not achieved or independently measured reductions.
- EPA must develop a regulatory framework within 60 days for sterile-insect, genetic and bacteria-based technologies and expedite review of products found safe and effective. HHS and USDA must pursue prizes and research within 90 days for diagnostics, prophylactics, therapeutics and nonchemical controls, including exploration of an alpha-gal treatment agenda and relevant labeling.
- Implementation is subject to law and available appropriations. The order does not itself approve a pesticide or genetic product, appropriate new money, complete environmental review or establish health and ecological outcomes.

## SIGNIFICANCE

The order creates a multi-agency vector-control program with quantitative federal-land targets and directs faster regulatory and research pathways. Its public-health and environmental value depends on appropriations, product review, surveillance and measured outcomes.

## GOALPOST / RESPONSE

The administration says coordinated habitat work and new technologies can reduce disease-carrying pests while expanding nonchemical options. Published baselines, environmental and safety reviews, registered products, appropriations, vector counts, disease incidence and unintended ecological effects are the tests.

## MAYBE / THEREFORE

Maybe coordinated federal action and new tools materially reduce mosquito- and tick-borne risk, or aggressive targets may outpace funding, evidence and environmental safeguards. Therefore the record establishes an ordered campaign and regulatory agenda—not approved technologies, achieved population reductions or measured health benefits.


## SOURCES

- [White House — Eliminating Disease-Carrying Pests and Restoring Enjoyment of the Great Outdoors](https://www.whitehouse.gov/presidential-actions/2026/09/eliminating-disease-carrying-pests-and-restoring-enjoyment-of-the-great-outdoors/) — signed presidential executive order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
