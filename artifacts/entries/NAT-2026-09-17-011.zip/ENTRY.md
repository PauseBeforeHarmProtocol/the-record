# DHS extends nationwide mass-influx finding for 180 days

**Entry ID:** NAT-2026-09-17-011
**Date:** September 17, 2026
**Checked:** 2026-09-21 12:01 PM EDT
**Evidence state:** complete Federal Register notice and cited statutory mechanism; finding effective and nationwide assistance requested, participation, operations and outcomes unresolved
**Review state:** current-standard-reviewed

The effective finding requests assistance from state and local governments in all 50 states and preserves authority to authorize consenting officers to perform immigration duties.

## THE FACTS

- The Homeland Security secretary extended for 180 days the January 2025 finding that an actual or imminent mass influx of migrants is arriving at the southern border. The prior extension ran through September 17, 2026; the new notice says it is effective immediately and can end earlier if the secretary publishes a changed-circumstances finding.
- The finding requests assistance from state and local governments in all 50 states. Under 8 U.S.C. 1103(a)(10) and the cited regulations, the secretary may authorize state or local officers, with their superiors' consent, to perform immigration-officer duties during a qualifying mass influx; the notice does not itself identify participating jurisdictions or prove that additional officers were deputized.
- DHS cites weekly southern-border encounters, an 83% ICE detention-facility occupancy rate as of August 12, court limits on direct repatriation under the 2025 invasion proclamation, interior arrests and agency-reported criminality and assaults. Those figures and causal interpretations are the department's stated findings; the notice does not independently adjudicate individual guilt or establish how many state or local officers will assist.
- The document was filed September 18 and published September 21 after the prior period ended. This record restores the operative continuation as a disclosed prior-window omission; it does not infer new arrests, detentions, removals, spending or public-safety outcomes from the authority alone.

## SIGNIFICANCE

The extension preserves an emergency-style nationwide request and a legal path for state and local participation in federal immigration enforcement for another 180 days. Its practical reach depends on consent, authorizations and later operations rather than the finding alone.

## GOALPOST / RESPONSE

DHS says border, detention and public-safety conditions require continued state and local assistance even while encounter levels are lower than in prior years. Participating jurisdictions, written authorizations, trained officers, deployments, arrests and removals, detention capacity, encounter data, costs, legal challenges and rights outcomes are the tests.

## MAYBE / THEREFORE

Maybe the extension supplies useful surge capacity and coordination, or broad nationwide authority may produce limited operational benefit, uneven participation or legal and civil-rights disputes. Therefore DHS continued the finding and requested assistance—not that every jurisdiction consented, new officers were deputized or claimed safety and enforcement benefits were measured.


## SOURCES

- [Federal Register — 180-day extension of mass-influx finding](https://www.federalregister.gov/documents/2026/09/21/2026-19253/finding-of-mass-influx-of-aliens) — complete primary operative finding and nationwide assistance request

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
