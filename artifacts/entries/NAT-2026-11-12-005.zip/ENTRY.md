# Senators open inquiry into whether Kennedy misled Congress about Samoa vaccine trip

**Entry ID:** NAT-2026-11-12-005
**Date:** November 12, 2026
**Checked:** 2026-11-12 12:11 PM EST
**Evidence state:** Associated Press reporting of the formal inquiry and HHS response plus AP/Guardian document-based reporting; inquiry opened and testimony-document conflict reported, with intent, materiality, influence and legal outcome unresolved
**Review state:** current-standard-reviewed

Sens. Ron Wyden and Angela Alsobrooks requested records from Children's Health Defense after documents contradicted Kennedy's confirmation-hearing description of his 2019 trip.

## THE FACTS

- Associated Press reported on November 12 that Senators Ron Wyden and Angela Alsobrooks opened an investigation into whether Health and Human Services Secretary Robert F. Kennedy Jr. misled Congress about his 2019 Samoa trip. Their November 11 letter to Children's Health Defense requested trip, campaign, confirmation and federal-contact records by December 4. This is a formal congressional inquiry and document request, not a criminal referral, subpoena, charge or finding that Kennedy lied.
- During his 2025 confirmation hearings, Kennedy said the Samoa visit had nothing to do with vaccines. AP and The Guardian previously obtained a January 2019 letter on Children's Health Defense letterhead in which Kennedy proposed a detailed assessment of what happened with Samoa's MMR vaccines and repeatedly discussed vaccines or vaccination. The documents create a specific factual conflict with his testimony; they do not by themselves establish criminal intent, materiality or causation of Samoa's later measles outbreak.
- HHS said the visit was unrelated to vaccines and called allegations that Kennedy lied false and defamatory. Kennedy was not under oath at the hearings; AP noted that knowingly making a material false statement to Congress can still be a crime, but no Justice Department charge or adjudication was reported by cutoff.
- The senators also requested communications between Children's Health Defense and federal officials since Trump's second term began. The inquiry may test whether Kennedy's prior organization had undisclosed access or influence, but the request itself establishes no such communication, conflict or policy effect.

## SIGNIFICANCE

The inquiry turns a documented contradiction involving the sitting health secretary into formal congressional oversight and may test both confirmation candor and later contacts with a former advocacy organization. Its significance depends on produced records and findings, not the lawmakers' accusation alone.

## GOALPOST / RESPONSE

HHS says the trip was unrelated to vaccines and denies that Kennedy lied. The tests are Children's Health Defense's production, authentic contemporaneous records, complete hearing context, evidence of intent and materiality, any committee findings or referral, a Justice Department decision and documented post-confirmation contacts or policy effects.

## MAYBE / THEREFORE

Maybe fuller records will support Kennedy's distinction between the trip's purpose and vaccine-related discussions, or they may show he materially mischaracterized the visit to secure confirmation. Therefore the archive records an opened Senate inquiry and a document-based contradiction—not a criminal finding, proven intent, causal responsibility for Samoa's outbreak or established improper influence at HHS.


## SOURCES

- [Associated Press — senators open inquiry into Kennedy Samoa testimony](https://apnews.com/article/e4b97becad6d2951d9e84ea584979c41) — independent reporting on the formal inquiry, document request and HHS response
- [The Guardian — documents contradict Kennedy account of Samoa trip](https://www.theguardian.com/us-news/2026/aug/27/rfk-jr-senate-confirmation-hearing-testimony-vaccines) — independent document-based reporting and HHS response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
