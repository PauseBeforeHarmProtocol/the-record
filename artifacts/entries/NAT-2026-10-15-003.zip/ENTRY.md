# DOJ sues St. Paul and Portland over federal-officer mask and identification rules

**Entry ID:** NAT-2026-10-15-003
**Date:** October 15, 2026
**Checked:** 2026-10-15 5:58 PM EDT
**Evidence state:** DOJ litigation announcement, filed Portland complaint and independent St. Paul and Portland reporting; filings and requested relief verified, merits and factual allegations unadjudicated
**Review state:** current-standard-reviewed

Two filed complaints extend DOJ's national Supremacy Clause campaign against local rules governing federal officers; the constitutional claims and requested injunctions remain unadjudicated.

## THE FACTS

- The Justice Department filed separate federal complaints against St. Paul, Minnesota, and Portland, Oregon, challenging local rules that restrict face coverings and prescribe identification for federal law-enforcement officers.
- DOJ alleges the ordinances directly regulate federal operations in violation of the Supremacy Clause and intergovernmental-immunity principles. The filed Portland complaint says federal agencies need operational discretion over masks and identifiers and asks the court to declare the provisions invalid and block enforcement; those are government allegations and requested remedies, not judicial findings.
- Independent local reports described St. Paul's criminal penalties and Portland's civil and administrative enforcement structure, along with exceptions in the local rules. Both cities' legal and public-accountability rationales remain part of the dispute; neither complaint established that every application is invalid.
- DOJ said the filings follow the attorney general's direction to identify state and local measures that impede federal operations and are part of a wider series of suits. The department says masks and flexible identification protect officers from doxxing, harassment and operational compromise; local advocates say visible identification protects the public from unaccountable enforcement.

## SIGNIFICANCE

The two complaints extend a coordinated federal litigation strategy that seeks to preempt local accountability rules for federal officers across multiple jurisdictions. The filings are material national enforcement policy, but they do not resolve the constitutional boundary or the practical safety and accountability tradeoff.

## GOALPOST / RESPONSE

DOJ says uniform federal control protects officers and operations; the challenged cities enacted visibility rules to make officers identifiable and accountable. Docketed answers, factual evidence on threats and misidentification, preliminary or final injunctions, appellate rulings, ordinance revisions and measurable safety and complaint outcomes are the tests.

## MAYBE / THEREFORE

Maybe local rules unlawfully interfere with sensitive federal work and expose officers, or categorical federal discretion may weaken public ability to identify and challenge official conduct. Therefore two complaints and a broader DOJ litigation program are documented; constitutional validity, enforcement scope and real-world effects remain unresolved.


## SOURCES

- [Justice Department — St. Paul and Portland federal-officer mask and ID complaints](https://www.justice.gov/opa/pr/justice-department-files-complaints-against-cities-st-paul-and-portland-challenging-mask-ban) — primary litigation announcement
- [United States v. City of Portland — complaint](https://www.justice.gov/opa/media/1466281/dl) — primary filed complaint
- [Valley News Live — DOJ sues St. Paul over officer mask and ID ordinances](https://www.valleynewslive.com/2026/10/15/doj-sues-st-paul-over-ordinances-federal-officer-face-coverings-identification/) — independent local litigation reporting
- [KPTV — DOJ sues Portland over federal-officer mask rules](https://www.kptv.com/2026/10/15/doj-sues-portland-over-mask-rules-federal-officers/) — independent local litigation reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
