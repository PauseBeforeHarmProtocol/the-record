# NRC lets Palisades small-reactor project build permanent excavation walls early

**Entry ID:** NAT-2026-08-28-002
**Date:** August 28, 2026
**Checked:** 2026-08-28 6:03 AM EDT
**Evidence state:** NRC Federal Register notice and attached exemption; narrow site-work exemption issued August 28, limited work authorization and construction permit unresolved
**Review state:** current-standard-reviewed

The exemption allows specified retaining walls before a limited work authorization but does not approve either reactor or commit NRC to later permits.

## THE FACTS

- The Nuclear Regulatory Commission issued Holtec an exemption allowing permanent support-of-excavation walls for proposed Pioneer Units 1 and 2 at Michigan's Palisades Energy Center before NRC issues a limited work authorization or construction permit. The walls may include diaphragm, soil-mix, and perimeter cutoff structures used to stabilize deep excavations and manage groundwater.
- The exemption lets the walls remain buried after construction even though they would serve no function in the completed SMR-300 plant. NRC says they will remain structurally isolated from safety-related structures and that Holtec must preserve geologic mapping and other information needed for later licensing review.
- NRC found the limited exemption authorized by law, consistent with security, and not an undue safety or environmental risk. It cited excavation safety, avoidance of delay costs, and the ability to preserve later alternatives and licensing review.
- NRC expressly says the exemption is not a commitment to grant the still-pending limited work authorization or a construction permit. Holtec proceeds at its own risk, and part two of its phased construction-permit application had not yet been submitted.

## SIGNIFICANCE

The order permits permanent site work to begin ahead of the main federal construction authorization for a proposed two-unit advanced-reactor project. It can reduce schedule risk for the developer while preserving that NRC has not approved reactor construction or operation.

## GOALPOST / RESPONSE

NRC says the narrow exemption protects excavation safety, avoids costly delay, and leaves its later safety and environmental judgments open. The central accountability question is whether early permanent work compromises alternatives or creates practical pressure for approval despite the formal disclaimer. The limited-work decision, full construction application, environmental review, inspections, costs, and final licensing outcome are the tests.

## MAYBE / THEREFORE

Maybe separating excavation support from reactor authorization is a sensible sequencing measure, or sunk costs may make later alternatives harder in practice even if legally preserved. Therefore the record reports authorization for specified permanent retaining walls—not approval to construct, fuel, or operate the Pioneer reactors.


## SOURCES

- [NRC — Palisades Pioneer Units 1 and 2 excavation-wall exemption](https://www.federalregister.gov/documents/2026/08/28/2026-17626/smr-llc-palisades-smr-llc-pioneer-units-1-and-2-exemption) — primary federal nuclear-licensing exemption and attached findings

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
