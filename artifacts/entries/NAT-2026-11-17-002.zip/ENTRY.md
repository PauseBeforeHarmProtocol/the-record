# U.S. and Thailand sign negotiating statement after substantial conclusion of trade talks

**Entry ID:** NAT-2026-11-17-002
**Date:** November 17, 2026
**Checked:** 2026-11-17 12:05 PM EST
**Evidence state:** signed White House and Thai government joint-statement records plus independent Reuters reporting; negotiating milestone completed, final reciprocal-trade agreement not yet signed or in force
**Review state:** current-standard-reviewed

The leaders signed a joint statement confirming substantial conclusion of reciprocal-trade negotiations, while the final agreement, legal drafting, signature, entry into force and any tariff implementation remain pending.

## THE FACTS

- President Donald Trump and Thai Prime Minister Anutin Charnvirakul signed a joint statement confirming that the United States and Thailand had substantially concluded negotiations on an Agreement on Reciprocal Trade.
- The joint statement says both governments will complete their internal procedures and prepare final agreement text for signature and entry into force. It therefore records a signed negotiating milestone, not a signed or implemented final ART.
- The projected terms include Thailand eliminating tariffs on U.S. exports and removing specified non-tariff barriers affecting vehicles, medical devices, pharmaceuticals, ethanol and poultry; Reuters reported an estimated $2.6 billion in additional Thai purchases of U.S. agricultural products.
- The Thai government said legal drafting and domestic procedures still remain and that the joint statement itself does not alter current tariffs or impose an interim implementation deadline.
- Both leaders described the formal agreement as forthcoming. No reviewed instrument established its final text, signature date, entry-into-force date, tariff schedule or measured trade effects by cutoff.

## SIGNIFICANCE

The signed statement advances bilateral negotiations from a scheduled announcement to an official, jointly documented milestone with described sector commitments. Its practical effect remains contingent because the final agreement and implementation instruments do not yet exist in the reviewed record.

## GOALPOST / RESPONSE

The administration presents the statement as a breakthrough toward expanded U.S. market access and agricultural sales, while Thailand describes reciprocal, mutually beneficial terms and continued domestic process. The tests are publication of final text and schedules, formal signature, legal entry into force, implementation notices and measured trade flows—not the negotiating statement alone.

## MAYBE / THEREFORE

Maybe the remaining legal drafting will preserve the projected concessions and deliver the promised market access, or unresolved details and domestic procedures may narrow, delay or prevent implementation. Therefore the leaders completed and signed a substantial-conclusion statement—not the final reciprocal-trade agreement, an immediate tariff change or evidence of economic results.


## SOURCES

- [Joint Statement on an Agreement Between the United States of America and the Kingdom of Thailand on Reciprocal Trade](https://www.whitehouse.gov/briefings-statements/2026/11/joint-statement-on-an-agreement-between-the-united-states-of-america-and-the-kingdom-of-thailand-on-reciprocal-trade/) — official joint statement
- [Prime Minister Anutin and President Trump sign joint statement on substantial conclusion of reciprocal-trade negotiations](https://www.thaigov.go.th/th/news/171295) — official government statement
- [Trump says US trade deal with Thailand to be signed soon](https://www.reuters.com/world/trump-says-us-trade-deal-with-thailand-be-signed-soon-2026-11-17/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
