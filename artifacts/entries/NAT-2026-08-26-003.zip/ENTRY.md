# Treasury sanctions three foreign organizations under counterterrorism authority

**Entry ID:** NAT-2026-08-26-003
**Date:** August 26, 2026
**Checked:** 2026-08-26 12:02 PM EDT
**Evidence state:** official Treasury designation and sanctions explanation, with Reuters independently confirming the Palestine Action action and legal dispute; designations implemented, predicate conduct partly contested
**Review state:** current-standard-reviewed

OFAC designated Palestine Action, Autistici Inventati, and Masar Badil, freezing U.S.-linked property and generally barring U.S. transactions.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control designated Palestine Action, the Italy-based Autistici Inventati, and the transnational Masar Badil movement under Executive Order 13224, describing them as part of violent far-left networks.
- The implemented designations block property and interests in property within U.S. jurisdiction and generally prohibit U.S. persons from transactions with the organizations. Treasury attributed specific attacks, threats, or material support to each group; those underlying descriptions are administration allegations supporting the sanctions, not separate criminal convictions established by the designation itself.
- Reuters independently confirmed the Palestine Action designation and noted that the United Kingdom previously banned the group while its challenge is headed to the U.K. Supreme Court. Palestine Action says its direct actions target the operations of an Israeli defense company and disputes the terrorism characterization.

## SIGNIFICANCE

The sanctions extend U.S. counterterrorism financial restrictions to three foreign activist networks and expose financial intermediaries and potential supporters to compliance and secondary-enforcement risk. The action also intensifies disputes over when property damage and militant advocacy become terrorism-designation predicates.

## GOALPOST / RESPONSE

Treasury says the designations disrupt violent networks and their fundraising, and that peaceful protest remains protected. Palestine Action disputes the terrorism label and frames its conduct as direct action against weapons production. Asset blocks, enforcement cases, delisting petitions, court review, and evidence connecting each organization to the cited conduct are the evidence tests.

## MAYBE / THEREFORE

Maybe the designations will materially reduce financing for violent conduct, or they may primarily constrain advocacy and association while legal challenges proceed. Therefore the record verifies the sanctions' legal effect, attributes the predicate allegations to Treasury, and preserves the strongest public dispute rather than treating designation as a criminal verdict.


## SOURCES

- [Treasury — counterterrorism sanctions against three foreign organizations](https://home.treasury.gov/news/press-releases/sb0616/) — primary OFAC designation announcement, legal effect, and administration allegations
- [Reuters — U.S. sanctions Palestine Action](https://www.reuters.com/business/aerospace-defense/us-imposes-sanctions-palestine-action-group-2026-08-26/) — independent reporting with organization response and U.K. legal context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
