# U.S. officials acknowledge operating weapons in orbit

**Entry ID:** NAT-2026-09-15-008
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:29 AM EDT
**Evidence state:** Reuters reporting based on named Air Force, Space Force and Space Command officials; an operating capability was acknowledged while systems, inventory, legal framework and operational use remained undisclosed
**Review state:** current-standard-reviewed

The named officials described defensive space-control capabilities but disclosed neither the systems nor any operational use against another satellite.

## THE FACTS

- Air Force Secretary Troy Meink said the United States has on-orbit space-control weapons capable of defending the joint force against hostile action. Lt. Gen. Douglas Schiess also said enlisted personnel operate on-orbit weapons that can defend against space-enabled attacks, according to Reuters.
- The statements are an official acknowledgment of an operating capability, not a newly announced deployment order. The officials did not identify the systems, say whether they are kinetic or non-kinetic, disclose their locations or describe an operational use against another satellite.
- A U.S. Space Command official characterized public acknowledgment as supporting deterrence and readiness. That is the administration's stated rationale; public disclosure by itself does not establish the weapons' effectiveness, rules of engagement, cost or compatibility with international law.
- Reuters reported that the United States had historically kept offensive counterspace capabilities highly classified and that China and Russia have objected to placing weapons in orbit. Their objections and analysts' escalation concerns are competing risk assessments, not proof that a particular U.S. system has been used or triggered an arms race.
- No program identifier, appropriation, test result, deployment inventory, target set or after-action record was public by cutoff. The record therefore distinguishes acknowledged operation from independently verified technical performance or combat employment.

## SIGNIFICANCE

The disclosure moves a consequential military capability from inference toward official acknowledgment and changes the public baseline for U.S. counterspace policy. Its strategic effect remains uncertain because officials withheld the systems, scale, legal framework and operational history.

## GOALPOST / RESPONSE

Administration officials frame disclosure as deterrence and defense of the joint force. Program identifiers, budget lines, doctrine, legal reviews, test results, inventories, allied consultation, adversary responses and any documented operational use are the tests of capability, cost and escalation risk.

## MAYBE / THEREFORE

Maybe the acknowledged systems are limited, reversible defensive tools whose disclosure reduces miscalculation, or they may include broader capabilities that increase competition in orbit. Therefore the record establishes named officials' acknowledgment that U.S. personnel operate on-orbit weapons—not their technical design, number, legality in every scenario, effectiveness or use against another spacecraft.


## SOURCES

- [Reuters — U.S. officials acknowledge operating weapons in orbit](https://www.reuters.com/business/aerospace-defense/us-orbital-weapons-acknowledgement-landmark-move-us-space-command-official-says-2026-09-15/) — independent reporting with named Space Force, Air Force and Space Command officials; system details and any operational use remain undisclosed
- [Associated Press — U.S. acknowledges deployed weapons in space](https://apnews.com/article/space-weapons-air-force-5a2a0ada771daaf4fbef0991d8c09259) — independent reporting on the first official acknowledgment, withheld system details and broader space-policy context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
