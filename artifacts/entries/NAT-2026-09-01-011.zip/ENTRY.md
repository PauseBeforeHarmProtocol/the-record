# State Department announces $150 million in Pacific Islands support

**Entry ID:** NAT-2026-09-01-011
**Date:** September 1, 2026
**Checked:** 2026-09-02 12:00 AM EDT
**Evidence state:** independent Reuters reporting of a named State Department official's formal funding announcement and agency breakdown; commitment announced, detailed instruments, delivery and outcomes unresolved
**Review state:** current-standard-reviewed

The package includes $60 million for fuel storage and grid stability; announcement does not establish completed transfers, construction or regional outcomes.

## THE FACTS

- Deputy Secretary of State Christopher Landau announced that the United States would provide $150 million in funding to Pacific Islands countries during the Pacific Islands Forum in Palau.
- The State Department said $60 million of the package would address the global energy crisis by expanding fuel-storage capacity and supporting grid stability. Public reporting did not itemize every recipient, project, condition or funding source for the remaining $90 million by cutoff.
- Reuters independently reported the U.S. announcement alongside a separate Australian package worth about $430 million. The combined $580 million headline covers two sovereign governments; only the $150 million U.S. commitment is counted in this record.
- The announcement establishes a formal U.S. funding commitment, not completed obligation or disbursement, built storage, improved grid reliability, reduced drug trafficking or a measured change in regional alignment.

## SIGNIFICANCE

The package commits material U.S. support to small Pacific states as Washington and Beijing compete for regional influence, with a defined energy-security component. Its practical value depends on appropriation authority, recipient agreements, delivery and infrastructure results rather than the headline commitment.

## GOALPOST / RESPONSE

The administration presents the package as support for Pacific energy security and regional resilience. Pacific governments may value the resources while judging whether projects match local priorities and arrive on workable terms; critics may view the package primarily as geopolitical competition with China. Funding instruments, recipient agreements, obligations, disbursements, project completion, grid performance and recipient assessments are the tests.

## MAYBE / THEREFORE

Maybe the commitment will finance useful, locally supported infrastructure and deepen durable partnerships, or portions may remain delayed, conditional or strategically driven without measurable benefit. Therefore the record confirms an announced $150 million U.S. package with a $60 million energy component—not completed spending, finished infrastructure or proven geopolitical and development outcomes.


## SOURCES

- [Reuters — United States announces $150 million for Pacific Islands](https://www.reuters.com/world/china/us-australia-commit-580-million-support-pacific-islands-2026-09-02/) — independent reporting of the named State Department announcement, U.S. amount and $60 million energy-security component

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
