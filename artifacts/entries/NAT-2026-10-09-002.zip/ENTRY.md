# Trump establishes inquiry into whether Fed Governor Lisa Cook can be removed for cause

**Entry ID:** NAT-2026-10-09-002
**Date:** October 7–9, 2026
**Checked:** 2026-10-09 11:56 AM EDT
**Evidence state:** signed White House memorandum plus independent Reuters and Associated Press reporting; inquiry established, allegations unadjudicated, hearing and decision pending
**Review state:** current-standard-reviewed

A presidential memorandum creates a three-member committee, schedules a closed November 5 hearing and requires findings; the mortgage allegations remain unadjudicated and Cook remains in office.

## THE FACTS

- A presidential memorandum dated October 7 and posted publicly on October 9 establishes a committee of inquiry to investigate allegations that Federal Reserve Governor Lisa Cook made false statements connected to mortgage instruments. The committee consists of the White House economic-policy assistant, the EEOC chair and the Office of Government Ethics director.
- The committee must investigate and recommend whether there is cause to remove Cook under 12 U.S.C. 242 as construed in Trump v. Cook. It scheduled a closed White House hearing for November 5, limited to four hours, with advance evidence disclosure, participation by Cook and counsel, a transcript, written submissions and later findings of fact and conclusions of law.
- The memorandum opens a formal inquiry; it does not find that Cook made false statements, committed mortgage fraud or can be removed. Cook has not been charged with a crime. Her lawyers said a genuine and objective hearing would show no legal basis for removal and that they were evaluating the proposed process.
- Reuters and Associated Press described the inquiry as a renewed stage in Trump's unprecedented attempt to remove a sitting Fed governor. The Supreme Court previously left Cook in office while requiring adequate cause, notice and a chance to respond; the new committee appears designed to build that process, but no final recommendation or removal decision existed by cutoff.

## SIGNIFICANCE

The inquiry creates a formal executive process that could test statutory for-cause protection and Federal Reserve independence. Its closed structure, membership, evidentiary procedures and later judicial review will matter as much as the allegations themselves.

## GOALPOST / RESPONSE

Trump says the inquiry will determine whether Cook can be trusted and whether legal cause exists for removal. Cook's lawyers say an objective process will clear her. The disclosed evidence, hearing transcript, committee findings, presidential decision and subsequent court review are the tests.

## MAYBE / THEREFORE

Maybe the procedure develops reliable evidence and supplies the due process the Supreme Court required, or it may function as a predetermined step in a campaign for greater presidential control of the Fed. Therefore a formal inquiry and hearing schedule now exist—not a fraud finding, removal for cause or change in Cook's current officeholding.


## SOURCES

- [White House — committee of inquiry into allegations concerning Lisa Cook](https://www.whitehouse.gov/presidential-actions/2026/10/establishment-of-a-committee-of-inquiry-to-investigate-allegations-of-false-statements-by-lisa-denell-cook/) — official presidential memorandum
- [Reuters — White House inquiry into Fed Governor Lisa Cook](https://www.reuters.com/world/us/trump-launches-committee-probe-feds-lisa-cook-white-house-statement-2026-10-09/) — independent reporting of the inquiry and Cook response
- [Associated Press — Trump establishes committee to investigate Lisa Cook](https://apnews.com/article/cook-federal-reserve-trump-debef61d38fbb6a74e84a57fe8e26fc5) — independent reporting of the inquiry, legal posture and response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
