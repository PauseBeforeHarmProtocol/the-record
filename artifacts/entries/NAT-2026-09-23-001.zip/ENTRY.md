# United States and Argentina launch Andes-Atlantic infrastructure corridor

**Entry ID:** NAT-2026-09-23-001
**Date:** September 23, 2026
**Checked:** 2026-09-24 6:02 AM EDT
**Evidence state:** complete published U.S.-Argentina joint statement and indexed State Department fact sheet, plus Reuters and Associated Press reporting; framework and financing ceiling announced, transaction approvals, disbursements, construction and outcomes unresolved
**Review state:** current-standard-reviewed

The governments announced a transport, energy, minerals and digital-infrastructure framework backed by U.S. financing tools, including an EXIM ceiling of up to $7 billion through 2027; the framework is not a $7 billion disbursement or approval of every listed project.

## THE FACTS

- U.S. Deputy Secretary of State Christopher Landau and Argentine Foreign Minister Pablo Quirno jointly launched the Andes-Atlantic Corridor on September 23. The published statement describes a framework to connect Argentine economic sectors with Atlantic ports and Western markets through transportation, energy and digital infrastructure.
- The joint statement identifies railways, waterways, ports, pipelines, power generation and transmission, critical-mineral mining and processing, trusted technology and customs screening as cooperation areas. It says U.S. firms may compete for projects and that U.S. agencies may use loans, guarantees, insurance, development assistance and technical support.
- A State Department fact sheet says the U.S.-Argentina Build the Future Framework provides for Export-Import Bank financing of up to $7 billion by 2027 for infrastructure and productive-capacity projects. This is an announced financing ceiling and project framework, not evidence that $7 billion was appropriated, approved for named borrowers or disbursed.
- The official materials identify the Export-Import Bank, Development Finance Corporation and Trade and Development Agency as potential support channels. Reuters had earlier reported the planned package from a document and an unnamed source; the later public statements resolve the existence of the framework but not project-level approvals, final terms or expenditures.
- The governments present the corridor as a way to secure Western Hemisphere supply chains, expand Argentine exports and create opportunities for U.S. equipment and service providers. No completed construction, increased export volume, procurement award, environmental review, final EXIM board approval or measured economic result was public by cutoff.

## SIGNIFICANCE

The corridor makes U.S. public-finance tools part of a long-term effort to shape Argentine mineral, energy and transport infrastructure and Western supply chains. Its scale could be substantial, but the announced ceiling and project pipeline remain distinct from approved transactions, public spending and completed infrastructure.

## GOALPOST / RESPONSE

The administration says the corridor will strengthen supply chains, increase exports and create opportunities for U.S. firms, while Argentina commits to a predictable investment environment. Published project lists, agency board approvals, financing terms, appropriations, borrower commitments, competitive awards, safeguards, disbursements, construction milestones, exports and U.S. jobs are the tests.

## MAYBE / THEREFORE

Maybe the framework will mobilize commercially viable infrastructure and diversify critical supply chains, or financing, regulatory, environmental and project-execution constraints may limit or delay it. Therefore the two governments launched a corridor and announced access to financing tools of up to $7 billion through 2027—not a $7 billion payment, approval of every proposed project or measured economic outcome.


## SOURCES

- [U.S. Department of State — joint statement launching Andes-Atlantic Corridor](https://www.state.gov/releases/office-of-the-spokesman/2026/09/joint-statement-on-the-launch-of-the-andes-atlantic-corridor/) — primary joint government statement
- [U.S. Department of State — Andes-Atlantic Corridor fact sheet](https://www.state.gov/releases/office-of-the-spokesman/2026/09/united-states-and-argentina-launch-andes-atlantic-corridor-fact-sheet/) — primary government fact sheet on financing tools and project pipeline
- [Reuters — planned U.S. financing for Argentina minerals and energy projects](https://www.reuters.com/business/energy/us-fund-7-billion-argentina-mineral-energy-projects-document-shows-2026-09-23/) — independent reporting on a financing document and later-announced framework
- [Associated Press — United States and Argentina launch infrastructure-financing corridor](https://apnews.com/article/argentina-javier-milei-donald-trump-mining-energy-financing-66f724b8d76915d75ae75df41b976049) — independent reporting on the announced corridor, financing ceiling and project scope

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
