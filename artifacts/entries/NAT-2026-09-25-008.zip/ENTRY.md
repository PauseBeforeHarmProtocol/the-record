# Trump signs public-ocean restrictions data law

**Entry ID:** NAT-2026-09-25-008
**Date:** September 25, 2026
**Checked:** 2026-09-25 5:59 PM EDT
**Evidence state:** primary White House signing statement and enrolled statutory text; data-standard and publication duties enacted September 25, with multi-year implementation pending
**Review state:** current-standard-reviewed

Commerce must standardize and publish geospatial information on fishing and recreational restrictions within multi-year deadlines while protecting Tribal waters and sensitive information.

## THE FACTS

- Trump signed S. 759, the Modernizing Access to Our Public Oceans Act, on September 25.
- The law requires the Commerce Department to develop geospatial data standards within 31 months and make specified federal fishing, recreational-use, vessel, protected-area and navigation restrictions in the exclusive economic zone publicly available on a website within four years.
- Covered data generally must be updated at least twice a year, or in real time where practicable for temporary restrictions, and the law requires coordination with relevant federal and state entities.
- The law excludes protected resource, proprietary and certain sensitive information; it does not apply to Tribal waters or areas and does not alter regulatory jurisdiction, treaty rights or existing statutory authority.

## SIGNIFICANCE

The law creates a multi-year federal duty to make marine access restrictions easier to find and use in interoperable geographic formats, while preserving legal and Tribal boundaries.

## GOALPOST / RESPONSE

Supporters say standardized data will improve public access and navigation. Published standards, website coverage, update frequency, usability, accuracy and implementation cost are the tests.

## MAYBE / THEREFORE

Maybe a single geospatial layer will reduce confusion for anglers and boaters, or it may duplicate existing systems and omit hard-to-standardize data. Therefore publication duties are enacted—not that the website exists or access outcomes have improved.


## SOURCES

- [Congressional bills H.R. 3657, H.R. 7250, S. 550, S. 603, S. 759 and S. 790 signed into law](https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bills-h-r-3657-h-r-7250-s-550-s-603-s-759-and-s-790-signed-into-law/) — primary presidential signing statement
- [S. 759 — Modernizing Access to Our Public Oceans Act, enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119s759enr/pdf/BILLS-119s759enr.pdf) — primary enacted legislation; enrolled text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
