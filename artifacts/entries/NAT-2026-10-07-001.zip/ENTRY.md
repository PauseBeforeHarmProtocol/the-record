# USTR formally continues two China Section 301 tariff actions

**Entry ID:** NAT-2026-10-07-001
**Date:** October 7, 2026
**Checked:** 2026-10-07 6:02 AM EDT
**Evidence state:** two primary USTR Federal Register notices and an independent KPMG trade summary; continuation implemented by statutory operation, review and outcome evidence pending
**Review state:** current-standard-reviewed

The 2018 actions did not expire at their 2026 anniversaries; a statutory effectiveness-and-effects review remains pending.

## THE FACTS

- USTR formally published notice that the July 6 and August 23, 2018 China Section 301 actions, as modified, did not terminate on their respective 2026 four-year anniversaries and remain in effect subject to possible further modification. The notice confirms continuation under the statute; it does not impose a new tariff rate on October 7.
- USTR said it received 68 continuation requests from domestic producers and 18 from trade associations for the July action, and 57 producer requests and 19 association requests for the August action. Those requests triggered continuation under Section 307(c)(1)(B) of the Trade Act.
- USTR said it will publish a separate notice or notices for the next review stage, including public comment on effectiveness, possible alternative actions and effects on the U.S. economy, including consumers. Continuation is established; effectiveness, consumer effects and any later modification are not yet determined by this notice.
- A companion USTR notice makes a conforming Harmonized Tariff Schedule amendment, effective July 1, after statistical-category changes affected one exclusion. USTR says the amendment maintains pre-existing product coverage; it is not treated here as an expansion of the exclusion or a separate tariff action.

## SIGNIFICANCE

The notices preserve two major China trade actions beyond their possible termination dates while moving them into another statutory review. The economic and strategic case remains consequential, but the required review—not the continuation notice—will test effectiveness, alternatives and effects on consumers.

## GOALPOST / RESPONSE

USTR relays benefiting industries’ view that the actions pressure China, reduce unfair competition and encourage domestic investment, production and reshoring. The forthcoming review’s evidence on those objectives, U.S. economic effects, consumer costs and any modifications is the test of that explanation.

## MAYBE / THEREFORE

Maybe continuation preserves negotiating leverage and supports domestic capacity, or the tariffs may impose input and consumer costs while protecting activity that would not otherwise be competitive. Therefore the two actions legally remained in force after their anniversary dates and USTR has formally documented that result; their net effectiveness and distributional effects remain unresolved pending review.


## SOURCES

- [USTR — Continuation of China Section 301 actions](https://public-inspection.federalregister.gov/2026-20510.pdf) — official Federal Register notice
- [USTR — Conforming amendment to China Section 301 product exclusion](https://public-inspection.federalregister.gov/2026-20511.pdf) — official Federal Register notice
- [KPMG — USTR continues China Section 301 actions and amends exclusion](https://kpmg.com/us/en/taxnewsflash/news/2026/10/ustr-china-section-301-actions-product-exclusion.html) — independent trade and tax analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
