# Ethiopia emergency expires and OFAC removes Eritrea-related sanctions

**Entry ID:** NAT-2026-09-18-015
**Date:** September 18, 2026
**Checked:** 2026-09-19 12:01 PM EDT
**Evidence state:** complete OFAC recent-action notice plus independent Associated Press reporting and named Eritrean response; sanctions removals implemented, broader effects unresolved
**Review state:** current-standard-reviewed

OFAC removed the Eritrean ruling party, military, two officials and affiliated entities after the underlying 2021 national emergency expired.

## THE FACTS

- The national emergency declared in Executive Order 14046 concerning the humanitarian and human-rights crisis in Ethiopia expired on September 18, 2026. OFAC said it consequently removed persons designated under that order and removed program-specific frequently asked questions.
- The published deletions include Eritrea's People's Front for Democracy and Justice, the Eritrean Defense Forces, officials Hagos Ghebrehiwet Weldekidan and Abraha Kassa Nemariam, Red Sea Trading Corporation and Hidri Trust. Aliases in the raw list do not represent additional people or entities.
- The action removes blocking sanctions imposed under the expired Ethiopia authority. It does not erase the factual history of the Tigray conflict, adjudicate alleged humanitarian or human-rights conduct, or establish a broader diplomatic or security agreement with Eritrea.
- Associated Press reported that Eritrean Information Minister Yemane Gebremeskel welcomed the reversal and called the earlier sanctions unwarranted. That is the Eritrean government's response, not an independent finding about the original designations or the effects of delisting.

## SIGNIFICANCE

Expiration of the emergency and target-level delistings end a defined U.S. sanctions program affecting Eritrea's ruling apparatus and military, changing their U.S. blocking status while leaving accountability claims and any strategic consequences unresolved.

## GOALPOST / RESPONSE

OFAC attributes the removals to expiration of the statutory emergency, while Eritrea describes the change as remediation of unwarranted sanctions. Subsequent Treasury guidance, transactions, diplomatic engagement, Red Sea security cooperation and independently measured humanitarian or accountability effects are the tests.

## MAYBE / THEREFORE

Maybe the delistings support normalization or regional-security cooperation, or they may reduce leverage without improving accountability or conditions. Therefore the emergency expired and OFAC removed the listed targets—not that prior allegations were disproved, conduct was adjudicated lawful or policy outcomes were measured.


## SOURCES

- [OFAC — expiration of Ethiopia emergency and designation removals](https://ofac.treasury.gov/recent-actions/20260918) — primary sanctions-list action
- [Associated Press — United States lifts Eritrea-related sanctions](https://apnews.com/article/us-eritrea-sanctions-tigray-houthi-red-sea-c3a4056f2c69b841d97b1bdd8d259716) — independent reporting with named Eritrean government response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
