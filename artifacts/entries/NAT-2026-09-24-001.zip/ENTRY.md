# Energy Department selects 31 grid projects for $1.9 billion in federal support

**Entry ID:** NAT-2026-09-24-001
**Date:** September 24, 2026
**Checked:** 2026-09-24 12:00 PM EDT
**Evidence state:** complete Energy Department announcement plus Associated Press reporting on program scope, funding origin and projected effects; selections announced, project-level awards, spending, construction and outcomes unresolved
**Review state:** current-standard-reviewed

DOE announced intended support for 31 projects across 26 states, paired with $3.35 billion in recipient cost share; selections and projected capacity are not completed awards, construction, savings or reliability outcomes.

## THE FACTS

- The Department of Energy announced that it intends to help fund 31 grid projects across 26 states through its Speed to Power initiative. DOE described $1.9 billion in federal support and $3.35 billion in recipient cost sharing, for a stated total of $5.25 billion.
- DOE said the selected projects would rebuild or reconductor more than 1,500 miles of transmission and deploy advanced grid-enhancing technologies across nearly 21,000 miles. It projected that the portfolio could enable more than 23 gigawatts of additional capacity.
- The department said the projects could benefit about 100 million Americans through lower costs and improved reliability. Those are agency projections attached to announced selections, not independently measured savings, outage reductions or completed capacity.
- Associated Press independently reported the announcement and noted that the funding comes from the 2021 bipartisan infrastructure law enacted under President Biden. The Trump administration is selecting and presenting the projects under its Speed to Power initiative; the underlying appropriation predates it.
- No complete project list, final award agreement, obligation schedule, disbursement, permit, construction milestone, energized capacity or measured consumer outcome was independently verified by cutoff.

## SIGNIFICANCE

The announced portfolio directs substantial existing federal infrastructure funding toward transmission upgrades at a time of rising electricity demand. Its practical value depends on final awards, recipient performance, permitting, construction and whether projected capacity and cost benefits materialize.

## GOALPOST / RESPONSE

DOE says the investments will speed power delivery, lower costs and improve reliability, with recipients supplying most of the stated portfolio cost. Executed award documents, project-by-project scopes, obligations and disbursements, permits, recipient cost share, miles completed, capacity placed in service, reliability data and customer-bill effects are the tests.

## MAYBE / THEREFORE

Maybe the selected projects will deliver large transmission gains efficiently, or permitting, procurement and construction constraints may reduce or delay the projected benefits. Therefore DOE announced intended support totaling $1.9 billion for 31 projects—not final expenditure of the full amount, completed upgrades, 23 gigawatts online or proven savings for 100 million people.


## SOURCES

- [U.S. Department of Energy — Speed to Power project selections](https://www.energy.gov/articles/energy-department-announces-speed-power-investments-across-26-states-lower-electricity-0) — primary government announcement of intended federal support, recipient cost share and projected grid effects
- [Associated Press — Energy Department announces 31 grid projects](https://apnews.com/article/energy-electricity-wright-power-grid-trump-447c7d80c93928712750710769a8ca43) — independent reporting on the selections, funding origin and projected effects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
