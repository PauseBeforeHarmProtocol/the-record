# Court rejects Google AdX breakup and orders behavioral antitrust remedies

**Entry ID:** NAT-2026-09-02-011
**Date:** September 2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** independent Reuters legal reporting on an oral federal remedies ruling; liability previously decided, divestiture rejected, behavioral relief ordered, detailed written opinion and appeals pending
**Review state:** current-standard-reviewed

The judge declined DOJ's requested divestiture after finding illegal monopolization and instead accepted conduct remedies; a detailed redacted opinion is still forthcoming.

## THE FACTS

- U.S. District Judge Leonie Brinkema orally rejected the Justice Department's request that Google divest its AdX advertising exchange after her April 2025 liability ruling found Google held illegal monopolies in publisher ad servers and ad exchanges.
- The court accepted behavioral remedies rather than structural separation. Reuters reported that Google's proposal included giving competitors real-time access to bids; the precise operative terms await the written ruling, which the court said would be released after a 14-day confidential-redaction period.
- DOJ said it was pleased the court ordered substantial relief and was evaluating next steps. Google welcomed rejection of the breakup request and argued that divestiture would create a complex, disruptive transition that would harm customers.
- The ruling is a remedies decision following an established antitrust violation. It does not reverse the liability finding, require an immediate AdX sale, prove that behavioral remedies will restore competition or establish the final scope before the written opinion issues.

## SIGNIFICANCE

The decision determines the initial remedy for a major federal monopolization case and rejects the administration's strongest structural request. Its significance turns on whether conduct obligations can reopen competition in digital advertising without divestiture and whether the written judgment survives appeal.

## GOALPOST / RESPONSE

DOJ says substantial relief is needed because Google's prior conduct harmed publishers, competition and consumers and is evaluating further steps. Google says divestiture would be technically disruptive and that conduct changes can address the court's concerns. The written injunction, implementation deadlines, compliance audits, rival access, publisher fees, market shares, appeals and enforcement proceedings are the tests.

## MAYBE / THEREFORE

Maybe behavioral remedies will create workable real-time access and restore competition without the disruption of a forced sale, or Google may retain durable advantages that only structural separation would have addressed. Therefore the record confirms that the court rejected AdX divestiture and ordered behavioral relief—not that Google won the liability case, that the final terms are already public or that competition has been restored.


## SOURCES

- [Reuters — court rejects Google AdX divestiture and orders behavioral remedies](https://www.reuters.com/legal/litigation/google-defeats-us-bid-force-ad-tech-sale-2026-09-02/) — independent legal reporting on the oral remedies ruling, the rejected DOJ breakup request and the forthcoming redacted opinion

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
