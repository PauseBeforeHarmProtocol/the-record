# FCC blocks two device approvals under new covered-component rules

**Entry ID:** NAT-2026-10-22-008
**Date:** October 22, 2026
**Checked:** 2026-10-23 6:03 AM EDT
**Evidence state:** FCC release text inspected through an exact syndicated copy because the agency page returned HTTP 403, plus Reuters corroboration; two equipment authorizations blocked
**Review state:** current-standard-reviewed

The agency said it prevented a dashboard camera and wireless video transmitter containing HiSilicon chips from being marketed, its first enforcement under component-level equipment rules.

## THE FACTS

- The Federal Communications Commission said its Office of Engineering and Technology prevented equipment authorization for a dashboard camera and a wireless video transmitter because each contained components from HiSilicon, a Huawei subsidiary on the agency's Covered List.
- The FCC described the action as its first enforcement under component-level equipment-authorization rules that had taken effect the prior week. Reuters independently reported the two blocked approvals and the cited HiSilicon components.
- The agency did not name the two device models in the inspected release. The action prevents those models from receiving authorization needed for marketing or sale in the United States; it is not evidence that every device using a Chinese-made component was banned.
- The inspected materials did not identify an exploited vulnerability in either device or measure a security benefit from the blocks. They establish use of the authorization rule, not the rule's effectiveness.

## SIGNIFICANCE

The blocks show the FCC has moved from adopting a component-level supply-chain rule to applying it in individual equipment reviews, expanding the practical reach of its Covered List controls.

## GOALPOST / RESPONSE

FCC Chair Brendan Carr said prohibited components can create back-door surveillance risks. The tests are consistently published authorization decisions, identified risk evidence, appeal outcomes and measurable changes in device security or supply chains.

## MAYBE / THEREFORE

Maybe component screening will keep high-risk equipment out of U.S. networks, or it may block products without demonstrating device-specific harm and shift sourcing costs. Therefore the record establishes two implemented authorization blocks under the new rule—not a broad ban or a measured security result.


## SOURCES

- [FCC — FCC Blocks Two Devices Containing Foreign Surveillance Chips](https://www.fcc.gov/document/fcc-blocks-two-devices-containing-foreign-surveillance-chips) — official agency release; direct page returned HTTP 403 during inspection and exact release text was inspected through a syndicated copy
- [Reuters — FCC blocks approvals for two devices containing Huawei subsidiary chips](https://www.reuters.com/world/us-blocks-two-devices-with-chinese-made-surveillance-chips-2026-10-22/) — independent reporting quoting the FCC action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
