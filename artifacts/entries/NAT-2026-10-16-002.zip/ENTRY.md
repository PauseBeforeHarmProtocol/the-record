# Reported ICAO safety findings complicate direct U.S.–Lebanon flight plan

**Entry ID:** NAT-2026-10-16-002
**Date:** October 16, 2026
**Checked:** 2026-10-16 6:01 PM EDT
**Evidence state:** Reuters inspection of an internal ICAO report summary, named Lebanese minister response and prior named FAA response; safety deficiencies reported, corrective work announced, U.S. approvals and service unresolved
**Review state:** current-standard-reviewed

Reuters reviewed a summary of an internal ICAO assistance report identifying expired airport certification, emergency-planning and regulatory gaps. The presidential directive permits a review process; no direct service has resumed and U.S. safety approvals remain pending.

## THE FACTS

- Reuters reported that an internal International Civil Aviation Organization technical-assistance report sent to Lebanon in September found that Beirut-Rafic Hariri International Airport’s conditional certification had expired and that the airport lacked an emergency plan and firefighting capability suitable for long-haul twin-aisle aircraft. The underlying report was not publicly available for direct inspection, so the findings are recorded as reported.
- The report summary also said Lebanon’s civil-aviation regulator lacked qualified inspectors for air-traffic-control licensing and did not have a fully established, operational and independent aircraft-accident investigation authority with clearly defined roles.
- Trump had directed the U.S. government in July to allow domestic carriers to fly directly to Lebanon and later signed an order advancing that policy. FAA and Transportation Security Administration safety reviews were still required, and no direct U.S.–Lebanon flight had resumed at cutoff.
- Lebanese Public Works and Transport Minister Fayez Rasamny said most issues had already been identified, corrective work had begun and conditional airport certification was expected after a new review. FAA declined comment; ICAO said it could not discuss country-specific matters, and the State Department continued to advise Americans not to travel to Lebanon.

## SIGNIFICANCE

The reported findings provide a concrete implementation test for a high-profile diplomatic announcement: legal permission alone does not establish airport certification, regulator capacity, airline willingness or safe service. The gaps affect both operational readiness and the credibility of independent safety oversight.

## GOALPOST / RESPONSE

The administration and Lebanon describe restoration of direct service as a step toward stronger bilateral ties, while Lebanese officials say corrective action is underway. Public certification, completed FAA and TSA reviews, adequate emergency and firefighting capacity, qualified inspectors, an independent accident-investigation authority, carrier commitments and an operated flight are the tests.

## MAYBE / THEREFORE

Maybe corrective work and U.S. reviews can restore direct service safely, or security and institutional gaps may delay or prevent carriers from returning. Therefore Reuters documented reported ICAO deficiencies and pending approvals; neither the report nor the presidential directive establishes that a route is certified, scheduled or operating.


## SOURCES

- [Reuters — ICAO findings complicate proposed restoration of direct U.S.–Lebanon flights](https://www.reuters.com/world/middle-east/trump-move-restart-direct-us-flights-with-lebanon-hits-roadblock-2026-10-16/) — independent reporting based on an internal ICAO report summary, named Lebanese response and regulator context
- [Reuters — Trump directs government to allow direct U.S.–Lebanon flights subject to safety review](https://www.reuters.com/world/middle-east/trump-directing-administration-allow-us-airlines-fly-lebanon-2026-07-21/) — independent reporting with named FAA response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
