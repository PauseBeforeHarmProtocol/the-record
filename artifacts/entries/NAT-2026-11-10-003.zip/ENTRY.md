# Fourth Circuit orders narrower demand for journalists' LinkedIn records

**Entry ID:** NAT-2026-11-10-003
**Date:** November 10, 2026
**Checked:** 2026-11-10 6:12 PM EST
**Evidence state:** primary published Fourth Circuit opinion plus Associated Press reporting; narrowing and remand ordered, with revised orders and investigative outcome unresolved
**Review state:** current-standard-reviewed

The unanimous panel found disclosure and secrecy orders substantially overbroad in a national-security leak probe but refused to quash them entirely.

## THE FACTS

- On November 10, a unanimous Fourth Circuit panel decided In re Application, No. 26-4303, affirming in part, reversing in part and remanding orders obtained by the government under the Stored Communications Act in a national-security leak investigation.
- The disclosure order covered 18 months of LinkedIn metadata for targeted journalists who collectively published nearly 1,000 stories, fewer than 5% of which appeared related to the classified military-operation article under investigation. The court said the demand could expose many confidential sources with no apparent connection to the leak.
- The panel held that the disclosure order was substantially overbroad under the statute and First Amendment considerations and directed the district court to narrow it. It also required closer consideration of LinkedIn's proposal to disclose the orders to one vetted news-outlet lawyer, while affirming denial of LinkedIn's request for the government's ex parte materials.
- The court rejected LinkedIn's request to quash the orders entirely and emphasized the government's compelling interest in investigating disclosure of sensitive national-security information. The ruling therefore narrows process and scope; it does not end the leak investigation or establish that the investigation itself is unlawful.

## SIGNIFICANCE

The published ruling constrains a federal leak investigation's access to journalist-source metadata and its use of secrecy, setting a circuit precedent at the intersection of national security, the Stored Communications Act and press freedom.

## GOALPOST / RESPONSE

The government says a classified military-operation leak warrants vigorous investigation; LinkedIn argued the orders swept far beyond relevant sources and burdened press rights. The next tests are the narrowed district-court orders, any approved disclosure to counsel, compliance, further appeal and whether investigators can identify relevant records without exposing unrelated sources.

## MAYBE / THEREFORE

Maybe careful narrowing preserves an effective leak investigation while protecting unrelated sources, or the revised orders may remain contested as too broad or too restrictive. Therefore the record establishes an appellate remand requiring narrower disclosure and secrecy—not a quashed investigation, a finding that every requested record was improper or immunity for any source who unlawfully disclosed classified information.


## SOURCES

- [Fourth Circuit — In re Application, No. 26-4303](https://www.ca4.uscourts.gov/opinions/264303.P.pdf) — primary published appellate opinion
- [AP — appeals court limits LinkedIn journalist-records order in leak probe](https://apnews.com/article/0b1f07e1fca918e6173a82be38489c3a) — independent court reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
