# FDIC proposes custodial-deposit exception framework

**Entry ID:** NAT-2026-11-20-002
**Date:** Proposed rule published November 20, 2026; comments due January 19, 2027
**Checked:** 2026-11-20 6:04 AM EST
**Evidence state:** official notice of proposed rulemaking and agency economic analysis; proposal published, not finalized or implemented by the rule
**Review state:** current-standard-reviewed

The proposal would implement a new statutory exception for qualifying custodial deposits at eligible banks, with a 20 percent cap, notice and annual certification requirements, and comments due January 19.

## THE FACTS

- The Federal Deposit Insurance Corporation proposed amendments to its brokered-deposit regulations to implement section 901 of the 21st Century ROAD to Housing Act. Comments are due January 19, 2027; the notice is a proposal, not a final rule.
- The proposal would allow an eligible insured depository institution with less than $10 billion in assets to treat qualifying custodial deposits up to 20 percent of total liabilities as non-brokered, subject to statutory eligibility and interest-rate restrictions.
- A bank, qualifying entity or other party in the placement arrangement would have to submit a one-time notice effective upon filing, certify it annually and update material changes. The FDIC would publish a list of qualifying notices.
- The FDIC estimates 4,031 institutions could meet the proposed eligibility definition and that as many as 1,629 could be immediately affected if the rule were finalized. It estimates about $450 in labor cost for an initial notice and $112 for annual certification, while saying some deposit-insurance assessments could fall but aggregate effects are likely small.

## SIGNIFICANCE

The proposal could change how up to 1,629 banks classify custodial funding and how some institutions are assessed for deposit insurance. The statutory exception already exists, but the proposed definitions, notice system and supervisory treatment would shape its operation.

## GOALPOST / RESPONSE

The FDIC says the proposal would clarify the statutory exception, reduce an asset-threshold cliff and make qualifying arrangements transparent. The tests are the final text, treatment of comments, number and identity of notice filers, reclassification of deposits, insurance-assessment effects, funding and liquidity changes, compliance costs, supervisory outcomes and any effect on deposit-insurance risk.

## MAYBE / THEREFORE

Maybe the proposal will give community banks clearer access to stable custodial deposits with limited compliance costs, or reclassification could change funding incentives and risk in ways the present estimates do not capture. Therefore the FDIC opened a rulemaking and supplied estimates; it has not finalized the definitions, approved a notice or measured bank, depositor or insurance-fund outcomes.


## SOURCES

- [Federal Register — Custodial Deposits: Implementing the 21st Century ROAD to Housing Act](https://www.federalregister.gov/documents/2026/11/20/2026-23669/custodial-deposits-implementing-the-21st-century-road-to-housing-act) — primary notice of proposed rulemaking

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
