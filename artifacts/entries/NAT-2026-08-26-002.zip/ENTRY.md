# DOJ and FBI seize domains used by China-linked hacking platforms

**Entry ID:** NAT-2026-08-26-002
**Date:** August 26, 2026
**Checked:** 2026-08-26 12:02 PM EDT
**Evidence state:** DOJ announcement and unsealed court-authorized seizure materials independently reported by Reuters; infrastructure action implemented, attribution alleged by U.S. authorities rather than judicially adjudicated
**Review state:** current-standard-reviewed

Court-authorized seizures disabled QScan and QTRouter infrastructure that DOJ says supported intrusions against U.S. government and private targets.

## THE FACTS

- The Justice Department announced that federal courts authorized the seizure of domains and server infrastructure used by the QScan and QTRouter platforms, and said the coordinated action rendered both platforms inoperable.
- Unsealed warrant materials and DOJ's announcement allege that China state-sponsored hackers used the platforms to scan for vulnerabilities, route malicious traffic, and target U.S. government agencies and private organizations, including NASA, the Senate, the Federal Reserve, and several executive departments.
- Reuters independently confirmed the seizure announcement. China's government routinely denies responsibility for state-linked hacking, and its Washington embassy did not immediately comment on this operation. The public materials establish the seizure and the government's attribution; they do not constitute an adjudicated finding against named Chinese officials.

## SIGNIFICANCE

The operation is an implemented disruption of alleged foreign cyber infrastructure rather than only a warning or attribution statement. Its lasting effectiveness depends on whether operators rebuild, migrate, or lose access to data and routing capacity.

## GOALPOST / RESPONSE

DOJ and the FBI say the seizures protect public and private networks by depriving state-sponsored actors of operational infrastructure. China has broadly rejected U.S. hacking accusations. Subsequent platform availability, replacement infrastructure, victim notifications, indictments, and independent technical analysis are the evidence tests.

## MAYBE / THEREFORE

Maybe the platforms also had legitimate users or the operators will rapidly reconstitute them elsewhere, and the attribution may remain contested without a merits proceeding. Therefore the record treats the court-authorized seizures and service disruption as verified while attributing the China-state sponsorship allegations to U.S. authorities.


## SOURCES

- [Justice Department — seizure of platforms allegedly used by China state-sponsored hackers](https://www.justice.gov/opa/pr/justice-department-and-fbi-seize-platforms-operated-and-used-china-state-sponsored-hackers) — primary administration announcement with links to unsealed court materials
- [Reuters — U.S. seizes China-linked hacking platforms](https://www.reuters.com/world/china/china-sponsored-hacking-platforms-seized-by-us-justice-department-says-2026-08-26/) — independent reporting on the court-authorized cyber disruption and attribution dispute

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
