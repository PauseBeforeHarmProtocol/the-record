# OFAC extends limited Lukoil International divestment authorization

**Entry ID:** NAT-2026-09-18-016
**Date:** September 18, 2026
**Checked:** 2026-09-19 12:01 PM EDT
**Evidence state:** complete two-page OFAC General License 131J and updated FAQs 1224–1225; authorization implemented through October 22, transaction and outcome unresolved
**Review state:** current-standard-reviewed

General License 131J extends negotiation, contingent-contract and maintenance authority through October 22 but still requires separate approval for an actual sale.

## THE FACTS

- OFAC issued Russia-related General License 131J, replacing General License 131I and extending specified Lukoil International GmbH authorizations through 12:01 a.m. EDT on October 22, 2026.
- The license authorizes negotiations and entry into contracts expressly contingent on separate OFAC authorization for the sale, disposition or transfer of Lukoil International GmbH or majority-owned entities. It also authorizes maintenance or wind-down transactions and use of blocked accounts for those activities during the license period.
- The license does not authorize an actual sale, general unblocking, transactions with other blocked persons or transfers of funds to any person or account in Russia. OFAC says any later sale authorization should sever ties to Lukoil, block proceeds owed to it in a U.S.-jurisdiction account and avoid a windfall.
- This is a time-limited sanctions license and divestment pathway, not evidence that a buyer, price, approved sale, transfer or reduction in Russian war revenue already exists.

## SIGNIFICANCE

The extension keeps a controlled path open for negotiations and maintenance of Lukoil's non-Russian assets while preserving sanctions leverage and a separate approval gate for any divestment.

## GOALPOST / RESPONSE

OFAC says the framework can support divestment while cutting funding to Russia. A qualifying buyer, transaction terms, separate sale license, blocked proceeds, severed control, completion and measurable effects on Lukoil and Russian revenue are the tests.

## MAYBE / THEREFORE

Maybe the additional month enables a compliant divestment that separates overseas assets from Lukoil, or negotiations may fail or produce terms OFAC rejects. Therefore transactions supporting negotiations and maintenance are temporarily authorized—not that a sale was approved, completed or shown to reduce war funding.


## SOURCES

- [OFAC General License 131J — Lukoil International divestment negotiations](https://ofac.treasury.gov/media/936951/download?inline=) — primary two-page general license
- [OFAC FAQs 1224 and 1225 — Lukoil International authorizations](https://ofac.treasury.gov/faqs/updated/2026-09-18) — primary agency guidance

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
