# Treasury agencies impose $1.21 billion Bank of America enforcement package

**Entry ID:** NAT-2026-10-13-008
**Date:** October 13, 2026
**Checked:** 2026-10-14 12:01 AM EDT
**Evidence state:** primary Treasury, FinCEN and OFAC enforcement records plus independent Associated Press reporting and company response; penalties and settlement imposed, remediation outcomes unmeasured
**Review state:** current-standard-reviewed

The coordinated anti-money-laundering and sanctions resolutions include a $1.2 billion FinCEN penalty, an overlapping OCC assessment and an $11.6 million OFAC settlement.

## THE FACTS

- The Treasury Department announced coordinated enforcement actions totaling more than $1.21 billion against Bank of America for anti-money-laundering and sanctions-compliance failures. FinCEN assessed a $1.2 billion civil money penalty, and OFAC announced an approximately $11.6 million settlement covering 475 apparent sanctions violations.
- FinCEN's consent order says the bank maintained an ineffective anti-money-laundering program and failed to timely file thousands of suspicious-activity reports. The Office of the Comptroller of the Currency separately assessed $750 million for related conduct, but that amount is credited toward FinCEN's $1.2 billion penalty and therefore is not an additional sum to be added to the package total.
- OFAC said the apparent violations involved transactions linked to sanctions programs concerning Russia, Belarus, Iran, Burma, Somalia, narcotics trafficking and global terrorism. Its settlement resolves potential civil liability and requires payment; it does not establish criminal guilt.
- Bank of America told Associated Press that it had invested billions of dollars in technology and dedicated thousands of employees to combating financial crime, and said it was committed to completing the work regulators required. Whether the ordered remediation prevents future reporting and sanctions failures has not yet been measured.

## SIGNIFICANCE

The package is a large implemented federal financial-enforcement outcome and documents failures in systems intended to flag illicit finance and blocked transactions. The overlapping OCC credit matters because adding the agency figures would overstate the amount, while the deterrent and compliance effects remain unmeasured.

## GOALPOST / RESPONSE

Treasury says the coordinated penalties enforce the Bank Secrecy Act and sanctions rules and require durable remediation. Tests include payment, timely suspicious-activity reporting, independent validation of controls, repeat violations, sanctions-screening performance and later supervisory findings.

## MAYBE / THEREFORE

Maybe the size and coordinated structure of the resolutions produce lasting compliance improvements, or they may function mainly as a costly settlement if control failures recur. Therefore the agencies imposed and settled more than $1.21 billion in penalties—not $1.96 billion, not a criminal conviction and not proof that remediation has succeeded.


## SOURCES

- [Treasury Department — record enforcement actions against Bank of America](https://home.treasury.gov/news/press-releases/sb0657) — primary consolidated enforcement announcement and agency penalty terms
- [FinCEN — $1.2 billion Bank of America anti-money-laundering penalty](https://www.fincen.gov/news/news-releases/fincen-assesses-12-billion-penalty-against-bank-america) — primary consent order, penalty and remedial-action announcement
- [OFAC — Bank of America sanctions settlement](https://ofac.treasury.gov/recent-actions/20261013_33) — primary enforcement action and settlement over 475 apparent sanctions violations
- [Associated Press — U.S. imposes Bank of America anti-money-laundering and sanctions penalties](https://apnews.com/article/29013b2c8f08a3a8d579a96721ed1aa4) — independent enforcement reporting and company response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
