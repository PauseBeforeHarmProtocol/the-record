# Treasury agencies impose $1.21 billion Bank of America enforcement package

**Entry ID:** NAT-2026-10-13-008
**Date:** October 13, 2026
**Checked:** 2026-10-14 11:55 AM EDT
**Evidence state:** primary Treasury, FinCEN and OFAC enforcement records plus Associated Press and Reuters reporting and company response; penalties imposed and remediation activity reported, sustained effectiveness unmeasured
**Review state:** current-standard-reviewed

The coordinated anti-money-laundering and sanctions resolutions include a $1.2 billion FinCEN penalty, an overlapping OCC assessment and an $11.6 million OFAC settlement.

## THE FACTS

- The Treasury Department announced coordinated enforcement actions totaling more than $1.21 billion against Bank of America for anti-money-laundering and sanctions-compliance failures. FinCEN assessed a $1.2 billion civil money penalty, and OFAC announced an approximately $11.6 million settlement covering 475 apparent sanctions violations.
- FinCEN's consent order says the bank maintained an ineffective anti-money-laundering program and failed to timely file thousands of suspicious-activity reports. The Office of the Comptroller of the Currency separately assessed $750 million for related conduct, but that amount is credited toward FinCEN's $1.2 billion penalty and therefore is not an additional sum to be added to the package total.
- OFAC said the apparent violations involved transactions linked to sanctions programs concerning Russia, Belarus, Iran, Burma, Somalia, narcotics trafficking and global terrorism. Its settlement resolves potential civil liability and requires payment; it does not establish criminal guilt.
- Bank of America told Associated Press that it had invested billions of dollars in technology and dedicated thousands of employees to combating financial crime, and said it was committed to completing the work regulators required. Whether the ordered remediation prevents future reporting and sanctions failures has not yet been measured.
- Bank of America told analysts it had repositioned about 1,000 employees to address the consent-order work and had made substantial investments in people and technology. The bank said much of the work was completed and that remediation spending was already reflected in its expense outlook; these are company implementation claims, while an outside former federal attorney said regulators will require sustained compliance rather than temporary corrective measures.

## SIGNIFICANCE

The package is a large implemented federal financial-enforcement outcome and documents failures in systems intended to flag illicit finance and blocked transactions. The newly reported staffing shift is concrete remediation activity, but company-reported effort is not regulator-validated effectiveness; the overlapping OCC credit still prevents overstating the penalty total.

## GOALPOST / RESPONSE

Treasury says the penalties and consent order require durable remediation, while Bank of America says it has reassigned about 1,000 employees and invested in people and technology. Tests include independent review, timely suspicious-activity reporting, regulator validation, repeat violations, sanctions-screening performance and sustained compliance.

## MAYBE / THEREFORE

Maybe the staffing and technology changes produce lasting compliance improvements, or they may document effort without curing the underlying control failures. Therefore agencies imposed and settled more than $1.21 billion and the bank reports substantial remediation—not $1.96 billion, a criminal conviction or proof that regulators have accepted the fixes.


## SOURCES

- [Treasury Department — record enforcement actions against Bank of America](https://home.treasury.gov/news/press-releases/sb0657) — primary consolidated enforcement announcement and agency penalty terms
- [FinCEN — $1.2 billion Bank of America anti-money-laundering penalty](https://www.fincen.gov/news/news-releases/fincen-assesses-12-billion-penalty-against-bank-america) — primary consent order, penalty and remedial-action announcement
- [OFAC — Bank of America sanctions settlement](https://ofac.treasury.gov/recent-actions/20261013_33) — primary enforcement action and settlement over 475 apparent sanctions violations
- [Associated Press — U.S. imposes Bank of America anti-money-laundering and sanctions penalties](https://apnews.com/article/29013b2c8f08a3a8d579a96721ed1aa4) — independent enforcement reporting and company response
- [Reuters — Bank of America describes consent-order remediation](https://www.reuters.com/legal/government/bank-america-says-it-has-completed-lot-work-consent-order-2026-10-14/) — independent reporting of company staffing and implementation claims with outside compliance context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
