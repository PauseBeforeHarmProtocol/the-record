# Study finds rapid growth in documented use of unapproved BPC-157

**Entry ID:** NAT-2026-09-15-018
**Date:** September 7–16, 2026
**Checked:** 2026-09-16 12:33 PM EDT
**Evidence state:** non-peer-reviewed retrospective clinical-note study with physician validation, Reuters independent review and primary FDA advisory materials; use trend measured, efficacy and regulatory outcome unresolved
**Review state:** current-standard-reviewed

A non-peer-reviewed clinical-note study found a 33-fold rise in newly documented users; sparse outcomes, co-treatments and incomplete capture prevent efficacy or population-wide safety conclusions as FDA weighs compounding.

## THE FACTS

- A September 7 non-peer-reviewed preprint analyzed de-identified clinical notes for 15.2 million patients and identified 1,039 with documented BPC-157 use. Newly confirmed users rose from four in the first quarter of 2020 to 134 in the first quarter of 2026, a roughly 33-fold increase within the observed network.
- The study used a large-language-model extraction process with physician validation. Manual review estimated 87.2% accuracy for confirmed-use classification in a 47-note sample; BPC-157 lacks a National Drug Code, and the authors said clinical notes probably capture only a fraction of actual use.
- Response direction was unavailable for 685 of the 1,039 users, and about half had documented co-use of other therapeutic agents. The authors said reported improvement cannot establish efficacy or separate BPC-157 effects from other drugs, procedures, physical therapy, placebo effects or documentation and selection bias.
- Reuters reported 10 serious adverse-event reports associated with BPC-157 in FDA's monitoring database since 2021, eight in 2026. Reports establish signals submitted during use, not verified causation, incidence or comparative risk, and underreporting remains possible.
- BPC-157 is not FDA approved. An FDA advisory committee voted 8-6 with one abstention in July to recommend placing it on the pharmacy-compounding bulk list after encouragement from Health Secretary Robert F. Kennedy Jr.; the recommendation is nonbinding, FDA staff documented characterization and safety concerns, and no final FDA decision existed by cutoff.

## SIGNIFICANCE

The study supplies the first large clinical-note measure of rapidly growing use while showing how little reliable efficacy and safety evidence accompanies the trend. That evidence is directly relevant to an administration-backed effort to broaden legal compounding, but it does not itself decide the pending FDA action.

## GOALPOST / RESPONSE

Kennedy and compounding supporters argue regulated pharmacy access could replace riskier gray-market supply and expand patient choice; FDA staff have emphasized insufficient human evidence, product characterization and immunogenicity concerns. The tests are a final FDA decision, product-quality standards, prospective trials, structured exposure reporting, adverse-event rates and comparative outcomes.

## MAYBE / THEREFORE

Maybe regulated compounding improves product quality while trials clarify benefit, or broader access may accelerate use before efficacy and safety are established. Therefore the record documents a steep rise in one network and a pending advisory recommendation—not FDA approval, national prevalence, clinical effectiveness or causal safety rates.


## SOURCES

- [Preprints.org — retrospective study of documented BPC-157 use](https://www.preprints.org/manuscript/202609.0501) — non-peer-reviewed retrospective observational study using de-identified clinical notes and physician validation
- [Reuters — measured rise in documented BPC-157 use](https://www.reuters.com/legal/litigation/use-untested-wolverine-peptide-backed-by-us-health-secretary-kennedy-rise-study-2026-09-15/) — independent reporting on the preprint, FDA status, advisory vote and adverse-event reports
- [FDA — Pharmacy Compounding Advisory Committee BPC-157 materials](https://www.fda.gov/advisory-committees/advisory-committee-calendar/july-23-24-2026-meeting-pharmacy-compounding-advisory-committee-07232026) — primary agency meeting page, briefing materials and advisory-committee record
- [FDA — bulk substances in compounding that may present safety risks](https://www.fda.gov/drugs/human-drug-compounding/certain-bulk-drug-substances-use-compounding-may-present-significant-safety-risks) — primary agency safety-status page for BPC-157 and other bulk substances

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
