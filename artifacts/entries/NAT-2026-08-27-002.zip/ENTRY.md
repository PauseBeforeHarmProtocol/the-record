# DEA places new anesthetic cipepofol in Schedule IV

**Entry ID:** NAT-2026-08-27-002
**Date:** August 27, 2026
**Checked:** 2026-08-27 6:00 AM EDT
**Evidence state:** published DEA interim final rule effective August 27, 2026, incorporating FDA approval and HHS and DEA scientific reviews; Schedule IV control implemented, post-market outcomes and final rule pending
**Review state:** current-standard-reviewed

An immediately effective interim final rule controls the newly FDA-approved general anesthetic while accepting comments through September 28.

## THE FACTS

- DEA issued an interim final rule placing cipepofol, marketed as Cypsedo, in Schedule IV effective August 27, 2026. FDA approved the drug on May 29 for induction of general anesthesia in adults undergoing surgery, and comments on the scheduling rule are due September 28.
- The rule subjects manufacture, distribution, dispensing, research, import-export activity, prescriptions, inventories, records, and security to Schedule IV controls. Under the statutory new-drug process, DEA was required to act within 90 days after receiving the later of FDA approval notice or HHS's scheduling recommendation.
- HHS and DEA found cipepofol has accepted medical use, a low abuse potential relative to Schedule III drugs, and limited dependence risk comparable to propofol. They reported no known U.S. diversion or abuse and no reported misuse among an estimated 14.5 million patients treated in China, while animal and human studies showed reinforcing and drug-liking effects similar to propofol.

## SIGNIFICANCE

The rule establishes the federal handling conditions under which a new anesthetic enters the U.S. market. It imposes nationwide controls based largely on comparative and premarket evidence while allowing lawful medical use, making post-market safety, diversion, availability, and compliance outcomes measurable.

## GOALPOST / RESPONSE

DEA and HHS say Schedule IV appropriately balances accepted medical use against predicted abuse and dependence risks similar to propofol. A countervailing concern is whether controls inferred from comparator studies are proportionate when no actual cipepofol abuse was reported. Post-market adverse-event and diversion data, anesthesia access, compliance costs, hearing requests, and the later final rule are the tests.

## MAYBE / THEREFORE

Maybe Schedule IV controls will prevent diversion without delaying legitimate anesthesia use, especially because they are less restrictive than Schedules I through III. Therefore the record distinguishes an implemented legal control from evidence of actual U.S. misuse and preserves the interim status pending comments and a final rule.


## SOURCES

- [Federal Register — interim final rule placing cipepofol in Schedule IV](https://www.federalregister.gov/documents/2026/08/27/2026-17536/schedules-of-controlled-substances-placement-of-cipepofol-in-schedule-iv) — primary interim final rule, HHS and DEA scientific findings, and immediate handling requirements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
