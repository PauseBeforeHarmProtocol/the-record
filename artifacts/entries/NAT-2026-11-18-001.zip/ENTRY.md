# White House announces $400 million Philippine military-financing use and pursues $2 billion loan

**Entry ID:** NAT-2026-11-18-001
**Date:** November 18, 2026
**Checked:** 2026-11-18 6:08 PM EST
**Evidence state:** official White House fact sheet plus independent Reuters reporting; $400 million use announced and loan package proposed, with no inspected obligation, disbursement or signed loan instrument
**Review state:** current-standard-reviewed

The White House said the United States will use $400 million in Foreign Military Financing for Philippine capabilities and will pursue a separate loan package above $2 billion; obligation, disbursement and loan terms remain unverified.

## THE FACTS

- A November 18 White House fact sheet announced that the United States will use $400 million in Foreign Military Financing for the Philippine military, identifying long-range fires, command and control, critical infrastructure and multi-domain drones as intended capability areas.
- The same fact sheet said the two governments will pursue a Foreign Military Financing loan package of more than $2 billion. 'Will pursue' records a proposal or commitment to negotiate, not a signed loan, completed congressional process, obligation or disbursement.
- Reuters independently reported Trump's announcement that the United States was expanding defense cooperation with the Philippines and his statement that more than $5 billion in arms sales had been approved. The inspected reporting did not establish that all approved sales were contracted, delivered or financed by the newly announced $400 million.
- The fact sheet also announced exploration of a civil-nuclear intergovernmental agreement and Philippine modernization of Basco Airport. Those announcements are retained as related prospective cooperation, not completed nuclear construction or a U.S.-implemented airport project.

## SIGNIFICANCE

The announcement is a material security-assistance commitment to a treaty ally amid South China Sea tensions and could channel substantial U.S. financing toward military capabilities. Its fiscal and operational effect remains contingent on legal authority, notifications, contracting and delivery, so announced use and proposed lending are kept separate from implementation.

## GOALPOST / RESPONSE

The administration says the financing will strengthen deterrence in the South China Sea, support U.S. defense jobs and protect taxpayers, while the broader alliance advances a free and open Indo-Pacific. The tests are the legal source of the $400 million, congressional notifications and approvals, signed loan terms, obligations and disbursements, contracts and delivery milestones, Philippine acceptance and measured capability or deterrence outcomes.

## MAYBE / THEREFORE

Maybe the announced financing becomes a timely, reciprocal alliance investment and the loan protects U.S. taxpayers, or negotiations and implementation may narrow, delay or fail. Therefore the evidence establishes a $400 million intended FMF use and a proposed loan package above $2 billion—not completed spending, a signed loan, delivered weapons or measured deterrence.


## SOURCES

- [Fact Sheet: President Donald J. Trump Secures Historic Economic Deals for American Workers and Strengthens America's Leadership in Asia](https://www.whitehouse.gov/fact-sheets/2026/11/fact-sheet-president-donald-j-trump-secures-historic-economic-deals-for-american-workers-and-strengthens-americas-leadership-in-asia/) — primary administration announcement; distinguishes intended FMF use and a proposed loan package from completed obligation or disbursement
- [Trump says U.S. is expanding defence cooperation with Philippines](https://www.reuters.com/world/asia-pacific/trump-says-us-is-expanding-defence-cooperation-with-philippines-2026-11-18/) — independent reporting on the administration's defense-cooperation and civil-nuclear announcements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
