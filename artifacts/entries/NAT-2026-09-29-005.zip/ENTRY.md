# Treasury finalizes automatic establishment of Trump Accounts

**Entry ID:** NAT-2026-09-29-005
**Date:** September 29, 2026
**Checked:** 2026-09-29 11:57 PM EDT
**Evidence state:** primary Treasury and IRS temporary regulations filed for public inspection plus independent Wall Street Journal reporting; rule finalized for September 30 effectiveness, enrollment, claims, contributions and outcomes not yet measured
**Review state:** current-standard-reviewed

Temporary regulations authorize Treasury to establish accounts automatically for eligible minors without a prior election; claiming the account and receiving the separate $1,000 pilot contribution still require additional steps.

## THE FACTS

- Treasury and the Internal Revenue Service filed temporary regulations on September 29 implementing Internal Revenue Code section 530A. The rule is scheduled for September 30 publication and becomes effective on publication; as of this cutoff it was finalized and publicly filed, not yet effective.
- The regulations authorize the Treasury secretary to make an automatic election for an eligible individual under 18 with a Social Security number when no prior account election exists. These automatically established accounts are held through a master group trust with account-specific records until an authorized person authenticates authority and claims the account.
- The separate $1,000 federal pilot contribution for qualifying children born in 2025 through 2028 is not triggered solely by automatic establishment. An authorized person must make the required pilot-contribution election, and ordinary contribution and distribution rules continue to apply.
- Treasury's regulatory analysis estimated about 73.37 million eligible children in 2026 and projected only 5.6 million electronic account-election filings before July 30 absent the automatic process. The Wall Street Journal reported that the rule was expected to add more than 60 million children to the account system.
- Automatic establishment does not prove that families will claim the accounts, make contributions, receive the pilot contribution, earn gains or experience improved long-term savings outcomes.

## SIGNIFICANCE

The temporary rule changes the program from an opt-in account-creation model to automatic federal establishment for a very large population, potentially expanding access while placing authentication, privacy, investment administration and family participation at the center of implementation.

## GOALPOST / RESPONSE

Treasury and the IRS say automatic establishment addresses low anticipated participation, including among nonfilers and families with limited resources, while the master trust permits administration without disclosing tax-return information to outside financial institutions. Accounts created, accounts claimed, pilot elections, contributions, fees, investment performance, complaints and privacy or operational incidents are the tests.

## MAYBE / THEREFORE

Maybe automatic establishment substantially broadens access to tax-advantaged savings, or unclaimed accounts and administrative friction may limit practical benefit while creating new oversight risks. Therefore the record establishes a finalized automatic-account mechanism—not universal participation, receipt of the $1,000 contribution or improved household wealth.


## SOURCES

- [Federal Register — Trump Accounts temporary regulations (TD 10056)](https://www.federalregister.gov/d/2026-20026) — official temporary regulations filed for public inspection; scheduled publication and effectiveness September 30
- [Wall Street Journal — Treasury will automatically establish Trump Accounts](https://www.wsj.com/politics/policy/treasury-will-auto-enroll-60-million-in-trump-accounts-a5f82421) — independent reporting on the filed temporary regulations and projected enrollment

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
