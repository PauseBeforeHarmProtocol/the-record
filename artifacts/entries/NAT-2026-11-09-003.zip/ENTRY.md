# DOJ sues Glendale over concealed-carry permit fees and review process

**Entry ID:** NAT-2026-11-09-003
**Date:** November 9, 2026
**Checked:** 2026-11-10 6:10 AM EST
**Evidence state:** primary DOJ litigation announcement plus independent local reporting; complaint allegations reported, city response and judicial disposition unresolved
**Review state:** current-standard-reviewed

The federal complaint alleges that high application costs and subjective checks violate the Second Amendment and federal law; the city had not provided a reported response and no court ruling had issued.

## THE FACTS

- On November 9, DOJ sued the City of Glendale, California, in federal court over its concealed-carry permit system. DOJ says it is enforcing the Second Amendment, 34 U.S.C. §12601 and Executive Order 14206. The filing is an allegation, not a liability finding.
- DOJ alleges total initial-application costs range from $1,971 to $2,106 and two-year renewal costs from $1,271 to $1,406, compared with the city’s prior $100 initial and $25 renewal fees. The totals include required steps described by DOJ; their legal reasonableness remains for the court to decide.
- The department also challenges reference interviews, psychological examinations, applicant interviews and review of public statements including social media, alleging Glendale publishes no objective standards for those checks and that the system conflicts with New York State Rifle & Pistol Association v. Bruen.
- MyNewsLA independently reported that the case was filed in Los Angeles federal court and that Glendale’s city attorney did not immediately provide a response. No answer, injunction, merits ruling, permit-policy change or remedy was located by cutoff.

## SIGNIFICANCE

The lawsuit is a federal intervention in local firearm licensing that tests how constitutional standards, fee levels and police discretion constrain concealed-carry administration. Its practical effect depends on court action and any resulting policy change, not DOJ’s filing alone.

## GOALPOST / RESPONSE

DOJ says the fees and subjective checks create unconstitutional barriers to a fundamental right. Glendale had no reported response by cutoff. The tests are the complaint and answer, itemized fee record, objective standards, permit-processing evidence, judicial findings, any injunction or settlement and verified policy changes.

## MAYBE / THEREFORE

Maybe the court finds Glendale’s costs or procedures unconstitutional and orders reform, or the city may justify some or all requirements as lawful administration. Therefore the record establishes a filed federal challenge and DOJ’s stated figures—not an adjudicated violation, injunction, refund or completed permit change.


## SOURCES

- [DOJ — lawsuit challenging Glendale concealed-carry permit fees and processes](https://www.justice.gov/opa/pr/justice-department-sues-city-glendale-california-violating-citizens-second-amendment-rights) — primary agency litigation announcement
- [MyNewsLA — DOJ sues Glendale over concealed-carry permit fees](https://mynewsla.com/weather/2026/11/09/doj-sues-city-of-glendale-over-concealed-carry-permit-fees/) — independent local reporting on filed federal lawsuit and city response gap

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
