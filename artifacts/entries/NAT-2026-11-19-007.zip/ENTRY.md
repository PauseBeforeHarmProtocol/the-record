# Interior completes American Samoa offshore-minerals auction

**Entry ID:** NAT-2026-11-19-007
**Date:** November 19, 2026
**Checked:** 2026-11-20 7:13 AM EST
**Evidence state:** official auction results and final leasing notice, a primary pre-sale ESA ruling, and independent Associated Press reporting; sale completed, final lease issuance and later activity approvals unresolved
**Review state:** current-standard-reviewed

The federal auction generated $6 million in high bids for two American Samoa seafloor areas, but winners remain provisional and neither lease issuance nor the auction authorizes testing or mining.

## THE FACTS

- The Interior Department's Marine Minerals Administration completed its November 19 oral auction for two offshore mineral areas east of American Samoa. The agency reported $6 million in combined high bids for approximately 31,503,235 acres; completing the auction does not establish that executed leases have been finally issued.
- Associated Press reported that Wetstone U.S. Ventures placed the only bids, $3 million for each area. The final leasing notice says auction winners are provisional and that final issuance follows the post-sale acceptance and payment process; each issued lease would have a 20-year primary term.
- The agency expressly says lease issuance would not authorize delineation, testing or mining. An issued lease would allow limited preliminary activity and an exclusive right to submit later plans, while proposed testing, delineation or commercial mining would require further environmental review and technical approval.
- On November 16, a federal district judge vacated the National Marine Fisheries Service's Endangered Species Act letter of concurrence after finding its review unlawfully narrow. The auction proceeded while the agency began further consultation; that order and additional lawsuits leave the sale and any eventual leases subject to unresolved legal challenge.

## SIGNIFICANCE

The auction is the first operative federal sale of its kind and covers a very large U.S. seafloor area, creating a concrete path toward exclusive mineral rights. Its lifecycle and environmental limits matter because a completed auction is not an approved mine, and a pre-sale ESA ruling creates immediate legal uncertainty.

## GOALPOST / RESPONSE

Interior describes the sale as a first step toward domestic critical-mineral supply and says future development will face U.S. safety and environmental standards. The tests are bid acceptance, executed lease issuance, payment, renewed ESA consultation, litigation, approved survey or mining plans, environmental safeguards, production, royalties and verified supply-chain effects.

## MAYBE / THEREFORE

Maybe the lease process will produce useful resource data and eventually diversify mineral supply under enforceable safeguards, or litigation, environmental review, economics and technical risk may prevent or narrow development. Therefore the government completed an auction and identified provisional high bidders; it did not finally issue every lease, approve testing or mining, begin commercial extraction or measure supply-chain gains.


## SOURCES

- [Interior Department — American Samoa offshore critical-minerals lease sale results](https://www.boem.gov/newsroom/press-releases/department-interior-completes-first-ever-offshore-critical-minerals-lease) — primary agency release reporting high bids, acreage and limits of lease issuance
- [Federal Register — American Samoa OCS Pacific Mineral Lease Sale 1 final leasing notice](https://www.govinfo.gov/content/pkg/FR-2026-10-20/html/2026-21462.htm) — primary final leasing notice with acreage, auction, provisional-award and post-sale issuance terms
- [Fa'asao Amerika Samoa v. NMFS — order vacating ESA letter of concurrence](https://cases.justia.com/federal/district-courts/hawaii/hidce/1:2026cv00438/179367/62/0.pdf) — primary summary-judgment order in No. 1:26-cv-00438-JAO-KJM
- [Associated Press — American Samoa offshore-minerals auction and unresolved legal challenges](https://apnews.com/article/deepsea-mining-american-samoa-oceans-trump-auction-1dad5cc71cd5b683c5d418edc3b78563) — independent reporting on the auction, bidder, lease lifecycle and environmental litigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
