# CMS finalizes 2027 outpatient, site-neutral and 340B Medicare payment changes

**Entry ID:** NAT-2026-11-04-003
**Date:** November 4, 2026
**Checked:** 2026-11-05 12:07 AM EST
**Evidence state:** CMS final-rule fact sheet and Federal Register public-inspection record, with an attributed AHA stakeholder summary and response
**Review state:** current-standard-reviewed

The rule raises baseline OPPS and ASC rates while changing off-campus imaging and 340B drug reimbursement nationwide.

## THE FACTS

- On November 4, CMS issued its CY 2027 hospital outpatient and ambulatory surgical center final rule with comment period, CMS-1850-FC. The public-inspection document was scheduled for Federal Register publication November 6. This same-day action occurred before the prior archive cutoff and is recorded as a disclosed backfill discovered and inspected in this run.
- For hospitals and ASCs meeting applicable quality-reporting requirements, CMS finalized 2.3% payment-rate updates, based on a projected 3.2% market-basket increase reduced by a 0.9 percentage-point productivity adjustment.
- CMS extended site-neutral payment to imaging without contrast in excepted off-campus hospital departments, using Physician Fee Schedule-equivalent rates and exempting rural sole community hospitals. CMS projects about $260 million in lower 2027 Part B spending, including about $70 million each in lower beneficiary premiums and lower cost-sharing; these are estimates, not measured savings.
- For separately payable drugs acquired through the 340B program, CMS finalized payment at average sales price minus 28%. It projects $4.35 billion less in Original Medicare drug payments and $1.1 billion less in beneficiary drug payments in the first year, with an average $900 saving for a qualifying beneficiary. Statute requires budget neutrality, so CMS says non-drug OPPS payments will rise by an equivalent amount.
- The rule also accelerates the annual offset used to recoup the earlier 340B remedy from 0.5% to 2%, removes 637 additional services from the inpatient-only list, expands selected prior authorization and provider-identifier requirements and gives safety measures greater weight in hospital star ratings. The AHA objected that the hospital update is inadequate and said the site-neutral and 340B changes may strain rural and underserved access; those are attributed stakeholder warnings, not measured outcomes.

## SIGNIFICANCE

This rule reallocates billions of projected Medicare payments among drugs and other outpatient services and expands site-neutral payment. It can lower some beneficiary liabilities while reducing particular hospital revenue streams, making distributional effects and access consequences as important as the headline aggregate projections.

## GOALPOST / RESPONSE

CMS says acquisition-cost evidence justifies lower 340B drug reimbursement and that site-neutral payment prevents beneficiaries from paying more solely because of setting. Hospitals argue that outpatient departments treat more complex patients and that the reductions threaten access. The tests are actual claims, beneficiary costs, hospital service availability and rural or safety-net access after implementation.

## MAYBE / THEREFORE

Maybe budget-neutral non-drug increases, statutory exemptions and service migration offset some hospital losses, or litigation and later rulemaking alter implementation. Therefore the archive records finalized payment formulas and agency projections, not guaranteed beneficiary savings or a proven access loss.


## SOURCES

- [CMS — CY 2027 OPPS and ASC final rule fact sheet](https://www.cms.gov/newsroom/fact-sheets/calendar-year-2027-hospital-outpatient-prospective-payment-system-opps-ambulatory-surgical-center-0) — primary final-rule fact sheet stating payment, site-neutral, 340B and quality policies
- [Federal Register public inspection — CMS-1850-FC OPPS and ASC final rule with comment period](https://www.federalregister.gov/public-inspection/2026-22739/medicare-program-hospital-outpatient-prospective-payment-system-ambulatory-surgical-center-payment) — primary public-inspection final rule with comment period and scheduled publication record
- [AHA — CMS finalizes CY 2027 outpatient payment, site-neutral and 340B changes](https://www.aha.org/news/headline/2026-11-04-cms-finalizes-increases-medicare-hospital-outpatient-department-payment-rates-changes-site-neutral-and) — stakeholder summary and attributed hospital-sector response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
