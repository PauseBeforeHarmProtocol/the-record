# State Department pauses immigrant-visa appointments worldwide for public-charge training

**Entry ID:** NAT-2026-08-26-001
**Date:** August 26, 2026
**Checked:** 2026-08-26 12:02 PM EDT
**Evidence state:** named State Department spokesperson independently reported by Reuters and The Washington Post; worldwide immigrant-visa appointment pause confirmed, duration and operational directive not public
**Review state:** current-standard-reviewed

A department spokesperson confirmed the global pause applies to immigrant visas; no public resumption date or directive was available at the checked time.

## THE FACTS

- The State Department paused immigrant-visa appointments at U.S. embassies and consulates worldwide while consular staff receive additional training on public-charge screening, according to a department spokesperson quoted independently by Reuters and The Washington Post.
- Reuters corrected its initial description to clarify that the pause covers immigrant-visa appointments, not all visa categories. Existing appointments were being adjusted, but the department publicly provided no duration, implementation memo, or official resumption date at the checked time.
- The administration says the training is intended to ensure immigrants will not become public charges and to apply existing admissibility law consistently. Immigration advocates and former officials quoted by the Post said a worldwide pause imposes delays on applicants and questioned the need for a blanket suspension.

## SIGNIFICANCE

The implemented pause temporarily interrupts a worldwide pathway to lawful permanent residence and may create backlogs, missed medical or document windows, and family or employment disruption. Its scale and duration remain unmeasured because the government has not published appointment counts or a restart timetable.

## GOALPOST / RESPONSE

The administration says enhanced training is necessary for consistent public-charge screening and protection of public resources. Critics say officers already apply the law and that a global pause is overbroad. The written directive, resumption date, appointment backlog, waiver handling, and subsequent refusal or approval data are the evidence tests.

## MAYBE / THEREFORE

Maybe the pause will be brief and produce more consistent adjudications without materially reducing lawful immigration, and internal operational details may follow. Therefore the record limits the finding to an implemented pause in immigrant-visa appointments, not all visas, and does not adopt an anonymously reported end date as established fact.


## SOURCES

- [Reuters — State Department pauses immigrant-visa appointments worldwide](https://www.reuters.com/legal/government/trump-administration-issues-pause-visa-appointments-applicants-worldwide-2026-08-26/) — independent reporting quoting a department spokesperson; corrected to immigrant visas only
- [The Washington Post — worldwide immigrant-visa appointment pause](https://www.washingtonpost.com/immigration/2026/08/26/state-dept-pauses-immigrant-visa-appointments-worldwide-says-staff-need-training/) — independent reporting and stakeholder response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
