# Appeals court keeps DOJ subpoenas to Letitia James's office blocked

**Entry ID:** NAT-2026-08-21-002
**Date:** August 21, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** federal appellate ruling described in independent reporting; further appeal announced

A divided panel held that the subpoenas could not proceed because acting U.S. Attorney John Sarcone was serving unlawfully.

## THE FACTS

- The U.S. Court of Appeals for the Second Circuit, in a 2–1 decision, upheld an order blocking Justice Department subpoenas seeking records from New York Attorney General Letitia James's office.
- The subpoenas concerned James's civil cases involving Trump and the National Rifle Association. The court agreed that John Sarcone was not lawfully serving as U.S. attorney when his office pursued them.
- Reuters described the decision as the third appellate rejection of an administration effort to bypass the ordinary appointment process for a U.S. attorney. The Justice Department said it intended to seek Supreme Court review.

## SIGNIFICANCE

The ruling links prosecutorial power to the constitutional and statutory appointment process. It also constrains an investigation touching an elected official who previously brought a civil case against the president, where independence and appearance of retaliation are central accountability concerns.

## GOALPOST / RESPONSE

The Justice Department maintains that Sarcone's appointment was lawful and that the subpoenas served a legitimate investigation. The court's ruling addresses authority to issue them, not a final judgment on every possible investigative theory; Supreme Court review may change the result.


## SOURCES

- [Reuters — appeals court keeps Letitia James subpoenas blocked](https://www.reuters.com/world/appeals-court-upholds-block-doj-subpoenas-ny-ag-james-office-2026-08-21/) — independent reporting on a federal appellate ruling

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
