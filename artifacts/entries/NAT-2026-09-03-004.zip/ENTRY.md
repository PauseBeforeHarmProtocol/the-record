# GAO finds gaps in Secret Service protection-policy reviews

**Entry ID:** NAT-2026-09-03-004
**Date:** September 3, 2026
**Checked:** 2026-09-03 6:02 PM EDT
**Evidence state:** primary GAO audit with agency responses plus independent Associated Press reporting; findings issued and agencies concurred, recommendations remain open
**Review state:** current-standard-reviewed

The federal audit found overdue policy reviews and incomplete documentation of incident responses; four recommendations remain open despite agency concurrence.

## THE FACTS

- The Government Accountability Office publicly released report GAO-26-108455 on September 3 after reviewing Secret Service protection policies, incident records and coordination for fiscal years 2015 through 2025.
- GAO identified 83 security incidents during the period. The Secret Service updated protection policies in response to 25, but GAO found the agency did not require documentation of its analysis when an incident produced no policy change, limiting assurance that every event was systematically assessed.
- Eight of 22 protection policies reviewed by GAO had not been reviewed or updated within the agency's required four-year cycle. GAO also found the 1991 memorandum coordinating Secret Service and State Department Diplomatic Security protection responsibilities had not been updated.
- GAO made four recommendations concerning incident-review documentation, timely policy reviews and interagency coordination. The Department of Homeland Security and State Department concurred, but all four recommendations were listed as open and not implemented at publication.
- The audit period spans multiple administrations and includes, but is not limited to, protection failures surrounding the 2024 attempted assassination of Trump. The findings therefore measure institutional controls across a decade rather than attributing every gap to the current administration.

## SIGNIFICANCE

The audit documents measurable governance weaknesses in an agency responsible for presidential and national-event security. Concurrence establishes agreement on corrective direction, but open recommendations mean the control gaps were not yet shown to be fixed.

## GOALPOST / RESPONSE

The agencies concurred with GAO's recommendations. Updated directives, documented incident analyses, on-time four-year reviews, a revised Secret Service-State agreement, implementation evidence and future incident performance are the tests.

## MAYBE / THEREFORE

Maybe the missing documentation and overdue reviews reflect administrative lag while operational lessons were still applied, or they may signal recurring weaknesses that leave protection practices inconsistent. Therefore the record establishes GAO's decade-wide findings and four open recommendations—not that every incident caused a failure, that no reforms occurred, or that concurrence completed remediation.


## SOURCES

- [GAO — Secret Service protection policy review and incident-response findings](https://www.gao.gov/products/gao-26-108455) — primary federal audit with findings, recommendations and agency responses
- [Associated Press — GAO finds Secret Service policy-review gaps](https://apnews.com/article/secret-service-trump-policy-butler-025f73769cfaebf9e4ed4256e8b79507) — independent reporting on the audit's scope, findings and open recommendations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
