# DOJ adopts position against federal handgun-sale ban for ages 18–20

**Entry ID:** NAT-2026-09-18-009
**Date:** September 18, 2026
**Checked:** 2026-09-18 6:32 PM EDT
**Evidence state:** primary DOJ announcement and complete Office of Legal Counsel opinion plus independent Associated Press reporting; executive-branch legal position implemented, statutory and judicial status unchanged
**Review state:** current-standard-reviewed

An Office of Legal Counsel opinion directs the executive branch not to criminally enforce the federal dealer restriction against otherwise law-abiding young adults; Congress did not repeal the statutes and no Supreme Court ruling resulted.

## THE FACTS

- The Justice Department's Office of Legal Counsel issued a 49-page opinion concluding that 18 U.S.C. sections 922(b)(1) and 922(c)(1) violate the Second Amendment as applied to otherwise law-abiding 18-to-20-year-olds who seek to acquire handguns from federally licensed dealers.
- DOJ announced that the provisions may not be criminally enforced against licensed dealers in those circumstances. The opinion is the executive branch's authoritative legal position for its own enforcement; it did not repeal the statutes, invalidate state age limits or create a Supreme Court precedent.
- The opinion relied on the administration's reading of Supreme Court history-and-tradition doctrine and said the government had not identified a sufficient founding-era analogue. Associated Press reported that gun-safety groups argued the opinion conflicts with public-safety evidence and existing appellate precedent.
- The action concerns licensed-dealer handgun sales covered by the cited provisions. It does not itself resolve other federal or state restrictions, civil litigation, future prosecutions under different provisions or later judicial review.

## SIGNIFICANCE

The opinion changes federal criminal-enforcement policy for a defined class of handgun transactions without a new act of Congress or controlling Supreme Court judgment, potentially expanding dealer access for adults under 21 while inviting further litigation.

## GOALPOST / RESPONSE

DOJ says the restriction cannot survive the Supreme Court's historical test and that constitutional rights attach at adulthood. Gun-safety advocates argue age limits protect public safety and have judicial support. Dealer guidance, enforcement records, congressional action, lower-court rulings, Supreme Court review and measured safety outcomes are the tests.

## MAYBE / THEREFORE

Maybe courts will accept DOJ's historical analysis and confirm broader handgun access for adults under 21, or other courts may uphold the statutes or narrower limits using a different record. Therefore DOJ adopted a nonenforcement position for specified licensed-dealer sales—not a statutory repeal, nationwide judicial invalidation or proof of the policy's safety effects.


## SOURCES

- [Justice Department — federal handgun-sale restrictions for 18-to-20-year-olds](https://www.justice.gov/opa/pr/justice-department-concludes-federal-ban-handgun-sales-18-20-year-olds-unconstitutional-and) — primary agency announcement
- [Office of Legal Counsel opinion — constitutionality of federal handgun-sale restrictions for 18-to-20-year-olds](https://www.justice.gov/olc/media/1461811/dl) — primary 49-page legal opinion
- [Associated Press — DOJ adopts nonenforcement position on handgun sales to young adults](https://apnews.com/article/justice-department-handguns-young-adults-4056c154c0d93a73fad8c1393e3b3fc2) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
