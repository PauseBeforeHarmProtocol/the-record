# DOJ publishes guidance directing agencies toward English-only operations

**Entry ID:** NAT-2026-11-11-001
**Date:** October 22–November 12, 2026
**Checked:** 2026-11-11 6:10 PM EST
**Evidence state:** Federal Register notice and operative memorandum, original executive order, agency implementation policies and an independent specialist tracker; guidance is in force and open for comment, with agency-by-agency effects and legal challenges unresolved
**Review state:** current-standard-reviewed

The operative memorandum tells agencies to eliminate multilingual help unless law or mission needs require it; comments run through January 11.

## THE FACTS

- A Department of Justice notice placed an October 22 Attorney General memorandum on public inspection on November 11 for November 12 Federal Register publication. The memorandum superseded September guidance and is already directed to executive departments and agencies; the notice requests comments through January 11, 2027 and says DOJ will decide whether changes are desirable.
- The guidance says agencies should conduct official business, public communication, forms, websites, outreach, internal materials and programs solely in English unless multilingual assistance is required by law or necessary to accomplish the agency's mission. It directs agencies to review and eliminate assistance based only on the rescinded Executive Order 13166 when neither condition applies.
- The same memorandum preserves exceptions for applicable law and mission needs including national security, immigration and law enforcement, emergencies, health care, courts, surveys, foreign officials, victims and witnesses. It says any assistance should be limited, cost-effective and normally label English as the authoritative version; it also states that it does not alter or supersede legal obligations.
- The memorandum reports that HUD moved to English-only business and services and that DHS, Education and Treasury had begun removing previously multilingual website material. HUD's published policy confirms broad removal, while GSA retains mission-critical language services and disability obligations. The administration's strongest explanation is cohesion, efficiency and lower translation burdens; access and compliance outcomes have not been measured.

## SIGNIFICANCE

The government-wide guidance can change access to applications, benefits, safety information and public participation for people with limited English proficiency. Its scope is bounded by statutes, court orders, disability law and agency mission determinations, which may produce uneven implementation and litigation.

## GOALPOST / RESPONSE

DOJ says English-first operations promote cohesion and efficiency while preserving legally required or mission-critical assistance. The tests are agency-specific rules and removals, translation contracts and costs, notice and benefit-access errors, emergency and health outcomes, civil-rights enforcement, public comments, revisions and court review.

## MAYBE / THEREFORE

Maybe targeted English-first policies reduce duplication while agencies preserve every necessary service, or broad removals may create avoidable barriers and legal risk for people who cannot effectively use English. Therefore the record establishes operative guidance and documented agency implementation—not a categorical ban on every translation, a final legislative rule, proven savings or lawful elimination of any service required by statute or mission.


## SOURCES

- [Federal Register — Attorney General memorandum on implementing English as the official language](https://www.federalregister.gov/documents/2026/11/12/2026-22966/attorney-general-memorandum-on-implementing-english-as-the-official-language-request-for-information) — primary guidance and request for information; public-inspection text inspected before publication
- [White House — Designating English as the Official Language of the United States](https://www.whitehouse.gov/presidential-actions/2025/03/designating-english-as-the-official-language-of-the-united-states/) — primary executive order and applicable-law boundary
- [GSA — Language Services Policy](https://www.gsa.gov/directives-library/language-access-plan) — primary agency implementation policy and retained mission-critical exceptions
- [HUD — English-only departmental business and services policy](https://www.hud.gov/espanol) — primary agency implementation statement
- [Federal Language Access Tracker — EO 14224 implementation changes](https://accessmultilingual.com/resources/language-access-toolkit/federal-language-access-tracker) — independent specialist tracker with Federal Register and agency citations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
