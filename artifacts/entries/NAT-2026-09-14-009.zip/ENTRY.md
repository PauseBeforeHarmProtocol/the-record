# Big Bend lawsuits challenge DHS fast-track barrier authority; administration seeks Supreme Court intervention

**Entry ID:** NAT-2026-09-14-009
**Date:** September 14–October 21, 2026
**Checked:** 2026-10-21 5:56 PM EDT
**Evidence state:** primary case docket and complaint materials plus Associated Press, Texas Tribune, plaintiff-side reporting and a second report on the emergency application; the filing was reported but not retrieved, no Supreme Court disposition was located, and final merits and project-wide effects remain unresolved
**Review state:** current-standard-reviewed

After a judge preliminarily barred covered barrier and road construction, the administration reportedly filed an emergency Supreme Court application to lift the pause; no Supreme Court disposition or final merits ruling had issued by cutoff.

## THE FACTS

- Conserve Big Bend and six landowners filed Conserve Big Bend v. Department of Homeland Security, No. 1:26-cv-03198, in the U.S. District Court for the District of Columbia on September 14. The complaint challenges DHS and CBP plans for border barriers, roads, lighting, cameras and related infrastructure across the Big Bend sector.
- The plaintiffs allege DHS could not lawfully invoke section 102 of the Illegal Immigration Reform and Immigrant Responsibility Act because the 517-mile Big Bend sector is not an area of ‘high illegal entry.’ Their complaint cites CBP statistics showing the sector accounted for about 1.16% of Southwest-border apprehensions in fiscal years 2021–2025. Those figures and legal conclusions are pleaded allegations, not judicial findings.
- The suit seeks declarations, vacatur of the challenged high-entry determinations and preliminary and permanent injunctions. Filing the complaint did not itself halt construction, decide the legality of statutory waivers or establish a taking of any plaintiff’s property.
- Associated Press reported that the government said no final plans had been selected for Big Bend National Park and that CBP Commissioner Rodney Scott temporarily paused construction-related activity there. The Texas Tribune reported administration officials said they did not plan a 30-foot barrier inside the parks but still intended vehicle barriers and detection technology in limited areas; plans and contracts outside the parks remain distinct.
- This case is separate from earlier Big Bend suits concerning religious, environmental and flood risks. Its narrower theory targets the sector-wide factual and statutory basis for expedited authority, and the archive does not merge those different plaintiffs, projects or requested remedies into one court event.
- On September 18, Associated Press reported after visiting the area that CBP said installation of steel panels was underway on the 47-mile Big Bend 1 project in Hudspeth County. That work is outside Big Bend National Park, where a separate project remained temporarily paused; the lawsuit had not halted the reported installation by cutoff.
- On October 2, U.S. District Judge Kathleen Cardone granted a preliminary injunction in Friends of the Ruidosa Church v. Mullin, No. 3:26-cv-01099, a separate Western District of Texas case. The order temporarily bars the federal defendants from constructing border barrier, road and related infrastructure covered by that case in the Big Bend region while litigation proceeds.
- Associated Press and the plaintiffs reported that the court found the plaintiffs likely to succeed on at least one claim, likely to face irreparable harm without relief, and favored by the equities and public interest. Those preliminary-injunction findings preserve the status quo; they do not decide final liability, permanently invalidate DHS authority or resolve the separate District of Columbia suit.
- Associated Press reported that DHS and CBP did not immediately respond to requests for comment on the injunction. The administration’s previously documented position remains that the infrastructure is needed for border security; later agency filings, an appeal, compliance and construction records will determine the order’s practical reach.
- On October 21, Associated Press and The Washington Sun reported that the administration filed an emergency application asking the Supreme Court to lift the October 2 preliminary injunction while the litigation continues. The application was reported filed, but the filing itself was not retrieved by cutoff and the Supreme Court had not issued a disposition.

## SIGNIFICANCE

The litigation has advanced from challenges to DHS’s statutory predicate and project design to temporary judicial relief and a reported emergency Supreme Court application. The injunction still pauses covered construction by cutoff, but it is not a final merits ruling and the emergency request does not itself lift the order or resolve the separate District of Columbia suit.

## GOALPOST / RESPONSE

DHS and CBP say the projects provide meaningful border security and that park plans can use lower-profile vehicle barriers and technology rather than continuous 30-foot walls. Plaintiffs cite religious, environmental, flood and statutory harms. The Supreme Court docket and disposition, the injunction’s exact scope, the administrative record, verified sector data, maps and contracts, construction activity and final merits rulings are the tests.

## MAYBE / THEREFORE

Maybe the Supreme Court will lift or narrow the injunction and allow covered construction to resume, or it may leave the pause in place while lower courts develop the record. Therefore the record establishes a reported emergency application and a still-operative preliminary injunction by cutoff—not Supreme Court relief, a final invalidation of DHS authority or proof that every proposed Big Bend project is halted.


## SOURCES

- [Conserve Big Bend v. DHS complaint, No. 1:26-cv-03198](https://www.oaoa.com/wp-content/uploads/2026/09/Complaint-As-Filed.pdf) — primary filed complaint mirror; allegations, statutory theories and requested relief
- [CourtListener RECAP docket — Conserve Big Bend v. DHS](https://www.courtlistener.com/docket/74785094/conserve-big-bend-v-us-department-of-homeland-security/) — primary docket metadata confirming case number and filing date
- [Associated Press — Texas landowners challenge Big Bend wall plans](https://apnews.com/article/border-wall-lawsuit-texas-trump-immigration-3c080168e2d0c5a053263c91a52b923c) — independent reporting of the filed complaint, project context and administration posture
- [Texas Tribune — Big Bend barrier plans and litigation explainer](https://www.texastribune.org/2026/09/14/texas-big-bend-national-park-border-wall-plans-explainer/) — independent regional reporting on plans, official response and distinct litigation
- [Associated Press — border-wall panel installation underway in Big Bend sector](https://apnews.com/article/border-wall-immigration-trump-texas-customs-border-protection-cdcdc43cd541cf0b42cb43c7cf9d0d8f) — independent on-site reporting and named agency statement
- [Associated Press — court pauses Big Bend border construction](https://apnews.com/article/border-immigration-texas-border-infrastructure-56ea4f79b989a4c894e1f2256bc0b886) — independent reporting on preliminary injunction, case posture and agency response status
- [Center for Biological Diversity — emergency injunction blocks Big Bend border construction](https://biologicaldiversity.org/w/news/press-releases/court-grants-emergency-injunction-to-block-big-bend-border-construction-2026-10-02/) — plaintiff-side release describing preliminary injunction; checked against independent reporting
- [Civil Rights Litigation Clearinghouse — Friends of the Ruidosa Church v. Mullin docket](https://clearinghouse.net/case/48106/) — case docket and litigation metadata
- [Texas Tribune — federal judge blocks Big Bend border wall construction](https://www.texastribune.org/2026/10/02/texas-big-bend-border-wall-court-ruling-injunction/) — independent reporting on preliminary injunction and regional scope
- [Associated Press — administration asks Supreme Court to lift Big Bend construction halt](https://apnews.com/article/border-wall-landowners-texas-immigration-8fd59097185de220bc9787eb20b522ec) — independent reporting on the reported emergency application, requested relief and continuing preliminary injunction
- [The Washington Sun — administration asks Supreme Court to intervene in Big Bend case](https://www.washingtonsun.com/immigration/big-bend-border-wall-trump-supreme-court) — second independent report on the emergency application and requested relief; filing itself not retrieved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
