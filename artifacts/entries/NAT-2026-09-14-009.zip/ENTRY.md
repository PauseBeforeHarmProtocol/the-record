# Supreme Court stays Big Bend construction injunction pending certiorari process

**Entry ID:** NAT-2026-09-14-009
**Date:** September 14–November 9, 2026
**Checked:** 2026-11-10 6:10 AM EST
**Evidence state:** primary Supreme Court docket and per curiam opinion plus independent reporting; stay implemented, certiorari and final merits unresolved
**Review state:** current-standard-reviewed

The Court temporarily lifted the lower-court pause after finding the government exceedingly likely to prevail on jurisdiction and facing unrecoverable daily costs; the order is not a final merits ruling.

## THE FACTS

- Conserve Big Bend and six landowners filed Conserve Big Bend v. Department of Homeland Security, No. 1:26-cv-03198, in the U.S. District Court for the District of Columbia on September 14. The complaint challenges DHS and CBP plans for border barriers, roads, lighting, cameras and related infrastructure across the Big Bend sector.
- The plaintiffs allege DHS could not lawfully invoke section 102 of the Illegal Immigration Reform and Immigrant Responsibility Act because the 517-mile Big Bend sector is not an area of ‘high illegal entry.’ Their complaint cites CBP statistics showing the sector accounted for about 1.16% of Southwest-border apprehensions in fiscal years 2021–2025. Those figures and legal conclusions are pleaded allegations, not judicial findings.
- The suit seeks declarations, vacatur of the challenged high-entry determinations and preliminary and permanent injunctions. Filing the complaint did not itself halt construction, decide the legality of statutory waivers or establish a taking of any plaintiff’s property.
- Associated Press reported that the government said no final plans had been selected for Big Bend National Park and that CBP Commissioner Rodney Scott temporarily paused construction-related activity there. The Texas Tribune reported administration officials said they did not plan a 30-foot barrier inside the parks but still intended vehicle barriers and detection technology in limited areas; plans and contracts outside the parks remain distinct.
- This case is separate from earlier Big Bend suits concerning religious, environmental and flood risks. Its narrower theory targets the sector-wide factual and statutory basis for expedited authority, and the archive does not merge those different plaintiffs, projects or requested remedies into one court event.
- On September 18, Associated Press reported after visiting the area that CBP said installation of steel panels was underway on the 47-mile Big Bend 1 project in Hudspeth County. That work is outside Big Bend National Park, where a separate project remained temporarily paused; the lawsuit had not halted the reported installation by cutoff.
- On October 2, U.S. District Judge Kathleen Cardone granted a preliminary injunction in Friends of the Ruidosa Church v. Mullin, No. 3:26-cv-01099, a separate Western District of Texas case. The order temporarily bars the federal defendants from constructing border barrier, road and related infrastructure covered by that case in the Big Bend region while litigation proceeds.
- Associated Press and the plaintiffs reported that the court found the plaintiffs likely to succeed on at least one claim, likely to face irreparable harm without relief, and favored by the equities and public interest. Those preliminary-injunction findings preserve the status quo; they do not decide final liability, permanently invalidate DHS authority or resolve the separate District of Columbia suit.
- Associated Press reported that DHS and CBP did not immediately respond to requests for comment on the injunction. The administration’s previously documented position remains that the infrastructure is needed for border security; later agency filings, an appeal, compliance and construction records will determine the order’s practical reach.
- On October 21, Associated Press and The Washington Sun reported that the administration filed an emergency application asking the Supreme Court to lift the October 2 preliminary injunction while the litigation continues. The application was reported filed, but the filing itself was not retrieved by cutoff and the Supreme Court had not issued a disposition.
- On November 9, the Supreme Court granted the government’s application in Mullin v. Friends of the Ruidosa Church, No. 26A560, and stayed the Western District of Texas preliminary injunction. The stay remains in effect through the timely certiorari process: it ends automatically if certiorari is denied and, if review is granted, when the Court sends down its judgment. Justice Ketanji Brown Jackson would have denied the application.
- The per curiam opinion said the government is exceedingly likely to show that the district court lacked jurisdiction because respondents’ claim is statutory rather than constitutional. The Court also relied on a CBP declaration estimating nearly $500,000 in unrecoverable costs per day while construction was enjoined and concluded that Congress’s balance in IIRIRA section 102(c) favored expeditious construction over the environmental and recreational harms alleged.
- The stay allows construction covered by the injunction to resume while the certiorari process continues. It does not finally resolve the merits, validate every project or waiver, decide the separate District of Columbia litigation, or establish whether the government will complete particular work before later review.

## SIGNIFICANCE

The Supreme Court has changed the operative posture from a lower-court construction pause to a temporary stay that permits covered work while the government pursues certiorari. The Court’s jurisdiction analysis is consequential but remains part of an emergency stay decision, not a final merits judgment.

## GOALPOST / RESPONSE

The administration says statutory waiver authority, border-security needs and unrecoverable costs justify continued construction. Respondents argue the projects exceed statutory authority and threaten religious, environmental, recreational and property interests. The tests are the certiorari petition and disposition, any merits ruling, project-level records, verified construction activity and final relief in both lawsuits.

## MAYBE / THEREFORE

Maybe the jurisdiction ruling will lead to dismissal and uninterrupted construction, or later merits and project-specific litigation may still limit particular work. Therefore the record establishes a Supreme Court stay allowing covered construction to resume during the certiorari process—not a final validation of every Big Bend project or final rejection of all plaintiffs’ claims.


## SOURCES

- [Conserve Big Bend v. DHS complaint, No. 1:26-cv-03198](https://www.oaoa.com/wp-content/uploads/2026/09/Complaint-As-Filed.pdf) — primary filed complaint mirror; allegations, statutory theories and requested relief
- [CourtListener RECAP docket — Conserve Big Bend v. DHS](https://www.courtlistener.com/docket/74785094/conserve-big-bend-v-us-department-of-homeland-security/) — primary docket metadata confirming case number and filing date
- [Associated Press — Texas landowners challenge Big Bend wall plans](https://apnews.com/article/border-wall-lawsuit-texas-trump-immigration-3c080168e2d0c5a053263c91a52b923c) — independent reporting of the filed complaint, project context and administration posture
- [Texas Tribune — Big Bend barrier plans and litigation explainer](https://www.texastribune.org/2026/09/14/texas-big-bend-national-park-border-wall-plans-explainer/) — independent regional reporting on plans, official response and distinct litigation
- [Associated Press — border-wall panel installation underway in Big Bend sector](https://apnews.com/article/border-wall-immigration-trump-texas-customs-border-protection-cdcdc43cd541cf0b42cb43c7cf9d0d8f) — independent on-site reporting and named agency statement
- [Associated Press — court pauses Big Bend border construction](https://apnews.com/article/border-immigration-texas-border-infrastructure-56ea4f79b989a4c894e1f2256bc0b886) — independent reporting on preliminary injunction, case posture and agency response status
- [Center for Biological Diversity — emergency injunction blocks Big Bend border construction](https://biologicaldiversity.org/w/news/press-releases/court-grants-emergency-injunction-to-block-big-bend-border-construction-2026-10-02/) — plaintiff-side release describing preliminary injunction; checked against independent reporting
- [Civil Rights Litigation Clearinghouse — Friends of the Ruidosa Church v. Mullin docket](https://clearinghouse.net/case/48106/) — case docket and litigation metadata
- [Texas Tribune — federal judge blocks Big Bend border wall construction](https://www.texastribune.org/2026/10/02/texas-big-bend-border-wall-court-ruling-injunction/) — independent reporting on preliminary injunction and regional scope
- [Associated Press — administration asks Supreme Court to lift Big Bend construction halt](https://apnews.com/article/border-wall-landowners-texas-immigration-8fd59097185de220bc9787eb20b522ec) — independent reporting on the reported emergency application, requested relief and continuing preliminary injunction
- [The Washington Sun — administration asks Supreme Court to intervene in Big Bend case](https://www.washingtonsun.com/immigration/big-bend-border-wall-trump-supreme-court) — second independent report on the emergency application and requested relief; filing itself not retrieved
- [Supreme Court — Mullin v. Friends of the Ruidosa Church per curiam stay opinion](https://www.supremecourt.gov/opinions/26pdf/26a560_onkq.pdf) — primary judicial opinion and stay order
- [Supreme Court docket 26A560 — Mullin v. Friends of the Ruidosa Church](https://www.supremecourt.gov/docket/docketfiles/html/public/26a560.html) — primary court docket
- [Reuters — Supreme Court permits Big Bend border construction while appeal proceeds](https://www.reuters.com/legal/government/us-supreme-court-allows-trump-border-wall-construction-texas-2026-11-09/) — independent reporting on judicial stay and litigation posture

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
