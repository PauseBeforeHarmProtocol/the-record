# Big Bend landowners sue over DHS fast-track border-barrier authority

**Entry ID:** NAT-2026-09-14-009
**Date:** September 14, 2026
**Checked:** 2026-09-14 11:59 PM EDT
**Evidence state:** primary federal docket and 37-page filed complaint, plus independent Associated Press and Texas Tribune reporting; allegations filed, no ruling or injunction in this case by cutoff
**Review state:** current-standard-reviewed

A nonprofit and six landowners challenged the ‘high illegal entry’ determinations supporting expedited projects; the complaint is an allegation and no injunction issued with filing.

## THE FACTS

- Conserve Big Bend and six landowners filed Conserve Big Bend v. Department of Homeland Security, No. 1:26-cv-03198, in the U.S. District Court for the District of Columbia on September 14. The complaint challenges DHS and CBP plans for border barriers, roads, lighting, cameras and related infrastructure across the Big Bend sector.
- The plaintiffs allege DHS could not lawfully invoke section 102 of the Illegal Immigration Reform and Immigrant Responsibility Act because the 517-mile Big Bend sector is not an area of ‘high illegal entry.’ Their complaint cites CBP statistics showing the sector accounted for about 1.16% of Southwest-border apprehensions in fiscal years 2021–2025. Those figures and legal conclusions are pleaded allegations, not judicial findings.
- The suit seeks declarations, vacatur of the challenged high-entry determinations and preliminary and permanent injunctions. Filing the complaint did not itself halt construction, decide the legality of statutory waivers or establish a taking of any plaintiff’s property.
- Associated Press reported that the government said no final plans had been selected for Big Bend National Park and that CBP Commissioner Rodney Scott temporarily paused construction-related activity there. The Texas Tribune reported administration officials said they did not plan a 30-foot barrier inside the parks but still intended vehicle barriers and detection technology in limited areas; plans and contracts outside the parks remain distinct.
- This case is separate from earlier Big Bend suits concerning religious, environmental and flood risks. Its narrower theory targets the sector-wide factual and statutory basis for expedited authority, and the archive does not merge those different plaintiffs, projects or requested remedies into one court event.

## SIGNIFICANCE

The lawsuit directly tests the statutory predicate DHS uses to accelerate a broad set of border projects and waive ordinary review in a region dominated by federal, state and private lands. Its practical effect depends on an injunction or merits ruling; the filing alone changes no construction authority.

## GOALPOST / RESPONSE

DHS and CBP say the projects provide meaningful border security and that park plans can use lower-profile vehicle barriers and technology rather than continuous 30-foot walls. Plaintiffs say the government’s own encounter data cannot support the required high-entry determination. The administrative record, verified sector statistics, precise project maps and contracts, access and condemnation actions, preliminary relief, merits rulings and construction status are the tests.

## MAYBE / THEREFORE

Maybe the court will find DHS’s sector designation and waiver authority adequately supported, or a low share of apprehensions and project-specific facts may require narrower plans or ordinary review. Therefore the record establishes a filed statutory and constitutional challenge—not an injunction, a finding that DHS acted unlawfully or proof that every proposed Big Bend barrier will be built.


## SOURCES

- [Conserve Big Bend v. DHS complaint, No. 1:26-cv-03198](https://www.oaoa.com/wp-content/uploads/2026/09/Complaint-As-Filed.pdf) — primary filed complaint mirror; allegations, statutory theories and requested relief
- [CourtListener RECAP docket — Conserve Big Bend v. DHS](https://www.courtlistener.com/docket/74785094/conserve-big-bend-v-us-department-of-homeland-security/) — primary docket metadata confirming case number and filing date
- [Associated Press — Texas landowners challenge Big Bend wall plans](https://apnews.com/article/border-wall-lawsuit-texas-trump-immigration-3c080168e2d0c5a053263c91a52b923c) — independent reporting of the filed complaint, project context and administration posture
- [Texas Tribune — Big Bend barrier plans and litigation explainer](https://www.texastribune.org/2026/09/14/texas-big-bend-national-park-border-wall-plans-explainer/) — independent regional reporting on plans, official response and distinct litigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
