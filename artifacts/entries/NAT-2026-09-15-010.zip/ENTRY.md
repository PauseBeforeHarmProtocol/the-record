# Justice Department backs bond demand in Paramount–Warner Bros antitrust fight

**Entry ID:** NAT-2026-09-15-010
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:29 AM EDT
**Evidence state:** Reuters legal reporting on a filed Justice Department position and the parties' requests; DOJ advocacy is established while the bond, injunction, merits and transaction outcomes remain pending
**Review state:** current-standard-reviewed

DOJ urged a proper bond if challengers obtain a preliminary injunction against the $110 billion transaction; the court had not imposed a bond or ruled on the injunction.

## THE FACTS

- The Justice Department filed a position supporting a proper bond requirement if states and private plaintiffs obtain a preliminary injunction blocking Paramount Skydance's proposed $110 billion acquisition of Warner Bros Discovery, Reuters reported.
- Paramount sought a $1.88 billion bond and cited a $7 million-per-day ticking fee after September 30. Those figures are the company's requested protection and contractual-risk assertions, not an amount ordered by the court or a measured public loss.
- DOJ argued that an adequate bond would protect the merging companies and the public from costs if an injunction were later found improper. That is the department's litigation position; it is not an antitrust merits ruling, approval of the transaction or finding that the challengers' case lacks merit.
- The state and private plaintiffs seek to stop the transaction on antitrust grounds. Filing the challenge and seeking preliminary relief establish live litigation, not that the acquisition is unlawful or that claimed competitive harms have occurred.
- No preliminary-injunction decision, bond amount, final antitrust judgment, completed transaction or measured effect on competition, consumers or workers existed by cutoff.

## SIGNIFICANCE

DOJ's filing places the administration on the side of requiring substantial financial protection before a court temporarily blocks one of the largest proposed media transactions. The immediate effect is advocacy over preliminary-relief conditions, not a completed merger-policy outcome.

## GOALPOST / RESPONSE

DOJ and Paramount say a bond should account for the financial consequences of an injunction later found improper; challengers say the transaction threatens competition and seek to preserve the pre-merger market. The court's injunction and bond rulings, discovery, a merits judgment, transaction closing and post-transaction market evidence are the tests.

## MAYBE / THEREFORE

Maybe a substantial bond appropriately protects against wrongful-injunction costs, or it could make otherwise valid public-interest antitrust challenges harder to pursue. Therefore the record establishes DOJ's filed support for a proper bond—not a $1.88 billion order, a ruling on competitive effects, transaction approval or final defeat of the challengers.


## SOURCES

- [Reuters — DOJ backs bond demand in Paramount–Warner Bros antitrust fight](https://www.reuters.com/legal/litigation/us-doj-backs-bond-demand-paramount-warner-bros-antitrust-fight-2026-09-15/) — independent legal reporting on DOJ's filed position; the filing is advocacy and no bond or injunction ruling had issued

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
