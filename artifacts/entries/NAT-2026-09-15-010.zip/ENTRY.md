# Paramount closes Warner Bros merger after DOJ’s antitrust nonchallenge

**Entry ID:** NAT-2026-09-15-010
**Date:** September 15–October 6, 2026
**Checked:** 2026-10-06 12:04 PM EDT
**Evidence state:** primary corporate completion announcement, independent AP reporting and DOJ’s original antitrust explanation; transaction completed, forecasts and separate litigation outcomes distinguished
**Review state:** current-standard-reviewed

The companies announced completion on October 6; DOJ’s earlier favorable analysis and bond advocacy remain distinct from court findings and measured competitive outcomes.

## THE FACTS

- The Justice Department filed a position supporting a proper bond requirement if states and private plaintiffs obtain a preliminary injunction blocking Paramount Skydance's proposed $110 billion acquisition of Warner Bros Discovery, Reuters reported.
- Paramount sought a $1.88 billion bond and cited a $7 million-per-day ticking fee after September 30. Those figures are the company's requested protection and contractual-risk assertions, not an amount ordered by the court or a measured public loss.
- DOJ argued that an adequate bond would protect the merging companies and the public from costs if an injunction were later found improper. That is the department's litigation position; it is not an antitrust merits ruling, approval of the transaction or finding that the challengers' case lacks merit.
- The state and private plaintiffs seek to stop the transaction on antitrust grounds. Filing the challenge and seeking preliminary relief establish live litigation, not that the acquisition is unlawful or that claimed competitive harms have occurred.
- At the September 16 inspection, the bond, preliminary-injunction and merits outcomes and transaction closing were still pending. The October 6 completion reported below changes the transaction’s lifecycle; it does not supply a court ruling on the earlier $1.88 billion bond request.
- On October 6, Paramount announced completion of its Warner Bros. Discovery acquisition and said the required regulatory approvals and customary closing conditions had been satisfied. AP independently reported the closing. The combined company is called Skydance and includes CBS News and CNN, major film studios and streaming services.
- DOJ’s June 12 statement had closed its antitrust investigation after finding the transaction unlikely to harm competition, consumers or workers and predicting benefits. This was the administration’s earlier agency analysis, not a new October 6 clearance, judicial antitrust judgment or measurement of post-merger effects.
- The company says the combined business will increase creative output and targets at least $6 billion in run-rate synergies within three years. Those are corporate commitments and forecasts, not savings or competitive benefits already realized. The inspected closing evidence does not determine the disposition of every separate lawsuit or the requested bond.

## SIGNIFICANCE

Completion converts a proposed media consolidation supported by the administration into an operating ownership change involving major studios, streamers and news networks. The closing itself does not settle whether consumers, workers or editorial independence benefit or suffer.

## GOALPOST / RESPONSE

DOJ predicted that the combination would not harm competition and would benefit consumers and workers; the company promises more creative output and efficiencies. Prices, output, employment, independent production, editorial governance and enforceable court or regulatory conditions are the tests of those claims.

## MAYBE / THEREFORE

Maybe greater scale supports investment and creative output as DOJ and the company expect, or consolidation may weaken competition, employment or editorial independence. Therefore the acquisition is completed according to the company and independent AP reporting, while claimed efficiencies, competitive outcomes and the disposition of every separate court issue remain unestablished here.


## SOURCES

- [Reuters — DOJ backs bond demand in Paramount–Warner Bros antitrust fight](https://www.reuters.com/legal/litigation/us-doj-backs-bond-demand-paramount-warner-bros-antitrust-fight-2026-09-15/) — independent legal reporting on DOJ's filed position; the filing is advocacy and no bond or injunction ruling had issued
- [Paramount — Completion of Warner Bros. Discovery acquisition](https://www.prnewswire.com/news-releases/paramount-completes-acquisition-of-warner-bros-discovery-creating-a-new-global-entertainment-leader-skydance-302899765.html) — primary corporate closing announcement
- [AP — Paramount and Warner Bros. become Skydance](https://abcnews.com/Business/wireStory/paramount-warner-bros-now-hollywood-giant-skydance-137031062) — independent reporting (ABC-hosted AP copy)
- [DOJ — Antitrust investigation closing statement](https://www.justice.gov/opa/pr/statement-department-justice-antitrust-division-closing-its-investigation-merger-paramount) — primary government antitrust explanation; retrospective context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
