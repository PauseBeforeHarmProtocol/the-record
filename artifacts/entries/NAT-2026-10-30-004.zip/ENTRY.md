# Court-document reporting describes planned Afghan removals through Pakistan

**Entry ID:** NAT-2026-10-30-004
**Date:** October 30–31, 2026
**Checked:** 2026-11-01 12:06 AM EDT
**Evidence state:** AP and ABC independently report original court-document inspection; documents unavailable here, scheduled/planned rather than implemented; individual protections and outcomes unknown
**Review state:** current-standard-reviewed

Two newsrooms report a route onward to Afghanistan; proposed flights, individual protections and actual removals remain distinct.

## THE FACTS

- AP and ABC News independently reported reviewing court filings describing a planned removal of Afghan immigrants from Louisiana to Pakistan, with onward transport to Afghanistan. The underlying sealed filings were not retrieved here; the evidence is corroborated reporting of a plan, not verified completed transport.
- AP reported possible departures as early as Monday, November 2; Human Rights First separately told AP it confirmed a scheduled Tuesday flight. ABC described an expected flight early the following week. These are reported schedules, not a manifest, a settled departure date or proof anyone boarded.
- Named advocates and families warned that return could expose people to Taliban persecution. Reporting did not establish that every intended passenger helped U.S. forces, held the same immigration status or had a protection order barring return. The individual cases and completed protection reviews remain unverified.
- DHS told AP it would not discuss future removal operations, citing operational security and personnel safety. ABC reported that State defended countries’ authority to manage borders for their citizens’ safety and prosperity. These explanations do not establish each removal’s legality or an adequate protection review.

## SIGNIFICANCE

A reported onward route to Afghanistan raises materially different protection risks from a transfer that stops in a third country. The immediate accountability questions concern notice, individual protection orders, access to counsel and whether onward removal is planned or carried out.

## GOALPOST / RESPONSE

The administration invokes border management and operational security. Advocates argue that return to Taliban-controlled territory could endanger people with U.S. ties. Individual orders, notice and counsel records, protection determinations, flight manifests and post-arrival outcomes are the tests; neither general rationale resolves an individual case.

## MAYBE / THEREFORE

Maybe lawful removals can proceed after individualized protection review, or the proposed route may expose people to prohibited onward return. Therefore this record establishes a corroborated reported plan—not completed deportations, a verified passenger count, proof every passenger is an Afghan ally, or a judicial finding that the plan is lawful or unlawful.


## SOURCES

- [Associated Press — reported Afghan removal plan via Pakistan](https://abcnews.com/amp/US/wireStory/us-plans-deport-afghans-back-home-country-pakistan-137741097) — independent inspection of court filing reported by outlet; underlying sealed record unavailable to this review
- [ABC News — reported Afghan removal plan via Pakistan](https://www.aol.com/articles/afghans-scheduled-removal-may-relatives-004307000.html) — independent inspection of court filing reported by outlet; underlying sealed record unavailable to this review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
