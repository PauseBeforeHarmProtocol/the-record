# Courts temporarily restrain planned Afghan removals through Pakistan

**Entry ID:** NAT-2026-10-30-004
**Date:** October 30–November 3, 2026
**Checked:** 2026-11-03 6:16 PM EST
**Evidence state:** AP reporting on the November 3 temporary order and government representation, plus party-counsel description of a separate New Mexico order; original orders remain unretrieved and no completed transfer is established
**Review state:** current-standard-reviewed

Two temporary orders interrupt individual and group removal plans; the government said no Afghan removal flights were scheduled before the broader order expires.

## THE FACTS

- AP and ABC News independently reported reviewing court filings describing a planned removal of Afghan immigrants from Louisiana to Pakistan, with onward transport to Afghanistan. The underlying sealed filings were not retrieved here; the evidence is corroborated reporting of a plan, not verified completed transport.
- AP reported possible departures as early as Monday, November 2; Human Rights First separately told AP it confirmed a scheduled Tuesday flight. ABC described an expected flight early the following week. These are reported schedules, not a manifest, a settled departure date or proof anyone boarded.
- Named advocates and families warned that return could expose people to Taliban persecution. Reporting did not establish that every intended passenger helped U.S. forces, held the same immigration status or had a protection order barring return. The individual cases and completed protection reviews remain unverified.
- DHS told AP it would not discuss future removal operations, citing operational security and personnel safety. ABC reported that State defended countries’ authority to manage borders for their citizens’ safety and prosperity. These explanations do not establish each removal’s legality or an adequate protection review.
- On November 3, U.S. District Judge Valerie Caproni temporarily barred the administration from removing detained Afghans to Afghanistan or Pakistan through Saturday. Associated Press reported the oral or written court action; the original order was not retrieved, so its precise text and scope remain a source gap.
- At the hearing, a government lawyer said ICE had no planned or confirmed charter or commercial flights removing Afghans to Afghanistan or Pakistan through the end of the week and that such flights are ordinarily booked weeks ahead. That representation reduces immediate risk during the temporary period but does not withdraw the reported policy or foreclose later flights.
- Separately, counsel for Sardar Akbari said the District of New Mexico prohibited his removal for 14 days and until adequate suicide-risk safeguards are in place, and directed his return to New Mexico. The ACLU release identifies Akbari v. Mullin, No. 1:26-cv-03573-KG-DLM; it said the written order was forthcoming, and the order itself was not retrieved.
- The temporary restraints do not establish that every planned third-country removal is unlawful, that Pakistan agreed to receive a group, or that any person was transferred. They preserve judicial review and safety questions while the administration's reported plan remains unimplemented.

## SIGNIFICANCE

The temporary orders impose concrete judicial limits on an imminent removal plan involving a country of transit and possible onward transfer to Taliban-controlled Afghanistan. They preserve review and safety safeguards without finally resolving the administration's third-country-removal authority or the plan's future operation.

## GOALPOST / RESPONSE

The administration has said third-country removals can proceed with notice and diplomatic assurances and told the New York court no flights were scheduled before the temporary order expired. Counsel and plaintiffs argue that notice, fear screening and mental-health safeguards are inadequate. The tests are the original orders, later hearings, verified diplomatic arrangements, individualized notice and screening, and any completed transfer—not reported planning alone.

## MAYBE / THEREFORE

Maybe the temporary orders permit adequate individualized safeguards before any later removal, or broader legal review may block the route. Therefore courts have temporarily restrained the planned removals and the government reported no immediate flights; the policy has not been withdrawn, finally adjudicated or implemented.


## SOURCES

- [Associated Press — reported Afghan removal plan via Pakistan](https://abcnews.com/amp/US/wireStory/us-plans-deport-afghans-back-home-country-pakistan-137741097) — independent inspection of court filing reported by outlet; underlying sealed record unavailable to this review
- [ABC News — reported Afghan removal plan via Pakistan](https://www.aol.com/articles/afghans-scheduled-removal-may-relatives-004307000.html) — independent inspection of court filing reported by outlet; underlying sealed record unavailable to this review
- [AP — judge temporarily blocks planned Afghan removals](https://apnews.com/article/afghans-deportation-pakistan-trump-immigration-a419fbb329b96480d806d9ffbd52ccb4) — independent court reporting on temporary relief and the government's flight representation
- [ACLU of New Mexico — Akbari temporary removal restraint](https://www.aclu-nm.org/press-releases/federal-court-in-new-mexico-blocks-ice-from-deporting-afghan-national-to-pakistan-without-adequate-safeguards/) — party-counsel release describing the individual temporary order; written order not retrieved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
