# Trump declares bulk-power emergency and restricts foreign grid equipment

**Entry ID:** NAT-2026-08-26-004
**Date:** August 26, 2026
**Checked:** 2026-09-09 12:01 PM EDT
**Evidence state:** official executive order and Federal Register correction, White House materials, Reuters context and DOE's September 9 request for information; emergency framework and implementation inquiry established, product-specific determinations and outcomes unmeasured
**Review state:** corrected

Executive Order 14421 bars future covered transactions that the Energy secretary finds present specified foreign-control and security risks, and authorizes conditions on equipment already operating.

## THE FACTS

- President Trump signed Executive Order 14421 declaring a national emergency over foreign supply of bulk-power system electric equipment under the International Emergency Economic Powers Act and National Emergencies Act.
- The order prohibits post-signing acquisition, import, transfer, or installation transactions when the Energy secretary determines that covered foreign control and specified sabotage, remote-access, supply-disruption, critical-infrastructure, or national-security risks are present. It reaches associated components, software, firmware, digital and maintenance services, and remote-access capabilities; it is not a blanket ban on every foreign-made grid component.
- The order also authorizes the Energy secretary to impose conditions on continued use of covered equipment already operating, directs implementation rules as needed, and requires risk identification and recommendations. Reuters reported that the action follows concerns about undocumented communication devices found in some Chinese solar inverters; the order itself does not publish a product list or establish that every covered device contains a backdoor.
- Correction — September 1, 2026: an earlier version identified the grid order as Executive Order 14420 because that number appears on the White House page. The official Federal Register assigns the August 26 grid order Executive Order 14421; Executive Order 14420 is the August 10 childhood-vaccine order.
- On September 9, the Energy Department published a request for information to prepare implementation measures. It seeks comment on covered equipment and transactions, covered foreign entities, software and remote-access risks, installed-equipment mitigation, licensing and vendor prequalification, domestic replacement capacity, federal procurement, reliability, safety, costs and small-entity effects. Responses are due October 9, and a public webinar is scheduled for September 16. The request begins a formal implementation process but does not itself identify prohibited products, covered vendors, vulnerable devices or mandatory replacements.

## SIGNIFICANCE

The order creates a broad emergency-power framework for federal review of future grid-equipment transactions and possible operating conditions on installed equipment. DOE's published inquiry is a concrete implementation step, but the framework's eventual reach, replacement costs, and effects on grid reliability still depend on later determinations and rules.

## GOALPOST / RESPONSE

The administration says foreign-controlled equipment can create remote-access, sabotage, and supply-disruption risks in infrastructure essential to defense, emergency services, and the economy. DOE says it is gathering technical and economic evidence before implementation. The covered-entity definitions, product determinations, mitigation or licensing rules, reliability analysis, documented vulnerability findings and replacement capacity are the tests.

## MAYBE / THEREFORE

Maybe broad technical consultation will help DOE target genuine grid-security gaps while protecting reliability and avoiding unnecessary replacement costs, or it may precede sweeping restrictions whose evidence and burdens remain uncertain. Therefore DOE has opened a formal implementation inquiry under the signed emergency framework—not issued a product list, found that every foreign device is compromised or ordered equipment removed.


## SOURCES

- [White House — bulk-power emergency order page (mislabels the order as EO 14420)](https://www.whitehouse.gov/presidential-actions/2026/08/declaring-a-national-emergency-to-secure-the-united-states-bulk-power-system/) — primary White House text and operative authorities; page-level executive-order number conflicts with the official Federal Register designation
- [Reuters — Trump restricts specified foreign equipment in U.S. electricity grid](https://www.reuters.com/legal/government/trump-signs-order-banning-some-foreign-equipment-us-energy-grid-2026-08-26/) — independent reporting and prior inverter-security context
- [Federal Register — Executive Order 14421 on the bulk-power system](https://www.federalregister.gov/documents/2026/08/31/2026-17843/declaring-a-national-emergency-to-secure-the-united-states-bulk-power-system) — official published presidential document assigning Executive Order 14421 to the August 26 bulk-power emergency order
- [Federal Register — request for information on implementing the bulk-power emergency](https://www.federalregister.gov/documents/2026/09/09/2026-18370/securing-the-united-states-bulk-power-system) — primary implementation request for information under Executive Order 14421; comments due October 9 and no product-specific determination yet

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
