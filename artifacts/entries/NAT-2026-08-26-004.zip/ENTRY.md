# Trump declares bulk-power emergency and restricts foreign grid equipment

**Entry ID:** NAT-2026-08-26-004
**Date:** August 26, 2026
**Checked:** 2026-09-01 12:03 PM EDT
**Evidence state:** official Federal Register publication assigning EO 14421, White House text whose page mislabels the number, fact sheet and independent Reuters reporting; identifier corrected, emergency and review authorities ordered, product-specific scope and outcomes unmeasured
**Review state:** corrected

Executive Order 14421 bars future covered transactions that the Energy secretary finds present specified foreign-control and security risks, and authorizes conditions on equipment already operating.

## THE FACTS

- President Trump signed Executive Order 14421 declaring a national emergency over foreign supply of bulk-power system electric equipment under the International Emergency Economic Powers Act and National Emergencies Act.
- The order prohibits post-signing acquisition, import, transfer, or installation transactions when the Energy secretary determines that covered foreign control and specified sabotage, remote-access, supply-disruption, critical-infrastructure, or national-security risks are present. It reaches associated components, software, firmware, digital and maintenance services, and remote-access capabilities; it is not a blanket ban on every foreign-made grid component.
- The order also authorizes the Energy secretary to impose conditions on continued use of covered equipment already operating, directs implementation rules as needed, and requires risk identification and recommendations. Reuters reported that the action follows concerns about undocumented communication devices found in some Chinese solar inverters; the order itself does not publish a product list or establish that every covered device contains a backdoor.
- Correction — September 1, 2026: an earlier version identified the grid order as Executive Order 14420 because that number appears on the White House page. The official Federal Register assigns the August 26 grid order Executive Order 14421; Executive Order 14420 is the August 10 childhood-vaccine order.

## SIGNIFICANCE

The order creates a broad emergency-power framework for federal review of future grid-equipment transactions and possible operating conditions on installed equipment. It can reduce cyber and supply-chain exposure, but its eventual reach, replacement costs, and effects on grid reliability depend on Energy Department determinations and rules.

## GOALPOST / RESPONSE

The administration says foreign-controlled equipment can create remote-access, sabotage, and supply-disruption risks in infrastructure essential to defense, emergency services, and the economy. Utilities and suppliers may argue that vague covered-entity criteria or rapid replacement mandates could raise costs and delay capacity. The covered-entity definitions, product determinations, implementation rules, reliability analysis, and documented vulnerability findings are the evidence tests.

## MAYBE / THEREFORE

Maybe targeted screening and conditions will close genuine grid-security gaps without materially constraining safe imports, especially if Energy applies the order narrowly. Therefore the record distinguishes the signed emergency framework from later product-specific determinations and does not describe all foreign equipment as banned or compromised.


## SOURCES

- [White House — bulk-power emergency order page (mislabels the order as EO 14420)](https://www.whitehouse.gov/presidential-actions/2026/08/declaring-a-national-emergency-to-secure-the-united-states-bulk-power-system/) — primary White House text and operative authorities; page-level executive-order number conflicts with the official Federal Register designation
- [Reuters — Trump restricts specified foreign equipment in U.S. electricity grid](https://www.reuters.com/legal/government/trump-signs-order-banning-some-foreign-equipment-us-energy-grid-2026-08-26/) — independent reporting and prior inverter-security context
- [Federal Register — Executive Order 14421 on the bulk-power system](https://www.federalregister.gov/documents/2026/08/31/2026-17843/declaring-a-national-emergency-to-secure-the-united-states-bulk-power-system) — official published presidential document assigning Executive Order 14421 to the August 26 bulk-power emergency order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
