# Trump grants one-year water-pollution exemption for federal wildfire suppression

**Entry ID:** NAT-2026-11-10-002
**Date:** November 10, 2026
**Checked:** 2026-11-10 6:12 PM EST
**Evidence state:** signed presidential determination, White House rationale and primary court context; exemption operative for one year, with implementation, environmental effects and firefighting outcomes unresolved
**Review state:** current-standard-reviewed

The signed determination covers federal agencies and contractors through November 10, 2027, including aerial fire-retardant use, while preserving specified statutory limits and other applicable laws.

## THE FACTS

- On November 10, President Trump signed a determination under section 313 of the Federal Water Pollution Control Act exempting federal firefighting activities conducted by the Forest Service, Interior Department, other executive agencies and their contractors from federal, state, interstate and local water-pollution requirements, administrative processes and sanctions. The instrument expressly includes aerial deployment and discharge of fire retardants.
- The exemption runs for one year, from November 10, 2026, through November 10, 2027. It is an operative presidential exemption, not a proposed rule or a permanent statutory amendment.
- The White House says litigation and permitting uncertainty could constrain wildfire response during the 2027 season and frames the action as preserving firefighters' ability to protect lives, communities, infrastructure and watersheds. A 2023 District of Montana order found specified unpermitted Forest Service retardant discharges into navigable waters violated the Clean Water Act but did not enjoin aerial retardant use.
- The memorandum does not exempt requirements under 33 U.S.C. §§ 1316 and 1317, says it does not limit other applicable law, and does not concede that permits otherwise would be required. Its practical environmental and operational effects have not yet been measured.

## SIGNIFICANCE

The action uses presidential statutory authority to suspend a layer of water-pollution control for a nationwide emergency-response tool. It may reduce legal delay for wildfire crews, while shifting accountability toward compliance with the remaining statutory limits, other environmental laws and agency operating safeguards.

## GOALPOST / RESPONSE

The administration says the one-year exemption prevents permitting uncertainty from tying firefighters' hands. The tests are Federal Register publication, agency guidance, actual retardant deployments, waterway incidents, remaining-law compliance, wildfire outcomes, litigation and whether agencies secure a durable permit or statutory resolution before the exemption expires.

## MAYBE / THEREFORE

Maybe the exemption prevents harmful delay while existing operational buffers and other laws adequately protect waterways, or reduced Clean Water Act process may increase ecological risk without improving fire outcomes. Therefore the record establishes a signed one-year exemption with express limits—not permanent repeal, proof that a permit was impossible, permission to disregard every environmental requirement or measured wildfire effectiveness.


## SOURCES

- [White House — Presidential determination exempting federal wildfire suppression from specified water-pollution requirements](https://www.whitehouse.gov/presidential-actions/2026/11/presidential-determination-concerning-wildfire-suppression-activities-in-the-united-states/) — primary signed presidential memorandum
- [White House — fact sheet on wildfire-suppression determination](https://www.whitehouse.gov/fact-sheets/2026/11/fact-sheet-president-donald-j-trump-advances-wildfire-suppression/) — primary administration explanation
- [District of Montana — order finding specified unpermitted aerial-retardant discharges violated the Clean Water Act](https://www.govinfo.gov/app/details/USCOURTS-mtd-9_22-cv-00168/USCOURTS-mtd-9_22-cv-00168-3) — primary court order and legal context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
