# Trump rejects an Iran-deal extension and threatens military action against Oman

**Entry ID:** NAT-2026-08-17-001
**Date:** August 17–18, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** on-record presidential statements and independent reporting; no extension or final deal

The 60-day negotiating period expired with talks stalled, the Iran war continuing, and the president publicly widening the threat to a U.S. regional partner.

## THE FACTS

- President Trump said the United States would not extend the June memorandum's 60-day period for negotiating a final agreement with Iran and said Iran should surrender.
- The June memorandum had called for an immediate end to military operations and up to 60 days of negotiations, but it unraveled in July and the conflict continued.
- While Oman and Iran discussed restoring commercial shipping through the Strait of Hormuz, Trump threatened to bomb Oman if it 'gets in the way.' Reuters reported that the strait carried about 20% of global oil and liquefied-natural-gas supplies before the war began.

## SIGNIFICANCE

A presidential threat against Oman moves beyond pressure on Iran and puts U.S. coercive power against a country serving as a regional interlocutor. The expired negotiating clock also provides a concrete test of whether military escalation is replacing the final agreement promised in the interim memorandum.

## GOALPOST / RESPONSE

Trump says the overriding objective is preventing an Iranian nuclear weapon and that Iran will not accept the deal he considers necessary. That rationale does not resolve the separate questions of congressional war authority, the threat against Oman, or what terms could end the conflict.


## SOURCES

- [Reuters — Trump rejects Iran-deal extension and threatens Oman](https://www.reuters.com/world/middle-east/trump-says-iran-should-surrender-threatens-bomb-oman-2026-08-17/) — independent reporting on presidential statements and negotiations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
