# Trump widens the Hormuz warning as U.S. and Iran exchange strikes

**Entry ID:** NAT-2026-08-17-001
**Date:** August 17–30, 2026
**Checked:** 2026-08-30 11:58 PM EDT
**Evidence state:** Trump's published statements, primary CENTCOM mission background, a named CENTCOM spokesperson quoted by Associated Press, independent Reuters confirmation through a U.S. official, Jordan's reported interception statement, and Reuters' documented lack of Kharg corroboration and synthetic-video finding; reciprocal strikes confirmed, Kharg attack unconfirmed
**Review state:** current-standard-reviewed

Iran answered the U.S. launcher strike with ballistic missiles aimed at U.S. sites in Jordan; Trump's later claim that Kharg Island was being destroyed remained unconfirmed and was accompanied by a synthetic video.

## THE FACTS

- President Trump said the United States would not extend the June memorandum's 60-day period for negotiating a final agreement with Iran and said Iran should surrender.
- The June memorandum had called for an immediate end to military operations and up to 60 days of negotiations, but it unraveled in July and the conflict continued.
- While Oman and Iran discussed restoring commercial shipping through the Strait of Hormuz, Trump threatened to bomb Oman if it 'gets in the way.' Reuters reported that the strait carried about 20% of global oil and liquefied-natural-gas supplies before the war began.
- On August 25, Trump said the Navy had told him all mines had been removed or detonated from the strait's international waters and announced that any vessel attempting to lay another mine would be 'immediately and systematically destroyed.' The Truth Social post proves that he issued the statement; it does not independently verify the operational claim.
- CENTCOM's latest located public release on the clearance mission, dated April 11, said forces had begun setting conditions for mine removal and that additional assets would join. No later Pentagon, Navy, or CENTCOM release confirming completion was located by the checked time. Reuters separately reported continued vessel attacks and Vortexa data showing roughly 5 million barrels per day of oil shipments on August 24, down from more than 20 million before the conflict.
- On August 30, U.S. forces struck two Iranian launchers on Larak Island. A named CENTCOM spokesperson told the Associated Press that Islamic Revolutionary Guard Corps forces had been observed preparing to launch rockets carrying sea mines into the Strait of Hormuz; Reuters independently quoted a U.S. official giving the same account. The public reporting did not disclose the strike platform, damage assessment, targeting evidence, or whether rockets or mines had already been launched.
- Iran's Revolutionary Guard said the strike killed and wounded fighters and civilians and vowed a military and economic response. Iranian media described a drone strike, while the United States had not publicly confirmed the weapon used. Those casualty and platform claims were not independently verified by cutoff. AP described the attack as the first U.S. military action in a month, and Reuters called it the first known U.S. strike on Iran since late July.
- Iran later launched ballistic missiles at two U.S. sites in Jordan in response. Jordan's armed forces said they intercepted eight missiles that entered Jordanian airspace; Iranian state television showed what it said were the launches. Public reporting did not establish independent battle-damage or casualty findings at the U.S. sites by cutoff.
- At 10:18 p.m. EDT, Trump posted that Kharg Island was being 'blown to smithereens' and attached a video. Reuters found no other evidence of an attack, received no immediate confirmation from the White House or Defense Department, and reported no immediate response in Iranian media. Reuters' image-analysis software found the clip was most likely synthetically generated. The post establishes that Trump made the claim; neither it nor the synthetic video establishes that an attack occurred.

## SIGNIFICANCE

The exchange moved the episode beyond a one-sided preventive strike: Iran carried out its promised military response against U.S. sites in Jordan. Trump's unverified Kharg statement further raised the risk around an island central to Iran's oil exports, but the synthetic video and absence of corroboration make it especially important not to record a claimed attack as an implemented one.

## GOALPOST / RESPONSE

The administration says the Larak action protected international shipping from an imminent mine-laying threat. Iran says it retaliated against U.S. sites in Jordan. Confirmation from the White House, Defense Department, CENTCOM, Iranian authorities, satellite imagery or independent reporting is required before treating the Kharg claim as an attack. Public targeting evidence, damage and casualty assessments, any new War Powers notice, congressional action, mine incidents and vessel traffic remain the tests.

## MAYBE / THEREFORE

Maybe the Larak strike prevented an imminent attempt to remine the strait and Iran's intercepted response ended the exchange, or the unverified Kharg post may signal or falsely imply a wider attack. Therefore the record confirms the U.S. launcher strike and Iran's missile response, accurately attributes their stated rationales, and records Trump's Kharg statement only as an unverified presidential claim; it does not independently establish the launch preparations, casualties, legality, a Kharg attack, or improved shipping safety.


## SOURCES

- [Reuters — Trump rejects Iran-deal extension and threatens Oman](https://www.reuters.com/world/middle-east/trump-says-iran-should-surrender-threatens-bomb-oman-2026-08-17/) — independent reporting on presidential statements and negotiations
- [Donald J. Trump on Truth Social — Strait of Hormuz mine-clearance claim and destruction warning](https://truthsocial.com/@realDonaldTrump/117156624974445904) — primary source for the fact that the president published the statement; not independent verification of claims inside it
- [U.S. Central Command — mine-clearance mission begins in the Strait of Hormuz](https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4457220/us-forces-start-mine-clearance-mission-in-strait-of-hormuz/) — primary military release documenting the mission's announced start and planned assets
- [Reuters — Trump says Hormuz was demined and warns against new mines](https://www.reuters.com/world/trump-says-strait-hormuz-has-been-demined-warns-iran-not-plant-more-2026-08-25/) — independent reporting on the presidential statement, continuing vessel attacks, and shipping-volume data
- [Associated Press — U.S. strikes Iranian rocket launchers on Larak Island](https://apnews.com/article/iran-strait-hormuz-strike-united-states-6b098da673ac3161a266ee459d5eff44) — independent reporting quoting a named CENTCOM spokesperson, Iranian response and unresolved operational details
- [Reuters — U.S. forces strike two Iranian launchers on Larak Island](https://www.reuters.com/world/middle-east/us-forces-strike-two-iranian-launchers-irans-larak-island-us-official-says-2026-08-30/) — independent confirmation through a U.S. official with Iranian casualty and retaliation claims clearly attributed
- [Donald Trump — Truth Social claim about Kharg Island](https://truthsocial.com/@realDonaldTrump/117187722429803464) — primary evidence that Trump published the Kharg Island statement and attached media; the post and attached media do not independently verify an attack
- [Reuters — Trump says Kharg is being attacked but gives no evidence](https://www.reuters.com/world/middle-east/us-iran-exchange-fire-flare-up-bessent-signals-more-sanctions-2026-08-31/) — independent reporting documenting the unconfirmed presidential claim, absence of official or Iranian corroboration, and synthetic-video analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
