# Trump widens the Hormuz war as U.S. forces strike new Iranian targets

**Entry ID:** NAT-2026-08-17-001
**Date:** August 17–September 1, 2026
**Checked:** 2026-09-01 6:02 PM EDT
**Evidence state:** primary CENTCOM announcement and Trump publication, independently corroborated and contextualized by Reuters and Associated Press; strike wave implemented, complete target set, damage, casualties, legal authority and consequences unresolved
**Review state:** current-standard-reviewed

CENTCOM began a new strike wave against IRGC targets at noon on September 1; the public record established the operation but not its full target list, damage, casualties or legal authority.

## THE FACTS

- President Trump said the United States would not extend the June memorandum's 60-day period for negotiating a final agreement with Iran and said Iran should surrender.
- The June memorandum had called for an immediate end to military operations and up to 60 days of negotiations, but it unraveled in July and the conflict continued.
- While Oman and Iran discussed restoring commercial shipping through the Strait of Hormuz, Trump threatened to bomb Oman if it 'gets in the way.' Reuters reported that the strait carried about 20% of global oil and liquefied-natural-gas supplies before the war began.
- On August 25, Trump said the Navy had told him all mines had been removed or detonated from the strait's international waters and announced that any vessel attempting to lay another mine would be 'immediately and systematically destroyed.' The Truth Social post proves that he issued the statement; it does not independently verify the operational claim.
- CENTCOM's latest located public release on the clearance mission, dated April 11, said forces had begun setting conditions for mine removal and that additional assets would join. No later Pentagon, Navy, or CENTCOM release confirming completion was located by the checked time. Reuters separately reported continued vessel attacks and Vortexa data showing roughly 5 million barrels per day of oil shipments on August 24, down from more than 20 million before the conflict.
- On August 30, U.S. forces struck two Iranian launchers on Larak Island. A named CENTCOM spokesperson told the Associated Press that Islamic Revolutionary Guard Corps forces had been observed preparing to launch rockets carrying sea mines into the Strait of Hormuz; Reuters independently quoted a U.S. official giving the same account. The public reporting did not disclose the strike platform, damage assessment, targeting evidence, or whether rockets or mines had already been launched.
- Iran's Revolutionary Guard said the strike killed and wounded fighters and civilians and vowed a military and economic response. Iranian media described a drone strike, while the United States had not publicly confirmed the weapon used. Those casualty and platform claims were not independently verified by cutoff. AP described the attack as the first U.S. military action in a month, and Reuters called it the first known U.S. strike on Iran since late July.
- Iran later launched ballistic missiles at two U.S. sites in Jordan in response. Jordan's armed forces said they intercepted eight missiles that entered Jordanian airspace; Iranian state television showed what it said were the launches. Public reporting did not establish independent battle-damage or casualty findings at the U.S. sites by cutoff.
- At 10:18 p.m. EDT, Trump posted that Kharg Island was being 'blown to smithereens' and attached a video. Reuters found no other evidence of an attack and received no immediate confirmation from the White House or Defense Department. Reuters' image-analysis software found the clip was most likely synthetically generated. The post establishes that Trump made the claim; neither it nor the synthetic video establishes that an attack occurred.
- After the prior cutoff, Hamid Bovard, chief executive of the state-run National Iranian Oil Company, called Trump's post false and said conditions were calm, oil operations had not stopped, and workers were repairing earlier damage. Reuters still found no evidence that Kharg had been attacked. The named denial and reported continuity of operations weigh against the presidential claim but do not substitute for independent satellite or battle-damage evidence.
- At noon EDT on September 1, CENTCOM announced that U.S. forces had begun striking Islamic Revolutionary Guard Corps targets in Iran. CENTCOM said the operation followed attempted IRGC attacks on commercial shipping in the Strait of Hormuz and on U.S. service members in the region; its public statement did not identify every target, weapon, legal authority, expected duration or damage assessment.
- Reuters independently reported explosions at Qeshm Island and in or near Bandar Abbas, Chabahar, Jask and Sirik, while Iranian state media said a civilian airport at Jiroft was struck. Those location and civilian-target descriptions came from Iranian media and were not independently established by cutoff.
- Trump said the strikes were large and powerful, linked them to the alleged mine-laying attempt and Iran's earlier missile response, and threatened much larger attacks if Iran retaliated. Associated Press reported that Trump separately told Fox News the operation focused heavily on Iranian efforts to rebuild radar systems. The presidential statements establish the administration's asserted rationale and threat, not independent proof of the target intelligence or operational results.
- Associated Press reported an Iranian provincial official's claim that a U.S. strike hit a home hosting a wedding, killing two people and wounding at least 20. The United States had not publicly confirmed that strike or released a casualty assessment by cutoff, so the civilian-harm report remains attributed rather than presented as a verified U.S. finding.

## SIGNIFICANCE

The September 1 operation broadened a weekend launcher strike into a new multi-location U.S. attack wave and renewed the risk of reciprocal escalation, civilian harm and further disruption around a waterway central to global energy supply. The scope, legal basis and results remain materially less certain than the fact that the strikes began.

## GOALPOST / RESPONSE

The administration says the latest strikes responded to attempted attacks on commercial shipping and U.S. personnel and targeted IRGC capabilities, including radar reconstruction. Iran disputes the U.S. account and state-linked sources reported civilian sites and casualties. Public target lists, intelligence supporting imminence, battle-damage and casualty assessments, any War Powers notice, congressional authorization or restraint, subsequent Iranian action, mine incidents and verified vessel traffic remain the tests.

## MAYBE / THEREFORE

Maybe the September 1 strikes disabled capabilities tied to imminent attacks and protected shipping, or they may have widened the conflict without resolving the strait's closure and may have caused civilian harm. Therefore the record confirms that CENTCOM began a new strike wave against IRGC targets and preserves the administration's stated rationale, Trump's escalation threat and attributed Iranian casualty claims; it does not establish every target, the intelligence basis, proportionality, casualties, legality or improved maritime security.


## SOURCES

- [Reuters — Trump rejects Iran-deal extension and threatens Oman](https://www.reuters.com/world/middle-east/trump-says-iran-should-surrender-threatens-bomb-oman-2026-08-17/) — independent reporting on presidential statements and negotiations
- [Donald J. Trump on Truth Social — Strait of Hormuz mine-clearance claim and destruction warning](https://truthsocial.com/@realDonaldTrump/117156624974445904) — primary source for the fact that the president published the statement; not independent verification of claims inside it
- [U.S. Central Command — mine-clearance mission begins in the Strait of Hormuz](https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4457220/us-forces-start-mine-clearance-mission-in-strait-of-hormuz/) — primary military release documenting the mission's announced start and planned assets
- [Reuters — Trump says Hormuz was demined and warns against new mines](https://www.reuters.com/world/trump-says-strait-hormuz-has-been-demined-warns-iran-not-plant-more-2026-08-25/) — independent reporting on the presidential statement, continuing vessel attacks, and shipping-volume data
- [Associated Press — U.S. strikes Iranian rocket launchers on Larak Island](https://apnews.com/article/iran-strait-hormuz-strike-united-states-6b098da673ac3161a266ee459d5eff44) — independent reporting quoting a named CENTCOM spokesperson, Iranian response and unresolved operational details
- [Reuters — U.S. forces strike two Iranian launchers on Larak Island](https://www.reuters.com/world/middle-east/us-forces-strike-two-iranian-launchers-irans-larak-island-us-official-says-2026-08-30/) — independent confirmation through a U.S. official with Iranian casualty and retaliation claims clearly attributed
- [Donald Trump — Truth Social claim about Kharg Island](https://truthsocial.com/@realDonaldTrump/117187722429803464) — primary evidence that Trump published the Kharg Island statement and attached media; the post and attached media do not independently verify an attack
- [Reuters — Trump says Kharg is being attacked but gives no evidence](https://www.reuters.com/world/middle-east/us-iran-exchange-fire-flare-up-bessent-signals-more-sanctions-2026-08-31/) — independent reporting documenting the unconfirmed presidential claim, absence of official or Iranian corroboration, and synthetic-video analysis
- [Reuters — Iran's state oil chief denies Kharg attack claim](https://www.reuters.com/world/middle-east/trump-posts-ai-video-irans-kharg-smithereens-no-evidence-attack-2026-08-31/) — independent reporting of a named Iranian oil-company denial, continued operations claim and continued absence of attack evidence
- [U.S. Central Command — September 1 strikes on IRGC targets](https://x.com/CENTCOM/status/2094826294466810366) — primary operational announcement establishing the noon start of U.S. strikes and CENTCOM's stated response rationale
- [Trump Truth Social — September 1 Iran strike statement and escalation threat](https://truthsocial.com/@realDonaldTrump/117196950497702512) — primary record of the president's published rationale, operational characterizations and threat; not independent verification of claims inside the post
- [Reuters — United States begins new strike wave on Iranian targets](https://www.reuters.com/world/middle-east/iran-urges-us-comply-with-interim-deal-after-trump-threatens-further-strikes-2026-09-01/) — independent reporting on CENTCOM's announcement, reported strike locations, Iranian responses and unresolved operational scope
- [Associated Press — U.S. strikes Iran as renewed hostilities widen](https://apnews.com/article/iran-us-strikes-ad84a64884aedbbd1e5914182bb3cd8d) — independent reporting on U.S. strikes, Trump's radar explanation, CENTCOM's rationale and attributed Iranian civilian-casualty claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
