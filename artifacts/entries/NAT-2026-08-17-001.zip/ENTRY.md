# Trump rejects an Iran-deal extension, threatens Oman, and announces a wider Hormuz response

**Entry ID:** NAT-2026-08-17-001
**Date:** August 17–25, 2026
**Checked:** 2026-08-25 11:58 AM EDT
**Evidence state:** on-record presidential statements, primary CENTCOM mission background, and independent reporting; mine-clearance completion claimed but not independently confirmed
**Review state:** current-standard-reviewed

The president later claimed the strait had been cleared of mines and announced that vessels laying new mines would be destroyed; the completion claim remains unconfirmed by a fresh military release.

## THE FACTS

- President Trump said the United States would not extend the June memorandum's 60-day period for negotiating a final agreement with Iran and said Iran should surrender.
- The June memorandum had called for an immediate end to military operations and up to 60 days of negotiations, but it unraveled in July and the conflict continued.
- While Oman and Iran discussed restoring commercial shipping through the Strait of Hormuz, Trump threatened to bomb Oman if it 'gets in the way.' Reuters reported that the strait carried about 20% of global oil and liquefied-natural-gas supplies before the war began.
- On August 25, Trump said the Navy had told him all mines had been removed or detonated from the strait's international waters and announced that any vessel attempting to lay another mine would be 'immediately and systematically destroyed.' The Truth Social post proves that he issued the statement; it does not independently verify the operational claim.
- CENTCOM's latest located public release on the clearance mission, dated April 11, said forces had begun setting conditions for mine removal and that additional assets would join. No later Pentagon, Navy, or CENTCOM release confirming completion was located by the checked time. Reuters separately reported continued vessel attacks and Vortexa data showing roughly 5 million barrels per day of oil shipments on August 24, down from more than 20 million before the conflict.

## SIGNIFICANCE

The August 25 statement publicly announces a standing military consequence for future mine-laying and therefore changes the stated risk of direct escalation at a chokepoint central to global energy trade. It does not, by itself, establish that demining is complete or that commercial transit has returned to normal.

## GOALPOST / RESPONSE

Trump says the objective is to keep international waters open, prevent renewed mining, and stop Iran from obtaining a nuclear weapon. Those explanations do not resolve congressional war-authority questions, the earlier threat against Oman, the scope of the newly announced engagement policy, or the absence of fresh military confirmation for the clearance claim.

## MAYBE / THEREFORE

Maybe the threat is intended as deterrence and the Navy has completed work that CENTCOM has not yet documented publicly. Therefore the record treats mine clearance as a presidential claim, records the destruction warning as an announced military policy, and leaves implementation, legal authority, and effects on shipping open for verification.


## SOURCES

- [Reuters — Trump rejects Iran-deal extension and threatens Oman](https://www.reuters.com/world/middle-east/trump-says-iran-should-surrender-threatens-bomb-oman-2026-08-17/) — independent reporting on presidential statements and negotiations
- [Donald J. Trump on Truth Social — Strait of Hormuz mine-clearance claim and destruction warning](https://truthsocial.com/@realDonaldTrump/117156624974445904) — primary source for the fact that the president published the statement; not independent verification of claims inside it
- [U.S. Central Command — mine-clearance mission begins in the Strait of Hormuz](https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4457220/us-forces-start-mine-clearance-mission-in-strait-of-hormuz/) — primary military release documenting the mission's announced start and planned assets
- [Reuters — Trump says Hormuz was demined and warns against new mines](https://www.reuters.com/world/trump-says-strait-hormuz-has-been-demined-warns-iran-not-plant-more-2026-08-25/) — independent reporting on the presidential statement, continuing vessel attacks, and shipping-volume data

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
