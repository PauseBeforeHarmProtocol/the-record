# Trump widens the Hormuz warning and U.S. forces strike Iranian launchers

**Entry ID:** NAT-2026-08-17-001
**Date:** August 17–30, 2026
**Checked:** 2026-08-30 5:59 PM EDT
**Evidence state:** Trump's published warning, primary CENTCOM mission background, a named CENTCOM spokesperson quoted by Associated Press, and independent Reuters confirmation through a U.S. official; strike implemented, targeting basis attributed, casualties and effects unresolved
**Review state:** current-standard-reviewed

The August 30 strike moved the announced consequence for renewed mine-laying from a presidential warning to implemented military action; disputed casualties and Iran's threatened response remain unresolved.

## THE FACTS

- President Trump said the United States would not extend the June memorandum's 60-day period for negotiating a final agreement with Iran and said Iran should surrender.
- The June memorandum had called for an immediate end to military operations and up to 60 days of negotiations, but it unraveled in July and the conflict continued.
- While Oman and Iran discussed restoring commercial shipping through the Strait of Hormuz, Trump threatened to bomb Oman if it 'gets in the way.' Reuters reported that the strait carried about 20% of global oil and liquefied-natural-gas supplies before the war began.
- On August 25, Trump said the Navy had told him all mines had been removed or detonated from the strait's international waters and announced that any vessel attempting to lay another mine would be 'immediately and systematically destroyed.' The Truth Social post proves that he issued the statement; it does not independently verify the operational claim.
- CENTCOM's latest located public release on the clearance mission, dated April 11, said forces had begun setting conditions for mine removal and that additional assets would join. No later Pentagon, Navy, or CENTCOM release confirming completion was located by the checked time. Reuters separately reported continued vessel attacks and Vortexa data showing roughly 5 million barrels per day of oil shipments on August 24, down from more than 20 million before the conflict.
- On August 30, U.S. forces struck two Iranian launchers on Larak Island. A named CENTCOM spokesperson told the Associated Press that Islamic Revolutionary Guard Corps forces had been observed preparing to launch rockets carrying sea mines into the Strait of Hormuz; Reuters independently quoted a U.S. official giving the same account. The public reporting did not disclose the strike platform, damage assessment, targeting evidence, or whether rockets or mines had already been launched.
- Iran's Revolutionary Guard said the strike killed and wounded fighters and civilians and vowed a military and economic response. Iranian media described a drone strike, while the United States had not publicly confirmed the weapon used. Those casualty and platform claims were not independently verified by cutoff. AP described the attack as the first U.S. military action in a month, and Reuters called it the first known U.S. strike on Iran since late July.

## SIGNIFICANCE

The August 30 strike shows that the August 25 destruction warning was not merely rhetorical: the United States used force after reporting preparations for renewed mine-laying. It also renewed direct U.S.-Iran hostilities after a month-long lull at a chokepoint central to global energy trade, with retaliation and commercial-shipping consequences still open.

## GOALPOST / RESPONSE

The administration says the objective is to protect international shipping and that forces acted after observing preparations to launch rockets carrying sea mines. Iran says the strike caused military and civilian casualties and promises retaliation. Public targeting evidence, a damage and casualty assessment, any new War Powers notice, congressional action, Iran's response, mine incidents, vessel traffic, and independent confirmation of the earlier clearance claim are the tests.

## MAYBE / THEREFORE

Maybe the strike was a narrow defensive action that prevented an imminent attempt to remine the strait, or the U.S. assessment may be incomplete and the attack may trigger wider escalation. Therefore the record confirms an implemented U.S. strike on two launchers and accurately attributes the stated trigger; it does not independently prove the launch preparations, Iran's casualty claims, the strike's legality, or any resulting improvement in shipping safety.


## SOURCES

- [Reuters — Trump rejects Iran-deal extension and threatens Oman](https://www.reuters.com/world/middle-east/trump-says-iran-should-surrender-threatens-bomb-oman-2026-08-17/) — independent reporting on presidential statements and negotiations
- [Donald J. Trump on Truth Social — Strait of Hormuz mine-clearance claim and destruction warning](https://truthsocial.com/@realDonaldTrump/117156624974445904) — primary source for the fact that the president published the statement; not independent verification of claims inside it
- [U.S. Central Command — mine-clearance mission begins in the Strait of Hormuz](https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4457220/us-forces-start-mine-clearance-mission-in-strait-of-hormuz/) — primary military release documenting the mission's announced start and planned assets
- [Reuters — Trump says Hormuz was demined and warns against new mines](https://www.reuters.com/world/trump-says-strait-hormuz-has-been-demined-warns-iran-not-plant-more-2026-08-25/) — independent reporting on the presidential statement, continuing vessel attacks, and shipping-volume data
- [Associated Press — U.S. strikes Iranian rocket launchers on Larak Island](https://apnews.com/article/iran-strait-hormuz-strike-united-states-6b098da673ac3161a266ee459d5eff44) — independent reporting quoting a named CENTCOM spokesperson, Iranian response and unresolved operational details
- [Reuters — U.S. forces strike two Iranian launchers on Larak Island](https://www.reuters.com/world/middle-east/us-forces-strike-two-iranian-launchers-irans-larak-island-us-official-says-2026-08-30/) — independent confirmation through a U.S. official with Iranian casualty and retaliation claims clearly attributed

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
