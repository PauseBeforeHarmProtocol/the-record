# Federal judge dismisses DOJ challenge to New York City sanctuary laws

**Entry ID:** NAT-2026-10-15-004
**Date:** October 15, 2026
**Checked:** 2026-10-15 11:57 PM EDT
**Evidence state:** DOJ’s filed complaint and litigation announcement, case docket and independent Reuters report of the district-court dismissal; ruling verified at district-court stage, appellate status unresolved
**Review state:** current-standard-reviewed

The district court rejected the administration’s preemption and information-sharing theories; the ruling leaves the local limits in place unless later litigation changes the result.

## THE FACTS

- U.S. District Judge Ramon Reyes dismissed the Justice Department’s lawsuit seeking to invalidate New York City laws that limit local cooperation with federal immigration enforcement.
- Reuters reported that Reyes held DOJ could not challenge the city’s refusal to detain people on federal civil immigration requests because New York state law already bars that practice, and that federal law does not require state or local governments to provide release dates, locations or other custody information.
- The July 2025 complaint had alleged the provisions obstruct federal immigration enforcement, violated the Supremacy Clause and endangered the public; those were the administration’s litigating claims. The October 15 dismissal rejected the legal basis for that suit rather than adjudicating every application of every sanctuary policy.
- DOJ did not immediately respond to Reuters’ request for comment. The ruling is a district-court disposition in United States v. City of New York, No. 1:25-cv-04084, and any appeal or later stay remained unresolved at cutoff.

## SIGNIFICANCE

The ruling is a material judicial limit on the administration’s campaign to compel local participation in federal immigration enforcement. It preserves New York City’s information-sharing and detention limits at the district-court stage while leaving appellate review possible.

## GOALPOST / RESPONSE

DOJ argued that the city obstructed federal enforcement and public safety; the court found no valid preemption basis for compelling the challenged assistance. A notice of appeal, stay request, appellate decision, revised federal theory or measurable change in transfers and community enforcement are the tests.

## MAYBE / THEREFORE

Maybe an appellate court will revive some claims or a narrower challenge could succeed, while the city’s rules may still impose operational costs on ICE. Therefore the verified result is a district-court dismissal preserving the challenged local limits—not a nationwide ruling on all sanctuary laws or a final appellate judgment.


## SOURCES

- [Justice Department — New York City sanctuary-policy complaint](https://www.justice.gov/opa/pr/justice-department-sues-new-york-city-over-sanctuary-policies) — primary litigation announcement and complaint
- [Civil Rights Litigation Clearinghouse — United States v. City of New York docket](https://clearinghouse.net/case/46818/) — case docket and document index
- [Reuters — judge dismisses federal challenge to New York City sanctuary laws](https://www.reuters.com/legal/government/us-judge-tosses-trump-administration-lawsuit-over-new-york-city-sanctuary-laws-2026-10-15/) — independent reporting of district-court ruling

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
