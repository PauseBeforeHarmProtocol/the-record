# DOJ and HHS consolidate criminal health-care fraud self-disclosures

**Entry ID:** NAT-2026-10-15-002
**Date:** October 15, 2026
**Checked:** 2026-10-15 5:58 PM EDT
**Evidence state:** DOJ policy announcement, HHS-OIG protocol page and independent STAT reporting with a named DOJ official; operational route documented, future uptake and outcomes unmeasured
**Review state:** current-standard-reviewed

A new policy directs potentially criminal federal health-program misconduct to DOJ first and extends HHS-OIG protocol benefits without a second portal submission.

## THE FACTS

- The Justice Department's National Fraud Enforcement Division and HHS Office of Inspector General announced a coordinated self-disclosure policy for potentially criminal conduct affecting federal health-care programs.
- Under the announced policy, a company that voluntarily discloses qualifying criminal conduct to DOJ's Health Care Fraud Section receives the benefits of HHS-OIG's Self-Disclosure Protocol automatically, without a separate direct submission through the HHS-OIG portal.
- HHS-OIG updated its protocol to clarify that potentially criminal conduct should be disclosed to DOJ. DOJ said disclosure only to HHS-OIG generally will not constitute a voluntary disclosure to DOJ or qualify for a declination on that basis; the policy does not guarantee a declination or settlement outcome in every case.
- DOJ and HHS say the consolidation removes uncertainty and delay where one arrangement may carry criminal, civil and administrative exposure. STAT independently reported the one-stop process and a named DOJ official's explanation that the government wants to reward remediation; measurable disclosure volume, case resolution and deterrence effects are not yet available.

## SIGNIFICANCE

The policy changes the operational route and potential incentives for companies reporting criminal health-care fraud, linking DOJ corporate-enforcement benefits with HHS-OIG's administrative protocol. It is implemented guidance, not proof that disclosures, declinations or recoveries will increase.

## GOALPOST / RESPONSE

DOJ and HHS say one coordinated entry point will reduce confusion, speed disclosures and reward remediation. Published eligibility criteria, consistent application, disclosure counts, declinations, resolutions, recoveries, processing time and evidence of reduced fraud are the tests.

## MAYBE / THEREFORE

Maybe streamlined incentives surface misconduct sooner and improve remediation, or companies may still find eligibility uncertain and the policy may mainly reorganize intake. Therefore the consolidated route and stated benefits are in force; uptake, consistency and enforcement outcomes remain to be measured.


## SOURCES

- [Justice Department — criminal health-care fraud self-disclosure protocol](https://www.justice.gov/opa/pr/national-fraud-enforcement-division-and-department-health-and-human-services-announce-self) — primary enforcement-policy announcement
- [HHS OIG — Health Care Fraud Self-Disclosure Protocol](https://oig.hhs.gov/compliance/self-disclosure-info/self-disclosure-protocol/) — primary compliance protocol and submission guidance
- [STAT — DOJ consolidates criminal health-care fraud self-disclosures](https://www.statnews.com/2026/10/15/healthcare-fraud-new-doj-policy-rewards-self-disclosure/) — independent policy reporting and named official interview

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
