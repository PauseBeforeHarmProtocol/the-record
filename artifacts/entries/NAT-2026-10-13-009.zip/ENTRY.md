# Trump signs pardons for two Alaska diesel mechanics at rally

**Entry ID:** NAT-2026-10-13-009
**Date:** October 13, 2026
**Checked:** 2026-10-14 12:01 AM EDT
**Evidence state:** independent Associated Press live-event reporting and independent video of the presidential signing; clemency signed, full official instruments not yet posted at the review cutoff
**Review state:** current-standard-reviewed

The president signed unconditional pardons for Zachary Czubak and Patrick Fleming, who had pleaded guilty to a Clean Air Act conspiracy involving emissions-control tampering.

## THE FACTS

- President Donald Trump signed documents onstage in Anchorage granting unconditional pardons to Zachary Czubak and Patrick Fleming, co-owners of Arm Rippin Toys. Independent video and Associated Press reporting documented the signing during the October 13 rally.
- Czubak and Fleming pleaded guilty in 2022 to conspiracy to violate the Clean Air Act by tampering with or removing diesel-emissions controls. The pardons apply to the federal convictions; they do not erase the historical guilty pleas or independently determine that the underlying conduct did not occur.
- Trump described the prosecutions as wrongful and the punishment as excessive, presenting the pardons as correction of government overreach against Alaska mechanics. Associated Press reported that the documents had not yet appeared on the Justice Department's clemency page by Tuesday night.
- The signed pardons are completed presidential clemency acts, while official publication and any downstream effects on fines, supervision or records remain follow-up questions. The archive does not infer those effects without the operative documents and case records.

## SIGNIFICANCE

The event used the constitutional clemency power to nullify federal punishment for two environmental-crime convictions and made the administration's enforcement critique operational rather than rhetorical. The public onstage format also makes the act independently observable, though the complete instruments and legal aftereffects still require official posting.

## GOALPOST / RESPONSE

Trump says the pardons remedy unjust or excessive prosecutions of small-business mechanics. Tests include publication of the signed instruments, their precise scope, implementation in the criminal cases and whether the administration changes emissions-tampering enforcement policy more broadly.

## MAYBE / THEREFORE

Maybe the cases involved disproportionate punishment that clemency appropriately corrected, or the pardons may weaken deterrence for conduct Congress made unlawful to protect air quality. Therefore Trump signed pardons for two named convictions—not a judicial exoneration, a finding that emissions tampering is harmless or a documented change to the Clean Air Act itself.


## SOURCES

- [Associated Press — Trump signs pardons for two Alaska diesel mechanics](https://apnews.com/article/aa4ec095692c57a851a942c0f21624f7) — independent live-event reporting and conviction context
- [Fox News — onstage signing of Alaska diesel-mechanic pardons](https://www.foxnews.com/politics/president-trump-signs-pardons-alaska-diesel-mechanics-onstage-rally-touting-major-energy-deals) — independent event video and reporting showing the presidential signing

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
