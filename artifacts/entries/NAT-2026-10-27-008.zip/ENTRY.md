# Reported ruling disqualifies Essayli from two prosecutions, with enforcement delayed

**Entry ID:** NAT-2026-10-27-008
**Date:** October 27, 2026
**Checked:** 2026-10-28 1:20 AM EDT
**Evidence state:** AP and Daily Journal original reporting, with brief Los Angeles Times confirmation. Named judicial ruling as reported; primary order uninspected. Earlier-date recovery; AP publication was October 28 at 04:36:45 UTC, before the new window.
**Review state:** current-standard-reviewed

AP and the Daily Journal report a new appointment-authority ruling; it does not establish immediate removal or dismissal of prosecutions.

## THE FACTS

- AP and the Daily Journal report that Judge J. Michael Seabright ruled October 27 that Bill Essayli was unlawfully serving as de facto U.S. attorney despite first-assistant and special-attorney designations.
- The Daily Journal identifies disqualification from participating in or supervising the Ramirez and Tran prosecutions. Enforcement is postponed for a government stay request. The original order was not retrieved, so this record asserts no exact operative deadline.
- The Los Angeles Times reports the indictments were not dismissed. AP reports Essayli disagrees and defends presidential and attorney-general authority to select DOJ supervisors while anticipating Supreme Court review.

## SIGNIFICANCE

The reported ruling tests executive control of a major prosecution office through delegated titles rather than Senate confirmation. It does not automatically invalidate other prosecutions.

## GOALPOST / RESPONSE

Essayli’s documented defense is executive authority to choose DOJ supervisors. The scope and legality of delegation remain contested through the stay and appellate process; an anticipated Supreme Court decision is not an existing ruling.

## MAYBE / THEREFORE

Maybe lawful delegation supports continuity, or it evades appointment limits. Therefore the finding is a reported, narrowly scoped disqualification with delayed enforcement, not completed removal or nationwide invalidation.


## SOURCES

- [Federal judge rules top U.S. prosecutor in Los Angeles is not legally serving](https://apnews.com/article/c3e6aa99c9d90193d649b8565e4f213a) — independent reporting
- [Federal judge disqualifies Essayli from overseeing criminal prosecutions](https://www.dailyjournal.com/articles/395705-federal-judge-disqualifies-essayli-from-overseeing-criminal-prosecutions) — independent legal reporting
- [Judge finds L.A. prosecutor unlawfully serving and bars him from two cases](https://www.latimes.com/california/story/2026-10-27/judge-finds-l-a-s-top-federal-prosecutor-is-unlawfully-serving-bars-him-from-two-cases) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
