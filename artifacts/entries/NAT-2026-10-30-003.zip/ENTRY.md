# U.S. approves proposed Ukraine Patriot sale; delivery remains unresolved

**Entry ID:** NAT-2026-10-30-003
**Date:** October 30, 2026
**Checked:** 2026-10-31 11:58 AM EDT
**Evidence state:** AP, Reuters and CNN corroboration of public official statements; original notification unavailable; reported approval of proposed sale, implementation unverified
**Review state:** current-standard-reviewed

Corroborated reporting of a possible $2.1 billion sale is not proof of a signed final agreement, shipment or immediate winter protection.

## THE FACTS

- Reuters and Associated Press reported that the State Department approved a proposed sale of 500 Patriot interceptors to Ukraine on October 30, with an estimated value of $2.1 billion. Reuters identified Lockheed Martin as principal contractor. The original State Department release and congressional notification were not retrieved in this review.
- Reuters reported that Ukraine would pay using Canadian, German and Norwegian contributions routed through JUMPSTART and Ukrainian funds financed by the EU’s Ukraine Support Loan. AP and CNN reported that the proposed purchase involves no U.S. financing. These descriptions do not establish completed payments, production or deliveries.
- CNN reported that Zelenskyy welcomed approval but warned that delivery could take years and requested interim releases from existing partner stocks. CNN said the State announcement supplied no delivery timetable. Those requests and warnings do not establish that stock transfers were approved or that a particular delivery year is guaranteed.
- CNN reported that State was not aware of an offset arrangement for production in Ukraine and said such arrangements could be negotiated by purchaser and contractor. This approval does not establish a Ukrainian factory, a technology-transfer license or completed local production.

## SIGNIFICANCE

Approval can permit a major defensive procurement while leaving the urgent protection gap unresolved. Delivery timing, available stocks and completed agreements matter separately from the headline quantity and estimated value.

## GOALPOST / RESPONSE

The administration frames the proposed sale as strengthening a European partner and advancing U.S. foreign-policy and security interests. Ukraine welcomes approval while seeking near-term protection. Final agreements, actual financing, production schedules and delivered interceptors—not approval alone—are the tests.

## MAYBE / THEREFORE

Maybe the approval enables useful future defense capacity and partners can arrange interim supplies. Therefore the established development is a reported proposed-sale approval, not delivered ammunition, verified inventory availability, an immediate security benefit or completed Ukrainian production.


## SOURCES

- [Reuters — Ukraine Patriot sale approval and delivery limits](https://www.investing.com/news/stock-market-news/us-approves-21-billion-patriot-missile-sale-to-ukraine-4988538) — independent reporting of proposed sale approval; original State/DSCA notification not retrieved
- [Associated Press — Ukraine Patriot sale approval and delivery limits](https://abcnews.com/amp/US/wireStory/us-approves-proposed-21-billion-sale-patriot-interceptors-137720328) — independent reporting of proposed sale approval; original State/DSCA notification not retrieved
- [CNN — Ukraine Patriot sale approval and delivery limits](https://kesq.com/news/national-politics/cnn-us-politics/2026/10/31/us-approves-potential-2-1-billion-sale-of-scarce-patriot-missiles-to-ukraine/) — independent reporting of proposed sale approval; original State/DSCA notification not retrieved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
