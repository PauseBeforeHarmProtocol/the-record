# NTSB identifies steering casualty in New Orleans vessel collision

**Entry ID:** NAT-2026-11-14-001
**Date:** November 13–15, 2026
**Checked:** 2026-11-15 6:03 PM EST
**Evidence state:** Reuters reporting quoting named NTSB investigator Bart Barnum on preliminary recorder evidence and the steering sequence, layered with the prior named NTSB, Coast Guard, Associated Press and operator records; the steering casualty is a preliminary evidentiary finding, not probable cause or a final fault determination
**Review state:** current-standard-reviewed

Preliminary recorder review showed the tanker's rudder stuck to starboard about two minutes before impact, sending the vessel east toward the docked passenger boat; investigators had not determined why the steering failed.

## THE FACTS

- On November 13, the asphalt tanker Atlantic Asphalt struck the docked American Heritage passenger vessel in New Orleans, causing the passenger vessel to capsize. Later Reuters reporting said 191 people were aboard; AP's initial report used a lower preliminary count. Both reported that everyone survived, so the differing early headcounts are not treated as a settled casualty count.
- NTSB member John DeLeeuw said at a November 14 news conference that investigators had recovered the tanker's voyage data recorder, which can preserve speed, direction, course, bridge audio and other information. Reuters reported that 16 NTSB investigators were on site, scheduling interviews and asking the public to submit video.
- On November 15, NTSB investigator Bart Barnum said preliminary recorder review showed a steering casualty: the rudder became stuck to starboard and the tanker veered east toward the docked passenger vessel. Reuters reported the steering event occurred about two minutes before impact; investigators had not determined why the steering failed.
- Barnum said investigators were examining whether anchors were deployed, the water depth and other circumstances, and planned crew interviews. Those are open investigative questions; the preliminary steering sequence does not establish probable cause, regulatory compliance, negligence or criminal conduct.
- OSM Thome, the tanker's manager, said the master immediately reported the incident to the Coast Guard, the tanker crew was safe, the vessel was stable at anchor and the company was cooperating with authorities. That statement establishes the operator's response, not the collision's cause, compliance outcome or absence of operator fault.

## SIGNIFICANCE

The recorder-based steering sequence materially narrows what happened immediately before impact and gives investigators a specific mechanical and operational line of inquiry. It remains preliminary: a stuck rudder describes the casualty sequence but does not explain the failure, assign responsibility or substitute for the NTSB and Coast Guard final processes.

## GOALPOST / RESPONSE

The operator says it reported the collision promptly, activated its emergency response and is cooperating. Accountability should be measured through the completed recorder and bridge-data analysis, steering-system examination, crew and pilot interviews, water-depth and anchor evidence, the NTSB probable-cause process, Coast Guard findings, safety recommendations and any enforcement—not the preliminary steering sequence alone.

## MAYBE / THEREFORE

Maybe the stuck rudder arose from a discrete mechanical failure, or the final investigation may identify interacting maintenance, design, navigation, pilotage or organizational factors. Therefore this refresh establishes a preliminary recorder-supported steering casualty and a more specific investigative sequence—not why the rudder failed, probable cause, operator liability, criminal conduct or a completed safety remedy.


## SOURCES

- [Reuters — NTSB recovers voyage recorder after New Orleans vessel collision](https://www.reuters.com/world/us/data-recorder-recovered-tanker-new-orleans-cruise-ship-collision-ntsb-says-2026-11-14/) — independent reporting quoting named NTSB member at Saturday news conference
- [Associated Press — all aboard survive New Orleans tanker and passenger-vessel collision](https://apnews.com/article/new-orleans-tanker-river-cruise-rescue-passengers-757bed7a70ceb72f0d7140143fe2a764) — independent event reporting quoting Coast Guard and local officials
- [OSM Thome — Atlantic Asphalt allision holding statement](https://osmthome.com/atlantic-asphalt-allision-in-mississippi-river/) — vessel manager response; primary only for its own account and cooperation statement
- [Reuters — NTSB identifies steering casualty in New Orleans vessel collision](https://www.reuters.com/world/us/tanker-new-orleans-ship-collision-suffered-steering-casualty-ntsb-says-2026-11-15/) — independent reporting quoting named NTSB investigator on preliminary recorder evidence, steering sequence and unresolved cause

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
