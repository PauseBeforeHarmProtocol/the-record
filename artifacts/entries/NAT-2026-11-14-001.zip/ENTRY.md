# NTSB recovers voyage recorder after New Orleans passenger-vessel collision

**Entry ID:** NAT-2026-11-14-001
**Date:** November 13–14, 2026
**Checked:** 2026-11-15 12:09 AM EST
**Evidence state:** Reuters reporting quoting named NTSB member John DeLeeuw at a Saturday news conference, Associated Press event reporting quoting Coast Guard and local officials, and the vessel manager's response; no standalone public NTSB release was located in the reviewed window, and investigation and evidence recovery were implemented while cause and accountability remain unresolved
**Review state:** current-standard-reviewed

Sixteen federal investigators were on site and the tanker's voyage recorder had been recovered after the collision sent about 100 people into the Mississippi River; no cause finding had been issued.

## THE FACTS

- On November 13, the asphalt tanker Atlantic Asphalt struck the docked American Heritage passenger vessel in New Orleans, causing the passenger vessel to capsize. Later Reuters reporting said 191 people were aboard; AP's initial report used a lower preliminary count. Both reported that everyone survived, so the differing early headcounts are not treated as a settled casualty count.
- NTSB member John DeLeeuw said at a November 14 news conference that investigators had recovered the tanker's voyage data recorder, which can preserve speed, direction, course, bridge audio and other information. Reuters reported that 16 NTSB investigators were on site, scheduling interviews and asking the public to submit video.
- Reuters reported that first responders pulled about 100 people from the river, 32 people were hospitalized Friday and nine remained hospitalized Saturday afternoon. AP independently reported 32 noncritical hospitalizations and quoted local officials describing a large rescue response; no death was reported.
- The Coast Guard said the exact cause was unknown. Early descriptions of an apparent steering loss and video-based expert speculation are leads, not an NTSB finding; the recovered recorder had not yet produced a published causal conclusion within the evidence window.
- OSM Thome, the tanker's manager, said the master immediately reported the incident to the Coast Guard, the tanker crew was safe, the vessel was stable at anchor and the company was cooperating with authorities. That statement establishes the operator's response, not the collision's cause, compliance outcome or absence of operator fault.

## SIGNIFICANCE

The NTSB's on-site deployment and recovery of the recorder turn a major passenger-vessel disaster into a documented federal safety investigation with preserved technical evidence. The investigation may inform national marine-safety practice, but its existence does not establish cause or fault.

## GOALPOST / RESPONSE

The operator says it reported the collision promptly, activated its emergency response and is cooperating, while the Coast Guard had not determined a cause. Accountability should be measured through preserved recorder and bridge data, interviews, vessel and steering-system examinations, pilot and traffic records, the NTSB probable-cause process, Coast Guard findings, safety recommendations and any enforcement—not early descriptions or the recovery of evidence alone.

## MAYBE / THEREFORE

Maybe the recorder and interviews will identify a discrete mechanical or steering failure, or they may reveal interacting equipment, navigation, pilotage or organizational factors. Therefore the record establishes a federal investigation, recovered voyage data and measured human consequences—not a probable cause, criminal act, terrorism, operator liability or completed safety remedy.


## SOURCES

- [Reuters — NTSB recovers voyage recorder after New Orleans vessel collision](https://www.reuters.com/world/us/data-recorder-recovered-tanker-new-orleans-cruise-ship-collision-ntsb-says-2026-11-14/) — independent reporting quoting named NTSB member at Saturday news conference
- [Associated Press — all aboard survive New Orleans tanker and passenger-vessel collision](https://apnews.com/article/new-orleans-tanker-river-cruise-rescue-passengers-757bed7a70ceb72f0d7140143fe2a764) — independent event reporting quoting Coast Guard and local officials
- [OSM Thome — Atlantic Asphalt allision holding statement](https://osmthome.com/atlantic-asphalt-allision-in-mississippi-river/) — vessel manager response; primary only for its own account and cooperation statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
