# Trump revokes Chesapeake Bay order and redirects federal support

**Entry ID:** NAT-2026-09-16-009
**Date:** September 16, 2026
**Checked:** 2026-09-20 11:58 PM EDT
**Evidence state:** signed White House order and official Federal Register text; revocation and agency instructions ordered, downstream resource, fee and water-quality effects unmeasured
**Review state:** current-standard-reviewed

Executive Order 14428 shifts federal Chesapeake Bay resources toward measurable projects and directs EPA to encourage repeal of local stormwater fees.

## THE FACTS

- President Trump signed Executive Order 14428 on September 16, immediately revoking Executive Order 13508, the 2009 federal Chesapeake Bay protection and restoration framework. The later Federal Register publication confirms the signed instrument; this record is restored as a prior-window omission.
- The order directs Defense, Interior, Agriculture, Commerce, Homeland Security and EPA to assess their Chesapeake Bay support and focus fiscal and personnel resources on direct projects in areas of highest need. Agencies that fund Bay health must prioritize projects that directly reduce nutrient and sediment runoff and document measurable water-quality outcomes.
- EPA must coordinate with six watershed states and the District of Columbia to assess household burdens from stormwater-management fees, explore alternatives that do not increase residents' costs and encourage states and localities to repeal or rescind those fees. The order itself does not repeal a state or local fee, cancel a named grant or set a new funding amount.
- The administration says the revoked framework lacked clarity, imposed what it calls 'rain taxes' with little measurable benefit and should be replaced by empirically measured projects. Those are the order's policy findings; implementation remains subject to law and appropriations, and no resulting funding shift, fee repeal or water-quality effect was measured by cutoff.

## SIGNIFICANCE

The order replaces a 17-year federal Chesapeake Bay coordination framework and can redirect agency staff and grant priorities while applying federal pressure against local stormwater fees. Its environmental and household-cost effects will depend on later agency choices and measured results, not the revocation alone.

## GOALPOST / RESPONSE

The administration says measurable, on-the-ground projects can improve Bay health without costly stormwater fees. Agency resource assessments, identified reallocations, grant decisions, local fee changes, nutrient and sediment data, water-quality trends and legal challenges are the tests.

## MAYBE / THEREFORE

Maybe tighter performance requirements will concentrate resources on effective projects and reduce unnecessary household costs, or dismantling the prior coordination framework and discouraging dedicated fees may weaken long-term restoration capacity. Therefore the order revokes the prior framework and directs reassessment and advocacy—not a completed fee repeal, specified budget cut or demonstrated water-quality improvement.


## SOURCES

- [White House — Executive Order 14428 on Chesapeake Bay support](https://www.whitehouse.gov/presidential-actions/2026/09/providing-meaningful-water-quality-improvements-through-collaboration-and-oversight-of-federal-support/) — primary signed executive order
- [Federal Register — Executive Order 14428 official publication](https://www.federalregister.gov/documents/2026/09/21/2026-19335/providing-meaningful-water-quality-improvements-through-collaboration-and-oversight-of-federal) — official publication of signed executive order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
