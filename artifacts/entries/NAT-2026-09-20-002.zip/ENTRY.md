# United States receives 18 Haiti assassination suspects for federal prosecution

**Entry ID:** NAT-2026-09-20-002
**Date:** September 20–21, 2026
**Checked:** 2026-09-21 6:01 PM EDT
**Evidence state:** named statements from the U.S. attorney and Haitian justice minister plus independent Reuters and Associated Press reporting and an observed federal court appearance; transfer and initial appearance implemented, allegations and ultimate liability unresolved
**Review state:** current-standard-reviewed

The defendants were transferred from Haitian custody and appeared in Miami federal court; the charges remain allegations and no new conviction was entered.

## THE FACTS

- A military aircraft transferred 18 people from Haitian custody to the United States on September 20 in connection with the 2021 assassination of Haitian President Jovenel Moïse. U.S. Attorney Jason Reding Quiñones announced the transfer, and Haiti's justice minister independently confirmed it; transfer establishes custody and prosecution, not guilt.
- On September 21, the 18 defendants appeared in federal court in Miami. Associated Press reported that U.S. Magistrate Judge Lisette Reid appointed counsel and set additional court dates. Joseph Badio and the other defendants face charges or allegations tied to the plot; those accusations have not been adjudicated as to the newly transferred group.
- U.S. authorities say South Florida served as a planning and financing base for the plot. Reuters and Associated Press reported that 30 people have been indicted in the U.S. case and that at least nine had already been convicted at trial or by guilty plea; those earlier outcomes are not convictions of all 18 new defendants.
- Haiti's justice ministry said its own proceedings faced significant delays, including repeated judicial turnover and insecurity. The transfer may advance the U.S. case, but it does not resolve Haiti's investigation, determine every defendant's role or repair the country's justice-system constraints.

## SIGNIFICANCE

The transfer moves a large group from a stalled Haitian process into an active U.S. prosecution concerning a presidential assassination allegedly planned in part from South Florida. Its accountability value depends on lawful proceedings and evidence tested in court rather than the transfer itself.

## GOALPOST / RESPONSE

The U.S. attorney calls the transfer a major new phase in pursuing accountability, while Haitian officials cite severe barriers to a domestic trial. Indictments, detention and counsel records, discovery, motions, plea or trial outcomes, appellate review and coordination with Haiti are the tests.

## MAYBE / THEREFORE

Maybe the consolidated U.S. proceedings will produce tested evidence and accountable judgments, or jurisdictional, evidentiary and due-process problems may prolong the case. Therefore 18 defendants were transferred and appeared in federal court—not that the allegations were proven, every suspect was charged identically or Haiti's investigation concluded.


## SOURCES

- [Reuters — 18 Haiti assassination suspects transferred to the United States](https://www.reuters.com/world/americas/suspects-2021-killing-haitian-president-flown-us-face-trial-2026-09-20/) — independent reporting with named U.S. and Haitian official confirmation
- [Associated Press — 18 Haiti assassination defendants appear in Miami federal court](https://apnews.com/article/haiti-assassination-us-charges-9fcfd67d71952037038ae62b5ed1b0a1) — independent courthouse reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
