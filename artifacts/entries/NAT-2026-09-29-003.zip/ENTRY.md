# Trump orders executive branch to call artificial intelligence 'Super Intelligence'

**Entry ID:** NAT-2026-09-29-003
**Date:** September 29–October 6, 2026
**Checked:** 2026-10-06 6:08 PM EDT
**Evidence state:** signed executive order plus Reuters reporting based on a DOJ implementation memo; DOJ implementation reported, original memo and government-wide completeness not independently retrieved
**Review state:** current-standard-reviewed

DOJ has begun implementing the terminology order in official communications; statutory definitions and substantive AI rules remain unchanged.

## THE FACTS

- President Trump signed an executive order directing executive departments and agencies, to the maximum extent permitted by law, to use 'Super Intelligence' and 'SI' instead of 'Artificial Intelligence' and 'AI' in official correspondence, public communications, websites, reports, policy documents and other nonstatutory materials.
- For present purposes, the order defines Super Intelligence by the existing statutory artificial-intelligence definition in 15 U.S.C. 9401(3). It says prior regulations, orders, contracts, grants, historical documents and statutory terminology are not altered.
- The Assistant to the President for Science and Technology must submit proposed legislative language within 60 days, including an assessment of statutory usage and recommendations for conforming amendments. Congress had not enacted such changes by cutoff.
- The order establishes a government communications rule and legislative proposal process. It does not create a new technical capability, change binding safety standards, appropriate funds or independently demonstrate improved AI performance.
- Reuters reported on October 6 that Acting Deputy Attorney General Trent McCotter directed Justice Department personnel to use 'Super Intelligence' or 'SI' instead of AI in public communications, policy documents, official records and court filings when appropriate. The reported memo establishes department-level implementation; the original memo was not retrieved, and it does not establish complete government-wide compliance.

## SIGNIFICANCE

The DOJ memo is concrete department-level implementation of the president's communications rule, including potential court filings. It still changes terminology rather than underlying statutory definitions, contracts, safety standards or technical capability.

## GOALPOST / RESPONSE

The administration says 'Super Intelligence' better conveys promise and ambition. The 60-day legislative proposal, implementation across agencies, court usage, public clarity, transition costs and any substantive policy change remain the tests.

## MAYBE / THEREFORE

Maybe consistent language improves strategic communication, or applying a political label in official and court records may create confusion without changing legal meaning. Therefore DOJ implementation is reported, while government-wide compliance, statutory change and measurable technology outcomes remain unestablished.


## SOURCES

- [White House — Inaugurating the Era of Super Intelligence](https://www.whitehouse.gov/presidential-actions/2026/09/inaugurating-the-era-of-super-intelligence/) — signed presidential executive order
- [Reuters — DOJ directs staff to use 'Super Intelligence' terminology](https://www.reuters.com/legal/litigation/us-justice-dept-tells-staff-call-ai-super-intelligence-under-trump-order-2026-10-06/) — independent reporting based on reviewed DOJ memo

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
