# Trump orders executive branch to call artificial intelligence 'Super Intelligence'

**Entry ID:** NAT-2026-09-29-003
**Date:** September 29, 2026
**Checked:** 2026-09-29 5:56 PM EDT
**Evidence state:** signed executive order; executive communications rule ordered and legislative language requested, statutory change and substantive technology effects absent
**Review state:** current-standard-reviewed

The terminology order changes nonstatutory executive communications and seeks legislation; it does not alter the statutory AI definition, contracts or safety rules.

## THE FACTS

- President Trump signed an executive order directing executive departments and agencies, to the maximum extent permitted by law, to use 'Super Intelligence' and 'SI' instead of 'Artificial Intelligence' and 'AI' in official correspondence, public communications, websites, reports, policy documents and other nonstatutory materials.
- For present purposes, the order defines Super Intelligence by the existing statutory artificial-intelligence definition in 15 U.S.C. 9401(3). It says prior regulations, orders, contracts, grants, historical documents and statutory terminology are not altered.
- The Assistant to the President for Science and Technology must submit proposed legislative language within 60 days, including an assessment of statutory usage and recommendations for conforming amendments. Congress had not enacted such changes by cutoff.
- The order establishes a government communications rule and legislative proposal process. It does not create a new technical capability, change binding safety standards, appropriate funds or independently demonstrate improved AI performance.

## SIGNIFICANCE

The order standardizes politically favored terminology across executive communications and could shape future legislation, but its immediate legal effect is narrower than a substantive AI regulation or technology program.

## GOALPOST / RESPONSE

The administration says 'Super Intelligence' better conveys the technology's promise and American ambition. The 60-day proposal, agency implementation, congressional response, costs, public clarity and any substantive policy changes are the tests.

## MAYBE / THEREFORE

Maybe a common label improves strategic communication, or it may obscure established technical and statutory meanings without changing capability or risk. Therefore the order changes executive-branch terminology and requests legislation—not the present statutory definition, existing obligations or measured technology outcomes.


## SOURCES

- [White House — Inaugurating the Era of Super Intelligence](https://www.whitehouse.gov/presidential-actions/2026/09/inaugurating-the-era-of-super-intelligence/) — signed presidential executive order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
