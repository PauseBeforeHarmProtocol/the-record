# Federal judge blocks election conditions on counterterrorism grants

**Entry ID:** NAT-2026-09-28-005
**Date:** September 28, 2026
**Checked:** 2026-09-28 5:55 PM EDT
**Evidence state:** named federal-court ruling reported by Reuters, including the relief, grant scale, challenged conditions and DHS response; primary order not retrieved by cutoff
**Review state:** current-standard-reviewed

The order bars FEMA and DHS from withholding 20% of roughly $1.1 billion based on state adoption of hand-marked ballots, manual audits and voter-roll comparisons.

## THE FACTS

- U.S. District Judge Amir Ali blocked FEMA and the Department of Homeland Security from withholding 20% of approximately $1.1 billion in counterterrorism grants from jurisdictions that declined three election-administration conditions.
- The challenged conditions called for hand-marked paper ballots, manual audits of at least 5% of ballots and comparison of voter rolls with federal data. The order does not itself change state election procedures.
- Ali concluded that Congress had not authorized the counterterrorism-grant programs to be used to compel election-administration changes. Separate state challenges remain pending, and no appeal result or higher-court stay was established at cutoff.
- DHS said the conditions were intended to protect elections from foreign interference and cyberattacks. That justification remains the administration's stated rationale; the ruling concerns the grant authority used to impose it.

## SIGNIFICANCE

The ruling immediately limits the administration's ability to use an established national-security grant stream as leverage over state election systems. It is judicial relief at one litigation stage, not a final nationwide resolution of every related condition.

## GOALPOST / RESPONSE

The administration argues that election-security safeguards are a proper counterterrorism and cyber-defense condition. The court's response is that agencies must remain within Congress's grant authority. The written order, appeal, any stay, grant payments and the separate state cases are the next tests.

## MAYBE / THEREFORE

Maybe the conditions address genuine election-security risks, or they may be policy requirements attached to funds without statutory authorization. Therefore the record reports an injunction against the funding condition—not a finding that the safeguards are substantively unsound or a final end to the litigation.


## SOURCES

- [Judge blocks Trump from tying anti-terrorism grants to election changes](https://www.reuters.com/world/judge-blocks-trump-tying-anti-terrorism-grants-election-changes-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
