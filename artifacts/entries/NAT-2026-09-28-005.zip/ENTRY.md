# Federal judge blocks election conditions on counterterrorism grants

**Entry ID:** NAT-2026-09-28-005
**Date:** September 28–October 8, 2026
**Checked:** 2026-10-08 5:59 PM EDT
**Evidence state:** named federal-court ruling reported by Reuters plus AP's October 8 report of FEMA's state notice rescinding the requirements; rescission reported as implemented, litigation not final
**Review state:** current-standard-reviewed

After a judge blocked election-administration conditions on roughly $1 billion in counterterrorism grants, FEMA told states it was rescinding the requirements.

## THE FACTS

- U.S. District Judge Amir Ali blocked FEMA and the Department of Homeland Security from withholding 20% of approximately $1.1 billion in counterterrorism grants from jurisdictions that declined three election-administration conditions.
- The challenged conditions called for hand-marked paper ballots, manual audits of at least 5% of ballots and comparison of voter rolls with federal data. The order does not itself change state election procedures.
- Ali concluded that Congress had not authorized the counterterrorism-grant programs to be used to compel election-administration changes. Separate state challenges remain pending, and no appeal result or higher-court stay was established at cutoff.
- DHS said the conditions were intended to protect elections from foreign interference and cyberattacks. That justification remains the administration's stated rationale; the ruling concerns the grant authority used to impose it.
- On October 8, FEMA informed states that it was rescinding the election-related requirements from the Homeland Security Grant Program after the district-court ruling. The agency action implements the immediate policy retreat; it does not itself terminate appeals or separate state litigation.

## SIGNIFICANCE

The injunction produced an immediate administrative retreat: FEMA removed the challenged conditions instead of continuing to hold back grant funds under them. That implementation matters, but it does not erase the underlying litigation or prevent a later appeal or differently authorized policy.

## GOALPOST / RESPONSE

The administration said the conditions protected elections from foreign interference and cyberattacks. The court held that Congress had not authorized these counterterrorism grants as leverage over state election systems, and FEMA then rescinded the requirements. Appeal activity, grant disbursements and the separate state cases remain the evidence tests.

## MAYBE / THEREFORE

Maybe the safeguards address genuine election-security risks, or they may be policy requirements attached to funds without statutory authorization. Therefore the record now establishes both the injunction and FEMA's resulting rescission—not a final appellate resolution or a judgment that every proposed safeguard is substantively unsound.


## SOURCES

- [Judge blocks Trump from tying anti-terrorism grants to election changes](https://www.reuters.com/world/judge-blocks-trump-tying-anti-terrorism-grants-election-changes-2026-09-28/) — independent reporting
- [Associated Press — FEMA rescinds election-related grant requirements after ruling](https://apnews.com/live/trump-midterm-elections-news-updates-10-08-2026) — independent reporting of the agency notice

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
