# ICE tightens enforcement of international-student internship authorizations

**Entry ID:** NAT-2026-08-24-007
**Date:** August 24–27, 2026
**Checked:** 2026-08-27 11:58 PM EDT
**Evidence state:** primary ICE/SEVP broadcast message plus independent Reuters reporting on university implementation; guidance issued and affecting some processing, existing regulations unchanged
**Review state:** current-standard-reviewed

The agency says existing CPT regulations have not changed, but its new guidance warns schools that noncompliant authorizations can jeopardize certification to enroll foreign students.

## THE FACTS

- The Student and Exchange Visitor Program, part of Immigration and Customs Enforcement, sent certified schools an August 24 broadcast message saying it had observed an increase in Curricular Practical Training authorizations that appeared to violate existing regulations requiring the work to be an integral part of an established curriculum.
- The guidance tells designated school officials to verify the curricular basis before authorizing CPT and warns that failure to comply with SEVP regulations may result in a school losing certification to enroll F-1 students. The document announces heightened oversight and enforcement of existing rules; it is not a new regulation or a categorical end to CPT.
- Reuters reported late August 27 that UCLA had paused some CPT authorizations while reviewing the guidance and that UC Berkeley had limited some categories while continuing degree-required and dissertation or thesis research CPT. DHS said the regulations had not changed but that schools and employers were on notice that the administration would enforce them more strictly.

## SIGNIFICANCE

CPT is a principal route for F-1 students to take internships and other curriculum-linked work. A stricter federal interpretation backed by the threat of school decertification can narrow access before any formal rulemaking, shift compliance risk to universities, and disrupt students and employers even where the underlying regulatory text is unchanged.

## GOALPOST / RESPONSE

DHS says the message targets abuse of a longstanding requirement that CPT be integral to the curriculum, rather than changing the law. Universities reported that the message was narrower and more restrictive in practice and paused some authorizations while seeking legal guidance. School certification actions, clarified criteria, processing data, student impacts, litigation, and any rulemaking are the tests.

## MAYBE / THEREFORE

Maybe tighter review will curb programs that used CPT as a work-authorization workaround while preserving legitimate degree-linked training, or uncertain standards and decertification pressure may chill lawful internships more broadly. Therefore the record describes implemented enforcement guidance and early university restrictions—not a new regulation, a nationwide CPT suspension, or proof that the affected programs violated the law.


## SOURCES

- [ICE Student and Exchange Visitor Program — guidance on CPT oversight and enforcement](https://www.ice.gov/doclib/sevis/pdf/bcm260802.pdf) — primary federal guidance to designated school officials
- [Reuters — ICE guidance narrows some international-student internship processing](https://www.reuters.com/legal/government/trump-administration-restricts-internships-international-students-2026-08-28/) — independent reporting on the federal memo, university responses, and DHS explanation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
