# Court blocks ICE’s narrower internship rule for member universities

**Entry ID:** NAT-2026-08-24-007
**Date:** August 24–November 17, 2026
**Checked:** 2026-11-18 12:05 PM EST
**Evidence state:** primary ICE guidance and federal-court preliminary-injunction order plus independent Reuters reporting; August interpretation implemented, then stayed and enjoined for plaintiffs and member institutions while merits remain unresolved
**Review state:** current-standard-reviewed

A federal judge preliminarily stayed and enjoined two August CPT directives for the plaintiff associations and member schools, finding a likely unexplained policy reversal.

## THE FACTS

- The Student and Exchange Visitor Program, part of Immigration and Customs Enforcement, sent certified schools an August 24 broadcast message saying it had observed an increase in Curricular Practical Training authorizations that appeared to violate existing regulations requiring the work to be an integral part of an established curriculum.
- The guidance tells designated school officials to verify the curricular basis before authorizing CPT and warns that failure to comply with SEVP regulations may result in a school losing certification to enroll F-1 students. The document announces heightened oversight and enforcement of existing rules; it is not a new regulation or a categorical end to CPT.
- Reuters reported late August 27 that UCLA had paused some CPT authorizations while reviewing the guidance and that UC Berkeley had limited some categories while continuing degree-required and dissertation or thesis research CPT. DHS said the regulations had not changed but that schools and employers were on notice that the administration would enforce them more strictly.
- On November 17, U.S. District Judge Julia Kobick issued a preliminary injunction and stayed application of the two August broadcast messages to the plaintiff higher-education associations and their member institutions. The order bars DHS and ICE, pending judicial review, from treating elective practical training taken for academic credit as ineligible merely because it is not required of every student in the degree program.
- Kobick found the plaintiffs substantially likely to show that SEVP changed a government interpretation used since 1991 without acknowledging the change, explaining it or addressing reliance interests, making the broadcasts likely arbitrary and capricious under the Administrative Procedure Act. That is a preliminary merits assessment, not a final judgment.
- The order found concrete current harms in declarations describing denied or rescinded authorizations, curriculum changes, diverted staff time, student departures and fear of certification or criminal consequences. Reuters reported that DHS declined to comment. The injunction’s association-and-member scope and the unresolved appeal and final merits remain material limits.

## SIGNIFICANCE

The order converts the earlier implementation dispute into enforceable preliminary relief for the plaintiff associations and their member institutions. It preserves elective, for-credit curriculum-linked training within that scope while the court reviews whether DHS lawfully changed a decades-old interpretation; it is not a final nationwide merits judgment.

## GOALPOST / RESPONSE

DHS had said the messages merely enforced the existing requirement that CPT be integral to a curriculum. The court found a likely unacknowledged change from the government’s prior acceptance of elective, for-credit training and rejected the government’s no-harm premise on the current record. Appeal, final judgment, any revised guidance or rulemaking, the precise covered membership and measured student and institution outcomes are the tests.

## MAYBE / THEREFORE

Maybe DHS can justify a narrower CPT interpretation through a lawful process or prevail after a fuller merits record, or the August broadcasts may remain an arbitrary change that disrupted legitimate training. Therefore the court has preliminarily stayed and enjoined the directives for the plaintiffs and their members—not vacated them nationwide, entered final judgment or established permanent eligibility for every internship.


## SOURCES

- [ICE Student and Exchange Visitor Program — guidance on CPT oversight and enforcement](https://www.ice.gov/doclib/sevis/pdf/bcm260802.pdf) — primary federal guidance to designated school officials
- [Reuters — ICE guidance narrows some international-student internship processing](https://www.reuters.com/legal/government/trump-administration-restricts-internships-international-students-2026-08-28/) — independent reporting on the federal memo, university responses, and DHS explanation
- [Association of American Universities v. DHS — preliminary injunction and stay](https://fingfx.thomsonreuters.com/gfx/legaldocs/xmpjdgaojpr/11172026cpt.pdf) — primary federal-court order, case 1:26-cv-14520-JEK, Document 36
- [U.S. judge blocks Trump policy restricting foreign-student work options](https://www.reuters.com/legal/government/us-judge-blocks-trump-policy-restricting-foreign-student-work-options-2026-11-17/) — independent reporting on preliminary injunction and agency response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
