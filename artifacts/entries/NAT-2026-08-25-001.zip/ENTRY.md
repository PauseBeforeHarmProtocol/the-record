# Appeals court blocks FCC extension of candidate advertising discounts to party committees

**Entry ID:** NAT-2026-08-25-001
**Date:** August 25, 2026
**Checked:** 2026-08-25 6:00 PM EDT
**Evidence state:** divided Fourth Circuit ruling independently reported by Reuters and Bloomberg Law; FCC rate extension blocked, further review possible

A divided Fourth Circuit held that political parties and joint fundraising committees with non-candidate members are not entitled to candidate-only broadcast rates.

## THE FACTS

- A 2–1 panel of the U.S. Court of Appeals for the Fourth Circuit blocked FCC guidance that would have extended the lowest-unit broadcast advertising rate to political party committees and joint fundraising committees with non-candidate members.
- The majority said federal campaign-finance statutes clearly reserve the discount for legally qualified candidates and rejected the FCC's characterization of the guidance as merely restating existing policy.
- The FCC and Republican campaign committees argued that the court lacked jurisdiction because the agency had not completed its process. Judge J. Harvie Wilkinson III dissented on that ground. FCC Chair Brendan Carr did not immediately comment.

## SIGNIFICANCE

The ruling prevents party and joint fundraising committees from using candidate-only broadcast discounts as the September 4 lowest-rate period approaches. It separates the Supreme Court's earlier removal of coordinated-spending limits from the distinct statutory question of who qualifies for broadcast discounts.

## GOALPOST / RESPONSE

The FCC and Republican committees argued that judicial review was premature and that the agency should complete the role Congress assigned it. Challengers argued that the Communications Act limits the discount to candidates. The operative tests are any rehearing or Supreme Court review, subsequent FCC action, and broadcasters' rate treatment during the election window.

## MAYBE / THEREFORE

Maybe a later court will accept the jurisdictional dissent or the FCC will issue narrower guidance after completing its process. Therefore the record states the present legal effect—the August 25 appellate ruling blocks the announced extension—without treating the dispute as finally exhausted.


## SOURCES

- [Reuters — Fourth Circuit blocks FCC political-advertising discount extension](https://www.reuters.com/world/fcc-expands-discounted-tv-advertising-rates-party-committees-2026-08-25/) — independent reporting on the divided appellate ruling
- [Bloomberg Law — Democrats win challenge to FCC discounted ad-rate guidance](https://news.bloomberglaw.com/litigation/democrats-win-court-challenge-to-fcc-discounted-ad-rate-guidance) — independent legal reporting on the Fourth Circuit opinion
- [Elias Law Group — Fourth Circuit challenge to FCC discounted ad-rate guidance](https://elias.law/press-release/fourth-circuit-fast-tracks-challenge-to-fcc-guidance-giving-parties-access-to-discounted-ad-rates/) — party statement and procedural background

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
