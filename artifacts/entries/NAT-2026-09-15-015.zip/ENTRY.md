# GAO estimates $6.7 billion in salary costs for deferred-resignation leave

**Entry ID:** NAT-2026-09-15-015
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:01 PM EDT
**Evidence state:** primary GAO performance audit using payroll data from 76 agencies; estimated costs, documented data limitations and two open recommendations accepted by OPM
**Review state:** current-standard-reviewed

Paid administrative-leave use rose 435% from 2023 to 2025; GAO warns data errors may overstate totals and says OPM cannot yet calculate the program's actual net savings.

## THE FACTS

- GAO analyzed payroll data from 76 agencies covering about 95% of the civilian workforce and estimated $9.5 billion in salary costs for paid administrative leave in 2025, six times the 2023 amount; usage increased 435% over that period.
- Using program assumptions and internal time-and-attendance data from payroll providers, GAO estimated about $6.7 billion of the 2025 amount was associated with the Trump administration's deferred resignation program, which generally allowed participating employees to stop working while receiving pay until resignation or retirement by September 30, 2025.
- GAO cautioned that agency reporting problems could overstate paid administrative leave. It found reported leave was 144% higher in pay periods containing a public holiday during 2023 through early 2025 even though holidays should not be coded as administrative leave; OPM does not plan to retroactively correct the public historical data.
- OPM could not identify the actual leave costs used for workforce-reduction efforts because those hours were combined with other administrative leave. GAO therefore said federal leaders lacked the data needed to determine whether government-wide cost-saving goals were being met; the report did not calculate long-term net savings from reduced headcount.
- GAO recommended that OPM disclose unresolved data limitations and create a dedicated payroll category for workforce-reduction leave. OPM agreed with both recommendations, which remained open at publication.

## SIGNIFICANCE

The audit supplies the first government-wide payroll estimate tying most of a sixfold leave-cost increase to the deferred resignation program, while also documenting why the headline totals and promised net savings cannot yet be treated as exact or complete.

## GOALPOST / RESPONSE

The administration presented deferred resignations as a tool to reduce headcount and long-term spending; OPM agreed to GAO's transparency and tracking recommendations. The tests are a dedicated leave code, corrected disclosures, verified separations and replacement hiring, service effects, and a net-savings calculation that includes short-term salary costs.

## MAYBE / THEREFORE

Maybe the $6.7 billion short-term cost is outweighed by durable payroll savings, or rehiring, service losses and coding errors may reduce or obscure those savings. Therefore GAO measured a large estimated leave cost and a tracking failure—not the program's final net fiscal effect or a precise count free of reporting error.


## SOURCES

- [GAO — Deferred Resignation Program Largely Responsible for Sixfold Increase in Paid Administrative Leave Salary Costs](https://www.gao.gov/products/gao-26-108477) — primary performance audit and cost estimate

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
