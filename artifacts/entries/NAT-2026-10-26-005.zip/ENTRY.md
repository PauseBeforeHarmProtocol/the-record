# Preliminary redesigned crime survey reports lower serious-violence and property victimization

**Entry ID:** NAT-2026-10-26-005
**Date:** October 26, 2026
**Checked:** 2026-10-28 12:10 PM EDT
**Evidence state:** Original four-page BJS report, publication/comparability notice and DOJ explanation inspected. October 26 recovery, not a new event occurring after the current opening boundary.
**Review state:** current-standard-reviewed

BJS reports declines in selected comparable redesigned measures; neither a historical-record comparison nor causal presidential credit follows.

## THE FACTS

- BJS’s October 26 preliminary 2025 NCVS report estimates serious violent victimization excluding simple assault at 7.4 per 1,000 people age 12 or older, versus 9.9 in its redesigned 2024 comparator, a 25% decline. Property victimization fell 19%, from 138.0 to 111.2 per 1,000 households; the report marks these differences statistically significant.
- The survey measures victimizations, including crimes not reported to police, and excludes homicide. Its 2025 estimates are preliminary. BJS says redesigned NCVS-R estimates cannot be compared with the legacy instrument; its 2024 comparison here uses the redesigned version, not the old series.
- Missing October and November 2025 interviews during the appropriations lapse required a one-time weighting adjustment. DOJ says the results demonstrate the administration’s public-safety agenda is working. The inspected report estimates victimization; it does not isolate the causal effect of presidential policy.

## SIGNIFICANCE

The official measurement supplies a meaningful outcome test while exposing limits on sweeping historical or causal claims. A change in a subset must not be relabeled a 25% decline in every violent-crime measure.

## GOALPOST / RESPONSE

DOJ credits the administration’s safety agenda. The strongest evidence for improvement is the report’s significant subset and property declines; causal attribution and claims of the largest drop across incompatible historical instruments need separate evidence.

## MAYBE / THEREFORE

Maybe genuine improvements contributed to the estimates, while redesign, response and weighting limitations affect interpretation. Therefore report the preliminary comparable measures, not a final count or proof that Trump caused the change.


## SOURCES

- [Preliminary Victimization Estimates from the NCVS, 2025, NCJ 312234](https://bjs.ojp.gov/document/pvencvs25.pdf) — primary statistical report
- [BJS preliminary NCVS publication and comparability notice](https://bjs.ojp.gov/library/publications/preliminary-victimization-estimates-ncvs-2025) — primary report metadata and methodological notice
- [DOJ attributes preliminary crime estimates to administration agenda](https://www.justice.gov/opa/pr/national-crime-victimization-survey-shows-violent-crime-plummeted-2025) — primary administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
