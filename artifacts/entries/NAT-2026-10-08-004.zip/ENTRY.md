# Trump disclosure shows Nvidia trades amid administration chip-policy decisions

**Entry ID:** NAT-2026-10-08-004
**Date:** August–October 8, 2026
**Checked:** 2026-10-08 12:00 PM EDT
**Evidence state:** primary OGE periodic transaction report plus independent Reuters reporting and the White House response; trades disclosed, exact exposure, control and policy influence unresolved
**Review state:** current-standard-reviewed

The official report lists four August Nvidia purchases and one sale; the disclosure establishes financial exposure and a potential conflict question, not that any policy was altered for the holding.

## THE FACTS

- A periodic transaction report signed by Trump on September 17 and released publicly by October 8 lists four August Nvidia purchases: $250,001–$500,000 on August 3, $1,001–$15,000 on August 10, $500,001–$1 million on August 17 and $15,001–$50,000 on August 26. At the top of the disclosed ranges, the purchases total about $1.565 million.
- The same report lists an August 21 Nvidia sale of $500,001–$1 million. The form reports ranges rather than exact prices, account ownership or net economic exposure, and it contains hundreds of transactions beyond Nvidia.
- Reuters reported that the administration was weighing advanced-chip export policies that could affect Nvidia and that Trump was scheduled to award CEO Jensen Huang the National Medal of Science on October 8. Those overlapping official decisions and holdings create a potential-conflict question; the disclosure and timing do not establish that Trump directed a trade or changed policy to benefit Nvidia.
- A White House spokesperson told Reuters that independent third-party financial institutions make all investment decisions and replicate recognized indexes such as the Schwab 1000, and said there were no conflicts of interest. The inspected disclosure does not identify the manager's mandate or supply transaction-level evidence connecting the trades to a particular index rebalance.

## SIGNIFICANCE

The disclosure provides a primary record of presidential financial exposure to a company directly affected by administration export and technology policy. Transparency permits scrutiny, but intent, control and policy influence require evidence beyond temporal overlap.

## GOALPOST / RESPONSE

The White House says independent managers, not Trump, made the trades through index-replicating strategies. Management agreements, index methodology, recusal or ethics records, later transaction reports and documented policy decision-making are the tests.

## MAYBE / THEREFORE

Maybe the Nvidia transactions were routine, independently managed index replication with no presidential knowledge, or undisclosed discretion could leave a meaningful conflict risk. Therefore the official report establishes trades and exposure during a policy-sensitive period; it does not establish personal direction, inside information, illegality or policy favoritism.


## SOURCES

- [Office of Government Ethics — Donald J. Trump periodic transaction report signed September 17, 2026](https://extapps2.oge.gov/201/Presiden.nsf/PAS%2BIndex/0BDCCCE7DE13AEFA85258E8A002DE2B5/$FILE/Donald-J-Trump.09.17.2026-278T.pdf) — official financial disclosure
- [Reuters — Trump discloses Nvidia trades as he prepares to honor CEO Huang](https://www.reuters.com/business/trump-discloses-nvidia-stock-trades-he-prepares-honor-ceo-huang-2026-10-08/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
