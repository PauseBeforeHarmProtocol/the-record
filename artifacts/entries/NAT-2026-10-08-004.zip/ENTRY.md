# Trump Nvidia exposure record expands into Senate preservation demand over chip policy

**Entry ID:** NAT-2026-10-08-004
**Date:** August–November 12, 2026
**Checked:** 2026-11-12 12:11 PM EST
**Evidence state:** official OGE disclosure, primary Senate preservation letter and independent Reuters reporting; trades and oversight request established, while control, intelligence claims, enforcement intervention and policy influence remain unresolved
**Review state:** current-standard-reviewed

Two senators directed the White House, Commerce and State to preserve Nvidia export-control and counterintelligence records and requested a briefing, extending the conflict question into formal oversight.

## THE FACTS

- A periodic transaction report signed by Trump on September 17 and released publicly by October 8 lists four August Nvidia purchases: $250,001–$500,000 on August 3, $1,001–$15,000 on August 10, $500,001–$1 million on August 17 and $15,001–$50,000 on August 26. At the top of the disclosed ranges, the purchases total about $1.565 million.
- The same report lists an August 21 Nvidia sale of $500,001–$1 million. The form reports ranges rather than exact prices, account ownership or net economic exposure, and it contains hundreds of transactions beyond Nvidia.
- Reuters reported that the administration was weighing advanced-chip export policies that could affect Nvidia and that Trump was scheduled to award CEO Jensen Huang the National Medal of Science on October 8. Those overlapping official decisions and holdings create a potential-conflict question; the disclosure and timing do not establish that Trump directed a trade or changed policy to benefit Nvidia.
- A White House spokesperson told Reuters that independent third-party financial institutions make all investment decisions and replicate recognized indexes such as the Schwab 1000, and said there were no conflicts of interest. The inspected disclosure does not identify the manager's mandate or supply transaction-level evidence connecting the trades to a particular index rebalance.
- In a November 11 letter located after the prior cutoff, Senators Elizabeth Warren and Christopher Coons requested that Commerce Secretary Howard Lutnick, Secretary of State Marco Rubio and White House Chief of Staff Stephen Miller preserve records concerning Nvidia advanced-chip exports, reported intelligence about a suspected Chinese operation involving CEO Jensen Huang, enforcement decisions and administration contacts with Nvidia. They requested written confirmation of preservation directives by November 17 and a congressional briefing. The letter is a formal oversight and preservation request, not a subpoena, adjudication or finding that records were destroyed or laws were violated.
- The senators framed the request around news reports that senior officials knew of counterintelligence concerns and that a Commerce investigation of Megaspeed was transferred to Justice and later altered. Reuters separately reported bipartisan calls for tighter China chip restrictions and a fuller accounting. Those are reported allegations and oversight questions; the letter does not independently prove an intelligence relationship, unlawful diversion, intervention in an investigation, presidential knowledge or policy favoritism. No administration response to this preservation request was located by cutoff.

## SIGNIFICANCE

The official disclosure already established presidential financial exposure during chip-policy decisions; the preservation demand adds a formal congressional test of whether administration contacts, intelligence handling and export-control enforcement were properly documented. It increases oversight and conflict risk without establishing misconduct.

## GOALPOST / RESPONSE

The White House says independent managers made Trump's trades through index-replicating strategies. The new institutional tests are compliance with the November 17 preservation deadline, the requested briefing, retained records, management and recusal documents, export licenses and enforcement files, and any inspector-general, congressional or judicial finding—not the senators' allegations alone.

## MAYBE / THEREFORE

Maybe the records will show routine investment management and defensible export-control decisions with no improper intervention, or they may reveal that financial exposure and Nvidia access overlapped with decisions that lacked adequate safeguards. Therefore the archive records disclosed trades and a formal preservation-and-briefing demand—not inside information, destroyed evidence, unlawful chip diversion, policy favoritism or presidential misconduct.


## SOURCES

- [Office of Government Ethics — Donald J. Trump periodic transaction report signed September 17, 2026](https://extapps2.oge.gov/201/Presiden.nsf/PAS%2BIndex/0BDCCCE7DE13AEFA85258E8A002DE2B5/$FILE/Donald-J-Trump.09.17.2026-278T.pdf) — official financial disclosure
- [Reuters — Trump discloses Nvidia trades as he prepares to honor CEO Huang](https://www.reuters.com/business/trump-discloses-nvidia-stock-trades-he-prepares-honor-ceo-huang-2026-10-08/) — independent reporting
- [Senators Warren and Coons — Nvidia export-control record-preservation and briefing request](https://www.banking.senate.gov/imo/media/doc/20261111_warren_coons_letter_to_wh_commerce_state_re_nvidia_record_retentionpdf.pdf) — primary congressional oversight letter; cited allegations remain reported rather than adjudicated
- [Reuters — lawmakers seek answers and tighter China chip controls after Nvidia allegations](https://www.reuters.com/world/schumer-says-congress-must-have-answers-trump-defense-nvidia-ceo-2026-11-10/) — independent reporting on congressional scrutiny, Nvidia response and unresolved allegations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
