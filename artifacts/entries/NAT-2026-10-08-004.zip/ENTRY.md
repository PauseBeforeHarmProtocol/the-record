# Nvidia conflict record adds public China chip-license disclosure and oversight demand

**Entry ID:** NAT-2026-10-08-004
**Date:** August–November 19, 2026
**Checked:** 2026-11-19 6:07 PM EST
**Evidence state:** official OGE disclosure, primary Senate preservation letter, statutory House committee license disclosure and independent Reuters reporting; trades, approvals and oversight established, while influence, shipment totals and misconduct remain unresolved
**Review state:** current-standard-reviewed

A House committee publicly released licensing data showing millions of requested advanced chips and hundreds of thousands approved, adding transaction-level policy evidence without proving presidential favoritism or completed shipments.

## THE FACTS

- A periodic transaction report signed by Trump on September 17 and released publicly by October 8 lists four August Nvidia purchases: $250,001–$500,000 on August 3, $1,001–$15,000 on August 10, $500,001–$1 million on August 17 and $15,001–$50,000 on August 26. At the top of the disclosed ranges, the purchases total about $1.565 million.
- The same report lists an August 21 Nvidia sale of $500,001–$1 million. The form reports ranges rather than exact prices, account ownership or net economic exposure, and it contains hundreds of transactions beyond Nvidia.
- Reuters reported that the administration was weighing advanced-chip export policies that could affect Nvidia and that Trump was scheduled to award CEO Jensen Huang the National Medal of Science on October 8. Those overlapping official decisions and holdings create a potential-conflict question; the disclosure and timing do not establish that Trump directed a trade or changed policy to benefit Nvidia.
- A White House spokesperson told Reuters that independent third-party financial institutions make all investment decisions and replicate recognized indexes such as the Schwab 1000, and said there were no conflicts of interest. The inspected disclosure does not identify the manager's mandate or supply transaction-level evidence connecting the trades to a particular index rebalance.
- In a November 11 letter located after the prior cutoff, Senators Elizabeth Warren and Christopher Coons requested that Commerce Secretary Howard Lutnick, Secretary of State Marco Rubio and White House Chief of Staff Stephen Miller preserve records concerning Nvidia advanced-chip exports, reported intelligence about a suspected Chinese operation involving CEO Jensen Huang, enforcement decisions and administration contacts with Nvidia. They requested written confirmation of preservation directives by November 17 and a congressional briefing. The letter is a formal oversight and preservation request, not a subpoena, adjudication or finding that records were destroyed or laws were violated.
- The senators framed the request around news reports that senior officials knew of counterintelligence concerns and that a Commerce investigation of Megaspeed was transferred to Justice and later altered. Reuters separately reported bipartisan calls for tighter China chip restrictions and a fuller accounting. Those are reported allegations and oversight questions; the letter does not independently prove an intelligence relationship, unlawful diversion, intervention in an investigation, presidential knowledge or policy favoritism. No administration response to this preservation request was located by cutoff.
- On November 19 House Foreign Affairs Committee Chairman Brian Mast publicly released Commerce export-license information under authority he cited in the Export Control Reform Act. The committee said applications covered about 3.4 million advanced chips for China and approvals covered more than 879,000, involving companies including Alibaba, Tencent, Nvidia and AMD.
- Reuters reported that disclosed approvals included 75,000 chips for Alibaba, 150,000 for Tencent, 43,000 for Baidu and 4,000 for BYD, while the records did not establish how many approved chips were actually shipped. Nvidia said licenses were subject to strict conditions and it had stopped H200 shipments to China; AMD said it complied with export controls. Commerce and the Chinese embassy did not immediately respond to Reuters.
- The disclosure supplies concrete licensing data relevant to the senators' preservation request, but it does not establish that Trump selected license recipients, knew of individual approvals, directed a financial trade, intervened in enforcement or caused an unlawful diversion.

## SIGNIFICANCE

The record now combines official presidential financial exposure, formal congressional preservation demands and a statutory release of chip-license data. That materially improves the evidence base for oversight while still separating approved licenses from completed shipments and policy overlap from proven conflict-driven conduct.

## GOALPOST / RESPONSE

The White House says independent managers made Trump's trades through index-replicating strategies; Nvidia and AMD say they comply with export controls. The tests are management and recusal records, preserved administration contacts, license conditions, actual shipment and end-use data, enforcement files, the requested briefing and any inspector-general, congressional or judicial finding.

## MAYBE / THEREFORE

Maybe the public license data will show controlled, conditional exports and routine investment management, or later shipment, end-use and contact records may reveal safeguards that failed or decisions affected by improper access. Therefore the archive records disclosed trades, formal oversight and approved licenses—not presidential direction, completed shipment of every approved chip, unlawful diversion or policy favoritism.


## SOURCES

- [Office of Government Ethics — Donald J. Trump periodic transaction report signed September 17, 2026](https://extapps2.oge.gov/201/Presiden.nsf/PAS%2BIndex/0BDCCCE7DE13AEFA85258E8A002DE2B5/$FILE/Donald-J-Trump.09.17.2026-278T.pdf) — official financial disclosure
- [Reuters — Trump discloses Nvidia trades as he prepares to honor CEO Huang](https://www.reuters.com/business/trump-discloses-nvidia-stock-trades-he-prepares-honor-ceo-huang-2026-10-08/) — independent reporting
- [Senators Warren and Coons — Nvidia export-control record-preservation and briefing request](https://www.banking.senate.gov/imo/media/doc/20261111_warren_coons_letter_to_wh_commerce_state_re_nvidia_record_retentionpdf.pdf) — primary congressional oversight letter; cited allegations remain reported rather than adjudicated
- [Reuters — lawmakers seek answers and tighter China chip controls after Nvidia allegations](https://www.reuters.com/world/schumer-says-congress-must-have-answers-trump-defense-nvidia-ceo-2026-11-10/) — independent reporting on congressional scrutiny, Nvidia response and unresolved allegations
- [House Foreign Affairs Committee — public release of China AI-chip license information](https://foreignaffairs.house.gov/news/press-releases/chairman-brian-mast-exercises-legislative-authority-to-publicly-release-ai-chip-license-information-for-china) — primary congressional disclosure under export-control law
- [Reuters — House committee releases China AI-chip license information](https://www.reuters.com/world/license-information-ai-chips-sent-china-released-by-us-house-committee-2026-11-19/) — independent reporting on disclosed export-license approvals and company responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
