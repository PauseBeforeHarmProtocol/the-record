# Second judge vacates agency policies implementing Trump's $100,000 H-1B charge

**Entry ID:** NAT-2026-08-24-001
**Date:** August 24–September 30, 2026
**Checked:** 2026-10-01 5:57 AM EDT
**Evidence state:** primary district-court order plus Reuters reporting; agency policies vacated, remanded and preliminarily enjoined on procedural grounds, with conflicting litigation, appeals and separate rulemaking unresolved
**Review state:** current-standard-reviewed

The California order enjoins USCIS and State Department implementation on procedural grounds; it does not finalize the separate $103,265 proposal or end the conflicting litigation.

## THE FACTS

- The administration proposed a $103,265 fee for each new H-1B worker visa and opened a 30-day public-comment period.
- Reuters reported that ordinary H-1B filing and related fees generally total about $2,000 to $5,000. The statutory program makes 65,000 visas available annually plus 20,000 for workers with advanced U.S. degrees.
- A federal judge in Boston blocked the agencies' implementation policies in June, and the First Circuit later declined to stay that ruling. A separate district court rejected a Chamber of Commerce challenge; the litigation therefore remained divided.
- On September 18, Trump issued a proclamation extending Proclamation 10973's separate $100,000 payment-based entry restriction for certain H-1B workers outside the United States for 12 months, through 12:00 a.m. EDT on September 21, 2027.
- The White House said more than 700 petitions had paid the charge and reported declines in registrations by large outsourcing firms and consular-processing requests. Those are administration measurements and do not independently establish effects on wages, displacement, innovation or total lawful hiring.
- On September 30, U.S. District Judge Haywood Gilliam vacated and remanded the USCIS and State Department implementation policies and preliminarily enjoined the agencies from enforcing them until they complete Administrative Procedure Act notice-and-comment and Regulatory Flexibility Act analysis. The order denied class certification without prejudice and denied a stay; it did not vacate the presidential proclamations themselves or resolve appeals and the separate proposed $103,265 rule.

## SIGNIFICANCE

A second court has disabled agency implementation of the six-figure charge, increasing practical and appellate pressure while another district court reached the opposite result. The ruling is procedural and agency-specific, so it does not itself settle presidential authority or the pending permanent-fee proposal.

## GOALPOST / RESPONSE

The administration says the charge protects U.S. workers, deters outsourcing abuse and shifts selection toward higher-value roles. Challengers say the agencies bypassed mandatory procedures and imposed disruptive costs. Appellate rulings, compliant rulemaking, petition processing, exception decisions, employer behavior, wages and independent labor data are the tests.

## MAYBE / THEREFORE

Maybe the administration can lawfully recreate a similar charge through notice-and-comment or prevail on appeal, or the procedural and statutory objections may prevent implementation. Therefore the September 30 order vacates and enjoins the two agency policies in that case; it does not erase the proclamations, finalize the $103,265 proposal or finally resolve the nationwide litigation.


## SOURCES

- [Reuters — proposed $103,265 fee for new H-1B visas](https://www.reuters.com/legal/government/trump-administration-moves-impose-more-than-100000-fee-h-1b-worker-visas-2026-08-24/) — independent reporting on a proposed rule
- [White House proclamation — restriction on entry of certain nonimmigrant workers](https://www.whitehouse.gov/presidential-actions/2026/09/restriction-on-entry-of-certain-nonimmigrant-workers-faad/) — primary presidential proclamation
- [N.D. California — order in Global Nurse Force v. Trump](https://fingfx.thomsonreuters.com/gfx/legaldocs/gdpzgmrjqvw/09302026hib.pdf) — primary judicial order
- [Reuters — second judge blocks agency implementation of H-1B charge](https://www.reuters.com/legal/government/second-judge-blocks-trumps-100000-fee-new-h-1b-worker-visas-2026-10-01/) — independent reporting on judicial ruling and litigation posture

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
