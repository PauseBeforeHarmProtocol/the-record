# Administration proposes a $103,265 fee for each new H-1B visa

**Entry ID:** NAT-2026-08-24-001
**Date:** August 24, 2026
**Checked:** 2026-08-24 10:43 AM EDT
**Evidence state:** reported proposed rule; comment period and litigation pending

The proposed rule would raise the price of a new skilled-worker visa far above ordinary filing costs; it is open for comment and not yet final.

## THE FACTS

- The administration proposed a $103,265 fee for each new H-1B worker visa and opened a 30-day public-comment period.
- Reuters reported that ordinary H-1B filing and related fees generally total about $2,000 to $5,000. The statutory program makes 65,000 visas available annually plus 20,000 for workers with advanced U.S. degrees.
- A federal judge blocked an earlier temporary version of the six-figure fee in June, and the administration's appeal remained pending. The new proposal had not become a final rule at the checked time.

## SIGNIFICANCE

A six-figure charge could function as a large restriction on access to the program even without changing its numerical cap. The effects would differ across employers, occupations, universities, workers, and firms able to absorb the fee.

## GOALPOST / RESPONSE

The administration says a high fee protects U.S. workers and discourages misuse of the visa program. Employers and immigration advocates argue it would price out legitimate hiring and innovation. The final rule, litigation, employer behavior, wage data, and domestic hiring outcomes are the evidence tests.


## SOURCES

- [Reuters — proposed $103,265 fee for new H-1B visas](https://www.reuters.com/legal/government/trump-administration-moves-impose-more-than-100000-fee-h-1b-worker-visas-2026-08-24/) — independent reporting on a proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
