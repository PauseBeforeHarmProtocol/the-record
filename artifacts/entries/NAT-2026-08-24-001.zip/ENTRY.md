# Trump extends $100,000 H-1B entry-payment restriction through September 2027

**Entry ID:** NAT-2026-08-24-001
**Date:** August 24–September 18, 2026
**Checked:** 2026-09-18 6:32 PM EDT
**Evidence state:** primary presidential proclamation plus the earlier independent report; one-year entry restriction extended and implemented, separate fee proposal and litigation unresolved
**Review state:** current-standard-reviewed

A presidential proclamation extended the separate entry restriction for another year; the earlier $103,265 fee proposal and its litigation remain distinct.

## THE FACTS

- The administration proposed a $103,265 fee for each new H-1B worker visa and opened a 30-day public-comment period.
- Reuters reported that ordinary H-1B filing and related fees generally total about $2,000 to $5,000. The statutory program makes 65,000 visas available annually plus 20,000 for workers with advanced U.S. degrees.
- A federal judge blocked an earlier temporary version of the six-figure fee in June, and the administration's appeal remained pending. The new proposal had not become a final rule at the checked time.
- On September 18, Trump issued a proclamation extending Proclamation 10973's separate $100,000 payment-based entry restriction for certain H-1B workers outside the United States for 12 months, through 12:00 a.m. EDT on September 21, 2027. The extension retains national-interest exceptions and applies to the petitions and entry circumstances specified in the proclamation.
- The White House said more than 700 petitions had paid the fee and reported large declines in registrations by the largest outsourcing firms and in consular-processing requests, plus a higher share of registrations for workers with master's degrees. Those are administration measurements; the proclamation did not independently establish effects on wages, displacement, innovation or total lawful hiring.

## SIGNIFICANCE

The proclamation keeps a six-figure barrier in force for another year while the distinct $103,265 rulemaking and litigation remain unresolved. Effects can differ sharply across employers, occupations, universities, workers and firms able to absorb the charge.

## GOALPOST / RESPONSE

The administration says the payment protects U.S. workers, discourages outsourcing misuse and shifts selection toward more highly educated workers. Employers and immigration advocates argue that six-figure charges can price out legitimate hiring and innovation. Petition records, exception decisions, court rulings, employer behavior, wages, domestic hiring and independent program data are the tests.

## MAYBE / THEREFORE

Maybe the extended payment restriction reserves covered H-1B hiring for genuinely hard-to-fill, high-value roles and improves opportunities for U.S. workers, or it may exclude smaller employers and needed workers without producing the claimed labor effects. Therefore the proclamation extends the separate $100,000 entry-payment restriction through September 2027; it does not finalize the $103,265 proposal or independently prove the administration's effectiveness claims.


## SOURCES

- [Reuters — proposed $103,265 fee for new H-1B visas](https://www.reuters.com/legal/government/trump-administration-moves-impose-more-than-100000-fee-h-1b-worker-visas-2026-08-24/) — independent reporting on a proposed rule
- [White House proclamation — restriction on entry of certain nonimmigrant workers](https://www.whitehouse.gov/presidential-actions/2026/09/restriction-on-entry-of-certain-nonimmigrant-workers-faad/) — primary presidential proclamation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
