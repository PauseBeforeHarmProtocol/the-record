# EPA releases revised vehicle-emissions model with lower EV assumptions

**Entry ID:** NAT-2026-10-27-003
**Date:** October 27, 2026
**Checked:** 2026-10-27 6:11 PM EDT
**Evidence state:** Primary Federal Register notice and EPA technical overview; model released and transition announced. Same-agency sources establish policy and specifications, not independent validation or environmental outcomes. Date-only publication recovered in this review; exact posting time unknown.
**Review state:** current-standard-reviewed

MOVES6 is available for air-quality planning, with a two-year conformity transition outside California; modeling changes are not measured pollution outcomes.

## THE FACTS

- EPA published its MOVES6 availability notice in the October 27 Federal Register, effective that day, for state air-quality plans and transportation-conformity analyses outside California. The notice starts a transition ending October 27, 2028, after which the new model is required for new regional and hot-spot conformity analyses.
- EPA says the model reduces default electric-vehicle shares to reflect rescinded greenhouse-gas standards, reduced EV incentives and congressional disapproval of the Advanced Clean Trucks waiver. It also updates energy-use and travel inputs and corrects emission-rate errors.
- The notice advises use of current models and assumptions for new state-plan work, while allowing specified ongoing work to continue with older versions. Its two-year transportation-conformity grace period is not a blanket two-year deferral for every state-plan analysis.
- EPA says the net change in estimated emissions depends on the modeled area and inputs. Releasing the model does not measure a nationwide increase or decrease in pollution, establish that particular projects comply, or independently validate the policy assumptions it incorporates.

## SIGNIFICANCE

The federal modeling baseline helps determine whether transportation plans and projects fit air-quality requirements. Incorporating policy-driven lower EV projections can change those estimates and planning choices, but direction and magnitude must be tested for each analysis rather than inferred as observed environmental damage or improvement.

## GOALPOST / RESPONSE

EPA describes MOVES6 as an updated scientific tool using current regulations, real-world data and corrected rates. A transition can limit disruption to ongoing planning. Tests include transparent inputs, reproducibility, local validation, conformity decisions and later observed emissions—not the release label alone.

## MAYBE / THEREFORE

Maybe the revised assumptions better reflect current law and fleet trends, while uncertainty in EV adoption and local inputs can still alter forecasts. Therefore the record confirms an implemented modeling release and future conformity requirement, not an independently measured emissions result or a completed change to every transportation plan.


## SOURCES

- [Official release of MOVES6 for SIPs and transportation conformity](https://www.govinfo.gov/content/pkg/FR-2026-10-27/pdf/2026-21843.pdf) — primary agency notice, 91 FR 67565
- [MOVES6 latest-version technical overview](https://www.epa.gov/moves/latest-version-motor-vehicle-emission-simulator-moves) — primary agency technical explanation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
