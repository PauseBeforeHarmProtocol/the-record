# Japan and GlobalFoundries announce up to $21 billion for New York chip fabs

**Entry ID:** NAT-2026-10-14-004
**Date:** October 14, 2026
**Checked:** 2026-10-14 6:03 PM EDT
**Evidence state:** primary company announcement plus independent Reuters and Associated Press reporting; first-fab investment announced, second fab conditional, output and returns projected
**Review state:** current-standard-reviewed

The first roughly $10 billion fab is scheduled for 2029 production; a second fab remains conditional on a decision by the end of 2028.

## THE FACTS

- GlobalFoundries announced that Japan will provide up to $21 billion and that the company was selected as technology provider and operator for as many as two semiconductor fabs at its Malta, New York, site. Reuters reported the facilities would be jointly owned by U.S. government and Japanese interests under the broader U.S.-Japan investment agreement.
- The announced initial investment of about $10 billion is intended to accelerate construction of a 300mm fab expected to begin production in 2029. GlobalFoundries says the first fab would add about 900,000 wafers of annual capacity when fully operating and help create more than 1,000 manufacturing jobs; those are forward-looking estimates, not completed output or employment.
- A second roughly $10 billion fab is not yet a completed investment decision. Reuters reported that the partners plan to decide by the end of 2028 whether to proceed, while the company said the second fab would add a similar amount of capacity if built.
- Reuters reported that the U.S. government's GlobalFoundries stake would rise from about 3% to 7% and that $955 million of an earlier federal award would be redirected to other GlobalFoundries projects. Trump said the government had provided $1.63 billion in grants and valued the 7% stake above $2 billion; the inspected materials did not establish a realized return to the Treasury.
- The administration and GlobalFoundries describe the initiative as supply-chain and national-security investment. Delivery tests include executed financing and ownership terms, construction milestones, the 2028 second-fab decision, 2029 production, actual jobs and capacity, and the market value and disposition of the federal stake.

## SIGNIFICANCE

The announcement commits a major bilateral investment structure to domestic semiconductor capacity and expands the federal government's equity role in a private manufacturer. Its scale is material, but most claimed production, jobs and fiscal benefits remain future outcomes and the second factory is conditional.

## GOALPOST / RESPONSE

The administration and company say Japanese capital plus GlobalFoundries operations will strengthen trusted U.S. supply chains and create high-skill jobs. Tests are binding project documents, timely construction and production, customer demand, net public cost, federal-equity returns and whether the optional second fab proceeds.

## MAYBE / THEREFORE

Maybe the structure delivers durable domestic capacity and a valuable public stake, or construction, demand, governance and subsidy risks may reduce those benefits and the second fab may never proceed. Therefore an up-to-$21 billion initiative and first-fab plan were announced—not two completed factories, realized production or a guaranteed Treasury profit.


## SOURCES

- [GlobalFoundries — selected to operate two New York fabs under U.S.-Japan initiative](https://gf.com/news-and-events/news/globalfoundries-selected-to-operate-two-new-semiconductor-fabs-in-new-york-under-landmark-us-japan-initiative/) — primary company announcement of investment structure, capacity, timing and conditional second fab
- [Reuters — Japan to invest up to $21 billion in GlobalFoundries New York fabs](https://www.reuters.com/business/retail-consumer/japan-invest-up-21-billion-two-us-chip-factories-be-run-by-globalfoundries-2026-10-14/) — independent reporting on ownership, funding, federal stake, construction timing and conditional second fab
- [Associated Press — GlobalFoundries plans two New York chip plants with Japanese financing](https://apnews.com/article/globalfoundries-chip-manufacturing-japan-trump-2cba3c18009fc19638dfd721a292bf1a) — independent reporting on announced fab financing, schedule and federal grant reallocation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
