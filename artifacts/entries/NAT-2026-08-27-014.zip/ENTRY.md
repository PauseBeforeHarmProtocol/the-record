# Study challenges EPA's claimed savings from vehicle-emissions rollback

**Entry ID:** NAT-2026-08-27-014
**Date:** August 27, 2026
**Checked:** 2026-08-28 6:03 AM EDT
**Evidence state:** peer-reviewed Science analysis and independent Associated Press reporting that includes EPA's response; modeled economic finding published, realized costs and legal consequences not yet measured
**Review state:** current-standard-reviewed

A peer-reviewed economic reanalysis estimates the rollback costs $670 billion rather than saving $600–790 billion; EPA stands by its model.

## THE FACTS

- A paper published in Science reanalyzed the Environmental Protection Agency's economic justification for eliminating federal greenhouse-gas standards for cars and trucks after the administration revoked the endangerment finding. The authors examined fuel savings, technology costs, vehicle mileage, and consumer behavior rather than treating the administration's projected savings as an observed result.
- EPA's analysis estimated that rescission would save Americans $600 billion to $790 billion over coming decades. The researchers estimate that correcting the assumptions reduces the claimed benefit by about $1.5 trillion and changes the result to an approximately $670 billion cost, before counting environmental benefits such as avoided pollution.
- One disputed assumption credits vehicle buyers with valuing only 23 cents of each dollar of future fuel savings. The authors also challenge technology-cost and payback-period assumptions and say each major correction can change the sign of the cost-benefit result.
- EPA told the Associated Press that it stands by its analysis, rejects what it calls an electric-vehicle mandate, and used established models with updated assumptions about consumer demand, fuel prices, and market conditions. The paper is an independently measured counter-analysis, not a court ruling or a revised agency estimate.

## SIGNIFICANCE

The study directly tests the administration's principal consumer-savings rationale for a major climate and vehicle-policy rollback. Its estimate would reverse the sign of the claimed economic benefit even before pollution costs, but policy consequences depend on scientific scrutiny, litigation, and whether EPA revises or successfully defends its analysis.

## GOALPOST / RESPONSE

EPA says removing the standards restores consumer choice and reflects updated demand, fuel-price, and market assumptions. The researchers say the analysis systematically understates fuel savings and misstates technology and mileage effects. Replication, peer response, the administrative record, judicial review, actual vehicle prices and fuel use, and any revised EPA analysis are the tests.

## MAYBE / THEREFORE

Maybe EPA's market assumptions better predict real consumer behavior than the study's corrections, or later data may validate part of either model. Therefore the record reports a peer-reviewed effectiveness and cost finding that sharply contradicts EPA's projection—not $670 billion in already-realized losses or a final legal determination that the rollback is invalid.


## SOURCES

- [Science — correcting the economic logic behind the 2026 U.S. vehicle-emissions rollback](https://www.science.org/doi/10.1126/science.aef0464) — peer-reviewed primary economic effectiveness analysis
- [Associated Press — economists challenge EPA's vehicle-emissions rollback savings](https://apnews.com/article/climate-study-vehicle-emissions-trump-administration-dfecdac9bb805dd9ab49f2c11f757fd2) — independent reporting on the study, outside assessment, and EPA response
- [EPA — regulatory analysis for rescission of vehicle greenhouse-gas standards](https://nepis.epa.gov/Exe/ZyPDF.cgi?Dockey=P101HV06.pdf) — primary administration economic analysis evaluated by the Science paper

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
