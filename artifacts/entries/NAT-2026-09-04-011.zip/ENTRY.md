# Supreme Court restores party committees' access to discounted broadcast ad rates

**Entry ID:** NAT-2026-09-04-011
**Date:** September 4, 2026
**Checked:** 2026-09-04 6:00 PM EDT
**Evidence state:** primary Supreme Court order plus independent Reuters and Associated Press reporting; stay operative, certiorari and merits unresolved
**Review state:** current-standard-reviewed

The emergency stay revives the FCC policy for the midterm advertising window while review continues; it does not finally decide the policy's legality.

## THE FACTS

- The Supreme Court granted the National Republican Congressional Committee and National Republican Senatorial Committee's emergency application in No. 26A274, recalled the Fourth Circuit's mandate and stayed it while the committees seek Supreme Court review.
- The Fourth Circuit had set aside FCC guidance treating coordinated political-party advertisements as eligible for broadcasters' lowest-unit-charge rates. The Supreme Court stay allows that policy to operate during the 60-day general-election window that began September 4.
- The Court's order terminates automatically if certiorari is denied and otherwise lasts until the Court sends down its judgment. Justice Ketanji Brown Jackson dissented. The order therefore preserves the policy temporarily rather than deciding its merits.
- Reuters reported that Republican national committees entered the period with more than twice the cash held by their Democratic counterparts and that the Republican Senate committee estimated lowest-unit-charge placements can cost three to thirteen times less than outside-group advertising. Those campaign claims and balances describe potential practical stakes, not a judicial finding about electoral effects.

## SIGNIFICANCE

The stay changes the price and availability rules governing coordinated party advertising at the start of the midterm general-election window. Because the major Republican committees held a substantial cash advantage, the temporary legal rule may affect campaign reach even before the Supreme Court decides whether to review the merits.

## GOALPOST / RESPONSE

The Republican committees and FCC say the lower-court mandate disrupted settled purchasing expectations and political speech; Democratic candidates say the policy exposes them to more negative advertising and competition for limited airtime. A certiorari petition, final Supreme Court disposition, FCC proceedings, broadcaster pricing data, ad reservations and spending and audience measures are the tests.

## MAYBE / THEREFORE

Maybe restoring the discounted rate treats coordinated party speech consistently with candidate advertising, or it may give cash-rich party committees an immediate advantage under a policy later found unlawful. Therefore the record confirms an emergency stay with present operational effect—not final approval of the FCC interpretation or proof of a particular election result.


## SOURCES

- [Supreme Court — stay order in NRCC v. Brown, No. 26A274](https://www.supremecourt.gov/opinions/25pdf/26a274_l537.pdf) — primary emergency order recalling and staying the Fourth Circuit mandate pending possible certiorari review
- [Reuters — Supreme Court restores party access to discounted broadcast advertising rates](https://www.reuters.com/world/us-supreme-court-preserves-parties-access-cheap-ads-siding-with-republicans-2026-09-04/) — independent reporting on the emergency stay, FCC policy and midterm campaign context
- [Associated Press — Supreme Court grants Republican emergency appeal on broadcast ad rates](https://apnews.com/article/a7a1cfc0c208d3949467756a64857cc2) — independent reporting on the temporary stay and Justice Jackson's dissent

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
