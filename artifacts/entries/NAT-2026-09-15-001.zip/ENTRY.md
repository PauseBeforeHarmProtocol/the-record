# Election officials build legal, physical-security and cyber contingencies amid federal pressure

**Entry ID:** NAT-2026-09-15-001
**Date:** September 15, 2026
**Checked:** 2026-09-15 6:02 AM EDT
**Evidence state:** Reuters special investigation based on direct interviews with more than 50 state and local officials, documentary records, site reporting and on-record White House, DHS and CISA responses; preparations implemented, feared interventions and election effects unresolved
**Review state:** current-standard-reviewed

Reuters interviewed more than 50 officials across parties; their preparations document consequences and perceived risks, not proof that a feared federal intervention will occur.

## THE FACTS

- Reuters interviewed more than 50 state and local election officials from both parties, including about a dozen secretaries of state. Nearly all said they were adopting new strategies for political interference, misinformation, cyberattacks or threats of violence before the November midterms; the finding measures reported preparation and concern, not a completed disruption.
- More than a dozen officials said jurisdictions were hiring outside lawyers or seeking legal training for possible federal demands involving records or equipment. Nearly twice that number reported expanding public outreach against misinformation, and most described efforts to replace reduced federal cyber or physical-security support.
- Reuters documented concrete preparations including draft court filings, counsel on standby, warrant and subpoena training, polling-place drills, surveillance, ballistic barriers, panic buttons and security escorts. The measures span Democratic and Republican jurisdictions; they do not establish that every office adopted the same response or that any forecast scenario will occur.
- The report connected the preparations to already documented federal actions and statements, including the Fulton County records seizure, election-related FBI contacts in Milwaukee, voter-data litigation, mail-ballot restrictions and Trump's refusal in May to rule out federal agents or troops at polling places. DHS told Reuters that ICE had no planned operations targeting polling sites, while reserving action for an active public-safety threat.
- Reuters reported that the Cybersecurity and Infrastructure Security Agency cut nearly 1,000 workers—about 30% of its staff—and stopped funding a platform that shared real-time election-threat information with states. CISA said it remained fully equipped for national-security cyber threats and was stronger than ever; the report did not measure a successful intrusion caused by the cuts.
- The White House said the administration was enforcing election laws and safeguarding confidence, and blamed Democrats for public distrust. Reuters noted that courts had blocked several federal efforts and that armed deployments at election sites would likely face legal challenge. No federal polling-place deployment, ballot seizure during the 2026 vote or adjudicated election interference was established by cutoff.

## SIGNIFICANCE

The investigation documents a national operational consequence of federal election-policy pressure: bipartisan local officials are spending time and resources on legal defense, physical protection, public communication and replacement cybersecurity capacity. Those preparations may improve resilience, but they also show diminished trust between federal and local election institutions before voting begins.

## GOALPOST / RESPONSE

The administration says it is enforcing election law, protecting public confidence and maintaining sufficient cyber capability; DHS says ICE has no operation planned to target polling places. The tests are actual federal directives and deployments, court rulings, CISA support and incident response, documented costs, voter access, verified threats and post-election audits—not anticipated scenarios alone.

## MAYBE / THEREFORE

Maybe officials are prudently planning for low-probability disruptions in a tense election environment, and the preparations may prevent rather than predict harm. Therefore the record establishes widespread, concrete contingency work reported across parties and a documented reduction in federal support—not that the administration will carry out every feared action, that an election outcome has been altered or that a cyberattack has succeeded.


## SOURCES

- [Reuters special report — election officials prepare legal, security and cyber contingencies](https://www.reuters.com/investigations/election-officials-prepare-chaos-trump-seeks-tilt-midterms-republicans-2026-09-15/) — independent investigation based on more than 50 direct official interviews, documents, field reporting and administration responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
