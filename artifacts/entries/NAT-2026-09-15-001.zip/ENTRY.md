# Election officials build contingencies as FBI and CISA issue midterm cyber alert

**Entry ID:** NAT-2026-09-15-001
**Date:** September 15–October 16, 2026
**Checked:** 2026-10-16 11:57 AM EDT
**Evidence state:** Reuters special investigation, primary federal complaint and litigant release, plus primary FBI/CISA alert and independent Reuters confirmation; preparations and warning documented, alleged policies, deployments, intrusions and outcomes unresolved
**Review state:** current-standard-reviewed

Local officials report legal and security preparations while a new federal alert warns of phishing, smishing and AI-enabled deepfakes; neither establishes a completed disruption.

## THE FACTS

- Reuters interviewed more than 50 state and local election officials from both parties, including about a dozen secretaries of state. Nearly all said they were adopting new strategies for political interference, misinformation, cyberattacks or threats of violence before the November midterms; the finding measures reported preparation and concern, not a completed disruption.
- More than a dozen officials said jurisdictions were hiring outside lawyers or seeking legal training for possible federal demands involving records or equipment. Nearly twice that number reported expanding public outreach against misinformation, and most described efforts to replace reduced federal cyber or physical-security support.
- Reuters documented concrete preparations including draft court filings, counsel on standby, warrant and subpoena training, polling-place drills, surveillance, ballistic barriers, panic buttons and security escorts. The measures span Democratic and Republican jurisdictions; they do not establish that every office adopted the same response or that any forecast scenario will occur.
- The report connected the preparations to already documented federal actions and statements, including the Fulton County records seizure, election-related FBI contacts in Milwaukee, voter-data litigation, mail-ballot restrictions and Trump's refusal in May to rule out federal agents or troops at polling places. DHS told Reuters that ICE had no planned operations targeting polling sites, while reserving action for an active public-safety threat.
- Reuters reported that the Cybersecurity and Infrastructure Security Agency cut nearly 1,000 workers—about 30% of its staff—and stopped funding a platform that shared real-time election-threat information with states. CISA said it remained fully equipped for national-security cyber threats and was stronger than ever; the report did not measure a successful intrusion caused by the cuts.
- The White House said the administration was enforcing election laws and safeguarding confidence, and blamed Democrats for public distrust. Reuters noted that courts had blocked several federal efforts and that armed deployments at election sites would likely face legal challenge. No federal polling-place deployment, ballot seizure during the 2026 vote or adjudicated election interference was established by cutoff.
- On October 7, plaintiffs filed a first amended complaint in LULAC v. DHS, No. 1:26-cv-03157-LLA, Doc. 22, adding Hennepin County, the Justice Department, FBI, Attorney General Todd Blanche and FBI Director Kash Patel. The pleading alleges that DHS/ICE and DOJ/FBI policies permit armed federal agents at polling places beyond the narrow 18 U.S.C. § 592 exception and adds a Voting Rights Act § 11(b) intimidation claim. These are allegations in a filed complaint; no inspected order, injunction or completed deployment established them by cutoff.
- On October 16, the FBI and CISA issued a joint public-service announcement warning that malicious actors may try to disrupt the 2026 midterms through phishing and smishing aimed at stealing credentials or sensitive information. The alert identifies election officials, candidates and political organizations as attractive targets because of their access to voter-registration, government and campaign information.
- The agencies said generative “super intelligence” can make fraudulent messages more convincing and enable deepfake audio and video. They recommended phishing-resistant multifactor authentication, content credentials and verification through known channels; the alert describes threats and mitigations, not a finding that a particular 2026 election system was breached.

## SIGNIFICANCE

The record now pairs bipartisan local contingency work with a formal federal cyber warning weeks before the midterms. The alert adds concrete federal guidance despite reported reductions in CISA support, but it does not prove a successful intrusion, validate every anticipated federal-pressure scenario or establish an election outcome effect.

## GOALPOST / RESPONSE

The administration says it is enforcing election law, protecting public confidence and retaining national-security cyber capability; the FBI/CISA alert says officials and campaigns should harden accounts and verify suspicious communications. The tests are implemented mitigations, actual directives and deployments, incident reports, court orders, CISA support, documented costs, voter access and post-election audits—not warnings or complaint allegations alone.

## MAYBE / THEREFORE

Maybe the new alert and local preparations will prevent or contain attacks, or the combination of sophisticated phishing and reduced support may expose gaps. Therefore the record establishes widespread contingency work, a filed legal challenge and a formal federal cyber warning—not a court finding, completed federal polling-place deployment, successful breach or altered election outcome.


## SOURCES

- [Reuters special report — election officials prepare legal, security and cyber contingencies](https://www.reuters.com/investigations/election-officials-prepare-chaos-trump-seeks-tilt-midterms-republicans-2026-09-15/) — independent investigation based on more than 50 direct official interviews, documents, field reporting and administration responses
- [LULAC v. DHS — first amended complaint, D.D.C. No. 1:26-cv-03157-LLA, Doc. 22](https://democracyforward.org/wp-content/uploads/2026/10/22.pdf) — primary filed complaint; allegations and requested relief, not a ruling
- [Democracy Forward — plaintiffs expand polling-place federal-agent challenge](https://democracyforward.org/news/press-releases/voting-rights-organizations-and-local-governments-expand-challenge-to-trump-vance-administrations-plans-for-armed-federal-agents-at-polling-places/) — litigant release identifying amended parties and claims
- [FBI/CISA PSA — Cyber threat actors target election and campaign officials](https://www.ic3.gov/PSA/2026/PSA261016) — primary federal cybersecurity alert
- [Reuters — U.S. warns election officials about AI-powered cyber tricks](https://www.reuters.com/legal/litigation/us-tells-election-officials-be-guard-against-ai-powered-tricks-ahead-midterms-2026-10-16/) — independent report on primary FBI/CISA alert

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
