# Election officials build legal, physical-security and cyber contingencies amid federal pressure

**Entry ID:** NAT-2026-09-15-001
**Date:** September 15–October 7, 2026
**Checked:** 2026-10-07 11:58 PM EDT
**Evidence state:** Reuters special investigation plus a primary first amended federal complaint and litigant release; preparations measured and complaint filed, alleged policies, deployments and court outcomes unresolved
**Review state:** current-standard-reviewed

An amended federal complaint now challenges alleged DHS, ICE, DOJ and FBI polling-place policies; the filing records allegations and requested relief, not a ruling or verified deployment.

## THE FACTS

- Reuters interviewed more than 50 state and local election officials from both parties, including about a dozen secretaries of state. Nearly all said they were adopting new strategies for political interference, misinformation, cyberattacks or threats of violence before the November midterms; the finding measures reported preparation and concern, not a completed disruption.
- More than a dozen officials said jurisdictions were hiring outside lawyers or seeking legal training for possible federal demands involving records or equipment. Nearly twice that number reported expanding public outreach against misinformation, and most described efforts to replace reduced federal cyber or physical-security support.
- Reuters documented concrete preparations including draft court filings, counsel on standby, warrant and subpoena training, polling-place drills, surveillance, ballistic barriers, panic buttons and security escorts. The measures span Democratic and Republican jurisdictions; they do not establish that every office adopted the same response or that any forecast scenario will occur.
- The report connected the preparations to already documented federal actions and statements, including the Fulton County records seizure, election-related FBI contacts in Milwaukee, voter-data litigation, mail-ballot restrictions and Trump's refusal in May to rule out federal agents or troops at polling places. DHS told Reuters that ICE had no planned operations targeting polling sites, while reserving action for an active public-safety threat.
- Reuters reported that the Cybersecurity and Infrastructure Security Agency cut nearly 1,000 workers—about 30% of its staff—and stopped funding a platform that shared real-time election-threat information with states. CISA said it remained fully equipped for national-security cyber threats and was stronger than ever; the report did not measure a successful intrusion caused by the cuts.
- The White House said the administration was enforcing election laws and safeguarding confidence, and blamed Democrats for public distrust. Reuters noted that courts had blocked several federal efforts and that armed deployments at election sites would likely face legal challenge. No federal polling-place deployment, ballot seizure during the 2026 vote or adjudicated election interference was established by cutoff.
- On October 7, plaintiffs filed a first amended complaint in LULAC v. DHS, No. 1:26-cv-03157-LLA, Doc. 22, adding Hennepin County, the Justice Department, FBI, Attorney General Todd Blanche and FBI Director Kash Patel. The pleading alleges that DHS/ICE and DOJ/FBI policies permit armed federal agents at polling places beyond the narrow 18 U.S.C. § 592 exception and adds a Voting Rights Act § 11(b) intimidation claim. These are allegations in a filed complaint; no inspected order, injunction or completed deployment established them by cutoff.

## SIGNIFICANCE

The investigation documents a national operational consequence of federal election-policy pressure: bipartisan local officials are spending time and resources on legal defense, physical protection, public communication and replacement cybersecurity capacity. The amended complaint converts part of that concern into a formal multi-agency legal challenge, but it does not establish the alleged policies or halt any deployment.

## GOALPOST / RESPONSE

The administration says it is enforcing election law, protecting public confidence and maintaining sufficient cyber capability; DHS says ICE has no operation planned to target polling places. The tests are the defendants’ formal positions, actual directives and deployments, court orders, CISA support, documented costs, voter access, verified threats and post-election audits—not complaint allegations or anticipated scenarios alone.

## MAYBE / THEREFORE

Maybe officials and plaintiffs are prudently responding to a low-probability risk, or discovery and merits review may show that the challenged policies are narrower than alleged. Therefore the record establishes widespread contingency work and a filed amended challenge naming additional agencies and claims—not a court finding, a completed polling-place deployment, an altered election outcome or a successful cyberattack.


## SOURCES

- [Reuters special report — election officials prepare legal, security and cyber contingencies](https://www.reuters.com/investigations/election-officials-prepare-chaos-trump-seeks-tilt-midterms-republicans-2026-09-15/) — independent investigation based on more than 50 direct official interviews, documents, field reporting and administration responses
- [LULAC v. DHS — first amended complaint, D.D.C. No. 1:26-cv-03157-LLA, Doc. 22](https://democracyforward.org/wp-content/uploads/2026/10/22.pdf) — primary filed complaint; allegations and requested relief, not a ruling
- [Democracy Forward — plaintiffs expand polling-place federal-agent challenge](https://democracyforward.org/news/press-releases/voting-rights-organizations-and-local-governments-expand-challenge-to-trump-vance-administrations-plans-for-armed-federal-agents-at-polling-places/) — litigant release identifying amended parties and claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
