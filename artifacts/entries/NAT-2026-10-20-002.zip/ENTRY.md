# Justice Department launches funded fraud-whistleblower incentive program

**Entry ID:** NAT-2026-10-20-002
**Date:** October 20, 2026
**Checked:** 2026-10-26 6:02 PM EDT
**Evidence state:** primary Justice Department program announcement and Trump Truth Social statement with independent Associated Press and Reuters reporting; WHIP terms and Treasury funding announced, later presidential reward descriptions differ, and no implementing details or measured effectiveness exist for the $1 million proposal
**Review state:** current-standard-reviewed

The announced program offers defined awards for qualifying tips involving major federal benefit and assistance programs, backed by a $25 million Treasury commitment.

## THE FACTS

- The Justice Department announced the Fraud Whistleblower Incentive Program, or WHIP, as an operating framework for rewarding people whose original information helps federal authorities pursue fraud, waste or abuse in specified government programs. The covered areas include Medicare, Medicaid, nutrition assistance, veterans benefits, unemployment insurance and disaster assistance.
- DOJ said the Treasury Department committed $25 million to the program. Announced award amounts begin at $10,000 and may rise to $30,000 when a tip contributes to criminal charges or specified civil or forfeiture outcomes. The published terms and committed funding establish a program launch, not measured fraud recovery or proof that every submitted allegation is valid.
- Associated Press reported that initial awards were presented in connection with matters in which charges had been filed. Charges are allegations, and neither the announcement nor the ceremony establishes guilt, final recoveries or the program's comparative effectiveness.
- President Trump said he would arbitrate competing claims over who first identified suspected fraud. Associated Press also reported that no award check was presented to activist Nick Shirley in reporters' presence and noted that prior inspections of facilities he publicized had found them operating as expected, although later investigations produced arrests and one guilty plea. Those distinctions limit what the ceremony establishes about any individual claim.
- Reuters reported after the prior cutoff that President Trump described an unlimited reward equal to 1 percent of reported fraud, while the Justice Department described awards of $10,000 to $30,000 and said awards remain in its sole discretion. Reuters also reported that Trump announced a $10,000 award for Nick Shirley. The differing descriptions are preserved as a material implementation question; the announcement does not establish that a payment was completed.
- On October 26, Trump published and repeated a new promise to pay $1 million for reports of voter fraud that lead to arrest and conviction. Reuters and Associated Press reported that no agency, funding source, eligibility rules or payment mechanism was identified. The statement is an announced proposal, not an implemented award program; election-fraud tips also do not appear among the federal-benefit categories in DOJ's published WHIP terms.

## SIGNIFICANCE

The funded WHIP program creates an incentive channel for tips across several high-spending federal programs, while the later $1 million election-fraud promise would be a much larger and differently scoped reward. Its significance depends on whether the administration supplies lawful funding, objective eligibility and false-report safeguards and whether tips generate verified recoveries or durable cases.

## GOALPOST / RESPONSE

The administration presents cash incentives as a faster way to expose fraud and protect taxpayers. The tests are published eligibility and conflict rules, an identified legal and funding authority for the $1 million promise, actual award decisions, independently documented charges and recoveries, false-report safeguards, due process for accused voters and audited cost-effectiveness.

## MAYBE / THEREFORE

Maybe rewards will surface valuable evidence that ordinary audits miss, or the much larger election-fraud promise may attract duplicative and poorly supported accusations without a workable payment authority. Therefore the record distinguishes DOJ's funded $10,000-to-$30,000 program from Trump's announced $1 million proposal; neither establishes proven savings, verified guilt in referenced cases or demonstrated effectiveness.


## SOURCES

- [Justice Department — Fraud Whistleblower Incentive Program announcement](https://www.justice.gov/opa/pr/justice-department-announces-innovative-whistleblower-rewards-program-combat-fraud) — primary program announcement describing eligibility, award ranges, covered programs and Treasury funding
- [Associated Press — administration announces fraud whistleblower awards program](https://apnews.com/article/trump-fraud-whistleblower-vance-cc7c155c06cbab74d423911c36f5ac78) — independent reporting on the program, its funding, initial award framework and administration claims
- [Reuters — Trump launches fraud-tip rewards and describes broader commission](https://www.reuters.com/legal/government/trump-promises-cash-fraud-tips-he-awards-right-wing-youtuber-2026-10-20/) — independent reporting comparing the President’s commission statement with Justice Department award terms and reporting the first announced award
- [Donald Trump Truth Social — $1 million voter-fraud reward statement](https://truthsocial.com/@realDonaldTrump/117508870323063258) — primary statement proving publication of the proposal, not independent verification of voter-fraud claims or implementation
- [Reuters — Trump offers $1 million for voter-fraud tipoffs](https://www.reuters.com/world/trump-offers-1-million-tipoffs-that-lead-voter-fraud-convictions-2026-10-26/) — independent reporting on the presidential proposal and absence of implementing details
- [Associated Press — Trump announces $1 million voter-fraud bounty](https://apnews.com/article/594f803fa578c450e38e5cb00410e299) — independent reporting on the social-media announcement and its political and evidentiary context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
