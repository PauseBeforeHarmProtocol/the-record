# Justice Department launches funded fraud-whistleblower incentive program

**Entry ID:** NAT-2026-10-20-002
**Date:** October 20, 2026
**Checked:** 2026-10-20 5:59 PM EDT
**Evidence state:** primary Justice Department program announcement with independent Associated Press reporting; program terms and Treasury funding announced, early enforcement links described and outcomes not yet measured
**Review state:** current-standard-reviewed

The announced program offers defined awards for qualifying tips involving major federal benefit and assistance programs, backed by a $25 million Treasury commitment.

## THE FACTS

- The Justice Department announced the Fraud Whistleblower Incentive Program, or WHIP, as an operating framework for rewarding people whose original information helps federal authorities pursue fraud, waste or abuse in specified government programs. The covered areas include Medicare, Medicaid, nutrition assistance, veterans benefits, unemployment insurance and disaster assistance.
- DOJ said the Treasury Department committed $25 million to the program. Announced award amounts begin at $10,000 and may rise to $30,000 when a tip contributes to criminal charges or specified civil or forfeiture outcomes. The published terms and committed funding establish a program launch, not measured fraud recovery or proof that every submitted allegation is valid.
- Associated Press reported that initial awards were presented in connection with matters in which charges had been filed. Charges are allegations, and neither the announcement nor the ceremony establishes guilt, final recoveries or the program's comparative effectiveness.
- President Trump said he would arbitrate competing claims over who first identified suspected fraud. Associated Press also reported that no award check was presented to activist Nick Shirley in reporters' presence and noted that prior inspections of facilities he publicized had found them operating as expected, although later investigations produced arrests and one guilty plea. Those distinctions limit what the ceremony establishes about any individual claim.

## SIGNIFICANCE

The program creates a funded incentive channel for public tips across several high-spending federal programs and links payments to enforcement milestones. Its significance will depend on whether tips generate verified recoveries or durable cases without rewarding unsupported accusations or duplicating existing whistleblower systems.

## GOALPOST / RESPONSE

The administration presents cash incentives as a faster way to expose fraud and protect taxpayers. The tests are published eligibility and conflict rules, award decisions, independently documented charges and recoveries, false-report safeguards, due process for accused recipients and audited cost-effectiveness.

## MAYBE / THEREFORE

Maybe a defined reward structure will surface valuable evidence that ordinary audits miss, or it may attract duplicative and poorly supported accusations while credit disputes consume resources. Therefore the record establishes an announced and funded incentive program with stated award criteria—not proven savings, verified guilt in referenced cases or demonstrated program effectiveness.


## SOURCES

- [Justice Department — Fraud Whistleblower Incentive Program announcement](https://www.justice.gov/opa/pr/justice-department-announces-innovative-whistleblower-rewards-program-combat-fraud) — primary program announcement describing eligibility, award ranges, covered programs and Treasury funding
- [Associated Press — administration announces fraud whistleblower awards program](https://apnews.com/article/trump-fraud-whistleblower-vance-cc7c155c06cbab74d423911c36f5ac78) — independent reporting on the program, its funding, initial award framework and administration claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
