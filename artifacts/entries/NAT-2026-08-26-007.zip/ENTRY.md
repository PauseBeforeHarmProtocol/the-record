# Federal judge blocks HUD's restructuring of fair-housing grants

**Entry ID:** NAT-2026-08-26-007
**Date:** August 26, 2026
**Checked:** 2026-08-26 5:59 PM EDT
**Evidence state:** August 26 district-court memorandum and temporary restraining order independently reported by Reuters; restructuring blocked at a preliminary stage, merits and long-term funding allocation unresolved
**Review state:** current-standard-reviewed

A temporary restraining order prevents HUD from replacing more than 100 historically smaller grants with a five-award structure while the court reviews an arbitrary-and-capricious claim.

## THE FACTS

- U.S. District Judge Myong Joun granted a temporary restraining order blocking HUD's July restructuring of the Fair Housing Initiatives Program, finding the plaintiff organizations likely to succeed on their claim that HUD lacked a reasoned explanation for sweeping changes.
- The challenged plan would direct $46 million of the $56 million fiscal-year 2025 appropriation to about five awards, including a potential $25 million award to a law school, and reserve $10 million for state or local agencies. The court said the structure effectively excluded many established fair-housing organizations and held the FY2025 funds available while the case proceeds.
- HUD described the changes as modernization intended to broaden participation and address new enforcement needs, and defended conditions concerning gender ideology, immigration, and faith-based language. The court ruled only at the preliminary stage, declined to resolve the remaining claims, and found the agency's explanation likely arbitrary and capricious.

## SIGNIFICANCE

The order temporarily preserves access to congressionally funded fair-housing enforcement and education grants for nonprofit organizations that HUD's new structure would have displaced. It also subjects a large grant-program redesign and unrelated ideological conditions to Administrative Procedure Act review.

## GOALPOST / RESPONSE

HUD says the older grant process had become formulaic and that larger, more competitive awards would modernize enforcement, broaden participation, and target emerging discrimination. Plaintiffs say the design excludes the experienced organizations Congress intended to support. The merits record, any revised notices, appeal, final award distribution, enforcement backlog, and grant performance are the evidence tests.

## MAYBE / THEREFORE

Maybe HUD can justify a revised competitive structure with a fuller record and preserve meaningful participation by smaller organizations, or it may prevail after the preliminary stage. Therefore the record says the restructuring is temporarily blocked—not permanently vacated—and distinguishes the court's likelihood finding from a final merits judgment.


## SOURCES

- [District of Massachusetts — memorandum granting temporary relief in fair-housing grant case](https://fingfx.thomsonreuters.com/gfx/legaldocs/lgvdeyzdkpo/08262026hud.pdf) — primary court memorandum and preliminary findings, Civil Action No. 26-30117-MJJ
- [Reuters — judge blocks HUD fair-housing grant restructuring](https://www.reuters.com/legal/government/us-judge-blocks-trump-overhaul-funding-fair-housing-groups-2026-08-26/) — independent reporting on the court order, funding structure, and HUD response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
