# Federal judge blocks HUD's restructuring of fair-housing grants

**Entry ID:** NAT-2026-08-26-007
**Date:** August 26, 2026
**Checked:** 2026-10-19 6:00 PM EDT
**Evidence state:** August 26 district-court order, October 19 First Circuit stay order and independent Reuters reporting; core restructuring remains blocked pending appeal, prior-structure notice mandate stayed and merits unresolved
**Review state:** current-standard-reviewed

The First Circuit left most of the block on HUD's fair-housing grant overhaul in place while lifting the requirement to reissue fiscal-year 2025 notices under the prior structure.

## THE FACTS

- U.S. District Judge Myong Joun granted a temporary restraining order blocking HUD's July restructuring of the Fair Housing Initiatives Program, finding the plaintiff organizations likely to succeed on their claim that HUD lacked a reasoned explanation for sweeping changes.
- The challenged plan would direct $46 million of the $56 million fiscal-year 2025 appropriation to about five awards, including a potential $25 million award to a law school, and reserve $10 million for state or local agencies. The court said the structure effectively excluded many established fair-housing organizations and held the FY2025 funds available while the case proceeds.
- HUD described the changes as modernization intended to broaden participation and address new enforcement needs, and defended conditions concerning gender ideology, immigration, and faith-based language. The court ruled only at the preliminary stage, declined to resolve the remaining claims, and found the agency's explanation likely arbitrary and capricious.
- On October 19, a First Circuit panel granted HUD a stay only as to the district court's direction to issue new fiscal-year 2025 notices under the 2024 structure. It denied the remainder of HUD's stay request, leaving the core block on the replacement notices in place during the appeal.
- The panel said HUD had not made a strong showing of likely success on its reviewability, vacatur-authority or arbitrary-and-capricious arguments and noted that the government had not substantially addressed the district court's pretext finding. HUD said it would use all legal options to defend the overhaul and cited responsible stewardship and improved enforcement.

## SIGNIFICANCE

The appellate order keeps most of the preliminary protection for the nonprofit fair-housing network while narrowing the remedy that dictated a specific prior-year notice structure. It also supplies a second judicial assessment of HUD's Administrative Procedure Act defenses without resolving the merits appeal.

## GOALPOST / RESPONSE

HUD says the older process had become formulaic and that larger awards would improve stewardship and enforcement. Plaintiffs say the redesign excludes experienced organizations Congress intended to support. Expedited merits briefing, any revised lawful notices, final award distribution, enforcement capacity and grant performance are the tests.

## MAYBE / THEREFORE

Maybe HUD can justify a revised competitive structure on a fuller record or ultimately prevail on appeal, while the narrower stay may give it flexibility to design new notices. Therefore most of the overhaul remains blocked pending appeal, but the court did not require HUD to reuse the 2024 structure and did not issue a final merits judgment.


## SOURCES

- [District of Massachusetts — memorandum granting temporary relief in fair-housing grant case](https://fingfx.thomsonreuters.com/gfx/legaldocs/lgvdeyzdkpo/08262026hud.pdf) — primary court memorandum and preliminary findings, Civil Action No. 26-30117-MJJ
- [Reuters — judge blocks HUD fair-housing grant restructuring](https://www.reuters.com/legal/government/us-judge-blocks-trump-overhaul-funding-fair-housing-groups-2026-08-26/) — independent reporting on the court order, funding structure, and HUD response
- [First Circuit — order granting in part and denying in part HUD's stay request](https://fingfx.thomsonreuters.com/gfx/legaldocs/zdvxejkdnpx/10192026housing.pdf) — primary appellate order on the fair-housing grant restructuring
- [Reuters — appeals court leaves most fair-housing grant block in place](https://www.reuters.com/legal/government/trump-administration-cannot-overhaul-fair-housing-grant-program-appeals-court-2026-10-19/) — independent reporting on the First Circuit stay order and HUD response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
