# Government-paid Trump ads top $1.4 million estimate amid bipartisan scrutiny

**Entry ID:** NAT-2026-09-24-002
**Date:** September 24–28, 2026
**Checked:** 2026-09-28 11:59 PM EDT
**Evidence state:** congressional records request and White House response plus independent Associated Press and Reuters reporting; three ads and an AdImpact estimate documented, payer agency, audited cost, contract, approvals and legal disposition unresolved
**Review state:** current-standard-reviewed

Three national spots carried a U.S.-government payer disclosure; AdImpact estimated more than $1.4 million in spending, while the responsible agency and legal disposition remained unknown.

## THE FACTS

- On September 24, Senator Maggie Hassan requested records from White House Chief of Staff Susie Wiles about government-paid television advertising and asked for a response by October 8. The inquiry alleges an improper political purpose; it is not an adjudicated finding.
- Associated Press and Reuters reported that three nationally broadcast spots identified the U.S. government as payer. One promoted tax, manufacturing and law-enforcement claims; another used Mount Rushmore imagery; a third was virtually identical to a 2024 Trump campaign video except for the government-payment disclosure.
- AdImpact estimated spending of more than $1.4 million across the three campaigns. AP said the actual total could be higher depending on classification. This is a third-party media-spending estimate, not an audited federal obligation, disbursement or final series cost.
- The White House defended the spots as patriotic public-service messaging, said they contained no call to action and emphasized that Trump was not on the ballot. Those are the administration's stated purpose and legal position, not an independent finding.
- Republican and Democratic lawmakers and several legal experts raised funding, propaganda and election-law concerns. Those views do not establish a violation. The paying agency, appropriation, contract, approvals and complete expenditure remained undisclosed, and no evidence tied the ads' funding or staff to Trump TV.

## SIGNIFICANCE

A measured expansion from one identified spot to three national campaigns, plus bipartisan scrutiny, makes the unresolved funding and approval chain more consequential. The reporting still does not establish an unlawful expenditure.

## GOALPOST / RESPONSE

The White House says the series is lawful public education and patriotic messaging rather than election advocacy. Critics point to the campaign-video reuse, timing and undisclosed payer. Agency invoices, contracts, funding accounts, approvals and any congressional, inspector-general or court findings remain the tests.

## MAYBE / THEREFORE

Maybe the spots were authorized public communications, or their content, campaign origins and timing may support an improper-purpose finding. Therefore the record reports three broadcasts and an attributed spending estimate while leaving the payer, total federal cost and legality unresolved; it does not infer shared funding with Trump TV.


## SOURCES

- [Senator Hassan calls for answers on taxpayer-funded Trump advertisement](https://www.jec.senate.gov/public/index.cfm/democrats/2026/9/senator-hassan-calls-for-immediate-answers-on-new-taxpayer-funded-trump-political-ad) — congressional letter
- [Presidential Public Service Announcements Are Nothing New](https://www.whitehouse.gov/releases/2026/09/presidential-public-service-announcements-are-nothing-new/) — official statement
- [White House defends government-funded Trump ad as Democrats demand answers](https://news4sanantonio.com/news/nation-world/white-house-defends-government-funded-trump-ad-democrats-demand-answers-public-service-announcement-midterm-elections-love-me-jmsn-song-dana-white-fox-newsmax-adimpact-spending-susie-wiles-letter-senator-maggie-hassan-jamie-raskin-advertisement) — news report
- [Government-funded advertisement reuses 2024 campaign video; AdImpact spending estimate](https://www.news4jax.com/news/politics/2026/09/27/trump-administration-begins-airing-2024-trump-campaign-ad-in-latest-taxpayer-funded-messaging/) — independent reporting
- [Trump administration's taxpayer-funded ads draw bipartisan criticism](https://apnews.com/article/26ae03010d78221d1d93b06c0818d06d) — independent reporting
- [Trump government ads draw scrutiny weeks before midterm elections](https://www.reuters.com/business/media-telecom/trump-government-ads-draw-scrutiny-weeks-before-midterm-elections-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
