# Government-paid advertisement reuses Trump campaign video; oversight questions remain

**Entry ID:** NAT-2026-09-24-002
**Date:** September 24–27, 2026
**Checked:** 2026-09-27 11:57 PM EDT
**Evidence state:** Congressional records request and White House response, supplemented by AP reporting identifying the reused campaign video and a named AdImpact estimate; payer agency, contract, total expenditure and legal disposition unresolved
**Review state:** current-standard-reviewed

AP identified a reused 2024 campaign spot and an AdImpact spending estimate; the White House defends public-service messaging, while agency funding and legality remain unresolved.

## THE FACTS

- On September 24, Senator Maggie Hassan sent White House Chief of Staff Susie Wiles a records request about a television advertisement identifying the U.S. government as its payer. Her published letter requested a response by October 8. This is a congressional inquiry, not an adjudicated finding of unlawful spending.
- The request seeks production and placement invoices, approvals and staff time, funding accounts and authority, legal or ethics reviews, contractor records and advertising schedules. Hassan alleged an improper political purpose; that allegation remains attributed.
- On September 25, the White House defended the advertisements as patriotic public education, citing earlier presidential public-service campaigns and arguing Trump was not on the ballot and the spots contained no call to action. Independent reporting also documented the request and response.
- The inspected statements did not identify the paying agency, appropriation, procurement contract or complete expenditure. No evidence inspected here ties the advertisement’s funding or personnel to Trump TV. This September 24–25 development is added retrospectively after source completion on September 26, not presented as a new September 26 action.
- On September 27, AP reported that a government-paid 30-second television spot was virtually identical to a 2024 Trump campaign video, with a government-payment disclosure replacing the campaign ending. AP attributed spending above approximately $319,000 for this latest spot to AdImpact. This is a third-party media-spending estimate, not an audited federal outlay or the total cost of the advertising series. The report predates the preceding research boundary and is included here as retrospective source completion.

## SIGNIFICANCE

The reported reuse of campaign material and a named spending estimate add concrete evidence for the existing oversight inquiry. They strengthen the need to identify the approving officials, appropriations and public purpose; they do not themselves establish a legal violation.

## GOALPOST / RESPONSE

The White House says the series educates the public, promotes patriotism, includes no call to action and concerns a president who is not on the ballot. The campaign-video comparison raises a concrete competing concern about purpose. Agency invoices, contracts, funding accounts, approvals and any congressional, inspector-general or court findings remain the tests.

## MAYBE / THEREFORE

Maybe the advertisements were authorized public communications, or their campaign origins and use may support an improper-purpose finding. Therefore the record distinguishes the reported broadcast and attributed spending estimate from unresolved funding authority and legality; it establishes no shared budget or staff with Trump TV.


## SOURCES

- [Senator Hassan calls for answers on taxpayer-funded Trump advertisement](https://www.jec.senate.gov/public/index.cfm/democrats/2026/9/senator-hassan-calls-for-immediate-answers-on-new-taxpayer-funded-trump-political-ad) — congressional letter
- [Presidential Public Service Announcements Are Nothing New](https://www.whitehouse.gov/releases/2026/09/presidential-public-service-announcements-are-nothing-new/) — official statement
- [White House defends government-funded Trump ad as Democrats demand answers](https://news4sanantonio.com/news/nation-world/white-house-defends-government-funded-trump-ad-democrats-demand-answers-public-service-announcement-midterm-elections-love-me-jmsn-song-dana-white-fox-newsmax-adimpact-spending-susie-wiles-letter-senator-maggie-hassan-jamie-raskin-advertisement) — news report
- [Government-funded advertisement reuses 2024 campaign video; AdImpact spending estimate](https://www.news4jax.com/news/politics/2026/09/27/trump-administration-begins-airing-2024-trump-campaign-ad-in-latest-taxpayer-funded-messaging/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
