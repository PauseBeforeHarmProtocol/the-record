# DHS identifies $20 million contract behind government-paid Trump ads

**Entry ID:** NAT-2026-09-24-002
**Date:** September 24–29, 2026
**Checked:** 2026-09-29 5:56 PM EDT
**Evidence state:** federal award data and independent Associated Press reporting identify DHS, CBP funding and a $20 million contract; airtime spending is estimated, final disbursements, approvals and legality remain unresolved
**Review state:** current-standard-reviewed

Federal award data ties the campaign to a $20 million DHS contract funded through CBP; estimated airtime exceeds $2.5 million, while legality and final spending remain unresolved.

## THE FACTS

- On September 24, Senator Maggie Hassan requested White House records about government-paid television advertising. On September 29, Senate Appropriations chair Susan Collins separately requested a full accounting, and Senators Patty Murray and Chris Murphy asked the Department of Homeland Security for contract and funding records. The inquiries allege or examine possible misuse; they are not adjudicated findings.
- Associated Press and Reuters reported that three nationally broadcast spots identified the U.S. government as payer. One promoted tax, manufacturing and law-enforcement claims; another used Mount Rushmore imagery; a third was virtually identical to a 2024 Trump campaign video except for the government-payment disclosure.
- Associated Press reported that the Department of Homeland Security used $20 million moved from a 2025 appropriation intended for Customs and Border Protection and awarded LMD Agency a firm-fixed-price national media campaign contract on September 20. The federal award identifier is 70B06C26F00001137 under parent agreement 70Z02323ACGRC0001, with a performance period through September 19, 2027.
- AdImpact estimated more than $2.5 million in airtime during the prior seven days. The estimate may omit some placements and is not an audited federal disbursement, while the $20 million award ceiling does not establish that the full amount has been spent.
- The White House defended the spots as patriotic public-service announcements, and DHS said public messaging supports its mission. Critics cite campaign-video reuse, timing and the use of border funds. No inspector general, court or congressional body had issued a legal finding by cutoff.
- No inspected evidence tied the advertising contract, appropriation, staff or production chain to Trump TV. The separate White House channel and this paid campaign therefore remain distinct unless primary records later establish shared resources.

## SIGNIFICANCE

Identifying DHS, the funding transfer and a $20 million contract converts an opaque payer question into a traceable federal expenditure and sharpens congressional oversight. The award amount and airtime estimate still do not establish final cost, statutory misuse or shared Trump TV funding.

## GOALPOST / RESPONSE

The administration says the campaign is lawful public-service messaging that supports DHS's mission. Critics argue the content and use of border funds may serve a political purpose. The appropriation transfer record, contract and invoices, approvals, deliverables, DHS responses, inspector-general work and any legal finding are the tests.

## MAYBE / THEREFORE

Maybe DHS lawfully purchased a broad public-information campaign, or the content and funding transfer may support an improper-purpose or appropriations finding after review. Therefore the record establishes a $20 million award and reported funding path—not that all $20 million was spent, that a violation occurred or that Trump TV shared its money or staff.


## SOURCES

- [Senator Hassan calls for answers on taxpayer-funded Trump advertisement](https://www.jec.senate.gov/public/index.cfm/democrats/2026/9/senator-hassan-calls-for-immediate-answers-on-new-taxpayer-funded-trump-political-ad) — congressional letter
- [Presidential Public Service Announcements Are Nothing New](https://www.whitehouse.gov/releases/2026/09/presidential-public-service-announcements-are-nothing-new/) — official statement
- [White House defends government-funded Trump ad as Democrats demand answers](https://news4sanantonio.com/news/nation-world/white-house-defends-government-funded-trump-ad-democrats-demand-answers-public-service-announcement-midterm-elections-love-me-jmsn-song-dana-white-fox-newsmax-adimpact-spending-susie-wiles-letter-senator-maggie-hassan-jamie-raskin-advertisement) — news report
- [Government-funded advertisement reuses 2024 campaign video; AdImpact spending estimate](https://www.news4jax.com/news/politics/2026/09/27/trump-administration-begins-airing-2024-trump-campaign-ad-in-latest-taxpayer-funded-messaging/) — independent reporting
- [Trump administration's taxpayer-funded ads draw bipartisan criticism](https://apnews.com/article/26ae03010d78221d1d93b06c0818d06d) — independent reporting
- [Trump government ads draw scrutiny weeks before midterm elections](https://www.reuters.com/business/media-telecom/trump-government-ads-draw-scrutiny-weeks-before-midterm-elections-2026-09-28/) — independent reporting
- [AP — Senate Appropriations chair seeks accounting for government-paid Trump advertisements](https://apnews.com/article/c6dd26d8e67270db543c37ac3762acd9) — independent reporting on a formal congressional records request and White House response
- [AP — DHS used border funds for $20 million Trump advertising contract](https://apnews.com/article/b869294503c8454db4109ae175ee9e5c) — independent reporting based on federal award data and named responses
- [GovTribe — LMD Agency national media campaign federal award record](https://govtribe.com/award/federal-contract-award/bpa-call-70z02323acgrc0001-70b06c26f00001137) — federal contract-data mirror for award 70B06C26F00001137

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
