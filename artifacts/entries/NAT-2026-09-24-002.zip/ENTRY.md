# Hassan seeks records on government-paid Trump advertisement; White House defends it

**Entry ID:** NAT-2026-09-24-002
**Date:** September 24–25, 2026 (reviewed September 26)
**Checked:** 2026-09-26 11:57 AM EDT
**Evidence state:** Primary congressional letter and White House response, corroborated by independent reporting; inquiry initiated, funding particulars and alleged legal violation unresolved
**Review state:** current-standard-reviewed

A congressional records request now supplies a formal oversight development for a previously withheld lead; the paying agency, contract, total cost and legal outcome remain unresolved.

## THE FACTS

- On September 24, Senator Maggie Hassan sent White House Chief of Staff Susie Wiles a records request about a television advertisement identifying the U.S. government as its payer. Her published letter requested a response by October 8. This is a congressional inquiry, not an adjudicated finding of unlawful spending.
- The request seeks production and placement invoices, approvals and staff time, funding accounts and authority, legal or ethics reviews, contractor records and advertising schedules. Hassan alleged an improper political purpose; that allegation remains attributed.
- On September 25, the White House defended the advertisements as patriotic public education, citing earlier presidential public-service campaigns and arguing Trump was not on the ballot and the spots contained no call to action. Independent reporting also documented the request and response.
- The inspected statements did not identify the paying agency, appropriation, procurement contract or complete expenditure. No evidence inspected here ties the advertisement’s funding or personnel to Trump TV. This September 24–25 development is added retrospectively after source completion on September 26, not presented as a new September 26 action.

## SIGNIFICANCE

The formal request identifies records that could establish who authorized the spending, which funds were used and whether the stated public purpose matches the actual purchase. Oversight can test an official explanation without presuming its conclusion.

## GOALPOST / RESPONSE

The White House says the spots educate the public and express patriotism rather than campaign advocacy. Hassan questions their official purpose. Invoices, approvals, appropriations, legal reviews and any eventual oversight or judicial findings are the tests; a promotional tone alone does not resolve legality.

## MAYBE / THEREFORE

Maybe the requested records will substantiate authorized public education, or they may reveal improper use of resources. Therefore the verified development is a formal records demand and administration defense; payer-level accounting, total cost and legal findings remain open.


## SOURCES

- [Senator Hassan calls for answers on taxpayer-funded Trump advertisement](https://www.jec.senate.gov/public/index.cfm/democrats/2026/9/senator-hassan-calls-for-immediate-answers-on-new-taxpayer-funded-trump-political-ad) — congressional letter
- [Presidential Public Service Announcements Are Nothing New](https://www.whitehouse.gov/releases/2026/09/presidential-public-service-announcements-are-nothing-new/) — official statement
- [White House defends government-funded Trump ad as Democrats demand answers](https://news4sanantonio.com/news/nation-world/white-house-defends-government-funded-trump-ad-democrats-demand-answers-public-service-announcement-midterm-elections-love-me-jmsn-song-dana-white-fox-newsmax-adimpact-spending-susie-wiles-letter-senator-maggie-hassan-jamie-raskin-advertisement) — news report

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
