# Trump announces private funding shift for government-paid advertising campaign

**Entry ID:** NAT-2026-09-24-002
**Date:** September 24–October 6, 2026
**Checked:** 2026-10-06 6:08 PM EDT
**Evidence state:** official inquiries/award evidence and independent reporting, now including a White House clarification reported by Axios; reimbursement unsupported, future private-payment implementation unresolved
**Review state:** current-standard-reviewed

The White House now says Trump's comments did not refer to reimbursement; future private funding and actual federal outlays remain unverified.

## THE FACTS

- On September 24, Senator Maggie Hassan requested White House records about government-paid television advertising. On September 29, Senate Appropriations chair Susan Collins separately requested a full accounting, and Senators Patty Murray and Chris Murphy asked the Department of Homeland Security for contract and funding records. The inquiries allege or examine possible misuse; they are not adjudicated findings.
- Associated Press and Reuters reported that three nationally broadcast spots identified the U.S. government as payer. One promoted tax, manufacturing and law-enforcement claims; another used Mount Rushmore imagery; a third was virtually identical to a 2024 Trump campaign video except for the government-payment disclosure.
- Associated Press reported that the Department of Homeland Security used $20 million moved from a 2025 appropriation intended for Customs and Border Protection and awarded LMD Agency a firm-fixed-price national media campaign contract on September 20. The federal award identifier is 70B06C26F00001137 under parent agreement 70Z02323ACGRC0001, with a performance period through September 19, 2027.
- AdImpact estimated more than $2.5 million in airtime during the prior seven days. The estimate may omit some placements and is not an audited federal disbursement, while the $20 million award ceiling does not establish that the full amount has been spent.
- The White House defended the spots as patriotic public-service announcements, and DHS said public messaging supports its mission. Critics cite campaign-video reuse, timing and the use of border funds. No inspector general, court or congressional body had issued a legal finding by cutoff.
- No inspected evidence tied the advertising contract, appropriation, staff or production chain to Trump TV. The separate White House channel and this paid campaign therefore remain distinct unless primary records later establish shared resources.
- The Washington Post reported that the campaign placed 38 spots on MS NOW and 10 on CNN, including the 'Country He Loves' and 'Final Battle' ads in selected markets. AdImpact modeled at least $2.87 million across three ads but could not isolate the CNN and MS NOW portions; the estimate is not an invoice or audited disbursement. The White House characterized the messages as public-service advertising intended to foster patriotism.
- On September 30, FCC Chair Brendan Carr said he saw no basis for Commission review or broadcaster liability and compared the spots to public-service announcements. Trump said the ads promoted the country rather than a candidate and said he would repay the money if the spending were found improper. Those statements are positions, not an FCC order, dismissal or legal judgment.
- On October 1, Representatives Jamie Raskin and George Whitesides asked the Government Accountability Office and Office of Special Counsel to investigate whether the ads violate restrictions on government propaganda or political activity. The requests open no adjudicated finding and do not establish that either watchdog accepted or completed a review by cutoff.
- On October 5, Trump said the television advertising would no longer use taxpayer funding and that he would pay personally or through MAGA Inc. AP and Reuters independently reported the statement and a White House confirmation that the PAC would fund future ads. This is an announced funding change, not proof of completed payments.
- AP reported that neither Trump nor the White House supplied details about repayment for ads already aired or verification of future private payments. No inspected contract amendment, termination, invoice, payment record or reimbursement established those outcomes by cutoff. The earlier federal award and oversight questions remain part of the record.
- On October 6, AP reported AdImpact’s estimate that more than $11 million in the advertising had aired. This is a named media-tracking estimate, not an audited federal cash disbursement or the $20 million contract ceiling. The original AdImpact placement dataset was not retrieved; reimbursement and completed private payments remain unverified.
- On October 6, a White House spokesperson told Axios that Trump's announcement was not referring to reimbursement. The clarification narrows the earlier ambiguity: no inspected evidence establishes repayment for government-funded ads already aired. The White House continued to characterize the spots as nonpolitical public-service announcements.

## SIGNIFICANCE

The clarification makes repayment of prior government-funded airtime less plausible on the present record while leaving the announced future private-funding shift and oversight questions unresolved. The estimated scale remains a media-tracking figure rather than audited outlays.

## GOALPOST / RESPONSE

The White House defends the messages as public-service announcements and says Trump's comments did not promise reimbursement. Contract amendments, invoices, completed private payments, future placements and watchdog or court findings are the tests.

## MAYBE / THEREFORE

Maybe private funding ends future taxpayer exposure and actual federal payments differ from airtime estimates. Therefore the White House has disclaimed a reimbursement reading, and no repayment evidence was located; future private payment, audited outlays and legality remain unresolved. No evidence links the campaign's resources to Trump TV.


## SOURCES

- [Senator Hassan calls for answers on taxpayer-funded Trump advertisement](https://www.jec.senate.gov/public/index.cfm/democrats/2026/9/senator-hassan-calls-for-immediate-answers-on-new-taxpayer-funded-trump-political-ad) — congressional letter
- [Presidential Public Service Announcements Are Nothing New](https://www.whitehouse.gov/releases/2026/09/presidential-public-service-announcements-are-nothing-new/) — official statement
- [White House defends government-funded Trump ad as Democrats demand answers](https://news4sanantonio.com/news/nation-world/white-house-defends-government-funded-trump-ad-democrats-demand-answers-public-service-announcement-midterm-elections-love-me-jmsn-song-dana-white-fox-newsmax-adimpact-spending-susie-wiles-letter-senator-maggie-hassan-jamie-raskin-advertisement) — news report
- [Government-funded advertisement reuses 2024 campaign video; AdImpact spending estimate](https://www.news4jax.com/news/politics/2026/09/27/trump-administration-begins-airing-2024-trump-campaign-ad-in-latest-taxpayer-funded-messaging/) — independent reporting
- [Trump administration's taxpayer-funded ads draw bipartisan criticism](https://apnews.com/article/26ae03010d78221d1d93b06c0818d06d) — independent reporting
- [Trump government ads draw scrutiny weeks before midterm elections](https://www.reuters.com/business/media-telecom/trump-government-ads-draw-scrutiny-weeks-before-midterm-elections-2026-09-28/) — independent reporting
- [AP — Senate Appropriations chair seeks accounting for government-paid Trump advertisements](https://apnews.com/article/c6dd26d8e67270db543c37ac3762acd9) — independent reporting on a formal congressional records request and White House response
- [AP — DHS used border funds for $20 million Trump advertising contract](https://apnews.com/article/b869294503c8454db4109ae175ee9e5c) — independent reporting based on federal award data and named responses
- [GovTribe — LMD Agency national media campaign federal award record](https://govtribe.com/award/federal-contract-award/bpa-call-70z02323acgrc0001-70b06c26f00001137) — federal contract-data mirror for award 70B06C26F00001137
- [Washington Post — government-paid Trump ads aired on CNN and MS NOW](https://www.washingtonpost.com/business/2026/09/30/trump-ads-run-cnn-ms-now-amid-fight-bar-them-white-house/) — independent reporting on placements and modeled airtime spending
- [Reuters — FCC chair says government-paid Trump ads do not raise concerns](https://www.reuters.com/world/us-fcc-chair-says-government-ads-featuring-trump-do-not-raise-concerns-2026-09-30/) — independent reporting on regulator-chair and presidential responses
- [Reuters — House members seek GAO and OSC review of government-paid Trump ads](https://www.reuters.com/legal/government/democratic-lawmakers-seek-probe-us-government-ads-featuring-trump-2026-10-01/) — independent reporting on oversight requests and responses
- [Reuters — Trump says taxpayers will no longer pay for TV ads](https://www.reuters.com/world/us/trump-says-will-pay-tv-ads-after-pushback-over-taxpayer-funding-close-election-2026-10-05/) — independent reporting
- [AP — Trump says super PAC will pay for ads](https://apnews.com/article/trump-taxpayer-funded-ads-super-pac-e6f47f7b86f83938aacfb16bda12efaa) — independent reporting
- [Donald J. Trump on Truth Social — announced shift of Patriotic Ads to personal and MAGA Inc. funding](https://truthsocial.com/@realDonaldTrump/117390649505706640) — primary source for the fact that Trump published the statement; retained text acquired from CNN-hosted public archive mirror; not independent verification of expenditures, completed funding changes, reimbursement, or Trump TV funding/staff
- [AP — AdImpact reports more than $11 million in government advertising airtime](https://apnews.com/live/trump-midterm-elections-news-updates-10-06-2026) — independent named-source expenditure estimate
- [Axios — White House says Trump ad comments did not refer to reimbursement](https://www.axios.com/2026/10/06/trump-super-pac-taxpayer-funded-ads-reimbursement) — independent reporting with named institutional response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
