# Government-paid Trump ads top $1.4 million estimate as oversight expands

**Entry ID:** NAT-2026-09-24-002
**Date:** September 24–29, 2026
**Checked:** 2026-09-29 11:56 AM EDT
**Evidence state:** congressional records requests and White House response plus independent Associated Press and Reuters reporting; three ads, an AdImpact estimate and expanded oversight documented, payer agency, audited cost, contract, approvals and legal disposition unresolved
**Review state:** current-standard-reviewed

Three national spots carried a U.S.-government payer disclosure; a second senator requested a full accounting, while the paying agency, audited cost and legal disposition remained unknown.

## THE FACTS

- On September 24, Senator Maggie Hassan requested records from White House Chief of Staff Susie Wiles about government-paid television advertising and asked for a response by October 8. The inquiry alleges an improper political purpose; it is not an adjudicated finding.
- Associated Press and Reuters reported that three nationally broadcast spots identified the U.S. government as payer. One promoted tax, manufacturing and law-enforcement claims; another used Mount Rushmore imagery; a third was virtually identical to a 2024 Trump campaign video except for the government-payment disclosure.
- AdImpact estimated spending of more than $1.4 million across the three campaigns. AP said the actual total could be higher depending on classification. This is a third-party media-spending estimate, not an audited federal obligation, disbursement or final series cost.
- The White House defended the spots as patriotic public-service messaging, said they contained no call to action and emphasized that Trump was not on the ballot. Those are the administration's stated purpose and legal position, not an independent finding.
- Republican and Democratic lawmakers and several legal experts raised funding, propaganda and election-law concerns. Those views do not establish a violation. The paying agency, appropriation, contract, approvals and complete expenditure remained undisclosed, and no evidence tied the ads' funding or staff to Trump TV.
- On September 29, Senate Appropriations Committee chair Susan Collins asked the White House and Office of Management and Budget for a full accounting of the advertisements' expenditures. The request expands bipartisan oversight; it is not a finding that a law was violated and did not identify the paying agency, appropriation, contract or final cost.

## SIGNIFICANCE

A measured expansion to three national campaigns and a formal request from the Senate Appropriations chair broaden the funding and approval inquiry. The reporting still does not establish an unlawful expenditure or identify the responsible agency.

## GOALPOST / RESPONSE

The White House says the series is lawful public education and patriotic messaging rather than election advocacy. Critics point to campaign-video reuse, timing and the undisclosed payer. Agency invoices, contracts, funding accounts, approvals, responses to congressional requests and any inspector-general or court findings remain the tests.

## MAYBE / THEREFORE

Maybe the spots were authorized public communications, or their content, campaign origins, timing and undisclosed funding may support an improper-purpose finding. Therefore the record reports three broadcasts, an attributed spending estimate and expanded congressional oversight while leaving the payer, total federal cost and legality unresolved; it does not infer shared funding with Trump TV.


## SOURCES

- [Senator Hassan calls for answers on taxpayer-funded Trump advertisement](https://www.jec.senate.gov/public/index.cfm/democrats/2026/9/senator-hassan-calls-for-immediate-answers-on-new-taxpayer-funded-trump-political-ad) — congressional letter
- [Presidential Public Service Announcements Are Nothing New](https://www.whitehouse.gov/releases/2026/09/presidential-public-service-announcements-are-nothing-new/) — official statement
- [White House defends government-funded Trump ad as Democrats demand answers](https://news4sanantonio.com/news/nation-world/white-house-defends-government-funded-trump-ad-democrats-demand-answers-public-service-announcement-midterm-elections-love-me-jmsn-song-dana-white-fox-newsmax-adimpact-spending-susie-wiles-letter-senator-maggie-hassan-jamie-raskin-advertisement) — news report
- [Government-funded advertisement reuses 2024 campaign video; AdImpact spending estimate](https://www.news4jax.com/news/politics/2026/09/27/trump-administration-begins-airing-2024-trump-campaign-ad-in-latest-taxpayer-funded-messaging/) — independent reporting
- [Trump administration's taxpayer-funded ads draw bipartisan criticism](https://apnews.com/article/26ae03010d78221d1d93b06c0818d06d) — independent reporting
- [Trump government ads draw scrutiny weeks before midterm elections](https://www.reuters.com/business/media-telecom/trump-government-ads-draw-scrutiny-weeks-before-midterm-elections-2026-09-28/) — independent reporting
- [AP — Senate Appropriations chair seeks accounting for government-paid Trump advertisements](https://apnews.com/article/c6dd26d8e67270db543c37ac3762acd9) — independent reporting on a formal congressional records request and White House response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
