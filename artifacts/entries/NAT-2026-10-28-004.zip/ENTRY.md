# Trump orders robotics import negotiations without imposing immediate tariffs

**Entry ID:** NAT-2026-10-28-004
**Date:** October 28, 2026
**Checked:** 2026-10-29 6:06 AM EDT
**Evidence state:** signed White House proclamation and independent Reuters report; negotiations ordered, immediate tariffs absent, underlying report and outcomes not independently validated
**Review state:** current-standard-reviewed

A signed Section 232 proclamation directs Commerce and USTR talks and a progress update within 180 days; future restrictions and claimed security benefits remain prospective.

## THE FACTS

- On October 28, Trump signed a Section 232 proclamation concurring with Commerce’s finding that imports of robotics, industrial machinery and their components threaten to impair national security. The proclamation attributes import-dependence, defense-production and cybersecurity concerns to Commerce; this record does not independently validate the underlying investigation’s findings.
- The operative clauses direct Commerce and the U.S. Trade Representative to pursue or continue agreements with trading partners and give the president a status update within 180 days. Commerce must monitor imports and identify circumstances that might warrant further presidential action.
- The proclamation leaves tariffs, duties, quotas, fees and a domestic-investment incentive program as possible future remedies. It sets no immediate new tariff rate or quota; Reuters independently reported that distinction. No completed agreement, new collection of duties or measured security, output or employment benefit is established by this action.

## SIGNIFICANCE

The order formally advances a sector-specific national-security trade process while leaving the commercial remedy unsettled. Negotiation authority and future tariff exposure can affect planning, but neither is a measured manufacturing revival or an imposed tariff.

## GOALPOST / RESPONSE

The administration argues domestic capacity and secure equipment supply are necessary for defense readiness and critical infrastructure. Its case must be tested against the investigation’s evidence, negotiated terms, equipment availability, downstream costs and demonstrated security and production results.

## MAYBE / THEREFORE

Maybe negotiations can reduce supply-chain and cybersecurity risks without raising manufacturers’ costs. Therefore a signed negotiation and monitoring direction is established; new tariff obligations, successful reshoring and net security or economic benefits require later instruments and evidence.


## SOURCES

- [White House — robotics and industrial-machinery Section 232 proclamation](https://www.whitehouse.gov/presidential-actions/2026/10/adjusting-imports-of-robotics-industrial-machinery-and-their-parts-and-components-into-the-united-states/) — primary signed proclamation; complete operative clauses inspected
- [Reuters — imported robotics security finding without immediate tariffs](https://www.reuters.com/world/china/trump-says-imported-robotics-pose-national-security-risks-does-not-impose-2026-10-28/) — independent reporting of the proclamation and absence of immediate new tariffs

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
