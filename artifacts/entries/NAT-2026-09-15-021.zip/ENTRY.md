# United States pays $827 million toward mandatory United Nations dues

**Entry ID:** NAT-2026-09-15-021
**Date:** September 11–16, 2026
**Checked:** 2026-09-16 5:58 PM EDT
**Evidence state:** Reuters reporting based on U.N. confirmation plus independent specialist PassBlue reporting; received amounts and remaining balances are separated by account and scope
**Review state:** current-standard-reviewed

The $725 million regular-budget and $102 million peacekeeping payments preserved the U.S. General Assembly vote, while substantial arrears remained.

## THE FACTS

- The United Nations confirmed that the Trump administration paid $725 million on September 15 toward the U.N. regular budget and $102 million on September 11 toward peacekeeping assessments. These were implemented payments, not announced future transfers.
- Reuters reported that the regular-budget payment reduced the U.S. amount outstanding there to $1.312 billion and eliminated the immediate risk of losing the General Assembly vote in 2027 under Article 19 of the U.N. Charter.
- PassBlue reported total remaining U.S. mandatory arrears of roughly $4.2 billion when regular-budget, peacekeeping and other assessed accounts are considered. That broader total is not interchangeable with the $1.312 billion regular-budget balance.
- The United States remained the U.N.'s largest assessed contributor. The administration has reduced voluntary funding and delayed mandatory payments while demanding reforms; the U.N. has been pursuing austerity and its UN80 reform initiative.
- Payment preserves voting rights under the arrears formula but does not settle all U.S. obligations, prove the effectiveness of the administration's leverage strategy or resolve the U.N.'s wider liquidity problems.

## SIGNIFICANCE

The transfer is a large implemented federal expenditure that materially reduces U.S. arrears and avoids a concrete institutional consequence: potential loss of the General Assembly vote. It also leaves billions in assessed obligations and the underlying dispute over U.N. funding and reform unresolved.

## GOALPOST / RESPONSE

The administration says it is aligning U.N. spending with U.S. taxpayer interests and using payment pressure to secure reform; U.N. officials emphasize the organization's legal assessments and liquidity needs. The tests are Treasury and U.N. payment records, remaining balances by account, Article 19 status, future appropriations and documented reform outcomes.

## MAYBE / THEREFORE

Maybe partial payment preserves U.S. influence while maintaining leverage for reform, or continued arrears may weaken programs and U.S. credibility without producing durable changes. Therefore the record establishes $827 million in received mandatory payments and the resulting vote protection—not full settlement, verified reform success or a single comparable figure for every U.N. account.


## SOURCES

- [Reuters — United States pays $725 million toward United Nations regular budget](https://www.reuters.com/world/us-pays-725-million-un-easing-its-debt-dispute-with-world-body-2026-09-16/) — independent reporting based on United Nations confirmation and assessed-contribution records
- [PassBlue — U.S. mandatory United Nations dues payments and remaining arrears](https://passblue.com/2026/09/15/us-pays-827-million-in-mandatory-un-dues-but-still-owes-about-4-2-billion/) — independent specialist reporting based on United Nations financial information

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
