# South Korea announces plans for major U.S. energy investments

**Entry ID:** NAT-2026-09-30-003
**Date:** September 30, 2026
**Checked:** 2026-09-30 6:04 PM EDT
**Evidence state:** independent Associated Press and Reuters reporting based on White House and South Korean government announcements, plus the federal permitting record; plans announced, Korean authorization and financing, binding contracts, construction and outcomes unresolved
**Review state:** current-standard-reviewed

The announced package includes an Alaska LNG project, a Texas gas-fired power project intended to supply AI data centers and nuclear projects, but financing, contracts and construction remain unresolved.

## THE FACTS

- South Korea's government on October 1 in Seoul—September 30 in the U.S. Eastern time zone—unveiled implementation plans for three U.S. energy initiatives within a broader bilateral investment framework. Trump separately announced plans for up to $200 billion in U.S. projects as part of a $350 billion trade-linked investment package.
- The plans include approximately $54 billion for the Alaska LNG project, which contemplates an 807-mile pipeline and export terminal. Associated Press reported that the project's financing still must be completed and that the timing and extent of South Korean government approval and spending were not settled.
- South Korea also described a $22.3 billion gas-fired power project in Encinal, Texas, intended to supply artificial-intelligence data centers, with initial operations targeted for 2029. Trump separately said the package included plans connected to eight U.S. nuclear plants.
- The administration presented the announcements as evidence that its trade policy was drawing capital, supporting U.S. energy production and strengthening the alliance. The announced headline amounts are plans and prospective investment values, not verified expenditures or completed projects.
- No final financing package, complete set of commercial contracts, construction completion or measured employment and energy-price effects was established by the cutoff; the record does not infer that no individual regulatory approval exists.

## SIGNIFICANCE

If financed and built, the projects would be a large cross-border commitment affecting U.S. gas exports, electricity supply, nuclear construction and AI infrastructure. At announcement stage, however, headline values can materially exceed eventual committed capital and do not establish public cost, delivery or economic benefit.

## GOALPOST / RESPONSE

The administration and South Korean government say the package will deepen the alliance, expand U.S. energy production and support jobs and AI infrastructure. The strongest response is that the largest projects still face financing, commercial and construction risk even though Alaska LNG completed federal permitting in December 2025. Binding contracts, financing closes, Korean authorization and spending, appropriations or guarantees, construction milestones, jobs and delivered energy are the tests.

## MAYBE / THEREFORE

Maybe the bilateral package converts into durable energy infrastructure and shared economic gains, or project economics and approvals may reduce, delay or reshape the announced commitments. Therefore the record establishes government-announced investment plans—not $200 billion already spent, completed Alaska LNG financing or operational projects.


## SOURCES

- [Associated Press — South Korea investment plan includes Alaska LNG](https://apnews.com/article/trump-alaska-south-korea-lng-gas-senate-03d3b10599c166840db2d92b872a8f7e) — independent reporting on announced projects, financing uncertainty and administration rationale
- [Reuters — South Korea unveils U.S. energy investment plans](https://www.reuters.com/world/asia-pacific/south-korea-unveils-major-energy-investment-plans-us-2026-09-30/) — independent reporting on South Korean government implementation announcements
- [Reuters — Trump announces South Korea U.S. investment package](https://www.reuters.com/legal/government/trump-expected-announce-54-billion-south-korea-investment-alaska-lng-sources-say-2026-09-30/) — independent reporting on White House announcement and package scope
- [Federal Permitting Improvement Steering Council — Alaska LNG completes federal permitting](https://www.permitting.gov/newsroom/press-releases/alaska-lng-completes-federal-permitting-ahead-schedule) — official federal permitting completion announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
