# USDA announces record $3.3 billion rural-utility loan for Georgia power plant

**Entry ID:** NAT-2026-10-14-010
**Date:** October 14–16, 2026
**Checked:** 2026-10-16 11:57 AM EDT
**Evidence state:** primary USDA announcement and SEC-filed borrower briefing plus independent Reuters reporting with named USDA and Oglethorpe responses; financing announced and prior conditional status documented, disbursement and outcomes unresolved
**Review state:** current-standard-reviewed

USDA calls the financing its largest Rural Utilities Service loan; an SEC-filed briefing listed it as conditionally committed with no funds advanced and initial funding expected in 2028.

## THE FACTS

- On October 14, Agriculture Secretary Brooke Rollins announced a $3.3 billion Rural Utilities Service loan to Oglethorpe Power Corporation to help finance the Smarr Combined-Cycle generating facility in Monroe County, Georgia. USDA described it as the largest loan in the Rural Utilities Service’s history.
- USDA said Oglethorpe is owned by 38 electric-distribution cooperatives serving nearly five million people and argued that lower-cost federal financing would support reliable, affordable power. Those are the agency and borrower’s stated purposes; the announcement does not measure final rates, construction costs, emissions or reliability outcomes.
- An Oglethorpe investor briefing filed with the SEC described the $3.324 billion Smarr financing as conditionally committed on August 6, requiring documentation, with $0 advanced as of July 31 and initial funding expected by 2028. The Record therefore treats USDA’s October announcement as committed or announced financing, not as proof that $3.3 billion had already been disbursed.
- USDA Rural Development Under Secretary Glen Smith told Reuters the plant could support growing Georgia industry, potentially including data centers, and said the agency had almost $8.6 billion in rural-utility loan requests. Oglethorpe said the facility is not dedicated to a data center and will serve broader cooperative demand.

## SIGNIFICANCE

The commitment is a record use of federal rural-utility financing for new gas-fired generation and could shape capacity, borrowing costs and who bears infrastructure risk as electricity demand grows. Potential data-center benefits are an official possibility, not a dedicated-use finding, and no disbursement or rate effect was established.

## GOALPOST / RESPONSE

USDA and Oglethorpe say the plant and lower-cost financing will improve reliability and affordability for cooperative members. Executed loan documents, advance schedules, appropriations exposure, construction milestones, generation costs, customer rates, capacity allocation, environmental permits and audited performance are the tests.

## MAYBE / THEREFORE

Maybe the loan lowers financing costs and supplies broadly shared rural capacity, or demand growth and project risks may leave customers or taxpayers with higher costs and benefits concentrated among large users. Therefore the record establishes an announced record loan and earlier conditional commitment—not completed disbursement, a data-center subsidy finding or demonstrated affordability and reliability gains.


## SOURCES

- [USDA — Historic $3.3 billion Oglethorpe Power loan announcement](https://usda.azureedge.us/about-usda/news/press-releases/2026/10/14/usda-makes-historic-33b-loan-build-electric-generation-facility-georgia) — primary federal financing announcement
- [Oglethorpe Power second-quarter 2026 investor briefing filed with SEC](https://www.sec.gov/Archives/edgar/data/788816/000078881626000050/oglethorpepowerq22026inv.htm) — primary company filing describing loan status and expected funding
- [Reuters — Data centers may benefit from record rural utility loan](https://www.reuters.com/legal/government/data-centers-may-benefit-massive-rural-utility-loan-us-official-says-2026-10-16/) — independent report with USDA and Oglethorpe responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
