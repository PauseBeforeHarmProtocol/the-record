# Supreme Court leaves $59 million research-grant injunction in place

**Entry ID:** NAT-2026-11-16-002
**Date:** November 16, 2026
**Checked:** 2026-11-16 12:08 PM EST
**Evidence state:** Supreme Court order list, Solicitor General petition and independent Reuters reporting; certiorari denied, preliminary injunction remains, underlying merits litigation not finally resolved
**Review state:** current-standard-reviewed

The justices denied the administration's petition in Trump v. Thakur without noted dissent, leaving the Ninth Circuit's preliminary First Amendment protection for NSF and NEH grants intact.

## THE FACTS

- The Supreme Court denied the administration's petition for certiorari in Trump v. Thakur, No. 26-210. No justice publicly noted a dissent from the denial. The denial leaves the lower-court judgment in place but does not create a Supreme Court merits precedent endorsing its reasoning.
- The Ninth Circuit had preserved preliminary relief for a class of University of California researchers whose National Science Foundation and National Endowment for the Humanities grants were terminated based on perceived viewpoints associated with diversity, equity and inclusion. The appellate court concluded the researchers were likely to succeed on their First Amendment claim.
- The Solicitor General said the affected NSF and NEH grants had about $59 million remaining and argued that government may selectively fund competitive projects aligned with elected policy. That is the administration's strongest legal explanation; the Court's denial does not separately adjudicate or reject every argument in the petition.
- The practical result is that the preliminary injunction requiring restoration and continued treatment of the covered grants remains operative while underlying litigation proceeds. Reuters reported that some grants extend as late as November 2029; final merits, payment execution and related parallel cases remain unresolved.
- The Court previously allowed other research-grant cuts to proceed on procedural grounds. The present denial concerns the specific First Amendment posture in Thakur and should not be described as a universal ruling requiring funding of every DEI-related project.

## SIGNIFICANCE

The denial preserves concrete funding and speech protections for a defined class and leaves a consequential Ninth Circuit rule governing viewpoint-based termination of existing competitive grants. It is a completed appellate development, but the relief remains preliminary and case-specific.

## GOALPOST / RESPONSE

The administration argues elected officials need latitude to change competitive-grant priorities; the researchers argue already-awarded grants were terminated for disfavored viewpoints. The tests are compliance with the injunction, final merits and statutory rulings, payment restoration, treatment of expiring grants, parallel-case outcomes and any revised termination policy.

## MAYBE / THEREFORE

Maybe the denial will stabilize the covered grants while courts clarify funding discretion, or agencies may pursue narrower procedural or programmatic routes in future cases. Therefore the Supreme Court declined review and left preliminary relief intact—not a merits holding that all grant cuts are unconstitutional or a final judgment ending the litigation.


## SOURCES

- [Supreme Court — order list denying certiorari in Trump v. Thakur](https://www.supremecourt.gov/orders/courtorders/111626zor_cb7d.pdf) — primary judicial order; certiorari denied without noted dissent
- [Office of the Solicitor General — petition for certiorari in Trump v. Thakur](https://www.justice.gov/osg/media/1459786/dl?inline=) — primary administration argument and procedural record; advocacy, not an adjudicated finding
- [Reuters — Supreme Court rejects appeal defending diversity-related grant cuts](https://www.reuters.com/world/supreme-court-rejects-trump-appeal-defending-diversity-related-grant-cuts-2026-11-16/) — independent court reporting on the denial, lower-court posture and grant amount

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
