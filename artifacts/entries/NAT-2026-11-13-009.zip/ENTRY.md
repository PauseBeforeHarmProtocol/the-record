# SEC proposes narrower executive-pay disclosure rules

**Entry ID:** NAT-2026-11-13-009
**Date:** November 13, 2026
**Checked:** 2026-11-14 12:08 AM EST
**Evidence state:** Primary SEC proposal announcement plus independent Reuters reporting of the agency rationale and an outside transparency objection; proposed, not final or effective
**Review state:** current-standard-reviewed

The proposal would usually reduce named executives from five or more to two, raise the perks threshold from $10,000 to $150,000 and simplify several compensation tables; it is open for comment and not yet effective.

## THE FACTS

- The Securities and Exchange Commission proposed amendments to Item 402 of Regulation S-K governing executive and director compensation disclosures. The proposal remains subject to public comment and is not a final or effective rule.
- The proposal would generally limit named executive officers to the principal executive officer and principal financial officer, reducing disclosure from typically five or more people to two in most circumstances. It would also replace four primary compensation tables with three new tables and accompanying narratives.
- The proposed amendments would raise the aggregate reporting threshold for executive perquisites from $10,000 to $150,000, simplify pay-versus-performance disclosure, limit the median-employee population under the pay-ratio rule to U.S. full-time employees and generally reduce that determination's frequency to once every five years.
- SEC Chairman Paul Atkins said the changes would make disclosure more materiality-driven, concise and useful while reducing burdens that do not provide commensurate investor benefit. Better Markets responded that scaling back disclosure would reduce transparency amid rapidly rising executive pay.
- The public comment period will remain open for 60 days after the proposing release is published in the Federal Register. The inspected material establishes no final Commission vote on adoption, effective date or measured compliance-cost or investor-information outcome.

## SIGNIFICANCE

The proposal would materially narrow and restructure information public companies provide about executive compensation, affecting investor oversight and issuer compliance burdens. Its effects remain prospective because the Commission has only proposed the changes.

## GOALPOST / RESPONSE

The proposal should be judged after comments and any final rule by the provisions actually adopted, issuer compliance costs, comparability and completeness of pay data, investor use, enforcement experience and whether omitted information proves material—not by the agency or opponents' predictions alone.

## MAYBE / THEREFORE

Maybe a principles-based framework will remove low-value complexity while preserving material compensation information, or the narrower scope may hide pay practices investors use to evaluate governance. Therefore the record establishes a formal SEC proposal and comment period—not an adopted rule, reduced disclosure in current filings or a measured benefit or harm.


## SOURCES

- [SEC — proposed executive and director compensation disclosure reforms](https://www.sec.gov/newsroom/press-releases/2026-114-sec-proposes-executive-director-compensation-disclosure-reforms) — primary regulatory proposal announcement stating the principal proposed amendments and comment period
- [Reuters — SEC proposes scaling back executive-pay disclosure rules](https://www.reuters.com/legal/government/us-sec-proposes-scaling-back-rules-on-executive-pay-disclosure-2026-11-13/) — independent reporting on the proposal's scope, SEC rationale and Better Markets response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
