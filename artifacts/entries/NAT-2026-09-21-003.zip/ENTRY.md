# Administration asks Supreme Court to review Badar Khan Suri detention ruling

**Entry ID:** NAT-2026-09-21-003
**Date:** September 21, 2026
**Checked:** 2026-09-22 12:02 PM EDT
**Evidence state:** complete primary certiorari petition plus Reuters legal reporting; requested review and arguments documented, Supreme Court disposition and underlying merits unresolved
**Review state:** current-standard-reviewed

The Solicitor General seeks review of a Fourth Circuit jurisdiction ruling that allowed Suri's habeas challenge and release; the petition is a request for certiorari, not a Supreme Court grant, merits ruling or order returning him to custody.

## THE FACTS

- The Solicitor General filed a petition asking the Supreme Court to review the Fourth Circuit's decision in Suri v. Trump. The petition presents whether the Immigration and Nationality Act channels Suri's detention challenge into the petition-for-review process rather than district-court habeas jurisdiction.
- The petition says Suri was detained during removal proceedings and that district-court orders barred his removal and released him on bond. It asks the Court to reverse the appellate jurisdictional ruling; it does not itself re-detain Suri, remove him, stay the lower-court orders or decide the underlying First Amendment allegations.
- The government argues that Suri's detention claims arise from the commencement and conduct of removal proceedings, that Congress made court-of-appeals review exclusive, and that the Fourth Circuit's approach conflicts with another circuit. Those are the administration's legal arguments, not Supreme Court findings.
- Reuters reported that Suri's lawyers describe the detention as retaliation for protected pro-Palestinian expression and associations. The administration disputes that characterization and maintains that the statutory review channel governs; the charges and constitutional claims remain contested.

## SIGNIFICANCE

The petition asks the Supreme Court to define whether district courts can use habeas jurisdiction to review and remedy immigration detention allegedly tied to protected speech. A ruling could affect the forum and timing available to other noncitizens challenging detention during removal proceedings.

## GOALPOST / RESPONSE

The administration says the INA channels intertwined removal and detention claims to courts of appeals and that parallel district-court habeas review disrupts enforcement. Suri argues habeas must remain available for allegedly retaliatory physical detention. Certiorari disposition, briefing, any stay request, a merits ruling, Suri's custody and removal case, and effects in other cases are the tests.

## MAYBE / THEREFORE

Maybe the Court will accept the government's channeling argument and narrow district-court habeas review, or it may deny review or preserve habeas for claims directed at present detention. Therefore the administration filed a certiorari petition challenging jurisdiction—not a Supreme Court decision, a renewed detention order or a merits resolution of the speech and removal claims.


## SOURCES

- [Solicitor General — petition for certiorari in Trump v. Suri](https://fingfx.thomsonreuters.com/gfx/legaldocs/moparjkmmva/09212026suri.pdf) — primary petition for a writ of certiorari (complete filed document hosted by Reuters)
- [Reuters — administration asks Supreme Court to review Suri detention ruling](https://www.reuters.com/legal/government/trump-administration-asks-us-supreme-court-allow-detention-pro-palestinian-2026-09-22/) — independent legal reporting on the certiorari petition and competing positions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
