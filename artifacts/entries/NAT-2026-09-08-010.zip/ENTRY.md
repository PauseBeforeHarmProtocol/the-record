# TSA launches ticketless gateside access for eligible trusted travelers at 13 airports

**Entry ID:** NAT-2026-09-08-010
**Date:** September 8, 2026
**Checked:** 2026-09-09 6:00 AM EDT
**Evidence state:** Associated Press and Scripps News independently reported the implemented TSA program and its stated rules; TSA's program page was identified but returned an access error during direct review
**Review state:** current-standard-reviewed

The free pilot permits approved visitors through security for one day; nationwide access and security or commercial effects are unmeasured.

## THE FACTS

- The Transportation Security Administration launched Gateside by TSA PreCheck at 13 airports, allowing eligible U.S. citizens, nationals and lawful permanent residents who already participate in TSA PreCheck or another specified trusted-traveler program to request airport-gate access without an airline ticket.
- Applicants must provide a Known Traveler Number and apply online one to three days in advance. Approval is not guaranteed; an approved visitor must present valid identification, use a TSA PreCheck lane, and receives access for one calendar day with reentry permitted at the participating airport.
- TSA described the program as supporting greetings and send-offs, meetings during layovers, dining and shopping, and said it could expand. The launch implements limited ticketless access at the named participating airports; it does not restore unrestricted pre-September-11 access, establish access at every airport or demonstrate effects on checkpoint security, wait times or airport revenue.

## SIGNIFICANCE

The program changes a longstanding post-September-11 access boundary for a screened, pre-vetted population and creates a new operational use of trusted-traveler credentials. Its public-safety and airport effects cannot be inferred from launch alone.

## GOALPOST / RESPONSE

TSA presents the program as a secure way to reconnect travelers and visitors while supporting airport activity. The tests are published screening criteria, denials and revocations, expansion decisions, checkpoint volume and wait times, security incidents, privacy safeguards and independently measured passenger and airport outcomes.

## MAYBE / THEREFORE

Maybe pre-vetted visitors can safely receive limited access with little operational burden, or additional screening volume and authorization complexity may create security or congestion costs. Therefore TSA implemented a bounded program at 13 airports—not universal ticketless access or proof that the program improves travel, commerce or security.


## SOURCES

- [Associated Press — TSA launches Gateside by TSA PreCheck at 13 airports](https://apnews.com/article/tsa-precheck-gateside-known-traveler-712d9888d3e7f00307a199c732986364) — independent reporting on an implemented TSA airport-access program and its stated eligibility rules
- [Scripps News — TSA gateside-access program begins at 13 airports](https://www.scrippsnews.com/us-news/new-tsa-program-brings-back-gate-access-for-eligible-individuals-without-tickets) — independent reporting quoting TSA's program page and describing eligibility and limitations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
