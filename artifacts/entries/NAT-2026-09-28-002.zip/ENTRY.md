# HUD sets higher conditional FY2027 Section 108 loan-guarantee fee

**Entry ID:** NAT-2026-09-28-002
**Date:** September 25–28, 2026
**Checked:** 2026-09-28 12:30 AM EDT
**Evidence state:** primary HUD fee announcement, 91 FR 61136–61138; publicly filed September 25 and published September 28; October 28 applicability subject to statutory collection authority
**Review state:** current-standard-reviewed

The announced fee rises from 0.58% to 1.05%, applicable October 28, but collection requires statutory authorization.

## THE FACTS

- HUD's September 28 notice, filed September 25, sets the Section 108 credit-subsidy fee at 1.05% of principal for FY2027 guarantee commitments, up from 0.58% for FY2026. The notice gives an October 28 applicability date.
- Collection is expressly conditional on enactment of authorizing appropriations language or other statutory authority. If authorized, HUD will apply the fee at loan disbursement. This notice does not itself enact an appropriation or establish that the fee has been collected.
- HUD bases the rate on updated portfolio composition, projected default and recovery cash flows, and required discount rates. It says no historical program default has required payment under its guarantee, but federal credit-budget rules prohibit assuming continued CDBG funds as repayment support. The fee reflects projected subsidy cost, not a newly measured default loss.

## SIGNIFICANCE

The announced increase changes the prospective financing cost of federally guaranteed community-development projects. Its legal collection condition and future applicability are material limits on the change.

## GOALPOST / RESPONSE

HUD says the fee should offset expected federal guarantee costs under credit-budget rules. The countervailing concern is higher borrower financing cost despite the cited absence of guarantee payouts. Enacted authority, disbursements, fee collections, project uptake and realized losses are the tests.

## MAYBE / THEREFORE

Maybe the higher fee will adequately price federal credit risk, or it may burden projects more than realized losses justify. Therefore the record identifies a conditional future charge, not an enacted funding measure, collected revenue or demonstrated program outcome.


## SOURCES

- [HUD sets higher conditional FY2027 Section 108 loan-guarantee fee](https://www.govinfo.gov/content/pkg/FR-2026-09-28/pdf/2026-19743.pdf) — primary HUD fee announcement, 91 FR 61136–61138; publicly filed September 25 and published September 28; October 28 applicability subject to statutory collection authority

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
