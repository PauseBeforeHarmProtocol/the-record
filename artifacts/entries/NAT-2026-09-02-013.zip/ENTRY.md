# Court preliminarily blocks EPA reclassification of California emissions waivers

**Entry ID:** NAT-2026-09-02-013
**Date:** June 12–September 2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** primary D.C. district-court preliminary-injunction order plus Reuters legal reporting; four EPA reclassifications stayed and status quo ordered restored, appeal and merits unresolved
**Review state:** current-standard-reviewed

The appealable order restores the pre-June status quo for four waiver orders while litigation continues; it does not resolve a separate challenge to Congress's earlier repeal action.

## THE FACTS

- U.S. District Judge Beryl Howell granted California a preliminary injunction against EPA's June reclassification of four Clean Air Act section 209(b) preemption-waiver orders as rules eligible for Congressional Review Act submission.
- The September 2 order directs EPA to restore the status quo before its June 12 press release, withdraw or correct the reclassifications in public statements and stop giving them effect. It covers Advanced Clean Cars I, its reinstatement, Small Off-Road Engine amendments and 2009-and-later greenhouse-gas emission standards.
- EPA must file a compliance status report by September 21. The court denied dismissal motions by EPA and industry intervenors and expressly identified the preliminary order as appealable and effective until further court order.
- The decision concerns these four waiver reclassifications and potential future congressional review. A separate challenge to Congress's earlier disapproval of California authority for a 2035 zero-emission vehicle mandate remains pending, so this injunction does not reinstate or finally resolve every California emissions waiver.

## SIGNIFICANCE

The injunction blocks an executive effort to expose longstanding California waiver orders to a streamlined congressional repeal mechanism and preserves the state's authority under the four covered actions while the case proceeds. It may also constrain EPA's ability to change legal classifications solely to trigger Congressional Review Act review.

## GOALPOST / RESPONSE

EPA and industry intervenors argued that the waiver actions are reviewable rules and that Congress should be able to consider them; California says Clean Air Act waivers are adjudicatory orders, not CRA rules. The administration had not issued a response by cutoff. EPA's September 21 compliance report, any appeal or stay, the merits judgment, congressional action and the separate 2035-waiver litigation are the tests.

## MAYBE / THEREFORE

Maybe the court will ultimately hold that EPA cannot reclassify waiver orders to route them through expedited congressional review, or an appellate court may find the dispute nonjusticiable or accept the agency's classification. Therefore the record states that four reclassifications are preliminarily enjoined and their pre-June status restored—not that every California vehicle rule is immune from Congress, finally valid or beyond separate litigation.


## SOURCES

- [U.S. District Court for the District of Columbia — California EPA-waiver preliminary-injunction order](https://oag.ca.gov/system/files/attachments/press-docs/order.pdf) — primary appealable order granting preliminary relief, restoring the pre-June status quo and staying EPA's reclassification of four waiver orders
- [Reuters — judge blocks EPA reclassification of four California emissions waivers](https://www.reuters.com/legal/litigation/us-judge-bars-epa-effort-send-california-vehicle-emissions-rules-congress-2026-09-03/) — independent reporting on the preliminary injunction, the Congressional Review Act dispute and the pending separate challenge

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
