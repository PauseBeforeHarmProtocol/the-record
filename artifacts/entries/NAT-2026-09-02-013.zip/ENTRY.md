# Court preliminarily blocks EPA reclassification of California emissions waivers

**Entry ID:** NAT-2026-09-02-013
**Date:** June 12–September 15, 2026
**Checked:** 2026-09-15 6:02 PM EDT
**Evidence state:** primary D.C. district-court preliminary-injunction order plus Reuters reporting of the filed appeal; four EPA reclassifications remain enjoined, with no stay or appellate merits ruling by cutoff
**Review state:** current-standard-reviewed

The administration appealed the preliminary injunction, but no stay or appellate merits decision had altered the order by cutoff.

## THE FACTS

- U.S. District Judge Beryl Howell granted California a preliminary injunction against EPA's June reclassification of four Clean Air Act section 209(b) preemption-waiver orders as rules eligible for Congressional Review Act submission.
- The September 2 order directs EPA to restore the status quo before its June 12 press release, withdraw or correct the reclassifications in public statements and stop giving them effect. It covers Advanced Clean Cars I, its reinstatement, Small Off-Road Engine amendments and 2009-and-later greenhouse-gas emission standards.
- EPA must file a compliance status report by September 21. The court denied dismissal motions by EPA and industry intervenors and expressly identified the preliminary order as appealable and effective until further court order.
- The decision concerns these four waiver reclassifications and potential future congressional review. A separate challenge to Congress's earlier disapproval of California authority for a 2035 zero-emission vehicle mandate remains pending, so this injunction does not reinstate or finally resolve every California emissions waiver.
- On September 15, the Trump administration filed an appeal seeking review of Judge Howell's preliminary injunction. The notice preserves the challenge but Reuters reported no stay or appellate merits decision by cutoff, so the district court's operative relief remained in place.

## SIGNIFICANCE

The appeal moves the dispute over whether California waiver orders can be routed through the Congressional Review Act into the D.C. Circuit while the preliminary restraint remains in place. The filing preserves the administration's challenge but does not itself suspend the district court's order or resolve the separate litigation over Congress's earlier disapproval of other California authority.

## GOALPOST / RESPONSE

EPA and industry intervenors argue that the waiver actions are reviewable rules and that Congress should be able to consider them; California says Clean Air Act waivers are adjudicatory orders, not CRA rules. The administration has now appealed. Any stay, EPA's compliance report, appellate briefing and merits decision, congressional action and the separate 2035-waiver litigation are the tests.

## MAYBE / THEREFORE

Maybe the D.C. Circuit will accept the administration's classification theory or grant a stay, or it may uphold the preliminary conclusion that EPA cannot reclassify waiver orders to trigger expedited review. Therefore the record establishes a filed appeal while the four reclassifications remain preliminarily enjoined—not an appellate reversal, a stay, final validity of every California vehicle rule or resolution of the separate congressional-disapproval case.


## SOURCES

- [U.S. District Court for the District of Columbia — California EPA-waiver preliminary-injunction order](https://oag.ca.gov/system/files/attachments/press-docs/order.pdf) — primary appealable order granting preliminary relief, restoring the pre-June status quo and staying EPA's reclassification of four waiver orders
- [Reuters — judge blocks EPA reclassification of four California emissions waivers](https://www.reuters.com/legal/litigation/us-judge-bars-epa-effort-send-california-vehicle-emissions-rules-congress-2026-09-03/) — independent reporting on the preliminary injunction, the Congressional Review Act dispute and the pending separate challenge
- [Reuters — administration appeals California EPA-waiver injunction](https://www.reuters.com/legal/government/trump-administration-appeals-ruling-blocking-epa-sending-california-auto-2026-09-15/) — independent legal reporting on the filed appeal; no stay or appellate merits ruling

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
