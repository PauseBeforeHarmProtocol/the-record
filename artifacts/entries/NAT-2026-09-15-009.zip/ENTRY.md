# House holds Leon Black in contempt and refers Epstein subpoena dispute to DOJ

**Entry ID:** NAT-2026-09-15-009
**Date:** September 15, 2026
**Checked:** 2026-09-16 5:58 PM EDT
**Evidence state:** primary committee record plus independent Reuters and Associated Press reporting; full-House contempt and referral completed, enforcement and merits outcomes pending
**Review state:** current-standard-reviewed

The completed House action advances subpoena enforcement to the Justice Department; no criminal charge, prosecution or finding of underlying Epstein-related wrongdoing existed by cutoff.

## THE FACTS

- The House of Representatives approved a resolution holding financier Leon Black in contempt of Congress for defying subpoenas in the Oversight Committee's Jeffrey Epstein investigation. Associated Press reported that the bipartisan action occurred without a formal recorded vote after the committee's earlier 41–0 recommendation.
- The House referred the contempt resolution to the Justice Department. Reuters reported that the U.S. Attorney's Office for the District of Columbia would review the referral; review is not a charging decision, prosecution, conviction or court order compelling compliance.
- The committee seeks sworn testimony and nondisclosure agreements concerning Black's relationship and financial dealings with Epstein. The contempt action establishes Congress's noncompliance finding and enforcement step, not the truth of every allegation under investigation.
- Black previously participated in a voluntary interview but declined a later deposition and disputed the document demands. His lawyers say the requested nondisclosure agreements do not exist, that he has cooperated and that the committee is abusing its authority.
- Black denies sexual abuse, trafficking, exploitation and knowledge of Epstein's crimes. Those denials and the committee's investigative theories remain unadjudicated; any prosecution would require a separate Justice Department decision and judicial process.

## SIGNIFICANCE

A bipartisan full-House contempt action is a material escalation beyond the unanimous committee recommendation and places enforcement before DOJ. Its legal consequence remains procedural unless prosecutors charge the referral or a court compels compliance; it does not prove the investigation's underlying misconduct allegations.

## GOALPOST / RESPONSE

Congress says compulsory process is necessary to obtain evidence about Epstein's network; Black says he has cooperated and cannot produce documents that do not exist. The tests are DOJ's disposition, any information or indictment, judicial review, compliance with subpoenas and independently corroborated investigative findings.

## MAYBE / THEREFORE

Maybe the referral prompts testimony or prosecution and produces material evidence, or DOJ and the courts may find the dispute unsuitable for criminal enforcement or narrower than Congress asserts. Therefore the record confirms a full-House contempt resolution and DOJ referral—not a criminal charge, conviction, compelled production or proof of Epstein-related wrongdoing.


## SOURCES

- [House Oversight Committee — bipartisan contempt recommendation for Leon Black](https://oversight.house.gov/release/oversight-committee-republicans-and-democrats-hold-leon-black-in-contempt-for-defying-lawful-subpoenas/) — primary committee announcement of the bipartisan vote and stated subpoena-enforcement basis; not a full-House contempt vote or criminal referral outcome
- [Reuters — House panel recommends contempt for Leon Black in Epstein probe](https://www.reuters.com/world/us-house-committee-recommends-contempt-congress-leon-black-epstein-probe-2026-09-15/) — independent reporting on the 41–0 committee vote, procedural status and Black's response
- [Reuters — House holds Leon Black in contempt of Congress](https://www.reuters.com/legal/government/us-house-votes-hold-billionaire-leon-black-contempt-congress-2026-09-16/) — independent congressional and legal reporting on the completed House action and DOJ referral
- [Associated Press — House contempt resolution for Leon Black](https://apnews.com/article/e556566061ce2bdf0928d46e7441853f) — independent congressional reporting on the voice vote, referral and response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
