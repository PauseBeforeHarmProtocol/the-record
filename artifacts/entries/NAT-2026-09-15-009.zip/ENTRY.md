# House panel unanimously recommends contempt for Leon Black in Epstein probe

**Entry ID:** NAT-2026-09-15-009
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:29 AM EDT
**Evidence state:** primary House Oversight Committee announcement plus Reuters reporting; 41–0 committee recommendation completed, with full-House action and any enforcement or merits findings pending
**Review state:** current-standard-reviewed

The 41–0 committee vote advanced a subpoena-enforcement resolution; the full House had not voted and no criminal contempt disposition existed by cutoff.

## THE FACTS

- The House Committee on Oversight and Government Reform voted 41–0 to recommend that the full House hold financier Leon Black in contempt of Congress for failing to comply with subpoenas in its Jeffrey Epstein investigation.
- The committee's primary announcement said it sought testimony and records concerning Black's relationship and financial dealings with Epstein. The vote establishes the committee's enforcement action and stated investigative purpose; it does not establish the truth of every allegation under investigation.
- The resolution still required action by the full House. No completed House contempt vote, Justice Department referral, prosecution, judicial enforcement order or finding that Black committed an underlying offense existed by cutoff.
- Reuters reported that Black denied sexual abuse, trafficking, exploitation and knowledge of Epstein's crimes, accused the committee of abusing its power, and asked the Office of Congressional Conduct to investigate Chairman James Comer. Those are Black's response and counter-allegations, not adjudicated findings.
- The committee described the vote as bipartisan subpoena enforcement. Whether Black produces records or testimony, whether the House acts, and whether any evidence corroborates or refutes the committee's investigative theories remain unresolved.

## SIGNIFICANCE

A unanimous committee recommendation is a material escalation in a congressional investigation with cross-party support. Its immediate consequence is procedural: it places a contempt resolution before the House, without itself creating a criminal conviction or proving misconduct beyond noncompliance alleged by the committee.

## GOALPOST / RESPONSE

The committee says compulsory process is necessary to obtain evidence about Epstein's network; Black says he has cooperated appropriately and that the committee is abusing its authority. Production of subpoenaed material, a full-House vote, any referral or enforcement action, court review and evidence-based findings are the tests.

## MAYBE / THEREFORE

Maybe the unanimous vote prompts compliance and produces material evidence, or later review may narrow the dispute and substantiate Black's objections. Therefore the record establishes a 41–0 committee recommendation based on alleged subpoena defiance—not a full-House contempt finding, criminal charge, judicial ruling or proof of underlying Epstein-related wrongdoing.


## SOURCES

- [House Oversight Committee — bipartisan contempt recommendation for Leon Black](https://oversight.house.gov/release/oversight-committee-republicans-and-democrats-hold-leon-black-in-contempt-for-defying-lawful-subpoenas/) — primary committee announcement of the bipartisan vote and stated subpoena-enforcement basis; not a full-House contempt vote or criminal referral outcome
- [Reuters — House panel recommends contempt for Leon Black in Epstein probe](https://www.reuters.com/world/us-house-committee-recommends-contempt-congress-leon-black-epstein-probe-2026-09-15/) — independent reporting on the 41–0 committee vote, procedural status and Black's response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
