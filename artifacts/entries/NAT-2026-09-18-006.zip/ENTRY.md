# First Circuit upholds protections against rapid third-country deportations

**Entry ID:** NAT-2026-09-18-006
**Date:** September 18, 2026
**Checked:** 2026-09-18 5:59 PM EDT
**Evidence state:** complete published First Circuit opinion plus independent Reuters reporting; appellate merits judgment issued, compliance and further review unresolved
**Review state:** current-standard-reviewed

The court affirmed notice, fear-screening and APA relief while vacating two declarations on standing grounds; further review remains possible.

## THE FACTS

- The U.S. Court of Appeals for the First Circuit issued its published opinion in D.V.D. v. Department of Homeland Security, No. 26-1212, largely affirming final judgment against DHS's February 18 third-country-removal guidance.
- The court upheld requirements that people receive effective notice of the destination country and a meaningful opportunity to raise a claim that they face persecution or torture there, followed by the applicable screening and agency-review process before removal.
- The panel also affirmed Administrative Procedure Act vacatur of the DHS guidance. It vacated two declarations concerning statutory priority for removal to a designated country or country of citizenship because the individual plaintiffs lacked standing for that relief; the opinion therefore was not an across-the-board affirmance of every declaration below.
- Reuters reported that the administration said the policy was needed to remove people whose home countries would not accept them. The September 18 opinion is an appellate merits ruling; any rehearing, Supreme Court review, revised guidance and compliance practice remain unresolved.

## SIGNIFICANCE

The ruling preserves procedural protections before the government sends a person to a country not named in the original removal process, while narrowing relief where the plaintiffs lacked standing. It constrains the administration's rapid-removal mechanism but does not end all third-country removals.

## GOALPOST / RESPONSE

DHS argued that flexible third-country transfers are necessary when home countries refuse return and that existing screening is lawful. Revised guidance, notice periods, fear interviews, agency review, actual transfer practices and any further appellate order are the tests.

## MAYBE / THEREFORE

Maybe DHS can continue third-country removals with constitutionally adequate notice and screening, or further litigation and operational constraints may materially limit the policy. Therefore the First Circuit affirmed most of the final judgment and APA vacatur while removing two declarations for lack of standing—not a categorical ban on every third-country removal or a final Supreme Court disposition.


## SOURCES

- [First Circuit opinion — D.V.D. v. DHS, No. 26-1212](https://www.ca1.uscourts.gov/sites/ca1/files/opnfiles/26-1212P-01A.pdf) — primary judicial opinion
- [Reuters — appeals court rejects rapid third-country deportation policy](https://www.reuters.com/world/us-appeals-court-rejects-trump-policy-allowing-fast-thirdcountry-deportations-2026-09-18/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
