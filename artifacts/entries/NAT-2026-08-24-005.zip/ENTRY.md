# USDA reopens the Douglas cattle crossing after a 15-month livestock-import suspension

**Entry ID:** NAT-2026-08-24-005
**Date:** August 24, 2026
**Checked:** 2026-08-24 5:58 PM EDT
**Evidence state:** USDA implementation schedule confirmed by Reuters and AP; price-effect claim remains prospective and independently questioned

Imports resumed under a phased disease-control plan; economists said the limited first step was unlikely to lower beef prices soon.

## THE FACTS

- USDA reopened the Douglas, Arizona, port to cattle imports from Mexico on August 24, the first easing of the southern-border livestock suspension imposed in May 2025 over New World screwworm.
- USDA said every animal would receive a full inspection and that the opening could be paused if risk increased. Santa Teresa and Columbus, New Mexico, remained under evaluation rather than open at the checked time.
- Reuters reported that imports were scheduled to begin at 700 cattle per day and rise gradually. AP reported that Mexico historically supplies about 3% of the U.S. cattle supply and cited agricultural economists who did not expect a measurable near-term effect on cattle or beef prices.

## SIGNIFICANCE

The reopening changes an implemented biosecurity and trade restriction while testing two competing risks: importing more cattle into the smallest U.S. herd in decades and preventing a destructive parasite from spreading. The staged volume means claims of quick consumer-price relief should be measured rather than assumed.

## GOALPOST / RESPONSE

Agriculture Secretary Brooke Rollins says USDA used overlapping safeguards and a science-based protocol to protect the U.S. herd while reopening trade. Some cattle groups and state officials argue the continuing screwworm spread makes reopening risky. Import volumes, detections, pauses, herd size, and retail beef prices are the evidence tests.


## SOURCES

- [USDA APHIS — phased reopening of southern livestock ports](https://www.aphis.usda.gov/news/agency-announcements/usda-announces-phased-reopening-southern-ports-livestock-trade-0) — primary agency announcement and implementation schedule
- [Reuters — cattle imports resume through Douglas, Arizona](https://www.reuters.com/world/americas/mexico-boosts-sterile-fly-dispersal-us-reopens-cattle-trade-2026-08-24/) — independent reporting on implementation, safeguards, and disease risk
- [Associated Press — economists assess the cattle reopening and beef prices](https://apnews.com/article/screwworm-beef-prices-cattle-trump-border-mexico-399cebbea159ae51a8eaa2e13eb1ef14) — independent reporting and evidence-based effectiveness context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
