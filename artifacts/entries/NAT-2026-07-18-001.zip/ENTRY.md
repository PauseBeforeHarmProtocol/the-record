# Court orders narrowed White House discovery in ABA law-firm retaliation suit

**Entry ID:** NAT-2026-07-18-001
**Date:** July 18–November 16, 2026
**Checked:** 2026-11-17 12:05 PM EST
**Evidence state:** primary 26-page D.D.C. memorandum opinion plus independent Reuters reporting; narrowed discovery granted in part, production process and privilege review pending, retaliation merits unresolved
**Review state:** current-standard-reviewed

A federal judge granted narrowed discovery requests for White House records and testimony, ordered the parties to propose search terms and a schedule, and left privilege disputes and final merits unresolved.

## THE FACTS

- The Justice Department previously disclosed subpoenas seeking detailed records and depositions from 14 major law firms that were targeted by White House executive orders or reached agreements intended to avoid those directives.
- The requests include communications related to the executive orders, Boris Epshteyn and the American Bar Association. The ABA alleges that the administration unlawfully punished firms over prior legal work, diversity policies and political ties; the government disputes that claim.
- On November 16, U.S. District Judge Amir H. Ali granted the ABA’s narrowed discovery requests 1, 2, 7, 9 and 13, found requests 3, 4, 5, 6, 11 and 12 moot, and denied requests 8, 10, 14, 15 and 16 without prejudice.
- The opinion says a discovery response may consist of production or an assertion of privilege; it did not resolve presidential-communications privilege or order public disclosure of every requested communication.
- Ali ordered the parties to meet and confer and submit proposed search terms and a production schedule by December 4. He called the government’s stay request premature while allowing a later request after specific production obligations are set.
- The White House told Reuters that an activist judge was seeking protected internal communications and said it was confident the ruling would not be the final word. That response preserves the government’s privilege and appellate objections but does not stay the order.

## SIGNIFICANCE

The ruling moves the challenge from disputes over access into court-supervised discovery of selected White House material, creating a concrete path to evidence about the law-firm campaign. It is a procedural and evidentiary development, not a merits judgment.

## GOALPOST / RESPONSE

The administration says the discovery intrudes on protected presidential communications and that the subpoenas were ordinary litigation discovery. The immediate tests are the December 4 search-and-schedule proposal, document-specific privilege assertions, any renewed stay or appeal and what admissible evidence ultimately shows about policy purpose—not the existence of discovery requests alone.

## MAYBE / THEREFORE

Maybe narrowed discovery will show routine policy and litigation deliberations protected in whole or part, or it may produce evidence supporting the ABA’s retaliation theory. Therefore the court has ordered a defined discovery process—not adjudicated retaliation, waived privilege, compelled public release of every communication or resolved the case.


## SOURCES

- [Reuters — DOJ subpoenas to 14 law firms](https://www.reuters.com/legal/government/trump-administration-discloses-subpoenas-law-firms-fight-with-us-lawyer-group-2026-07-18/) — independent reporting
- [Financial Times — Big Law braces for second fight](https://www.ft.com/content/44a3698f-6481-4e83-a50d-7db109768ea1) — independent reporting (subscription)
- [American Bar Association v. Executive Office of the President, Memorandum Opinion](https://fingfx.thomsonreuters.com/gfx/legaldocs/akpewgyglpr/American%20Bar%20v%20Executive%20Office.pdf) — court opinion
- [White House ordered to hand over records in lawsuit over Trump’s law firm crackdown](https://www.reuters.com/legal/government/white-house-ordered-hand-over-records-lawsuit-over-trumps-law-firm-crackdown-2026-11-17/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
