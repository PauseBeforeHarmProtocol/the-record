# Justice Department discloses subpoenas to 14 major law firms

**Entry ID:** NAT-2026-07-18-001
**Date:** July 18, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** corroborated reporting; underlying filings referenced but not republished here
**Review state:** current-standard-reviewed

The subpoenas were disclosed in the American Bar Association’s lawsuit challenging the administration’s law-firm pressure campaign.

## THE FACTS

- The Justice Department disclosed subpoenas seeking detailed records and depositions from 14 major law firms that were targeted by White House executive orders or reached agreements intended to avoid those directives.
- The requests include communications related to the executive orders, Boris Epshteyn, and the American Bar Association.
- The subpoenas surfaced in the ABA’s lawsuit alleging that the administration’s policy unlawfully punished firms over prior legal work, diversity policies, and political ties. Four firms previously obtained permanent court orders blocking executive orders directed at them; appeals remain pending.

## SIGNIFICANCE

This is a test of whether federal investigative and discovery power is being used neutrally in litigation or as another pressure point against institutions that represent disfavored clients or positions. The answer affects access to counsel, law-firm independence, and the government’s ability to impose political costs through contracting and security-clearance authorities.

## GOALPOST / RESPONSE

The Justice Department says the subpoenas seek information the ABA itself requested and argues that the association should obtain responsive material from its own members rather than directly from the White House. That is the government’s stated litigation rationale; it does not resolve the ABA’s retaliation claim.

## MAYBE / THEREFORE

Maybe the subpoenas are ordinary discovery aimed at obtaining ABA-requested material from the member firms that possess it, as the Justice Department says. Therefore their targets alone do not establish retaliation; the claim should turn on the requests’ scope and relevance, the underlying filings, and subsequent court rulings.


## SOURCES

- [Reuters — DOJ subpoenas to 14 law firms](https://www.reuters.com/legal/government/trump-administration-discloses-subpoenas-law-firms-fight-with-us-lawyer-group-2026-07-18/) — independent reporting
- [Financial Times — Big Law braces for second fight](https://www.ft.com/content/44a3698f-6481-4e83-a50d-7db109768ea1) — independent reporting (subscription)

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
