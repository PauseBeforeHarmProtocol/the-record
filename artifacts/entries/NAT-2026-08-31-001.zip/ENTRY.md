# Bureau of Prisons finalizes broader First Step Act time-credit eligibility

**Entry ID:** NAT-2026-08-31-001
**Date:** August 31, 2026
**Checked:** 2026-08-31 5:58 AM EDT
**Evidence state:** published Bureau of Prisons interim final rule with operative text, effective date, cited statutes and case-law explanation; rule finalized for publication, implementation and individual outcomes pending
**Review state:** current-standard-reviewed

An interim final rule expands when eligible prisoners may begin earning credits and preserves eligibility for some transferred foreign sentences; it is published but does not take effect until September 30.

## THE FACTS

- The Bureau of Prisons published an interim final rule revising two provisions of its First Step Act time-credit regulations. The rule is scheduled to take effect September 30, 2026, and BOP is accepting comments through that date.
- The rule removes language that had tied the start of credit earning to arrival or voluntary surrender at the designated Bureau facility. The revised text says an eligible inmate begins earning credits after the term of imprisonment commences, which BOP says aligns the regulation with the statute, 18 U.S.C. 3585(a), and recent court decisions finding the prior language too restrictive.
- The rule also clarifies that the bar on applying credits for convictions under non-U.S.-Code law does not exclude people serving foreign-country sentences when the U.S. Parole Commission has determined an equivalent U.S.-Code sentence under 18 U.S.C. 4106A. It separately preserves application of credits authorized by the D.C. Code.
- BOP describes both changes as beneficial expansions and says the foreign-sentence treatment codifies an existing practice. Publication establishes the regulatory change; it does not establish how many people will receive additional credits, whether individual release dates will change, or how BOP will handle earlier credit calculations.

## SIGNIFICANCE

First Step Act credits can move eligible federal prisoners into prerelease custody or supervised release sooner. The rule removes one regulatory restriction that courts had rejected and clarifies access for a narrow transferred-sentence group, but its practical reach depends on BOP calculations and individual eligibility.

## GOALPOST / RESPONSE

BOP says the changes follow the best reading of the statute, conform to case law, and expand benefits without significant controversy. The strongest remaining questions concern retroactive calculations, program participation records, excluded offenses, administrative appeals, and whether the September 30 implementation changes actual custody or supervision dates. Published guidance, recalculation notices, litigation and aggregate release data are the tests.

## MAYBE / THEREFORE

Maybe the rule will primarily codify court-mandated and existing practices, producing limited additional change, or it may materially advance credits for some prisoners whose earning start was delayed. Therefore the record treats the revisions as a published interim final rule with a future effective date—not as proof that any named person has been released or that every eligible prisoner's credits have already been recalculated.


## SOURCES

- [Federal Register — First Step Act Time Credits—Revisions](https://www.federalregister.gov/documents/2026/08/31/2026-17752/first-step-act-time-credits-revisions) — primary interim final rule with operative text, effective date, comment period and case-law explanation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
