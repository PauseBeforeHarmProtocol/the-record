# Trump threatens to immediately double Mexico tariffs if migrant convoy is not stopped

**Entry ID:** NAT-2026-11-12-006
**Date:** November 12, 2026
**Checked:** 2026-11-12 12:11 PM EST
**Evidence state:** Trump Truth Social statement plus independent Reuters and Associated Press reporting and named Mexican response; threat announced, with convoy facts contested and no implementing tariff instrument located
**Review state:** current-standard-reviewed

The president announced a conditional tariff escalation but published no implementing instrument, rate schedule or legal authority; Mexico disputed the border-risk premise.

## THE FACTS

- At 7:04 a.m. EST on November 12, Trump published a Truth Social post saying tariffs on Mexico would be immediately doubled if Mexico did not stop migrant caravans moving north. The post establishes that he made the conditional threat; it does not independently verify the convoy claims or implement a tariff.
- Reuters reported that about 1,500 people, mostly from Central America, had left Tapachula and that Homeland Security Secretary Markwayne Mullin said the United States would use all available resources to secure the border. No presidential proclamation, Federal Register notice, Customs instruction, product list, new rate, effective date or invoked tariff authority was located by cutoff, so the archive records an announced threat rather than an ordered or implemented tariff change.
- Mexican President Claudia Sheinbaum said no caravan had reached the U.S. border since Trump returned to office and that Mexico was working to return migrants without repression. Associated Press reported that the current group had fallen to roughly 600 and was largely dispersing. Those named accounts directly contest the urgency and scale asserted in Trump's post but do not establish the final movement of every participant.
- The threat came while the countries were negotiating trade arrangements after Trump declined to extend the U.S.-Mexico-Canada Agreement, Reuters reported. The statement raises immediate trade-policy risk, but no completed change in customs treatment, migration flow, consumer prices or negotiations was measured by cutoff.

## SIGNIFICANCE

Conditioning a major trade escalation on Mexico's handling of a moving group of migrants links tariff policy to an asserted border emergency without a published instrument or measurable trigger. Even unimplemented, the threat can affect bilateral negotiations and business expectations; the actual legal and economic effects remain contingent.

## GOALPOST / RESPONSE

Trump says Mexico must stop the convoy or tariffs will double; Sheinbaum says no caravan has reached the border and the current group is dispersing. The tests are a signed tariff instrument, stated authority, covered products and rates, Customs implementation, verified convoy location and size, Mexico's actions, bilateral negotiating records and measured trade, price and migration outcomes.

## MAYBE / THEREFORE

Maybe the threat prompts faster Mexican action without tariffs, or it may be reversible leverage based on a convoy that never reaches the border. Therefore the archive records a material presidential tariff threat and named counterevidence—not an implemented duty increase, verified border breach, completed deportation measure or proven economic result.


## SOURCES

- [Donald J. Trump / Truth Social — conditional threat to double Mexico tariffs](https://truthsocial.com/@realDonaldTrump/117603372250841698) — primary evidence that Trump published the threat; claims inside are not independently verified
- [Reuters — Trump threatens to double tariffs on Mexico over migrant convoy](https://www.reuters.com/world/us/trump-threatens-double-tariffs-mexico-if-it-does-not-halt-migrants-2026-11-12/) — independent reporting on the presidential threat, convoy and administration response
- [Associated Press — Sheinbaum disputes border-caravan premise and describes dispersal](https://apnews.com/article/mexico-us-sheinbaum-trump-d9829fe92a0ce9afecb909cb35a2977d) — independent reporting and named Mexican government response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
