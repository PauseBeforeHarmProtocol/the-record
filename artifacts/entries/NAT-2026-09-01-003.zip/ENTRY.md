# OMB board raises federal contract-cost thresholds and rescinds CAS 407

**Entry ID:** NAT-2026-09-01-003
**Date:** September 1, 2026
**Checked:** 2026-09-01 6:04 AM EDT
**Evidence state:** two primary coordinated Cost Accounting Standards Board final rules with thresholds, rationale, comments and October 1 effective date; rules finalized, contract-level effects and outcomes pending
**Review state:** current-standard-reviewed

Two coordinated final rules reduce Cost Accounting Standards coverage and disclosure requirements and remove a standard governing direct-material and labor cost methods, effective October 1.

## THE FACTS

- The Office of Management and Budget's Cost Accounting Standards Board issued two coordinated final rules scheduled to take effect October 1, 2026.
- The first raises the basic Cost Accounting Standards applicability threshold from $2.5 million to $35 million, eliminates the $7.5 million trigger, doubles the threshold for full CAS coverage and a Disclosure Statement from $50 million to $100 million, and raises a waiver-authority threshold to $100 million.
- The second rescinds CAS 407, which governed the use of standard costs for direct materials and direct labor. The Board said generally accepted accounting principles and remaining Cost Accounting Standards now provide sufficient coverage and that the rescission does not require contractors to change compliant practices.
- The Board described both rules as deregulatory measures intended to reduce administrative burden and align the system with modern accounting. Public comments generally supported the threshold changes, while one commenter raised concern that rescinding CAS 407 could permit inconsistent practice changes; the Board rejected that interpretation.
- The rules alter future federal contract-cost oversight. They do not retroactively change every existing contract, quantify savings, prove reduced competition or establish that cost misallocation will increase or decrease.

## SIGNIFICANCE

The much higher thresholds will exempt more federal contracts and contractors from specialized cost-accounting coverage and disclosure, while CAS 407's rescission shifts reliance to other standards and GAAP. That may lower entry and compliance costs, but it also reduces a layer of uniform federal oversight for affected awards.

## GOALPOST / RESPONSE

The Board says the package modernizes outdated requirements, reduces burden and preserves necessary cost-accounting coverage through GAAP and other standards. The countervailing concern is whether fewer disclosures and one fewer specific standard make inconsistent allocation or oversight gaps harder to detect. Contract coverage data, entrant and competition measures, contractor compliance costs, audit findings, questioned costs, disputes and procurement outcomes are the tests.

## MAYBE / THEREFORE

Maybe the higher thresholds and CAS 407 rescission will remove expensive duplication without weakening cost integrity, or reduced standardized coverage may create gaps that surface later in audits and disputes. Therefore the record confirms two final rules effective October 1—not realized savings, increased competition, weaker accounting in any named contract or a measured change in federal procurement value.


## SOURCES

- [Federal Register — Cost Accounting Standards threshold final rule](https://www.federalregister.gov/documents/2026/09/01/2026-17901/increase-of-monetary-thresholds-and-other-matters-related-to-cost-accounting-standards-program) — primary final rule raising Cost Accounting Standards coverage, disclosure and waiver thresholds effective October 1
- [Federal Register — Cost Accounting Standard 407 rescission](https://www.federalregister.gov/documents/2026/09/01/2026-17903/conformance-of-cost-accounting-standards-to-generally-accepted-accounting-principles-for-cas-407-use) — primary coordinated final rule rescinding CAS 407 after the Board found generally accepted accounting principles and remaining standards sufficient

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
