# DOJ reportedly investigates Corey Lewandowski after DHS watchdog referral

**Entry ID:** NAT-2026-10-22-007
**Date:** October 22, 2026
**Checked:** 2026-10-23 6:03 AM EDT
**Evidence state:** Independent Reuters, Washington Post and CBS reporting, with AP documenting the administration response; investigation reported, no public charge or finding
**Review state:** current-standard-reviewed

Reuters, The Washington Post and CBS independently reported a criminal investigation concerning Lewandowski's handling of government contracts; no charge, subpoena or finding of wrongdoing was reported.

## THE FACTS

- Reuters, The Washington Post and CBS News independently reported, citing separate sets of unnamed sources, that the Department of Homeland Security inspector general made a criminal referral and that the Justice Department was investigating Trump adviser Corey Lewandowski's handling of government contracts.
- The inspected reports described an investigation, not a criminal charge or adjudicated finding. Reuters reported that investigators had not issued subpoenas or other legal demands at publication, and CBS reported that Lewandowski had not been charged.
- Lewandowski's attorney denied wrongdoing and called the allegations baseless. The Washington Post reported that a DHS inspector-general spokesperson declined comment, while DOJ declined or did not provide comment to the outlets.
- President Trump said he had heard something about the matter but did not know the specifics, and said he would not stop a prosecution if Lewandowski had been dishonest. That response did not independently confirm the reported referral's factual allegations.

## SIGNIFICANCE

A reported criminal investigation involving a senior presidential adviser and government-contract handling is a material oversight development, while the absence of public process or findings sharply limits what can responsibly be concluded.

## GOALPOST / RESPONSE

Lewandowski's counsel says he did nothing wrong, and Trump says dishonesty should be prosecuted. The tests are a disclosed referral or court filing, compulsory process, charges, declination or inspector-general finding—not anonymous-source reporting alone.

## MAYBE / THEREFORE

Maybe investigators will find procurement misconduct, or the referral may not produce charges or substantiated findings. Therefore the supported conclusion is that multiple independent outlets reported an active criminal investigation—not that Lewandowski committed a crime.


## SOURCES

- [Reuters — DOJ investigating Trump adviser Corey Lewandowski, sources say](https://www.reuters.com/legal/government/trump-ally-lewandowski-faces-criminal-investigation-over-dhs-tenure-sources-say-2026-10-23/) — independent reporting based on four unnamed sources with responses from Trump and Lewandowski
- [Washington Post — Justice Dept. investigating Corey Lewandowski, people familiar say](https://www.washingtonpost.com/national-security/2026/10/22/doj-reviewing-accusations-contracting-misconduct-involving-corey-lewandowski/) — independent reporting based on four unnamed sources with attorney and agency responses
- [CBS News — DOJ investigating Corey Lewandowski after DHS watchdog referral](https://www.cbsnews.com/news/doj-corey-lewandowski-dhs-investigation/) — independent reporting based on two unnamed sources with attorney response
- [Associated Press — Trump responds to reported Lewandowski investigation](https://apnews.com/article/trump-justice-department-investigation-lewandowski-corey-homeland-security-1639485a611f2fc6be06ed35d6628416) — independent reporting documenting the president's response and counsel's denial

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
