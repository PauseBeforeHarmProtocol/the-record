# Fed watchdog finds renovation failures but no criminal or administrative misconduct

**Entry ID:** NAT-2026-09-30-002
**Date:** September 30, 2026
**Checked:** 2026-09-30 6:04 PM EDT
**Evidence state:** primary Federal Reserve inspector-general report and official summary, independent Reuters reporting, and Trump's retained Truth Social post for what he published; report issued and recommendations accepted, legal threats not implemented
**Review state:** current-standard-reviewed

The inspector general documented more than $1 billion in cost growth and deficient contracting and oversight; Trump responded by demanding Jerome Powell's resignation and threatening litigation, but no case or removal action existed by cutoff.

## THE FACTS

- In a report dated September 29 and publicly released September 30, the Federal Reserve inspector general said the combined Eccles Building and 1951 Constitution Avenue renovation budget rose from $1.317 billion in February 2020 to $2.381 billion in December 2024. The construction portion rose from $921 million to $2.018 billion.
- The inspector general found no reasonable grounds for a criminal referral and no administrative misconduct. It nevertheless found ineffective execution of the construction-manager-at-risk contract, inadequate governance and reporting, and other deficiencies; by July 2026 the Board had awarded more than $2 billion in construction work without a guaranteed maximum price.
- The report made seven recommendations. The Federal Reserve Board concurred, and Chair Kevin Warsh said the Board accepted them and would pursue an independent audit and stronger oversight.
- Trump cited the report in a September 30 Truth Social post, called for former chair Jerome Powell to resign, said he had asked Attorney General Todd Blanche to study the report and determine what to do, and threatened a federal lawsuit. Reuters reported that the U.S. attorney's office in Washington was reviewing the report.
- No criminal referral, charge, filed civil suit or completed removal action against Powell was identified by the cutoff. Trump's post is evidence of the demand and threatened legal response, not independent proof of the post's accusations.

## SIGNIFICANCE

The watchdog substantiated major procurement and governance failures in a politically charged Federal Reserve project while finding no reasonable grounds for a criminal referral or administrative misconduct. The president's renewed legal pressure on a former central-bank chair creates a separate institutional-independence risk that must not be confused with a filed case.

## GOALPOST / RESPONSE

The administration says the cost growth and contracting failures warrant accountability, further Justice Department review and potentially litigation. The strongest response is that the independent inspector general found serious management defects but no reasonable grounds for a criminal referral or administrative misconduct. Implementation of the seven recommendations, audit results, final project cost and schedule, and any signed complaint, charge or lawful removal process are the tests.

## MAYBE / THEREFORE

Maybe the inspector general's recommendations and an independent audit will correct genuine procurement failures, or the report may be used to intensify pressure on central-bank officials beyond what its findings support. Therefore the record establishes documented cost growth, governance failures and a presidential legal threat—not criminal wrongdoing, a filed government lawsuit or Powell's removal.


## SOURCES

- [Federal Reserve OIG — Board building-renovation cost and management review](https://oig.federalreserve.gov/reports/board-eccles-1951-renovation-construction-costs-sep2026.htm) — primary inspector-general report, findings and recommendations
- [Reuters — Fed watchdog finds renovation deficiencies but no misconduct](https://www.reuters.com/world/us/watchdog-finds-deficiencies-no-fed-misconduct-powell-era-renovation-project-2026-09-30/) — independent reporting on inspector-general findings and administration response
- [Donald Trump on Truth Social — Powell resignation and lawsuit demand](https://truthsocial.com/@realDonaldTrump/117361716972225267) — primary evidence that Trump published the statement; claims inside are not independently verified

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
