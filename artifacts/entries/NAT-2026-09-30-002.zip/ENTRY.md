# Fed watchdog finds renovation failures; DOJ says Powell probe will not reopen

**Entry ID:** NAT-2026-09-30-002
**Date:** September 30–October 2, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** primary inspector-general findings and retained presidential statement; Reuters confirmation from a DOJ spokesperson plus Bloomberg’s named attorney-general interview; probe not reopening as stated October 2, future inquiry conditional on new evidence
**Review state:** current-standard-reviewed

The inspector general found major procurement defects but no criminal or administrative misconduct. DOJ says it is not reopening the Powell criminal probe, while leaving future action conditional on new evidence.

## THE FACTS

- In a report dated September 29 and publicly released September 30, the Federal Reserve inspector general said the combined Eccles Building and 1951 Constitution Avenue renovation budget rose from $1.317 billion in February 2020 to $2.381 billion in December 2024. The construction portion rose from $921 million to $2.018 billion.
- The inspector general found no reasonable grounds for a criminal referral and no administrative misconduct. It nevertheless found ineffective execution of the construction-manager-at-risk contract, inadequate governance and reporting, and other deficiencies; by July 2026 the Board had awarded more than $2 billion in construction work without a guaranteed maximum price.
- The report made seven recommendations. The Federal Reserve Board concurred, and Chair Kevin Warsh said the Board accepted them and would pursue an independent audit and stronger oversight.
- Trump cited the report in a September 30 Truth Social post, called for former chair Jerome Powell to resign, said he had asked Attorney General Todd Blanche to study the report and determine what to do, and threatened a federal lawsuit. Reuters reported that the U.S. attorney's office in Washington was reviewing the report.
- On October 2, a Justice Department spokesperson told Reuters that DOJ was not reopening the criminal investigation into Powell over the building renovation. Attorney General Todd Blanche separately told Bloomberg that the department was not reopening a criminal investigation into him.
- Blanche left any future inquiry conditional on evidence of criminal wrongdoing emerging from a new review. Reuters reported that Fed Chair Kevin Warsh had said he would hire an independent auditor to verify project costs and compliance.

## SIGNIFICANCE

The watchdog documented serious management failures while finding no basis for a criminal referral. DOJ’s subsequent statement limits the immediate criminal escalation of Trump’s threat, but a planned audit and conditional future action leave institutional-independence and procurement-accountability questions open.

## GOALPOST / RESPONSE

The administration says genuine cost and oversight failures warrant accountability and further review. DOJ now says it is not reopening the criminal probe, while Blanche leaves later action dependent on new evidence. The strongest counterweight remains the inspector general’s no-misconduct finding; audit evidence, implementation of recommendations and any actual charge or filed claim are the tests.

## MAYBE / THEREFORE

Maybe an independent audit produces new material evidence or corrects procurement failures; its mere commissioning could also prolong political pressure without substantiating wrongdoing. Therefore the record establishes watchdog-documented management failures and DOJ’s stated decision not to reopen the Powell criminal probe, with any later investigation conditional rather than accomplished.


## SOURCES

- [Federal Reserve OIG — Board building-renovation cost and management review](https://oig.federalreserve.gov/reports/board-eccles-1951-renovation-construction-costs-sep2026.htm) — primary inspector-general report, findings and recommendations
- [Reuters — Fed watchdog finds renovation deficiencies but no misconduct](https://www.reuters.com/world/us/watchdog-finds-deficiencies-no-fed-misconduct-powell-era-renovation-project-2026-09-30/) — independent reporting on inspector-general findings and administration response
- [Donald Trump on Truth Social — Powell resignation and lawsuit demand](https://truthsocial.com/@realDonaldTrump/117361716972225267) — primary evidence that Trump published the statement; claims inside are not independently verified
- [Reuters — DOJ will not reopen criminal probe into Powell](https://www.investing.com/news/general-news/blanche-says-doj-is-not-reopening-criminal-probe-into-feds-powell-bloomberg-news-reports-4930341) — independent reporting quoting DOJ spokesperson; conditional future inquiry
- [Bloomberg — Blanche says DOJ not reopening Powell probe](https://news.bloomberglaw.com/banking-law/doj-not-reopening-criminal-probe-into-feds-powell-blanche-says) — named attorney-general interview and independent reporting; excerpt retrieved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
