# USDA proposes narrowing SNAP categorical eligibility

**Entry ID:** NAT-2026-11-10-001
**Date:** November 10, 2026
**Checked:** 2026-11-10 12:07 PM EST
**Evidence state:** primary USDA proposed rule and regulatory impact analysis, OIRA rulemaking record and independent Reuters reporting; proposal and agency projections verified, with finalization, implementation and measured effects unresolved
**Review state:** current-standard-reviewed

The economically significant proposal would require qualifying TANF assistance and estimates 6.3 million people would lose SNAP at full effect; it is not final or implemented.

## THE FACTS

- On November 10, USDA's Food and Nutrition Administration published a proposed rule, RIN 0584-AF10, that would limit SNAP categorical eligibility to households receiving TANF assistance as defined at 45 C.F.R. § 260.31. The agency invited written comments for 30 days. This is a proposal, not a final rule or implemented eligibility change.
- USDA's regulatory impact analysis estimates that at full effect in fiscal year 2029, 3.2 million households containing 6.3 million people—17.6% of SNAP participants—would no longer receive SNAP because their income or resources exceed federal statutory limits. It estimates $44.649 billion less in federal SNAP transfers over fiscal years 2027 through 2031. These are agency projections, not measured removals or savings.
- The proposal also estimates that about 1.78 million children would lose automatic eligibility for free school meals. USDA projects about 97% would remain eligible for free or reduced-price meals through income-based certification, including about 1.66 million retaining free meals, 93,000 moving to reduced-price meals and 28,000 paying full price. Those are projected eligibility pathways, not completed school-meal losses.
- USDA says broad-based categorical eligibility created inconsistent state standards and extended benefits beyond congressionally established income and resource limits; it frames the proposal as preserving benefits for households that qualify under federal standards. Reuters reported Representative Angie Craig, the House Agriculture Committee's ranking Democrat, said the proposal would make it harder to meet basic needs and undo administrative streamlining.

## SIGNIFICANCE

If finalized substantially as proposed, the rule would materially contract SNAP eligibility, reduce federal transfers and require millions of households and school-meal applicants to pass separate income and resource tests. The scale is projected by USDA, while final scope, timing, state administration and actual household outcomes remain unresolved.

## GOALPOST / RESPONSE

USDA says the proposal restores consistent statutory limits, program integrity and targeting to needy households; opponents argue categorical eligibility reduces paperwork and supports food access. The tests are final-rule text, effective and transition dates, litigation, state implementation, administrative burden, participation, food insecurity and school-meal outcomes.

## MAYBE / THEREFORE

Maybe individualized eligibility checks better target benefits while most affected children retain meal assistance through other certification, or added applications and tighter resource limits may cause eligible households to lose access. Therefore the record establishes an economically significant proposal and USDA's modeled effects—not a final rule, 6.3 million completed terminations, $44.649 billion realized savings or measured nutrition outcomes.


## SOURCES

- [USDA FNA — Proposed rule reforming SNAP categorical eligibility (RIN 0584-AF10)](https://www.federalregister.gov/d/2026-22936) — primary Federal Register proposed rule and regulatory impact analysis
- [OIRA — Unified Agenda record for SNAP categorical-eligibility proposal](https://www.reginfo.gov/public/do/eAgendaViewRule?RIN=0584-AF10&pubId=202510) — primary federal rulemaking status and significance record
- [Reuters — USDA proposes narrower SNAP categorical eligibility](https://www.reuters.com/world/us/trump-administration-moves-cut-food-stamps-63-million-people-2026-11-10/) — independent reporting on proposed rule, agency estimates and response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
