# Supreme Court temporarily restores third-country removals pending appeal

**Entry ID:** NAT-2026-09-23-004
**Date:** September 23–29, 2026
**Checked:** 2026-09-29 5:56 PM EDT
**Evidence state:** interim Supreme Court stay and granted review documented by Reuters and Associated Press, with the earlier appellate posture preserved; removals may resume pending appeal, merits and implementation outcomes unresolved
**Review state:** current-standard-reviewed

The justices stayed the procedural judgment and agreed to hear the dispute; removals may resume for now, but the order is not a merits ruling.

## THE FACTS

- The First Circuit dissolved its stay on September 23, allowing a district-court judgment to require meaningful notice and an opportunity to raise persecution or torture claims before removal to a country not named in a person's original order. The judgment regulates process rather than categorically prohibiting every third-country removal.
- The administration filed an emergency Supreme Court application on September 24, arguing that the judgment interfered with executive removal authority and had forced cancellation of planned removals. Filing the application did not itself suspend the judgment.
- On September 29, the Supreme Court granted the administration's stay application, allowing the government to resume third-country removals while appellate proceedings continue. Six justices formed the majority and the three liberal justices dissented, according to Reuters and Associated Press.
- The Court also agreed to hear the dispute, with argument expected in December. The interim order does not decide whether the administration's notice and screening procedures ultimately satisfy statutory or constitutional requirements.
- Attorney General Todd Blanche called third-country removal an essential enforcement tool. Migrant advocates argue meaningful notice and screening are required to prevent removal to persecution or torture. Published DHS procedures, adjudicated protection claims, completed later removals and the eventual merits decision remain the tests.

## SIGNIFICANCE

The stay changes the policy's immediate legal effect: removals may resume while the Court considers the dispute. It does not resolve the governing procedural protections or validate every destination and removal decision.

## GOALPOST / RESPONSE

The administration says lower-court procedures improperly restrict lawful executive removal authority; migrant advocates say individualized notice and a meaningful chance to seek protection are essential. The Supreme Court's merits ruling, published DHS procedures, protection-claim outcomes and documented removals are the tests.

## MAYBE / THEREFORE

Maybe the Court will uphold a broader executive power to use third countries, or it may ultimately require stronger notice and screening safeguards. Therefore the administration obtained temporary relief and review—not a merits judgment, a categorical approval of every removal or proof that every destination is safe.


## SOURCES

- [Reuters — administration files emergency Supreme Court request in third-country removal case](https://www.reuters.com/world/us-seek-supreme-court-relief-after-court-blocked-third-country-removals-blanche-2026-09-24/) — independent legal reporting on the appellate stay dissolution, reported flight consequence and filed emergency Supreme Court application
- [Associated Press — district court rules third-country removal policy unlawful](https://apnews.com/article/148cee2906dc7286b074116d3eec6fd4) — independent legal reporting on the district-court judgment and procedural requirements
- [Reuters — Supreme Court permits third-country removals pending appeal](https://www.reuters.com/world/supreme-court-lets-trump-resume-third-country-deportations-2026-09-29/) — independent legal reporting on an interim Supreme Court order and granted review
- [AP — Supreme Court lets administration resume third-country removals](https://apnews.com/article/2219c35c065eab4b0690058d81bd787a) — independent legal reporting on an interim Supreme Court order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
