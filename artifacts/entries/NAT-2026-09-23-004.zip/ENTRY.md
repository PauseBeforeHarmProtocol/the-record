# Appeals court lets ruling against third-country removal policy take effect

**Entry ID:** NAT-2026-09-23-004
**Date:** September 23–24, 2026
**Checked:** 2026-09-24 12:00 PM EDT
**Evidence state:** Reuters legal reporting on the First Circuit stay dissolution, prior appellate disposition, lawyers' reported flight consequence and the attorney general's announced Supreme Court response, plus Associated Press reporting on the corrected February district-court stage; appellate restriction documented, complete order not independently retrieved and Supreme Court action unresolved
**Review state:** current-standard-reviewed

The First Circuit dissolved its stay of a judgment requiring meaningful notice and a chance to raise persecution or torture claims before third-country removal; the administration announced, but had not filed, a Supreme Court request by cutoff.

## THE FACTS

- The U.S. Court of Appeals for the First Circuit dissolved a stay on September 23, allowing a district-court judgment against the administration's third-country removal policy to take effect. Reuters reported that the appellate court had largely upheld the judgment the preceding Friday.
- The underlying judgment requires the government to provide meaningful notice and an opportunity for people to raise claims that removal to a country not named in their original order would expose them to persecution or torture. The ruling constrains procedure; it does not categorically prohibit every third-country removal.
- Lawyers for affected migrants said the stay's dissolution blocked a September 24 flight to Burundi, Rwanda and the Central African Republic. Reuters reported that consequence from counsel; no passenger manifest, agency cancellation notice or completed transfer was independently inspected.
- Attorney General Todd Blanche said the administration would seek emergency relief from the Supreme Court and argued that the ruling interfered with executive removal authority. No Supreme Court application, stay, merits ruling or authorization for the planned flight existed by cutoff.
- The appellate stage is distinct from the February district-court judgment and from separately recorded completed transfers to third countries. Future notice procedures, Supreme Court action and actual removals remain unresolved.

## SIGNIFICANCE

The stay dissolution makes enforceable a procedural safeguard against sending people to countries where they claim they face persecution or torture, immediately affecting a planned removal flight. Its durability depends on Supreme Court review and on how DHS implements notice and screening requirements.

## GOALPOST / RESPONSE

The administration argues that the courts are improperly restricting lawful executive removal authority and announced a Supreme Court challenge; migrant counsel says meaningful process is required to prevent torture or persecution. A filed application, Supreme Court order, published DHS procedures, notice records, adjudicated protection claims and documented later removals are the tests.

## MAYBE / THEREFORE

Maybe the ruling will produce workable screening without ending lawful third-country removals, or emergency review may narrow or stay the requirements. Therefore the First Circuit let the district-court judgment take effect and a planned flight was reported blocked—not a permanent Supreme Court resolution, categorical ban on third-country removal or finding that every destination is unsafe.


## SOURCES

- [Reuters — First Circuit lets third-country removal ruling take effect](https://www.reuters.com/world/us-seek-supreme-court-relief-after-court-blocked-third-country-removals-blanche-2026-09-24/) — independent legal reporting on the appellate stay dissolution, reported flight consequence and announced Supreme Court response
- [Associated Press — district court rules third-country removal policy unlawful](https://apnews.com/article/148cee2906dc7286b074116d3eec6fd4) — independent legal reporting on the district-court judgment and procedural requirements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
