# Appeals court lets ruling against third-country removal policy take effect

**Entry ID:** NAT-2026-09-23-004
**Date:** September 23–24, 2026
**Checked:** 2026-09-24 6:02 PM EDT
**Evidence state:** Reuters legal reporting on the First Circuit stay dissolution, reported flight consequence and filed emergency Supreme Court application, plus Associated Press reporting on the corrected February district-court stage; appellate restriction and application documented, complete application not independently retrieved and Supreme Court action unresolved
**Review state:** current-standard-reviewed

The administration filed an emergency Supreme Court application to stay the judgment requiring meaningful notice and a chance to raise persecution or torture claims; the Court had not acted by cutoff.

## THE FACTS

- The U.S. Court of Appeals for the First Circuit dissolved a stay on September 23, allowing a district-court judgment against the administration's third-country removal policy to take effect. Reuters reported that the appellate court had largely upheld the judgment the preceding Friday.
- The underlying judgment requires the government to provide meaningful notice and an opportunity for people to raise claims that removal to a country not named in their original order would expose them to persecution or torture. The ruling constrains procedure; it does not categorically prohibit every third-country removal.
- Lawyers for affected migrants said the stay's dissolution blocked a September 24 flight to Burundi, Rwanda and the Central African Republic. Reuters reported that consequence from counsel; no passenger manifest, agency cancellation notice or completed transfer was independently inspected.
- Attorney General Todd Blanche initially said the administration would seek emergency relief from the Supreme Court and argued that the ruling interfered with executive removal authority.
- Later September 24, the administration filed an emergency Supreme Court application asking the justices to stay the district-court judgment while its appeal proceeds. Reuters reported that the filing says the ruling forced cancellation of planned removals and calls third-country removal an essential tool. The application is a filed request, not a Supreme Court stay, merits ruling or authorization for any canceled flight.
- The appellate and Supreme Court stages are distinct from the February district-court judgment and from separately recorded completed transfers to third countries. Published notice procedures, Supreme Court action, protection-claim outcomes and actual later removals remain unresolved.

## SIGNIFICANCE

The enforceable procedural safeguard has already affected planned removals, and the filed emergency application puts its immediate durability before the Supreme Court. The filing changes the litigation posture but does not itself suspend notice and screening requirements.

## GOALPOST / RESPONSE

The administration argues that the courts are improperly restricting lawful executive removal authority and says the judgment has forced flight cancellations; migrant counsel says meaningful process is required to prevent torture or persecution. A Supreme Court order, published DHS procedures, notice records, adjudicated protection claims and documented later removals are the tests.

## MAYBE / THEREFORE

Maybe the Supreme Court will stay or narrow the requirements, or it may leave the procedural judgment in force while appeals continue. Therefore the administration filed an emergency application after the First Circuit let the judgment take effect—not a Supreme Court stay, permanent resolution, categorical ban on third-country removal or finding that every destination is unsafe.


## SOURCES

- [Reuters — administration files emergency Supreme Court request in third-country removal case](https://www.reuters.com/world/us-seek-supreme-court-relief-after-court-blocked-third-country-removals-blanche-2026-09-24/) — independent legal reporting on the appellate stay dissolution, reported flight consequence and filed emergency Supreme Court application
- [Associated Press — district court rules third-country removal policy unlawful](https://apnews.com/article/148cee2906dc7286b074116d3eec6fd4) — independent legal reporting on the district-court judgment and procedural requirements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
