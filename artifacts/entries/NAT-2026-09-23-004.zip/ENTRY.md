# Judge orders return of man sent to Equatorial Guinea without protection process

**Entry ID:** NAT-2026-09-23-004
**Date:** September 23–October 6, 2026
**Checked:** 2026-10-09 12:03 AM EDT
**Evidence state:** primary district-court final order plus independent Reuters reporting; constitutional violation and return directive ordered in one case, implementation and appellate status unresolved
**Review state:** current-standard-reviewed

A case-specific final order requires DHS to facilitate Ahmed Soliman's release and return after finding his third-country removal unconstitutional; the government has not yet completed the return and may appeal.

## THE FACTS

- The First Circuit dissolved its stay on September 23, allowing a district-court judgment to require meaningful notice and an opportunity to raise persecution or torture claims before removal to a country not named in a person's original order. The judgment regulates process rather than categorically prohibiting every third-country removal.
- The administration filed an emergency Supreme Court application on September 24, arguing that the judgment interfered with executive removal authority and had forced cancellation of planned removals. Filing the application did not itself suspend the judgment.
- On September 29, the Supreme Court granted the administration's stay application, allowing the government to resume third-country removals while appellate proceedings continue. Six justices formed the majority and the three liberal justices dissented, according to Reuters and Associated Press.
- The Court also agreed to hear the dispute, with argument expected in December. The interim order does not decide whether the administration's notice and screening procedures ultimately satisfy statutory or constitutional requirements.
- Attorney General Todd Blanche called third-country removal an essential enforcement tool. Migrant advocates argue meaningful notice and screening are required to prevent removal to persecution or torture. Published DHS procedures, adjudicated protection claims, completed later removals and the eventual merits decision remain the tests.
- In a final order dated October 6, U.S. District Judge John C. Hinderaker directed DHS to facilitate Ahmed Soliman's release from custody in Equatorial Guinea and return to the United States. The order concerns one person's removal and does not itself impose a nationwide rule.
- The court found that DHS removed Soliman without notice or an opportunity to raise fear of torture or persecution in Equatorial Guinea, violating due process. It ordered status reports while return efforts proceed and barred another third-country removal without meaningful notice and an opportunity to present claims to a neutral decision-maker.
- The government argued that the Supreme Court's interim order in the broader third-country-removal litigation foreclosed relief and that a return directive intruded on foreign affairs. Hinderaker rejected those arguments. DHS did not immediately comment to Reuters; implementation, appeal and Soliman's actual return remained unresolved at cutoff.

## SIGNIFICANCE

The order demonstrates that the Supreme Court's interim relief does not automatically validate each removal and that case-specific due-process violations can produce affirmative return relief. Its reach is limited to Soliman unless adopted more broadly on appeal or in the Supreme Court case.

## GOALPOST / RESPONSE

The administration says third-country removals are an essential lawful tool and argues courts should not direct diplomatic return efforts; Soliman's lawyers say he was removed without the required chance to seek protection. Compliance reports, actual release and return, any stay or appeal, published DHS procedures and the Supreme Court's merits ruling are the tests.

## MAYBE / THEREFORE

Maybe the government will secure Soliman's prompt return while preserving the broader program, or appellate review may narrow or reverse the relief. Therefore a federal judge entered a case-specific final order finding unconstitutional process and directing facilitation of return—not proof that return is complete or that all third-country removals are unlawful.


## SOURCES

- [Reuters — administration files emergency Supreme Court request in third-country removal case](https://www.reuters.com/world/us-seek-supreme-court-relief-after-court-blocked-third-country-removals-blanche-2026-09-24/) — independent legal reporting on the appellate stay dissolution, reported flight consequence and filed emergency Supreme Court application
- [Associated Press — district court rules third-country removal policy unlawful](https://apnews.com/article/148cee2906dc7286b074116d3eec6fd4) — independent legal reporting on the district-court judgment and procedural requirements
- [Reuters — Supreme Court permits third-country removals pending appeal](https://www.reuters.com/world/supreme-court-lets-trump-resume-third-country-deportations-2026-09-29/) — independent legal reporting on an interim Supreme Court order and granted review
- [AP — Supreme Court lets administration resume third-country removals](https://apnews.com/article/2219c35c065eab4b0690058d81bd787a) — independent legal reporting on an interim Supreme Court order
- [Ahmed v. Noem — final order directing facilitation of Ahmed Soliman's return](https://tucson.com/pdf_625a64d1-5d1e-4116-ab0c-03ea0c24cc3f.html) — primary court order
- [Reuters — judge orders Soliman's release and return from Equatorial Guinea](https://www.reuters.com/legal/government/us-judge-orders-return-egyptian-deported-equatorial-guinea-2026-10-08/) — independent reporting of the named court order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
