# DOJ states limits on midterm poll monitors while litigation continues

**Entry ID:** NAT-2026-10-28-003
**Date:** October 28, 2026
**Checked:** 2026-10-29 6:06 AM EDT
**Evidence state:** original October 27 DOJ notice and selected October 16 complaint pages, plus Reuters reporting on later assurances; later filing original, actual deployment and merits unresolved
**Review state:** current-standard-reviewed

Reuters reports FBI and ICE exclusions and an unarmed, non-enforcement role; original earlier filings document unresolved transparency and intimidation disputes.

## THE FACTS

- Reuters reported on October 29 that DOJ said in a late October 28 court filing that FBI and ICE employees would not serve as midterm poll monitors. Bureau of Prisons, ATF and DEA employees would participate, but monitors would not act as law-enforcement personnel. The later filing itself was not retrieved for this record.
- According to the same report, DOJ said monitors would observe, take notes, carry no firearms, avoid interfering with voting and follow state and local rules. These are reported departmental assurances, not an inspection of actual Election Day conduct or a judicial approval of the program.
- In the separately inspected October 27 notice, Document 27 in NAACP v. Dhillon, No. 1:26-cv-03461-SLS, DOJ reported two searches returning 18,993 and 7,842 potentially responsive records. It said the jurisdiction list would not be final until Election Day and it had not collected participating employees’ position titles. The search counts are records, not people, pages, unique responsive documents or proven violations.
- The October 16 complaint in NAACP v. Blanche, No. 1:26-cv-03626, alleges voter intimidation and unlawful agency changes under the Voting Rights Act and Administrative Procedure Act, and seeks restrictions on criminal-enforcement personnel as monitors. The inspected complaint is a party’s allegation and request for relief, not an issued injunction. The FOIA records case and the program challenge are distinct proceedings.

## SIGNIFICANCE

The stated limits create concrete tests for federal conduct at polling places, but a promise of an unarmed role does not resolve who is deployed, local consent, voter intimidation or the plaintiffs’ legal claims. The original records notice also exposes limits in pre-election disclosure.

## GOALPOST / RESPONSE

DOJ says the program follows past practice and monitors are trained to observe without interfering. The strongest test is documented compliance: assignments, training and local-law restrictions, actual conduct, complaint resolution and later court findings—not simply employees’ agency affiliations.

## MAYBE / THEREFORE

Maybe trained, unarmed observers can protect voting rights without intimidation. Therefore the record establishes reported limits and a documented disclosure dispute, not a ban on all federal election activity, a completed deployment, proven intimidation or a ruling that the entire program is lawful.


## SOURCES

- [Reuters — DOJ says FBI and ICE will not serve as midterm poll monitors](https://www.investing.com/news/world-news/us-justice-department-says-fbi-ice-agents-will-not-serve-as-poll-monitors-in-midterms-4981450) — independent reporting of a late October 28 filing; original later filing not retrieved
- [D.D.C. — NAACP v. Dhillon, Document 27 notice](https://www.democracydocket.com/wp-content/uploads/2026/10/2026-10-27-Notice.pdf) — primary government court filing, hosted copy; all three pages inspected
- [D.D.C. — NAACP v. Blanche, Document 1 complaint](https://www.democracydocket.com/wp-content/uploads/2026/10/2026-10-16-Complaint-1.pdf) — primary party pleading; pages 1–5 and 30–35 inspected, allegations not findings

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
