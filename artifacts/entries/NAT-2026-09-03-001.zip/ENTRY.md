# Treasury proposes tax-exemption nondiscrimination rule for private schools

**Entry ID:** NAT-2026-09-03-001
**Date:** September 3, 2026
**Checked:** 2026-09-03 12:03 PM EDT
**Evidence state:** primary Treasury announcement and Federal Register public-inspection proposal, independently contextualized by Associated Press; formal proposal published for comment, no final rule or exemption action by cutoff
**Review state:** current-standard-reviewed

The proposal would condition Section 501(c)(3) status on racial nondiscrimination across private-school programs beginning after May 2027; it is not yet final or operative.

## THE FACTS

- The Treasury Department and Internal Revenue Service placed a proposed rule on public inspection September 3 that would deny Section 501(c)(3) tax-exempt status to a private school that discriminates based on race, color, or national or ethnic origin in educational policies, admissions, scholarships and loans, athletics, or other school-administered programs.
- The proposal, REG-119986-25, estimates that as many as 18,000 private primary, secondary, postsecondary, professional and trade schools could be affected. Government-operated schools are outside its scope. Treasury says the rule would still allow selection based on religious affiliation and race-neutral criteria aimed at educational or socioeconomic disadvantage.
- If finalized as written, the standard would apply to taxable years beginning after May 31, 2027. The document was scheduled for Federal Register publication on September 4 with comments due 60 days after publication. No school's exemption was revoked and no new obligation became final by cutoff.
- Treasury framed the proposal as a uniform enforcement standard derived from the Supreme Court's Bob Jones University precedent and as protection against racial discrimination in tax-supported education. Associated Press reported the rule amid continuing disputes over federal civil-rights enforcement and tax-exempt educational institutions.

## SIGNIFICANCE

Tax exemption is a substantial federal subsidy, and a uniform rule could affect thousands of private educational institutions and the government's evidentiary basis for granting or withdrawing that benefit. Because the action is only proposed, its final scope, enforcement process, costs and legal durability remain open.

## GOALPOST / RESPONSE

Treasury says the proposal protects equal treatment while preserving religious affiliation decisions and race-neutral assistance for disadvantaged students. The final text, public comments, implementation guidance, exemption reviews, notice and appeal procedures, affected-school data, enforcement consistency and judicial review are the tests.

## MAYBE / THEREFORE

Maybe a clear rule will make nondiscrimination requirements more predictable and enforceable, or it may generate disputes over definitions, evidence and federal intrusion into private education. Therefore the record describes a formally published proposal with a future possible applicability date—not an operative nationwide mandate, a completed exemption revocation or proof of changed school practices.


## SOURCES

- [Treasury — proposed private-school nondiscrimination standard for tax exemption](https://home.treasury.gov/news/press-releases/sb0621) — primary agency announcement of the proposed Section 501(c)(3) standard, scope and rationale
- [Federal Register public inspection — private-school racial nondiscrimination proposed rule](https://public-inspection.federalregister.gov/2026-18127.pdf) — primary proposed rule REG-119986-25 with applicability, estimated scope and comment process
- [Associated Press — administration proposes tax-exemption rule for private schools](https://apnews.com/article/tax-exempt-status-colleges-schools-trump-f8556ba3d94099df3c8aaa06fc13105f) — independent reporting on the proposed rule, legal background and unresolved implementation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
