# FAA ends single-pilot exemption policy for specified Cessna Citation aircraft

**Entry ID:** NAT-2026-09-28-001
**Date:** September 25–28, 2026
**Checked:** 2026-09-28 12:30 AM EDT
**Evidence state:** primary FAA policy statement, 91 FR 61135–61136; issued September 24, publicly filed September 25, published September 28; effective September 29
**Review state:** current-standard-reviewed

The policy takes effect September 29; remaining exemptions require separate rescissions, and accident causation remains under investigation.

## THE FACTS

- FAA issued a policy statement on September 24, filed it for public inspection September 25 and published it September 28. Effective September 29, it will stop granting training-provider exemptions for specified transport-category CE-500 aircraft that otherwise require two pilots; current holders are to receive separate rescissions.
- FAA says its compliance review found incomplete records, improper checks and other violations; 13 of 14 Part 61 exemption holders had already been denied extensions or had exemptions rescinded. These are attributed agency findings, not a new independent audit by The Record.
- FAA reports approximately twice the accident rate for single-pilot Part 25 CE-500 aircraft compared with specified single-pilot Part 23 models. Its footnote defines that rate by the number of aircraft, not flight hours. The notice says probable causes for the cited May and December 2025 accidents remain undetermined.
- When exemption relief ends, affected pilots' logbook endorsements no longer authorize single-pilot operation. The notice preserves qualifying proficiency checks for two-pilot operations. It does not prohibit all single-pilot Cessna flying or establish that every individual rescission was completed by this cutoff.

## SIGNIFICANCE

The decision withdraws a decades-old exception and changes crew requirements for affected operators. Its safety rationale is documented, while operational compliance and resulting accident reductions remain unmeasured.

## GOALPOST / RESPONSE

FAA says the exemptions no longer provide equivalent safety and that training providers cannot oversee pilots whose operations they do not control. The original exemptions offered flexibility and lower costs. Rescission notices, operator compliance, exposure-adjusted accident data and completed NTSB findings will test the change.

## MAYBE / THEREFORE

Maybe ending these exemptions will improve oversight and safety, or costs and aircraft-use differences may complicate the comparison. Therefore the record verifies the policy and attributed findings, without treating a fleet-based accident ratio as causal proof or a prospective rescission as completed.


## SOURCES

- [FAA ends single-pilot exemption policy for specified Cessna Citation aircraft](https://www.govinfo.gov/content/pkg/FR-2026-09-28/pdf/2026-19843.pdf) — primary FAA policy statement, 91 FR 61135–61136; issued September 24, publicly filed September 25, published September 28; effective September 29
- [FAA Ends Single-Pilot Exemptions for Certain Cessna Citations](https://aviationweek.com/business-aviation/safety-ops-regulation/faa-ends-single-pilot-exemptions-certain-cessna-citations) — independent specialist reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
