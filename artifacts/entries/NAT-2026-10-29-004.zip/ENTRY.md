# Advance estimate measures third-quarter real GDP growth at 3.4% annualized

**Entry ID:** NAT-2026-10-29-004
**Date:** October 29, 2026
**Checked:** 2026-10-29 6:05 PM EDT
**Evidence state:** primary BEA release and technical notes plus Reuters and White House response; measured advance estimate, subject to revision and not causal policy evaluation
**Review state:** current-standard-reviewed

BEA reports 0.8% quarter-to-quarter growth; stronger output is not proof of a particular policy’s causal effect.

## THE FACTS

- BEA’s October 29 advance estimate puts third-quarter real GDP growth at 3.4% at a seasonally adjusted annual rate, equivalent to 0.8% quarter-to-quarter, after 2.2% annualized growth in the second quarter. Investment, consumer spending and government spending increased; exports fell and imports rose.
- BEA measured real final sales to private domestic purchasers rising 4.9% annualized. Quarterly PCE inflation was 2.1% annualized and the food-and-energy-excluded measure 2.5%; these are quarterly annualized rates, not September year-over-year inflation. The estimate is scheduled for revision November 25.
- Reuters reported 3.8% annualized consumer-spending growth and 20.9% equipment-investment growth, with AI-related investment prominent. It separately reported September PCE inflation of 3.6% year-over-year and unchanged real monthly spending. The White House credits its tax, regulatory, energy and trade agenda; the release does not independently identify those policies’ causal contribution.

## SIGNIFICANCE

This is a measured output result, including strong private demand, with a weaker end-of-quarter household picture. Growth, inflation, distribution and policy causation are different questions.

## GOALPOST / RESPONSE

The White House argues faster growth and investment vindicate its agenda. Revised national accounts, sustained real household gains and independent causal analysis can test that explanation; promotional claims are not the measurement itself.

## MAYBE / THEREFORE

Maybe AI investment and resilient demand sustain expansion, or financing, inflation and household pressure slow it. Therefore the advance growth estimate is documented, not a guarantee of continued growth, universal prosperity or proof that one administration policy caused it.


## SOURCES

- [BEA — third-quarter 2026 advance GDP estimate](https://www.bea.gov/news/2026/gdp-advance-estimate-3rd-quarter-2026) — primary statistical release and technical notes, full text inspected; advance estimate subject to revision
- [Reuters — consumer spending and AI investment power third-quarter growth](https://www.investing.com/news/economy-news/us-economic-growth-accelerates-in-third-quarter-4983581) — independent reporting, complete article body inspected on Investing.com; not the host platform’s AI tools
- [White House — response to third-quarter GDP release](https://www.whitehouse.gov/releases/2026/10/president-trump-unleashes-the-american-economy-gdp-surges-as-investment-hits-multi-year-high/) — primary administration explanation, not independent causal verification

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
