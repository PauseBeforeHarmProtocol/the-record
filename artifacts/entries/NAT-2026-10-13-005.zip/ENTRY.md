# Court temporarily blocks 10-day refugee-status response deadline

**Entry ID:** NAT-2026-10-13-005
**Date:** October 13–27, 2026
**Checked:** 2026-10-27 6:11 PM EDT
**Evidence state:** Primary two-page administrative-stay order and Reuters reporting with a named USCIS response; temporarily enjoined through November 6, merits and individual outcomes unresolved. High confidence in order scope.
**Review state:** current-standard-reviewed

An administrative stay through November 6 also protects recipients of earlier shortened-deadline notices; the merits remain pending.

## THE FACTS

- The October refugee rule shortened the response period for status-termination notices from 30 to 10 days. On October 27, Judge Julia Kobick entered an administrative stay in PANA v. Edlow, No. 1:26-cv-14817-MJJ, Document 24, temporarily barring implementation and enforcement through November 6.
- The order also bars enforcement of notices issued from October 14 through October 27 that required a response in less than 30 days. Recipients need not respond to those notices during the pause, and the government may not terminate their refugee status for failing to respond.
- Kobick issued the temporary pause to preserve the status quo, avoid irreparable harm and allow the assigned judge to consider the requested statutory stay. The order is subject to modification or extension; it is not a final invalidation of the rule or a ruling granting all claims in the broader lawsuit.
- Reuters reports that USCIS spokesperson Zach Kahler defended enforcement of the immigration laws and characterized the lawsuit as an effort to disrupt that commitment. The order resolves neither individual eligibility nor the number of eventual terminations or removals.

## SIGNIFICANCE

The interim order changes the immediate legal obligations of refugees already facing abbreviated notices, not merely the schedule for future notices. Whether the protection persists and whether notice and response procedures are adequate remain consequential questions, separate from the eventual eligibility decisions.

## GOALPOST / RESPONSE

USCIS defends enforcing immigration laws as Congress intended; the underlying policy invokes eligibility and program-integrity concerns. The court preserves time for judicial review without deciding those claims. Further orders, notice compliance, access to counsel, adjudication accuracy and actual individual outcomes are the tests.

## MAYBE / THEREFORE

Maybe a shorter response period could serve legitimate eligibility enforcement, or it could prevent people from correcting consequential errors. Therefore the rule and specified earlier notices are temporarily enjoined through November 6—not permanently reversed, validated on the merits, or proof that all reviewed refugees are ineligible or protected from every removal ground.


## SOURCES

- [Associated Press — refugee status-termination contest deadline reduced to 10 days](https://apnews.com/article/trump-refugees-immigration-deportation-fda84f5c5ebeb929cbc2c2dbeb92bf27) — independent reporting based on inspected administration policy document and named responses
- [PANA v. Edlow, Document 24: administrative stay through November 6](https://democracyforward.org/wp-content/uploads/2026/10/Pana-Order.pdf) — primary court order hosted by plaintiffs counsel
- [Judge temporarily blocks shortened refugee-status response rule](https://wsau.com/2026/10/27/us-judge-blocks-trump-rule-cutting-the-time-refugees-have-to-contest-end-of-status/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
