# Administration orders 10-day deadline to contest refugee-status termination

**Entry ID:** NAT-2026-10-13-005
**Date:** October 13, 2026
**Checked:** 2026-10-13 5:56 PM EDT
**Evidence state:** Associated Press inspection of the administration policy document and named advocate responses; deadline announced and scheduled to take effect October 14, individual effects not yet measured
**Review state:** current-standard-reviewed

The policy is set to take effect October 14, cutting the challenge period from 30 days while a large Biden-era refugee review continues.

## THE FACTS

- Associated Press reviewed an administration policy that reduces from 30 days to 10 the period for refugees to challenge termination of their status. The policy was announced October 13 and is scheduled to take effect October 14; it had not yet taken effect at this review cutoff.
- The document says the goal is to mitigate potential risks from people admitted as refugees who were not eligible and specifically criticizes admissions during the Biden administration. The government was already reviewing at least 185,000 Biden-era refugees with pending green-card applications; the policy does not state how many people will receive termination notices.
- Refugee advocates told AP that ten days may be insufficient to find counsel, translate documents or obtain records from a country a person fled, and warned that erroneous terminations could expose people to deportation and persecution. DHS did not respond to AP's questions, while the State Department referred questions to DHS.
- The change shortens an administrative contest period; it does not itself terminate every reviewed refugee's status or establish that any individual was ineligible. Individual notices, challenges, adjudications and removals remain separate potential stages.

## SIGNIFICANCE

A shorter contest period changes the process available before refugee-status termination and may affect access to counsel and evidence for a large reviewed population. The number of notices, reversal rate and removal consequences are unknown, so the archive distinguishes the ordered deadline from later individual outcomes.

## GOALPOST / RESPONSE

The policy document says the shorter period mitigates eligibility and program-integrity risks. Tests include whether the rule takes effect as scheduled, notice quality, counsel access, timely challenges, adjudication accuracy, court review, the number and basis of terminations and any resulting removals or protection failures.

## MAYBE / THEREFORE

Maybe ten days is sufficient for a focused administrative response and helps resolve genuinely ineligible admissions faster, or it may make factual errors harder to correct for people facing severe consequences. Therefore the administration has ordered a shorter challenge window—not proved widespread ineligibility or completed terminations and deportations under it.


## SOURCES

- [Associated Press — refugee status-termination contest deadline reduced to 10 days](https://apnews.com/article/trump-refugees-immigration-deportation-fda84f5c5ebeb929cbc2c2dbeb92bf27) — independent reporting based on inspected administration policy document and named responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
