# Supreme Court stays federal order requiring Missouri’s Republican-drawn congressional map

**Entry ID:** NAT-2026-09-10-001
**Date:** September 10, 2026
**Checked:** 2026-09-10 11:57 AM EDT
**Evidence state:** primary Supreme Court order plus Reuters procedural reporting; stayed pending appeal, not a final merits judgment
**Review state:** current-standard-reviewed

The emergency stay suspends the federal order during appellate review; it is not a final ruling against partisan redistricting.

## THE FACTS

- On September 10, the Supreme Court granted a stay in People Not Politicians v. Onder, No. 26A326, suspending the Eastern District of Missouri’s September 8 order in No. 4:26-cv-1424 pending the Eighth Circuit appeal and a timely Supreme Court petition.
- The stay terminates automatically if certiorari is denied, or when the Supreme Court sends down its judgment if review is granted. The unsigned order states no reasoning and records no dissent.
- Reuters reports that the suspended order required the Republican-drawn 2025 map, which eliminated a Democratic-held Kansas City district as part of Trump’s redistricting push. Missouri’s Supreme Court had blocked that map pending a referendum.

## SIGNIFICANCE

The stay removes the conflicting federal mandate favoring the new map during the appellate process. It affects the legal framework for a competitive national House election, but does not establish a final constitutional holding, voter outcome or changed seat count.

## GOALPOST / RESPONSE

Republican plaintiffs sought the 2025 map; the district judge relied on its use in the August primary. State officials argued congressional redistricting was outside the referendum provision, while opponents defended the referendum. The federal stay supplies no merits rationale. Subsequent appellate orders and official election instructions are the tests.

## MAYBE / THEREFORE

Maybe retaining one map across primary and general elections avoids disruption, or enforcing the state referendum process better protects voters’ reserved authority. Therefore the established result is a stay of one federal order during review—not a final rejection of partisan maps, a completed referendum or a predicted election result.


## SOURCES

- [Supreme Court — People Not Politicians v. Onder, No. 26A326](https://www.supremecourt.gov/orders/courtorders/091026zr_b07d.pdf) — primary judicial stay order
- [Reuters — Supreme Court blocks Republican-drawn Missouri map](https://www.reuters.com/world/us-supreme-court-blocks-republican-drawn-congressional-map-missouri-2026-09-10/) — independent reporting
- [Reuters — Missouri map litigation returns to Supreme Court](https://www.reuters.com/world/fight-over-republican-drawn-congressional-map-missouri-returns-us-supreme-court-2026-09-09/) — independent reporting on parties and procedural arguments

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
