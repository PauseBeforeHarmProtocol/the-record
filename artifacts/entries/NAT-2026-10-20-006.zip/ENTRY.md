# Trump signs ten program-specific bills into law

**Entry ID:** NAT-2026-10-20-006
**Date:** October 20, 2026
**Checked:** 2026-10-21 12:03 AM EDT
**Evidence state:** primary White House signing announcement identifying enacted bills and summarized legal effects; implementation and outcomes not yet measured
**Review state:** current-standard-reviewed

The enacted package covers fraud notices, trafficking training, tribal and public-land transfers, a manufacturing study, Social Security elections and federal permitting fees.

## THE FACTS

- The White House announced that President Trump signed ten House bills into law on October 20: H.R. 227, 837, 1721, 2388, 2481, 3620, 4307, 4467, 6380 and 7831. The page was published before the prior cutoff but materially modified at 11:14 p.m. UTC, so this run records the recovered, post-boundary signing notice rather than implying a new October 21 action.
- The laws include a two-year window for eligible clergy to revoke a Social Security coverage exemption, a Commerce Department feasibility study on domestic production of constrained high-demand goods, fraud-ban notifications for online dating services, and Labor Department training for designated employees to detect and help prevent human trafficking.
- The remaining measures direct or authorize land transfers involving Gila County, the Lower Elwha Klallam Tribe, the Southcentral Foundation and Mississippi; redesignate Chiricahua National Monument as a national park; modify Vicksburg National Military Park boundaries; and extend Interior Department authority to collect specified oil-and-gas permit application processing fees.
- Signing establishes enactment, not completed agency studies, transfers, training, notifications, construction, fee collections or measured benefits. The White House notice summarized the statutes but did not provide implementation schedules, appropriations or outcome measurements for the full group.

## SIGNIFICANCE

The signing converts ten congressional measures into law across consumer protection, trafficking enforcement, tribal and public lands, industrial policy and permitting administration. The measures vary greatly in scale, so the record treats the signing package as one presidential action while preserving each statute’s distinct implementation test.

## GOALPOST / RESPONSE

The strongest administration-facing case is that the package implements discrete congressional directions and removes administrative gaps without a broad new executive program. The tests are timely agency implementation, lawful land conveyances, usable fraud notices and trafficking training, publication of the manufacturing study, transparent fee collection and any later appropriations or measured outcomes.

## MAYBE / THEREFORE

Maybe the narrow statutes produce practical protections and administrative clarity with limited controversy, or some may remain symbolic without funding, rulemaking or measurable execution. Therefore ten bills were signed into law—not that every required transfer, study, training program or consumer-protection outcome has already occurred.


## SOURCES

- [White House — ten congressional bills signed into law](https://www.whitehouse.gov/briefings-statements/2026/10/congressional-bills-h-r-227-h-r-837-h-r-1721-h-r-2388-h-r-2481-h-r-3620-h-r-4307-h-r-4467-h-r-6380-and-h-r-7831-signed-into-law/) — primary presidential signing announcement identifying ten enacted bills and their stated legal effects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
