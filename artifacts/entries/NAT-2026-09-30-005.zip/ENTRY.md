# Pentagon orders 20 percent reduction in general and flag officer positions

**Entry ID:** NAT-2026-09-30-005
**Date:** September 30, 2026
**Checked:** 2026-09-30 6:04 PM EDT
**Evidence state:** Associated Press reporting on the defense secretary's public directive and named congressional responses, with earlier Reuters reporting for the prior baseline; reductions ordered, implementation incomplete
**Review state:** current-standard-reviewed

The new directive doubles the previously announced force-wide target and sets a January 1, 2027 deadline; the reductions were ordered but not shown complete.

## THE FACTS

- Defense Secretary Pete Hegseth announced a directive requiring a total 20 percent reduction in general and flag officer positions across the armed forces by January 1, 2027. Associated Press reported that the force has roughly 800 such positions.
- Associated Press described the new January 1 target as doubling a 10 percent force-wide reduction announced in May 2025. The May directive separately called for at least 20 percent cuts to four-star positions and top National Guard posts.
- General and flag officer positions are constrained by law, but a position can be left unfilled. The directive therefore concerns authorized or occupied leadership positions and does not establish that 20 percent of individual officers had already been dismissed or retired.
- Hegseth framed the reductions as overdue streamlining and accountability and separately claimed prior firings and billet reductions. The inspected reporting did not supply a roster or common denominator that independently establishes a completed 20 percent reduction. Senator Mark Kelly described the policy as a purge, while Senator Mike Rounds said Congress should receive the rationale for proposed cuts.
- No final position-by-position plan, completed 20 percent reduction, readiness assessment, cost measurement or congressional change to statutory limits was identified by the cutoff.

## SIGNIFICANCE

A one-fifth reduction would materially reshape the military's senior-command structure and may affect oversight, promotion pathways and operational management. The effect depends on which billets remain vacant or are eliminated and whether responsibilities are consolidated without readiness losses.

## GOALPOST / RESPONSE

Hegseth says the reductions will remove excess bureaucracy and increase accountability. The strongest response is that Congress and military critics want evidence that the cuts are mission-based rather than a loyalty-driven purge and will not weaken command capacity. Implementing guidance, billet lists, statutory notifications, actual headcount, readiness reviews and savings are the tests.

## MAYBE / THEREFORE

Maybe fewer senior billets will reduce overhead and clarify command, or poorly targeted cuts may concentrate authority, disrupt expertise and impair oversight or readiness. Therefore the record establishes an ordered 20 percent target with a deadline—not completed personnel reductions, demonstrated savings or a measured operational result.


## SOURCES

- [Associated Press — Hegseth orders deeper general and flag officer cuts](https://apnews.com/article/hegseth-pentagon-generals-job-cuts-67a20b026ee858895c7e5ff7fadbc029) — independent reporting on public directive and named congressional responses
- [Reuters — Pentagon announces initial senior-officer reductions](https://www.reuters.com/world/us/pentagon-reduce-4-star-positions-by-20-official-says-2025-05-05/) — independent reporting on the earlier reduction baseline
- [Agence France-Presse — Hegseth describes senior-officer cuts](https://currently.att.yahoo.com/att/hegseth-says-us-cut-number-201545329.html) — independent reporting on the defense secretary's public claims and reduction measures

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
