# EPA finalizes Maricopa mobile-source emissions-credit rule

**Entry ID:** NAT-2026-11-05-003
**Date:** November 5, 2026
**Checked:** 2026-11-05 6:08 PM EST
**Evidence state:** primary EPA announcement and Federal Register final rule, with independent local public-radio context from the proposal stage; final approval published, effective December 7, implementation and outcomes pending
**Review state:** current-standard-reviewed

The final SIP approval creates a federally enforceable credit program effective December 7; emissions neutrality and economic benefits remain prospective, not measured.

## THE FACTS

- EPA published a final rule approving Maricopa County Air Quality Department Rule 205 into Arizona's State Implementation Plan. The rule creates a federally enforceable program for fleet owners to generate emission-reduction credits by retrofitting or replacing on-road vehicles with lower-emitting vehicles.
- The credits may be used as offsets for major stationary sources under the nonattainment New Source Review program. EPA said Rule 205 meets applicable Clean Air Act requirements; the final rule is scheduled to take effect December 7, 2026.
- EPA says the program can facilitate manufacturing, power-plant and other stationary-source development without increasing overall emissions. That is the agency's prospective rationale, not a measured post-implementation result; KJZZ's earlier local reporting described the proposal and public economic-development rationale before final approval.
- No credits had been documented as generated, traded or retired under the federally approved program by cutoff, and no reviewed evidence measured changes in ozone, nitrogen oxides, volatile organic compounds, industrial investment or community exposure.

## SIGNIFICANCE

The final rule establishes a novel federally enforceable pathway for mobile-source reductions to offset emissions from major stationary projects in an ozone-nonattainment area. It may change both development and air-quality incentives, but actual credit integrity, distributional effects and emissions outcomes remain unknown.

## GOALPOST / RESPONSE

EPA says the program permits economic growth while maintaining emissions reductions and Clean Air Act safeguards. Issued and retired credits, baseline and verification audits, project approvals, ambient-air monitoring, enforcement and community-level exposure are the tests.

## MAYBE / THEREFORE

Maybe verified vehicle reductions will produce durable offsets for needed projects, or credit assumptions and market behavior may fail to preserve equivalent air-quality gains. Therefore the archive records a final SIP approval with a December 7 effective date—not generated credits, completed projects or measured clean-air and economic outcomes.


## SOURCES

- [EPA — final approval of Maricopa County Rule 205 emissions-credit program](https://www.epa.gov/newsreleases/epa-finalizes-first-its-kind-air-quality-plan-promote-clean-air-and-facilitate) — primary agency final-action announcement and administration rationale
- [Federal Register — final Arizona SIP approval for Maricopa County Rule 205](https://www.govinfo.gov/content/pkg/FR-2026-11-05/pdf/2026-22647.pdf) — primary final rule, 91 FR 69694, document 2026-22647
- [KJZZ — Maricopa County mobile-source emissions-credit proposal and local explanation](https://www.kjzz.org/politics/2026-10-12/maricopa-county-closer-to-getting-u-s-approval-incentivizing-lower-vehicle-emissions) — independent local public-radio reporting on the proposed rule and public rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
