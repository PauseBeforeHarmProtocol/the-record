# EEOC approves proposed overhaul of federal-worker discrimination complaints

**Entry ID:** NAT-2026-08-26-008
**Date:** August 26, 2026
**Checked:** 2026-08-27 12:00 AM EDT
**Evidence state:** EEOC press release and 150-page draft NPRM, independently reported by Reuters; commission-approved proposal awaiting Federal Register publication, comments, and any final rule
**Review state:** current-standard-reviewed

A 2-1 commission vote advances a proposed rule that would end mandatory pre-complaint counseling, narrow administrative-judge proceedings, and remove administrative class-complaint adjudication.

## THE FACTS

- The Equal Employment Opportunity Commission voted 2-1 on August 26 to issue a Notice of Proposed Rulemaking revising the federal-sector discrimination complaint process. The proposal has not taken effect; formal Federal Register publication will begin a 30-day comment period.
- The draft would allow direct filing without mandatory pre-complaint counseling, remove the automatic option to request proceedings before an EEOC administrative judge before a final agency decision, reserve judge proceedings for targeted referral on appeal, and bar administrative adjudication of class complaints while preserving putative class assertions for exhaustion and access to federal court.
- The EEOC says the existing system is too slow and reports that counseling settled about 1 percent of matters, administrative-judge processing averaged 442 days, and successful complainants waited an average of 962 days for a decision. Reuters reported that the federal employees' union and the commission's Democratic member warned the proposal could weaken access to independent review and make discrimination claims harder to pursue.

## SIGNIFICANCE

If finalized, the rule would shift more first-instance decision-making to the federal agencies accused of discrimination and make independent EEOC judge proceedings discretionary rather than automatic. The same design could shorten delays, so speed, access, outcomes, and appeal quality are all material effectiveness measures.

## GOALPOST / RESPONSE

EEOC Chair Andrea Lucas says the proposal would make a broken process faster, fairer, and more straightforward while preserving appeals and federal-court rights. Critics say removing automatic hearings and administrative class adjudication reduces practical access to relief. Federal Register publication, public comments, the final text, processing times, dismissal rates, findings of discrimination, appeal reversals, and court filings are the evidence tests.

## MAYBE / THEREFORE

Maybe targeted hearings and direct filing can reduce years-long delay without reducing meritorious outcomes, especially because de novo EEOC appeals and federal-court rights would remain. Therefore the record describes a formally approved proposal—not an implemented rule—and does not infer either faster justice or reduced protection before the final rule and outcome data exist.


## SOURCES

- [EEOC — proposed federal-sector discrimination complaint process changes](https://www.eeoc.gov/newsroom/eeoc-proposes-major-rule-changes-improve-workplace-discrimination-complaint-process) — primary commission announcement, proposal status, administration rationale, and retained rights
- [EEOC — draft NPRM revising 29 CFR part 1614](https://www.eeoc.gov/sites/default/files/2026-08/%28OLC_to_Exec_Sec_8.26.26_FR%29_NPRM_29_CFR_part_1614_508.pdf) — primary 150-page proposed rule, regulatory text, agency data, and stated justification
- [Reuters — EEOC proposes narrowing federal-worker administrative discrimination cases](https://www.reuters.com/legal/government/eeoc-moves-curb-in-house-enforcement-anti-bias-laws-against-us-agencies-2026-08-26/) — independent reporting on the commission vote, proposed changes, union response, and dissent

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
