# Federal judge rules Maurene Comey's firing unlawful

**Entry ID:** NAT-2026-10-26-001
**Date:** October 26, 2026
**Checked:** 2026-10-26 6:02 PM EDT
**Evidence state:** primary 55-page Southern District of New York order independently corroborated by Reuters and Associated Press; unlawful-removal judgment entered, First Amendment claim and remedy amount unresolved
**Review state:** current-standard-reviewed

The court ordered retroactive reinstatement and backpay while reserving the amount and Comey's First Amendment retaliation claim.

## THE FACTS

- U.S. District Judge Jesse M. Furman granted Maurene Comey summary judgment on statutory, separation-of-powers and due-process claims arising from her July 2025 removal as an assistant U.S. attorney. The 55-page order held that the firing violated the Civil Service Reform Act and constitutional separation of powers; it is a district-court judgment, not an appellate disposition.
- The court ordered retroactive reinstatement and backpay from Comey's termination through December 20, 2025. It reserved the amount of backpay, attorney's fees and costs, and the record notes that she accepted another job; the order therefore does not establish a current return to prosecutorial duties or a final dollar award.
- Furman rejected the government's argument that Article II allowed the president or attorney general to remove assistant U.S. attorneys without cause despite the civil-service framework. The court also declared that the defendants violated the Administrative Procedure Act and Comey's Fifth Amendment due-process and statutory rights.
- The court denied Comey's motion on one count and reserved her First Amendment retaliation claim, directing further briefing due November 9 with opposition one week later. Her allegation that she was fired because of her father's identity and her work on politically sensitive cases remains unadjudicated.
- Reuters and Associated Press independently reported the ruling. After the prior cutoff, the Justice Department said it disagreed with the decision and intended to appeal. That statement records an announced appellate response; no filed notice of appeal, stay, appellate ruling or final monetary calculation was public by this cutoff.

## SIGNIFICANCE

The ruling applies federal civil-service protections and separation-of-powers limits to a politically prominent prosecutorial firing, converting Comey's challenge from an allegation into a district-court finding of unlawful removal. The unresolved retaliation claim, remedy calculation and appeal posture limit the broader conclusions that can be drawn.

## GOALPOST / RESPONSE

The government argued that presidential and attorney-general removal authority displaced the civil-service restrictions; the court rejected that theory at the district-court stage, and the Justice Department said it intends to appeal. The tests are the November briefing, any judgment on the First Amendment count, backpay calculation, a filed notice or stay, appellate treatment of Article II and whether the government changes removal procedures.

## MAYBE / THEREFORE

Maybe the judgment will reinforce civil-service constraints on politically sensitive removals, or appellate review may narrow the statutory, constitutional or remedial holdings. Therefore the supported conclusion is that a federal district court ruled Comey's removal unlawful and ordered retroactive relief—not that political retaliation was proved, a final dollar amount was awarded or appellate review is complete.


## SOURCES

- [Comey v. U.S. Department of Justice — summary-judgment order](https://storage.courtlistener.com/recap/gov.uscourts.nysd.649409/gov.uscourts.nysd.649409.96.0.pdf) — primary 55-page judicial order; First Amendment claim and monetary amount remain unresolved
- [Reuters — judge rules Maurene Comey firing unlawful](https://www.reuters.com/legal/litigation/trump-administrations-firing-prosecutor-maurene-comey-was-unlawful-judge-rules-2026-10-26/) — independent court reporting with administration-response status
- [Associated Press — judge rules Maurene Comey firing unlawful](https://apnews.com/article/be7de14f705def3bb6eeadafa7e60805) — independent court reporting with procedural context and response status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
