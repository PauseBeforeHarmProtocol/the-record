# FAA discloses Boeing paid full $3.1 million safety penalty

**Entry ID:** NAT-2026-09-02-015
**Date:** September 12, 2025–September 2, 2026
**Checked:** 2026-09-03 6:02 AM EDT
**Evidence state:** primary FAA penalty announcement plus Reuters reporting based on FAA disclosure and Boeing confirmation; maximum proposed amount paid, deterrent effect and long-term safety outcomes unresolved
**Review state:** current-standard-reviewed

Boeing paid the maximum proposed civil penalty in January after FAA findings involving unairworthy aircraft, quality-system violations and interference with delegated safety staff.

## THE FACTS

- The Federal Aviation Administration told Reuters that Boeing paid the full $3,139,319 civil penalty in January 2026; Boeing separately confirmed payment. The completed payment had not been publicly disclosed before the September 2 report.
- FAA proposed the penalty in September 2025 using what it described as its maximum statutory civil-penalty authority for violations between September 2023 and February 2024, including conduct connected to the January 2024 Alaska Airlines 737 MAX 9 door-plug blowout.
- FAA said it found hundreds of quality-system violations at Boeing's Renton factory and Spirit AeroSystems' Wichita facility, that Boeing presented two unairworthy aircraft for certification, and that a Boeing employee pressured a delegated safety representative to approve a noncompliant 737 MAX to meet the delivery schedule.
- Payment resolves the announced civil-penalty amount, not every Boeing safety issue. Reuters noted that FAA later lifted a production cap and in July 2026 restored Boeing's authority to issue airworthiness certificates for all 737 MAX and 787 aircraft after its review; those steps do not by themselves establish the penalty's deterrent effect or long-term production safety.

## SIGNIFICANCE

The disclosure converts a proposed enforcement action into a completed monetary outcome tied to failures exposed by a major in-flight emergency. The amount and subsequent restoration of delegated authority make compliance trends and production quality more informative than the payment alone.

## GOALPOST / RESPONSE

FAA says it used the maximum civil-penalty authority available and later restored certification authority after production-quality review. Boeing confirmed payment and has emphasized safety and quality improvements. The strongest response, voiced by Senator Richard Blumenthal, is that $3.1 million may be too small to deter a company of Boeing's scale. Audit findings, defect rates, certification rejections, whistleblower reports, production incidents and any further enforcement are the tests.

## MAYBE / THEREFORE

Maybe the paid penalty, oversight and production controls will reinforce durable safety improvements, or the fine may be absorbed as a minor cost while structural risks persist. Therefore the record confirms full payment of FAA's $3.1 million civil penalty—not a finding that every violation was cured, that Boeing admitted all alleged conduct or that aircraft quality and delegated oversight are now proven effective.


## SOURCES

- [FAA — proposed $3,139,319 Boeing civil penalties](https://www.faa.gov/newsroom/faa-proposes-31-million-fines-against-boeing) — primary agency penalty announcement describing quality-system, airworthiness and delegated-safety findings
- [Reuters — FAA and Boeing confirm full $3.1 million penalty payment](https://www.reuters.com/world/boeing-paid-31-million-fine-faa-over-widespread-safety-violations-2026-09-02/) — independent reporting on the previously undisclosed January payment and later FAA oversight decisions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
