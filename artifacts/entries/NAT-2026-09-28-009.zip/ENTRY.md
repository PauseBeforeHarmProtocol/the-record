# Pentagon awards provisional $20.7 billion AMRAAM contract

**Entry ID:** NAT-2026-09-28-009
**Date:** September 28, 2026
**Checked:** 2026-09-28 5:55 PM EDT
**Evidence state:** named Pentagon contract announcement reported by Reuters; provisional award verified, complete appropriation, obligation, production and delivery outcomes pending
**Review state:** current-standard-reviewed

The Raytheon multiyear award is intended to accelerate missile production, but full commitment depends on future congressional appropriations.

## THE FACTS

- The Pentagon awarded RTX's Raytheon business a provisional multiyear contract valued at $20.7 billion to accelerate production of Advanced Medium Range Air-to-Air Missiles, according to the department's announcement reported by Reuters.
- The multiyear arrangement is provisional because the full commitment depends on future congressional appropriations. The reported ceiling therefore is not treated as money already obligated, disbursed or spent.
- RTX had previously set a goal of producing at least 1,900 AMRAAMs annually. The contract announcement does not establish that production reached that rate or that any delivery occurred under the new award.
- The award responds to heightened missile demand, but contract value, future appropriations, production capacity, unit costs, delivery schedules and recipient use remain separate questions.

## SIGNIFICANCE

The award is a major defense-procurement commitment intended to expand a widely used missile supply chain. Its provisional and appropriation-dependent structure is essential to interpreting the headline value.

## GOALPOST / RESPONSE

The administration and manufacturer frame multiyear procurement as a way to increase output and meet demand. The strongest response is that a ceiling and production goal are not completed capacity or delivery. Future appropriations, definitized terms, obligations, factory output, unit cost and deliveries are the tests.

## MAYBE / THEREFORE

Maybe the multiyear structure will give suppliers enough certainty to expand output, or appropriation and industrial-base constraints may limit the announced scale. Therefore the record verifies the provisional award while avoiding claims that $20.7 billion has been fully funded or that the production target has been achieved.


## SOURCES

- [Pentagon awards Raytheon provisional $20.7 billion AMRAAM contract](https://www.reuters.com/business/aerospace-defense/pentagon-awards-rtxs-raytheon-207-billion-contract-amraam-missiles-amid-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
