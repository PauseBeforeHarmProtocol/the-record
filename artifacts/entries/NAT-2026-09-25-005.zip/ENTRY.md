# Trump signs hydropower licensing transparency law

**Entry ID:** NAT-2026-09-25-005
**Date:** September 25, 2026
**Checked:** 2026-09-25 5:59 PM EDT
**Evidence state:** primary White House signing statement and enrolled statutory text; reporting requirement enacted September 25, with implementation and outcomes pending
**Review state:** current-standard-reviewed

FERC must report annually on specified pending hydropower licensing applications, beginning within 180 days; the law creates reporting duties, not project approvals or shorter licensing times.

## THE FACTS

- Trump signed H.R. 3657, the Hydropower Licensing Transparency Act, into law on September 25.
- The law adds section 37 to the Federal Power Act and requires the Federal Energy Regulatory Commission, within 180 days and annually thereafter, to report to Congress on specified original, new and subsequent hydropower license applications that remain outstanding.
- For each covered project, the report must identify the notice or application date, docket, status, anticipated issuance date, proceedings, meetings and other Commission actions, and it must disaggregate the three licensing categories.
- The law does not approve a hydropower project, impose a new decision deadline or establish that licensing delays have shortened.

## SIGNIFICANCE

The law gives Congress a recurring, project-level view of part of the hydropower licensing backlog, creating a public accountability mechanism without changing the substantive licensing standard.

## GOALPOST / RESPONSE

Supporters can describe the measure as licensing transparency. Timely reports, completeness, identified bottlenecks and any later change in licensing duration are the tests; project approvals are separate decisions.

## MAYBE / THEREFORE

Maybe recurring reporting will expose avoidable bottlenecks, or it may add paperwork without accelerating decisions. Therefore a reporting duty is enacted—not any project approval or measured reduction in delay.


## SOURCES

- [Congressional bills H.R. 3657, H.R. 7250, S. 550, S. 603, S. 759 and S. 790 signed into law](https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bills-h-r-3657-h-r-7250-s-550-s-603-s-759-and-s-790-signed-into-law/) — primary presidential signing statement
- [H.R. 3657 — Hydropower Licensing Transparency Act, enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119hr3657enr/pdf/BILLS-119hr3657enr.pdf) — primary enacted legislation; enrolled text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
