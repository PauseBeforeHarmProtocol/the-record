# Treasury urges G20 members to use trade barriers against distorted Chinese exports

**Entry ID:** NAT-2026-09-01-007
**Date:** September 1, 2026
**Checked:** 2026-09-01 6:02 PM EDT
**Evidence state:** primary Treasury G20 agenda plus independent on-site Reuters and Associated Press reporting of Bessent's remarks and unresolved negotiations; proposal made, adoption and effects unresolved
**Review state:** current-standard-reviewed

The United States formally pressed other governments to protect domestic industries from subsidized Chinese goods; no common G20 position or new U.S. tariff resulted by cutoff.

## THE FACTS

- At the G20 finance ministers' meeting in Asheville, Treasury Secretary Scott Bessent urged other governments to consider tariffs and other barriers to protect jobs and manufacturing from a diversion of Chinese exports into their markets.
- Bessent argued that Chinese subsidies, an undervalued currency and weak domestic demand had produced export and trade imbalances that were reducing growth elsewhere. Reuters reported that European officials shared concern about Chinese imbalances while also criticizing uncertainty created by U.S. tariff disputes.
- Reuters and Associated Press separately reported the U.S. position and Bessent's remarks. The administration's published 2026 G20 finance-track agenda had already identified excessive global imbalances as a priority; the September 1 remarks specified trade barriers as a policy response other countries should consider.
- Officials said negotiations over a joint communique remained unresolved, including disagreement over language concerning non-market economies and critical-mineral export controls. No agreed communique, foreign tariff commitment or new U.S. tariff instrument was public by cutoff.
- The proposal concerns what other sovereign governments should do. It does not itself impose a tariff, quantify consumer costs or benefits, compel China to change policy or prove that protected industries will expand.

## SIGNIFICANCE

The administration is attempting to internationalize its tariff strategy by encouraging other major economies to restrict diverted Chinese exports. Coordinated barriers could materially reshape trade flows and manufacturing investment, while also increasing prices, retaliation risk and fragmentation if governments adopt them.

## GOALPOST / RESPONSE

The administration says Chinese subsidies, currency policy and export dependence threaten employment and production outside China, making defensive trade measures necessary. The strongest countercase is that broader tariffs can raise domestic prices, invite retaliation and compound uncertainty already attributed to U.S. trade conflicts. Final G20 language, national tariff instruments, trade diversion, prices, investment, employment and Chinese policy responses are the tests.

## MAYBE / THEREFORE

Maybe coordinated, targeted barriers will reduce non-market distortions and preserve industrial capacity, or they may spread the costs and instability of the U.S. tariff model without changing China's underlying incentives. Therefore the record confirms a formal U.S. diplomatic proposal at the G20—not an adopted multilateral policy, a new operative tariff or a demonstrated economic result.


## SOURCES

- [Treasury — 2026 G20 Finance Track agenda](https://home.treasury.gov/news/press-releases/sb0398) — primary agenda identifying excessive global imbalances as a U.S. G20 finance-track priority
- [Reuters — United States urges G20 action against Chinese trade imbalances](https://www.reuters.com/world/china/us-pushes-g20-cut-trade-imbalances-focus-china-2026-09-01/) — independent on-site reporting of Bessent's trade-barrier proposal, other governments' responses and unresolved communique negotiations
- [Associated Press — Bessent urges G20 members to consider U.S.-style trade barriers](https://apnews.com/article/treasury-bessent-g20-trade-tariffs-426a8b4d10c6610c2d7200bab412fe1b) — independent on-site corroboration of the Treasury secretary's proposal and stated protection-of-jobs rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
