# Treasury urges G20 members to use trade barriers against distorted Chinese exports

**Entry ID:** NAT-2026-09-01-007
**Date:** September 1, 2026
**Checked:** 2026-09-02 12:00 AM EDT
**Evidence state:** primary Treasury G20 agenda plus independent on-site Reuters and Associated Press reporting of Bessent's remarks and the subsequent 19-delegation chair's statement; diplomatic backing documented, national adoption and effects unresolved
**Review state:** current-standard-reviewed

Nineteen G20 finance delegations backed chair-statement language against non-market distortions; China objected, and no national tariff instrument followed by cutoff.

## THE FACTS

- At the G20 finance ministers' meeting in Asheville, Treasury Secretary Scott Bessent urged other governments to consider tariffs and other barriers to protect jobs and manufacturing from a diversion of Chinese exports into their markets.
- Bessent argued that Chinese subsidies, an undervalued currency and weak domestic demand had produced export and trade imbalances that were reducing growth elsewhere. Reuters reported that European officials shared concern about Chinese imbalances while also criticizing uncertainty created by U.S. tariff disputes.
- Reuters and Associated Press separately reported the U.S. position and Bessent's remarks. The administration's published 2026 G20 finance-track agenda had already identified excessive global imbalances as a priority; the September 1 remarks specified trade barriers as a policy response other countries should consider.
- After the prior cutoff, the G20 chair's statement said all participating finance delegations except China agreed that countries should eliminate non-market policies that worsen imbalances, including distortions that constrain domestic consumption and produce excessive reliance on exports for growth. The statement also urged countries to avoid unnecessary critical-mineral export restrictions.
- The outcome was a chair's statement backed by 19 delegations rather than a consensus communique, and it did not require any government to adopt Bessent's proposed tariffs or other barriers. No foreign tariff commitment or new U.S. tariff instrument followed by cutoff.
- The statement records broad diplomatic agreement on a problem and desired direction. It does not quantify consumer costs or benefits, compel China to change policy, or prove that protected industries will expand.

## SIGNIFICANCE

The administration converted its tariff pitch into a broadly backed G20 finance statement identifying non-market distortions and export dependence as shared problems. That diplomatic result may encourage national measures, but the absence of consensus and binding instruments leaves implementation and economic effects open.

## GOALPOST / RESPONSE

The administration says Chinese subsidies, currency policy and export dependence threaten employment and production outside China, making defensive trade measures necessary. The strongest countercase is that broader tariffs can raise domestic prices, invite retaliation and compound uncertainty already attributed to U.S. trade conflicts. National tariff instruments, trade diversion, prices, investment, employment and Chinese policy responses are the tests.

## MAYBE / THEREFORE

Maybe the 19-delegation statement will support coordinated, targeted measures that reduce non-market distortions, or it may remain nonbinding language while unilateral barriers spread costs and instability. Therefore the record confirms broad G20 finance backing for the problem statement—not consensus with China, adopted national tariffs, a binding multilateral policy or a demonstrated economic result.


## SOURCES

- [Treasury — 2026 G20 Finance Track agenda](https://home.treasury.gov/news/press-releases/sb0398) — primary agenda identifying excessive global imbalances as a U.S. G20 finance-track priority
- [Reuters — United States urges G20 action against Chinese trade imbalances](https://www.reuters.com/world/china/us-pushes-g20-cut-trade-imbalances-focus-china-2026-09-01/) — independent on-site reporting of Bessent's trade-barrier proposal, other governments' responses and unresolved communique negotiations
- [Associated Press — Bessent urges G20 members to consider U.S.-style trade barriers](https://apnews.com/article/treasury-bessent-g20-trade-tariffs-426a8b4d10c6610c2d7200bab412fe1b) — independent on-site corroboration of the Treasury secretary's proposal and stated protection-of-jobs rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
