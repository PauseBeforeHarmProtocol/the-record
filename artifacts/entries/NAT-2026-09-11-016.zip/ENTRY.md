# CFTC finalizes 30% presumption for smaller whistleblower awards

**Entry ID:** NAT-2026-09-11-016
**Date:** September 11–16, 2026
**Checked:** 2026-09-16 12:01 PM EDT
**Evidence state:** primary CFTC final rule, Federal Register publication and agency announcement; finalized with delayed effective date and measurable outcomes pending
**Review state:** current-standard-reviewed

The rule takes effect October 16 and presumptively gives eligible awardees the statutory maximum when the total award is $5 million or less, subject to stated conditions and Commission discretion.

## THE FACTS

- The Commodity Futures Trading Commission approved a final rule on September 11 and published it in the Federal Register on September 16. It takes effect October 16, 2026.
- New rule 165.9(d) creates a rebuttable presumption that eligible whistleblower awardees receive, in total, the 30% statutory maximum when the resulting award is $5 million or less, subject to Commission discretion, regulatory factors and specified public-interest and claimant-conduct conditions.
- The underlying statute continues to authorize awards between 10% and 30% of collected monetary sanctions. Claims above the threshold and claims that do not meet the presumption's conditions remain subject to individualized assessment; the rule does not guarantee a $5 million payment or change the sanctions collected in an enforcement case.
- CFTC modeled the provision on an SEC rule and also made technical amendments reflecting the Whistleblower Office's 2025 transfer to the Office of General Counsel. The agency said the change should improve speed, transparency and predictability and free staff to focus on larger claims.
- The final rule says historical data suggest the presumption would have raised payments in about 30% of eligible matters. It creates no new reporting or recordkeeping duty for registrants, and its effects on processing time, tip quality and enforcement recoveries remain unmeasured.

## SIGNIFICANCE

The final rule changes how the CFTC calculates a substantial class of whistleblower awards and could increase predictability and payments without new registrant obligations. Its actual incentive and enforcement effects will depend on claims processing and Commission use of the exceptions.

## GOALPOST / RESPONSE

CFTC says the presumption will shorten award timelines, harmonize its process with the SEC and strengthen incentives to report violations. The tests are award-processing times, the share receiving 30%, use of exceptions, total awards and sanctions, and whether larger-case backlogs decline after the effective date.

## MAYBE / THEREFORE

Maybe a predictable maximum award brings stronger tips and faster decisions, or discretion and eligibility disputes may limit practical change. Therefore CFTC has finalized a presumption effective October 16—not guaranteed any individual award, proved faster processing or measured additional enforcement recoveries.


## SOURCES

- [Federal Register — Whistleblower Award Determination, 91 FR 58846](https://www.federalregister.gov/documents/2026/09/16/2026-19006/whistleblower-award-determination) — primary final rule effective October 16
- [CFTC — final whistleblower-award rule announcement](https://www.cftc.gov/PressRoom/PressReleases/9297-26) — primary agency announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
