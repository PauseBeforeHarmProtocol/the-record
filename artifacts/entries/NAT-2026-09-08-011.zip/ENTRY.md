# Judge dismisses Imran Ahmed's challenge to Trump immigration action on jurisdictional grounds

**Entry ID:** NAT-2026-09-08-011
**Date:** September 8–9, 2026
**Checked:** 2026-09-09 6:00 AM EDT
**Evidence state:** CourtListener docket metadata plus Reuters legal reporting; jurisdictional dismissal entered with a short continuation of prior protection, merits and any later immigration enforcement unresolved
**Review state:** current-standard-reviewed

The ruling permits the government to pursue immigration enforcement after a short appeal stay; it is not a merits judgment or completed removal.

## THE FACTS

- Imran Ahmed, a British anti-disinformation advocate and U.S. lawful permanent resident, sued after the Trump administration designated him for visa restrictions alongside four Europeans it accused of pressuring American technology companies to censor speech. Reuters reported that Ahmed lives in Washington with his U.S.-citizen wife and child.
- On September 8, U.S. District Judge Loretta Preska dismissed Ahmed v. Rubio for lack of jurisdiction under a recent appellate ruling. CourtListener's docket identifies the September 8 memorandum and opinion; Reuters reported that Preska wrote Ahmed 'very well may have valid causes of action' but that Congress had not authorized the district court to hear the case in its current posture. The dismissal did not decide the factual allegations or constitutional merits.
- Preska kept the existing temporary restraint in place for five business days to permit an appeal. Reuters reported that the dismissal could then allow detention or removal proceedings, but no detention, removal order or completed deportation was established by cutoff. The administration says the restrictions defend Americans against foreign censorship; Ahmed says the action is retaliation for protected advocacy.

## SIGNIFICANCE

The dismissal narrows the immediate judicial path for a lawful permanent resident challenging an administration speech-based immigration measure and may expose him to enforcement while appellate review is sought. The ruling rests on jurisdiction, leaving the underlying legality unresolved.

## GOALPOST / RESPONSE

The administration says it is protecting U.S. speech from foreign coercion; Ahmed argues the designation punishes lawful advocacy and threatens family and residence interests. The tests are appellate action, expiration or extension of the restraint, any immigration charge or custody action, the administrative record and a court ruling with jurisdiction to reach the merits.

## MAYBE / THEREFORE

Maybe Congress lawfully channeled this dispute to immigration proceedings or another forum, or the jurisdictional rule may delay meaningful review until coercive consequences occur. Therefore the September 8 order dismisses this suit and preserves a five-business-day appeal window—not a merits endorsement of the designation, a removal order or a completed deportation.


## SOURCES

- [Reuters — judge dismisses Ahmed challenge while preserving a short appeal stay](https://www.reuters.com/legal/government/us-judge-dismisses-suit-by-british-anti-disinformation-activist-against-2026-09-09/) — independent legal reporting on the September 8 jurisdictional dismissal and temporary continuation of prior protection
- [CourtListener — Ahmed v. Rubio docket, No. 1:26-cv-01315](https://www.courtlistener.com/docket/72079865/ahmed-v-rubio/) — primary-court docket metadata identifying the September 8 memorandum and opinion; complete opinion text was not retrievable in this review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
