# Commerce issues final solar-trade determinations; duty orders await ITC injury finding

**Entry ID:** NAT-2026-09-11-010
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 PM EDT
**Evidence state:** Reuters report based on Commerce final determinations, cross-checked against official case-scope and process pages; final agency margin stage reached, ITC injury decision and orders pending
**Review state:** current-standard-reviewed

Commerce set final dumping and subsidy margins for cells and modules from India, Indonesia and Laos, but actual duty orders depend on the trade commission's October injury decision.

## THE FACTS

- Reuters reported on September 11 that the Commerce Department issued affirmative final antidumping and countervailing-duty determinations covering crystalline-silicon photovoltaic cells and modules from India, Indonesia and Laos.
- Reported final antidumping margins were 123.04% for India, 94.36% for Indonesia and 65.43% for Laos. Reported countervailing rates were 126.09% for India, 73.20% to 173.70% for Indonesia and 82.03% to 153.67% for Laos; company-specific application may differ within those ranges.
- The petitions were brought by the Alliance for American Solar Manufacturing and Trade, whose members include First Solar, Hanwha Qcells and Mission Solar. The petitioners say subsidized and unfairly priced imports injure domestic manufacturing; importers and developers have warned that trade restrictions can raise project costs and constrain supply.
- Commerce's determinations do not by themselves create final duty orders. The U.S. International Trade Commission's final injury determination is due October 14; Commerce is expected to issue orders in November only if the commission reaches an affirmative finding.

## SIGNIFICANCE

The determinations advance a trade case that could materially alter solar-equipment prices, sourcing and domestic manufacturing investment. The pending injury stage means the final margins are formal agency findings, not yet completed import restrictions or measured market effects.

## GOALPOST / RESPONSE

The administration and petitioning manufacturers frame the case as enforcement against dumping and subsidies and support for U.S. production. The tests are the ITC injury vote, final orders and company rates, import volumes, module and project prices, domestic output, jobs and deployment timelines.

## MAYBE / THEREFORE

Maybe duties support durable domestic capacity and fair pricing, or they may raise near-term costs and slow installations without producing the claimed manufacturing gains. Therefore Commerce reached final dumping and subsidy determinations—not final duty orders, an ITC injury finding or measured effects on prices, jobs and generation.


## SOURCES

- [Reuters — Commerce finalizes solar-trade determinations for India, Indonesia and Laos](https://www.reuters.com/business/energy/us-commerce-department-finalizes-steep-duties-solar-imports-india-indonesia-laos-2026-09-11/) — independent trade reporting based on Commerce determinations
- [Commerce — preliminary antidumping determinations for solar cells from India, Indonesia and Laos](https://www.trade.gov/preliminary-determinations-antidumping-duty-investigations-crystalline-silicon-photovoltaic-cells) — primary agency case background
- [Commerce — preliminary countervailing-duty determinations for solar cells from India, Indonesia and Laos](https://www.trade.gov/preliminary-determinations-countervailing-duty-investigations-crystalline-silicon-photovoltaic) — primary agency case background

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
