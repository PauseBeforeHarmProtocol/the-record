# Appeals court declines to stay sanctions in Trump IRS settlement case

**Entry ID:** NAT-2026-09-29-008
**Date:** September 29, 2026
**Checked:** 2026-09-29 11:57 PM EDT
**Evidence state:** independent Reuters legal reporting on the Eleventh Circuit order and named judicial findings; stay denied, underlying appeal and disciplinary consequences unresolved
**Review state:** current-standard-reviewed

An Eleventh Circuit panel left a district judge's sanctions in place while the underlying appeal continues, rejecting an immediate pause without deciding every merits issue.

## THE FACTS

- A three-judge U.S. Court of Appeals for the Eleventh Circuit panel on September 29 denied an emergency request to pause sanctions imposed by U.S. District Judge Kathleen Williams in litigation over Trump's attempted settlement of a $10 billion lawsuit against the Internal Revenue Service, Reuters reported.
- The panel concluded that a bar referral was not a final appealable order and declined to stay a narrow prohibition on using the agreement as a settlement in official proceedings. It said the applicants had not shown a strong likelihood of success or clear error and had offered no evidence undermining the district court's collusion finding.
- Williams had found the private agreement improper and collusive, referred attorney Alejandro Brito to the bar and barred official reliance on the document as a settlement. The proposed $1.8 billion fund was abandoned; the continuing legal status and practical effect of other provisions, including reported audit protection, remain disputed.
- A Trump legal spokesperson defended the underlying lawsuit as an appropriate effort to hold alleged wrongdoers accountable. The appellate order addressed interim relief and appealability, not a final merits resolution of every underlying claim or sanction.
- The sanctions and restriction remained operative at cutoff, while further appellate proceedings and any disciplinary action remained unresolved.

## SIGNIFICANCE

The ruling preserves a federal judge's response to an unusual attempted executive-branch settlement involving the president, sustaining immediate institutional constraints while leaving broader appellate and disciplinary questions open.

## GOALPOST / RESPONSE

Trump's legal team says the lawsuit properly seeks accountability; the district court found the agreement collusive, and the appellate panel found no basis for emergency relief. A merits appellate ruling, any bar disposition, disclosure of operative terms and documented government reliance are the tests.

## MAYBE / THEREFORE

Maybe the sanctions will deter conflicted or nontransparent government settlements, or later appellate review may narrow the district court's authority or findings. Therefore the record establishes denial of a stay and continuation of the sanctions—not final resolution of the merits, completed discipline or proof that every disputed agreement term remains operative.


## SOURCES

- [Reuters — Appeals court declines to pause sanctions in Trump IRS settlement case](https://www.reuters.com/world/us/appeals-court-declines-pause-sanctions-against-trump-lawyers-irs-settlement-2026-09-29/) — independent legal reporting on an Eleventh Circuit stay denial

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
