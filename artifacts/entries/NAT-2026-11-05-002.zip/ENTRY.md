# State authorizes up to $50 million in rewards for three Tren de Aragua fugitives

**Entry ID:** NAT-2026-11-05-002
**Date:** November 5, 2026
**Checked:** 2026-11-05 6:08 PM EST
**Evidence state:** primary State and Justice Department reward announcements and charging posture; offers implemented, allegations unadjudicated and operational outcomes pending
**Review state:** current-standard-reviewed

Two offers were increased and one was created under the organized-crime rewards program; the men remain charged fugitives, and no arrest or payment is established.

## THE FACTS

- The State Department, coordinated with DOJ, FBI and DEA, authorized reward offers totaling up to $50 million for information leading to the arrest or conviction in any country of three alleged Tren de Aragua leaders.
- The offer for Yohan José Romero increased from $4 million to $20 million; the offer for Giovanni Vicente Mosquera Serrano increased from $5 million to $15 million; and a new offer of up to $15 million was created for Juan Gabriel Rivas Núñez.
- DOJ says the three men were charged in superseding indictments in the Southern District of Texas, including material-support counts, and that Mosquera Serrano also faces cocaine-distribution charges. Indictments and agency descriptions are allegations; the reward announcement does not establish guilt.
- The offers are implemented authorizations under the Transnational Organized Crime Rewards Program, not appropriated cash already paid. No reviewed evidence established an arrest, conviction, reward claim, payment or measured deterrent effect by cutoff.

## SIGNIFICANCE

The offers materially increase the government's financial incentive for information about three named fugitives and link diplomatic reward authority to an active federal prosecution. Their value depends on actionable tips, arrests, lawful proceedings and any eventual payment—not the headline ceiling alone.

## GOALPOST / RESPONSE

The administration says the offers will help bring alleged leaders to justice and disrupt a transnational threat. Verified tips, arrests, extraditions, court outcomes, reward determinations, payments and any measured effect on the organization are the tests.

## MAYBE / THEREFORE

Maybe the larger offers will produce actionable information, or they may yield no arrest or create unreliable claims requiring careful vetting. Therefore the archive records three operative reward ceilings totaling up to $50 million—not guilt, capture, conviction, payment or dismantlement of the organization.


## SOURCES

- [Justice Department — reward offers totaling up to $50 million for three Tren de Aragua leaders](https://www.justice.gov/opa/pr/reward-offers-50m-information-leading-arrests-andor-convictions-foreign-terrorist) — primary reward authorization and charging-status announcement
- [U.S. Attorney's Office SDTX — amounts and charging posture for three Tren de Aragua reward offers](https://www.justice.gov/usao-sdtx/pr/rewards-combined-50m-three-tren-de-aragua-leaders-following-homeland-security-task) — primary district announcement with individual reward amounts and indictment status
- [State Department — Tren de Aragua Transnational Organized Crime Rewards Program offers](https://www.state.gov/releases/office-of-the-spokesman/2026/11/reward-offers-totaling-up-to-50-million-for-information-leading-to-arrests-and-or-convictions-of-leaders-of-foreign-terrorist-organization-tren-de-aragua/) — primary reward-program announcement coordinated with DOJ, FBI and DEA

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
