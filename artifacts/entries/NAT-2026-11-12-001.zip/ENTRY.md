# HUD finalizes eligibility verification and limits prorated housing aid for mixed-status families

**Entry ID:** NAT-2026-11-12-001
**Date:** November 12, 2026
**Checked:** 2026-11-12 6:13 AM EST
**Evidence state:** published HUD final rule, official PDF and administration release plus independent housing-sector analysis; final and effective December 14, with implementation and effects not yet measured
**Review state:** current-standard-reviewed

The final rule takes effect December 14, requires verification for every household member and replaces indefinite prorated assistance with a temporary transition; implementation outcomes remain unmeasured.

## THE FACTS

- HUD published a final rule on November 12 with a December 14 effective date. It requires public-housing agencies and owners to verify U.S. citizenship or eligible immigration status for every applicant and recipient regardless of age, and it removes the option for a person to decline to contend eligibility without supplying evidence.
- The rule requires signed consent and use of DHS's SAVE system for noncitizen eligibility. If a housing entity determines that a household member is unlawfully present, it must notify DHS immediately. A household may contest an adverse determination and seek an informal hearing under the rule's procedures.
- For mixed-status families, prorated assistance becomes temporary rather than indefinite. Existing families generally must submit evidence within 90 days after the effective date; eligible deferrals can extend assistance, including in renewable six-month periods, but the rule caps the transition rather than guaranteeing permanent prorated aid.
- HUD says the change preserves scarce assistance for fully eligible households and estimates a $167 million to $218 million annual transfer of assistance to replacement households. NAHRO identifies displacement and implementation concerns for mixed families. Those figures are modeled transfers, not measured savings, removals or replacement outcomes.

## SIGNIFICANCE

The final rule changes the eligibility process and duration of assistance for households containing both eligible and ineligible members, potentially shifting aid and housing stability once implementation begins. Due-process steps and deferrals remain material limits, and the record does not assume every mixed family will immediately lose housing.

## GOALPOST / RESPONSE

HUD says uniform verification protects program integrity and directs limited assistance to eligible households. The strongest competing concern is displacement of eligible family members and administrative burden. Implementation guidance, SAVE accuracy, notices and hearings, deferrals, terminations, replacement-household awards, costs, litigation and measured housing outcomes are the tests.

## MAYBE / THEREFORE

Maybe uniform verification will reduce improper payments and reallocate aid to eligible households, or documentation errors and the end of indefinite prorating may destabilize families that include eligible children or adults. Therefore the archive records a published final rule with a future effective date—not completed implementation, verified fraud reduction, measured savings or a finding that every affected person is unlawfully present.


## SOURCES

- [HUD — verification of eligible status final rule](https://www.federalregister.gov/documents/2026/11/12/2026-23003/housing-and-community-development-act-of-1980-verification-of-eligible-status) — primary final rule; eligibility verification, prorated-assistance and implementation requirements
- [Federal Register PDF — HUD verification of eligible status final rule](https://www.govinfo.gov/content/pkg/FR-2026-11-12/pdf/2026-23003.pdf) — official PDF of published final rule, including regulatory analysis and effective date
- [HUD — final rule on taxpayer-funded housing eligibility](https://www.hud.gov/news/hud-no-26-091) — primary administration explanation of the final rule
- [NAHRO — HUD publishes mixed-status final rule](https://www.nahro.org/news/hud-publishes-mixed-status-final-rule/) — independent specialist analysis of implementation timing and mixed-family consequences

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
