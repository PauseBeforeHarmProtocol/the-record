# FAA proposes direct medical certification for qualifying pilots with non-insulin-treated diabetes

**Entry ID:** NAT-2026-09-04-003
**Date:** September 4, 2026
**Checked:** 2026-09-04 6:02 AM EDT
**Evidence state:** primary FAA proposed rule; proposed for comment, implementation and safety effects not established
**Review state:** current-standard-reviewed

Qualified applicants could receive certificates from aviation medical examiners instead of waiting for special-issuance review; FAA estimated the affected certification volume, not unique pilots or safety outcomes.

## THE FACTS

- FAA proposed September 4 to allow aviation medical examiners to issue certificates at the examination to qualifying pilots with non-insulin-dependent diabetes who use permitted non-insulin medications and meet specified criteria.
- Under current practice described by FAA, these cases generally require deferral and special-issuance review; the agency reported an average 64-day processing period. Comments are due October 5, 2026, and the streamlined pathway is not yet operative.
- FAA estimated that 49,967 initial and 119,118 recurrent medical certifications over five years could move to the new process. Those figures are certification events, not necessarily 169,085 different people.
- FAA reviewed 51 fatal accidents from 2008 through 2025 involving pilots with non-insulin-treated diabetes, finding a diabetes contribution improbable in 50 and one case still pending. That review supports the agency's proposed risk judgment but does not prove future safety performance.

## SIGNIFICANCE

Medical-certification delays can interrupt pilot employment and flight privileges. Moving defined cases to aviation medical examiners could reduce administrative delay while placing greater importance on clear eligibility rules, examiner consistency and post-change safety monitoring.

## GOALPOST / RESPONSE

FAA says the pathway can reduce delay without adding safety risk. The final rule, examiner guidance, processing times, approval and deferral rates, medication criteria, appeals, incident and accident data, and inspector-general or independent review are the tests.

## MAYBE / THEREFORE

Maybe mature treatment standards make centralized special issuance unnecessary for lower-risk cases, or decentralized certification could miss complications if criteria and oversight are weak. Therefore the record establishes a formal proposal and FAA risk analysis—not an active pathway, a count of unique beneficiaries or proof of unchanged safety outcomes.


## SOURCES

- [FAA — proposed modernization of non-insulin-dependent diabetes medical standards](https://www.federalregister.gov/documents/2026/09/04/2026-18162/modernizing-medical-standards-for-non-insulin-dependent-diabetes-mellitus-cases) — primary proposed rule on aviation medical certification for pilots using qualifying non-insulin diabetes medications

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
