# EPA asks Supreme Court to restore termination of $16 billion in climate grants

**Entry ID:** NAT-2026-11-02-005
**Date:** November 2, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** primary Supreme Court docket and certiorari petition plus independent Associated Press reporting; petition filed and review pending, with injunction and administrative stay posture preserved
**Review state:** current-standard-reviewed

The Solicitor General filed a certiorari petition seeking review of an injunction that preserves five nonprofits' grants; the Court has not agreed to hear the case and disputed funds remain administratively stayed.

## THE FACTS

- On November 2 the Solicitor General filed a petition for a writ of certiorari in Zeldin v. Climate United Fund, No. 26-589; the Supreme Court docketed it November 4 and extended all respondents' response deadline to December 15. The justices have not granted review or ruled on the merits.
- The petition says EPA terminated $20 billion in Greenhouse Gas Reduction Fund grants, including $16 billion awarded to the five respondent nonprofits. A district court preliminarily enjoined the terminations, and the en banc D.C. Circuit affirmed in a fractured August 4 judgment.
- The government asks whether the Tucker Act channels the grantees' claims to the Court of Federal Claims and whether the repealed statutory authorization can support prospective injunctive relief. It argues the case affects the government's ability to terminate grants inconsistent with a later administration's priorities.
- The petition alleges conflicts of interest and inadequate oversight; Associated Press reported that the grantees characterize the cancellations as unlawful and unconstitutional and that the district judge previously said EPA did not provide requested evidence of fraud. The administrative stay means the disputed funds have not been released while Supreme Court review is pending.

## SIGNIFICANCE

The petition puts the administration's broad grant-termination strategy and $16 billion before the Supreme Court, with potential consequences beyond this program for where federal grant disputes may be heard. It is a requested review, not a Supreme Court holding, restored termination or completed recovery of funds.

## GOALPOST / RESPONSE

The administration says the case concerns contract claims assigned to the Court of Federal Claims, statutory repeal and executive authority to end grants that do not serve current priorities. The grantees say EPA unlawfully dismantled a congressionally created program. The tests are whether certiorari is granted, the response and merits arguments, any change to the stay, and actual fund access or termination.

## MAYBE / THEREFORE

Maybe the Court will take the case and adopt EPA's jurisdictional or statutory arguments, or it may deny review or preserve the injunction. Therefore the evidence establishes a pending petition concerning $16 billion—not a Supreme Court victory, effective grant cancellation or disbursement.


## SOURCES

- [Zeldin v. Climate United Fund, No. 26-589 — docket](https://www.supremecourt.gov/docket/docketfiles/html/public/26-589.html) — primary Supreme Court docket recording the certiorari petition, response schedule and pending status
- [Petition for a Writ of Certiorari, Zeldin v. Climate United Fund](https://www.supremecourt.gov/DocketPDF/26/26-589/431482/20261102131123209_Climate%20United%20Petition.pdf) — primary certiorari petition stating the administration's jurisdictional and statutory arguments concerning $16 billion in grants
- [Trump urges justices to let EPA cancel billions in Biden-era climate grants](https://apnews.com/article/climate-grants-green-bank-trump-supreme-court-1e078ef59eae642349ee6a44a73c0d50) — independent reporting on the petition, the parties' positions, the lower-court posture and unresolved Supreme Court review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
