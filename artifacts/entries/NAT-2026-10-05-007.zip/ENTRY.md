# DOJ reports forty denaturalization complaints; citizenship outcomes remain unresolved

**Entry ID:** NAT-2026-10-05-007
**Date:** October 5, 2026
**Checked:** 2026-10-06 12:04 PM EDT
**Evidence state:** original DOJ announcement and numbered inventory, independently reported announcement; filings reported by the agency, allegations and final civil outcomes unresolved; source-date inconsistency disclosed
**Review state:** current-standard-reviewed

The October 5 announcement describes filed civil cases, not forty completed citizenship revocations; its aggregate date range conflicts with one listed case.

## THE FACTS

- On October 5, DOJ announced that it had filed civil denaturalization actions against forty people in multiple federal district courts. The original announcement lists forty individuals; The Guardian separately reported the announcement on October 6. The count is the department’s reported complaint inventory, not an independently audited count of final judgments.
- DOJ describes illegal procurement of naturalization, concealment of material facts or willful misrepresentation as the legal grounds and cites alleged pre-naturalization conduct. Criminal convictions described in individual summaries do not themselves establish that a civil court has revoked citizenship in these cases.
- Attorney General Todd Blanche and Civil Division head Brett Shumate say the effort protects national security, the public and the integrity of naturalization. Their assertions that every defendant concealed disqualifying facts, and that this is the largest effort in modern history, remain attributed government claims rather than independent adjudications or a verified historical ranking.
- The announcement’s opening describes complaints filed from August 21 through October 2, but its item 12 dates the Douglas Eze complaint to August 10. That source inconsistency is preserved. The record does not treat the headline interval as verified for every case, and the inspected material does not establish completed revocation or removal for the forty people.

## SIGNIFICANCE

The official inventory documents an expanded use of civil proceedings that can remove a person’s citizenship if the government meets the legal standard. The severe potential consequences make the reported filings material, while complaint allegations and an internally inconsistent aggregate date range require careful attribution.

## GOALPOST / RESPONSE

DOJ says it is targeting unlawfully obtained citizenship to protect security and restore integrity. Record-specific complaints, defenses, court decisions, the evidence of pre-naturalization disqualification and clarification of the filing inventory are the tests; an announcement or prior criminal conviction is not a denaturalization judgment.

## MAYBE / THEREFORE

Maybe these proceedings correct materially fraudulent naturalizations, or individual claims may fail on proof or legal grounds. Therefore DOJ’s forty-case announcement and reported litigation inventory are established, while liability, final citizenship revocations, removals, the claimed historic ranking and the full filing-date range remain unverified.


## SOURCES

- [DOJ — Announcement of forty denaturalization complaints](https://www.justice.gov/opa/pr/justice-department-moves-strip-citizenship-40-criminals-largest-single-period) — primary official reported filing inventory; allegations and outcomes distinguished
- [The Guardian — DOJ announces denaturalization proceedings for forty people](https://www.theguardian.com/us-news/2026/oct/06/trump-justice-department-denaturalize-citizens-crimes) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
