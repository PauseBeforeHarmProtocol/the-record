# Judge declines to block Pentagon firings of three Stars and Stripes journalists

**Entry ID:** NAT-2026-09-04-016
**Date:** August 21–September 4, 2026
**Checked:** 2026-09-05 12:00 PM EDT
**Evidence state:** primary district-court memorandum order plus Reuters and Associated Press reporting; notices and preliminary ruling documented, final legality, motive and newsroom effects unresolved
**Review state:** current-standard-reviewed

A district judge denied preliminary relief after concluding the employees were unlikely to prevail on the First Amendment theory presented at this stage; the underlying lawsuit remains pending.

## THE FACTS

- The Pentagon issued separation notices in August to Stars and Stripes publisher Max Lederer, editor-in-chief Erik Slavin and Middle East reporter Lara Korte. Reuters reported that Slavin said the Pentagon cited insubordination after he objected in a CBS interview to potential military censorship; Lederer was also cited for refusing to deliver separation notices and for statements about the paper's direction.
- The three journalists sued the Defense Department and senior officials, alleging retaliation and violations of the First Amendment and Administrative Procedure Act. Those allegations remain claims in pending litigation, not adjudicated facts.
- On September 4, U.S. District Judge Trevor McFadden denied their request for a preliminary injunction. He concluded on the current record that Slavin and Korte likely spoke as public employees performing official duties rather than as private citizens and that the plaintiffs had not shown likely First Amendment success or irreparable harm.
- The court's order allows the Pentagon to proceed with the terminations while the case continues. It did not grant summary judgment, decide the Administrative Procedure Act claims, determine every disputed fact or finally resolve whether the firings were lawful.
- The Pentagon argued that the interviews were official employee speech and that the firings were unrelated to Stars and Stripes reporting on conditions aboard the USS Abraham Lincoln. The plaintiffs said they were defending congressionally recognized editorial independence and expect discovery to support their case.

## SIGNIFICANCE

The ruling permits the Defense Department to remove senior personnel from a congressionally recognized military news outlet during an unresolved dispute over editorial independence. Its immediate employment effect is material, but its preliminary posture sharply limits what it establishes about censorship, retaliation or final legality.

## GOALPOST / RESPONSE

The Pentagon says the separations address insubordination and unauthorized official speech rather than protected journalism or retaliation. Final merits rulings, discovery concerning the timing and reasons for the notices, any administrative review, staffing and policy changes at Stars and Stripes, and evidence of editorial interference are the tests.

## MAYBE / THEREFORE

Maybe the Pentagon lawfully disciplined federal employees for official-duty speech while leaving the newspaper's editorial work intact, or the notices may be part of a broader effort to chill independent reporting that the preliminary record could not yet prove. Therefore the record confirms the separation notices and denial of emergency relief—not a final First Amendment judgment, proven retaliation or proof that editorial independence has or has not been impaired.


## SOURCES

- [Slavin v. Parnell — memorandum order denying preliminary injunction](https://www.courthousenews.com/wp-content/uploads/2026/09/stars-and-stripes-mcfadden-pi-denied-opinion.pdf) — primary court order denying emergency relief while the journalists' claims continue
- [Associated Press — judge declines to block Stars and Stripes firings](https://apnews.com/article/stars-stripes-pentagon-censorship-c9cd2e453e6bb2e8ca5908e0581e6eca) — independent reporting on the preliminary ruling, parties' positions and unresolved litigation
- [Reuters — Pentagon fires Stars and Stripes leadership](https://www.reuters.com/world/us/pentagon-fires-us-military-newspaper-leadership-2026-08-21/) — independent reporting on the separation notices and stated insubordination rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
