# CMS offers states optional Medicaid work-requirement enforcement pause

**Entry ID:** NAT-2026-11-13-012
**Date:** November 13, 2026
**Checked:** 2026-11-14 6:05 AM EST
**Evidence state:** CMS announcement and operative state-director letter plus Associated Press reporting and KFF tracking; optional transition offered, state adoption and effects unresolved
**Review state:** current-standard-reviewed

States may seek approval to assess compliance without denying or ending otherwise valid coverage through June 30, 2027; the transition is optional and does not postpone every part of implementation.

## THE FACTS

- CMS issued State Medicaid Director Letter 26-006 offering every state an optional hold-harmless period through June 30, 2027, for the new Medicaid community-engagement requirement. States may choose a shorter period or decline the option.
- A participating state must still assess whether applicants and beneficiaries meet the requirement, qualify through deemed compliance or fall within an exclusion. During the approved period, however, the state may suspend denials and disenrollments based solely on failure to demonstrate community engagement.
- The protection applies to relevant applications received and renewals initiated during the state's approved period and only to the community-engagement condition. States must obtain CMS approval through a mitigation plan and remain responsible for other eligibility rules; notices for a January 1 start are requested by December 11.
- CMS said the transition will let states test data matching, notices and eligibility systems, expand automated verification and address workforce training before enforcement. The agency still expects covered states to implement the other parts of the requirement by January 1, 2027.
- AP reported that states had faced staffing, training and technology challenges and that early Nebraska data showed most denials among people subject to the requirement were tied to missing verification rather than a finding that they had not worked. The evidence does not establish which states will elect the option or how many coverage losses it will prevent.

## SIGNIFICANCE

The guidance changes the immediate coverage consequences of a major national eligibility policy while preserving implementation and assessment duties. An optional transition may reduce erroneous losses during systems deployment, but it also leaves state-by-state variation and does not repeal the statutory requirement.

## GOALPOST / RESPONSE

Implementation should be tracked by state elections and approved mitigation plans, automated-verification rates, notices and appeals, denials and disenrollments by cause, eligible people retaining or losing coverage, administrative cost and post-transition compliance—not by the federal announcement alone.

## MAYBE / THEREFORE

Maybe the transition will prevent avoidable coverage losses while states repair systems, or uneven adoption may simply delay similar paperwork failures in some jurisdictions. Therefore the record establishes an optional, approved-plan hold-harmless pathway through June 30—not a nationwide mandatory delay, repeal of the work requirement or proof of its coverage effects.


## SOURCES

- [CMS — Medicaid work-requirement hold-harmless announcement](https://www.cms.gov/newsroom/press-releases/cms-announces-hold-harmless-period-strengthen-medicaid-work-requirement-systems-improve-beneficiary) — primary agency announcement of optional transition period and implementation rationale
- [CMS State Medicaid Director Letter 26-006 — Optional Hold Harmless Period](https://www.medicaid.gov/Federal-Policy-Guidance/Downloads/smd26006.pdf) — primary operative guidance defining optional period, approval process, scope and post-period enforcement
- [Associated Press — states receive additional Medicaid work-requirement transition time](https://apnews.com/article/medicaid-work-requirements-states-delay-680a36383fbcb2c615408a34ad41785a) — independent reporting on optional delay, implementation pressures and early coverage-loss evidence
- [KFF — Medicaid work-requirements implementation tracker](https://www.kff.org/medicaid/medicaid-work-requirements-tracker-overview/) — independent health-policy tracker confirming national scope and optional hold-harmless period

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
