# DOJ broadens its interpretation of states’ immigration-reporting duty

**Entry ID:** NAT-2026-09-02-008
**Date:** September 2, 2026
**Checked:** 2026-09-02 6:02 PM EDT
**Evidence state:** primary Justice Department announcement and Office of Legal Counsel interpretation plus independent Guardian reporting; legal position issued, state implementation and judicial review unresolved
**Review state:** current-standard-reviewed

The Office of Legal Counsel says participating states must apply a federal reporting provision across state agencies; it is an executive-branch legal interpretation, not a court ruling or proof of statewide implementation.

## THE FACTS

- The Justice Department's Office of Legal Counsel issued an interpretation of section 404 of the 1996 welfare-reform law concluding that states participating in Temporary Assistance for Needy Families and Supplemental Security Income must apply the law's reporting duty across state agencies, rather than only through the agencies administering those programs.
- The opinion reverses a 1998 Clinton-era Justice Department interpretation. It says the duty applies when a state agency knows a person is unlawfully present and rejects an artificially high requirement for a formal federal adjudication, while also saying agencies need not report suspicions unsupported by reliable information.
- The Justice Department said the interpretation does not retroactively alter prior agreements and noted that states can avoid the statutory condition by declining to participate in the covered federal programs.
- The opinion states the executive branch's view of federal law. It is not a judicial decision, does not itself establish that every state agency has begun reporting, and does not resolve possible disputes over knowledge, privacy, due process, federalism or implementation guidance.

## SIGNIFICANCE

If implemented as DOJ describes, the interpretation could expand immigration reporting from welfare offices to education, health, licensing or other state agencies that possess reliable information, changing how residents encounter state services. The practical reach depends on state procedures, federal guidance, litigation and what qualifies as actual knowledge.

## GOALPOST / RESPONSE

The administration says Congress imposed a government-wide reporting duty and that the 1998 interpretation improperly narrowed it. The strongest response is that broader reporting may deter eligible families from public services, expose lawful residents or citizens to error and press states into immigration enforcement. State directives, agency guidance, reports transmitted, error rates, program participation, court rulings and privacy safeguards are the tests.

## MAYBE / THEREFORE

Maybe the opinion will produce more consistent reporting of people state agencies reliably know are unlawfully present, or ambiguous knowledge standards and fear of enforcement may generate errors and deter lawful use of services. Therefore the record confirms a consequential new executive-branch legal interpretation—not a court-approved mandate, completed nationwide implementation or proof that any reported person is removable.


## SOURCES

- [Department of Justice — states' duty to report known unlawfully present people](https://www.justice.gov/opa/pr/justice-department-clarifies-duty-states-report-known-illegal-aliens-under-welfare-reform) — primary announcement and Office of Legal Counsel interpretation of the state reporting duty in section 404 of the 1996 welfare-reform law
- [The Guardian — DOJ directs broader state reporting of undocumented people](https://www.theguardian.com/us-news/2026/sep/02/justice-department-undocumented-immigrants-reports) — independent reporting on the new executive-branch legal interpretation, its scope and the prior 1998 interpretation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
