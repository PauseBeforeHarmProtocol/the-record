# DOJ broadens its interpretation of states’ immigration-reporting duty

**Entry ID:** NAT-2026-09-02-008
**Date:** September 2, 2026
**Checked:** 2026-09-03 12:02 AM EDT
**Evidence state:** primary Justice Department announcement and Office of Legal Counsel interpretation plus Guardian and Reuters reporting; legal position and funding warning issued, state implementation, funding action and judicial review unresolved
**Review state:** current-standard-reviewed

DOJ says participating states must report known unlawfully present people across state agencies and warns that noncompliance could jeopardize federal welfare funds; no cutoff had occurred by the review time.

## THE FACTS

- The Justice Department's Office of Legal Counsel issued an interpretation of section 404 of the 1996 welfare-reform law concluding that states participating in Temporary Assistance for Needy Families and Supplemental Security Income must apply the law's reporting duty across state agencies, rather than only through the agencies administering those programs.
- The opinion reverses a 1998 Clinton-era Justice Department interpretation. It says the duty applies when a state agency knows a person is unlawfully present and rejects an artificially high requirement for a formal federal adjudication, while also saying agencies need not report suspicions unsupported by reliable information.
- The Justice Department said the interpretation does not retroactively alter prior agreements and noted that states can avoid the statutory condition by declining to participate in the covered federal programs.
- The opinion states the executive branch's view of federal law. It is not a judicial decision, does not itself establish that every state agency has begun reporting, and does not resolve possible disputes over knowledge, privacy, due process, federalism or implementation guidance.
- Reuters reported that DOJ officials said states that fail to follow the interpretation could risk federal welfare funding. The cited programs distribute more than $16.5 billion annually in Temporary Assistance for Needy Families grants and about $60 billion in Supplemental Security Income benefits; those figures describe program scale, not money already withheld.
- All 50 states, the District of Columbia and U.S. territories participate in the covered programs. DOJ's Office of Legal Counsel opinions bind executive agencies, but the interpretation is not binding precedent for courts, and no state funding cutoff, statewide implementation finding or judicial ruling upholding the position was public by cutoff.

## SIGNIFICANCE

The funding warning gives the legal interpretation a concrete enforcement lever that could affect every state, the District of Columbia and U.S. territories and could expand immigration reporting through education, health, licensing and other agencies. The amounts describe program scale, not funds already withheld, and the practical reach depends on federal guidance, state procedures and litigation.

## GOALPOST / RESPONSE

The administration says Congress imposed a government-wide reporting condition on states choosing to participate in TANF and SSI and warns that noncompliance can carry serious funding consequences. The strongest response is that broader reporting may deter eligible families from services, expose citizens or lawful residents to error and use welfare funds to press states into immigration enforcement. Formal compliance notices, state directives, reports transmitted, funding actions, error rates, court rulings and privacy safeguards are the tests.

## MAYBE / THEREFORE

Maybe the opinion and funding warning will produce more consistent reporting based on reliable knowledge, or ambiguous standards and the scale of threatened funds may generate errors, deter lawful service use and trigger successful state challenges. Therefore the record confirms DOJ's binding executive-branch interpretation and stated funding risk—not a court-approved mandate, a completed nationwide reporting system, an actual cutoff or proof that any reported person is removable.


## SOURCES

- [Department of Justice — states' duty to report known unlawfully present people](https://www.justice.gov/opa/pr/justice-department-clarifies-duty-states-report-known-illegal-aliens-under-welfare-reform) — primary announcement and Office of Legal Counsel interpretation of the state reporting duty in section 404 of the 1996 welfare-reform law
- [The Guardian — DOJ directs broader state reporting of undocumented people](https://www.theguardian.com/us-news/2026/sep/02/justice-department-undocumented-immigrants-reports) — independent reporting on the new executive-branch legal interpretation, its scope and the prior 1998 interpretation
- [Reuters — DOJ says state noncompliance could risk federal welfare funds](https://www.reuters.com/legal/government/trumps-doj-threatens-cut-aid-states-unless-they-report-migrants-without-legal-2026-09-02/) — independent reporting on the stated funding consequence, program scale and potential state legal challenges

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
