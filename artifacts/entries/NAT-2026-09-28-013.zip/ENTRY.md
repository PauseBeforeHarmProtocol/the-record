# Judicial council dismisses complaint against judge in transgender-care subpoena dispute

**Entry ID:** NAT-2026-09-28-013
**Date:** May 14–September 28, 2026
**Checked:** 2026-11-18 12:05 PM EST
**Evidence state:** primary First Circuit judicial-misconduct order plus independent Reuters reporting connecting the anonymized order to the subpoena case; misconduct complaint dismissed, underlying merits appeal and attorney discipline unresolved
**Review state:** current-standard-reviewed

The First Circuit’s chief judge rejected claims that a Rhode Island judge acted from bias or retaliation when she criticized DOJ lawyers and referred them for possible discipline.

## THE FACTS

- In May, U.S. District Judge Mary McElroy blocked a Justice Department effort to compel Brown University Health-run Rhode Island Hospital to produce records concerning youth transgender care. In June she referred government lawyers for possible discipline over representations and omissions in the subpoena litigation. Reuters reported that the underlying ruling remains on appeal; a referral is not a disciplinary finding.
- In an order entered September 28 and made public in November, Chief Judge David Barron dismissed Judicial Misconduct Complaint No. 01-26-90041 as baseless and not cognizable. The order does not name McElroy, but Reuters matched its detailed procedural account to her case.
- Barron reviewed the underlying docket, hearing transcript and order and concluded that the record supplied no basis for further misconduct inquiry. He wrote that the challenged findings about misleading statements, withheld information and an unlawful inquiry objective were grounded in the case record, and that the attorney-discipline referral did not show bias, rage or retaliation.
- The misconduct dismissal resolves only the complaint against the judge. It does not decide the pending appeal from her subpoena ruling, whether the referred DOJ lawyers will be disciplined, whether every underlying factual finding survives review, or the lawfulness of other investigations into gender-affirming care.

## SIGNIFICANCE

A judicial-misconduct process independently rejected an effort to recast a judge’s record-based criticism and attorney referral as ethics violations. That protects adjudicative independence in a politically charged federal investigation while leaving the underlying subpoena appeal and any attorney-discipline process to their separate legal channels.

## GOALPOST / RESPONSE

The Justice Department’s underlying position is that its inquiry into hospital records was lawful and that its lawyers disputed McElroy’s characterization of their conduct. Barron’s order says a misconduct complaint cannot substitute for appellate review and found the bias and retaliation allegations unsupported by the record. The underlying appeal, any bar or court discipline decision and future subpoena rulings are the tests.

## MAYBE / THEREFORE

Maybe appellate review will narrow or reverse McElroy’s subpoena ruling even though the misconduct complaint failed, or the record will continue to support both the blocked subpoena and attorney referral. Therefore the First Circuit chief judge dismissed the complaint against McElroy—not the appeal, the attorney-discipline question or every broader dispute over transgender-care investigations.


## SOURCES

- [In re Judicial Misconduct Complaint No. 01-26-90041](https://www.ca1.uscourts.gov/sites/ca1/files/01-26-90041.O.pdf) — primary judicial-misconduct dismissal order
- [U.S. judge cleared of misconduct claims in transgender-care subpoena dispute](https://www.reuters.com/legal/government/us-judge-cleared-misconduct-claims-transgender-care-subpoena-dispute-2026-11-18/) — independent reporting identifying the underlying case and preserving appeal and discipline limits

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
