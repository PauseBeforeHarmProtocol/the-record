# United States conducts second third-country deportation flight to Central African Republic

**Entry ID:** NAT-2026-08-29-001
**Date:** June 12–August 29, 2026
**Checked:** 2026-08-29 11:59 PM EDT
**Evidence state:** Associated Press reporting based on named counsel, court documents and Human Rights First flight monitoring, plus Reuters reporting on the Central African Republic arrangement and the Department of Homeland Security response; second flight implemented, agreement terms and individual post-arrival outcomes not public
**Review state:** current-standard-reviewed

The implemented flight carried dozens from countries including Afghanistan and Iran; one Afghan passenger had protection against return to Afghanistan, not a right to remain in the United States.

## THE FACTS

- A second U.S. third-country deportation flight landed in Bangui, Central African Republic, on August 29. Associated Press reported that it carried dozens of people; Human Rights First identified 12 Afghans, eight Iranians, and people from Nepal and Nicaragua.
- One Afghan man aboard had been granted protection against removal to Afghanistan because of feared Taliban persecution, according to his lawyer and court documents reviewed by AP. His lawyer said two of his brothers had supported the U.S. military and one, a pilot trained by the United States, was killed by the Taliban. The protection barred return to Afghanistan but did not itself grant U.S. lawful status or categorically prohibit removal to another country.
- The administration began transfers to Central African Republic in June under an arrangement whose full terms remain undisclosed. Reuters reported that the Department of Homeland Security said third-country deportees receive full due process and referred questions about the agreement to the State Department. Human Rights First's flight monitoring separately documented the first June flight.
- No public U.S. flight manifest, bilateral agreement text, set of individual removal orders, or post-arrival status records was available by cutoff. The evidence establishes the flight and reported composition, not that every passenger had the same legal protection or that anyone was returned onward to a feared country.

## SIGNIFICANCE

The second flight shows that Central African Republic is functioning as an ongoing third-country destination rather than a one-off transfer. Sending people with protection against return to their home countries to a nation with which they may have no ties shifts the factual tests to notice and screening, custody, asylum access, freedom of movement, durable legal status, and safeguards against onward removal.

## GOALPOST / RESPONSE

The administration says third-country removal lawfully executes final removal orders when direct return is unavailable, that deportees receive due process, and that withholding of removal protects against a specified destination rather than every country. Publication of the agreement, individual notice and screening records, legal status and freedom of movement in Central African Republic, asylum access, custody conditions, and any onward repatriations are the tests.

## MAYBE / THEREFORE

Maybe Central African Republic provides a lawful, safer alternative to indefinite U.S. detention or return to a country of feared persecution, and the Afghan man's protection did not authorize permanent U.S. residence. Therefore the record reports a second implemented third-country flight—not proof that every removal was unlawful, that every passenger held protection, or that durable safety and legal status in Central African Republic have been established.


## SOURCES

- [Associated Press — second U.S. third-country deportation flight lands in Central African Republic](https://apnews.com/article/central-african-republic-afghan-deportation-united-states-687d053499ccdbf6a26f091219ae10fe) — independent reporting based on named counsel, court documents reviewed by AP, and Human Rights First flight monitoring
- [Reuters — Central African Republic agrees to accept U.S. third-country deportees](https://www.reuters.com/world/africa/central-african-republic-accept-third-country-deportees-us-sources-say-2026-06-07/) — independent reporting on the bilateral arrangement and Department of Homeland Security due-process response
- [Human Rights First — ICE Flight Monitor methodology and dashboard](https://www.humanrightsfirst.org/library/new-ice-flight-monitor-dashboard-brings-greater-transparency-to-ice-air-system-operating-in-darkness1) — civil-society flight-monitoring methodology using public aviation data and corroborating records

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
