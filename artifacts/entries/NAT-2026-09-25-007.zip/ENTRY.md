# Trump signs Miami Tribe land-claim jurisdiction law

**Entry ID:** NAT-2026-09-25-007
**Date:** September 25, 2026
**Checked:** 2026-09-25 5:59 PM EDT
**Evidence state:** primary White House signing statement and enrolled statutory text; special jurisdiction and claim limits enacted September 25, with filing and adjudication pending
**Review state:** current-standard-reviewed

The Court of Federal Claims may hear one Treaty of Grouseland claim without limitations defenses if filed within a year; other Illinois land claims are extinguished.

## THE FACTS

- Trump signed S. 550, concerning land claims of the Miami Tribe of Oklahoma, on September 25.
- The law gives the U.S. Court of Federal Claims jurisdiction over the Tribe's claim for compensation arising from the 1805 Treaty of Grouseland and directs the court to disregard statute-of-limitations and delay defenses.
- That jurisdiction expires one year after enactment unless the Tribe files the claim, and the law extinguishes the Tribe's other existing or future land claims in Illinois except the authorized claim.
- The statute creates a path to adjudication; it does not decide liability, recognize title, award compensation or establish that a settlement will occur.

## SIGNIFICANCE

The law opens a narrow federal judicial route for one historic treaty claim while foreclosing other Illinois land claims, materially changing both the Tribe's opportunity and its remaining legal options.

## GOALPOST / RESPONSE

Supporters can frame the law as access to a merits hearing. A timely filing, the court's jurisdictional treatment, factual findings and any judgment or settlement are the tests.

## MAYBE / THEREFORE

Maybe the court will find compensable treaty loss, or it may reject the claim after considering the merits. Therefore Congress authorized one claim to be heard—it did not determine the outcome or award a remedy.


## SOURCES

- [Congressional bills H.R. 3657, H.R. 7250, S. 550, S. 603, S. 759 and S. 790 signed into law](https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bills-h-r-3657-h-r-7250-s-550-s-603-s-759-and-s-790-signed-into-law/) — primary presidential signing statement
- [S. 550 — Miami Tribe of Oklahoma land-claim jurisdiction, enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119s550enr/pdf/BILLS-119s550enr.pdf) — primary enacted legislation; enrolled text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
