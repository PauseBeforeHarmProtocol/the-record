# Interior ends automatic protections for newly listed threatened species

**Entry ID:** NAT-2026-07-18-002
**Date:** July 17–18, 2026
**Checked:** 2026-09-09 6:01 PM EDT
**Evidence state:** official rule-position statement plus independent reporting
**Review state:** current-standard-reviewed

Threatened species will require individualized protection plans, while a separate rule adds economic-impact analysis to critical-habitat decisions.

## THE FACTS

- The Interior Department canceled the rule that automatically extended Endangered Species Act protections to plants and animals listed as threatened.
- Newly threatened species will instead require individualized protection plans, creating an interim period in which protections may not yet be in place.
- A second finalized change requires economic impacts to be considered when officials decide whether habitat is critical to a species’ survival. The change follows the July 10 rescission of the regulatory definition of “harm,” while direct injury or killing of listed wildlife remains prohibited.
- On September 9, twenty states and the District of Columbia filed two lawsuits in federal courts in Northern California challenging the harm definition, removal of default protections and critical-habitat changes as unlawful under the Endangered Species Act, National Environmental Policy Act and Administrative Procedure Act. Those are the plaintiffs’ allegations, not court findings.
- Reuters reported that complaint copies were not immediately available. No merits ruling or injunction had issued at cutoff, and the challenged rules remained in place.

## SIGNIFICANCE

The changes replace a default-protection model with case-by-case agency action and give economic considerations a more explicit role. The multistate suits move the policy into litigation but have not changed its legal effect; practical consequences will depend on plan timing, exemptions, habitat decisions, enforcement, court rulings and species outcomes.

## GOALPOST / RESPONSE

Interior says the revisions faithfully implement the statute, reduce regulatory overreach and unnecessary costs, and can improve landowner cooperation; it says the lawsuits seek to preserve prior overreach and will be vigorously defended. The plaintiff states argue the rules unlawfully weaken protections. Complaints, briefing, injunctions, merits decisions and measured conservation outcomes are the tests.

## MAYBE / THEREFORE

Maybe individualized plans and economic analysis can target protections more precisely without worsening conservation outcomes, or delay and exemptions could expose already-imperiled species to additional harm. Therefore the September 9 filings establish a new litigation stage—not that the rules are unlawful, enjoined, ecologically successful or proven to cause species decline.


## SOURCES

- [Associated Press — automatic threatened-species protections canceled](https://apnews.com/article/endangered-species-trump-extinction-0659d56d66285ca502b4e776c1782799) — independent reporting
- [Interior Department — final ESA regulation reforms](https://www.doi.gov/node/67431) — official final-rule statement
- [Interior Department — rescission of ESA “harm” definition](https://www.doi.gov/pressreleases/department-interior-restores-clear-esa-enforcement-rescinding-misguided-harm) — official administration statement
- [Reuters — states sue over revised Endangered Species Act rules](https://www.reuters.com/world/us-states-sue-trump-administration-weakening-endangered-species-protections-2026-09-09/) — independent reporting on two filed multistate lawsuits, the states’ allegations and Interior’s response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
