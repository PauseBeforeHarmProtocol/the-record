# Interior ends automatic protections for newly listed threatened species

**Entry ID:** NAT-2026-07-18-002
**Date:** July 17–18, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** official rule-position statement plus independent reporting

Threatened species will require individualized protection plans, while a separate rule adds economic-impact analysis to critical-habitat decisions.

## THE FACTS

- The Interior Department canceled the rule that automatically extended Endangered Species Act protections to plants and animals listed as threatened.
- Newly threatened species will instead require individualized protection plans, creating an interim period in which protections may not yet be in place.
- A second finalized change requires economic impacts to be considered when officials decide whether habitat is critical to a species’ survival. The change follows the July 10 rescission of the regulatory definition of “harm,” while direct injury or killing of listed wildlife remains prohibited.

## SIGNIFICANCE

The changes replace a default-protection model with case-by-case agency action and give economic considerations a more explicit role. The practical effect will depend on how quickly plans are written, what exemptions are granted, and how courts interpret the revised rules.

## GOALPOST / RESPONSE

Interior argues that prior rules created regulatory overreach, imposed unnecessary costs, and reduced incentives for landowner cooperation. Conservation groups argue that delay and industry exemptions can expose already-imperiled species to the very habitat loss driving their decline. Both claims require outcome tracking, not slogans.


## SOURCES

- [Associated Press — automatic threatened-species protections canceled](https://apnews.com/article/endangered-species-trump-extinction-0659d56d66285ca502b4e776c1782799) — independent reporting
- [Interior Department — final ESA regulation reforms](https://www.doi.gov/node/67431) — official final-rule statement
- [Interior Department — rescission of ESA “harm” definition](https://www.doi.gov/pressreleases/department-interior-restores-clear-esa-enforcement-rescinding-misguided-harm) — official administration statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
