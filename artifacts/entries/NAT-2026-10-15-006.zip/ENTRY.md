# Fourth Circuit revives Virginia school districts’ Title IX funding challenges

**Entry ID:** NAT-2026-10-15-006
**Date:** October 15, 2026
**Checked:** 2026-10-15 11:57 PM EDT
**Evidence state:** Fourth Circuit decision and independent Reuters reporting; jurisdictional dismissal reversed 2-1, merits and final funding consequences unresolved
**Review state:** current-standard-reviewed

The appellate court held Fairfax and Arlington may pursue broader equitable claims in federal district court; it did not decide whether the districts’ transgender-facilities policies comply with Title IX.

## THE FACTS

- A divided U.S. Court of Appeals for the Fourth Circuit reversed the jurisdictional dismissals of Fairfax County School Board v. McMahon and Arlington School Board v. McMahon, Nos. 25-2087 and 25-2107.
- The Education Department had found the districts’ policies allowing transgender students to use bathrooms and other facilities matching their gender identity violated Title IX, designated both districts high-risk and moved federal grants to reimbursement-only payment.
- The 2-1 appellate majority held the cases seek declarations and injunctions against future enforcement in addition to monetary relief and therefore are not confined to the Court of Federal Claims. The dissent viewed prepayment of grant funds as the suits’ focus.
- The ruling revives the challenges in Virginia federal court but does not decide whether the school policies comply with Title IX, whether the department’s interpretation is lawful or whether funding restrictions ultimately may be imposed. Neither the department nor school-board counsel immediately commented to Reuters.

## SIGNIFICANCE

The ruling restores judicial review of a funding mechanism the administration used to pressure large school districts over transgender-student policies. It is a procedural appellate win for the districts and a material check on forum-based dismissal, not a merits ruling on Title IX.

## GOALPOST / RESPONSE

The administration says Title IX requires sex-based facilities and used high-risk grant controls to enforce that view; the districts say their policies comply with federal law and seek broader equitable relief. District-court merits rulings, funding status, any en banc or Supreme Court review and actual policy changes are the tests.

## MAYBE / THEREFORE

Maybe the administration will prevail on the merits or show that grant-payment remedies belong partly in the Court of Federal Claims. Therefore the Fourth Circuit reopened the district-court path for declaratory and injunctive claims—not a final holding that the department’s Title IX interpretation or funding action is unlawful.


## SOURCES

- [Fourth Circuit — Fairfax County School Board and Arlington School Board v. McMahon decision](https://fingfx.thomsonreuters.com/gfx/legaldocs/lbpgxzxwrvq/EDUCATION_TRANSGENDER_VIRGINIA_decision.pdf) — primary appellate opinion
- [Reuters — Fourth Circuit revives Virginia school Title IX challenges](https://www.reuters.com/legal/government/virginia-schools-can-sue-us-education-dept-over-transgender-policies-us-court-2026-10-15/) — independent reporting of appellate ruling

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
