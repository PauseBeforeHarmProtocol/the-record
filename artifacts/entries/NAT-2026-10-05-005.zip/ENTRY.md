# Trump approves Army firing-squad execution for Nidal Hasan

**Entry ID:** NAT-2026-10-05-005
**Date:** October 5–8, 2026
**Checked:** 2026-10-08 5:59 PM EDT
**Evidence state:** named Pentagon and Army announcements reported by AP, earlier independently reported presidential approval, and the Army's official conviction account; date and livestream announced, execution pending
**Review state:** current-standard-reviewed

The Army scheduled the firing-squad execution for December 3 at Fort Hood, and the Pentagon said it would livestream it; habeas litigation could still delay the date.

## THE FACTS

- Pentagon spokesperson Sean Parnell said Defense Secretary Pete Hegseth recommended and President Trump approved execution by U.S. Army firing squad for former Army Major Nidal Malik Hasan. Reuters and the Associated Press independently reported the named Pentagon announcement.
- An Army court-martial convicted Hasan in 2013 of 13 counts of premeditated murder and 32 counts of attempted premeditated murder for the November 5, 2009 Fort Hood attack and sentenced him to death. The approval concerns the execution method and presidential authorization for an existing military sentence, not a new conviction.
- Acting Army Secretary Michael Obadal set the execution for December 3, 2026, at Fort Hood, Texas. The Pentagon said on October 8 that it would livestream the proceeding and would provide access details later. This is a scheduled date, not a completed execution.
- Associated Press reported that the U.S. military has not carried out an execution since 1961. Reuters reported that the administration had added firing squad, electrocution and gas as permissible federal execution methods in April amid difficulties obtaining lethal-injection drugs; method availability does not establish that every legal challenge is resolved.
- Parnell described the approval as judgment for the victims and used the attacker's asserted religious motive as the administration's rationale. No lawyer for Hasan was identified in the reviewed reporting, and the record does not infer waiver of later judicial review, clemency proceedings or method-of-execution challenges.
- Associated Press reported that Hasan may seek federal habeas review and that litigation could delay the scheduled execution. No inspected source established that remaining judicial or clemency avenues had ended.

## SIGNIFICANCE

The scheduling order and planned livestream move a long-final military death sentence from presidential method approval toward the first U.S. military execution in more than six decades. The announced date is consequential but not proof that remaining judicial or clemency review is complete.

## GOALPOST / RESPONSE

The administration says the punishment is judgment for the 13 murders and that public streaming will provide access to the proceeding. The notice to counsel and victims, habeas litigation, clemency record, protocol compliance, any date change and whether an execution occurs are the evidence tests.

## MAYBE / THEREFORE

Maybe the Army can complete the remaining legal and operational steps on December 3, or litigation, clemency or protocol challenges may delay or alter the plan. Therefore the record establishes a scheduled, livestreamed firing-squad execution—not a completed execution or proof that every avenue of review has ended.


## SOURCES

- [Reuters — Trump approves Army firing-squad execution for Nidal Hasan](https://www.reuters.com/world/us/trump-orders-firing-squad-gunman-who-killed-13-people-fort-hood-texas-2026-10-06/) — independent reporting quoting the named Pentagon spokesperson
- [Associated Press — Trump approves firing-squad execution for Fort Hood shooter](https://apnews.com/article/6ab1d9cfb936d00d17c02105ea0a0ead) — independent reporting quoting the named Pentagon spokesperson
- [U.S. Army — Hasan sentenced to death for Fort Hood attack](https://www.army.mil/article/110393/fort_hood_shooter_hasan_sentenced_to_death) — primary official account of court-martial conviction and sentence
- [Associated Press — Army sets Hasan execution date and Pentagon announces livestream](https://apnews.com/article/fort-hood-shooter-execution-pentagon-818853afc1be5c70fe41c5b781a8d559) — independent reporting of named Army and Pentagon announcements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
