# Trump keeps Hasan firing-squad date but cancels public livestream

**Entry ID:** NAT-2026-10-05-005
**Date:** October 5–15, 2026
**Checked:** 2026-10-15 11:59 AM EDT
**Evidence state:** presidential Truth Social announcement independently reported by AP, alongside prior Pentagon, Army and court-martial records; livestream reversed, execution date and method still scheduled, legal review pending
**Review state:** current-standard-reviewed

Trump reversed the Pentagon’s plan to livestream the scheduled December 3 execution; immediate victim families may attend, while habeas review and the execution itself remain pending.

## THE FACTS

- Pentagon spokesperson Sean Parnell said Defense Secretary Pete Hegseth recommended and President Trump approved execution by U.S. Army firing squad for former Army Major Nidal Malik Hasan. Reuters and the Associated Press independently reported the named Pentagon announcement.
- An Army court-martial convicted Hasan in 2013 of 13 counts of premeditated murder and 32 counts of attempted premeditated murder for the November 5, 2009 Fort Hood attack and sentenced him to death. The approval concerns the execution method and presidential authorization for an existing military sentence, not a new conviction.
- Acting Army Secretary Michael Obadal set the execution for December 3, 2026, at Fort Hood, Texas. The Pentagon said on October 8 that it would livestream the proceeding and would provide access details later. This is a scheduled date, not a completed execution.
- Associated Press reported that the U.S. military has not carried out an execution since 1961. Reuters reported that the administration had added firing squad, electrocution and gas as permissible federal execution methods in April amid difficulties obtaining lethal-injection drugs; method availability does not establish that every legal challenge is resolved.
- Parnell described the approval as judgment for the victims and used the attacker's asserted religious motive as the administration's rationale. No lawyer for Hasan was identified in the reviewed reporting, and the record does not infer waiver of later judicial review, clemency proceedings or method-of-execution challenges.
- Associated Press reported that Hasan may seek federal habeas review and that litigation could delay the scheduled execution. No inspected source established that remaining judicial or clemency avenues had ended.
- On October 15, Trump said the Pentagon would not livestream the execution. His Truth Social post is primary evidence of the presidential reversal; Associated Press independently reported the announcement and said the Pentagon declined to elaborate beyond Trump's statement.
- Trump said immediate family members of the victims may view the execution in person if they choose. The announced December 3 date and firing-squad method remain unchanged; the cancellation concerns public streaming, not completion of the execution or exhaustion of judicial and clemency review.
- Associated Press reported bipartisan criticism of the earlier streaming plan, including concern that execution footage could fuel radicalization. That opposition supplies context for the reversal; it does not establish the deterrent or radicalization effects of either approach.

## SIGNIFICANCE

Canceling the livestream reverses the administration’s most unusual public-access element while leaving the scheduled firing-squad execution in place. The distinction matters: the policy on broadcasting changed, but no execution has occurred and the remaining legal process is unresolved.

## GOALPOST / RESPONSE

Trump says many well-meaning people opposed watching the execution and now limits viewing to immediate victim families. The notice to counsel and families, habeas litigation, clemency record, protocol compliance, any date or method change and whether the execution occurs remain the evidence tests.

## MAYBE / THEREFORE

Maybe canceling the broadcast reduces the risk of spectacle or propaganda while preserving family access, or the execution plan may still change through litigation or clemency. Therefore the public livestream has been reversed; the December 3 firing-squad execution remains scheduled, not completed, and unresolved review is not treated as exhausted.


## SOURCES

- [Reuters — Trump approves Army firing-squad execution for Nidal Hasan](https://www.reuters.com/world/us/trump-orders-firing-squad-gunman-who-killed-13-people-fort-hood-texas-2026-10-06/) — independent reporting quoting the named Pentagon spokesperson
- [Associated Press — Trump approves firing-squad execution for Fort Hood shooter](https://apnews.com/article/6ab1d9cfb936d00d17c02105ea0a0ead) — independent reporting quoting the named Pentagon spokesperson
- [U.S. Army — Hasan sentenced to death for Fort Hood attack](https://www.army.mil/article/110393/fort_hood_shooter_hasan_sentenced_to_death) — primary official account of court-martial conviction and sentence
- [Associated Press — Army sets Hasan execution date and Pentagon announces livestream](https://apnews.com/article/fort-hood-shooter-execution-pentagon-818853afc1be5c70fe41c5b781a8d559) — independent reporting of named Army and Pentagon announcements
- [Donald Trump Truth Social post — Hasan execution will not be streamed](https://truthsocial.com/@realDonaldTrump/117445309638266855) — primary presidential statement; evidence of publication and announced reversal only
- [Associated Press — Trump cancels Pentagon livestream of Hasan execution](https://apnews.com/article/9b48781e88660064bf0f5aa020db8df7) — independent reporting and Pentagon response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
