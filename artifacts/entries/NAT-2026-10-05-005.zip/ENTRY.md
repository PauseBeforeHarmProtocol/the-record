# Trump approves Army firing-squad execution for Nidal Hasan

**Entry ID:** NAT-2026-10-05-005
**Date:** October 5, 2026
**Checked:** 2026-10-06 5:57 AM EDT
**Evidence state:** named Pentagon announcement independently reported by Reuters and AP plus the Army's official conviction and sentence account; method approved, scheduling and execution pending
**Review state:** current-standard-reviewed

The president approved the method on the defense secretary's recommendation; the Army secretary had not yet set a time or place and no execution had occurred.

## THE FACTS

- Pentagon spokesperson Sean Parnell said Defense Secretary Pete Hegseth recommended and President Trump approved execution by U.S. Army firing squad for former Army Major Nidal Malik Hasan. Reuters and the Associated Press independently reported the named Pentagon announcement.
- An Army court-martial convicted Hasan in 2013 of 13 counts of premeditated murder and 32 counts of attempted premeditated murder for the November 5, 2009 Fort Hood attack and sentenced him to death. The approval concerns the execution method and presidential authorization for an existing military sentence, not a new conviction.
- Parnell said the Secretary of the Army would set the time and place. Neither outlet reported a scheduled date or location by cutoff, and the order had not been carried out.
- Associated Press reported that the U.S. military has not carried out an execution since 1961. Reuters reported that the administration had added firing squad, electrocution and gas as permissible federal execution methods in April amid difficulties obtaining lethal-injection drugs; method availability does not establish that every legal challenge is resolved.
- Parnell described the approval as judgment for the victims and used the attacker's asserted religious motive as the administration's rationale. No lawyer for Hasan was identified in the reviewed reporting, and the record does not infer waiver of later judicial review, clemency proceedings or method-of-execution challenges.

## SIGNIFICANCE

The approval moves a long-final military death sentence toward the first U.S. military execution in more than six decades and selects a method newly emphasized by the administration, while leaving scheduling and any remaining legal process unresolved.

## GOALPOST / RESPONSE

The administration says the punishment is justified by the 13 murders and the final court-martial sentence. The Army secretary's scheduling order, notice to counsel and victims, clemency record, judicial review, protocol compliance and whether an execution occurs are the evidence tests.

## MAYBE / THEREFORE

Maybe the Army can complete the remaining legal and operational steps and carry out the sentence, or litigation or clemency may delay or alter it. Therefore the record establishes presidential approval of an Army firing squad for an existing death sentence—not a completed execution, a newly adjudicated conviction or a fixed execution date.


## SOURCES

- [Reuters — Trump approves Army firing-squad execution for Nidal Hasan](https://www.reuters.com/world/us/trump-orders-firing-squad-gunman-who-killed-13-people-fort-hood-texas-2026-10-06/) — independent reporting quoting the named Pentagon spokesperson
- [Associated Press — Trump approves firing-squad execution for Fort Hood shooter](https://apnews.com/article/6ab1d9cfb936d00d17c02105ea0a0ead) — independent reporting quoting the named Pentagon spokesperson
- [U.S. Army — Hasan sentenced to death for Fort Hood attack](https://www.army.mil/article/110393/fort_hood_shooter_hasan_sentenced_to_death) — primary official account of court-martial conviction and sentence

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
