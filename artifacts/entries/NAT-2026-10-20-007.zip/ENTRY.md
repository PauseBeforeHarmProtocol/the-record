# Interior asks court to return New England Wind permit for reconsideration

**Entry ID:** NAT-2026-10-20-007
**Date:** October 20, 2026
**Checked:** 2026-10-22 12:02 AM EDT
**Evidence state:** Associated Press review of the filed federal motion, project status and on-record Interior response; the motion itself was not independently retrieved by cutoff, and no court disposition or new agency decision had issued
**Review state:** current-standard-reviewed

The administration formally requested remand of the project's construction-and-operations approval, citing adverse impacts; the court had not ruled and the permit had not been revoked by cutoff.

## THE FACTS

- Federal defendants filed a motion on October 20 asking the U.S. District Court for the District of Columbia to remand the Bureau of Ocean Energy Management's 2024 approval of New England Wind's construction and operations plan to Interior for a new decision. The request was made in litigation brought by ACK for Whales and concerns a federal permit, not a completed cancellation.
- Associated Press reported that the planned project off Massachusetts could include as many as 129 turbines and supply up to 2,600 megawatts, with construction not yet begun. The developer, Avangrid, declined to comment; the underlying plaintiffs allege the federal approval violated multiple statutes.
- The administration told the court remand was warranted because the plan had been approved despite major adverse impacts. Interior said the filing complied with a briefing schedule, did not announce a new policy change and was consistent with the administration's prior offshore-wind position.
- The filing makes New England Wind the fourth offshore-wind project the administration had recently targeted through permit reconsideration. A prior request to revisit the related SouthCoast Wind approval had already been granted, while other projects remained in separate legal and agency proceedings; those outcomes do not decide this motion.
- By cutoff, the court had not granted remand, Interior had not issued a new permit decision and no construction, generation, cost or reliability consequence from this request had been measured. The record therefore treats the action as a formal litigation and permitting proposal, not revocation or project termination.

## SIGNIFICANCE

A court-filed remand request can reopen a foundational federal approval and create material financing and development uncertainty even before a judge rules. Because the permit remained in force and construction had not begun, the practical effect depends on the court's disposition, Interior's new review and any resulting conditions, revocation or delay.

## GOALPOST / RESPONSE

Interior says reconsideration is warranted because the prior approval did not adequately account for major adverse impacts and says the filing is consistent with its established policy. The tests are the court's remand ruling, whether the permit remains effective during review, Interior's documented analysis and final decision, litigation outcomes, project financing and any measured grid, rate or environmental effects.

## MAYBE / THEREFORE

Maybe a new review corrects material statutory or environmental deficiencies, or the remand request may function as another route to delay a disfavored energy technology without a completed merits showing. Therefore the record establishes a formal request to reconsider the permit—not a judicial remand, revoked approval, canceled project or measured energy outcome.


## SOURCES

- [Associated Press — Interior seeks remand of New England Wind permit approval](https://apnews.com/article/trump-offshore-wind-energy-projects-fossil-fuels-2240e0178af111dfcff46c902cb646e2) — independent review of the filed federal remand motion, project status and Interior response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
