# DHS orders DeepSeek products removed from civilian executive-branch systems

**Entry ID:** NAT-2026-10-19-003
**Date:** October 19, 2026
**Checked:** 2026-10-19 12:02 PM EDT
**Evidence state:** Federal Register public-inspection order and independent Reuters reporting; exclusion ordered and timetable verified, agency implementation and security outcomes unresolved
**Review state:** current-standard-reviewed

The five-year supply-chain order halts new acquisitions within 30 days, requires inventories within 60 days and sets a 180-day removal deadline; completion and claimed security risks remain to be tested.

## THE FACTS

- A Department of Homeland Security supply-chain security order was filed for public inspection on October 19 under the Federal Acquisition Supply Chain Security Act. The order excludes DeepSeek products from federal civilian executive-branch information systems and directs agencies to stop acquiring covered products within 30 days.
- Covered agencies must inventory and report affected products within 60 days and remove them within 180 days. The order covers DeepSeek, listed affiliates including High-Flyer, and third-party products or services developed with DeepSeek implementations; it remains in effect for five years unless modified or rescinded.
- DHS said covered technology creates national-security and supply-chain risks, including possible data transfer to the People's Republic of China and software vulnerabilities. Those are the department's findings supporting the order; the archive does not independently establish every alleged vulnerability or data flow.
- The order was signed July 24 and became publicly inspectable on October 19, with Federal Register publication scheduled for October 20. The acquisition ban and removal timetable are ordered, but agency inventories, exceptions, completed removals, procurement effects and security outcomes were not yet available.

## SIGNIFICANCE

The order applies a government-wide supply-chain authority to a widely used Chinese AI provider and reaches embedded third-party implementations, creating procurement, inventory and removal duties across civilian agencies. Its operational breadth and cybersecurity value depend on agency identification, exceptions, vendor substitution and verified completion.

## GOALPOST / RESPONSE

DHS says exclusion reduces espionage, data and software-supply-chain risk. Agency inventories, disclosed waivers or exceptions, acquisition records, removal completion, replacement costs, service disruption, incident evidence and oversight findings are the tests.

## MAYBE / THEREFORE

Maybe the phased exclusion reduces a material foreign-technology risk, or broad definitions and embedded dependencies may make implementation costly or incomplete. Therefore DHS issued a binding five-year order with deadlines—not that every covered product has already been found, removed or proven to have transferred federal data.


## SOURCES

- [Federal Register public inspection — DHS DeepSeek exclusion and removal order](https://www.federalregister.gov/public-inspection/2026-21447/order-exclusion-and-removal-of-deepseek-products-from-federal-civilian-executive-branch-information) — primary supply-chain security order and implementation schedule
- [Reuters — U.S. orders DeepSeek removed from civilian executive-branch systems](https://www.reuters.com/technology/us-banning-chinese-ai-deepseek-government-agency-it-systems-2026-10-19/) — independent reporting on the DHS order, scope and deadlines

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
