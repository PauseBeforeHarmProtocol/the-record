# CFTC opens rulemaking toward federal retail crypto-market framework

**Entry ID:** NAT-2026-10-13-003
**Date:** October 5–13, 2026
**Checked:** 2026-10-13 12:05 PM EDT
**Evidence state:** primary CFTC advance notice and announcement plus independent reporting; policy options proposed for comment, no final obligations or outcomes
**Review state:** current-standard-reviewed

The advance notice sketches transaction and market rules but imposes no new obligation; comments are due December 14.

## THE FACTS

- The CFTC announced an advance notice of proposed rulemaking on October 5 and formally published it October 13. It seeks comment on a comprehensive framework for retail crypto-asset transactions offered on a leveraged, margined or financed basis under Commodity Exchange Act section 2(c)(2)(D). Comments are due December 14, 2026.
- The notice contemplates Regulation Crypto Asset Transactions and Regulation Crypto Asset Markets, including a possible Crypto Asset Market subcategory of designated contract market registration. It asks about trading, intermediation, clearing, custody, margin, operational risk, systems safeguards, surveillance, reporting and proof-of-reserves mechanisms.
- The filing explores possible dual registrations and exemptions, limited-purpose futures commission merchant functions, eligible collateral and liquidation rules. It is an advance notice seeking information; it does not itself create the contemplated categories, register a platform or impose new customer, custody or margin requirements.
- Chairman Michael Selig says a uniform national framework could provide clarity, certainty and consumer protection while supporting innovation and competition. The notice also identifies market failures and fragmented oversight as problems; the costs, legal boundaries and effects of any eventual proposal remain unresolved.

## SIGNIFICANCE

The notice is a formal first stage toward placing a large segment of retail crypto trading inside a tailored federal market structure. The breadth is consequential, but the agency has not selected final rules and Congress, courts and other regulators may affect its authority and design.

## GOALPOST / RESPONSE

The CFTC says fit-for-purpose rules can protect customers, improve market integrity and reduce fragmented regulation without suppressing innovation. A proposed and final text, statutory authority, registration uptake, custody and reserve failures, customer losses, market concentration, compliance cost and judicial review are the tests.

## MAYBE / THEREFORE

Maybe a national framework reduces regulatory gaps and customer risk, or agency-defined categories may exceed existing authority, duplicate other regimes or entrench large intermediaries. Therefore the Commission has opened an advance rulemaking and described options—not adopted a crypto-market regime or demonstrated its effects.


## SOURCES

- [Federal Register — Regulation Crypto Asset Transactions and Regulation Crypto Asset Markets ANPRM](https://www.govinfo.gov/content/pkg/FR-2026-10-13/html/2026-20888.htm) — primary advance notice of proposed rulemaking and request for comment
- [CFTC — seeks comment on crypto asset transaction and market regulation](https://www.cftc.gov/PressRoom/PressReleases/9307-26) — primary agency announcement and stated rationale
- [Reuters — CFTC proposes federal crypto oversight framework](https://www.reuters.com/world/us-commodities-regulator-proposes-new-federal-crypto-oversight-rules-2026-10-05/) — independent regulatory reporting and market context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
