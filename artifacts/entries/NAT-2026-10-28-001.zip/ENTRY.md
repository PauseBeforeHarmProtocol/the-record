# Treasury sanctions Rwanda’s defense ministry and Zigama over eastern Congo conflict

**Entry ID:** NAT-2026-10-28-001
**Date:** October 28, 2026
**Checked:** 2026-10-28 12:10 PM EDT
**Evidence state:** Original OFAC additions and Treasury release, independently corroborated by Reuters. Implemented designation; allegations and effectiveness unresolved.
**Review state:** current-standard-reviewed

SDN additions impose U.S. blocking restrictions; allegations and peace outcomes remain distinct from the legal designation.

## THE FACTS

- OFAC added Rwanda’s Ministry of Defence and Zigama Credit and Savings Society to its SDN list on October 28 under the DRC sanctions program. Treasury identifies Executive Order 13413, as amended, as the designation authority.
- Treasury alleges the ministry supports the previously designated Rwanda Defence Force and that Zigama facilitates military payments and support to M23 and its political wing. These are Treasury’s administrative grounds, not criminal convictions established here.
- The action blocks covered property within U.S. jurisdiction and generally restricts U.S.-person transactions, subject to licenses and exemptions. No frozen-dollar total or withdrawal of troops is established. Reuters corroborates the action, reports Rwanda denies supporting the rebels, and says fresh government and Zigama comment requests went unanswered.

## SIGNIFICANCE

The designations expand financial pressure on a foreign defense ministry and bank. Their legal effect is distinct from whether they change battlefield conduct or deliver peace.

## GOALPOST / RESPONSE

Treasury says the sanctions enforce commitments under the Washington Accords and seek an end to support for M23 and withdrawal from eastern DRC. That is the administration’s stated objective, not a measured result.

## MAYBE / THEREFORE

Maybe financial pressure changes incentives, or evasion and conflict dynamics limit its effect. Therefore record implemented sanctions and attributed allegations, not a proven peace settlement or quantified financial disruption.


## SOURCES

- [North Korea and DRC-related SDN additions](https://ofac.treasury.gov/recent-actions/20261028) — primary sanctions list update
- [Treasury sanctions Rwandan Ministry of Defence and Zigama](https://home.treasury.gov/news/press-releases/sb0668/) — primary designation announcement
- [U.S. sanctions Rwanda defense ministry over Congo conflict](https://www.reuters.com/world/africa/us-imposes-sanctions-rwandas-ministry-defense-2026-10-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
