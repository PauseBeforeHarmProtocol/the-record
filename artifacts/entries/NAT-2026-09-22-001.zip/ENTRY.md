# FDIC proposes new bank-merger review and deemed-approval framework

**Entry ID:** NAT-2026-09-22-001
**Date:** September 22, 2026
**Checked:** 2026-09-22 5:57 AM EDT
**Evidence state:** complete Federal Register proposed rule; formal proposal and comment deadline documented, final rule, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The proposal would revise competitive analysis, create a letter filing and deemed approval for qualifying de minimis transactions, and tailor other review requirements; it is not final or implemented.

## THE FACTS

- The FDIC published a proposed Bank Merger Act rule on September 22 after board approval on September 17. Comments are due November 23, 2026; the notice does not establish a final rule, effective date or approval of any particular merger.
- For qualifying de minimis transactions, the proposal would create a shorter letter filing and deemed approval after specified processing periods. Eligibility would depend on transaction, size, condition and supervisory criteria, and the FDIC could remove a filing from expedited processing when adverse information, a material protest or other good cause warrants more review.
- The proposal would revise competitive-effects screening to account for credit-union shares and centrally booked deposits, add safe harbors, and codify how the FDIC evaluates statutory factors including competition, financial resources, managerial resources, convenience and needs, financial stability, anti-money-laundering effectiveness and Deposit Insurance Fund risk.
- The FDIC says the changes are intended to make review faster, more predictable and better aligned with modern competition while retaining scrutiny where risks warrant it. Those are the agency's stated aims; the proposal has not shortened an actual review, approved a merger or produced a measured competition, stability or community outcome.

## SIGNIFICANCE

If finalized, the rule would materially change how the federal deposit insurer screens and times bank-merger applications, including when a small transaction can proceed without an affirmative approval order. The competitive, supervisory and community effects depend on the final text and later cases.

## GOALPOST / RESPONSE

The FDIC argues that the framework recognizes credit unions and modern deposit booking, reduces unnecessary burden and preserves case-specific escalation. Commenters can test the de minimis thresholds, deemed-approval safeguards, market definitions and statutory-factor standards; the final rule, implementation data, merger outcomes and competition or service measurements are the goalposts.

## MAYBE / THEREFORE

Maybe a more tailored process speeds low-risk combinations while focusing staff on consequential cases, or deemed approval and broader safe harbors could reduce scrutiny that later proves important. Therefore the FDIC has proposed a detailed merger-review framework for comment—not adopted it, approved any merger under it or demonstrated its effects.


## SOURCES

- [Federal Register — FDIC proposed rule on merger transactions](https://www.govinfo.gov/content/pkg/FR-2026-09-22/pdf/2026-19308.pdf) — primary proposed rule (91 FR 60196; FR Doc. 2026-19308)

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
