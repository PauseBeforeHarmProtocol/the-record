# U.S. military completes withdrawal from Iraq and ends coalition mission

**Entry ID:** NAT-2026-09-30-001
**Date:** September 30, 2026
**Checked:** 2026-09-30 6:00 AM EDT
**Evidence state:** official U.S. Central Command completion announcement plus independent Associated Press and Reuters reporting with Iraqi, Kurdish and Pentagon positions; withdrawal completed, downstream security effects unresolved
**Review state:** current-standard-reviewed

The final U.S. forces and equipment left Erbil Air Base, concluding Operation Inherent Resolve in Iraq while a narrower bilateral support relationship continues.

## THE FACTS

- U.S. Central Command announced that U.S. forces and equipment completed an orderly departure from Erbil Air Base on September 30, marking the end of the Operation Inherent Resolve coalition mission in Iraq.
- The withdrawal completed a 2024 U.S.-Iraq agreement to wind down the mission against the Islamic State group. Most U.S. forces had previously left other Iraqi bases, while hundreds remained in the semi-autonomous Kurdish region until the final departure.
- The Pentagon said the change transitions from a wartime coalition mission to an Iraqi-led security effort and a more normal bilateral relationship. Reuters reported that the United States plans to continue targeted training and intelligence support to Iraqi partners.
- Iraq's government presented the handover as a sovereignty milestone and said its forces would continue fighting Islamic State remnants. Kurdish officials expressed concern about losing U.S. air-defense support, and Iran-aligned militias celebrated the departure.
- The mission's conclusion does not establish that Islamic State cells or militia influence have ended, that every form of U.S. military assistance has ceased, or that the future bilateral arrangement has produced measurable security outcomes.

## SIGNIFICANCE

The completed departure ends a twelve-year coalition combat mission and materially changes the U.S. military footprint in Iraq during an active regional conflict. It transfers primary responsibility to Iraqi forces while leaving narrower security cooperation in place.

## GOALPOST / RESPONSE

The Pentagon says the mission defeated ISIS as an organized military threat and that Iraqi forces can lead with targeted U.S. support. The strongest response is that Kurdish and Iraqi observers warn about Islamic State sleeper cells, militia leverage and reduced air-defense capacity. Force levels, attack data, Iraqi operations, intelligence cooperation, militia disarmament and any renewed deployment are the tests.

## MAYBE / THEREFORE

Maybe Iraqi forces and bilateral support can contain Islamic State and reduce dependence on a foreign military presence, or the withdrawal may create security gaps exploited by extremist or Iran-aligned groups. Therefore the record establishes completed withdrawal and formal mission termination—not the disappearance of every U.S. security role or proof of either durable stability or a security vacuum.


## SOURCES

- [U.S. Central Command — U.S. forces end Operation Inherent Resolve mission in Iraq](https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4614532/us-forces-end-operation-inherent-resolve-mission-in-iraq/) — official completion announcement
- [Associated Press — U.S. military completes Iraq withdrawal](https://apnews.com/article/a097a39f3d1a3515adc2ba3298a6816f) — independent reporting with Pentagon, Iraqi, Kurdish and militia responses
- [Reuters — U.S. forces end Iraq mission](https://www.reuters.com/world/us-forces-exit-iraq-emboldening-irans-proxies-islamic-state-2026-09-30/) — independent reporting on completed withdrawal, continuing support and security risks

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
