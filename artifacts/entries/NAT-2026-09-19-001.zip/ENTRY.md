# Trump announces planned AI Force and future AI czar

**Entry ID:** NAT-2026-09-19-001
**Date:** September 19, 2026
**Checked:** 2026-09-19 6:01 PM EDT
**Evidence state:** complete retained presidential post plus independent Reuters reporting; proposal announced, structure, authority, personnel and implementation absent by cutoff
**Review state:** current-standard-reviewed

The president announced a new federal AI coordinating body and future adviser but published no order, charter, agency placement, authority, budget or appointment.

## THE FACTS

- President Trump wrote on Truth Social that he was 'forming the AI Force' and would announce an AI 'Czar' in the near future. The post is primary evidence of his policy announcement and intent; it is not an executive order, appointment or proof that a government body became operational.
- Trump said the administration would not hinder AI-industry growth and would look for harmful conduct through the existing criminal and civil justice system. His claim that AI could reach 25% of U.S. gross domestic product is an administration projection, not an independently measured outcome.
- Reuters independently confirmed the announcement and reported that Trump supplied no implementation details and the White House did not immediately respond to a request for comment. No charter, member list, department, military or civilian status, statutory authority, funding, reporting line or effective date was public by cutoff.
- Existing federal AI offices, councils and advisers are not automatically replaced or reorganized by a social-media announcement. A later written instrument could define the AI Force or rebrand existing coordination, but neither result had occurred in the inspected record.

## SIGNIFICANCE

A presidential AI coordinating body and czar could shape federal AI promotion, safety, enforcement and competition policy. Without an operative instrument or defined authority, the announcement signals policy direction but does not yet establish institutional power or measurable effect.

## GOALPOST / RESPONSE

Trump says rapid AI growth should be protected and existing civil and criminal law can address harmful conduct. A signed order or memorandum, public charter, agency placement, named appointee, membership, budget, authorities, rules, enforcement actions and measured economic and safety outcomes are the tests.

## MAYBE / THEREFORE

Maybe a later order will create a new cross-agency institution, or the label may consolidate or rebrand existing AI coordination without new legal authority. Therefore Trump announced an intended AI Force and future czar—not an operational entity, completed appointment, new enforcement power or verified economic outcome.


## SOURCES

- [Donald Trump Truth Social post announcing planned AI Force and AI czar](https://truthsocial.com/@realDonaldTrump/117298821562014906) — primary presidential statement
- [Reuters — Trump says he will create AI Force and name AI czar](https://www.reuters.com/world/us/trump-says-he-will-create-ai-force-name-ai-czar-2026-09-19/) — independent reporting on a presidential policy announcement and missing implementation details

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
