# Super Intelligence Force adopts charter and begins 120-day review

**Entry ID:** NAT-2026-09-19-001
**Date:** September 19–October 15, 2026
**Checked:** 2026-10-16 5:57 AM EDT
**Evidence state:** presidential formation statements and prior AP, Reuters and WSJ reporting, plus Semafor's October 15 account based on an announcement shared with it and a White House official statement; charter adoption and workstreams reported, public charter instrument and measured outcomes not retrieved
**Review state:** current-standard-reviewed

Semafor reported that the White House task force formally adopted a charter, commissioned a three-part PCAST risk review and created implementation and coordination workstreams. The charter text, enforcement mechanism, funding and outcomes were not independently retrieved.

## THE FACTS

- President Trump wrote on Truth Social that he was 'forming the AI Force' and would announce an AI 'Czar' in the near future. The post is primary evidence of his policy announcement and intent; it is not an executive order, appointment or proof that a government body became operational.
- Trump said the administration would not hinder AI-industry growth and would look for harmful conduct through the existing criminal and civil justice system. His claim that AI could reach 25% of U.S. gross domestic product is an administration projection, not an independently measured outcome.
- In an October 4 Truth Social post, Trump announced the formation of the Super Intelligence Force and named Jay Clayton, Andrew Ferguson, Emil Michael and Scott Kupor as its leaders. AP and Reuters independently reported the announcement.
- Trump said the task force would coordinate federal engagement with consumers, public-interest and religious groups, critical-infrastructure providers and AI companies, and report to the president and Chief of Staff Susie Wiles.
- Clayton told the Wall Street Journal the group would have 120 days to assess AI risks and opportunities and recommend the federal government’s role. Reuters reported that the Journal’s account of the charter included reviewing incident-reporting mechanisms and recommending stronger responses under existing authorities.
- Semafor reported on October 15 that the task force formally adopted its charter after its first official meeting, starting the previously described 120-day window. The underlying charter was not publicly retrieved in this review, so adoption and scope remain reported rather than independently authenticated from the instrument.
- According to the reported White House announcement, the task force commissioned the President's Council of Advisers on Science and Technology to assess cybersecurity and critical-infrastructure protection, biosecurity and dual-use applications, and model control and accountability.
- Semafor reported that the task force created a working group to implement the voluntary White House Accord, an effort to develop incident-reporting protocols for AI labs, and a Justice Department–FTC law-enforcement and consumer-protection coordination committee.
- Semafor also reported that it remained unclear how compliance would be enforced or how current law would apply to companies that did not follow new protocols. A White House official identified export controls as one possible tool, not as an ordered enforcement action.

## SIGNIFICANCE

A reported adopted charter, first official meeting and assigned workstreams move the task force beyond a leadership announcement into an operational review stage. The material still does not establish new statutory powers, appropriations, binding duties for private firms or completed safety and economic outcomes.

## GOALPOST / RESPONSE

The White House says the task force will protect Americans, implement its voluntary Accord and preserve U.S. technological leadership. Publication of the charter and PCAST report, disclosed authorities and budgets, adopted incident protocols, company participation, enforcement decisions and measured security, competition and labor outcomes are the tests.

## MAYBE / THEREFORE

Maybe the chartered review and specialized workstreams produce usable risk controls and better interagency coordination, or they may largely reorganize existing authorities around voluntary commitments. Therefore the task force's charter adoption, first meeting and workstreams are reported and the 120-day review has begun; public charter text, binding enforcement, new funding and effectiveness remain unverified.


## SOURCES

- [Donald Trump Truth Social post announcing planned AI Force and AI czar](https://truthsocial.com/@realDonaldTrump/117298821562014906) — primary presidential statement
- [Reuters — Trump says he will create AI Force and name AI czar](https://www.reuters.com/world/us/trump-says-he-will-create-ai-force-name-ai-czar-2026-09-19/) — independent reporting on a presidential policy announcement and missing implementation details
- [Donald Trump — Super Intelligence Force formation and leadership announcement](https://truthsocial.com/@realDonaldTrump/117382616783706638) — primary presidential statement; formation and coordination mission announced
- [AP — Jay Clayton to lead federal AI task force](https://apnews.com/article/trump-jay-clayton-artificial-intelligence-task-force-b8689ea07de9102a52bd1cd2049b5901) — independent reporting on publicly announced leadership and reporting line
- [Reuters — Clayton named AI czar and Super Intelligence Force head](https://www.marketscreener.com/news/latest/Trump-names-intelligence-chief-Clayton-as-AI-czar-to-head-task-force-12373826/) — independent reporting on formation and leadership; WSJ charter account explicitly attributed
- [WSJ — Clayton outlines 120-day White House AI task-force review](https://www.wsj.com/tech/ai/new-ai-task-force-to-report-on-risks-of-technology-after-public-and-industry-concerns-b6308bef) — named task-force-head interview; accessible excerpt inspected, full article unavailable
- [Semafor — White House AI task force adopts charter and workstreams](https://www.semafor.com/article/10/15/2026/white-houses-ai-task-force-gets-to-work) — independent reporting based on a White House announcement and named institutional workstreams; public charter text not retrieved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
