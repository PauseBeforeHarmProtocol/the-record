# Trump names Super Intelligence Force leaders; 120-day review reported

**Entry ID:** NAT-2026-09-19-001
**Date:** September 19–October 4, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** retained October 4 presidential post plus independent AP and Reuters reporting and the accessible named-Clayton WSJ interview excerpt; formation and leaders announced, 120-day review reported. Reuters reports WSJ reviewed a charter; this run did not retrieve a public signed charter or funding/authority instrument and does not claim none exists.
**Review state:** current-standard-reviewed

Trump publicly named Clayton, Ferguson, Michael and Kupor to coordinate federal AI policy and report to him and Susie Wiles. Clayton described a 120-day risk-and-opportunity review; new powers, funding and measured results remain unverified.

## THE FACTS

- President Trump wrote on Truth Social that he was 'forming the AI Force' and would announce an AI 'Czar' in the near future. The post is primary evidence of his policy announcement and intent; it is not an executive order, appointment or proof that a government body became operational.
- Trump said the administration would not hinder AI-industry growth and would look for harmful conduct through the existing criminal and civil justice system. His claim that AI could reach 25% of U.S. gross domestic product is an administration projection, not an independently measured outcome.
- In an October 4 Truth Social post, Trump announced the formation of the Super Intelligence Force and named Jay Clayton, Andrew Ferguson, Emil Michael and Scott Kupor as its leaders. AP and Reuters independently reported the announcement.
- Trump said the task force would coordinate federal engagement with consumers, public-interest and religious groups, critical-infrastructure providers and AI companies, and report to the president and Chief of Staff Susie Wiles.
- Clayton told the Wall Street Journal the group would have 120 days to assess AI risks and opportunities and recommend the federal government’s role. Reuters reported that the Journal’s account of the charter included reviewing incident-reporting mechanisms and recommending stronger responses under existing authorities.

## SIGNIFICANCE

Naming leaders and a presidential reporting line makes the earlier AI Force proposal materially more concrete. The announced coordinating and review mandate could influence AI oversight, but it does not itself demonstrate new legal powers, additional appropriations or completed safety and economic outcomes.

## GOALPOST / RESPONSE

Trump frames the task force as protecting Americans while maintaining U.S. technological leadership. Clayton describes a time-limited assessment of risks, opportunities and federal responsibility. A retrieved public charter, authorities, budget, reporting deadlines, published recommendations, subsequent decisions and measured outcomes are the tests.

## MAYBE / THEREFORE

Maybe coordination and a 120-day assessment identify actionable risks and improve federal responses, or the body may primarily consolidate existing offices without changing effective oversight. Therefore leadership and a reporting line are publicly announced and a review deadline is reported; new powers, funding, completed implementation and effectiveness are not established by the material inspected.


## SOURCES

- [Donald Trump Truth Social post announcing planned AI Force and AI czar](https://truthsocial.com/@realDonaldTrump/117298821562014906) — primary presidential statement
- [Reuters — Trump says he will create AI Force and name AI czar](https://www.reuters.com/world/us/trump-says-he-will-create-ai-force-name-ai-czar-2026-09-19/) — independent reporting on a presidential policy announcement and missing implementation details
- [Donald Trump — Super Intelligence Force formation and leadership announcement](https://truthsocial.com/@realDonaldTrump/117382616783706638) — primary presidential statement; formation and coordination mission announced
- [AP — Jay Clayton to lead federal AI task force](https://apnews.com/article/trump-jay-clayton-artificial-intelligence-task-force-b8689ea07de9102a52bd1cd2049b5901) — independent reporting on publicly announced leadership and reporting line
- [Reuters — Clayton named AI czar and Super Intelligence Force head](https://www.marketscreener.com/news/latest/Trump-names-intelligence-chief-Clayton-as-AI-czar-to-head-task-force-12373826/) — independent reporting on formation and leadership; WSJ charter account explicitly attributed
- [WSJ — Clayton outlines 120-day White House AI task-force review](https://www.wsj.com/tech/ai/new-ai-task-force-to-report-on-risks-of-technology-after-public-and-industry-concerns-b6308bef) — named task-force-head interview; accessible excerpt inspected, full article unavailable

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
