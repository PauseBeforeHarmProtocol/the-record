# Trump signs annual disclosure law for major delayed or over-budget projects

**Entry ID:** NAT-2026-10-07-007
**Date:** October 7, 2026
**Checked:** 2026-10-07 6:04 PM EDT
**Evidence state:** official White House signing statement and enrolled statutory text; enacted, reporting implementation pending
**Review state:** current-standard-reviewed

OMB must issue guidance within one year and publish annual project-level reports; direct-spending projects are excluded.

## THE FACTS

- Trump signed S. 766, the Billion Dollar Boondoggle Act of 2025, on October 7. The law covers executive and independent regulatory agencies and requires annual reporting for projects that are more than five years behind their original completion schedule or at least $1 billion above their original cost estimate.
- Within one year of enactment, the Office of Management and Budget director must issue guidance requiring agencies to submit project descriptions, locations, award numbers, dates, contractors and recipients, scope changes, completion dates, inflation-adjusted original and current cost estimates, explanations for delay or cost growth, and any incentive or bonus payments.
- OMB must submit the collected information to Congress and post an annual report on its website. The definition includes major acquisitions, defense acquisition programs, procurement, construction, remediation and other time-limited endeavors, but excludes projects funded through direct spending.
- The law creates a disclosure process; it does not itself cancel, restructure or recover money from a covered project, and no first annual report was due or available by cutoff.

## SIGNIFICANCE

The statute could make extreme federal schedule delays and cost growth easier to identify across agencies and contractors. Its reach is narrowed by high thresholds and the exclusion of direct-spending projects, and disclosure alone does not correct an overrun.

## GOALPOST / RESPONSE

The law’s transparency rationale should be tested against timely OMB guidance, complete agency submissions, usable project identifiers, consistent inflation adjustments, public accessibility and documented follow-up by agencies or Congress.

## MAYBE / THEREFORE

Maybe a recurring public list creates pressure to correct entrenched overruns, or agencies may report only a small threshold-defined subset without changing project outcomes. Therefore the reporting mandate is enacted, while coverage quality, compliance and any savings remain unmeasured.


## SOURCES

- [White House — H.R. 5345 and S. 766 signed into law](https://www.whitehouse.gov/briefings-statements/2026/10/congressional-bills-h-r-5345-and-s-766-signed-into-law/) — official bill-signing statement
- [GovInfo — S. 766 enrolled bill](https://www.govinfo.gov/content/pkg/BILLS-119s766enr/html/BILLS-119s766enr.htm) — official enrolled bill text

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
