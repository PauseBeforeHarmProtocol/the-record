# Trump expands Interior and Energy authority under the Defense Production Act

**Entry ID:** NAT-2026-09-08-009
**Date:** September 8, 2026
**Checked:** 2026-09-08 11:58 PM EDT
**Evidence state:** primary White House executive order; signed delegation change, no project-specific implementation or independently measured result identified
**Review state:** current-standard-reviewed

The signed order redistributes delegated energy and industrial-resource authority; it does not itself prioritize a contract, compel production or spend money.

## THE FACTS

- Trump signed an executive order amending the national-defense resources framework so the Interior and Energy secretaries may each independently exercise delegated Defense Production Act priority and allocation authority over forms of energy under their respective purview. It likewise delegates specified section 101(c) authority independently to Interior, Commerce and Energy.
- Energy-related disputes between Interior and Energy are sent first to the National Energy Dominance Council. Matters involving defense infrastructure or military operations also go to the National Security Council, with both councils coordinating with the Department of War. The order is subject to applicable law and available appropriations and does not identify a particular project, priority order, allocation or expenditure.

## SIGNIFICANCE

The order changes who can exercise powerful production-priority and allocation authorities for energy and industrial resources, potentially accelerating later interventions. The institutional change is operative, but its practical consequences depend on subsequent agency actions.

## GOALPOST / RESPONSE

The order provides no project-specific outcome claim; its evident administrative rationale is independent authority and a defined dispute path. The tests are agency regulations or orders, council dispute resolutions, contracts or allocations, appropriations, judicial review and measurable supply, timing, cost and market effects.

## MAYBE / THEREFORE

Maybe parallel delegations reduce delay in energy emergencies, or overlapping authority may produce conflict that the new council process must resolve. Therefore the delegation structure changed upon signature, but no production order, compulsory allocation, completed project or expenditure follows from the order alone.


## SOURCES

- [White House — adjusting Defense Production Act delegations](https://www.whitehouse.gov/presidential-actions/2026/09/adjusting-certain-delegations-under-the-defense-production-act-e2de/) — primary executive order independently delegating specified energy priority, allocation and section 101(c) authority and defining dispute routing

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
