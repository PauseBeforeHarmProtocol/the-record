# Supreme Court lifts Fourth Circuit deadline in FCC political-ad dispute

**Entry ID:** NAT-2026-10-08-005
**Date:** October 8–14, 2026
**Checked:** 2026-10-15 11:59 AM EDT
**Evidence state:** official October 14 Supreme Court per curiam opinion plus independent Reuters reporting; Fourth Circuit mandamus vacated, FCC merits and later judicial review unresolved
**Review state:** current-standard-reviewed

The Court vacated a mandamus order forcing the FCC to decide an election-season advertising-rate challenge; the FCC policy remains in effect, but its legality is not finally resolved.

## THE FACTS

- Chief Justice John Roberts issued an administrative stay temporarily pausing a Fourth Circuit deadline that required the Federal Communications Commission to decide a challenge to its political-advertising rate policy by Friday. Reuters reported the named October 8 Supreme Court action; the complete October 8 order text was not retrieved.
- The dispute concerns an FCC policy that allows national political parties to qualify for broadcasters' lowest unit advertising rates when they coordinate ads with candidates. The Supreme Court had allowed the policy to remain in effect in September while litigation continued.
- The Fourth Circuit imposed the deadline after concluding that the FCC had delayed action on the challenge. Roberts requested a response by Saturday, making the pause an administrative measure while the Court considers the application rather than a final ruling on the policy or agency authority.
- Republican committees seeking the stay argue the lower court interfered with the FCC's decision-making process. The challengers to the FCC policy argue coordinated party advertising should not receive the candidate-rate benefit. Those positions remain disputed and unresolved on the merits.
- On October 14, the Supreme Court vacated the Fourth Circuit's writ of mandamus that had required the FCC to act on the challengers' application. The per curiam order said the appeals court's intervention was inappropriate because federal law does not require the Commission to decide within a particular time.
- The Court did not decide whether political parties and joint fundraising committees are legally entitled to the lowest unit charge. It left the FCC process and later judicial review available, so the ruling removes the compelled deadline rather than finally validating the underlying rate policy.
- Reuters reported that the practical status quo favors Republican committees that had relied more heavily on the coordinated advertising arrangement before the November 3 midterms. That campaign consequence does not convert the procedural ruling into a merits holding.

## SIGNIFICANCE

The final Supreme Court disposition removes an appellate deadline during the last weeks before the midterms and preserves the FCC policy while agency review continues. It is a consequential procedural victory for the administration and Republican committees, but it does not resolve the statutory merits of the advertising-rate rule.

## GOALPOST / RESPONSE

The administration and Republican committees say the Fourth Circuit improperly short-circuited agency deliberation; challengers say the FCC expanded candidate-rate benefits unlawfully and delayed review. The FCC’s eventual order, any properly timed petition for review, and a later merits judgment are the tests.

## MAYBE / THEREFORE

Maybe the ruling protects orderly agency review and avoids election-season disruption, or it may permit delay to preserve a disputed advantage through the election. Therefore the compelled deadline is vacated and the policy remains operative; the Court did not finally decide who is entitled to the lowest unit charge.


## SOURCES

- [Reuters — Supreme Court administrative stay in FCC political-ad dispute](https://www.reuters.com/legal/government/us-supreme-court-wont-speed-up-democratic-challenge-fcc-political-ad-policy-now-2026-10-08/) — independent reporting of the named Supreme Court action
- [Supreme Court docket 26A274 — NRCC v. Brown](https://www.supremecourt.gov/docket/docketfiles/html/public/26A274.html) — primary court docket and emergency application metadata
- [Supreme Court — FCC v. Brown per curiam opinion](https://www.supremecourt.gov/opinions/26pdf/26a476_k537.pdf) — primary judicial opinion
- [Reuters — Supreme Court vacates FCC political-ad deadline](https://www.reuters.com/world/us-supreme-court-again-backs-republicans-clash-over-political-ad-rates-2026-10-14/) — independent court reporting and election context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
