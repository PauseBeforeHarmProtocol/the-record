# FAA reaches 100-airport surface-awareness deployment milestone

**Entry ID:** NAT-2026-09-02-010
**Date:** September 2, 2026
**Checked:** 2026-09-02 6:02 PM EDT
**Evidence state:** primary FAA milestone announcement and program background plus independent AVweb aviation reporting; installations confirmed, safety outcomes not yet measured
**Review state:** current-standard-reviewed

The installed systems give controllers real-time surface tracking at nearly half of a 220-airport target; the milestone does not yet demonstrate fewer incursions, accidents or delays.

## THE FACTS

- The Federal Aviation Administration announced installation of the 100th Surface Awareness Initiative system, reaching nearly half of its stated 220-airport deployment target.
- The systems use Automatic Dependent Surveillance–Broadcast data to give controllers real-time displays of aircraft and vehicles on airport surfaces, including in poor visibility or beyond direct sight. FAA said 44 more installations were planned by the end of 2026.
- The surface-safety program began before the current administration. The Transportation Department says the administration doubled the deployment pace and points to funding from the Working Families Tax Cut Act; the milestone should not be read as attributing all 100 installations to Trump.
- The announcement documents installed capability, not an effectiveness result. FAA had not published a causal measurement showing how the 100 systems changed runway-incursion rates, accidents, controller workload, delays or costs by cutoff.

## SIGNIFICANCE

Surface surveillance can help controllers detect conflicts at airports that lack larger radar systems, making the milestone a concrete aviation-safety implementation step. Whether the accelerated rollout materially reduces risk requires comparable incident and operational data after deployment.

## GOALPOST / RESPONSE

The administration says faster deployment modernizes air traffic control and improves runway safety. The strongest response is that installation counts are inputs, not proof of safer outcomes, and that training, maintenance, alert design and controller staffing also matter. Deployment completion, system uptime, false-alert rates, incursions, accidents, staffing and audited costs are the tests.

## MAYBE / THEREFORE

Maybe wider real-time surface awareness will help controllers prevent collisions and close a technology gap at smaller airports, or benefits may be limited without reliable equipment, training and staffing. Therefore the record confirms 100 installations and a stated acceleration—not that the administration originated the program or that the systems have already produced a measured national safety improvement.


## SOURCES

- [FAA — 100th Surface Awareness Initiative installation](https://www.faa.gov/newsroom/trumps-transportation-secretary-sean-p-duffy-announces-milestone-air-traffic-control) — primary agency announcement of the 100-airport milestone, system function and remaining deployment target
- [FAA — Surface Safety Portfolio](https://www.faa.gov/surface-safety-portfolio) — primary program background on airport surface surveillance technologies and deployment
- [AVweb — FAA installs 100th Surface Awareness Initiative system](https://avweb.com/aviation-news/faa-100th-surface-awareness-initiative/) — independent aviation reporting on the deployment milestone and system capabilities

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
