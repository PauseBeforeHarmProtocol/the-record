# EEOC secures $2.3 million Ford harassment conciliation agreement

**Entry ID:** NAT-2026-09-01-012
**Date:** September 1, 2026
**Checked:** 2026-09-03 6:02 AM EDT
**Evidence state:** primary EEOC settlement announcement and independent Reuters labor reporting, including Ford's response; conciliation agreement reached, distribution and long-term compliance outcomes pending
**Review state:** current-standard-reviewed

The pre-litigation agreement provides monetary relief and three years of reporting and training after a federal reasonable-cause finding; it is a settlement, not a court judgment.

## THE FACTS

- The Equal Employment Opportunity Commission announced that Ford agreed to pay $2.3 million to resolve a 2021 race and national-origin harassment charge involving its Buffalo, New York stamping plant.
- EEOC said its investigation found reasonable cause to believe Ford personnel subjected workers to unlawful harassment and discrimination and found graffiti targeting Black, Native American and Hispanic employees in bathrooms, break rooms and other work areas.
- The pre-litigation conciliation agreement provides monetary relief to eligible claimants and requires Ford to post its anti-graffiti protocol, conduct regular training and report discrimination complaints and graffiti to EEOC for three years. No lawsuit or judicial liability finding produced the agreement.
- Ford said it does not tolerate harassment, described more than $3.5 million in voluntary surveillance, coating and plant-environment improvements, and said reported graffiti had declined. Those remedial steps and the settlement are documented; the final claimant distribution and sustained workplace outcomes were not yet measured.

## SIGNIFICANCE

The agreement is an implemented federal civil-rights enforcement outcome combining monetary relief, monitoring and workplace controls at a major manufacturer. Its deterrent and remedial value depends on claimant participation, compliance and whether harassment remains reduced during the three-year term.

## GOALPOST / RESPONSE

EEOC says conciliation secured meaningful relief and accountability without litigation, while Ford emphasizes cooperation, prior investments and its anti-harassment policies. The strongest response is that a negotiated agreement does not itself establish every allegation or prove lasting workplace change. Claimant payments, compliance reports, complaint and graffiti trends, training completion and any enforcement action for breach are the tests.

## MAYBE / THEREFORE

Maybe the monetary relief, reporting and physical controls will sustainably reduce harassment and compensate affected workers, or a plant-specific agreement may have limited deterrent value without transparent compliance results. Therefore the record confirms a $2.3 million federal conciliation agreement and reasonable-cause finding—not a court judgment, an admission resolving every allegation or proof that all eligible workers have been paid and future harassment eliminated.


## SOURCES

- [EEOC — Ford $2.3 million race and national-origin harassment conciliation agreement](https://www.eeoc.gov/newsroom/ford-motor-company-pay-23-million-resolve-eeoc-race-and-national-origin-harassment-charge) — primary agency announcement of reasonable-cause findings, monetary relief, monitoring terms and Ford's response
- [Reuters — Ford and EEOC reach $2.3 million harassment agreement](https://www.reuters.com/legal/legalindustry/ford-eeoc-ink-23-million-deal-probe-over-racist-graffiti-2026-09-02/) — independent labor reporting on the federal conciliation outcome and three-year compliance terms

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
