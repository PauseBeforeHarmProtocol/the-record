# DOJ announces arrests and Texas laptop-farm seizures in North Korean remote-work cases

**Entry ID:** NAT-2026-10-13-007
**Date:** September 21–October 13, 2026
**Checked:** 2026-10-13 5:56 PM EDT
**Evidence state:** primary Justice Department charging, arrest, search and seizure announcement plus independent Reuters reporting; physical disruption implemented, criminal allegations pending and broader effects unmeasured
**Review state:** current-standard-reviewed

The coordinated operation charged 14 people, arrested two U.S. nationals and seized about 187 devices; the criminal allegations remain unproved.

## THE FACTS

- The Justice Department announced an indictment charging 14 people, the arrests of two U.S. nationals and searches of known or suspected Texas laptop farms in a coordinated action against alleged North Korean remote-IT-worker schemes. The FBI says it seized about 187 laptops and KVM devices.
- Operation Lonestar Roundup included law-enforcement actions at more than 40 Texas residences between September 21 and 25. Justice says the devices and U.S.-based facilitators allowed overseas workers using stolen or fabricated identities to appear to work inside the United States.
- The Ohio indictment alleges a multi-year scheme affecting more than 70 U.S. employers and generating about $3 million for IT workers, with revenue believed sent to sanctioned North Korean entities. The affected sectors included health care, communications, cyber support, retail and manufacturing.
- Justice and the FBI frame the operation as protection against illicit revenue generation, identity theft and access to employer systems and issued mitigation guidance to companies. The indictment's details are allegations; all defendants are presumed innocent unless proved guilty, and the final disposition and amount of disrupted revenue remain unresolved.

## SIGNIFICANCE

The action combines arrests, charges, searches and device seizures against a foreign-state revenue and access scheme that allegedly reached dozens of U.S. employers. It is an implemented disruption, but the alleged conduct, state links and financial scale still require adjudication and the broader campaign's effectiveness is unknown.

## GOALPOST / RESPONSE

Justice and the FBI say dismantling laptop farms and improving employer verification can close domestic access points and cut North Korean weapons revenue. Tests include prosecutions, forfeitures, verified employer remediation, repeat intrusions, prevented payments, recovered funds and independent evidence of sustained disruption.

## MAYBE / THEREFORE

Maybe the coordinated seizures remove a meaningful domestic infrastructure node and improve hiring defenses, or the network may adapt through other facilitators while contested allegations remain pending. Therefore federal agents executed a substantial enforcement operation—not proved every charge or demonstrated a lasting reduction in North Korean revenue and access.


## SOURCES

- [Justice Department — coordinated actions against North Korean remote IT-worker schemes](https://www.justice.gov/opa/pr/justice-department-announces-coordinated-actions-combat-north-korean-remote-it-worker) — primary indictment, arrest, search and seizure announcement
- [Reuters — DOJ arrests two and seizes 187 devices in North Korean laptop-farm crackdown](https://www.reuters.com/legal/government/doj-arrests-two-seizes-187-devices-north-korean-laptop-farm-crackdown-texas-2026-10-13/) — independent enforcement reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
