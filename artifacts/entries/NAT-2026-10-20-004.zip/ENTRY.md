# Justice Department reports results from Indian Country enforcement surge

**Entry ID:** NAT-2026-10-20-004
**Date:** October 20, 2026
**Checked:** 2026-10-20 5:59 PM EDT
**Evidence state:** primary Justice Department announcement reporting operational totals; figures are attributed to DOJ and FBI, with no independent audit or case-level verification available by cutoff
**Review state:** current-standard-reviewed

DOJ attributed hundreds of investigations and arrests to a six-month FBI surge, but the published figures are agency-reported outputs rather than audited outcome measures.

## THE FACTS

- The Justice Department announced results from Operation Not Forgotten 2026, a six-month FBI surge addressing violent crime and missing or murdered Indigenous people in Indian Country. DOJ reported 548 case investigations, a 59 percent increase from the comparable prior period, along with 118 arrests, 41 people charged, 25 child victims identified or located, 72 weapons recovered, 990 interviews and 232 searches.
- DOJ also reported cumulative results for the companion Operation Steadfast Promise since April: 1,200 investigations, 678 people charged, 700 arrests, 2,260 weapons recovered and 140 drug seizures. The release did not provide a case-level dataset, independent audit or consistent denominator for comparing all measures.
- Arrests and charges are enforcement steps, not convictions. Identifying or locating victims and recovering weapons are concrete reported outputs, but the announcement does not establish longer-term changes in violent-crime rates, victim safety, prosecution outcomes or community trust.

## SIGNIFICANCE

The reported surge directs federal investigative capacity toward serious crimes and unresolved victim cases in tribal communities, an area with longstanding jurisdictional and resource gaps. Output counts show operational scale but cannot by themselves demonstrate durable safety gains or fair case outcomes.

## GOALPOST / RESPONSE

DOJ and the FBI present the surge as evidence of sustained commitment and increased investigative reach in Indian Country. The tests are case dispositions, victim-centered outcomes, tribal-government assessments, independently verifiable trends, lawful searches and arrests, resource continuity and whether gains persist after the surge.

## MAYBE / THEREFORE

Maybe concentrated staffing and intergovernmental coordination will resolve more cases and improve safety, or temporary output growth may not translate into convictions, prevention or trusted local capacity. Therefore the record establishes agency-reported investigations, arrests, charges and recoveries—not independently audited totals, guilt, or measured long-term effectiveness.


## SOURCES

- [Justice Department — Operation Not Forgotten 2026 results](https://www.justice.gov/opa/pr/justice-department-announces-results-operation-not-forgotten-2026) — primary agency announcement reporting six-month Indian Country investigative outputs and companion-operation totals

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
