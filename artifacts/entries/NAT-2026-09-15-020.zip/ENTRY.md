# Trump removes Venezuela from failed-demonstrably drug-control designation

**Entry ID:** NAT-2026-09-15-020
**Date:** September 15–16, 2026
**Checked:** 2026-09-16 5:58 PM EDT
**Evidence state:** published presidential determination as preserved by a State Department release mirror plus Reuters's independent review; designation change is formal, downstream assistance and enforcement effects remain unestablished
**Review state:** current-standard-reviewed

The annual determination changed Venezuela's performance status for the first time since 2005 but kept it on the separate major transit or illicit-production list.

## THE FACTS

- In the annual presidential determination submitted September 15 and published September 16, Trump removed Venezuela from the countries designated as having failed demonstrably during the prior 12 months to meet international counternarcotics obligations. Reuters reported that Venezuela had carried that designation since 2005.
- The determination continued to identify Venezuela as a major drug-transit or major illicit drug-producing country. The two lists serve different statutory functions, so removal from the failed-demonstrably group is not a finding that Venezuela is no longer a major trafficking or production country.
- Colombia remained in the failed-demonstrably group. Trump said he would consider removing it next year if its new government makes progress on coca eradication and dismantling narcoterrorist networks; that is a conditional future possibility, not a present change.
- Trump attributed Venezuela's changed status to cooperation by the interim government after the U.S. ouster and arrest of Nicolás Maduro and cited operations against Tren de Aragua. Those causal and operational claims are the administration's stated basis; the determination did not itself publish an independently audited outcome series proving them.
- No evidence reviewed by cutoff established a separate assistance restoration, sanctions removal or certification beyond the annual determination. Later funding and enforcement consequences require their own instruments and implementation records.

## SIGNIFICANCE

The formal annual determination changes Venezuela's statutory counternarcotics performance classification after more than two decades and signals closer cooperation with its interim government. The narrower status change does not erase the separate major-country finding or establish every claimed enforcement result.

## GOALPOST / RESPONSE

Trump says cooperation with Venezuela's interim government is producing measurable progress and expects further dismantling of trafficking groups; Colombia's status may change if it produces similar results. The tests are the published determination, assistance and sanctions instruments, coca and seizure data, prosecutions, trafficking routes and next year's designation—not rhetoric alone.

## MAYBE / THEREFORE

Maybe the designation accurately reflects improved operational cooperation and will support further enforcement, or it may chiefly reflect a political realignment whose drug-control effects require independent measurement. Therefore the record confirms the formal removal from the failed-demonstrably category while preserving Venezuela's separate major-country listing and treating the stated causes as attributed claims.


## SOURCES

- [State Department publication — FY2027 major drug-transit and producing-country determination](https://www.forth.news/lists/state/Cf7ECeafhhh2KHWFmDURh) — primary presidential determination as republished from the State Department release
- [Reuters — Venezuela removed from failed-demonstrably drug-control designation](https://www.reuters.com/world/americas/us-drops-venezuela-drug-list-may-remove-colombia-trump-says-2026-09-16/) — independent reporting quoting and describing the presidential determination published by the State Department

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
