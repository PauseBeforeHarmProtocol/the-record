# Alex Saab pleads guilty and agrees to forfeit $195 million

**Entry ID:** NAT-2026-09-15-016
**Date:** September 15, 2026
**Checked:** 2026-09-16 12:33 PM EDT
**Evidence state:** Reuters and Associated Press court reporting based on the plea hearing, plea agreement and statement of facts; guilty plea entered, sentencing and downstream cooperation outcomes pending
**Review state:** current-standard-reviewed

The former Maduro official admitted one money-laundering conspiracy count and agreed to cooperate; sentencing, forfeiture collection and any resulting cases remain pending.

## THE FACTS

- Alex Saab pleaded guilty in federal court in Miami to one count of conspiracy to launder monetary instruments. Reuters and AP reported that he agreed to cooperate with the Justice Department and forfeit $195 million in criminal proceeds.
- AP reported that an eight-page statement of facts admitted skimming at least $195 million from at least six Venezuelan food-and-medicine contracts controlled by Saab, using false shipping records, shell companies and international accounts to conceal the proceeds. It also described $17 million in kickbacks to former governor Jose Gregorio Vielma Mora.
- The offense carries a maximum 20-year sentence. Prosecutors agreed to recommend the low end of the applicable range and may seek an additional reduction for substantial assistance; no sentencing date or sentence had been set by cutoff.
- The public court records did not identify the investigations in which Saab may cooperate. The plea therefore does not establish testimony against any particular person, corroboration of separate allegations, a completed forfeiture recovery or any conviction beyond Saab's admitted count.
- Saab's lawyers did not provide Reuters an immediate response. The agreement resolves the changed plea and admitted conduct while leaving sentencing, collection, cooperation value and any related prosecutions to later proceedings.

## SIGNIFICANCE

The plea converts a major foreign-corruption case from allegation to an admitted federal offense and creates a substantial forfeiture and cooperation obligation. Its broader value depends on collection, sentencing and whether cooperation produces independently corroborated evidence or cases.

## GOALPOST / RESPONSE

Federal prosecutors accepted a plea, forfeiture and cooperation framework in a case they describe as corruption involving Venezuelan public contracts. The tests are the entered judgment, sentence, amount actually recovered, substantial-assistance motion, disclosed cooperation and independently supported outcomes in related matters.

## MAYBE / THEREFORE

Maybe Saab's cooperation materially advances other corruption cases and recovers the agreed proceeds, or the information and assets may prove limited or difficult to use. Therefore the record establishes a guilty plea, admitted scheme and $195 million forfeiture agreement—not a sentence, completed collection or proved case against anyone else.


## SOURCES

- [Reuters — Alex Saab guilty plea and cooperation agreement](https://www.reuters.com/legal/government/alex-saab-ally-venezuelas-maduro-change-plea-us-corruption-case-2026-09-15/) — independent court reporting based on the plea hearing and court records
- [Associated Press — Alex Saab admits $195 million laundering scheme](https://apnews.com/article/14baef4f4517e95b02fc6875742a8463) — independent court reporting based on the plea agreement and eight-page statement of facts

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
