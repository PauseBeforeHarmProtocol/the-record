# Trump signs permanent higher small-business and Chapter 13 bankruptcy thresholds

**Entry ID:** NAT-2026-11-10-008
**Date:** November 10, 2026
**Checked:** 2026-11-11 12:05 AM EST
**Evidence state:** White House signature announcement, primary enrolled statutory text and independent specialized context; thresholds enacted for new cases, filing and outcome effects unresolved
**Review state:** current-standard-reviewed

H.R. 7730 sets a $7.5 million Subchapter V ceiling and a $2.75 million aggregate Chapter 13 debt ceiling for newly filed cases.

## THE FACTS

- The White House announced that President Trump signed H.R. 7730, the Bankruptcy Threshold Adjustment Act, into law on November 10. The page was published at 4:03 p.m. EST, before the prior archive boundary; no exact signing time was stated, so this is a same-day retrospective discovery rather than a claimed post-boundary signature.
- The enrolled text makes a $7.5 million aggregate noncontingent liquidated debt ceiling permanent for eligibility as a small-business debtor under Chapter 11 Subchapter V, subject to the statute’s existing exclusions and debt-source rules.
- The law sets a permanent $2.75 million aggregate debt limit for an individual or individual and spouse to use Chapter 13. The amendments apply to bankruptcy cases commenced on or after enactment.
- The Commercial Law League of America supported the bill and described the higher Subchapter V threshold as widening access to a streamlined reorganization process. Enactment does not establish how many debtors will qualify, how courts will interpret disputed eligibility or whether reorganizations and creditor recoveries will improve.

## SIGNIFICANCE

The law permanently expands the debt range in which businesses and individuals may use streamlined bankruptcy chapters, affecting filing options, procedure and bargaining leverage nationwide. Actual filings, completion rates, creditor recoveries and court interpretations remain to be measured.

## GOALPOST / RESPONSE

Supporters say the higher ceilings make reorganization more accessible and efficient for small businesses and debtors whose obligations exceed the old limits. The tests are filing volumes, eligibility rulings, plan confirmation and completion, time and cost, creditor recoveries and business survival.

## MAYBE / THEREFORE

Maybe permanent higher thresholds preserve viable businesses and give more debtors a workable reorganization route, or expanded eligibility may shift costs and bargaining power without improving completion rates. Therefore the record establishes enacted eligibility ceilings for newly commenced cases—not a completed restructuring, guaranteed discharge, business survival or measured creditor outcome.


## SOURCES

- [White House — H.R. 997, H.R. 1703, H.R. 1945 and H.R. 7730 signed into law](https://www.whitehouse.gov/briefings-statements/2026/11/congressional-bills-h-r-997-h-r-1703-h-r-1945-and-h-r-7730-signed-into-law/) — primary announcement of presidential signatures and short descriptions
- [GovInfo — enrolled text of H.R. 7730](https://www.govinfo.gov/content/pkg/BILLS-119hr7730enr/html/BILLS-119hr7730enr.htm) — primary enrolled legislation making small-business Chapter 11 and Chapter 13 debt thresholds permanent
- [Commercial Law League of America — H.R. 7730 threshold legislation](https://clla.org/clla-press-releases/) — independent specialized context on the prior thresholds and practical small-business bankruptcy effect

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
