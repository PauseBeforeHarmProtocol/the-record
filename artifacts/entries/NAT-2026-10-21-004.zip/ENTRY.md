# Administration drops two appeals defending PSLF employer-disqualification rule

**Entry ID:** NAT-2026-10-21-004
**Date:** October 21, 2026
**Checked:** 2026-10-22 12:02 AM EDT
**Evidence state:** primary June 30 district-court decisions and final rule, Associated Press and Washington Post reporting on the filed dismissal stipulations, plus docket-specific reporting confirming the third appeal remained pending; no administration explanation was located
**Review state:** current-standard-reviewed

DOJ filed joint stipulations ending the D.C. Circuit appeal and one First Circuit appeal; the rule remains vacated, while a separate states' appeal was still pending at cutoff.

## THE FACTS

- On October 21, Justice Department lawyers filed joint stipulations dismissing the administration's appeals in Robert F. Kennedy Center for Justice and Human Rights v. McMahon, No. 26-5308 in the D.C. Circuit, and National Council of Nonprofits v. McMahon, No. 26-1972 in the First Circuit. The one-sentence agreements gave no reason and provided that each side would bear its own fees and costs.
- The appeals concerned an Education Department final rule that would have allowed the secretary to disqualify a public-service employer after determining it engaged in activities constituting a 'substantial illegal purpose.' The department said the rule would protect taxpayers and prevent PSLF from subsidizing unlawful conduct; the final rule said determinations would not be based on an organization's political views or policy preferences.
- Federal judges in Massachusetts and the District of Columbia vacated the rule on June 30 before its July 1 effective date. Judge Myong Joun's Massachusetts decision held the rule contrary to law, beyond statutory authority, arbitrary and capricious, and in violation of the First Amendment; Judge Amir Ali issued a separate vacatur in the D.C. case.
- A companion First Circuit appeal in Commonwealth of Massachusetts v. U.S. Department of Education, No. 26-1973, brought by 22 states and the District of Columbia, remained pending at cutoff, with no dismissal filed and the government's opening brief due November 4. Dropping two appeals therefore did not formally end every appellate path.
- The rule remained vacated and existing PSLF employer rules remained in place. No federal official supplied an explanation for the two dismissals by cutoff, and the record does not infer a permanent abandonment, a ruling on the remaining appeal or a change to separate PSLF payment-counting and servicing disputes.

## SIGNIFICANCE

The two filed dismissals narrow the administration's legal effort to revive a rule that could have changed whether work for government and nonprofit employers counted toward loan forgiveness. The nationwide vacatur remains operative, but the unresolved companion appeal means the litigation lifecycle was not fully closed at cutoff.

## GOALPOST / RESPONSE

The administration originally said the rule would restore PSLF to its statutory purpose, deter unlawful conduct and protect taxpayers without ideological enforcement. The tests are the status and outcome of No. 26-1973, any revised rulemaking, employer-disqualification procedures, borrower payment-credit outcomes and whether neutral enforcement can be demonstrated with reviewable evidence.

## MAYBE / THEREFORE

Maybe the dismissals signal a retreat from the employer-disqualification policy, or the administration may continue through the remaining appeal or a narrower replacement rule. Therefore two specific appeals ended and the vacatur remains in force—not every related appeal, a permanent policy renunciation or a resolution of other PSLF administration problems.


## SOURCES

- [Education Department — final PSLF employer-eligibility rule](https://www.govinfo.gov/content/pkg/FR-2025-10-31/pdf/2025-19729.pdf) — primary final rule and administration rationale for the substantial-illegal-purpose employer standard
- [District of Massachusetts — National Council of Nonprofits v. McMahon memorandum and judgment](https://docs.justia.com/cases/federal/district-courts/massachusetts/madce/1:2025cv13242/291142/127) — primary district-court decision vacating the PSLF employer-disqualification final rule
- [District of Columbia — Robert F. Kennedy Center v. McMahon memorandum opinion](https://law.justia.com/cases/federal/district-courts/district-of-columbia/dcdce/1:2025cv03860/286525/47/) — primary district-court decision vacating the PSLF employer-disqualification final rule
- [Associated Press — administration drops two PSLF employer-rule appeals](https://apnews.com/article/public-service-loan-forgiveness-trump-debt-0e25878fbf2b6742131a93260164c63b) — independent reporting on two joint dismissal stipulations, the underlying vacaturs and absence of a federal explanation
- [Washington Post — DOJ drops two PSLF employer-rule appeals](https://www.washingtonpost.com/education/2026/10/21/doj-drops-fight-put-trumps-restrictions-public-service-loan-forgiveness/) — independent reporting confirming the two appeal withdrawals and continued effect of current PSLF rules
- [The College Investor — docket status for three PSLF employer-rule appeals](https://thecollegeinvestor.com/90837/education-department-drops-appeals-ending-fight-over-pslf-employer-rule/) — specialist docket reporting identifying the two dismissed appeals and the still-pending companion appeal

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
