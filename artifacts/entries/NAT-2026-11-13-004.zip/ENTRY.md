# Supreme Court grants review of Trump asylum-suspension dispute

**Entry ID:** NAT-2026-11-13-004
**Date:** November 13, 2026
**Checked:** 2026-11-13 6:03 PM EST
**Evidence state:** Supreme Court docket and official questions-presented order, supported by Associated Press reporting on the lower-court posture and competing positions; certiorari granted, merits unresolved
**Review state:** current-standard-reviewed

The Court accepted two questions concerning Proclamation 10888 and classwide relief; it did not decide the merits or grant review of the petition's third class-definition question.

## THE FACTS

- The Supreme Court granted certiorari in Mullin v. Refugee and Immigrant Center for Education and Legal Services, No. 26-239, on November 13. The docket says the grant is limited to questions one and two in the government's petition.
- Question one asks whether Presidential Proclamation 10888 and its implementing guidance—described in the official question as suspending entry of certain noncitizens and precluding access to statutory provisions including asylum—are lawful.
- Question two asks whether 8 U.S.C. § 1252(f)(1) bars the classwide relief entered by the district court. The Court did not grant review of question three, which challenged the class definition under Article III and Federal Rule of Civil Procedure 23.
- The docket identifies the reviewed judgment as the D.C. Circuit's April 24 decision in case 25-5243, with rehearing denied July 23. AP reported that the administration seeks to overturn lower-court decisions finding the asylum suspension unlawful.
- The administration argues it can categorically deny asylum to covered migrants and need not accept applications it says will be rejected; challengers argue federal law protects access to the asylum process. The certiorari grant resolves neither position and is not a merits ruling.

## SIGNIFICANCE

The grant puts a central immigration-policy dispute and the permissible scope of classwide relief before the Supreme Court. It creates a consequential appellate stage but does not reinstate, invalidate or finally approve the policy by itself.

## GOALPOST / RESPONSE

The administration's legal position will be tested by merits briefing, argument and the Court's eventual judgment on the two accepted questions. The operative injunction, any stay, implementation guidance and real access to asylum must be tracked separately from the grant of review.

## MAYBE / THEREFORE

Maybe the Court will uphold broad presidential entry authority or limit classwide relief, or it may affirm that the proclamation conflicts with statutory asylum protections. Therefore the record establishes only that the Court agreed to decide two defined questions—not that the policy is lawful, that asylum access has been finally suspended or that the lower courts were reversed.


## SOURCES

- [Supreme Court docket 26-239 — Mullin v. Refugee and Immigrant Center for Education and Legal Services](https://www.supremecourt.gov/docket/docketfiles/html/public/26-239.html) — primary docket recording the November 13 certiorari grant limited to questions one and two
- [Supreme Court questions presented — Mullin v. RAICES, No. 26-239](https://www.supremecourt.gov/docket/docketfiles/html/qp/26-00239qp.pdf) — primary questions-presented order defining the two issues accepted for review
- [Associated Press — Supreme Court agrees to review asylum-suspension dispute](https://apnews.com/article/3ed27e89abf3b0489d463fd30dacf37d) — independent reporting on the grant, lower-court posture and competing legal positions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
