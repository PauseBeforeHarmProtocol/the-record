# CMS removes Marketplace subsidies tied to 189,000 duplicate or deceased records

**Entry ID:** NAT-2026-10-14-001
**Date:** October 14, 2026
**Checked:** 2026-10-14 11:55 AM EDT
**Evidence state:** primary CMS process and outcome announcement plus independent Reuters reporting; subsidy removals implemented, agency savings estimates and no-coverage-loss claim not independently audited
**Review state:** current-standard-reviewed

The agency says the 2026 reviews prevented $738 million in payments this year; the larger $1.5 billion figure is an annualized projection, not audited realized savings.

## THE FACTS

- CMS said it identified about 189,000 people in 2026 who had subsidized coverage through the federally facilitated Affordable Care Act Marketplace while also appearing in Medicare, Medicaid or CHIP records, or whose federal record indicated they were deceased. The agency said it removed Marketplace subsidies after its matching and notice process.
- Reuters reported the agency's breakdown as about 120,000 Medicaid overlaps, 58,000 Medicare overlaps and 11,000 deceased records through July, with another 3,500 removals expected by the end of October. The categories are agency determinations based on data matching, not findings that every flagged enrollee intentionally sought duplicate benefits.
- CMS says flagged enrollees or estates receive 30 days to dispute a match before the subsidy stops; people may appeal later or show Medicaid or CHIP coverage is ending and regain subsidies. Reuters reported that half of the people flagged in the first Medicaid round resolved the match by the deadline and that officials said affected living people retained coverage in another program.
- Health Secretary Robert F. Kennedy Jr. estimated $738 million in prevented 2026 subsidy payments and more than $1.5 billion on an annualized basis. CMS separately claimed nearly $6 billion already saved across the restored duplicate-enrollment enforcement program; the reviewed materials did not provide an independent audit of those savings figures.
- CMS presented the action as program-integrity enforcement that prevents taxpayers from paying twice for coverage. The implementation tests are successful notices and appeals, error and reinstatement rates, uninterrupted lawful coverage, and audited net savings rather than the headline projection alone.

## SIGNIFICANCE

This is an implemented federal eligibility and payment-control action affecting subsidies associated with 189,000 records. It may reduce improper payments, but matching errors or notice failures could interrupt coverage; separating realized 2026 payments from annualized and cumulative agency claims keeps the fiscal evidence bounded.

## GOALPOST / RESPONSE

CMS and HHS say the reviews protect taxpayers while preserving one valid source of coverage. Tests include the number of matches sustained after disputes, reinstatements, coverage gaps, appeal outcomes, corrected death records, state-data accuracy and independently audited savings.

## MAYBE / THEREFORE

Maybe the matching process mainly removes genuine duplicate or deceased-record subsidies without reducing lawful coverage, or data mismatches and missed notices may impose avoidable disruptions. Therefore CMS implemented subsidy removals tied to about 189,000 records and projected savings—not proof of fraud by every enrollee, independently audited savings or zero coverage harm.


## SOURCES

- [CMS — duplicate and deceased Marketplace subsidy removals](https://www.cms.gov/newsroom/press-releases/trump-administration-delivers-second-year-savings-stopping-taxpayer-payments-duplicate-deceased) — primary agency announcement and process description
- [Reuters — ACA subsidies removed for duplicate coverage and deceased records](https://www.reuters.com/business/healthcare-pharmaceuticals/us-government-cuts-subsidies-189000-obamacare-enrollees-2026-10-14/) — independent reporting on implemented removals, official estimates and dispute process

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
