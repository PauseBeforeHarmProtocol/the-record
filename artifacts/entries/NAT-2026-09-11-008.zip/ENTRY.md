# D.C. Circuit vacates DOE's expired Campbell coal emergency order while later extension remains operative

**Entry ID:** NAT-2026-09-11-008
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 PM EDT
**Evidence state:** primary appellate opinion plus Reuters and AP reporting; original order vacated, later extension operative and separately challenged
**Review state:** current-standard-reviewed

The court rejected the original May 2025 order's emergency rationale; a separate later order still requires operation into November while its challenges remain pending.

## THE FACTS

- On September 11, a unanimous D.C. Circuit panel granted Michigan, environmental groups and consumer advocates' petitions and vacated the Department of Energy's May 23, 2025 order requiring Consumers Energy to keep Michigan's J.H. Campbell coal plant available after its planned retirement.
- The court held that Federal Power Act section 202(c) requires an identified risk of a substantial electricity-supply shortfall that calls for immediate federal action. It concluded that DOE had used an emergency power to override longer-term state resource planning without identifying the required present emergency.
- The vacated order had already expired after 90 days. DOE issued successive extension orders, and the latest separate order requires the plant to remain available until approximately November 14, 2026. The court held challenges to those extensions in abeyance, and Consumers Energy said it continued to comply; the opinion therefore did not authorize immediate closure.
- DOE has said the plant is needed for grid reliability and to meet growing demand, including from data centers. Michigan attributed about $295 million in added ratepayer costs to the federal orders, while the court did not decide a final allocation of costs or measure whether the plant prevented an outage.

## SIGNIFICANCE

The ruling limits how DOE may use an emergency statute to displace state-approved generation planning, but its practical effect is incomplete because a later extension remains operative. The legal holding and the plant's present status must therefore be kept separate.

## GOALPOST / RESPONSE

DOE argues that retaining dispatchable generation protects reliability during rapid load growth. The court required a concrete, immediate shortfall finding rather than general long-term reliability concern. The tests are the extension litigation, plant dispatch and costs, regional reliability evidence, replacement capacity and any Supreme Court review.

## MAYBE / THEREFORE

Maybe Campbell's availability provides a real reliability margin during a period of demand growth, or emergency orders may impose large costs while bypassing ordinary planning without preventing outages. Therefore the court vacated the expired original order on statutory grounds—not every later extension, an immediate plant closure or a final measurement of reliability and cost effects.


## SOURCES

- [D.C. Circuit — Michigan v. Department of Energy opinion](https://media.cadc.uscourts.gov/opinions/docs/2026/09/25-1159-2192454.pdf) — primary judicial opinion
- [Reuters — court vacates original Campbell coal emergency order](https://www.reuters.com/legal/litigation/us-court-blocks-trump-administration-bid-keep-michigan-coal-plant-open-2026-09-11/) — independent legal and energy reporting
- [Associated Press — appeals court rejects original Campbell coal emergency order](https://apnews.com/article/a9bc050527d58ed501a5498cbf0411d5) — independent legal and energy reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
