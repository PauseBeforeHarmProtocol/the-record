# Trump invokes $810 million pocket rescission

**Entry ID:** NAT-2026-09-25-009
**Date:** September 25, 2026
**Checked:** 2026-09-26 12:01 AM EDT
**Evidence state:** primary White House program-and-amount announcement, independent Associated Press reporting and GAO's published legal position; $810 million late-year pocket rescission invoked, original special message not independently retrieved, congressional approval and legal resolution absent at cutoff
**Review state:** current-standard-reviewed

The White House identified eleven funding pools for cancellation five days before the fiscal year ended; GAO says timing a rescission to let appropriations expire cannot lawfully bypass Congress.

## THE FACTS

- The White House announced on September 25 that Trump was using a pocket rescission for eleven unspent funding pools whose listed amounts total $810 million.
- The package includes $567 million in HHS services for refugees, asylees and other noncitizens, plus $243 million across DHS immigrant programs, migrant-student education, the Justice Department's Community Relations Service, Treasury conservation debt relief, minority-business development, international education, HHS research and minority health, and HUD housing counseling.
- AP reported that the administration announced the proposal with five days remaining in the fiscal year and the House out of session through the election. The Impoundment Control Act otherwise permits withholding proposed rescissions for 45 days of continuous congressional session while Congress considers whether to approve them.
- The administration calls the programs wasteful, unnecessary or discriminatory. Republican Senate Appropriations Chair Susan Collins called the delay and maneuver illegal, and GAO's published position is that the Act does not permit funds to be withheld through expiration. Congress had not approved this package and no court had ruled on its legality by cutoff.

## SIGNIFICANCE

The package uses fiscal-year timing to try to make $810 million in domestic appropriations expire before Congress can complete the review process, directly testing the constitutional allocation of spending power and immediately placing services and grants at risk.

## GOALPOST / RESPONSE

The administration says reduced border crossings, duplication and ideological grantmaking make the money unnecessary or harmful. The strongest response is that the executive delayed the request to defeat Congress's statutory review. The special message, agency obligation records, congressional action, GAO findings, litigation and any documented program or fiscal effects are the tests.

## MAYBE / THEREFORE

Maybe much of the money would otherwise remain unobligated or fund programs that the administration can justify ending, or the late withholding may unlawfully prevent agencies from carrying out enacted appropriations. Therefore the record establishes an announced and operative late-year rescission attempt—not congressional approval, settled legality, realized savings or measured effects on beneficiaries.


## SOURCES

- [President Trump Takes Historic Action to Eliminate Wasteful and Harmful Spending](https://www.whitehouse.gov/briefings-statements/2026/09/president-trump-takes-historic-action-to-eliminate-wasteful-and-harmful-spending/) — primary administration announcement; eleven listed rescission pools totaling $810 million
- [Trump administration uses rare authority to claw back nearly $1B in spending approved by Congress](https://www.clickorlando.com/news/politics/2026/09/25/trump-administration-uses-rare-authority-to-claw-back-nearly-1b-in-spending-approved-by-congress/) — independent reporting on timing, affected programs, legal dispute and congressional response
- [What is a ‘Pocket Rescission’ and is it Legal?](https://www.gao.gov/blog/what-pocket-rescission-and-it-legal) — primary congressional watchdog explanation of the Impoundment Control Act and GAO legal position

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
