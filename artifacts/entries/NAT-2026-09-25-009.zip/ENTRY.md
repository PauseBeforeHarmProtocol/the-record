# GAO says Trump's $810 million pocket rescission violates spending law

**Entry ID:** NAT-2026-09-25-009
**Date:** September 25–30, 2026
**Checked:** 2026-10-01 12:04 AM EDT
**Evidence state:** official GAO legal decision plus Associated Press reporting and the White House announcement; watchdog found the withholding unlawful, court enforcement, agency compliance and final program effects unresolved; September 30 congressional record and independent reporting establish the failed legislative block and expiration risk, while litigation and final account balances remain unresolved
**Review state:** current-standard-reviewed

Congress did not enact a block before the fiscal-year deadline after a senator objected to unanimous consent; litigation seeks to preserve particular funds, and account-level final balances remain unresolved.

## THE FACTS

- The White House announced on September 25 that Trump was using a pocket rescission for eleven unspent funding pools whose listed amounts total $810 million, including $567 million in HHS services for refugees, asylees and other noncitizens and $243 million across ten additional programs.
- The administration announced the proposal with five days remaining in the fiscal year. Under the Impoundment Control Act, a President may transmit a rescission proposal and withhold funds temporarily while Congress considers it, but Congress had not enacted this package.
- On September 29, the Government Accountability Office issued decision B-338788, concluding that the President may not withhold the eleven accounts past their period of availability and that the Act does not authorize timing a proposal so appropriations expire before Congress can act.
- GAO's decision says the funds must remain available for obligation unless Congress enacts a rescission. It is an official congressional-watchdog legal determination, not a federal-court judgment, and the record does not establish whether every agency had obligated the disputed balances by cutoff.
- The administration calls the programs wasteful, unnecessary or discriminatory. GAO and congressional critics say the maneuver circumvents Congress's power of the purse. Agency obligation records, any litigation, congressional action and program-level consequences remain the outcome tests.
- On September 30, Senator Patty Murray sought unanimous consent to advance legislation blocking the rescission, and Senator Ron Johnson objected. Congress did not enact that measure before the fiscal year ended.
- The Washington Post reported that expiration allowed the administration to proceed with the rescission strategy. New York's attorney general separately sought emergency relief to preserve $56.1 million in housing-counseling funds. The inspected evidence did not provide a final account-by-account obligation and expiration ledger, so the record does not assert that every dollar in the $810 million proposal was finally canceled or unobligated.

## SIGNIFICANCE

The missed fiscal-year legislative deadline moved the dispute from GAO's legal finding into concrete expiration and litigation risk for affected accounts. Because account balances and emergency relief may differ, the headline proposal cannot substitute for final program-level accounting.

## GOALPOST / RESPONSE

The administration says the programs are wasteful or unnecessary and that unused balances should be canceled. GAO says Congress must affirmatively approve rescissions and funds cannot be forced to expire during review; congressional and state challengers seek preservation. Final agency obligation records, court orders, congressional action and beneficiary effects are the tests.

## MAYBE / THEREFORE

Maybe the fiscal-year deadline leaves most targeted balances unavailable, or obligations and court relief may preserve some funds despite the administration's strategy. Therefore the record establishes that Congress did not enact a block before expiration and litigation continued—not a verified $810 million account-level cancellation or a final court judgment.


## SOURCES

- [President Trump Takes Historic Action to Eliminate Wasteful and Harmful Spending](https://www.whitehouse.gov/briefings-statements/2026/09/president-trump-takes-historic-action-to-eliminate-wasteful-and-harmful-spending/) — primary administration announcement; eleven listed rescission pools totaling $810 million
- [Trump administration uses rare authority to claw back nearly $1B in spending approved by Congress](https://www.clickorlando.com/news/politics/2026/09/25/trump-administration-uses-rare-authority-to-claw-back-nearly-1b-in-spending-approved-by-congress/) — independent reporting on timing, affected programs, legal dispute and congressional response
- [What is a ‘Pocket Rescission’ and is it Legal?](https://www.gao.gov/blog/what-pocket-rescission-and-it-legal) — primary congressional watchdog explanation of the Impoundment Control Act and GAO legal position
- [GAO — Impoundment Control Act and pocket rescissions, B-338788](https://www.gao.gov/products/b-338788) — official legal decision
- [AP — GAO says pocket rescission cannot force appropriations to expire](https://apnews.com/article/af985be40c136d1d590761e21aae88b9) — independent reporting on an official GAO legal decision
- [Washington Post — Congress does not block pocket-rescission expiration](https://www.washingtonpost.com/business/2026/09/30/trump-will-be-allowed-do-an-810-million-pocket-recission/) — independent reporting on fiscal-year deadline and unresolved account balances
- [Murray — Senate objection blocks unanimous-consent pocket-rescission bill](https://www.murray.senate.gov/republicans-block-democrats-bill-to-stop-trump-from-robbing-the-american-people-with-pocket-rescissions/) — official congressional account of attempted legislative response
- [New York attorney general seeks preservation of housing-counseling funds](https://ur.ag.ny.gov/press-release/2026/attorney-general-james-sues-trump-administration-protect-housing-counseling-0) — official litigation announcement; allegations and requested relief unresolved

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
