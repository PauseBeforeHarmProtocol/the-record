# GAO says Trump's $810 million pocket rescission violates spending law

**Entry ID:** NAT-2026-09-25-009
**Date:** September 25–October 1, 2026
**Checked:** 2026-10-05 10:11 PM EDT
**Evidence state:** official GAO decision, primary multistate complaint and independent reporting; withholding challenged in filed litigation, with emergency relief, merits, compliance and final account balances unresolved
**Review state:** corrected

Seven states challenge the withholding in federal court after Congress did not enact a block; the inspected complaint establishes a filed challenge, rather than a court ruling or an account-level final cancellation total.

## THE FACTS

- The White House announced on September 25 that Trump was using a pocket rescission for eleven unspent funding pools whose listed amounts total $810 million, including $567 million in HHS services for refugees, asylees and other noncitizens and $243 million across ten additional programs.
- The administration announced the proposal with five days remaining in the fiscal year. Under the Impoundment Control Act, a President may transmit a rescission proposal and withhold funds temporarily while Congress considers it, but Congress had not enacted this package.
- On September 29, the Government Accountability Office issued decision B-338788, concluding that the President may not withhold the eleven accounts past their period of availability and that the Act does not authorize timing a proposal so appropriations expire before Congress can act.
- GAO's decision says the funds must remain available for obligation unless Congress enacts a rescission. It is an official congressional-watchdog legal determination, not a federal-court judgment, and the record does not establish whether every agency had obligated the disputed balances by cutoff.
- The administration calls the programs wasteful, unnecessary or discriminatory. GAO and congressional critics say the maneuver circumvents Congress's power of the purse. Agency obligation records, any litigation, congressional action and program-level consequences remain the outcome tests.
- On September 30, Senator Patty Murray sought unanimous consent to advance legislation blocking the rescission, and Senator Ron Johnson objected. Congress did not enact that measure before the fiscal year ended.
- The Washington Post reported that expiration allowed the administration to proceed with the rescission strategy. New York's attorney general separately sought emergency relief to preserve $56.1 million in housing-counseling funds. The inspected evidence did not provide a final account-by-account obligation and expiration ledger, so the record does not assert that every dollar in the $810 million proposal was finally canceled or unobligated.
- California, Maine, Maryland, Michigan, New Mexico, Nevada and Oregon filed a complaint in the Northern District of California on September 30 challenging the administration’s withholding of funds, including the approximately $810 million pocket-rescission package and other unobligated balances. The complaint alleges constitutional and statutory violations and seeks declaratory and injunctive relief; a filed complaint is not a merits ruling or proof of final account-level cancellation.

## SIGNIFICANCE

The dispute has moved from a GAO legal determination and failed legislative response into multistate federal litigation. A filed complaint creates a judicial path but does not itself preserve every account, establish injury, or prove that the full $810 million was finally canceled.

## GOALPOST / RESPONSE

The administration says the programs are wasteful or contrary to its priorities and that unused balances should be canceled. GAO and the plaintiff states say Congress must approve rescissions and that executive withholding usurps the power of the purse. Court orders, agency obligation records, congressional action and program-level effects are the tests.

## MAYBE / THEREFORE

Maybe the states obtain relief preserving some balances, or jurisdiction, expiration rules and account-specific facts may limit the case. Therefore seven states have filed a consequential challenge to the withholding; the complaint is not a ruling, and the inspected record still does not prove a final $810 million account-level cancellation.

## CORRECTIONS

- **2026-10-06T02:16:12Z** — Corrected the September 30 complaint’s plaintiff list to California, Maine, Maryland, Michigan, New Mexico, Nevada and Oregon after inspecting its caption and California DOJ release. The earlier list incorrectly named Arizona, Colorado, Delaware, Illinois, Minnesota and New York; the original content is retained in version history.


## SOURCES

- [President Trump Takes Historic Action to Eliminate Wasteful and Harmful Spending](https://www.whitehouse.gov/briefings-statements/2026/09/president-trump-takes-historic-action-to-eliminate-wasteful-and-harmful-spending/) — primary administration announcement; eleven listed rescission pools totaling $810 million
- [Trump administration uses rare authority to claw back nearly $1B in spending approved by Congress](https://www.clickorlando.com/news/politics/2026/09/25/trump-administration-uses-rare-authority-to-claw-back-nearly-1b-in-spending-approved-by-congress/) — independent reporting on timing, affected programs, legal dispute and congressional response
- [What is a ‘Pocket Rescission’ and is it Legal?](https://www.gao.gov/blog/what-pocket-rescission-and-it-legal) — primary congressional watchdog explanation of the Impoundment Control Act and GAO legal position
- [GAO — Impoundment Control Act and pocket rescissions, B-338788](https://www.gao.gov/products/b-338788) — official legal decision
- [AP — GAO says pocket rescission cannot force appropriations to expire](https://apnews.com/article/af985be40c136d1d590761e21aae88b9) — independent reporting on an official GAO legal decision
- [Washington Post — Congress does not block pocket-rescission expiration](https://www.washingtonpost.com/business/2026/09/30/trump-will-be-allowed-do-an-810-million-pocket-recission/) — independent reporting on fiscal-year deadline and unresolved account balances
- [Murray — Senate objection blocks unanimous-consent pocket-rescission bill](https://www.murray.senate.gov/republicans-block-democrats-bill-to-stop-trump-from-robbing-the-american-people-with-pocket-rescissions/) — official congressional account of attempted legislative response
- [New York attorney general seeks preservation of housing-counseling funds](https://ur.ag.ny.gov/press-release/2026/attorney-general-james-sues-trump-administration-protect-housing-counseling-0) — official litigation announcement; allegations and requested relief unresolved
- [California et al. — complaint challenging federal withholding and pocket rescission](https://oag.ca.gov/system/files/attachments/press-docs/1-complaint.pdf) — primary court complaint; allegations not adjudicated
- [California Attorney General — multistate funding lawsuit announcement](https://oag.ca.gov/news/press-releases/attorney-general-bonta-takes-trump-court-over-latest-attempt-weaponize-federal) — official plaintiff announcement; allegations not adjudicated
- [Reuters — seven states sue over federal withholding and pocket rescission](https://www.reuters.com/legal/government/california-six-other-states-sue-trump-administration-over-federal-funds-2026-10-01/) — independent reporting on filed complaint and administration position

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
