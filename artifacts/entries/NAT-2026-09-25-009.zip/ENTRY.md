# GAO says Trump's $810 million pocket rescission violates spending law

**Entry ID:** NAT-2026-09-25-009
**Date:** September 25–29, 2026
**Checked:** 2026-09-29 5:56 PM EDT
**Evidence state:** official GAO legal decision plus Associated Press reporting and the White House announcement; watchdog found the withholding unlawful, court enforcement, agency compliance and final program effects unresolved
**Review state:** current-standard-reviewed

The congressional watchdog concluded that eleven appropriations could not be withheld through expiration; its legal decision is authoritative oversight but not a court judgment.

## THE FACTS

- The White House announced on September 25 that Trump was using a pocket rescission for eleven unspent funding pools whose listed amounts total $810 million, including $567 million in HHS services for refugees, asylees and other noncitizens and $243 million across ten additional programs.
- The administration announced the proposal with five days remaining in the fiscal year. Under the Impoundment Control Act, a President may transmit a rescission proposal and withhold funds temporarily while Congress considers it, but Congress had not enacted this package.
- On September 29, the Government Accountability Office issued decision B-338788, concluding that the President may not withhold the eleven accounts past their period of availability and that the Act does not authorize timing a proposal so appropriations expire before Congress can act.
- GAO's decision says the funds must remain available for obligation unless Congress enacts a rescission. It is an official congressional-watchdog legal determination, not a federal-court judgment, and the record does not establish whether every agency had obligated the disputed balances by cutoff.
- The administration calls the programs wasteful, unnecessary or discriminatory. GAO and congressional critics say the maneuver circumvents Congress's power of the purse. Agency obligation records, any litigation, congressional action and program-level consequences remain the outcome tests.

## SIGNIFICANCE

GAO's completed decision moves the dispute from a known institutional disagreement to a formal finding that the eleven-account withholding is unlawful. Enforcement, agency compliance and any judicial resolution remain separate questions.

## GOALPOST / RESPONSE

The administration says the programs are wasteful or unnecessary and that unused balances should be canceled. GAO says Congress must affirmatively approve rescissions and funds cannot be forced to expire during review. Agency obligation records, congressional action, litigation and beneficiary effects are the tests.

## MAYBE / THEREFORE

Maybe agencies will release or obligate the funds in response to GAO, or the administration may continue the dispute and seek judicial or congressional support. Therefore GAO has formally rejected this pocket-rescission mechanism—not that a court has ruled, Congress has rescinded the funds or every program outcome is known.


## SOURCES

- [President Trump Takes Historic Action to Eliminate Wasteful and Harmful Spending](https://www.whitehouse.gov/briefings-statements/2026/09/president-trump-takes-historic-action-to-eliminate-wasteful-and-harmful-spending/) — primary administration announcement; eleven listed rescission pools totaling $810 million
- [Trump administration uses rare authority to claw back nearly $1B in spending approved by Congress](https://www.clickorlando.com/news/politics/2026/09/25/trump-administration-uses-rare-authority-to-claw-back-nearly-1b-in-spending-approved-by-congress/) — independent reporting on timing, affected programs, legal dispute and congressional response
- [What is a ‘Pocket Rescission’ and is it Legal?](https://www.gao.gov/blog/what-pocket-rescission-and-it-legal) — primary congressional watchdog explanation of the Impoundment Control Act and GAO legal position
- [GAO — Impoundment Control Act and pocket rescissions, B-338788](https://www.gao.gov/products/b-338788) — official legal decision
- [AP — GAO says pocket rescission cannot force appropriations to expire](https://apnews.com/article/af985be40c136d1d590761e21aae88b9) — independent reporting on an official GAO legal decision

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
