# Pentagon investigates F-35 component shipment routed through China

**Entry ID:** NAT-2026-09-23-003
**Date:** September 23, 2026
**Checked:** 2026-09-24 12:00 PM EDT
**Evidence state:** Associated Press reporting containing on-record statements from the F-35 Joint Program Office, Australia's defense minister and China's Foreign Ministry, with unconfirmed component details clearly attributed to Bloomberg; investigation and response documented, cause, exposure and outcomes unresolved
**Review state:** current-standard-reviewed

The F-35 Joint Program Office opened an investigation and retrieval effort after aircraft components were routed to Hong Kong; the cause, exposure, sensitivity and supply-chain safeguards remain unresolved.

## THE FACTS

- The F-35 Joint Program Office said it was aware of an issue involving a shipment of aircraft components to Hong Kong and was actively working to retrieve the items, investigate the incident and add safeguards. That on-record response establishes a formal Pentagon investigation and mitigation effort.
- Australian Defence Minister Richard Marles confirmed that components intended for Australia's F-35 program ended up in Hong Kong and said they were not sensitive. The Joint Program Office did not publicly identify the parts, their classification, the intended route or how the shipment was diverted.
- Bloomberg reported that the shipment included a canopy and weapons-bay door. Associated Press said it could not independently confirm those details, and neither the Pentagon nor Australia publicly established that sensitive technical information was exposed.
- China's Foreign Ministry said it was unaware of the incident, while Hong Kong authorities did not respond to Associated Press. No public finding attributed the routing to a government, contractor, cyberattack, deliberate diversion or espionage.
- No completed retrieval, forensic report, disciplinary action, contract remedy, program delay, readiness effect or documented compromise existed by cutoff. The record therefore treats the investigation and response as verified while keeping the shipment's cause and consequences unresolved.

## SIGNIFICANCE

F-35 components passing through Chinese territory raise material defense supply-chain and counterintelligence questions even if the items prove nonsensitive. The investigation matters because it tests custody controls for a multinational weapons program, while the public record does not establish espionage, technical compromise or operational harm.

## GOALPOST / RESPONSE

The Joint Program Office says it is retrieving the components, investigating and adding safeguards; Australia says the items were not sensitive. Confirmed component identity, chain-of-custody findings, retrieval, exposure assessment, contractor responsibility, corrective controls, sanctions or discipline, and any cost, delay or readiness effect are the tests.

## MAYBE / THEREFORE

Maybe the routing was an isolated logistics error involving nonsensitive hardware, or it may reveal a broader weakness in defense supply-chain custody. Therefore the Pentagon opened an investigation and retrieval effort after components reached Hong Kong—not that China obtained classified technology, caused the incident or compromised F-35 operations.


## SOURCES

- [Associated Press — Pentagon investigates F-35 component shipment routed through Hong Kong](https://apnews.com/article/f35-parts-china-hong-kong-australia-c0b248635c79cae9446a2bd7bf4a32f8) — independent reporting containing on-record U.S., Australian and Chinese statements and bounded unverified shipment details

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
