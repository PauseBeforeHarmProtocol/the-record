# United States backs broad AI-training fair-use position in New York Times case

**Entry ID:** NAT-2026-09-02-007
**Date:** September 1–2, 2026
**Checked:** 2026-09-02 11:57 AM EDT
**Evidence state:** primary United States statement of interest and independent Reuters legal reporting; executive-branch position filed, judicial adoption and case-specific liability unresolved
**Review state:** current-standard-reviewed

The Justice Department's statement of interest supports OpenAI's legal theory; it is advocacy to a court, not a ruling or blanket immunity for specific training conduct.

## THE FACTS

- The United States filed a statement of interest in the Southern District of New York litigation brought by The New York Times and other publishers against Microsoft and OpenAI.
- The filing argues that training large language models on copyrighted works generally can be transformative fair use and asks the court to account for scientific advancement, national security, prosperity and economic mobility when applying copyright doctrine.
- Reuters reported that the filing appeared to be the federal government's first intervention in the wave of AI-training copyright cases. The government supports OpenAI's broad legal position but does not resolve disputed facts about particular datasets, copying, outputs, licensing or alleged market harm.
- A statement of interest expresses the executive branch's legal view. The district court had not adopted that view, ruled on liability or created a binding nationwide rule by cutoff.

## SIGNIFICANCE

The filing places the administration's national-security and economic policy behind an expansive fair-use theory at a formative point in AI copyright litigation. A court's response could influence licensing leverage, model-development costs and the rights of publishers and creators, but the brief itself changes no legal entitlement.

## GOALPOST / RESPONSE

The government argues that copyright law should preserve room for transformative AI research and development with national benefits. Publishers and creators argue that commercial model developers copied protected works without permission and can substitute for or devalue original markets. The court's factual findings, fair-use analysis, licensing evidence, output behavior, appeals and any congressional action are the tests.

## MAYBE / THEREFORE

Maybe the filing will help courts preserve socially valuable machine learning while existing doctrine addresses harmful substitution, or it may give excessive weight to industry and national-policy claims over creators' rights. Therefore the record confirms a consequential federal litigation position supporting broad AI-training fair use—not a judicial ruling, a license to use every copyrighted work or proof that OpenAI's challenged conduct was lawful.


## SOURCES

- [United States statement of interest — New York Times v. Microsoft and OpenAI](https://fingfx.thomsonreuters.com/gfx/legaldocs/jnvwzqxzbpw/OPENAI%20NEW%20YORK%20TIMES%20COPYRIGHT%20LAWSUIT%20govtbrief.pdf) — primary federal court filing arguing that large-language-model training generally can be transformative fair use
- [Reuters — U.S. government backs OpenAI in New York Times copyright case](https://www.reuters.com/legal/litigation/us-government-backs-openai-new-york-times-copyright-case-2026-09-02/) — independent legal reporting on the federal statement of interest and its nonbinding procedural status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
