# ATF implements nationwide nonenforcement of major NFA controls for silencers and short-barreled firearms

**Entry ID:** NAT-2026-10-09-005
**Date:** October 9, 2026
**Checked:** 2026-10-09 11:59 PM EDT
**Evidence state:** ATF open letter, detailed official guidance and press release plus independent AP reporting; implemented nationwide through enforcement discretion, with statutes, state-law interaction and future rulemaking unresolved
**Review state:** current-standard-reviewed

DOJ extended a plaintiff-limited district-court ruling nationwide through enforcement discretion; federal background-check, dealer-record, machinegun, destructive-device and state-law rules remain.

## THE FACTS

- Effective October 9, ATF says it will no longer require prior NFA approval or federal registration before anyone otherwise subject to those rules makes or transfers a domestically made short-barreled rifle, short-barreled shotgun, silencer or weapon in the statutory ‘any other weapon’ category. The agency also stopped enforcing related making, transfer, receipt, possession, marking and documentation provisions identified in its guidance, while leaving voluntary registration available.
- The change follows an August 5 Northern District of Texas ruling in Silencer Shop Foundation v. ATF. The court held that, after Congress reduced the NFA making and transfer taxes on the covered items to zero, specified registration and transfer provisions could not rest on the taxing power; its injunction applied only to the plaintiffs and covered items. DOJ chose not to appeal and instead adopted a nationwide enforcement-discretion policy to avoid a patchwork.
- The policy is narrower than repeal of the NFA or general deregulation of the covered items. Machineguns and destructive devices remain subject to the full NFA; federal firearms-licensee recordkeeping, Form 4473 and background-check duties under the Gun Control Act remain; prohibited-person rules, special occupational taxes, import and obliterated-serial-number provisions and state or local law remain. ATF also announced interim nonenforcement of 18 U.S.C. § 922(b)(4) while it develops regulations for dealer transfers of short-barreled rifles and shotguns.
- ATF Director Robert Cekada said the administration was following the President, Congress and the court while focusing enforcement on violent crime. AP reported that gun-rights groups welcomed the nationwide result and gun-safety groups described the move as unlawful and dangerous. ATF cautioned that many states tie legality to federal registration and that interstate treatment of unregistered items remains uncertain.

## SIGNIFICANCE

The executive branch converted a lawsuit remedy limited to named plaintiffs into an implemented nationwide enforcement policy, removing a federal preapproval and registration layer for several categories of weapons and silencers. The practical reach is large, but the underlying statutes remain on the books and the policy's durability, state-law interaction, rulemaking and effects on acquisition, tracing, crime and compliance remain unresolved.

## GOALPOST / RESPONSE

The administration says nationwide discretion creates uniformity after Congress set the relevant taxes to zero, respects the court's reasoning and lets ATF focus on violent crime while retaining Gun Control Act safeguards. The tests are whether forthcoming regulations and forms match the guidance, whether another court or administration sustains the interpretation, how dealers and states implement it, and what measurable safety, tracing, ownership and enforcement consequences follow.

## MAYBE / THEREFORE

Maybe nationwide nonenforcement is a pragmatic and legally defensible response to a zero-dollar tax and a district-court ruling, or maybe it is an executive decision not to enforce statutory controls beyond what that court ordered. Therefore the archive records an implemented enforcement policy—not a congressional repeal, not a nationwide appellate judgment, not elimination of background checks or state restrictions, and not evidence yet of the policy's effectiveness or harms.


## SOURCES

- [ATF — open letter on NFA making and transfer requirements for certain firearms and devices](https://www.atf.gov/media/30961/download) — primary agency guidance letter
- [ATF — update to NFA transfer guidance](https://www.atf.gov/firearms/update-to-nfa-transfer-guidance) — primary agency guidance and FAQ
- [ATF — agency issues guidance on NFA transfers](https://www.atf.gov/news/press-releases/atf-issues-guidance-national-firearms-act-transfers-short-barreled-rifles-short-barreled-shotguns-suppressors-and-certain-other-firearms) — primary agency announcement and response
- [Associated Press — DOJ applies Texas NFA ruling nationwide](https://apnews.com/article/justice-department-guns-silencers-court-ruling-5838cce00f75db274d664a534344dd3a) — independent reporting on implementation and competing responses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
