# Senate invokes cloture to open debate on permitting-package vehicle

**Entry ID:** NAT-2026-11-09-004
**Date:** November 9, 2026
**Checked:** 2026-11-10 6:10 AM EST
**Evidence state:** primary Senate roll call, schedule and introduced bill record plus Reuters and Trump’s publication-only endorsement; procedural advance verified, final text and enactment unresolved
**Review state:** current-standard-reviewed

The 73–25 vote advanced the motion to proceed to H.R. 2347, the legislative vehicle for the permitting package; the Senate had not passed the package and the House had not acted on it.

## THE FACTS

- On November 9, the Senate voted 73–25 to invoke cloture on the motion to proceed to H.R. 2347. The Senate’s official roll call identifies the question as cloture on the motion to proceed, and the Senate Daily Press identifies H.R. 2347 as the legislative vehicle for the permitting-reform bill. The vote opened a path to debate; it was not passage of the package.
- The underlying permitting proposal was introduced as S. 5653, the Bipartisan American Affordability and Jobs Act. Reuters reported the package would accelerate approvals for power plants, transmission, mines and other infrastructure while shifting more grid-upgrade costs to large data centers.
- Reuters reported that revisions added or strengthened tribal consultation, roles for tribes and states in transmission planning and a Department of Energy community-assistance program addressing data-center impacts. The National Congress of American Indians and environmental critics still objected that the package could weaken sovereignty, environmental review and community protections.
- Trump published a Truth Social post urging senators to support S. 5653. That post establishes his endorsement, not the bill’s effects or enactment. At cutoff, the Senate still had to consider and pass final text and the House would have to act before presentation to the president.

## SIGNIFICANCE

A large bipartisan procedural vote moved a consequential permitting package into Senate debate, potentially changing review, litigation, transmission and data-center cost rules. Its substance and effects remain contingent because cloture on a motion to proceed is several stages short of enactment.

## GOALPOST / RESPONSE

Supporters say predictable deadlines and transmission reforms will lower costs and accelerate energy and infrastructure construction. Tribal and environmental opponents warn of reduced sovereignty and safeguards. The tests are final text and amendments, Senate passage, House action, presidential action, implementing rules, project timelines, costs, consultation records and environmental and community outcomes.

## MAYBE / THEREFORE

Maybe the procedural coalition produces an enacted compromise that shortens project timelines while preserving safeguards, or amendments and House opposition may change or defeat it. Therefore the record establishes a 73–25 cloture vote opening debate on the legislative vehicle—not Senate passage, enactment or measured permitting reform.


## SOURCES

- [Senate roll call vote 257 — cloture on motion to proceed to H.R. 2347](https://www.senate.gov/legislative/LIS/roll_call_votes/vote1192/vote_119_2_00257.htm) — primary congressional roll call
- [Senate Daily Press — H.R. 2347 identified as permitting-reform legislative vehicle](https://www.dailypress.senate.gov/monday-november-9-2026/) — primary Senate schedule and vehicle description
- [S. 5653 — Bipartisan American Affordability and Jobs Act](https://www.govinfo.gov/app/details/BILLS-119s5653is) — primary introduced bill text and metadata
- [Reuters — Senate advances energy permitting package](https://www.reuters.com/legal/litigation/democratic-us-senators-see-hope-permitting-bill-ahead-key-senate-vote-2026-11-09/) — independent reporting on procedural vote, revisions and objections
- [Donald Trump Truth Social post urging support for S. 5653](https://truthsocial.com/@realDonaldTrump/117583560661477967) — primary evidence only that Trump published this endorsement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
