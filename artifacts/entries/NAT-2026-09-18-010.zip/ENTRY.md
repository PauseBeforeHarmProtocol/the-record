# OPM proposes broad excepted-service hiring rewrite

**Entry ID:** NAT-2026-09-18-010
**Date:** September 18, 2026
**Checked:** 2026-09-18 6:32 PM EDT
**Evidence state:** complete Federal Register proposed rule; formally proposed, comments open, no final rule or measured outcome by cutoff
**Review state:** current-standard-reviewed

The proposal would conform multiple personnel rules to new appointment schedules and simplify procedures; comments remain open through November 17 and no final rule is in force.

## THE FACTS

- The Office of Personnel Management published a proposed rule covering Employment in the Excepted Service, 91 Fed. Reg. 59076, with comments due November 17, 2026.
- The proposal would amend personnel rules across parts 213, 302, 317, 359, 362, 432, 550, 731, 920 and 930 to conform to Schedule E, Schedule Policy/Career and Schedule G and to simplify appointment and conversion procedures.
- OPM says the proposal preserves statutory veterans' preference and restoration rights. It would also clarify Pathways conversions into Schedule Policy/Career and remove monthly Federal Register notices of agency-specific excepted-service authorities while retaining an annual consolidated notice.
- The notice proposes changes to legacy lists, administrative-law-judge procedures and other hiring mechanics. It does not itself move an employee, finalize a new appointment authority, establish realized savings or demonstrate an effect on merit-system protections.

## SIGNIFICANCE

The proposal could reshape how agencies document, fill and convert excepted-service positions across several appointment systems, including roles designated Policy/Career. Reduced notice frequency and revised procedures could affect transparency and workforce protections, but the operational result depends on a final rule and agency use.

## GOALPOST / RESPONSE

OPM says the rewrite modernizes obsolete rules, reduces complexity and preserves statutory rights. Critics may test whether the schedules weaken merit protections or public visibility. The comment record, final text, litigation, appointment data, notices, veterans' outcomes and employee appeals are the tests.

## MAYBE / THEREFORE

Maybe the rewrite removes obsolete procedure while preserving merit and veterans' protections, or its new schedules and reporting changes may enable politicization or reduce transparency. Therefore OPM published a proposal for comment—not an implemented government-wide personnel conversion or measured efficiency gain.


## SOURCES

- [Federal Register — Employment in the Excepted Service proposed rule](https://www.federalregister.gov/documents/2026/09/18/2026-19222/employment-in-the-excepted-service) — primary proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
