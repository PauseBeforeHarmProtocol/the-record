# USDA removes blight-tolerant Darling 54 chestnut from biotech regulation

**Entry ID:** NAT-2026-08-28-001
**Date:** August 28, 2026
**Checked:** 2026-08-28 6:03 AM EDT
**Evidence state:** Federal Register notice summarizing APHIS's signed determination, risk assessment, corrected petition history, and public comments; nonregulated status implemented August 28 under the plant-pest rules
**Review state:** current-standard-reviewed

APHIS recognized the genetically engineered tree as nonregulated after finding no greater plant-pest risk than its conventional comparator.

## THE FACTS

- The Agriculture Department's Animal and Plant Health Inspection Service recognized Darling 54 American chestnut as no longer regulated under 7 CFR part 340, effective August 28. The genetically engineered tree was developed by the State University of New York College of Environmental Science and Forestry for tolerance to chestnut blight.
- APHIS says its determination rests on the revised petition, available scientific data, a plant-pest risk assessment, and multiple rounds of public comment. The agency concluded that Darling 54 is unlikely to pose a greater plant-pest risk than the nonmodified comparator.
- The original petition called the tree Darling 58. A 2016 labeling error was discovered through later analyses, and the university amended the petition in 2024 because nearly all phenotype data had actually come from Darling 54 offspring produced with the same transgenes and genetic background.
- Public comments were divided across the long review, including substantial opposition to deregulation. APHIS's decision removes this tree from its plant-pest biotechnology rules; it does not by itself resolve every ecological, restoration, intellectual-property, or other-agency question about widespread planting.

## SIGNIFICANCE

The decision removes a central federal plant-pest regulatory barrier for a genetically engineered tree intended to restore a species devastated by fungal blight. It also closes a review complicated by a major line-identification correction and unusually large, polarized public participation.

## GOALPOST / RESPONSE

APHIS says the relevant statutory test is whether Darling 54 poses greater plant-pest risk and that the evidence does not show it does. Supporters frame the tree as a restoration tool; opponents have raised ecological and governance concerns beyond that narrow test. Field performance, blight tolerance, gene flow, restoration outcomes, any remaining approvals, and post-release monitoring are the tests.

## MAYBE / THEREFORE

Maybe Darling 54 can safely help restore American chestnut populations, or long-lived forest deployment may reveal ecological and performance uncertainties that the plant-pest review does not answer. Therefore the record describes a final APHIS nonregulated-status determination—not a finding that the tree is risk-free, a planting mandate, or proof of successful landscape-scale restoration.


## SOURCES

- [APHIS — nonregulated-status determination for Darling 54 American chestnut](https://www.federalregister.gov/documents/2026/08/28/2026-17596/state-university-of-new-york-college-of-environmental-science-and-forestry-determination-of) — primary final federal biotechnology-regulatory notice and determination summary

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
