# Newborn vitamin K nonreceipt rises sharply while HHS evaluates the data

**Entry ID:** NAT-2026-09-01-006
**Date:** January–September 1, 2026
**Checked:** 2026-09-01 12:03 PM EDT
**Evidence state:** Reuters analysis of Truveta records covering more than one million births, primary CDC risk guidance, primary August 10 executive order and an on-record HHS response; nonreceipt trend measured, causation and clinical outcomes unresolved
**Review state:** current-standard-reviewed

A review of more than one million births measured a 57% first-half increase; the timing overlaps federal vaccine changes but does not prove that administration policy caused the refusals.

## THE FACTS

- A Truveta review reported by Reuters examined 1,026,375 infants born to 825,599 mothers from January 2019 through June 2026 and found that hospital nonreceipt of the vitamin K shot within one day of birth rose from 5.2% at the end of December 2025 to 8.1% at the end of June 2026, an increase of more than 57%.
- The first-half 2026 nonreceipt rate was 2.5 times the 2019–2024 average and 1.4 times the 2025 rate. The analysis measured receipt in participating health records; it did not measure a national census of refusals, later catch-up shots or resulting bleeding cases.
- The Centers for Disease Control and Prevention continues to recommend the birth shot and says infants who do not receive it are 81 times more likely to develop late vitamin K deficiency bleeding. CDC says the condition is preventable and may produce brain or intestinal bleeding without warning.
- The acceleration temporally overlapped January federal childhood-vaccine schedule changes and President Trump's August 10 Executive Order 14420, which reaffirmed narrower recommendation categories and directed agencies to advance them. Vitamin K is not a vaccine and the executive order does not direct parents to refuse it.
- HHS said it and CDC are evaluating refusal and bleeding data, argued that declining institutional trust predates this administration and grew during the COVID-19 pandemic, and emphasized respect for individual choice. The observational trend does not isolate federal policy, political messaging, social media, hospital practice or other causes.

## SIGNIFICANCE

The measurement identifies a large and rapid change in a preventive newborn intervention with a known severe-risk differential. It is evidence of increased nonreceipt and potential exposure—not yet evidence of more bleeding events or proof that federal vaccine policy caused the change.

## GOALPOST / RESPONSE

HHS says mistrust predates the administration and that it is evaluating the data while providing vitamin K information. Clinicians argue that vaccine-policy messaging can spill over to unrelated newborn care. Replicated national measurements, stated parental reasons, hospital practices, catch-up rates, confirmed bleeding incidence and designs that isolate causal drivers are the tests.

## MAYBE / THEREFORE

Maybe a preexisting rise in medical mistrust accelerated for reasons only partly or not at all attributable to federal policy, or administration messaging may have amplified confusion across newborn interventions. Therefore the record supports a measured 2026 increase in vitamin K nonreceipt and a material risk signal—not a causal verdict against the administration, a count of actual injuries or evidence that every nonreceipt was an informed refusal.


## SOURCES

- [Reuters — Truveta analysis finds a 2026 spike in newborn vitamin K nonreceipt](https://www.reuters.com/world/us/refusals-crucial-newborn-vitamin-spike-raising-risk-dangerous-bleeding-2026-09-01/) — independent data analysis of more than one million births, specialist interviews and HHS response; reports temporal alignment without proving policy causation
- [CDC — About Vitamin K Deficiency Bleeding](https://www.cdc.gov/vitamin-k-deficiency/about/index.html) — primary public-health guidance documenting preventability, incidence and relative risk when the birth shot is not received
- [White House — Executive Order 14420 on childhood vaccine recommendations](https://www.whitehouse.gov/presidential-actions/2026/08/delivering-gold-standard-childhood-vaccine-recommendations-for-americans/) — primary executive order defining the administration's three vaccine-recommendation categories and directing agencies to advance them

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
