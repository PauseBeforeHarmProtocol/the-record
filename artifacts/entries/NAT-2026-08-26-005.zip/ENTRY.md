# Trump formalizes 90-day increase in lower-tariff lean-beef imports

**Entry ID:** NAT-2026-08-26-005
**Date:** August 26, 2026
**Checked:** 2026-08-26 5:59 PM EDT
**Evidence state:** signed White House proclamation with exact quota, tariff schedule, and tranche dates, plus Reuters and AP reporting on the prior announcement, producer response, and effect uncertainty; action signed, implementation and price effects pending
**Review state:** current-standard-reviewed

The proclamation adds 300,000 metric tons to the 2026 tariff-rate quota in three monthly tranches beginning September 1, converting an August 21 announcement into a signed trade action.

## THE FACTS

- President Trump signed a proclamation increasing the 2026 in-quota quantity for specified lean beef trimmings by 300,000 metric tons, allocated to eligible 'other countries or areas' on a first-come, first-served basis.
- The lower-tariff quantity opens in three tranches of 100,000 metric tons: September 1–30, October 1–30, and October 31 through November 30 or until filled. The proclamation modifies the Harmonized Tariff Schedule and directs U.S. Customs and Border Protection to administer the increase.
- The White House says the measure is intended to increase ground-beef supply and lower consumer prices while the domestic herd is near a 75-year low. Reuters and AP reported that cattle producers and rural-state lawmakers warn imports could weaken herd-rebuilding incentives, while economists questioned whether roughly 3% of annual U.S. beef consumption can materially change retail prices.

## SIGNIFICANCE

The signed proclamation turns a previously announced affordability plan into a time-limited tariff-rate-quota change with a defined start date and volume. Its consumer benefit and producer cost are empirical questions that can be tested against import uptake, wholesale and retail prices, cattle prices, and herd growth.

## GOALPOST / RESPONSE

The administration projects added supply and a discounted imported product while arguing that the 90-day limit protects ranchers. Producer groups say the policy may depress cattle prices and discourage domestic expansion; economists cited by Reuters and AP doubt the volume will significantly reduce grocery prices. Tranche utilization, landed prices, retailer pass-through, cattle futures, and January herd data are the evidence tests.

## MAYBE / THEREFORE

Maybe a short, tightly scoped quota increase will modestly relieve ground-beef prices without changing long-term herd investment, or exporters may be unable to fill the quota quickly. Therefore the record treats the proclamation as signed but not yet operational until September 1 and does not credit the projected price reduction as an achieved result.


## SOURCES

- [White House — proclamation increasing the lean-beef tariff-rate quota](https://www.whitehouse.gov/presidential-actions/2026/08/further-ensuring-affordable-beef-for-the-american-consumer/) — primary signed proclamation, tariff schedule, quota volume, and tranche dates
- [Reuters — announced lean-beef quota increase and producer response](https://www.reuters.com/world/us/trump-ease-ground-beef-import-quotas-90-days-2026-08-21/) — independent reporting on the precursor announcement, market response, and effect uncertainty
- [Associated Press — announced beef-import plan and rancher response](https://apnews.com/article/donald-trump-beef-prices-ranchers-e0e3dd60ae754d647527c7734a091edf) — independent reporting on scope, producer objections, and economist estimates

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
