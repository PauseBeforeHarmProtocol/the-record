# FDA conditionally adopts broader nonclinical-testing terminology

**Entry ID:** NAT-2026-09-22-004
**Date:** September 22, 2026
**Checked:** 2026-09-22 5:57 AM EDT
**Evidence state:** complete paired Federal Register direct-final and proposed rules; conditional lifecycle, definitions and agency rationale documented, effective status and outcomes unresolved
**Review state:** current-standard-reviewed

A direct final rule would replace animal-, preclinical- and in-vitro-specific terms with broader nonclinical terminology, but it takes effect only if FDA receives no significant adverse comment; a companion proposal preserves notice-and-comment review.

## THE FACTS

- FDA published a direct final rule and a substantively paired proposed rule on September 22. Comments are due December 7, 2026; the direct final rule is scheduled for February 4, 2027 only if FDA receives no significant adverse comment and confirms the effective date.
- The paired texts would replace multiple regulatory references to animal tests or studies, preclinical tests and in vitro tests with nonclinical terminology. New definitions encompass in vivo studies, cell-based assays, computer modeling and other nonhuman or human-biology-based methods conducted outside the body.
- FDA says the changes impose no new testing requirement, remove an undue textual emphasis on animal testing as the only methodology, and may foster new approach methodologies, improve predictivity and reduce animal use while maintaining safety and effectiveness standards. These are the agency's rationale and anticipated benefits, not measured outcomes.
- If FDA receives significant adverse comments, it says it will withdraw the affected direct-final provisions before the effective date and use the companion proposal to continue rulemaking. No provision was effective at cutoff, and the terminology change does not by itself validate a method, approve a product or replace evidence requirements for a particular submission.

## SIGNIFICANCE

The rulemaking would modernize the vocabulary across drug and biologic regulations so non-animal methods are not excluded by animal-specific wording. Whether it materially changes sponsor behavior, FDA acceptance, safety prediction or animal use depends on method validation, guidance and implementation beyond the textual amendments.

## GOALPOST / RESPONSE

FDA says broader terminology reflects statutory recognition of nonclinical tests and supports alternatives without weakening safety standards or adding requirements. Adverse comments, the confirmation or withdrawal notice, later guidance, accepted submissions, validation results, animal-use data and product-safety outcomes are the tests.

## MAYBE / THEREFORE

Maybe terminology that expressly includes modeling and human-biology methods removes a real regulatory signal favoring animal studies, or wording alone may change little without validated methods and review standards. Therefore FDA conditionally issued paired rulemaking to broaden terminology—not an effective mandate, blanket acceptance of alternatives or demonstrated reduction in animal use.


## SOURCES

- [Federal Register — FDA direct final Nonclinical Testing Terminology rule](https://www.govinfo.gov/content/pkg/FR-2026-09-22/pdf/2026-19350.pdf) — primary direct final rule contingent on adverse-comment review (91 FR 60295; FR Doc. 2026-19350)
- [Federal Register — FDA proposed Nonclinical Testing Terminology rule](https://www.govinfo.gov/content/pkg/FR-2026-09-22/pdf/2026-19349.pdf) — primary companion proposed rule (91 FR 60309; FR Doc. 2026-19349)

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
