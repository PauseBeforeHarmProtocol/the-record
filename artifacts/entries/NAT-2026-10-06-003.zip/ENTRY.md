# Departments finalize expanded insurer price-transparency requirements

**Entry ID:** NAT-2026-10-06-003
**Date:** October 6, 2026
**Checked:** 2026-10-06 6:08 PM EDT
**Evidence state:** joint final rule, CMS fact sheet and independent industry summary; finalized with staggered future applicability, outcomes projected
**Review state:** current-standard-reviewed

The rule takes effect December 7 with staggered applicability; projected savings and consumer effects are not yet measured.

## THE FACTS

- Treasury, Labor and HHS published the Transparency in Coverage final rule on October 6, effective December 7. It applies to non-grandfathered group health plans and health-insurance issuers, with implementation dates that vary by provision.
- The rule adds network and product identifiers, provider-taxonomy and utilization information to machine-readable files, lowers an out-of-network disclosure threshold from 20 claims to 11 and expands the reporting time range. It also moves file publication from monthly to quarterly and adds website discovery language and senior-official attestation.
- For plan years beginning on or after January 1, 2027, plans and issuers must provide specified cost-sharing information by telephone when requested. Machine-readable-file changes generally apply five or eleven months after publication, depending on the provision.
- The departments project roughly $174.5 million in annual net savings after the first year and say the changes will improve usable price information while reducing burden. Those are regulatory estimates and goals, not observed savings or proof that patients will pay less. AHA independently summarized the principal requirements.

## SIGNIFICANCE

The final rule changes the format, cadence and accessibility of nationwide insurer transparency data and creates a telephone-access obligation. Its consumer, competition and administrative effects depend on implementation and data quality.

## GOALPOST / RESPONSE

The administration says more standardized, usable prices will support comparison and competition while quarterly files reduce burden. File completeness, usability, enforcement, caller access, administrative cost and actual price or spending changes are the tests.

## MAYBE / THEREFORE

Maybe better identifiers and access make prices more comparable while lower frequency reduces unnecessary cost, or the changes may still leave data too complex for consumers. Therefore the obligations are finalized with future applicability; projected savings and real-world price effects remain unmeasured.


## SOURCES

- [Treasury, Labor and HHS — Transparency in Coverage final rule](https://www.federalregister.gov/documents/2026/10/06/2026-20447/transparency-in-coverage) — primary joint final rule
- [CMS fact sheet — Transparency in Coverage final rule](https://www.cms.gov/newsroom/fact-sheets/transparency-coverage-final-rules-cms-9882-f) — primary agency explanation
- [AHA — Agencies finalize insurer transparency updates](https://www.aha.org/news/headline/2026-10-05-agencies-finalize-updates-insurer-transparency-requirements) — independent industry summary

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
