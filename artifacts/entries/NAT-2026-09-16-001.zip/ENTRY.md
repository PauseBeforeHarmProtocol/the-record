# Belarus begins prisoner releases under interim U.S. agreement

**Entry ID:** NAT-2026-09-16-001
**Date:** September 16, 2026
**Checked:** 2026-09-16 5:59 AM EDT
**Evidence state:** Reuters reporting with a named U.S. envoy quotation and attributed Viasna reporting, plus Reuters and Associated Press context; implementation reported begun, while full release and reciprocal sanctions relief remain unconfirmed
**Review state:** current-standard-reviewed

Reuters reported pardons and family pickup notices under a 25-person deal; the full release and U.S. sanctions relief were not yet independently documented by cutoff.

## THE FACTS

- Reuters reported that Belarus began a new round of prisoner pardons after talks between President Alexander Lukashenko and U.S. envoy John Coale. Coale told Belarusian state agency Belta that an interim agreement called for Belarus to release 25 people and the United States to lift sanctions on two Belarusian companies.
- The Viasna human-rights group said relatives of some prisoners had been told they could collect loved ones Wednesday morning. By cutoff, no complete official list or independently verified count established that all 25 people had been released.
- No public U.S. sanctions instrument identifying the two companies or establishing effective relief was located by cutoff. The agreement and beginning of implementation therefore do not establish completion of the reciprocal U.S. step.
- Viasna and independent reporting counted more than 900 political prisoners still held in Belarus. Lukashenko denies that Belarus holds political prisoners and rejects criticism that releases are followed by new arrests.
- Earlier talks also included Coale's stated U.S. support for unblocking $43 million to $44 million for Belarus, but Reuters reported no implemented mechanism. That separate prospective financing was not treated as part of the completed prisoner-release action.

## SIGNIFICANCE

Beginning the release process is a concrete diplomatic outcome after earlier talks, but the limited scale and absent public sanctions instrument leave both completion and broader human-rights effects unresolved. More than 900 reported political prisoners make the denominator essential.

## GOALPOST / RESPONSE

The U.S. envoy presents engagement and reciprocal sanctions relief as a path to releases; Lukashenko denies the political-prisoner characterization. Names and release confirmations for all 25 people, the sanctions instrument and effective date, new arrests, access for independent monitors and changes in the total prisoner population are the tests.

## MAYBE / THEREFORE

Maybe the interim agreement expands into sustained releases and reduced repression, or it may remain a limited exchange within a continuing cycle of detention. Therefore the record establishes reported pardons, pickup notices and an announced 25-person framework—not verified completion for all 25, implemented U.S. sanctions relief or structural change in Belarusian repression.


## SOURCES

- [Reuters — Belarus begins prisoner releases after U.S. envoy talks](https://www.reuters.com/world/belarus-frees-more-prisoners-after-us-envoys-visit-2026-09-16/) — independent reporting with named U.S. envoy quotation and Viasna reporting
- [Reuters — U.S. envoy arrives in Belarus for prisoner-release talks](https://www.reuters.com/business/media-telecom/trump-envoy-coale-arrives-belarus-new-talks-prisoner-releases-2026-09-15/) — independent reporting and negotiation context
- [Associated Press — U.S. envoy and Belarus discuss prisoner releases](https://apnews.com/article/82b391981a9c5e8eddaf53c9173a5a71) — independent reporting and political-prisoner context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
