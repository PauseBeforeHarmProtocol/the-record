# Belarus releases 25 prisoners under interim U.S. sanctions-relief deal

**Entry ID:** NAT-2026-09-16-001
**Date:** September 16, 2026
**Checked:** 2026-09-16 12:01 PM EDT
**Evidence state:** Reuters on-site reporting and named-envoy interview, independently corroborated by Associated Press reporting and released-prisoner accounts; 25-person release completed, public U.S. sanctions instrument still not located
**Review state:** current-standard-reviewed

Reuters observed freed prisoners in Vilnius and AP independently confirmed the 25-person release; the U.S. envoy named two companies for relief, but no public legal instrument was located by cutoff.

## THE FACTS

- Reuters reported from Vilnius that Belarus released 25 prisoners on September 16 after talks between President Alexander Lukashenko and U.S. envoy John Coale. Reuters interviewed released prisoners, and AP independently reported Coale's statement that all 25 were free.
- The group included journalists, media managers and musicians who had received long prison terms. Reuters named Liudmila Chekina, Andrei Alyaksandrau and Iryna Zlobina among those released; AP reported that Belarusian authorities had not published a complete official release list by cutoff.
- Coale said the United States would lift sanctions on Lakokraska, a paint and industrial-coatings manufacturer, and Bellesbumprom, a state industrial concern overseeing forestry, pulp and paper companies. A public Treasury, OFAC or State Department legal instrument establishing the scope and effective date of that relief was not located by cutoff, so the record does not treat the legal step as independently documented.
- Viasna counted 886 political prisoners still held in Belarus; AP cited 887. The one-person difference reflects contemporaneous outside counts rather than proof of a new detention or release. Lukashenko rejects the political-prisoner label, while opposition figures say arrests continue and releases are used as bargaining leverage.
- AP reported that passports were confiscated from some released people, which a Viasna lawyer characterized as forced deportation. Coale said he hoped to return in about a month and secure hundreds more releases; that goal remains prospective and is not counted as an additional outcome.

## SIGNIFICANCE

The observed and independently corroborated release completes the 25-person Belarusian step that was previously only beginning. It is a concrete diplomatic result, but the much larger remaining prisoner population, reported passport confiscations and absent public U.S. sanctions instrument limit claims of structural human-rights change or fully documented reciprocal implementation.

## GOALPOST / RESPONSE

The U.S. envoy says direct diplomacy and reciprocal sanctions relief are producing releases; Lukashenko denies that Belarus holds political prisoners. The tests are a public sanctions instrument and effective date, a complete release list, whether released people may remain or return freely, new arrests, independent monitoring and sustained reduction in the political-prisoner total.

## MAYBE / THEREFORE

Maybe the completed 25-person exchange leads to the larger releases Coale predicts, or Belarus may continue pairing selective releases with new arrests and exile pressure. Therefore the record now establishes that 25 people were freed and two companies were publicly named for U.S. relief—not that the legal sanctions step was independently documented, that hundreds more will be freed or that repression has ended.


## SOURCES

- [Reuters — Belarus releases 25 prisoners under U.S. sanctions-relief deal](https://www.reuters.com/world/belarus-frees-more-prisoners-after-us-envoys-visit-2026-09-16/) — independent on-site reporting, released-prisoner accounts and named-envoy interview
- [Reuters — U.S. envoy arrives in Belarus for prisoner-release talks](https://www.reuters.com/business/media-telecom/trump-envoy-coale-arrives-belarus-new-talks-prisoner-releases-2026-09-15/) — independent reporting and negotiation context
- [Associated Press — U.S. envoy and Belarus discuss prisoner releases](https://apnews.com/article/82b391981a9c5e8eddaf53c9173a5a71) — independent reporting and political-prisoner context
- [Associated Press — Belarus frees 25 prisoners as U.S. envoy announces company sanctions relief](https://apnews.com/article/belarus-lukashenko-us-coale-prisoners-release-sanctions-5de69d788ec172248a0f3cbc021e951c) — independent reporting with released-prisoner and human-rights context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
