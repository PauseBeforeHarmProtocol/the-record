# OFAC implements company delistings after Belarus prisoner-release deal

**Entry ID:** NAT-2026-09-16-001
**Date:** September 16, 2026
**Checked:** 2026-09-17 6:01 PM EDT
**Evidence state:** primary September 17 OFAC deletions added to previously reviewed Reuters and AP prisoner-release reporting; implemented company relief, broader outcomes unresolved
**Review state:** current-standard-reviewed

September 17 list deletions now document relief for Lakokraska and Bellesbumprom; the earlier 25-person release is not counted again.

## THE FACTS

- Reuters reported from Vilnius that Belarus released 25 prisoners on September 16 after talks between President Alexander Lukashenko and U.S. envoy John Coale. Reuters interviewed released prisoners, and AP independently reported Coale's statement that all 25 were free.
- The group included journalists, media managers and musicians who had received long prison terms. Reuters named Liudmila Chekina, Andrei Alyaksandrau and Iryna Zlobina among those released; AP reported that Belarusian authorities had not published a complete official release list by cutoff.
- Coale announced U.S. sanctions relief for Lakokraska and Bellesbumprom on September 16. At that record's earlier cutoff, a public legal instrument had not been located; the subsequent OFAC action below resolves that documentary gap.
- Viasna counted 886 political prisoners still held in Belarus; AP cited 887. The one-person difference reflects contemporaneous outside counts rather than proof of a new detention or release. Lukashenko rejects the political-prisoner label, while opposition figures say arrests continue and releases are used as bargaining leverage.
- AP reported that passports were confiscated from some released people, which a Viasna lawyer characterized as forced deportation. Coale said he hoped to return in about a month and secure hundreds more releases; that goal remains prospective and is not counted as an additional outcome.
- On September 17 OFAC published SDN deletions for Lakokraska and the Belarusian timber, woodworking, pulp and paper concern Bellesbumprom. The notice repeats alternate names for these two organizations; those aliases are not five separate companies. The instrument establishes delisting, not additional prisoner releases or the removal of every Belarus-related restriction.

## SIGNIFICANCE

The U.S. reciprocal step is now documented by the sanctions authority rather than only an envoy's promise. The scope remains two organizations; the existing release count and human-rights limitations are unchanged.

## GOALPOST / RESPONSE

The envoy presents reciprocal relief as a way to secure releases. With the two delistings now established, test the broader promise against further verified releases, new arrests, freedom of movement and independent monitoring.

## MAYBE / THEREFORE

Maybe this completed step enables further releases, or selective exchanges continue alongside repression. Therefore two organizational delistings are now confirmed; no additional release, economy-wide sanctions lifting or durable human-rights improvement is inferred.


## SOURCES

- [Reuters — Belarus releases 25 prisoners under U.S. sanctions-relief deal](https://www.reuters.com/world/belarus-frees-more-prisoners-after-us-envoys-visit-2026-09-16/) — independent on-site reporting, released-prisoner accounts and named-envoy interview
- [Reuters — U.S. envoy arrives in Belarus for prisoner-release talks](https://www.reuters.com/business/media-telecom/trump-envoy-coale-arrives-belarus-new-talks-prisoner-releases-2026-09-15/) — independent reporting and negotiation context
- [Associated Press — U.S. envoy and Belarus discuss prisoner releases](https://apnews.com/article/82b391981a9c5e8eddaf53c9173a5a71) — independent reporting and political-prisoner context
- [Associated Press — Belarus frees 25 prisoners as U.S. envoy announces company sanctions relief](https://apnews.com/article/belarus-lukashenko-us-coale-prisoners-release-sanctions-5de69d788ec172248a0f3cbc021e951c) — independent reporting with released-prisoner and human-rights context
- [OFAC — Iran and Cuba designations and Belarus deletions, September 17](https://ofac.treasury.gov/recent-actions/20260917) — primary sanctions-list action

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
