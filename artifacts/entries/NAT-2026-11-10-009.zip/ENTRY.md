# Labor Department proposes five weekly work-search activities for unemployment benefits

**Entry ID:** NAT-2026-11-10-009
**Date:** November 9–10, 2026
**Checked:** 2026-11-11 12:02 PM EST
**Evidence state:** Federal Register proposed rule plus independent reporting; announced and proposed, with comments, finalization, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The national floor would require reporting before payment while leaving verification and adjudication methods largely to states.

## THE FACTS

- The Labor Department announced the proposal on November 9 and the Federal Register published it on November 10, before the prior archive boundary. This release records a retrospective discovery, not a post-boundary rulemaking. Comments are due January 11, 2027.
- The proposal would require unemployment-compensation claimants to complete at least five qualifying work-search activities each claimed week, meet an equivalent five-point state system or demonstrate equivalent labor-force attachment. Claimants would report the activities before payment, and states would have to recognize qualifying activities beyond direct employer contacts.
- The proposal would prohibit states from substituting formal or informal warnings for an ineligibility determination when a claimant fails the requirement. It would not prescribe a reporting form, verification method, audit frequency or adjudication process, and it proposes one year after a final rule takes effect for states to comply.
- The Department says a national minimum would improve program integrity and labor-market attachment; CBS reported that current state minimums vary and some are below five. The proposal itself acknowledges a temporary risk of higher improper-payment estimates during transition. No final rule, state-law change or measured reemployment effect exists yet.

## SIGNIFICANCE

The proposal would replace varied state standards with a national eligibility floor affecting weekly benefit certification across the federal-state unemployment system. Its legal and practical effect depends on a final rule, state implementation and measured claimant outcomes.

## GOALPOST / RESPONSE

The administration says structured searches and prepayment reporting will reduce errors and speed reemployment. The tests are the final text, state-law changes, notices and appeals, improper-payment measures, benefit denials, reemployment speed, wages and job stability.

## MAYBE / THEREFORE

Maybe five varied activities and flexible points systems promote meaningful job searches, or a fixed minimum may increase administrative burdens and benefit denials without improving job matches. Therefore the record establishes a proposed national eligibility floor—not a current five-activity mandate, a proven reduction in improper payments or faster reemployment.


## SOURCES

- [Federal Register — national minimum weekly unemployment-insurance work-search proposal](https://www.federalregister.gov/documents/2026/11/10/2026-22903/unemployment-insurance-program-national-minimum-weekly-work-search-requirements) — primary proposed rule; complete notice and regulatory analysis inspected
- [CBS News — Labor Department proposes five weekly work-search activities for unemployment benefits](https://www.cbsnews.com/news/trump-work-search-rules-unemployment-benefits/) — independent reporting on the proposal and variation in current state standards

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
