# Trump orders interagency H-1B screening and labor-data review

**Entry ID:** NAT-2026-09-18-012
**Date:** September 18, 2026
**Checked:** 2026-09-19 6:01 AM EDT
**Evidence state:** complete White House executive order; ordered and partly time-bound, with implementing criteria, enforcement and outcomes unresolved
**Review state:** current-standard-reviewed

The order directs agencies to coordinate reviews and consider recent or planned layoffs; it does not itself deny a petition or establish an employer violation.

## THE FACTS

- President Trump signed an executive order directing State, Labor and Homeland Security to coordinate with Commerce, Education and the Small Business Administration when administering H-1B petitions, labor-condition applications and visas.
- The agencies must take into account whether a sponsoring employer had layoffs during the preceding year or plans future layoffs affecting similarly situated U.S. workers. The order does not publish a dispositive test, find a named employer liable or itself deny a petition.
- Within 30 days, the Labor Department's Wage and Hour Division must begin reviewing previously submitted labor-condition-application data to assess whether further action is warranted under the Immigration and Nationality Act.
- The order delegates presidential authority under 8 U.S.C. 1185(a) to the named departments for implementing rules, policies and guidance. Any enforcement cases, regulatory changes and effects on workers or employers remain to be established.

## SIGNIFICANCE

The order adds a cross-agency enforcement and screening layer to H-1B administration and makes employer layoffs an explicit consideration, potentially changing scrutiny before any new formal rule or adjudication is complete.

## GOALPOST / RESPONSE

The administration says coordination will protect U.S. workers and program integrity. Published criteria, data-review findings, investigations, petition outcomes, employer responses, due-process challenges and measured effects on wages and hiring are the tests.

## MAYBE / THEREFORE

Maybe coordinated review identifies displacement or fraud more effectively, or vague criteria may create inconsistent decisions and burden compliant employers without improving outcomes. Therefore the order directs review and coordination—not that a sponsor was found liable, a petition was denied, or program effectiveness was measured.


## SOURCES

- [White House — H-1B integrity and interagency coordination executive order](https://www.whitehouse.gov/presidential-actions/2026/09/enhancing-program-integrity-and-integrity-and-interagency-coordination-in-the-administration-of-the-h-1b-nonimmigrant-visa-program/) — primary executive order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
