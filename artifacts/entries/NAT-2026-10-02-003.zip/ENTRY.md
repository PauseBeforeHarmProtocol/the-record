# Treasury sanctions alleged Hamas international financing network

**Entry ID:** NAT-2026-10-02-003
**Date:** October 2, 2026
**Checked:** 2026-10-02 5:57 PM EDT
**Evidence state:** Treasury designation announcement and Reuters reporting; listed targets and sanctions consequences are implemented, while alleged roles, transfers and effectiveness are not judicially established or independently measured
**Review state:** current-standard-reviewed

OFAC designated three people and two entities it says used sham charities and cryptocurrency to move more than $2 million for Hamas; the designations and blocking rules are operative, while the underlying conduct remains Treasury’s allegation.

## THE FACTS

- The Treasury Department’s Office of Foreign Assets Control designated Saleem Abdallah Saleem al-Zaq, France-based Faouzi Barika and Amel Oualid, and the organizations Association Baraka and Ensemble C Mieux on October 2 under Executive Order 13224.
- Treasury alleged that the network used purported charitable organizations, fundraising and cryptocurrency over multiple years to support Hamas and moved more than $2 million. The roles, intent and amount are the department’s findings and allegations supporting the designations, not independently adjudicated facts.
- As an implemented sanctions action, property and interests in property of designated persons in the United States or controlled by U.S. persons are blocked, entities owned 50% or more by blocked persons are also blocked, and U.S. transactions are generally prohibited absent authorization.
- Treasury said the action was intended to prevent Hamas from exploiting charities and digital assets for financing. Reuters independently reported the designations and Treasury’s account; no adjudication, target response or measured financing effect was located by cutoff.

## SIGNIFICANCE

The designations impose immediate blocking and transaction restrictions on a financing network Treasury links to Hamas and extend enforcement to charity and cryptocurrency channels. They do not by themselves prove the alleged conduct in court or establish how much financing will be disrupted.

## GOALPOST / RESPONSE

Treasury presents the action as disruption of covert financing through charitable fronts and digital assets. The designation record, any administrative challenge or delisting, asset blocks, enforcement actions, independently verified transfers and measured effect on financing are the tests.

## MAYBE / THEREFORE

Maybe the designations will materially impede the alleged network, or funds and intermediaries may shift while the targets contest Treasury’s account. Therefore the record establishes implemented U.S. sanctions and Treasury’s stated evidentiary basis—not a criminal conviction or independently measured disruption exceeding the blocked assets actually identified.


## SOURCES

- [Treasury — OFAC targets Hamas international financing network](https://home.treasury.gov/news/press-releases/sb0647/) — primary designation announcement and sanctions rationale
- [Reuters — U.S. sanctions Hamas financing network](https://www.reuters.com/world/middle-east/us-issues-sanctions-against-hamas-financing-network-treasury-says-2026-10-02/) — independent reporting on implemented designations and Treasury allegations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
