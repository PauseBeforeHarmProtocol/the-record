# CMS and states launch $275 million nursing-home nurse initiative

**Entry ID:** NAT-2026-10-23-002
**Date:** October 23, 2026
**Checked:** 2026-10-24 12:02 AM EDT
**Evidence state:** primary HHS/CMS program announcement plus Associated Press and independent trade reporting; initiative launched and funding commitments announced, with applications and outcomes pending
**Review state:** current-standard-reviewed

Civil-penalty funds will support loan repayment or stipends tied to three years of service; enrollment, payments, retention and care outcomes remain unmeasured.

## THE FACTS

- CMS and participating states launched Nurses for Nursing Homes, a nationwide initiative funded with $275 million from civil monetary penalties collected from nursing homes. CMS committed $100 million and states committed at least $175 million; the inspected announcement describes committed program resources, not a new congressional appropriation or completed disbursement.
- Eligible registered nurses and licensed practical or vocational nurses may receive up to $40,000 in student-loan repayment and/or a $10,000 stipend for a three-year commitment, at least 30 hours of work per week, at a qualifying Medicare- or Medicaid-certified nursing home. All 50 states and the District of Columbia participate; all rural facilities and selected higher-shortage areas are eligible.
- The administration expects the initiative to support more than 4,000 nurses. Applications open October 26, with an initial exception for nurses who began eligible work between July 28 and October 25; payments are to follow quarterly verification of hours worked.
- Industry groups welcomed the program while a nursing specialist said long-term-care nursing requires specialized skills beyond filling vacancies. No application count, award, payment, three-year retention result, staffing-ratio change, inspection result or resident-care outcome was available by cutoff.

## SIGNIFICANCE

The program directs already-collected nursing-home penalty funds toward a national recruitment and retention intervention in rural and shortage areas. Its scale and service commitment are concrete, but the administration's staffing and quality claims remain prospective until enrollment, retention and resident outcomes are measured.

## GOALPOST / RESPONSE

HHS and CMS say direct financial support will recruit and retain more than 4,000 nurses and improve stability and dignity of care without new taxpayer funding. The tests are completed applications, eligibility decisions, quarterly payments, three-year retention, facility staffing and turnover, survey findings, resident outcomes and any penalty-fund tradeoffs.

## MAYBE / THEREFORE

Maybe loan relief and stipends attract clinicians to persistent shortage areas, or geographic eligibility and service conditions may shift staff without producing durable staffing or care gains. Therefore the initiative is launched with $275 million committed from civil-penalty funds—not proof that 4,000 nurses enrolled, money was paid, vacancies fell or resident care improved.


## SOURCES

- [HHS — CMS and states launch $275 million Nurses for Nursing Homes initiative](https://www.hhs.gov/press-room/cms-launches-275-million-nurses-nursing-homes-initiative.html) — primary official program announcement with eligibility, funding-source and participation terms
- [Skilled Nursing News — CMS and states launch nursing-home workforce initiative](https://skillednursingnews.com/2026/10/breaking-cms-states-partner-to-launch-275m-nursing-home-workforce-initiative/) — independent trade reporting with provider and clinical-workforce responses
- [Associated Press — October 23 live national updates](https://apnews.com/article/4b43d8df0f4d7666de64f272f7b81ae7) — independent live reporting on the nursing-home initiative, seafood package, embassy drawdown and presidential remarks

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
