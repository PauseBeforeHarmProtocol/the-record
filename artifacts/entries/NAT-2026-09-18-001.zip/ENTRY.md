# State narrows ITAR controls for some uncrewed underwater vehicles

**Entry ID:** NAT-2026-09-18-001
**Date:** September 18, 2026
**Checked:** 2026-09-18 12:00 PM EDT
**Evidence state:** complete primary State Department interim final rule; published September 18, scheduled for October 19 effectiveness, downstream export and security outcomes unresolved
**Review state:** current-standard-reviewed

The interim final rule takes effect October 19; qualifying vehicles leave the Munitions List but may remain subject to Commerce export controls.

## THE FACTS

- The State Department published an interim final rule revising U.S. Munitions List Category XX(a) for certain uncrewed underwater vehicles. It is scheduled to take effect October 19, 2026, with comments due the same day.
- The existing category covers specified vehicles above 3,000 pounds designed to operate without human interaction for more than 24 hours or more than 70 nautical miles. Under the revision, vehicles at or below 8,000 pounds remain on the Munitions List only when described elsewhere on the list or specially designed with navigation capabilities beyond fixed waypoints and collision-avoidance maneuvers following see-and-avoid principles.
- Vehicles above 8,000 pounds with the specified endurance or range move to a new paragraph and remain controlled. The existing license exemption for qualifying Category XX(a)(10) activities is not changed.
- Items removed from ITAR are not necessarily uncontrolled: the rule says items outside ITAR and other agencies' exclusive jurisdiction are subject to the Export Administration Regulations. The rule does not change the separate U.S. Munitions Import List.
- State and Defense determined that the removed vehicles no longer provide the critical military or intelligence advantage needed for ITAR control. The rule is not effective at cutoff, and no export volume, licensing change or national-security outcome has been measured.

## SIGNIFICANCE

The rule shifts a defined class of dual-use underwater technology from the stricter ITAR regime toward Commerce controls, potentially changing export licensing and market access while retaining controls for larger or more capable systems.

## GOALPOST / RESPONSE

State says the revised threshold focuses ITAR on vehicles that provide a critical military or intelligence advantage and asks for comments on navigation criteria and the existing exemption. The tests are October 19 effectiveness, Commerce classifications, license volumes, compliance burdens, exports and documented security consequences.

## MAYBE / THEREFORE

Maybe narrower controls reduce unnecessary licensing for lower-capability systems while preserving national-security limits, or the new line may understate the military usefulness of smaller autonomous vehicles. Therefore the verified action is a published rule scheduled to narrow ITAR coverage—not immediate deregulation of every UUV or evidence of export or security effects.


## SOURCES

- [Federal Register — ITAR modification for uncrewed underwater vehicles](https://www.federalregister.gov/documents/2026/09/18/2026-19211/international-traffic-in-arms-regulations-modification-of-us-munitions-list-category-xxa) — primary interim final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
