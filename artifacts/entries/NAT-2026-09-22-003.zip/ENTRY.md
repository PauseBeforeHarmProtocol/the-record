# GSA proposes streamlined Federal Supply Schedule ordering rules

**Entry ID:** NAT-2026-09-22-003
**Date:** September 22, 2026
**Checked:** 2026-09-22 5:57 AM EDT
**Evidence state:** complete Federal Register proposed rule; proposed procedures and comment deadline documented, final rule, implementation and procurement outcomes unresolved
**Review state:** current-standard-reviewed

The proposal would move schedule-ordering procedures from the FAR to GSA's own regulation and remove or simplify several order-level steps; comments are due October 22.

## THE FACTS

- GSA published a proposed rule on September 22 to move Federal Supply Schedule ordering procedures from FAR subpart 8.4 to GSAR part 538 as part of the administration's Revolutionary FAR Overhaul. Comments are due October 22, 2026; no final or effective rule exists.
- The proposal would organize order placement primarily by dollar threshold and state that FAR parts 5, 6, 14, 15, 16 and 19 do not apply to the new subpart unless another provision says otherwise. It also says schedule requests for quotations are not negotiated procurements or source selections and generally would not require evaluation plans, quotation scoring or a competitive range.
- For some lower-value acquisitions the proposed text would allow oral orders before written confirmation. For schedule-priced products, services or solutions, it would not require a new responsibility determination or a new fair-and-reasonable-price determination at the order or blanket-purchase-agreement level because GSA says those determinations occur at contract level; separate requirements would remain for order-level materials and sole-source justifications.
- GSA says the change would improve speed, readability, flexibility and administrative efficiency. Those benefits have not been measured under this proposal, and the notice does not document an executed procurement, savings, competition result or contractor outcome.

## SIGNIFICANCE

Federal Supply Schedule procedures govern recurring purchases across the government. Moving and simplifying them could materially change how agencies solicit, evaluate and document orders, but the practical balance between speed, competition, price discipline and small-business access remains prospective.

## GOALPOST / RESPONSE

GSA presents the proposal as an essential-requirements approach that relies on contract-level vetting while preserving threshold-based competition and sole-source controls. The final GSAR text, agency guidance, procurement files, protest decisions, cycle time, participation, prices and independently measured savings are the goalposts.

## MAYBE / THEREFORE

Maybe removing procedures designed for other acquisition methods lets schedule buyers act faster without sacrificing safeguards already built into the contracts, or reduced order-level documentation could make weaknesses harder to detect. Therefore GSA has proposed a streamlined framework—not implemented it or shown that it saves money while preserving competition and accountability.


## SOURCES

- [Federal Register — GSA proposed Federal Supply Schedule ordering procedures](https://www.govinfo.gov/content/pkg/FR-2026-09-22/pdf/2026-19331.pdf) — primary proposed rule (91 FR 60063; FR Doc. 2026-19331)

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
