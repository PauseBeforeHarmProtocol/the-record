# D.C. and Virginia join legal challenges to proposed Triumphal Arch

**Entry ID:** NAT-2026-08-28-012
**Date:** August 28–October 31, 2026
**Checked:** 2026-10-31 6:09 PM EDT
**Evidence state:** primary October 21 court notice plus independent AP and Nexstar reporting of October 31 filing; new complaint unavailable; allegations, conditional timetable and requested relief distinguished from rulings and implementation
**Review state:** current-standard-reviewed

A new governmental lawsuit seeks to stop the same unbuilt project; a recovered court notice makes a November 5 start conditional on further approvals, not a completed authorization.

## THE FACTS

- The National Park Service released a revised 133-page assessment under the National Historic Preservation Act for Trump's proposed 250-foot, gilded Triumphal Arch at Memorial Circle near Arlington Memorial Bridge.
- NPS found that the undertaking would have an adverse effect on one or more historic properties. The assessment identifies effects on dozens of properties and character-defining views and spatial relationships involving the Lincoln Memorial, Washington Monument, Jefferson Memorial, Arlington Memorial Bridge and Circle, and Arlington House.
- The agency nevertheless said the location's historic relationships make it appropriate for the commemorative gateway and that the adverse effects could not be fully avoided without relocating the arch or eliminating a principal feature, which would not meet the stated purpose and need.
- The project had preliminary approvals and remained subject to further historic-preservation consultation, mitigation planning, other approvals, and litigation. The assessment did not appropriate construction money or establish that construction had begun.
- On September 3, the administration told the Associated Press that excavation would begin within two weeks. Interior Secretary Doug Burgum publicly described the planned arch as 250 feet tall, while the administration continued to characterize it as a semiquincentennial gateway.
- The announcement advanced the project from general planning to a stated near-term site-work timetable, but AP reported that litigation continued over whether Congress must authorize the monument. No completed excavation, publicly identified construction contract, dedicated appropriation or final merits ruling was located by cutoff.
- On September 18, the Federal Aviation Administration said its aeronautical review determined that the proposed 250-foot arch would not pose a hazard to aircraft. The agency reviewed airspace, traffic patterns and procedures for Reagan National and nearby military and public-use airports.
- FAA conditioned the determination on aviation visibility measures for the proposed nonstandard eternal flame and floodlight projectors. Reuters reported that the determination could be petitioned for review through October 18 and does not use the standard red obstruction lights.
- The FAA finding addresses navigable-airspace safety only. It does not authorize excavation or construction, supply an appropriation or contract, reverse the National Park Service's historic-property adverse-effect finding, or resolve the pending court and congressional-authority disputes.
- On September 20, Trump said on Truth Social that, at what he called a strong military request, he had agreed to make the proposed arch a military complex that could house and store rapid-use drones, place snipers on its roof and plaza, and store sniper ammunition. He cited national security but identified no specific threat.
- Reuters and Associated Press independently reported the statement. Reuters said the White House and Defense Department did not respond to questions, while AP said the Pentagon had no information beyond Trump's post. Neither report established that the military requested the functions or that an operational plan, authority, appropriation, contract, final planning approval or construction implementation exists.
- The announced military role materially changes the stated purpose and risk profile of the project but not its legal status. Final National Capital Planning Commission approval remains pending, litigation continues over congressional authorization, and no published military plan explains command, access, storage, safety, privacy or rules for deploying drones or snipers from the site.
- On September 23, FAA Administrator Bryan Bedford told a House hearing that the agency used its standard obstruction-evaluation process and gave the proposal no special consideration or political treatment. He also said that evaluation did not contemplate drone operations from the arch.
- Representative Don Beyer said the later drone proposal would require a new aviation-safety analysis. Bedford did not directly answer whether FAA would conduct one, and no new review, amended determination, construction approval or operational authorization was established by cutoff.
- On October 8, the Arlington County Board filed suit in the Eastern District of Virginia against Interior and the National Park Service. The complaint asks the court to halt the agency's movement toward ground-disturbing construction until it completes the review required by the National Environmental Policy Act.
- Arlington alleges that the 250-foot project could harm residents through traffic, emergency-transport, aviation, noise, air-quality and historic-property effects. Those are litigant allegations, not judicial findings. The White House and Interior did not immediately respond to Associated Press requests for comment, and no injunction or merits ruling had issued by cutoff.
- On October 31, Associated Press and DC News Now reported that the District of Columbia and Virginia filed a federal lawsuit seeking to block the proposed arch. The case adds a joint governmental challenge to the existing veterans’ and Arlington County litigation. The linked new complaint could not be retrieved in this review; the filing is reported, not independently docket-verified here.
- The plaintiffs allege missing congressional authorization and legally inadequate review, alongside traffic, emergency-service, pollution and stormwater harms. These are allegations and requests for relief, not judicial findings that those harms have occurred or that the project is unlawful.
- A recovered October 21 government notice in Lemmon v. Trump, No. 1:26-cv-00544-TSC, ECF 63, says NCPC consideration is scheduled for November 5. It says construction could begin that day only if NCPC approves, Interior subsequently issues a final construction decision, and NPS publishes notice of that authorization. The notice is a conditional timetable, not a final approval or proof that work began.
- AP reported that Judge Tanya Chutkan held an October 30 hearing in the veterans’ case and was considering interim relief without immediately ruling. This review verifies the older conditional notice and corroborated reports of the new lawsuit, not a new injunction, a final merits decision, completed approvals or construction.

## SIGNIFICANCE

The D.C.–Virginia filing broadens governmental opposition to the same monument and its regional effects. The government’s conditional timetable makes the next approvals consequential, but filing a lawsuit does not itself stop work or resolve the legality of construction.

## GOALPOST / RESPONSE

White House spokesman Davis Ingle told AP that the arch would commemorate military sacrifice and serve as a gateway to Arlington National Cemetery. The administration also argues that delay would impede a high-priority project and has asserted military uses. Plaintiffs dispute its authority and review process. The tests are court orders, final NCPC and Interior decisions, the NPS authorization notice, a complete environmental and military-safety record, funding, contracts and observed construction.

## MAYBE / THEREFORE

Maybe further review and litigation will validate a lawful, mitigated project, or establish defects requiring delay or redesign. Therefore the new established stage is a corroborated reported lawsuit plus an inspected conditional government notice—not proven allegations, a new court-ordered halt, final construction permission or completed work.


## SOURCES

- [National Park Service — revised Triumphal Arch assessment of effects](https://parkplanning.nps.gov/document.cfm?documentID=153235&parkID=186&projectID=136973) — primary revised Section 106 assessment finding adverse effects on historic properties
- [Associated Press — National Park Service details historic effects of proposed arch](https://apnews.com/article/trump-arch-nps-lincoln-memorial-jefferson-arlington-520d30d18a4d4943a2fb97c1521ae858) — independent reporting on the revised assessment, project status, and agency rationale
- [Associated Press — administration says Triumphal Arch excavation will begin within two weeks](https://apnews.com/article/trump-triumphal-arch-dc-monument-854f5e59402c013bbea87da2b415f34d) — independent reporting on the announced excavation timetable, proposed dimensions and continuing litigation
- [FAA statement — proposed Triumphal Arch airspace determination](https://www.faa.gov/newsroom/statements/general-statements) — primary agency statement
- [Reuters — FAA clears proposed Trump arch with lighting conditions](https://www.reuters.com/business/aerospace-defense/faa-clears-proposed-trump-arch-requires-eternal-flame-alert-pilots-2026-09-18/) — independent reporting
- [Donald J. Trump — Truth Social statement announcing military uses for proposed Triumphal Arch](https://truthsocial.com/@realDonaldTrump/117303154231930646) — primary presidential statement; evidence of publication and claimed intent only
- [Reuters — Trump says proposed arch would become a military complex](https://www.reuters.com/world/us/trump-convert-triumphal-arch-into-military-complex-2026-09-20/) — independent reporting on the announced drone, sniper and ammunition functions and absent agency response
- [Associated Press — Trump says planned arch would host drones and snipers](https://apnews.com/article/trump-arch-drones-snippers-national-security-ef9212f98c337a6a142b338c1861da97) — independent reporting on the announced military functions, Pentagon noncorroboration and unresolved approvals
- [Reuters — FAA administrator describes arch review and drone-operation scope](https://www.reuters.com/world/faa-says-trump-arch-with-signal-flame-got-no-special-treatment-review-2026-09-23/) — independent reporting on named FAA administrator congressional testimony
- [Democracy Forward — Arlington County arch lawsuit announcement](https://democracyforward.org/news/press-releases/arlington-county-takes-legal-action-to-stop-trumps-250-foot-tall-vanity-project/) — plaintiff counsel statement describing filed litigation
- [Reuters — Arlington County sues over proposed Triumphal Arch](https://www.reuters.com/world/virginia-county-board-sues-block-proposed-trump-triumphal-arch-2026-10-09/) — independent reporting of the filed federal lawsuit
- [Associated Press — Arlington County arch lawsuit](https://apnews.com/article/trump-arlington-triumphal-arch-d642d3d3f196a9806667a92b4c536050) — independent reporting of the filed federal lawsuit and responses
- [Associated Press — Triumphal Arch litigation and conditional construction notice](https://www.click2houston.com/news/politics/2026/10/31/virginia-and-dc-sue-over-trumps-arch-adding-to-legal-challenges-as-government-wants-work-to-begin/) — independent reporting of filed litigation and named White House response
- [DC News Now / Nexstar — Triumphal Arch litigation and conditional construction notice](https://www.aol.com/articles/dc-virginia-sue-halt-trump-160246000.html) — independent local reporting of complaint and White House response; complaint PDF unavailable
- [Department of Justice / U.S. District Court for D.C. — Triumphal Arch litigation and conditional construction notice](https://storage.courtlistener.com/recap/gov.uscourts.dcd.289572/gov.uscourts.dcd.289572.63.0.pdf) — primary two-page filed notice, ECF 63, Lemmon v. Trump, 1:26-cv-00544-TSC

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
