# FAA says arch review was standard but did not cover proposed drone operations

**Entry ID:** NAT-2026-08-28-012
**Date:** August 28–September 23, 2026
**Checked:** 2026-09-23 5:57 PM EDT
**Evidence state:** primary FAA administrator testimony reported by Reuters clarifies that the standard obstruction review did not contemplate drone operations; the earlier FAA determination and Trump's primary statement establish the proposal, while any new safety review, approvals, authority, funding and implementation remain unresolved
**Review state:** current-standard-reviewed

The FAA administrator said the agency gave the unbuilt arch no special treatment, while confirming that its no-hazard review did not assess Trump's later proposal to operate drones from the site.

## THE FACTS

- The National Park Service released a revised 133-page assessment under the National Historic Preservation Act for Trump's proposed 250-foot, gilded Triumphal Arch at Memorial Circle near Arlington Memorial Bridge.
- NPS found that the undertaking would have an adverse effect on one or more historic properties. The assessment identifies effects on dozens of properties and character-defining views and spatial relationships involving the Lincoln Memorial, Washington Monument, Jefferson Memorial, Arlington Memorial Bridge and Circle, and Arlington House.
- The agency nevertheless said the location's historic relationships make it appropriate for the commemorative gateway and that the adverse effects could not be fully avoided without relocating the arch or eliminating a principal feature, which would not meet the stated purpose and need.
- The project had preliminary approvals and remained subject to further historic-preservation consultation, mitigation planning, other approvals, and litigation. The assessment did not appropriate construction money or establish that construction had begun.
- On September 3, the administration told the Associated Press that excavation would begin within two weeks. Interior Secretary Doug Burgum publicly described the planned arch as 250 feet tall, while the administration continued to characterize it as a semiquincentennial gateway.
- The announcement advanced the project from general planning to a stated near-term site-work timetable, but AP reported that litigation continued over whether Congress must authorize the monument. No completed excavation, publicly identified construction contract, dedicated appropriation or final merits ruling was located by cutoff.
- On September 18, the Federal Aviation Administration said its aeronautical review determined that the proposed 250-foot arch would not pose a hazard to aircraft. The agency reviewed airspace, traffic patterns and procedures for Reagan National and nearby military and public-use airports.
- FAA conditioned the determination on aviation visibility measures for the proposed nonstandard eternal flame and floodlight projectors. Reuters reported that the determination could be petitioned for review through October 18 and does not use the standard red obstruction lights.
- The FAA finding addresses navigable-airspace safety only. It does not authorize excavation or construction, supply an appropriation or contract, reverse the National Park Service's historic-property adverse-effect finding, or resolve the pending court and congressional-authority disputes.
- On September 20, Trump said on Truth Social that, at what he called a strong military request, he had agreed to make the proposed arch a military complex that could house and store rapid-use drones, place snipers on its roof and plaza, and store sniper ammunition. He cited national security but identified no specific threat.
- Reuters and Associated Press independently reported the statement. Reuters said the White House and Defense Department did not respond to questions, while AP said the Pentagon had no information beyond Trump's post. Neither report established that the military requested the functions or that an operational plan, authority, appropriation, contract, final planning approval or construction implementation exists.
- The announced military role materially changes the stated purpose and risk profile of the project but not its legal status. Final National Capital Planning Commission approval remains pending, litigation continues over congressional authorization, and no published military plan explains command, access, storage, safety, privacy or rules for deploying drones or snipers from the site.
- On September 23, FAA Administrator Bryan Bedford told a House hearing that the agency used its standard obstruction-evaluation process and gave the proposal no special consideration or political treatment. He also said that evaluation did not contemplate drone operations from the arch.
- Representative Don Beyer said the later drone proposal would require a new aviation-safety analysis. Bedford did not directly answer whether FAA would conduct one, and no new review, amended determination, construction approval or operational authorization was established by cutoff.

## SIGNIFICANCE

The FAA's testimony narrows what its earlier no-hazard finding means: the review followed the ordinary obstruction process but did not cover the operational drone use Trump later announced. The gap matters because the proposed military functions change the site's aviation, public-safety and civil-liberties risk profile while the project remains unbuilt and the claimed military request uncorroborated.

## GOALPOST / RESPONSE

Trump says the military strongly requested the added functions and that they are needed for national security. The FAA says its existing review was standard but did not assess drone operations, and the Pentagon has supplied no corroborating plan. The tests are a new or amended safety review, a published military request and operational plan, identified authority and threat, final planning and preservation approvals, funding and contracts, safeguards, and actual implementation.

## MAYBE / THEREFORE

Maybe a later FAA review and classified military planning will address the operational risks, or the military rationale may remain an unsupported addition to a disputed monument proposal. Therefore the evidence establishes a standard obstruction review that excluded later-proposed drone operations and Trump's announced intent—not a completed drone-safety review, Pentagon adoption, approval, funding, construction or operational readiness.


## SOURCES

- [National Park Service — revised Triumphal Arch assessment of effects](https://parkplanning.nps.gov/document.cfm?documentID=153235&parkID=186&projectID=136973) — primary revised Section 106 assessment finding adverse effects on historic properties
- [Associated Press — National Park Service details historic effects of proposed arch](https://apnews.com/article/trump-arch-nps-lincoln-memorial-jefferson-arlington-520d30d18a4d4943a2fb97c1521ae858) — independent reporting on the revised assessment, project status, and agency rationale
- [Associated Press — administration says Triumphal Arch excavation will begin within two weeks](https://apnews.com/article/trump-triumphal-arch-dc-monument-854f5e59402c013bbea87da2b415f34d) — independent reporting on the announced excavation timetable, proposed dimensions and continuing litigation
- [FAA statement — proposed Triumphal Arch airspace determination](https://www.faa.gov/newsroom/statements/general-statements) — primary agency statement
- [Reuters — FAA clears proposed Trump arch with lighting conditions](https://www.reuters.com/business/aerospace-defense/faa-clears-proposed-trump-arch-requires-eternal-flame-alert-pilots-2026-09-18/) — independent reporting
- [Donald J. Trump — Truth Social statement announcing military uses for proposed Triumphal Arch](https://truthsocial.com/@realDonaldTrump/117303154231930646) — primary presidential statement; evidence of publication and claimed intent only
- [Reuters — Trump says proposed arch would become a military complex](https://www.reuters.com/world/us/trump-convert-triumphal-arch-into-military-complex-2026-09-20/) — independent reporting on the announced drone, sniper and ammunition functions and absent agency response
- [Associated Press — Trump says planned arch would host drones and snipers](https://apnews.com/article/trump-arch-drones-snippers-national-security-ef9212f98c337a6a142b338c1861da97) — independent reporting on the announced military functions, Pentagon noncorroboration and unresolved approvals
- [Reuters — FAA administrator describes arch review and drone-operation scope](https://www.reuters.com/world/faa-says-trump-arch-with-signal-flame-got-no-special-treatment-review-2026-09-23/) — independent reporting on named FAA administrator congressional testimony

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
