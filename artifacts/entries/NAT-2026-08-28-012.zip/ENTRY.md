# Trump adds proposed military functions to Triumphal Arch plan

**Entry ID:** NAT-2026-08-28-012
**Date:** August 28–September 20, 2026
**Checked:** 2026-09-20 12:01 PM EDT
**Evidence state:** primary Truth Social statement establishes Trump's publication and claimed intent; Reuters and Associated Press independently report the announcement and the absence of Pentagon corroboration, while approvals, authority, funding, operational planning and implementation remain unresolved
**Review state:** current-standard-reviewed

Trump said the unbuilt arch would store rapid-use drones and ammunition and support snipers; the Pentagon did not corroborate his claimed military request.

## THE FACTS

- The National Park Service released a revised 133-page assessment under the National Historic Preservation Act for Trump's proposed 250-foot, gilded Triumphal Arch at Memorial Circle near Arlington Memorial Bridge.
- NPS found that the undertaking would have an adverse effect on one or more historic properties. The assessment identifies effects on dozens of properties and character-defining views and spatial relationships involving the Lincoln Memorial, Washington Monument, Jefferson Memorial, Arlington Memorial Bridge and Circle, and Arlington House.
- The agency nevertheless said the location's historic relationships make it appropriate for the commemorative gateway and that the adverse effects could not be fully avoided without relocating the arch or eliminating a principal feature, which would not meet the stated purpose and need.
- The project had preliminary approvals and remained subject to further historic-preservation consultation, mitigation planning, other approvals, and litigation. The assessment did not appropriate construction money or establish that construction had begun.
- On September 3, the administration told the Associated Press that excavation would begin within two weeks. Interior Secretary Doug Burgum publicly described the planned arch as 250 feet tall, while the administration continued to characterize it as a semiquincentennial gateway.
- The announcement advanced the project from general planning to a stated near-term site-work timetable, but AP reported that litigation continued over whether Congress must authorize the monument. No completed excavation, publicly identified construction contract, dedicated appropriation or final merits ruling was located by cutoff.
- On September 18, the Federal Aviation Administration said its aeronautical review determined that the proposed 250-foot arch would not pose a hazard to aircraft. The agency reviewed airspace, traffic patterns and procedures for Reagan National and nearby military and public-use airports.
- FAA conditioned the determination on aviation visibility measures for the proposed nonstandard eternal flame and floodlight projectors. Reuters reported that the determination could be petitioned for review through October 18 and does not use the standard red obstruction lights.
- The FAA finding addresses navigable-airspace safety only. It does not authorize excavation or construction, supply an appropriation or contract, reverse the National Park Service's historic-property adverse-effect finding, or resolve the pending court and congressional-authority disputes.
- On September 20, Trump said on Truth Social that, at what he called a strong military request, he had agreed to make the proposed arch a military complex that could house and store rapid-use drones, place snipers on its roof and plaza, and store sniper ammunition. He cited national security but identified no specific threat.
- Reuters and Associated Press independently reported the statement. Reuters said the White House and Defense Department did not respond to questions, while AP said the Pentagon had no information beyond Trump's post. Neither report established that the military requested the functions or that an operational plan, authority, appropriation, contract, final planning approval or construction implementation exists.
- The announced military role materially changes the stated purpose and risk profile of the project but not its legal status. Final National Capital Planning Commission approval remains pending, litigation continues over congressional authorization, and no published military plan explains command, access, storage, safety, privacy or rules for deploying drones or snipers from the site.

## SIGNIFICANCE

The proposed arch is no longer described only as a commemorative gateway: Trump has announced intended operational military uses involving drones, snipers and ammunition at a prominent public site. That heightens unresolved questions about authority, public safety, civil liberties, planning review and funding while leaving the project unbuilt and the claimed military request uncorroborated.

## GOALPOST / RESPONSE

Trump says the military strongly requested the added functions and that they are needed for national security. The Pentagon's lack of additional information leaves the tests as a published military request and operational plan, identified authority and threat, final planning and preservation approvals, funding and contracts, storage and public-safety safeguards, privacy and use rules, and actual implementation.

## MAYBE / THEREFORE

Maybe classified planning supports a genuine security mission and public detail is limited to protect operations, or the military rationale may be an unsupported addition to a disputed monument proposal. Therefore the evidence establishes Trump's announced intent and claimed rationale—not Pentagon adoption, approval, funding, construction, operational readiness or proof that the military requested it.


## SOURCES

- [National Park Service — revised Triumphal Arch assessment of effects](https://parkplanning.nps.gov/document.cfm?documentID=153235&parkID=186&projectID=136973) — primary revised Section 106 assessment finding adverse effects on historic properties
- [Associated Press — National Park Service details historic effects of proposed arch](https://apnews.com/article/trump-arch-nps-lincoln-memorial-jefferson-arlington-520d30d18a4d4943a2fb97c1521ae858) — independent reporting on the revised assessment, project status, and agency rationale
- [Associated Press — administration says Triumphal Arch excavation will begin within two weeks](https://apnews.com/article/trump-triumphal-arch-dc-monument-854f5e59402c013bbea87da2b415f34d) — independent reporting on the announced excavation timetable, proposed dimensions and continuing litigation
- [FAA statement — proposed Triumphal Arch airspace determination](https://www.faa.gov/newsroom/statements/general-statements) — primary agency statement
- [Reuters — FAA clears proposed Trump arch with lighting conditions](https://www.reuters.com/business/aerospace-defense/faa-clears-proposed-trump-arch-requires-eternal-flame-alert-pilots-2026-09-18/) — independent reporting
- [Donald J. Trump — Truth Social statement announcing military uses for proposed Triumphal Arch](https://truthsocial.com/@realDonaldTrump/117303154231930646) — primary presidential statement; evidence of publication and claimed intent only
- [Reuters — Trump says proposed arch would become a military complex](https://www.reuters.com/world/us/trump-convert-triumphal-arch-into-military-complex-2026-09-20/) — independent reporting on the announced drone, sniper and ammunition functions and absent agency response
- [Associated Press — Trump says planned arch would host drones and snipers](https://apnews.com/article/trump-arch-drones-snippers-national-security-ef9212f98c337a6a142b338c1861da97) — independent reporting on the announced military functions, Pentagon noncorroboration and unresolved approvals

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
