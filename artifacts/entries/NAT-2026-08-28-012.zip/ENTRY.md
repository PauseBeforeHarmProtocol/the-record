# National Park Service finds proposed Triumphal Arch would harm historic properties

**Entry ID:** NAT-2026-08-28-012
**Date:** August 28, 2026
**Checked:** 2026-08-29 12:05 AM EDT
**Evidence state:** primary National Park Service revised assessment and project page plus independent Associated Press reporting; adverse-effect finding issued, project and mitigation review remain pending
**Review state:** current-standard-reviewed

The revised federal assessment identifies adverse effects while defending the Memorial Circle location; it is not a final construction approval.

## THE FACTS

- The National Park Service released a revised 133-page assessment under the National Historic Preservation Act for Trump's proposed 250-foot, gilded Triumphal Arch at Memorial Circle near Arlington Memorial Bridge.
- NPS found that the undertaking would have an adverse effect on one or more historic properties. The assessment identifies effects on dozens of properties and character-defining views and spatial relationships involving the Lincoln Memorial, Washington Monument, Jefferson Memorial, Arlington Memorial Bridge and Circle, and Arlington House.
- The agency nevertheless said the location's historic relationships make it appropriate for the commemorative gateway and that the adverse effects could not be fully avoided without relocating the arch or eliminating a principal feature, which would not meet the stated purpose and need.
- The project had preliminary approvals and remained subject to further historic-preservation consultation, mitigation planning, other approvals, and litigation. The assessment did not appropriate construction money, award a construction contract, authorize operation, or establish that construction had begun.

## SIGNIFICANCE

A federal preservation review now formally documents the proposed monument's effects on the capital's central commemorative landscape while the administration continues to support the site. The finding supplies a concrete record for consultation, design, funding, and judicial review rather than treating aesthetic objections as the only evidence.

## GOALPOST / RESPONSE

The administration and NPS describe the arch as a commemorative gateway for the nation's 250th anniversary and say the site is essential to that purpose. The agency proposes mitigation and a programmatic agreement. Final designs, Section 106 consultation, mitigation commitments, commission and congressional actions, appropriations, court rulings, contracts, and site work are the tests.

## MAYBE / THEREFORE

Maybe design changes and enforceable mitigation will reduce the identified harm, or reviewing bodies and courts may require relocation, redesign, or abandonment. Therefore the record reports a revised adverse-effect finding coupled with agency support—not final project approval, secured funding, or completed construction.


## SOURCES

- [National Park Service — revised Triumphal Arch assessment of effects](https://parkplanning.nps.gov/document.cfm?documentID=153235&parkID=186&projectID=136973) — primary revised Section 106 assessment finding adverse effects on historic properties
- [Associated Press — National Park Service details historic effects of proposed arch](https://apnews.com/article/trump-arch-nps-lincoln-memorial-jefferson-arlington-520d30d18a4d4943a2fb97c1521ae858) — independent reporting on the revised assessment, project status, and agency rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
