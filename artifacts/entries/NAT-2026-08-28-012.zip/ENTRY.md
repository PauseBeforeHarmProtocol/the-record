# FAA finds proposed Triumphal Arch poses no aviation hazard

**Entry ID:** NAT-2026-08-28-012
**Date:** August 28–September 18, 2026
**Checked:** 2026-09-18 5:59 PM EDT
**Evidence state:** primary NPS assessment and FAA determination statement plus independent AP and Reuters reporting; aviation no-hazard finding issued with conditions, construction authority, funding, preservation mitigation and litigation unresolved
**Review state:** current-standard-reviewed

The aviation determination imposes flame and floodlight conditions but does not authorize construction or resolve preservation, funding and court disputes.

## THE FACTS

- The National Park Service released a revised 133-page assessment under the National Historic Preservation Act for Trump's proposed 250-foot, gilded Triumphal Arch at Memorial Circle near Arlington Memorial Bridge.
- NPS found that the undertaking would have an adverse effect on one or more historic properties. The assessment identifies effects on dozens of properties and character-defining views and spatial relationships involving the Lincoln Memorial, Washington Monument, Jefferson Memorial, Arlington Memorial Bridge and Circle, and Arlington House.
- The agency nevertheless said the location's historic relationships make it appropriate for the commemorative gateway and that the adverse effects could not be fully avoided without relocating the arch or eliminating a principal feature, which would not meet the stated purpose and need.
- The project had preliminary approvals and remained subject to further historic-preservation consultation, mitigation planning, other approvals, and litigation. The assessment did not appropriate construction money or establish that construction had begun.
- On September 3, the administration told the Associated Press that excavation would begin within two weeks. Interior Secretary Doug Burgum publicly described the planned arch as 250 feet tall, while the administration continued to characterize it as a semiquincentennial gateway.
- The announcement advanced the project from general planning to a stated near-term site-work timetable, but AP reported that litigation continued over whether Congress must authorize the monument. No completed excavation, publicly identified construction contract, dedicated appropriation or final merits ruling was located by cutoff.
- On September 18, the Federal Aviation Administration said its aeronautical review determined that the proposed 250-foot arch would not pose a hazard to aircraft. The agency reviewed airspace, traffic patterns and procedures for Reagan National and nearby military and public-use airports.
- FAA conditioned the determination on aviation visibility measures for the proposed nonstandard eternal flame and floodlight projectors. Reuters reported that the determination could be petitioned for review through October 18 and does not use the standard red obstruction lights.
- The FAA finding addresses navigable-airspace safety only. It does not authorize excavation or construction, supply an appropriation or contract, reverse the National Park Service's historic-property adverse-effect finding, or resolve the pending court and congressional-authority disputes.

## SIGNIFICANCE

FAA's determination removes one aviation-hazard obstacle for the proposed 250-foot arch near Reagan National Airport, while leaving the National Park Service's adverse-effect finding and unresolved construction authority, funding and litigation intact.

## GOALPOST / RESPONSE

The administration describes the arch as a commemorative gateway; FAA says the specified location and height do not endanger air navigation if the eternal flame and floodlights meet its conditions. The tests remain compliance with those conditions, any administrative review, final design and preservation process, legal authority, funding, contracts and completed site work.

## MAYBE / THEREFORE

Maybe FAA's technical clearance permits planning to advance without materially affecting flight safety, or other preservation, legal, funding and construction constraints may still block or reshape the project. Therefore FAA issued a conditional no-hazard determination—not a construction permit, congressional authorization, appropriation or final court judgment.


## SOURCES

- [National Park Service — revised Triumphal Arch assessment of effects](https://parkplanning.nps.gov/document.cfm?documentID=153235&parkID=186&projectID=136973) — primary revised Section 106 assessment finding adverse effects on historic properties
- [Associated Press — National Park Service details historic effects of proposed arch](https://apnews.com/article/trump-arch-nps-lincoln-memorial-jefferson-arlington-520d30d18a4d4943a2fb97c1521ae858) — independent reporting on the revised assessment, project status, and agency rationale
- [Associated Press — administration says Triumphal Arch excavation will begin within two weeks](https://apnews.com/article/trump-triumphal-arch-dc-monument-854f5e59402c013bbea87da2b415f34d) — independent reporting on the announced excavation timetable, proposed dimensions and continuing litigation
- [FAA statement — proposed Triumphal Arch airspace determination](https://www.faa.gov/newsroom/statements/general-statements) — primary agency statement
- [Reuters — FAA clears proposed Trump arch with lighting conditions](https://www.reuters.com/business/aerospace-defense/faa-clears-proposed-trump-arch-requires-eternal-flame-alert-pilots-2026-09-18/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
