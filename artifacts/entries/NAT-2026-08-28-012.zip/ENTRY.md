# National Park Service finds proposed Triumphal Arch would harm historic properties

**Entry ID:** NAT-2026-08-28-012
**Date:** August 28–September 3, 2026
**Checked:** 2026-09-03 6:02 PM EDT
**Evidence state:** primary National Park Service assessment and project page plus independent Associated Press reporting; adverse-effect finding and excavation timetable announced, actual site work, funding and final legal authority unresolved
**Review state:** current-standard-reviewed

After finding adverse effects, the administration said excavation would begin within two weeks; no completed site work, appropriation or final court ruling was public by cutoff.

## THE FACTS

- The National Park Service released a revised 133-page assessment under the National Historic Preservation Act for Trump's proposed 250-foot, gilded Triumphal Arch at Memorial Circle near Arlington Memorial Bridge.
- NPS found that the undertaking would have an adverse effect on one or more historic properties. The assessment identifies effects on dozens of properties and character-defining views and spatial relationships involving the Lincoln Memorial, Washington Monument, Jefferson Memorial, Arlington Memorial Bridge and Circle, and Arlington House.
- The agency nevertheless said the location's historic relationships make it appropriate for the commemorative gateway and that the adverse effects could not be fully avoided without relocating the arch or eliminating a principal feature, which would not meet the stated purpose and need.
- The project had preliminary approvals and remained subject to further historic-preservation consultation, mitigation planning, other approvals, and litigation. The assessment did not appropriate construction money or establish that construction had begun.
- On September 3, the administration told the Associated Press that excavation would begin within two weeks. Interior Secretary Doug Burgum publicly described the planned arch as 250 feet tall, while the administration continued to characterize it as a semiquincentennial gateway.
- The announcement advanced the project from general planning to a stated near-term site-work timetable, but AP reported that litigation continued over whether Congress must authorize the monument. No completed excavation, publicly identified construction contract, dedicated appropriation or final merits ruling was located by cutoff.

## SIGNIFICANCE

The near-term excavation announcement raises the practical stakes of the federal adverse-effect finding and unresolved authorization litigation. Site work could create costs or physical changes before every preservation, funding and legal dispute is finally resolved.

## GOALPOST / RESPONSE

The administration and NPS describe the arch as a commemorative gateway and say the site is essential; NPS proposes mitigation. Excavation records, final designs, Section 106 consultation, mitigation commitments, commission and congressional actions, appropriations, court rulings, contracts and completed site work are the tests.

## MAYBE / THEREFORE

Maybe preliminary excavation can proceed lawfully while design, mitigation and authorization questions are resolved, or starting work may constrain later review and increase public cost. Therefore the record confirms an announced two-week excavation timetable following an adverse-effect finding—not that excavation occurred, Congress authorized the monument, funding was secured or litigation ended.


## SOURCES

- [National Park Service — revised Triumphal Arch assessment of effects](https://parkplanning.nps.gov/document.cfm?documentID=153235&parkID=186&projectID=136973) — primary revised Section 106 assessment finding adverse effects on historic properties
- [Associated Press — National Park Service details historic effects of proposed arch](https://apnews.com/article/trump-arch-nps-lincoln-memorial-jefferson-arlington-520d30d18a4d4943a2fb97c1521ae858) — independent reporting on the revised assessment, project status, and agency rationale
- [Associated Press — administration says Triumphal Arch excavation will begin within two weeks](https://apnews.com/article/trump-triumphal-arch-dc-monument-854f5e59402c013bbea87da2b415f34d) — independent reporting on the announced excavation timetable, proposed dimensions and continuing litigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
