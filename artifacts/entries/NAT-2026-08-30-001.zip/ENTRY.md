# Trump says NBC's Kristen Welker will be reported to FCC for punishment

**Entry ID:** NAT-2026-08-30-001
**Date:** August 30, 2026
**Checked:** 2026-08-30 12:03 PM EDT
**Evidence state:** Trump's public Truth Social posts plus independent Reuters reporting and procedural context; threat announced, no public FCC action located by cutoff
**Review state:** current-standard-reviewed

The president invoked federal communications regulation against a named journalist over political commentary; no public FCC complaint, inquiry or sanction was located by cutoff.

## THE FACTS

- President Trump wrote on Truth Social that NBC's Kristen Welker would be reported to the Federal Communications Commission for ‘rebuke or punishment’ after she characterized his candidate endorsements as producing mixed results.
- Trump called the statement purposely inaccurate, cited his own claimed 100% Senate and 98% House endorsement success rates, and separately wrote ‘FCC to the rescue’ while urging the commission and Chair Brendan Carr to treat ‘fake polls and commentary’ seriously. The Record treats those electoral-performance figures as Trump's claims, not independently established facts.
- Reuters found no immediate NBC response and described the threat in the context of prior presidential pressure on broadcast licensees, ABC and Disney litigation challenging accelerated FCC review, and an FCC examination of NBC parent Comcast's affiliate relationships. The FCC licenses local broadcast stations rather than individual journalists or national networks, and license revocation is rare and requires a formal process.
- No public complaint, FCC docket, agency inquiry, notice, sanction, station-license proceeding or adjudicated finding that Welker's statement was false was located by the checked time.

## SIGNIFICANCE

A president's express request for a communications regulator to punish a named journalist over evaluative political speech can chill coverage even if no formal agency action follows. Whether the threat becomes an FCC proceeding, and whether any such proceeding has a lawful jurisdictional basis, separates political pressure from implemented regulation.

## GOALPOST / RESPONSE

Trump says broadcasters using public airwaves should face consequences for purposeful inaccuracies and points to his claimed endorsement record. The strongest response is that political commentary and editorial judgments receive broad First Amendment protection, the FCC does not license individual network hosts, and any station action would require jurisdiction, evidence and due process. A filed complaint, FCC response, docket, investigation, sanction, judicial review, NBC evidence, and independent verification of the endorsement claims are the tests.

## MAYBE / THEREFORE

Maybe the post is political rhetoric or notice of an ordinary complaint that produces no agency action. Therefore the record documents an explicit presidential threat to seek federal regulatory punishment of a journalist—not an FCC investigation or sanction, proof that Welker's characterization was false, or a completed restriction on NBC.


## SOURCES

- [Donald Trump — Truth Social threat to report Kristen Welker to the FCC](https://truthsocial.com/@realDonaldTrump/117184581053116309) — primary evidence that Trump published the regulatory-punishment threat; claims inside the post require independent verification
- [Reuters — Trump says Kristen Welker will be reported to FCC for punishment](https://www.reuters.com/business/media-telecom/trump-says-nbcs-welker-will-be-reported-fcc-2026-08-30/) — independent reporting on the presidential threat, NBC response posture and FCC license context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
