# Forest Service announces closure of 23 research facilities

**Entry ID:** NAT-2026-09-03-005
**Date:** March 31–September 3, 2026
**Checked:** 2026-09-03 6:02 PM EDT
**Evidence state:** primary USDA reorganization announcement and Forest Service implementation page plus Associated Press reporting based on named agency officials; closure plan announced, outcomes and realized savings unmeasured
**Review state:** current-standard-reviewed

The agency says research will continue at other sites and 95 employees will relocate locally; the facility consolidation is projected to save about $16 million.

## THE FACTS

- The Forest Service told the Associated Press on September 3 that it is closing 23 research stations and laboratories across more than a dozen states as part of the reorganization USDA announced in March.
- Named agency officials said 95 employees would be moved to other local Forest Service facilities and that 41 other research facilities previously considered for closure would remain open. The agency projected about $16 million in savings from the research-facility and regional-office closures.
- USDA's March plan said Forest Service research would be unified under one organization in Fort Collins, Colorado, while headquarters would move to Salt Lake City and field operations would shift toward a state-based model.
- The Forest Service said ongoing scientific work and experimental forests would not close and research would continue at other locations. Closing buildings therefore does not by itself establish cancellation of every project or elimination of the research function.
- Researchers and outside critics told AP that losing specialized sites could disrupt long-running work and public access. No complete project-by-project transfer plan, realized savings audit, attrition total or measured research output after consolidation was public by cutoff.

## SIGNIFICANCE

Closing 23 facilities implements a concrete part of a national agency reorganization and changes where federal forest science is performed. Whether the consolidation saves money without degrading long-term wildfire, ecology and forest-management research depends on transfers, staffing and outputs that have not yet been measured.

## GOALPOST / RESPONSE

USDA and the Forest Service say the reorganization reduces administrative cost, places staff closer to communities and preserves ongoing science. Facility disposition records, staff retention, project-transfer plans, realized savings, publication and monitoring output, experimental-forest continuity and stakeholder access are the tests.

## MAYBE / THEREFORE

Maybe co-locating staff will preserve research while reducing building and management costs, or specialized capacity and institutional knowledge may be lost despite formal project transfers. Therefore the record confirms the announced closure of 23 facilities, local relocation of 95 employees and projected savings—not completed closures at every site, realized savings or a demonstrated improvement or decline in forest science.


## SOURCES

- [USDA — Forest Service reorganization announcement](https://www.usda.gov/about-usda/news/press-releases/2026/03/31/usda-prioritizing-common-sense-forest-management-moves-forest-service-headquarters-salt-lake-city) — primary agency announcement of the research consolidation and broader reorganization plan
- [Forest Service — reorganization information page](https://www.fs.usda.gov/about-agency/reorganization) — primary agency page describing the reorganization and public implementation materials
- [Associated Press — Forest Service closing 23 research facilities](https://apnews.com/article/forest-service-research-centers-closing-4735447f7487743d8e4aceb471b21d01) — independent reporting based on named agency officials about facility closures, staff relocation and projected savings

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
