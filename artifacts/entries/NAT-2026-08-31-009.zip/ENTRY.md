# Administration launches trucking-fraud task force and removes 110 training providers

**Entry ID:** NAT-2026-08-31-009
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** primary joint DOJ-DOT-DHS release describing the operative and proposed actions, corroborated by independent trucking-industry reporting on the emergency removals and audit; task force and 110 removals implemented, additional removals and outcomes pending
**Review state:** current-standard-reviewed

FMCSA executed emergency registry removals, proposed more than 160 additional removals and began a tester audit as DOJ and DHS announced coordinated investigations and inspections.

## THE FACTS

- The Justice, Transportation and Homeland Security departments announced Joint Task Force Crossroads of America, joining federal prosecutors in Illinois, Indiana, Michigan and Ohio with FMCSA, FBI, DEA, HSI, ICE, ATF and state and local partners to investigate trucking-industry fraud and related crimes.
- FMCSA said it was executing emergency removal of more than 110 entry-level driver-training providers from the federal Training Provider Registry after matching providers to more than 5,000 drivers cited for failing English-language-proficiency requirements. Emergency removal bars the providers from operating as registered federal training providers; it is not a criminal conviction of every school or driver associated with the records.
- The agency also reported issuing more than 160 notices of proposed removal following nearly 400 investigations in 40 states and launched a nationwide audit of third-party CDL skills testers and state oversight. Proposed removals remain subject to process and are distinct from the 110 emergency removals.
- DHS announced a synchronized August 31 service of inspection notices at more than 200 driving schools across 23 states and said it had disseminated more than 1,000 business leads. The release separately described ongoing investigations involving suspected document, employment, financial, labor and trafficking offenses; allegations in those investigations are not adjudicated findings.
- The administration attributed thousands of earlier out-of-service orders, license cancellations and school removals to its broader campaign. Those totals and asserted links to fatalities are agency-reported operational metrics; the release did not provide record-level data permitting independent attribution of legal status, language proficiency, training quality or crash causation for every person and provider.

## SIGNIFICANCE

The coordinated removals, proposed removals, audits, inspections and multi-state task force materially expand federal scrutiny from individual commercial drivers to schools, testers, licensing systems and employers. The enforcement can affect driver supply and state highway funding, while its safety rationale and immigration framing require separation of proven violations from association-based claims.

## GOALPOST / RESPONSE

The administration says fraudulent training and licensing expose the public to unsafe drivers and criminal networks, and that coordinated enforcement will reduce deaths and restore lawful standards. Providers and drivers may contest whether cited language failures or registry associations establish training fraud, immigration violations or crash causation. Final removal decisions, inspection returns, filed charges, adjudications, state corrective plans, crash data, due-process challenges and independently reproducible enforcement statistics are the tests.

## MAYBE / THEREFORE

Maybe the provider-level data will substantiate widespread certification failures and improve road safety, or broad enforcement may sweep in compliant schools and drivers based on indirect associations and disputed proxies. Therefore the record confirms formation of the task force, 110 emergency provider removals, more than 160 proposed removals and announced audits and inspections—not guilt for every associated person, completion of the proposed actions or a measured reduction in crashes.


## SOURCES

- [DOJ-DOT-DHS — Joint Task Force Crossroads and commercial-driver enforcement actions](https://www.justice.gov/opa/pr/us-attorneys-and-department-justice-join-departments-transportation-and-homeland-security) — primary interagency release distinguishing emergency provider removals, proposed removals, audits, inspections, investigations and administration-reported metrics
- [FreightWaves — FMCSA removes 110 truck-driving schools](https://www.freightwaves.com/news/dot-shuts-down-110-truck-driving-schools-in-cdl-fraud-crackdown) — independent trucking-industry reporting on executed emergency removals, proposed additional removals and the tester audit

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
