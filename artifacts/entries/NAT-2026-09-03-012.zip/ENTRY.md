# Trump grants clemency to 30 people in an incompletely disclosed batch

**Entry ID:** NAT-2026-09-03-012
**Date:** September 3, 2026
**Checked:** 2026-09-05 12:00 AM EDT
**Evidence state:** official announcement by the White House pardon czar plus independent Reuters reporting and a checked DOJ clemency index; aggregate action and one recipient identified, complete warrants and recipient-level effects not yet public
**Review state:** current-standard-reviewed

The White House pardon czar announced 30 grants and identified Emory Jones, but the complete recipient list, pardon-versus-commutation breakdown and warrants were not public by cutoff.

## THE FACTS

- White House pardon czar Alice Marie Johnson announced on September 4 that President Trump had granted clemency to 30 people the prior day. Reuters independently reported the announcement and timing.
- Johnson identified Emory Jones among the recipients and said he had served nearly 16 years in federal prison on drug charges before his 2010 release. Her post described the group as deserving and framed the action as second chances; it did not publish the other 29 names or the legal instrument for each person.
- Reuters reported that the batch included pardons of convictions and commutations shortening sentences, but neither Johnson's announcement nor the Justice Department's public clemency index disclosed the pardon-versus-commutation count, complete recipient roster, offenses, sentencing terms, restitution effects or warrants by cutoff.
- The White House has said its clemency review emphasizes public safety, demonstrated change and second chances. That is the administration's stated standard; recipient-level documentation is needed to evaluate how it was applied in this batch.
- The grants are recorded as an officially announced and independently reported exercise of presidential clemency power. The archive does not infer undisclosed recipients, offenses or legal consequences from the aggregate count.

## SIGNIFICANCE

Presidential pardons and commutations alter federal criminal consequences without judicial or congressional approval. A 30-person batch is material, while the lack of contemporaneous recipient-level warrants prevents assessment of who benefited, what penalties changed and whether the stated review criteria were applied consistently.

## GOALPOST / RESPONSE

The administration describes clemency as a public-safety-conscious second-chance process for people who demonstrated change. The signed warrants, complete roster, offenses and sentences, pardon-versus-commutation breakdown, restitution and supervision terms, review records where lawfully available and recipient outcomes are the tests.

## MAYBE / THEREFORE

Maybe the batch reflects careful review of rehabilitation and disproportionate punishment, or incomplete disclosure may obscure inconsistent criteria, favoritism or legal effects. Therefore the record establishes the administration's announcement of 30 grants and Emory Jones's inclusion—not a complete accounting of recipients, reasons, instruments or consequences.


## SOURCES

- [White House pardon czar Alice Marie Johnson — announcement of 30 clemency grants](https://x.com/AliceMarieFree/status/2095970598316900499) — official White House clemency-process announcement identifying the aggregate count and Emory Jones
- [Reuters — Trump grants clemency to 30 people](https://www.reuters.com/world/us/trump-grants-clemency-30-people-white-house-pardon-czar-says-2026-09-05/) — independent reporting on the official announcement, timing, one named recipient and incomplete public roster
- [Justice Department — Trump clemency grants index checked after announced batch](https://www.justice.gov/pardon/clemency-grants-president-donald-j-trump-2025-present) — primary official clemency index; complete September 3 batch was not posted by cutoff
- [White House — presidential message on Second Chance Month](https://www.whitehouse.gov/briefings-statements/2026/04/presidential-message-on-second-chance-month/) — official administration statement of clemency review rationale and claimed public-safety standard

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
