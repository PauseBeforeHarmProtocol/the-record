# Federal judge rules Pentagon's Anthropic blacklist unlawful

**Entry ID:** NAT-2026-08-27-012
**Date:** August 27, 2026
**Checked:** 2026-08-27 11:58 PM EDT
**Evidence state:** federal case docket and independently consistent Reuters and AP reporting on the 59-page merits order; Pentagon designation held unlawful at district court, appeal and separate case unresolved
**Review state:** current-standard-reviewed

The district-court merits ruling blocks the supply-chain-risk designation after finding unlawful retaliation; a separate case under another procurement authority remains pending.

## THE FACTS

- U.S. District Judge Rita Lin issued a 59-page written merits ruling in Anthropic PBC v. U.S. Department of War, holding that the Pentagon acted unlawfully when it designated Anthropic a national-security supply-chain risk and imposed related penalties. Lin had temporarily blocked the measures in March; the August 27 order rules for Anthropic rather than merely predicting likely success.
- The court found that the measures were motivated by a desire to punish Anthropic for criticizing unrestricted military use of its Claude models, not by an articulated basis to believe the company would sabotage them. The ruling says the retaliation violated the First Amendment and that the designation was arbitrary and capricious under the governing procurement statute.
- The Justice Department argued that Anthropic's refusal to accept contract terms allowing any lawful military use created operational uncertainty and national-security risk, rather than punishment for its views. The Pentagon did not immediately comment, an appeal remained possible, and a separate Washington case concerning a different supply-chain-risk authority was still pending at the checked time.

## SIGNIFICANCE

The ruling limits the executive branch's ability to use national-security procurement authorities to penalize a domestic technology supplier for public disagreement over autonomous weapons and surveillance. It resolves the district-court merits stage of one case but does not settle the separate designation, possible appeal, or the broader military policy dispute over private AI safeguards.

## GOALPOST / RESPONSE

The Pentagon says military users, not contractors, must control lawful operational use and that uncertain model restrictions can endanger missions. Anthropic says current systems are not reliable enough for fully autonomous weapons and that mass domestic surveillance threatens rights. Appellate rulings, the separate D.C. case, procurement actions, contract terms, model reliability evidence, and any congressional standards are the tests.

## MAYBE / THEREFORE

Maybe the ruling will protect contractor speech while leaving the Pentagon free to choose vendors on documented operational grounds, or an appeal may restore broader deference to national-security designations. Therefore the record describes a district-court merits victory blocking this designation—not a final appellate resolution, an order requiring the Pentagon to contract with Anthropic, or a decision that all military uses of Claude are safe.


## SOURCES

- [Anthropic PBC v. U.S. Department of War — federal district-court docket](https://www.courtlistener.com/docket/72379655/anthropic-pbc-v-us-department-of-war/) — primary federal case docket for the merits ruling
- [Reuters — judge rules Pentagon's Anthropic blacklist unlawful](https://www.reuters.com/legal/government/us-judge-blocks-pentagons-anthropic-blacklisting-2026-08-28/) — independent reporting on the 59-page merits order and government defense
- [Associated Press — district judge rules for Anthropic in Pentagon blacklist case](https://apnews.com/article/anthropic-pentagon-lawsuit-supply-chain-risk-f15e3c30186385e73e72bee82d85b05c) — independent reporting on the merits ruling, prior injunction, and unresolved separate case

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
