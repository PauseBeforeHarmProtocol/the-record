# California court blocks one Anthropic designation while D.C. Circuit leaves another in place

**Entry ID:** NAT-2026-08-27-012
**Date:** August 27–September 25, 2026
**Checked:** 2026-09-25 11:59 AM EDT
**Evidence state:** federal case docket, primary Pentagon-official statement and Reuters and AP reporting; California merits ruling remains effective for one designation, D.C. Circuit denied interim relief against a separate designation and both appellate outcomes remain unresolved
**Review state:** current-standard-reviewed

A California merits ruling invalidated one Pentagon blacklist, but the D.C. Circuit declined interim relief against a separate supply-chain-risk designation; neither appellate dispute is finally resolved.

## THE FACTS

- U.S. District Judge Rita Lin issued a 59-page written merits ruling in Anthropic PBC v. U.S. Department of War, holding that the Pentagon acted unlawfully when it designated Anthropic a national-security supply-chain risk and imposed related penalties. Lin had temporarily blocked the measures in March; the August 27 order rules for Anthropic rather than merely predicting likely success.
- The court found that the measures were motivated by a desire to punish Anthropic for criticizing unrestricted military use of its Claude models, not by an articulated basis to believe the company would sabotage them. The ruling says the retaliation violated the First Amendment and that the designation was arbitrary and capricious under the governing procurement statute.
- The Justice Department argued that Anthropic's refusal to accept contract terms allowing any lawful military use created operational uncertainty and national-security risk, rather than punishment for its views. The Pentagon did not immediately comment, an appeal remained possible, and a separate Washington case concerning a different supply-chain-risk authority was still pending at the checked time.
- On September 3, Under Secretary of War for Research and Engineering Emil Michael said Anthropic “continues to be designated a Supply Chain Risk” by the Department of War and throughout the defense industrial base. His statement followed Commerce Secretary Howard Lutnick's public suggestion that the company was again trusted. The department did not identify in that statement which statutory designation remained, its operative scope, or how it complied with the August 27 Northern District of California ruling; the separate Washington litigation under a different authority also remained unresolved.
- On September 25, the D.C. Circuit declined to block a separate Pentagon supply-chain-risk designation while Anthropic's Washington case proceeds. Reuters reported that the designation remains blocked under the separate California judgment. The appellate refusal concerns interim relief in the Washington litigation; it is not a merits decision and does not reverse the California ruling.

## SIGNIFICANCE

The two cases now produce different interim practical results under distinct asserted authorities: one designation remains blocked in California while a separate Washington designation remains operative. The split does not itself establish which restrictions control every procurement or resolve the constitutional and statutory merits on appeal.

## GOALPOST / RESPONSE

The Pentagon says military users must control lawful operational use and that Anthropic presents supply-chain risk; Anthropic says the designations punish protected safety limits and exceed statutory authority. The exact operative instruments, contract effects, merits decisions in both cases, appeals and any agency compliance guidance are the tests.

## MAYBE / THEREFORE

Maybe the Washington designation rests on a legally distinct authority that survives the California ruling, or later merits review may find the same retaliatory or statutory defects. Therefore the record shows one blocked designation and one designation left in place at the interim-relief stage—not a final nationwide resolution of Anthropic's status.


## SOURCES

- [Anthropic PBC v. U.S. Department of War — federal district-court docket](https://www.courtlistener.com/docket/72379655/anthropic-pbc-v-us-department-of-war/) — primary federal case docket for the merits ruling
- [Reuters — judge rules Pentagon's Anthropic blacklist unlawful](https://www.reuters.com/legal/government/us-judge-blocks-pentagons-anthropic-blacklisting-2026-08-28/) — independent reporting on the 59-page merits order and government defense
- [Associated Press — district judge rules for Anthropic in Pentagon blacklist case](https://apnews.com/article/anthropic-pentagon-lawsuit-supply-chain-risk-f15e3c30186385e73e72bee82d85b05c) — independent reporting on the merits ruling, prior injunction, and unresolved separate case
- [Pentagon research chief Emil Michael — Anthropic remains designated a supply-chain risk](https://x.com/i/status/2095506733380588018) — primary public statement on the department's asserted continuing designation
- [Reuters — Pentagon official says Anthropic remains a supply-chain risk](https://www.reuters.com/business/anthropic-still-flagged-risk-defense-industrial-base-us-official-says-2026-09-03/) — independent reporting on conflicting administration statements and unresolved designation authority
- [Appeals court declines to block Pentagon's separate Anthropic designation](https://www.reuters.com/world/us-appeals-court-declines-block-pentagons-blacklisting-anthropic-2026-09-25/) — independent litigation reporting; interim relief denied in separate D.C. case

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
