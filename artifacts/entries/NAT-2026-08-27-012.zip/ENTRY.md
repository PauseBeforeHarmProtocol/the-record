# Federal judge rules Pentagon's Anthropic blacklist unlawful

**Entry ID:** NAT-2026-08-27-012
**Date:** August 27–September 3, 2026
**Checked:** 2026-09-03 12:03 PM EDT
**Evidence state:** federal case docket, primary Pentagon-official statement and independently consistent Reuters and AP reporting; one designation held unlawful at district court, asserted continuing risk status under publicly unidentified authority and separate litigation unresolved
**Review state:** current-standard-reviewed

A judge held one Pentagon blacklist unlawful, but a senior defense official now says Anthropic remains designated under an authority the public statements did not identify.

## THE FACTS

- U.S. District Judge Rita Lin issued a 59-page written merits ruling in Anthropic PBC v. U.S. Department of War, holding that the Pentagon acted unlawfully when it designated Anthropic a national-security supply-chain risk and imposed related penalties. Lin had temporarily blocked the measures in March; the August 27 order rules for Anthropic rather than merely predicting likely success.
- The court found that the measures were motivated by a desire to punish Anthropic for criticizing unrestricted military use of its Claude models, not by an articulated basis to believe the company would sabotage them. The ruling says the retaliation violated the First Amendment and that the designation was arbitrary and capricious under the governing procurement statute.
- The Justice Department argued that Anthropic's refusal to accept contract terms allowing any lawful military use created operational uncertainty and national-security risk, rather than punishment for its views. The Pentagon did not immediately comment, an appeal remained possible, and a separate Washington case concerning a different supply-chain-risk authority was still pending at the checked time.
- On September 3, Under Secretary of War for Research and Engineering Emil Michael said Anthropic “continues to be designated a Supply Chain Risk” by the Department of War and throughout the defense industrial base. His statement followed Commerce Secretary Howard Lutnick's public suggestion that the company was again trusted. The department did not identify in that statement which statutory designation remained, its operative scope, or how it complied with the August 27 Northern District of California ruling; the separate Washington litigation under a different authority also remained unresolved.

## SIGNIFICANCE

The merits ruling limits use of one national-security procurement authority to punish contractor speech, while the Pentagon research chief's later statement shows that Anthropic's practical status across the defense industrial base remains contested. The conflict between administration statements leaves contractors and agencies without a clear public account of which designation, authority or restrictions are operative.

## GOALPOST / RESPONSE

The Pentagon says military users, not contractors, must control lawful operational use and now says Anthropic remains a supply-chain risk. Anthropic says current systems are not reliable enough for fully autonomous weapons and that mass domestic surveillance threatens rights. The controlling designation instrument, statutory authority, implementation guidance, compliance with the California judgment, the separate D.C. case, any appeal, procurement actions, contract terms, model reliability evidence and congressional standards are the tests.

## MAYBE / THEREFORE

Maybe the September 3 statement refers to a legally distinct designation left untouched by the California judgment, or the department may be maintaining restrictions that the ruling requires it to withdraw. Therefore the record confirms a district-court merits victory and a later senior Pentagon claim that a supply-chain-risk designation continues; it does not infer the designation's legal basis, operational scope, compliance with the judgment or final appellate validity from conflicting public statements.


## SOURCES

- [Anthropic PBC v. U.S. Department of War — federal district-court docket](https://www.courtlistener.com/docket/72379655/anthropic-pbc-v-us-department-of-war/) — primary federal case docket for the merits ruling
- [Reuters — judge rules Pentagon's Anthropic blacklist unlawful](https://www.reuters.com/legal/government/us-judge-blocks-pentagons-anthropic-blacklisting-2026-08-28/) — independent reporting on the 59-page merits order and government defense
- [Associated Press — district judge rules for Anthropic in Pentagon blacklist case](https://apnews.com/article/anthropic-pentagon-lawsuit-supply-chain-risk-f15e3c30186385e73e72bee82d85b05c) — independent reporting on the merits ruling, prior injunction, and unresolved separate case
- [Pentagon research chief Emil Michael — Anthropic remains designated a supply-chain risk](https://x.com/i/status/2095506733380588018) — primary public statement on the department's asserted continuing designation
- [Reuters — Pentagon official says Anthropic remains a supply-chain risk](https://www.reuters.com/business/anthropic-still-flagged-risk-defense-industrial-base-us-official-says-2026-09-03/) — independent reporting on conflicting administration statements and unresolved designation authority

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
