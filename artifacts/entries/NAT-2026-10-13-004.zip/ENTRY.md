# CMS restriction on federal Medicaid and CHIP funding for specified youth gender-transition procedures takes effect

**Entry ID:** NAT-2026-10-13-004
**Date:** August 13–October 13, 2026
**Checked:** 2026-10-13 5:56 PM EDT
**Evidence state:** primary CMS final rule and regulatory analysis plus independent Associated Press reporting; federal funding restriction effective, limited transition established, implementation and outcomes not yet measured
**Review state:** current-standard-reviewed

The final rule bars federal matching funds for specified procedures, with a limited six-month hormone taper and continued mental-health funding.

## THE FACTS

- A CMS final rule published August 13 took effect October 13. It bars federal financial participation for procedures the rule calls ‘sex-rejecting procedures’ for Medicaid beneficiaries under 18 and separate-CHIP beneficiaries under 19 when used to align physical appearance or the body with a gender identity different from sex.
- The restriction covers puberty blockers, cross-sex hormones and specified surgeries for that purpose. It preserves federal funding for other medical uses, complications, verifiable disorders of sexual development, mental-health counseling and psychotherapy; it does not prevent states from using state-only funds where state law permits.
- Beneficiaries already receiving cross-sex hormones on the effective date may receive federal matching funds for a taper of up to six months. The transition does not extend to new hormone starts, puberty blockers or surgeries, for which federal matching funds cease on the effective date.
- CMS says the rule responds to an uncertain evidence base and risks of irreversible harm and is consistent with statutory quality and beneficiary-interest duties. Medical groups and advocates cited by Associated Press argue these treatments can be medically necessary and that withdrawing coverage can harm low-income transgender youth; current use and fiscal effects were not quantified in the reviewed independent report.

## SIGNIFICANCE

The effective rule changes the federal financing available for a defined category of care for low-income minors and shifts possible costs to states, providers or families. Its practical reach depends on state coverage choices, litigation, the transition period and the number of affected beneficiaries; effectiveness and health consequences have not yet been measured.

## GOALPOST / RESPONSE

CMS frames the restriction as a child-safety and program-integrity measure grounded in its evidence review while preserving counseling and nonfederal options. Tests include state-plan implementation, federal matching claims, beneficiary continuity during and after the taper, state-only coverage, litigation and measured physical, mental-health and fiscal outcomes.

## MAYBE / THEREFORE

Maybe the rule prevents federal financing of interventions whose pediatric risk-benefit evidence CMS considers insufficient, or it may interrupt medically necessary care and transfer costs without improving outcomes. Therefore the record shows a financing restriction has taken effect—not that all gender-affirming care is banned, that every state stopped coverage, or that either claimed health effect has been demonstrated.


## SOURCES

- [Federal Register — Medicaid and CHIP funding restriction for specified pediatric gender-transition procedures](https://www.federalregister.gov/documents/2026/08/13/2026-16508/medicaid-program-prohibition-on-federal-medicaid-and-childrens-health-insurance-program-funding-for) — primary final rule and regulatory analysis
- [Associated Press — Medicaid to stop federal payment for specified gender-affirming care for minors](https://apnews.com/article/39722b01ab47a891bbca643a7ae5dde6) — independent reporting and policy context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
