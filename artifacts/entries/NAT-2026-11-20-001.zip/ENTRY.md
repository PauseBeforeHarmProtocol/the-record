# DHS issues HAVANA Act brain-injury payment framework

**Entry ID:** NAT-2026-11-20-001
**Date:** Interim final rule published November 20, 2026; effective December 21, 2026
**Checked:** 2026-11-20 6:04 AM EST
**Evidence state:** official interim final rule; eligibility and payment framework issued, future effective date and appropriations contingency preserved
**Review state:** current-standard-reviewed

The interim final rule creates a DHS application and appeal process with 2026 awards of $157,200 or $209,600, but it is not effective until December 21 and payments depend on specific appropriations.

## THE FACTS

- The Department of Homeland Security published an interim final rule implementing the HAVANA Act for current and former DHS employees and covered dependents. The rule is scheduled to take effect December 21, 2026; publication does not establish that any individual payment has been approved or disbursed.
- The rule permits a discretionary, one-time, non-taxable payment for a qualifying brain injury connected to a covered incident. For 2026, the base payment is $157,200 and the base-plus payment for specified severe impacts is $209,600, tied to Level III of the Executive Schedule.
- DHS says eligibility requires documented medical evidence and an incident determination. Payments may use only funds appropriated in advance specifically for that purpose and will be processed first-come, first-served, so the rule does not itself appropriate money or guarantee an award.
- The DHS chief financial officer may approve payments. A denial may be appealed to the Office of Health Security within 60 days, while the amount of an approved payment is not appealable under the rule.

## SIGNIFICANCE

The rule creates the operative DHS process for substantial statutory payments to employees and family members reporting qualifying brain injuries associated with anomalous incidents. Its practical reach depends on medical and incident determinations plus appropriated funds.

## GOALPOST / RESPONSE

DHS presents the rule as a consistent compensation mechanism for employees and dependents with qualifying long-term brain injuries. The tests are the December 21 effective date, application access, incident and medical determinations, specific appropriations, approvals and denials, appeal outcomes, payment timing and whether eligible claimants actually receive funds.

## MAYBE / THEREFORE

Maybe the framework will provide meaningful compensation and a usable review process for DHS personnel and families with qualifying injuries, or appropriations limits and discretionary determinations may restrict access. Therefore DHS issued a future-effective payment framework; it did not appropriate funds, approve every applicant or document any completed payment or health outcome.


## SOURCES

- [Federal Register — DHS Implementation of HAVANA Act of 2021](https://www.federalregister.gov/documents/2026/11/20/2026-23713/implementation-of-havana-act-of-2021) — primary interim final rule and request for comments

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
