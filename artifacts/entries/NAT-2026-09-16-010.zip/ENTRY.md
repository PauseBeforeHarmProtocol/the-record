# SEC proposes ending federal shareholder-proposal rule and revising proxy process

**Entry ID:** NAT-2026-09-16-010
**Date:** September 16, 2026
**Checked:** 2026-09-21 12:01 PM EDT
**Evidence state:** complete Federal Register texts for both linked proposals, SEC release and independent Reuters reporting; proposed rules published with November 20 comment deadline, no final rule or implementation
**Review state:** current-standard-reviewed

Two linked proposals would rescind Rule 14a-8, expand companies' discretionary proxy authority and remove several delivery and filing requirements; comments close November 20.

## THE FACTS

- The Securities and Exchange Commission voted to propose rescinding Exchange Act Rule 14a-8, the federal framework requiring companies to include qualifying shareholder proposals in proxy materials. The proposal would leave whether proposals must be included to state law and, when state law permits, company governing documents.
- The linked proposal would amend Rule 14a-4 so companies could exercise broader discretionary voting authority over proposals presented at a meeting but omitted from company proxy materials, while requiring a check box allowing each shareholder to withhold that authority for the shareholder's shares.
- A separate same-day proposal would eliminate required delivery of annual reports to security holders, eliminate the 20-business-day delivery deadline for proxy statements incorporating material by reference, end notices of exempt solicitation, shorten the minimum broker search period from 20 to five business days and require contact information on proxy and information-statement covers.
- The SEC says the changes would return corporate-governance questions to states, reflect electronic filing and communication, reduce registrant burdens and reduce investor confusion. Reuters reported criticism that rescission could weaken a longstanding channel for investor oversight. Both actions remain proposals; the Federal Register comment periods end November 20, 2026, and no final rule or changed legal obligation existed by cutoff.

## SIGNIFICANCE

If finalized, the proposals would dismantle an 80-year federal route for shareholder proposals and change how companies distribute and vote proxy materials, shifting authority and costs among states, companies, proponents and investors. Existing requirements remain in force during rulemaking.

## GOALPOST / RESPONSE

The SEC says federal law does not authorize the current shareholder-proposal regime and that modernization can reduce burdens without sacrificing investor protection. Comment records, a final rule, legal challenges, company practices, proposal volume, voting participation, compliance costs and investor-access outcomes are the tests.

## MAYBE / THEREFORE

Maybe state law, private ordering and electronic filings can preserve meaningful shareholder participation at lower cost, or fragmented rules and broader company discretion may make proposals and informed voting harder. Therefore the SEC opened two formal rulemakings—not that Rule 14a-8 was rescinded, annual-report delivery ended or the projected benefits and harms occurred.


## SOURCES

- [Federal Register — proposed rescission of Rule 14a-8 and amendments to Rule 14a-4](https://www.federalregister.gov/documents/2026/09/21/2026-19260/rescission-of-rule-14a-8s-federal-regulation-of-shareholder-proposals-and-amendments-to-rule-14a-4) — complete primary proposed rule
- [Federal Register — Proxy Solicitation Modernization proposed rule](https://www.federalregister.gov/documents/2026/09/21/2026-19259/proxy-solicitation-modernization) — complete primary proposed rule
- [SEC — proposed shareholder-rule rescission and proxy-process reforms](https://www.sec.gov/newsroom/press-releases/2026-89-sec-proposes-rescission-shareholder-proposal-rule-reforms-proxy-solicitation-process) — official agency announcement and rationale
- [Reuters — SEC proposes ending federal shareholder-vote oversight](https://www.reuters.com/legal/government/sec-proposes-end-shareholder-vote-oversight-blow-reformers-2026-09-16/) — independent reporting on the proposals, administration rationale and criticism

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
