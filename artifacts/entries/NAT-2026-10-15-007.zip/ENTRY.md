# Nine fired FBI employees sue over Mar-a-Lago investigation terminations

**Entry ID:** NAT-2026-10-15-007
**Date:** February–October 15, 2026
**Checked:** 2026-10-15 11:57 PM EDT
**Evidence state:** Filed complaint indexed through DocumentCloud plus independent Associated Press and Axios reporting; terminations and requested remedies reported, retaliation and process violations alleged and unadjudicated
**Review state:** current-standard-reviewed

The filed suit seeks reinstatement and back pay, alleging political retaliation and denied process; Patel’s stated rationale was poor judgment and politicization, and no court has resolved the claims.

## THE FACTS

- Nine former FBI agents, intelligence analysts and staff operations specialists filed a federal lawsuit in Washington seeking reinstatement, back pay and a declaration that their February 2026 terminations were unlawful.
- The complaint alleges the employees were fired because they had been assigned to the FBI investigation of Trump’s retention of classified documents at Mar-a-Lago, without an internal investigation, notice, hearing or appeal. Those retaliation and due-process assertions remain plaintiffs’ allegations.
- Associated Press reported that the employees did not volunteer for the investigation and that their other work included counterintelligence, hostage recovery, the Boston Marathon bombing response and the 2024 assassination-attempt investigation. The filing says several participated in the 2022 search and one signed the warrant affidavit.
- FBI Director Kash Patel has said the terminated employees exercised poor judgment, lacked impartiality and contributed to political weaponization; the plaintiffs deny misconduct. The suit documents a formal challenge to completed firings but does not establish retaliatory motive or entitlement to reinstatement.

## SIGNIFICANCE

The lawsuit places nine completed career-personnel removals tied to an investigation of Trump before a federal court and tests civil-service process and political-retaliation limits at the FBI. The national-security and institutional stakes are substantial, while motive and legality remain unresolved.

## GOALPOST / RESPONSE

Patel says the removals addressed poor judgment and politicization; the plaintiffs say they were punished for assigned investigative work without required process. Termination records, internal investigations, comparator evidence, discovery, civil-service jurisdiction rulings and any reinstatement or back-pay order are the tests.

## MAYBE / THEREFORE

Maybe the FBI can substantiate case-specific performance grounds or jurisdictional defenses unrelated to politics, or the employees may prove that the stated rationale was pretextual. Therefore nine firings and a filed reinstatement suit are established—not a judicial finding of political retaliation, employee misconduct or unlawful dismissal.


## SOURCES

- [Nine former FBI employees — complaint challenging February terminations](https://www.documentcloud.org/documents/26088065-fired-fbi-agents-lawsuit/) — primary filed complaint
- [Associated Press — fired FBI employees sue for reinstatement](https://apnews.com/article/fired-fbi-agents-lawsuit-trump-patel-maralago-69d3544a73ddcdb54f164807adde85ea) — independent reporting on filed employment suit
- [Axios — fired FBI employees challenge Mar-a-Lago-probe terminations](https://www.axios.com/2026/10/15/trump-fbi-agents-lawsuit-classified-documents-firings) — independent reporting on filed complaint and stated FBI rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
