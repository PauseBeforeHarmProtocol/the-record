# Administration reports early Medicare Bridge GLP-1 uptake

**Entry ID:** NAT-2026-08-31-007
**Date:** August 31, 2026
**Checked:** 2026-08-31 6:03 PM EDT
**Evidence state:** Reuters reporting of CMS Administrator Oz's on-record 600,000 figure, primary CMS program terms and a same-day White House fact sheet reporting more than 500,000 and claimed savings; early uptake reported by the administration, methodology and outcomes unresolved
**Review state:** current-standard-reviewed

CMS Administrator Mehmet Oz said 600,000 seniors sought or signed up for prescriptions in the program's first two months; the figure is administration-reported and differs from a same-day White House count.

## THE FACTS

- CMS Administrator Mehmet Oz said on August 31 that 600,000 seniors had signed up to receive, or had sought prescriptions for, GLP-1 weight-loss medicines during the first two months of the Medicare GLP-1 Bridge. Reuters used both formulations in separate coverage of the announcement.
- CMS launched the time-limited demonstration on July 1 for eligible Medicare Part D enrollees who meet clinical criteria, offering a monthly supply for a $50 copayment. The bridge is intended to run through December 31, 2027 while a broader Medicare model is prepared.
- A White House fact sheet published the same day said more than 500,000 seniors had saved $216 million through the program. It did not reconcile that figure with Oz's 600,000 count or publish a denominator, claims methodology, prescription-fill count, unique-beneficiary count or savings calculation.
- The figures establish an administration-reported early participation signal, not independently audited enrollment, completed dispensing, adherence, clinical benefit or net federal savings. A request or enrollment also does not necessarily mean that a beneficiary filled or continued a prescription.

## SIGNIFICANCE

The reported participation suggests substantial demand for a new federal coverage pathway in a drug class that Medicare historically excluded for weight loss alone. Its fiscal, access and health effects depend on verified claims, continued use, negotiated prices, eligibility decisions and outcomes over the full demonstration.

## GOALPOST / RESPONSE

CMS says the bridge makes evidence-based obesity treatment more affordable and accessible while transitioning to a larger model. The strongest caution is that a headline sign-up count does not show dispensed doses, persistence, clinical outcomes or net savings. CMS claims data, unique beneficiary and fill counts, denials, discontinuation, adverse events, spending, manufacturer payments and independently evaluated outcomes are the tests.

## MAYBE / THEREFORE

Maybe the two administration figures describe different stages or cutoff times and will reconcile in detailed claims data, or the gap may reflect imprecise promotional counting. Therefore the record reports Oz's 600,000 early-uptake claim with the White House's lower same-day figure and does not convert either into a verified count of treated patients, measured health improvement or audited savings.


## SOURCES

- [Reuters — Oz reports early Medicare Bridge GLP-1 uptake](https://www.reuters.com/legal/litigation/600000-seniors-have-signed-up-obesity-drugs-under-new-medicare-program-2026-08-31/) — independent reporting of the CMS administrator's 600,000 early sign-up claim and the program's monthly patient cost
- [CMS — Medicare GLP-1 Bridge program terms](https://www.cms.gov/newsroom/press-releases/coming-soon-cms-provide-50-monthly-access-glp-1-medications-medicare-beneficiaries) — primary program announcement describing the time-limited demonstration, eligible Part D population and $50 monthly supply
- [White House — nine additional most-favored-nation pharmaceutical arrangements](https://www.whitehouse.gov/fact-sheets/2026/08/fact-sheet-president-donald-j-trump-announces-deal-with-nine-additional-pharmaceutical-manufacturers-to-lower-drug-prices-for-americans/) — primary administration fact sheet naming manufacturers, pricing representations, manufacturing commitments, API pledges and projected savings

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
