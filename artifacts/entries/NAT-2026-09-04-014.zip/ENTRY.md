# CDC reports 4,410 measles cases and deploys Pennsylvania support amid death-count dispute

**Entry ID:** NAT-2026-09-04-014
**Date:** January–October 16, 2026
**Checked:** 2026-10-16 11:57 AM EDT
**Evidence state:** primary CDC surveillance and methodology plus independent Reuters reporting on current totals, state figures and announced Epi-Aid support; case scale and assistance announcement documented, deployment completion, classifications and effectiveness unresolved
**Review state:** current-standard-reviewed

Federal assistance moved from a conditional dispute to an announced Epi-Aid deployment as confirmed cases and hospitalizations continued to rise.

## THE FACTS

- CDC reported 4,410 confirmed U.S. measles cases as of October 15, up 330 from the prior weekly update, according to Reuters. Reuters reported 451 hospitalizations; the total is a surveillance count subject to later revision, not a measure of infections that were never diagnosed or reported.
- CDC’s public page listed two measles-associated deaths, while Pennsylvania reported five measles-related deaths. CDC says the number is subject to review and that it is working with the Council of State and Territorial Epidemiologists on a standardized death definition; The Record does not have the underlying case files and does not adjudicate the classifications.
- Pennsylvania formally requested CDC Epi-Aid assistance, and CDC said on October 13 that it would deploy additional support to investigate the outbreak, strengthen response and prevent spread. The announcement changes the earlier conditional-request status, but it does not establish the deployment date, staffing, completed work or measured effect.
- Pennsylvania reported 1,222 cases and 225 hospitalizations as of October 14, Reuters said. The state and federal figures update on different schedules and use reviewed reporting processes, so they should not be treated as a synchronized real-time ledger.
- CDC states that MMR coverage among kindergartners fell from 95.2% in 2019–20 to 92.4% in 2025–26, leaving about 280,000 kindergartners at risk. CDC also identifies rising global measles activity and pockets of lower local coverage; those factors do not isolate the effect of any single federal, state, local or personal decision on the 2026 total.
- The prior dispute remains material: Pennsylvania sought recognition of its state classifications, while federal officials argued that assistance and standardized death-count review should be separate. The announced Epi-Aid support shows assistance proceeding; it does not resolve the death-count dispute or prove that either side’s classifications are medically correct.

## SIGNIFICANCE

The national outbreak expanded substantially while federal assistance to Pennsylvania moved from a disputed conditional request to an announced deployment. That is a concrete response step and a measurable health outcome, but surveillance totals, death classifications and the effect of federal support remain provisional or unresolved.

## GOALPOST / RESPONSE

CDC says Epi-Aid teams can help jurisdictions investigate outbreaks and prevent spread, while standardized definitions are intended to make death reporting consistent. Deployment records, staffing, completed field work, state and federal case and death revisions, vaccination uptake, transmission trends and hospitalization outcomes are the tests—not an assistance announcement or either side’s classification alone.

## MAYBE / THEREFORE

Maybe the deployment and local response will slow transmission while standardized review reconciles death counts, or the outbreak may continue despite assistance and the classification dispute may persist. Therefore the record establishes 4,410 confirmed cases, 451 reported hospitalizations, competing death counts and announced federal support—not a final mortality ledger, completed deployment or proven causal allocation.


## SOURCES

- [CDC — 2026 measles cases and outbreaks, updated October 16](https://www.cdc.gov/measles/data-research/index.html) — primary federal surveillance data updated October 16
- [Reuters — CDC to deploy additional Pennsylvania measles support](https://www.reuters.com/business/healthcare-pharmaceuticals/cdc-deploy-additional-support-pennsylvania-probe-measles-outbreak-2026-10-13/) — independent report with CDC and state responses
- [Reuters — CDC reports 4,410 measles cases](https://www.reuters.com/legal/litigation/cdc-reports-4410-measles-cases-outbreak-grows-2026-10-16/) — independent report on CDC and Pennsylvania surveillance data

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
