# CDC reports 3,134 measles cases, the highest annual count in more than 35 years

**Entry ID:** NAT-2026-09-04-014
**Date:** January–September 3, 2026
**Checked:** 2026-09-04 6:00 PM EDT
**Evidence state:** primary CDC surveillance data plus independent Reuters reporting; national count and outbreak share measured, policy-specific causation unresolved
**Review state:** current-standard-reviewed

The federal surveillance total measures a major outbreak year; it does not by itself establish that a particular administration policy caused the cases.

## THE FACTS

- The Centers for Disease Control and Prevention reported 3,134 confirmed U.S. measles cases in 2026 as of September 3, the highest annual total in more than 35 years, according to Reuters.
- CDC said 2,969 cases, or 95%, were associated with outbreaks. The agency reported 38 new outbreaks in 2026, with 1,594 cases tied to outbreaks that began this year and 1,375 tied to outbreaks that began in 2025; 16 cases involved international visitors.
- For comparison, CDC reported 2,289 confirmed cases for all of 2025 and 285 for 2024. The agency says confirmed cases reach it through state, local, tribal and territorial health departments and that states can publish newer figures on different schedules.
- CDC states that MMR coverage among kindergartners fell from 95.2% in 2019–20 to 92.4% in 2025–26, leaving about 280,000 kindergartners at risk, while global measles activity also increases importation opportunities. Those factors do not isolate the effect of any single federal, state, local or personal decision on the 2026 total.

## SIGNIFICANCE

A record measles year after national elimination in 2000 is a material public-health outcome and creates risks of hospitalization, preventable disability and loss of elimination status. The surveillance count supports measuring the problem, but causal accountability requires more granular vaccination, transmission and policy evidence.

## GOALPOST / RESPONSE

CDC says measles spreads when imported infections reach communities with insufficient vaccination and continues to recommend the safe and effective MMR vaccine. Jurisdiction-level vaccination and case data, outbreak chains, hospitalization and death records, federal and state guidance, vaccine access and uptake and formal elimination-status review are the tests.

## MAYBE / THEREFORE

Maybe the 2026 surge primarily reflects outbreaks that began earlier, local coverage gaps and increased global exposure, or contemporaneous federal messaging and policy may have worsened vaccine confidence or response capacity. Therefore the record confirms 3,134 reported cases and declining kindergarten coverage—not that the Trump administration alone caused the outbreaks or that any disputed intervention in CDC reporting occurred.


## SOURCES

- [CDC — 2026 measles cases and outbreaks](https://www.cdc.gov/measles/data-research/index.html) — primary federal surveillance data updated September 4
- [Reuters — U.S. measles count exceeds 3,100 cases](https://www.reuters.com/legal/litigation/us-cdc-records-more-than-3100-measles-cases-so-far-2026-2026-09-04/) — independent reporting on the federal surveillance count and historical comparison

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
