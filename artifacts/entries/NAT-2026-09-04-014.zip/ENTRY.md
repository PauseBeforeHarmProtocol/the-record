# CDC reports 5,412 measles cases as vaccination decline and pregnancy harms deepen

**Entry ID:** NAT-2026-09-04-014
**Date:** January–November 17, 2026
**Checked:** 2026-11-17 12:05 PM EST
**Evidence state:** primary CDC surveillance and PAHO re-verification framework plus independent Reuters, AP and KFF Health News reporting; elimination-status loss formally announced, counts and causal allocation remain provisional or disputed
**Review state:** current-standard-reviewed

PAHO formally announced that the United States lost measles-elimination status after 26 years, as federal and state surveillance continued to show thousands of cases and declining vaccination coverage.

## THE FACTS

- CDC reported 5,412 confirmed measles cases assigned to 2026 as of November 12, including 5,394 cases in 47 jurisdictions and 18 among international visitors. CDC counted 43 outbreaks and said 96% of confirmed cases were outbreak-associated; the surveillance totals are preliminary and update on a different schedule from state dashboards.
- CDC listed six measles-associated deaths for 2026, subject to review, while Reuters counted more than 7,700 cases and 13 state-reported deaths since 2025. Those are different scopes and classification processes, so The Record does not combine them into one synchronized federal total.
- CDC says kindergarten MMR coverage fell from 95.2% in 2019–20 to 92.4% in 2025–26, leaving about 280,000 kindergartners at risk. Reuters separately analyzed younger-child immunization data from 13 states and New York City and found a broader decline in 2025; in Utah, the seven-vaccine toddler series fell 2.4 percentage points to 69.6%, while first-dose MMR fell 0.7 point to 86.6%.
- AP reported preliminary CDC findings of 112 measles cases during pregnancy and 13 congenital cases from January 2025 through September 2026. The findings were presented as a public-health alert and had not completed journal publication, so they establish a reported preliminary measurement rather than a final national study.
- Reuters and Associated Press reported PAHO’s November 17 formal announcement that the United States lost measles-elimination status after sustained transmission, ending 26 years with that classification. Bolivia and Mexico also lost status; the reviewed PAHO decision page itself was not retrievable by cutoff, so the announcement is independently corroborated while the formal instrument remains an access gap.
- HHS said vaccination gaps and declining coverage began before this administration and rejected claims that Secretary Robert F. Kennedy Jr. caused the resurgence. The White House said Trump and Kennedy repeatedly encouraged measles vaccination, coordinated with states and facilitated vaccine-dose deployment; CDC said roughly 250 people were working on measles nationally and assistance was available or provided.

## SIGNIFICANCE

The formal PAHO announcement converts the prior reported expectation into an internationally recognized public-health reversal after 26 years. It does not itself identify one cause, finalize surveillance counts or measure the effect of any particular federal response.

## GOALPOST / RESPONSE

Administration claims and outbreak-response performance should be tested through CDC and state surveillance revisions, vaccination uptake, confirmed interruption of transmission, PAHO re-verification requirements, published pregnancy evidence, field-assistance records, hospitalizations and deaths—not by treating classification status or provisional counts as a single-cause finding.

## MAYBE / THEREFORE

Maybe long-running vaccination decline and local variation explain much of the resurgence, or federal messaging, funding and response choices worsened an already fragile baseline. Therefore the evidence establishes a formal loss of elimination status, sharply higher case counts, declining coverage and reported pregnancy-associated harm—not a single-cause finding, a final mortality ledger or proof that one intervention would have prevented every case.


## SOURCES

- [CDC — 2026 measles cases and outbreaks, data through November 12](https://www.cdc.gov/measles/data-research/index.html) — primary federal surveillance data
- [Reuters — investigation of measles response and vaccination declines](https://www.reuters.com/investigations/how-kennedy-let-measles-run-wild-america-2026-11-17/) — independent investigation and data analysis with attributed administration responses
- [KFF Health News — U.S. measles elimination-status decision and response](https://kffhealthnews.org/public-health/us-measles-elimination-status-lost-outbreaks-continuous-spread-year-paho-cdc/) — independent public-health reporting and administration response
- [Associated Press — CDC scientists report congenital and pregnancy-associated measles cases](https://apnews.com/article/measles-newborns-congenital-cdc-mmr-vaccine-a58272bce83828699dbb4d2eba4e27a1) — independent reporting on preliminary CDC findings
- [US loses measles elimination status after nearly three decades](https://www.reuters.com/business/healthcare-pharmaceuticals/us-loses-measles-elimination-status-after-nearly-three-decades-2026-11-17/) — independent reporting
- [US loses measles elimination status after 26 years](https://apnews.com/article/b6694152aca12e8cf4293d9f50090ec9) — independent reporting
- [Measles and Rubella Elimination Regional Monitoring and Re-Verification Commission meeting](https://www.paho.org/en/news/14-10-2026-measles-and-rubella-elimination-regional-monitoring-and-re-verification-commission) — official public-health statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
