# CDC reports 5,412 measles cases as vaccination decline and pregnancy harms deepen

**Entry ID:** NAT-2026-09-04-014
**Date:** January–November 17, 2026
**Checked:** 2026-11-17 6:31 AM EST
**Evidence state:** primary CDC surveillance plus independent Reuters, KFF Health News and AP reporting; federal totals measured and provisional, vaccination analyses reported, pregnancy findings preliminary, and the PAHO classification reported but not yet located in a public PAHO announcement at cutoff
**Review state:** current-standard-reviewed

CDC counted 5,412 confirmed 2026 cases and six deaths as independent reporting documented deeper state totals, falling vaccination and pregnancy-associated harm; the international classification decision remained publicly unannounced at cutoff.

## THE FACTS

- CDC reported 5,412 confirmed measles cases assigned to 2026 as of November 12, including 5,394 cases in 47 jurisdictions and 18 among international visitors. CDC counted 43 outbreaks and said 96% of confirmed cases were outbreak-associated; the surveillance totals are preliminary and update on a different schedule from state dashboards.
- CDC listed six measles-associated deaths for 2026, subject to review, while Reuters counted more than 7,700 cases and 13 state-reported deaths since 2025. Those are different scopes and classification processes, so The Record does not combine them into one synchronized federal total.
- CDC says kindergarten MMR coverage fell from 95.2% in 2019–20 to 92.4% in 2025–26, leaving about 280,000 kindergartners at risk. Reuters separately analyzed younger-child immunization data from 13 states and New York City and found a broader decline in 2025; in Utah, the seven-vaccine toddler series fell 2.4 percentage points to 69.6%, while first-dose MMR fell 0.7 point to 86.6%.
- AP reported preliminary CDC findings of 112 measles cases during pregnancy and 13 congenital cases from January 2025 through September 2026. The findings were presented as a public-health alert and had not completed journal publication, so they establish a reported preliminary measurement rather than a final national study.
- Reuters and KFF Health News independently reported that PAHO had determined the United States no longer met measles-elimination criteria after sustained transmission. PAHO had planned a November 17 public announcement, but no public PAHO decision page was located by this cutoff; the classification is therefore recorded as independently reported, not as a newly inspected public PAHO instrument.
- HHS said vaccination gaps and declining coverage began before this administration and rejected claims that Secretary Robert F. Kennedy Jr. caused the resurgence. The White House said Trump and Kennedy repeatedly encouraged measles vaccination, coordinated with states and facilitated vaccine-dose deployment; CDC said roughly 250 people were working on measles nationally and assistance was available or provided.

## SIGNIFICANCE

The federal count rose by more than 1,000 since the prior version, while independent analyses documented broader vaccination decline and harms affecting pregnancy and newborns. The reported elimination-status loss marks a major public-health reversal, but causal allocation and several counts remain contested or preliminary.

## GOALPOST / RESPONSE

Administration claims and outbreak-response performance should be tested through subsequent CDC and state surveillance revisions, vaccination uptake, confirmed transmission interruption, public PAHO classification and re-verification criteria, published pregnancy evidence, field-assistance records, hospitalizations and deaths—not by treating provisional counts, reported attribution or a planned announcement as final proof.

## MAYBE / THEREFORE

Maybe long-running vaccination decline and local variation explain much of the resurgence, or federal messaging, funding and response choices worsened an already fragile baseline. Therefore the evidence establishes sharply higher confirmed cases, declining coverage and reported pregnancy-associated harm, plus a reported loss of elimination status—not a single-cause finding, a final mortality ledger or proof that any one intervention would have prevented every case.


## SOURCES

- [CDC — 2026 measles cases and outbreaks, data through November 12](https://www.cdc.gov/measles/data-research/index.html) — primary federal surveillance data
- [Reuters — investigation of measles response and vaccination declines](https://www.reuters.com/investigations/how-kennedy-let-measles-run-wild-america-2026-11-17/) — independent investigation and data analysis with attributed administration responses
- [KFF Health News — U.S. measles elimination-status decision and response](https://kffhealthnews.org/public-health/us-measles-elimination-status-lost-outbreaks-continuous-spread-year-paho-cdc/) — independent public-health reporting and administration response
- [Associated Press — CDC scientists report congenital and pregnancy-associated measles cases](https://apnews.com/article/measles-newborns-congenital-cdc-mmr-vaccine-a58272bce83828699dbb4d2eba4e27a1) — independent reporting on preliminary CDC findings

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
