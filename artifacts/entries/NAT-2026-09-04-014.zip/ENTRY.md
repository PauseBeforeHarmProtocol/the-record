# Pennsylvania conditions CDC measles aid request on recognition of four deaths

**Entry ID:** NAT-2026-09-04-014
**Date:** January–September 17, 2026
**Checked:** 2026-09-18 5:59 AM EDT
**Evidence state:** primary CDC surveillance language and health-secretary statements plus independent Reuters and Associated Press reporting; outbreak scale and conditional request documented, death classifications and aid disposition unresolved
**Review state:** current-standard-reviewed

The state says it will withdraw its Epi-Aid request unless CDC recognizes four state-classified deaths; federal officials reject linking aid to the count.

## THE FACTS

- The Centers for Disease Control and Prevention reported 3,134 confirmed U.S. measles cases in 2026 as of September 3, the highest annual total in more than 35 years, according to Reuters.
- CDC said 2,969 cases, or 95%, were associated with outbreaks. The agency reported 38 new outbreaks in 2026, with 1,594 cases tied to outbreaks that began this year and 1,375 tied to outbreaks that began in 2025; 16 cases involved international visitors.
- For comparison, CDC reported 2,289 confirmed cases for all of 2025 and 285 for 2024. The agency says confirmed cases reach it through state, local, tribal and territorial health departments and that states can publish newer figures on different schedules.
- CDC states that MMR coverage among kindergartners fell from 95.2% in 2019–20 to 92.4% in 2025–26, leaving about 280,000 kindergartners at risk, while global measles activity also increases importation opportunities. Those factors do not isolate the effect of any single federal, state, local or personal decision on the 2026 total.
- In a September 4 statement, Health Secretary Robert F. Kennedy Jr. said the Lancaster County coroner had attributed one infant's death to measles while rejecting the state's classification of a second death. Pennsylvania's health department continued to report two measles-related deaths. The Record does not have the underlying case files and does not resolve that medical classification dispute.
- CDC's September 4 page says the National Center for Health Statistics does not currently have a 2026 death record listing measles as the underlying cause and that CDC is working with the Council of State and Territorial Epidemiologists on a standardized death definition. It says reporting will be updated after additional information and review.
- Reuters previously reported, based on unnamed sources, that Kennedy asked CDC to remove the two Pennsylvania deaths after CDC staff had accepted the state classification. Kennedy's new public statement confirms his disagreement with Pennsylvania and the present zero-death federal display; it does not independently establish every detail of the reported internal intervention.
- By September 17, Pennsylvania classified four deaths as measles-associated amid more than 700 reported cases across 37 counties. Associated Press independently reported the fourth death; the underlying case files remain unavailable to The Record, so the medical classifications are not independently adjudicated here.
- Reuters reviewed a letter from Pennsylvania Health Secretary Debra Bogen saying the state had begun a formal CDC Epi-Aid request but would rescind it unless CDC acknowledged all four deaths. HHS said CDC had not received the request through normal channels, said outbreak assistance is separate from death-count reconciliation and accused the state of political blackmail. The conditional letter does not establish that federal assistance was delivered or denied.

## SIGNIFICANCE

The dispute now affects both public surveillance and a conditional request for federal outbreak assistance during a large state epidemic. Conflicting death classifications remain unresolved, and tying aid to the dispute could affect response capacity without proving that either side's classification is medically correct.

## GOALPOST / RESPONSE

Pennsylvania says its classifications follow state investigation and wants CDC to recognize all four before continuing the Epi-Aid request. HHS says assistance should remain separate from the count and that federal review must use standardized evidence. Receipt and disposition of a formal request, deployed staff, case files, written classification criteria, a completed NCHS/CSTE review and revised state or federal totals are the tests.

## MAYBE / THEREFORE

Maybe the dispute reflects legitimate differences between state measles-associated and federal underlying-cause measures that a joint review can reconcile, or political conflict may be obstructing transparent surveillance and assistance. Therefore the record confirms Pennsylvania's four classifications and conditional request plus HHS's rejection of the condition—not the correct classification of each death, a refusal of completed aid or a proven motive.


## SOURCES

- [CDC — 2026 measles cases and outbreaks](https://www.cdc.gov/measles/data-research/index.html) — primary federal surveillance data updated September 4
- [Reuters — U.S. measles count exceeds 3,100 cases](https://www.reuters.com/legal/litigation/us-cdc-records-more-than-3100-measles-cases-so-far-2026-2026-09-04/) — independent reporting on the federal surveillance count and historical comparison
- [HHS Secretary Kennedy — statement on Pennsylvania measles deaths](https://x.com/SecKennedy/status/2095972590808416484) — primary public statement describing the secretary's position on two disputed death classifications
- [Reuters — Kennedy acknowledges one Pennsylvania measles death as federal review continues](https://www.reuters.com/legal/litigation/kennedy-acknowledges-one-measles-death-pennsylvania-2026-09-05/) — independent reporting on the federal-state classification dispute, CDC reporting status and unresolved case-level evidence
- [Reuters — Pennsylvania conditions CDC measles-outbreak aid request on death-count recognition](https://www.reuters.com/world/pennsylvania-asks-cdc-help-measles-outbreak-demands-agency-recognize-measles-2026-09-17/) — independent reporting based on the state health secretary's letter and an attributed HHS response
- [Associated Press — Pennsylvania reports fourth measles-associated death](https://apnews.com/article/5267e2deff65b12941e6a1c279976f13) — independent public-health reporting on the state classification and federal disagreement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
