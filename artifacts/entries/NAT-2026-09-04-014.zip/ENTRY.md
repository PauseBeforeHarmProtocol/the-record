# CDC reports 3,134 measles cases while federal and Pennsylvania death counts diverge

**Entry ID:** NAT-2026-09-04-014
**Date:** January–September 4, 2026
**Checked:** 2026-09-05 6:00 AM EDT
**Evidence state:** primary CDC surveillance and reporting language, the health secretary's public statement and independent Reuters reporting; case total measured, death classifications disputed and internal intervention details partly reported from unnamed sources
**Review state:** current-standard-reviewed

The federal surveillance total measures a major outbreak year, while CDC records no 2026 measles deaths and Pennsylvania maintains that two occurred; the public record does not resolve the case-level dispute.

## THE FACTS

- The Centers for Disease Control and Prevention reported 3,134 confirmed U.S. measles cases in 2026 as of September 3, the highest annual total in more than 35 years, according to Reuters.
- CDC said 2,969 cases, or 95%, were associated with outbreaks. The agency reported 38 new outbreaks in 2026, with 1,594 cases tied to outbreaks that began this year and 1,375 tied to outbreaks that began in 2025; 16 cases involved international visitors.
- For comparison, CDC reported 2,289 confirmed cases for all of 2025 and 285 for 2024. The agency says confirmed cases reach it through state, local, tribal and territorial health departments and that states can publish newer figures on different schedules.
- CDC states that MMR coverage among kindergartners fell from 95.2% in 2019–20 to 92.4% in 2025–26, leaving about 280,000 kindergartners at risk, while global measles activity also increases importation opportunities. Those factors do not isolate the effect of any single federal, state, local or personal decision on the 2026 total.
- In a September 4 statement, Health Secretary Robert F. Kennedy Jr. said the Lancaster County coroner had attributed one infant's death to measles while rejecting the state's classification of a second death. Pennsylvania's health department continued to report two measles-related deaths. The Record does not have the underlying case files and does not resolve that medical classification dispute.
- CDC's September 4 page says the National Center for Health Statistics does not currently have a 2026 death record listing measles as the underlying cause and that CDC is working with the Council of State and Territorial Epidemiologists on a standardized death definition. It says reporting will be updated after additional information and review.
- Reuters previously reported, based on unnamed sources, that Kennedy asked CDC to remove the two Pennsylvania deaths after CDC staff had accepted the state classification. Kennedy's new public statement confirms his disagreement with Pennsylvania and the present zero-death federal display; it does not independently establish every detail of the reported internal intervention.

## SIGNIFICANCE

A record measles year after national elimination in 2000 is a material public-health outcome and creates risks of hospitalization, preventable disability and loss of elimination status. Divergent federal and state death reporting also affects surveillance credibility, but the public evidence does not establish the correct medical classification of either infant's death.

## GOALPOST / RESPONSE

CDC says its standardized work is intended to make death classification consistent; Kennedy says federal review should follow complete records, while Pennsylvania maintains that both deaths were measles-related. Death certificates and case files where lawfully releasable, written classification criteria, CSTE's definition, a completed NCHS review, revised state or federal totals and transparent explanation of any change are the tests.

## MAYBE / THEREFORE

Maybe federal review will produce a more consistent standard and reconcile legitimate differences between underlying-cause and measles-related-death measures, or political direction may be displacing accepted state surveillance judgments. Therefore the record confirms 3,134 cases, CDC's present zero-death display, Kennedy's acknowledgement of one coroner-attributed measles death and Pennsylvania's two-death position—not the correct classification of either case, a proven motive or that federal policy alone caused the outbreak.


## SOURCES

- [CDC — 2026 measles cases and outbreaks](https://www.cdc.gov/measles/data-research/index.html) — primary federal surveillance data updated September 4
- [Reuters — U.S. measles count exceeds 3,100 cases](https://www.reuters.com/legal/litigation/us-cdc-records-more-than-3100-measles-cases-so-far-2026-2026-09-04/) — independent reporting on the federal surveillance count and historical comparison
- [HHS Secretary Kennedy — statement on Pennsylvania measles deaths](https://x.com/SecKennedy/status/2095972590808416484) — primary public statement describing the secretary's position on two disputed death classifications
- [Reuters — Kennedy acknowledges one Pennsylvania measles death as federal review continues](https://www.reuters.com/legal/litigation/kennedy-acknowledges-one-measles-death-pennsylvania-2026-09-05/) — independent reporting on the federal-state classification dispute, CDC reporting status and unresolved case-level evidence

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
