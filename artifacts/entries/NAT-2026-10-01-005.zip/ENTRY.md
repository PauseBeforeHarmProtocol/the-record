# Pentagon raises hostile-fire and imminent-danger pay

**Entry ID:** NAT-2026-10-01-005
**Date:** October 1, 2026
**Checked:** 2026-10-01 6:00 PM EDT
**Evidence state:** official Defense announcement and independent reporting on the implementing memorandum and effective rates; pay implemented, recipient counts and outcomes unmeasured
**Review state:** current-standard-reviewed

The military-wide rates took effect October 1, raising hostile-fire pay to $450 monthly and imminent-danger pay to as much as $275; receipt depends on incident or location eligibility.

## THE FACTS

- The Defense Department implemented new hostile-fire and imminent-danger pay rates across the armed services effective October 1. Hostile-fire pay rose to $450 per month, while imminent-danger pay rose to $9.16 per eligible day, capped at $275 per month.
- Hostile-fire pay requires qualifying exposure to hostile action or a closely related incident; imminent-danger pay depends on service in a designated location. A member cannot receive both payments for the same month, so the headline rates are not cumulative.
- Defense officials described the change as the first increase in these pays since 2002 and said it better recognizes operational risk. The implementing memorandum also reduced hardship-duty pay for location from $150 to $100 monthly to stay within statutory combined-payment limits.
- The rate changes establish new entitlements for qualifying service, not the number of recipients or total budget cost. No service-wide outlay, retention effect, casualty effect or readiness outcome was measured by the cutoff.

## SIGNIFICANCE

The implemented increase changes compensation for service members exposed to hostile fire or assigned to designated danger areas during a period of expanded Middle East operations.

## GOALPOST / RESPONSE

Defense officials say the higher rates better reflect combat risk and allow commanders to recognize escalation promptly. The tests are payroll implementation, eligible member counts, appropriations and outlays, designation changes, audits and measured retention or readiness effects.

## MAYBE / THEREFORE

Maybe the higher payments will improve compensation and retention for members facing elevated risk, or the amounts may remain small relative to the danger and operational burden. Therefore the record establishes effective rate changes—not universal combat pay, combined receipt of both benefits or demonstrated personnel outcomes.


## SOURCES

- [War Department — hostile-fire and imminent-danger pay increases](https://www.war.gov/News/News-Stories/Article/Article/4616621/war-department-increases-two-hazard-pays-for-first-time-in-nearly-quarter-centu/) — primary agency announcement of effective military pay changes
- [Military Times — first hostile-fire and imminent-danger pay increase since 2002](https://www.militarytimes.com/news/your-military/2026/10/01/troops-get-first-increase-in-24-years-for-hostile-fire-danger-pays/) — independent reporting on effective rates, scope and implementing memorandum

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
