# Four states implement USDA-approved SNAP food-purchase restrictions

**Entry ID:** NAT-2026-11-01-003
**Date:** November 1–3, 2026
**Checked:** 2026-11-03 6:09 AM EST
**Evidence state:** USDA waiver tracker, four primary state implementation sources, November 3 Federal Register issue and independent corroboration; scopes are state-specific and outcomes remain unmeasured
**Review state:** current-standard-reviewed

Montana, North Dakota, South Carolina and Virginia began state-specific limits on using SNAP benefits for selected drinks, candy or desserts; benefit eligibility and amounts did not change, and health and access effects remain unmeasured.

## THE FACTS

- USDA's SNAP Food Restriction Waivers tracker and official state pages show that Montana, North Dakota, South Carolina and Virginia implemented approved demonstration projects on November 1. The Federal Register's November 3 issue published state-specific notices; the later publication date does not change the local November 1 implementation date.
- The categories differ by state. Montana excludes candy, high-sugar beverages, energy drinks and shelf-stable prepared desserts; North Dakota and South Carolina exclude specified sweetened or soft drinks, energy drinks and candy; Virginia excludes carbonated sweetened beverages, including diet or artificially sweetened soda. The archive does not collapse those definitions into a single national rule.
- Virginia says SNAP eligibility, monthly benefit amount and schedule are unchanged and excluded beverages may still be bought with non-SNAP funds. The other state materials likewise describe changes to which products an EBT benefit may purchase, not a criminal ban on buying or selling those products.
- USDA and the states frame the waivers as demonstrations intended to encourage healthier purchases and evaluate outcomes. That establishes the program rationale and an evaluation commitment, not measured improvements in diet, obesity, diabetes, spending or household food security.
- Independent reporting corroborated the four-state November 1 start. Retail-industry materials warn that differing product definitions and point-of-sale rules can increase compliance costs and checkout complexity; those concerns are stakeholder positions, not measured statewide harm.
- A federal court previously vacated different state waiver approvals, but the reviewed federal tracker continued to list these four November 1 projects as operative. No injunction against these four implementations was located by cutoff, and the archive does not infer that the earlier ruling resolved their legality.

## SIGNIFICANCE

The demonstrations materially narrow federal food-benefit purchasing eligibility across four statewide systems and require retailer point-of-sale implementation. They also create a concrete test of the administration's nutrition-policy theory, but the effects on diet, access, substitution, retailer errors and household food security are not yet measured.

## GOALPOST / RESPONSE

USDA and participating states say the restrictions will encourage healthier choices and generate evidence through demonstration evaluations. Critics and retailers cite participant choice, inconsistent definitions, stigma and implementation burden. The tests are error and complaint rates, retailer compliance, out-of-state or cash substitution, nutritional and health measures, food-security outcomes, costs and court review—not the waiver approvals alone.

## MAYBE / THEREFORE

Maybe the restrictions reduce purchases of targeted products and improve diets, or households may substitute unrestricted products, cash purchases or stores while facing confusion and stigma. Therefore four state-specific demonstrations are implemented—not a nationwide SNAP rule, a reduction in benefit amount, proof of improved health, or proof of participant harm.


## SOURCES

- [USDA FNA — SNAP Food Restriction Waivers tracker](https://www.fna.usda.gov/snap/waivers/foodrestriction) — primary federal waiver tracker with state scopes and target implementation dates
- [Montana DPHHS — Healthy SNAP food restriction waiver takes effect](https://dphhs.mt.gov/News/2026/October/Healthy-SNAP-Nov-1) — primary state implementation notice and restricted-category definitions
- [North Dakota HHS — SNAP Healthy Choice waiver implementation](https://www.hhs.nd.gov/news/commitment-healthier-food-choices-north-dakota-snap-participants-begins-next-week) — primary state implementation notice and waiver information
- [South Carolina DSS — SNAP food eligibility update](https://benefitsportal.dss.sc.gov/) — primary state benefits-portal implementation notice
- [Virginia DSS — SNAP Healthy beverage update](https://www.dss.virginia.gov/relief/food-assistance/snap/snap-healthy/) — primary state implementation page, scope and participant guidance
- [Federal Register — November 3 SNAP demonstration notices](https://www.federalregister.gov/documents/2026/11/03) — official daily issue listing Montana, North Dakota, South Carolina and Virginia demonstration notices
- [FOX 13 — four states begin SNAP purchase restrictions November 1](https://www.fox13news.com/news/snap-junk-food-purchase-ban-november-2026) — independent report corroborating the four-state implementation date and differing scopes
- [NACS — SNAP restriction waiver implementation tracker](https://www.convenience.org/advocate-for-the-industry/issues/snap/snap-restriction-waivers) — industry tracker documenting retailer-compliance concerns and state-by-state scopes

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
