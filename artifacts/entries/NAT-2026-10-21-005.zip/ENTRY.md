# Fifth Circuit holds federal interstate switchblade ban unconstitutional

**Entry ID:** NAT-2026-10-21-005
**Date:** October 21, 2026
**Checked:** 2026-10-22 11:58 AM EDT
**Evidence state:** published Fifth Circuit opinion plus Reuters reporting; Section 1242 claim reversed and remanded, separate Section 1243 facial challenge dismissal affirmed, further review and remand relief unresolved
**Review state:** current-standard-reviewed

A three-judge panel applied the Supreme Court's history-and-tradition test, reversed dismissal of the interstate-ban challenge and remanded while affirming dismissal of a separate territorial-jurisdiction claim.

## THE FACTS

- In Knife Rights, Inc. v. Blanche, the Fifth Circuit held on October 21 that 15 U.S.C. § 1242's restrictions on introducing, manufacturing for introduction, transporting or distributing switchblade knives in interstate commerce violate the Second Amendment. The panel treated switchblades as protected arms and concluded that the government had not shown a relevant historical analogue.
- The panel reversed dismissal of the Section 1242 claim and remanded for further proceedings. The decision is an appellate-panel ruling, not a Supreme Court judgment or a completed district-court remedy, and later rehearing, appeal or remand proceedings remain possible.
- The court separately affirmed dismissal of the facial challenge to 15 U.S.C. § 1243, which concerns specified federal territories, possessions, Indian country and special maritime or territorial jurisdiction. The ruling therefore did not invalidate every federal switchblade restriction or address separate state and local knife laws.
- The Justice Department argued that switchblades fit a historical tradition of regulating dangerous and unusual weapons and had told the court it would continue enforcing the statute. Reuters reported no immediate post-ruling department comment; the litigation position is the government's explanation, not a later enforcement directive.
- Knife Rights described the decision as recognition that knives are protected arms. That is the prevailing party's characterization; the operative evidence is the court's limited disposition and remand.

## SIGNIFICANCE

The panel extends modern Second Amendment history-and-tradition analysis to a federal knife restriction and limits federal interstate-commerce enforcement in the Fifth Circuit. Its reach remains bounded by the surviving Section 1243 dismissal, remand posture, possible further review and laws outside the challenged federal provision.

## GOALPOST / RESPONSE

The Justice Department defended the statute as a traditional regulation of dangerous and unusual weapons. The tests are any petition for rehearing or Supreme Court review, the mandate, district-court relief on remand, revised federal enforcement guidance and treatment of Section 1243 and state laws—not advocacy descriptions of a complete nationwide invalidation.

## MAYBE / THEREFORE

Maybe the panel faithfully applies the Supreme Court's Second Amendment framework to commonly possessed knives, or a higher court may accept a broader historical analogue or narrow the remedy. Therefore the archive records a panel holding, partial reversal and remand—not final nationwide elimination of every switchblade restriction or a completed end to federal enforcement.


## SOURCES

- [U.S. Court of Appeals for the Fifth Circuit — Knife Rights v. Blanche opinion](https://fingfx.thomsonreuters.com/gfx/legaldocs/xmpjwyezgvr/switchblades.pdf) — published appellate opinion reversing dismissal of the interstate-switchblade claim, affirming dismissal of a separate facial challenge and remanding
- [Reuters — Fifth Circuit rules federal interstate switchblade ban unconstitutional](https://www.reuters.com/legal/government/us-ban-switchblades-is-unconstitutional-appeals-court-rules-2026-10-22/) — independent legal reporting on the panel ruling, Justice Department position and limited disposition

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
