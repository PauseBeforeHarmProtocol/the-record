# D.C. Circuit affirms bar on unilateral firing of Voice of America director

**Entry ID:** NAT-2026-11-10-005
**Date:** November 10, 2026
**Checked:** 2026-11-10 6:12 PM EST
**Evidence state:** primary published D.C. Circuit opinion plus Washington Post reporting; permanent injunction affirmed, with possible further review and broader VOA consequences unresolved
**Review state:** current-standard-reviewed

The unanimous panel upheld a permanent injunction requiring approval from the International Broadcasting Advisory Board before Michael Abramowitz can be removed.

## THE FACTS

- On November 10, a unanimous D.C. Circuit panel affirmed the August 2025 permanent injunction barring U.S. Agency for Global Media officials from removing Voice of America Director Michael Abramowitz without approval from a majority of the International Broadcasting Advisory Board.
- The opinion says agency leaders tried to reassign Abramowitz to a lower-level North Carolina post and then remove him after he refused. The panel held that 22 U.S.C. § 6205(e) gives the board final authority over appointment and removal of network heads and that the attempted unilateral termination violated that statute.
- The court rejected the administration's arguments that the claim belonged before the Merit Systems Protection Board, that the board-approval requirement violated Article II and that equitable relief was unavailable. It held that the statute remains constitutional because the president can remove board members and thus retains indirect supervisory authority.
- The administration argued that requiring collective board approval diffuses presidential removal power and that the district court could not enjoin the removal. The ruling leaves the injunction in force; it does not prevent removal through the statutory board process or resolve every dispute over VOA staffing, funding and programming.

## SIGNIFICANCE

The decision preserves a congressionally created institutional firewall for leadership of the government's international broadcaster and rejects a direct executive-removal theory. It is a binding appellate ruling unless changed through rehearing or Supreme Court review.

## GOALPOST / RESPONSE

The administration says Article II requires stronger presidential control and disputes the district court's remedial power. Abramowitz and the court frame board approval as a lawful safeguard for editorial independence. The tests are rehearing or certiorari, compliance, board staffing and votes, Abramowitz's actual authority, newsroom operations and future congressional action.

## MAYBE / THEREFORE

Maybe the ruling stabilizes VOA's statutory independence while preserving lawful presidential supervision through the board, or further review may alter the constitutional balance. Therefore the record establishes an affirmed permanent injunction and an unlawful attempted removal—not lifetime tenure, immunity from board-approved removal or proof that all broader USAGM changes are unlawful.


## SOURCES

- [D.C. Circuit — Abramowitz v. Lake, No. 25-5314](https://media.cadc.uscourts.gov/opinions/docs/2026/11/25-5314.pdf) — primary published appellate opinion
- [Washington Post — D.C. Circuit affirms ruling that VOA director's removal was unlawful](https://www.washingtonpost.com/business/2026/11/10/appeals-court-says-voa-director-was-fired-illegally-by-former-head-kari-lake/) — independent court reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
