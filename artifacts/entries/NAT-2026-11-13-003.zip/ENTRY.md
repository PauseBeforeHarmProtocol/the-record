# FAA disables about 60 similar routers as third-day disruptions top 5,200

**Entry ID:** NAT-2026-11-13-003
**Date:** November 13–15, 2026
**Checked:** 2026-11-15 6:03 PM EST
**Evidence state:** Official Transportation Department Sunday update plus Reuters and Associated Press reporting on measured third-day disruption, implemented router isolation, revised recovery forecast, equipment age and continuing diagnostics; the Reuters report was published nine minutes before the prior exact boundary and recovered in this review, while final root cause, full recovery, liability and enacted additional funding remain unresolved
**Review state:** current-standard-reviewed

More than 1,600 Sunday cancellations and nearly 3,600 delays followed the nationwide outage; the FAA disabled the two originating routers and about 60 similar units while moving its normalization forecast to Monday, with root cause still unresolved.

## THE FACTS

- At 3:54 p.m. EST on November 13, the Federal Aviation Administration imposed a nationwide ground stop on departing flights after a communications issue affected all Air Route Traffic Control Centers. Officials lifted the stop at 8:15 p.m. EST after almost five hours; aircraft already airborne were permitted to land and international departures were handled case by case.
- On Sunday, Transportation Secretary Sean Duffy said an El Dorado router had been activated during contractor maintenance and an Amarillo router then broadcast repeated connection attempts across the network. The FAA disabled functionality on those two routers and about 60 similar routers as an implemented precaution. Officials had not determined why the routers interacted or whether equipment, installation or another factor caused the failure.
- Reuters reported that more than 5,200 U.S. flights had been affected Sunday, including more than 1,600 cancellations and almost 3,600 delays. Those systemwide figures measure a third day of disruption but do not prove that every listed flight had one cause.
- Duffy moved the forecast for full-capacity operations to Monday, superseding the earlier late-Sunday forecast. Associated Press and Reuters reported continued airline disruption while officials said the air-traffic system was stable; the forecast is not proof that full normalization occurred.
- Officials said the two originating routers were purchased in 2001 and considered obsolete by 2006, remained under laboratory diagnostics, and showed no indication of a cyberattack. Duffy said the previously enacted $12.5 billion was fully accounted for and continued to seek $50 billion for modernization; the additional amount remains a proposal, not an appropriation.

## SIGNIFICANCE

The Sunday outcome shows that recovery took longer than forecast, while disabling about 60 similar routers is a material implemented risk-control step rather than rhetoric. It also exposes the operational consequences of obsolete equipment, but neither the mitigation nor the revised forecast establishes final cause, complete recovery or durable prevention.

## GOALPOST / RESPONSE

The administration's strongest explanation is that the safety stop prevented a communications loss, the network is stable, implicated and similar routers were isolated, and deep diagnostics are underway while officials seek modernization money. The tests are verified Monday normalization, a final root-cause and after-action report, change-control records, contractor findings and accountability, itemized appropriations, durable replacement or recurrence controls and measured reliability—not the forecast or preliminary sequence alone.

## MAYBE / THEREFORE

Maybe isolating the router class will contain a discrete legacy-equipment interaction, or it may reveal a wider architecture and change-control vulnerability that requires replacement rather than temporary disabling. Therefore this refresh establishes an implemented precaution across about 60 routers, more than 5,200 Sunday disruptions and a shifted Monday recovery forecast—not final causation, complete recovery, contractor liability, enacted new funding or protection against recurrence.


## SOURCES

- [Reuters — FAA grounds all departing flights after air-traffic communications failure](https://www.reuters.com/world/us/faa-issues-national-ground-stop-due-extraordinary-circumstance-reasons-safety-2026-11-13/) — independent reporting on the implemented stop, timing, operational scope, disruption and unresolved cause
- [Associated Press — FAA lifts nationwide ground stop after five-hour communications failure](https://apnews.com/article/f81b0904331dafad6133f291e5f531a8) — independent reporting on the lifting, reported technical explanation, diversions, recovery limits and continuing investigation
- [U.S. Department of Transportation — Secretaries Duffy and Mullin announce lifting of the nationwide ground stop](https://www.transportation.gov/briefing-room/icymi-us-transportation-secretary-sean-duffy-announces-lifting-nationwide-ground) — official account and quoted briefing on the outage timeline, preliminary equipment explanation, lifting time and modernization request
- [Reuters — Thousands of U.S. flights canceled and delayed as air-travel system recovers](https://www.reuters.com/business/aerospace-defense/thousands-us-flights-canceled-delayed-air-travel-system-recovers-shutdown-2026-11-14/) — independent reporting on the contractor-focused investigation, measured disruption, recovery and funding proposal
- [Associated Press — U.S. air travel recovery and contractor investigation](https://apnews.com/article/ground-stop-flights-airlines-cancellations-faa-1fbf4992f0ddaa4c463b0e4990b6e291) — independent reporting on measured disruption, recovery forecast and change-control questions
- [Reuters — U.S. air-travel disruptions continue into a third day](https://www.reuters.com/world/us/us-air-travel-disruptions-continue-into-third-day-2026-11-15/) — independent reporting on Sunday cancellations and delays, implemented router isolation, revised recovery forecast and unresolved root cause
- [U.S. Department of Transportation — Sunday update on the nationwide FAA communications failure](https://www.transportation.gov/briefing-room/icymi-trumps-transportation-secretary-sean-duffy-provides-update-across-sunday) — primary official update on the two-router interaction, implemented isolation of similar routers, diagnostics, funding and unresolved root cause
- [Associated Press — FAA isolates routers while U.S. air travel recovers](https://apnews.com/article/trump-ground-stop-air-travel-faa-duffy-1a308c557552b2ce24a0532fee0be191) — independent reporting on implemented router mitigation, Monday recovery forecast, obsolete equipment and continuing diagnostics

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
