# FAA recovery enters second day as contractor equipment change becomes investigation focus

**Entry ID:** NAT-2026-11-13-003
**Date:** November 13–14, 2026
**Checked:** 2026-11-14 12:05 PM EST
**Evidence state:** Official Transportation Department timeline and preliminary technical account, plus Associated Press and Reuters reporting on the implemented stop, lifting, contractor-focused investigation, measured disruption and proposed funding; final root cause, contractor liability, full recovery and enacted funding remain unresolved
**Review state:** current-standard-reviewed

More than 7,000 Saturday cancellations and delays followed the nationwide ground stop while officials investigated whether installer error or a faulty router during a contractor copper-to-fiber conversion caused the failure; no final root cause was established.

## THE FACTS

- At 3:54 p.m. EST on November 13, the Federal Aviation Administration imposed a nationwide ground stop on departing flights after a communications issue affected all Air Route Traffic Control Centers. The action applied to departures from all U.S. airports; aircraft already airborne were permitted to land and international departures were handled case by case.
- Officials lifted the stop at 8:15 p.m. EST after almost five hours. Reuters reported nearly 10,000 cancellations and more than 7,000 delays on Friday; limited departures resumed, but the lifting did not establish full airline recovery.
- On Saturday, Transportation Secretary Sean Duffy said the failure occurred during L3Harris remote work to convert copper connections to fiber, with more than 1,000 connection attempts every four to five seconds overloading other centers. He said investigators had not determined whether installer error or a faulty router was responsible. The Transportation Department said older routers and switches overloaded while newer internet-protocol equipment did not; officials said the SMART scheduling system was not involved, had not attributed the event to a cyberattack, and were investigating with the National Security Agency and Department of Homeland Security.
- Reuters reported more than 4,000 cancellations and 3,000 delays by Saturday afternoon, tens of thousands of stranded passengers, cancellation rates near 20% at several major carriers and about 40% at JetBlue. Those measured disruptions show recovery was continuing; they do not establish a final total or that every cancellation had a single cause.
- Duffy increased the administration's requested air-traffic-control modernization funding to $50 billion, from $30 billion, while the Transportation Department described $12.5 billion already provided as a partial down payment. That is a proposal, not an appropriation. Officials said the immediate fault was fixed and flying was safe, but a final after-action review, permanent recurrence controls and full recovery remained unresolved.

## SIGNIFICANCE

The follow-up converts the initial five-hour stop into a measured two-day national disruption and narrows the preliminary investigation to a contractor-led technology migration, while preserving that neither error nor equipment failure has been finally assigned. The increased $50 billion modernization request raises the fiscal stakes but is not enacted funding.

## GOALPOST / RESPONSE

The administration's strongest explanation is that officials used a safety stop, restored service, isolated the immediate fault and are investigating an L3Harris copper-to-fiber conversion while seeking $50 billion for modernization. The tests are a final root-cause and after-action report, change-control records, the contractor's response and any accountability, itemized and appropriated funding, durable recurrence controls, and measured full recovery—not the preliminary explanation or funding request alone.

## MAYBE / THEREFORE

Maybe this was an isolated migration fault contained by a prudent safety stop, or it may expose a change-control vulnerability in a fragile national system. Therefore the record establishes the contractor-focused preliminary investigation, measured second-day disruption and a larger funding proposal—not final causation, contractor liability, enacted funding, complete recovery or protection against recurrence.


## SOURCES

- [Reuters — FAA grounds all departing flights after air-traffic communications failure](https://www.reuters.com/world/us/faa-issues-national-ground-stop-due-extraordinary-circumstance-reasons-safety-2026-11-13/) — independent reporting on the implemented stop, timing, operational scope, disruption and unresolved cause
- [Associated Press — FAA lifts nationwide ground stop after five-hour communications failure](https://apnews.com/article/f81b0904331dafad6133f291e5f531a8) — independent reporting on the lifting, reported technical explanation, diversions, recovery limits and continuing investigation
- [U.S. Department of Transportation — Secretaries Duffy and Mullin announce lifting of the nationwide ground stop](https://www.transportation.gov/briefing-room/icymi-us-transportation-secretary-sean-duffy-announces-lifting-nationwide-ground) — official account and quoted briefing on the outage timeline, preliminary equipment explanation, lifting time and modernization request
- [Reuters — Thousands of U.S. flights canceled and delayed as air-travel system recovers](https://www.reuters.com/business/aerospace-defense/thousands-us-flights-canceled-delayed-air-travel-system-recovers-shutdown-2026-11-14/) — independent reporting on the contractor-focused investigation, measured disruption, recovery and funding proposal

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
