# FAA projects late-Sunday normalization after more than 14,000 Saturday disruptions

**Entry ID:** NAT-2026-11-13-003
**Date:** November 13–15, 2026
**Checked:** 2026-11-15 12:09 AM EST
**Evidence state:** official Transportation Department timeline and preliminary technical account, plus updated Reuters and Associated Press reporting on measured disruption, recovery forecast, contractor response and change-control questions; final root cause, liability, full recovery and enacted funding remain unresolved
**Review state:** current-standard-reviewed

By late Saturday, more than 6,400 U.S. flights had been canceled and 8,000 delayed, with 875 Sunday cancellations already posted; the FAA projected broad normalization by late Sunday but had not completed the root-cause investigation.

## THE FACTS

- At 3:54 p.m. EST on November 13, the Federal Aviation Administration imposed a nationwide ground stop on departing flights after a communications issue affected all Air Route Traffic Control Centers. Officials lifted the stop at 8:15 p.m. EST after almost five hours; aircraft already airborne were permitted to land and international departures were handled case by case.
- Transportation Secretary Sean Duffy said the failure arose during L3Harris remote work converting copper connections to fiber, when more than 1,000 connection attempts every four to five seconds overloaded other centers. Officials said 17 of 22 en route centers were affected, no facility went fully dark and additional testing was underway; investigators had not determined whether installer error or a faulty router was responsible.
- As of 9:35 p.m. EST Saturday, Reuters reported more than 6,400 U.S. flight cancellations and 8,000 delays, following roughly 9,200 cancellations and 7,500 delays Friday. FlightAware also listed 875 Sunday cancellations. Those measured systemwide figures document continuing recovery but do not prove that every disruption had one cause.
- FAA Administrator Bryan Bedford said he expected operations to be largely normal by late Sunday, apologized and said the system remained stable. Associated Press separately reported more than 6,000 Saturday cancellations and the same end-of-Sunday recovery forecast. The forecast is not proof that normalization occurred; Sunday outcomes remained outside the evidence window.
- The technicians' union said its normal advance risk consultation did not occur for this upgrade, while L3Harris said it was supporting the investigation and took the disruption seriously. Duffy increased the administration's requested modernization funding to $50 billion, with $12.5 billion previously enacted; the larger amount is a proposal, not an appropriation, and the final change-control findings remain unresolved.

## SIGNIFICANCE

The measured Saturday totals establish a substantially larger second-day national disruption than the afternoon snapshot, while the late-Sunday forecast supplies a concrete recovery test. The account also identifies a possible change-control gap, but neither installer fault nor router defect has been finally established and the $50 billion request remains proposed.

## GOALPOST / RESPONSE

The administration's strongest explanation is that the safety stop prevented a loss of communications, the system is stable, operations should largely normalize by late Sunday and additional testing is underway while officials seek modernization money. The tests are actual Sunday recovery, a final root-cause and after-action report, change-control records, the contractor's response and any accountability, itemized appropriations, durable recurrence controls and measured reliability—not the forecast or preliminary attribution alone.

## MAYBE / THEREFORE

Maybe the remaining cancellations are the finite network effects of a contained migration fault, or they may show how one change-control failure can cascade across a fragile national system. Therefore this refresh establishes more than 14,000 Saturday cancellations and delays, 875 early Sunday cancellations and an official normalization forecast—not completed recovery, final causation, contractor liability, enacted funding or protection against recurrence.


## SOURCES

- [Reuters — FAA grounds all departing flights after air-traffic communications failure](https://www.reuters.com/world/us/faa-issues-national-ground-stop-due-extraordinary-circumstance-reasons-safety-2026-11-13/) — independent reporting on the implemented stop, timing, operational scope, disruption and unresolved cause
- [Associated Press — FAA lifts nationwide ground stop after five-hour communications failure](https://apnews.com/article/f81b0904331dafad6133f291e5f531a8) — independent reporting on the lifting, reported technical explanation, diversions, recovery limits and continuing investigation
- [U.S. Department of Transportation — Secretaries Duffy and Mullin announce lifting of the nationwide ground stop](https://www.transportation.gov/briefing-room/icymi-us-transportation-secretary-sean-duffy-announces-lifting-nationwide-ground) — official account and quoted briefing on the outage timeline, preliminary equipment explanation, lifting time and modernization request
- [Reuters — Thousands of U.S. flights canceled and delayed as air-travel system recovers](https://www.reuters.com/business/aerospace-defense/thousands-us-flights-canceled-delayed-air-travel-system-recovers-shutdown-2026-11-14/) — independent reporting on the contractor-focused investigation, measured disruption, recovery and funding proposal
- [Associated Press — U.S. air travel recovery and contractor investigation](https://apnews.com/article/ground-stop-flights-airlines-cancellations-faa-1fbf4992f0ddaa4c463b0e4990b6e291) — independent reporting on measured disruption, recovery forecast and change-control questions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
