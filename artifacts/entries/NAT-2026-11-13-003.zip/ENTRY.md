# FAA imposes nationwide departure stop after air-traffic communications failure

**Entry ID:** NAT-2026-11-13-003
**Date:** November 13, 2026
**Checked:** 2026-11-13 6:03 PM EST
**Evidence state:** Reuters and Associated Press reporting quoting the FAA notice and administration officials; nationwide stop implemented, cause and recovery unresolved at cutoff
**Review state:** current-standard-reviewed

The agency halted departures at every U.S. airport for safety after communications failed across regional control centers; airborne flights could land and the cause remained under investigation at cutoff.

## THE FACTS

- At 3:54 p.m. EST, the Federal Aviation Administration imposed a nationwide ground stop on departing flights after a communications issue affected all Air Route Traffic Control Centers. The action applied to departures from all U.S. airports; aircraft already airborne were permitted to land and international departures were handled case by case.
- The FAA and Transportation Secretary Sean Duffy described the stop as a safety measure and said technicians were investigating. The inspected Reuters report said no lifting time had been given, while the AP reported that the order was in effect through at least 11 p.m. EST.
- Reuters reported that nearly 7,000 flights had been delayed or canceled according to FlightAware. That contemporaneous systemwide count does not establish that every listed disruption was caused solely by the communications failure.
- The cause remained unknown at cutoff. Homeland Security Secretary Markwayne Mullin said there was no indication at that time of a malicious attack; the inspected evidence did not establish a cyberattack or a connection to the prior Microsoft outage or National Weather Service communications problems.
- The action was a temporary national operational restriction, not an airport closure or a permanent suspension of air travel. Its duration, technical cause, recovery sequence and downstream safety effects remained unresolved at the evidence cutoff.

## SIGNIFICANCE

A nationwide stop of departures is an exceptional federal safety action with immediate national travel and economic consequences. It also supplies a concrete operational test for the resilience of air-traffic communications, but the stop itself does not identify the cause or prove a hostile attack.

## GOALPOST / RESPONSE

The administration can substantiate its response with the incident timeline, affected systems and facilities, root-cause analysis, restoration milestones, safety-risk assessment and a public after-action report. Recovery should be measured by the formal lifting time, restored communications, residual delays and any verified corrective action—not by assurances alone.

## MAYBE / THEREFORE

Maybe the stop was a prudent short-lived response to a recoverable technical failure, or it may reveal a wider vulnerability in national air-traffic communications. Therefore the record establishes an implemented nationwide departure stop and a large contemporaneous disruption—not the outage's cause, a cyberattack, an airport closure or completion of recovery.


## SOURCES

- [Reuters — FAA grounds all departing flights after air-traffic communications failure](https://www.reuters.com/world/us/faa-issues-national-ground-stop-due-extraordinary-circumstance-reasons-safety-2026-11-13/) — independent reporting on the implemented stop, timing, operational scope, disruption and unresolved cause
- [Associated Press — FAA grounds all departures nationwide after communications outage](https://apnews.com/article/6aaa6bd4991ef22eb0c3baa6961a91d1) — independent reporting quoting the FAA notice and administration response while preserving the unresolved cause

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
