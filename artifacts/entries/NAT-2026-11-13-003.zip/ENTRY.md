# FAA lifts nationwide departure stop after five-hour communications failure

**Entry ID:** NAT-2026-11-13-003
**Date:** November 13, 2026
**Checked:** 2026-11-14 12:08 AM EST
**Evidence state:** Initial Reuters reporting and updated Associated Press reporting on the implemented stop, lifting, official preliminary explanation, diversion count and continuing investigation; restriction ended, full recovery and final root cause not established
**Review state:** current-standard-reviewed

Limited departures resumed after the longest nationwide ground stop in 25 years; officials attributed the failure to new equipment overwhelming legacy systems while the technical investigation and airline recovery continued.

## THE FACTS

- At 3:54 p.m. EST, the Federal Aviation Administration imposed a nationwide ground stop on departing flights after a communications issue affected all Air Route Traffic Control Centers. The action applied to departures from all U.S. airports; aircraft already airborne were permitted to land and international departures were handled case by case.
- The stop was lifted Friday evening after about five hours, and a limited number of domestic departures resumed. The Associated Press described it as the longest nationwide ground stop in 25 years and reported that full airline recovery was expected to take days because aircraft and crews were out of position.
- Administration officials said new equipment being added to the air-traffic system overwhelmed older legacy equipment and caused intermittent communications and radar gaps. Homeland Security Secretary Markwayne Mullin described the problem as mechanically driven and said no cyberattack footprints had been found, while also saying officials were still investigating the cause; that explanation is not a final root-cause finding.
- Mullin said more than 3,000 flights landed safely during the stoppage. Aviation analytics company Cirium counted at least 827 diverted flights by 7:05 p.m. EST—670 returned to their origin airports and 157 redirected elsewhere—while the AP reported thousands of flights and potentially more than one million travelers affected.
- Transportation Secretary Sean Duffy said he could not guarantee that another outage would not occur and warned that more disruptions could happen. The implemented lifting ended the national departure restriction, but did not establish full network recovery, a completed after-action review or a verified permanent correction.

## SIGNIFICANCE

The lifting ended an exceptional national safety restriction but left a major recovery and resilience problem: a modernization deployment was reported to have overloaded older equipment, and officials could not rule out recurrence. The record distinguishes the restored ability to depart from full operational normalization or a completed technical diagnosis.

## GOALPOST / RESPONSE

The administration can substantiate its response with the incident timeline, affected systems and facilities, root-cause analysis, change-management records, restoration milestones, safety-risk assessment and a public after-action report. Effectiveness should be measured by durable communications availability, residual delays and diversions, verified corrective action and recurrence—not by the lifting announcement alone.

## MAYBE / THEREFORE

Maybe the five-hour stop was a prudent containment measure followed by successful restoration, or it may expose a recurring risk created by connecting new technology to fragile legacy systems. Therefore the record establishes an implemented nationwide departure stop, its lifting and a reported preliminary equipment-overload explanation—not a final root cause, proof of full recovery or assurance against recurrence.


## SOURCES

- [Reuters — FAA grounds all departing flights after air-traffic communications failure](https://www.reuters.com/world/us/faa-issues-national-ground-stop-due-extraordinary-circumstance-reasons-safety-2026-11-13/) — independent reporting on the implemented stop, timing, operational scope, disruption and unresolved cause
- [Associated Press — FAA lifts nationwide ground stop after five-hour communications failure](https://apnews.com/article/f81b0904331dafad6133f291e5f531a8) — independent reporting on the lifting, reported technical explanation, diversions, recovery limits and continuing investigation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
