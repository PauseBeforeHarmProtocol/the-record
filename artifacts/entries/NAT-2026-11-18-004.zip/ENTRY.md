# Seventh Circuit revives federal challenge to Illinois nonprofit demographic-disclosure law

**Entry ID:** NAT-2026-11-18-004
**Date:** November 18, 2026
**Checked:** 2026-11-19 12:07 AM EST
**Evidence state:** published Seventh Circuit opinion plus independent Reuters reporting and the Justice Department's reported response; standing resolved, constitutional merits and injunctive relief unresolved
**Review state:** current-standard-reviewed

The panel restored the federal and private challenges on standing grounds, vacated the injunction denials and returned the case to district court without deciding whether Illinois's law is constitutional or enjoining it.

## THE FACTS

- In consolidated appeals Nos. 25-2461 and 25-2487, the Seventh Circuit reversed the district court's dismissal of the United States' and American Alliance for Equal Rights' complaints, vacated the denials of their preliminary-injunction motions and remanded for further proceedings. The November 18 opinion held that both plaintiffs had Article III standing.
- Illinois Senate Bill 2930 requires covered charitable organizations that report at least $1 million in grants to other charities to collect and post aggregated demographic information about directors and officers. The statute covers categories including race, ethnicity, gender, disability status, veteran status, sexual orientation and gender identity, while allowing individuals to decline disclosure.
- The United States intervened under 42 U.S.C. § 2000h-2 with a Fourteenth Amendment claim. The panel held that the federal government has standing to enforce citizens' Equal Protection rights when Congress has supplied clear statutory authority, and separately held that the Alliance's pseudonymous members alleged a sufficiently likely disclosure-related injury.
- The panel expressly declined to decide the constitutional merits, including the proper scrutiny for the First and Fourteenth Amendment claims. It did not enjoin Illinois's law; the district court must reconsider the merits and preliminary-injunction requests on remand. Reuters reported that the Justice Department welcomed the standing ruling, while Illinois's attorney general did not respond to its request for comment.

## SIGNIFICANCE

The precedential ruling restores a Trump administration civil-rights intervention and confirms a route for federal Equal Protection enforcement against a state law even without a conventional private injury. It advances the administration's anti-DEI litigation strategy, but only through the standing threshold; no constitutional violation or operational remedy has yet been adjudicated.

## GOALPOST / RESPONSE

The Justice Department says the ruling confirms federal standing to enforce Equal Protection rights where Congress supplied authority. Illinois has not supplied a response in the inspected independent report. The tests are the district court's renewed injunction analysis, merits rulings on compelled speech and equal protection, any enforcement change, subsequent appeal and concrete compliance effects for covered nonprofits.

## MAYBE / THEREFORE

Maybe the remand will produce an injunction or merits ruling against Illinois's disclosure law, or the state may prevail once the constitutional claims are analyzed. Therefore the evidence establishes standing and revival of the federal challenge—not that the law was held unconstitutional, enjoined or repealed.


## SOURCES

- [American Alliance for Equal Rights and United States v. State of Illinois, Nos. 25-2461 & 25-2487](https://media.ca7.uscourts.gov/cgi-bin/OpinionsWeb/processWebInputExternal.pl?Path=Y2026%2FD11-18%2FC%3A25-2487%3AJ%3AKirsch%3Aaut%3AT%3AfnOp%3AN%3A3644210%3AS%3A0&Submit=Display) — primary precedential appellate opinion reversing standing dismissals, vacating preliminary-injunction denials and remanding without reaching the merits
- [US appeals court revives Trump challenge to Illinois nonprofit diversity law](https://www.reuters.com/legal/government/us-appeals-court-revives-trump-challenge-illinois-nonprofit-diversity-law-2026-11-18/) — independent reporting on the Seventh Circuit ruling, Justice Department response and unresolved district-court proceedings

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
