# USTR extends China maritime-action suspension and 178 tariff exclusions

**Entry ID:** NAT-2026-11-10-012
**Date:** November 9–10, 2026
**Checked:** 2026-11-11 12:02 PM EST
**Evidence state:** Two primary USTR final notices plus independent trade-compliance context; implemented temporary extensions, with customs instructions, negotiations and post-January status unresolved
**Review state:** current-standard-reviewed

Two final notices preserve temporary relief while U.S.-China discussions continue, without ending either Section 301 investigation.

## THE FACTS

- USTR published two final notices on November 10, before the prior archive boundary; this release records a retrospective discovery. The maritime modification took effect November 9 and further suspends the action through 11:59 p.m. EST January 9, 2027.
- During the maritime suspension, parties do not accrue liability for specified fees on Chinese-linked maritime transport services or duties on ship-to-shore cranes and other cargo-handling equipment. The underlying Section 301 findings and potential actions remain in place.
- A separate notice extends all 178 current exclusions from additional Section 301 duties on identified Chinese products through 11:59 p.m. EST January 9, 2027. It adds no new exclusions and does not repeal the broader tariffs.
- USTR says continued discussions with China justify the temporary suspensions. The International Compliance Professionals Association confirmed the two deadline changes and noted that customs entry instructions for the exclusion extension were not yet issued when checked. Negotiation results, later reinstatement and trade effects remain unresolved.

## SIGNIFICANCE

The notices avoid near-term fees and duties for affected shipping services, equipment and product lines while keeping the administration’s Section 301 leverage available. Import costs and negotiating leverage may change again when the temporary period ends.

## GOALPOST / RESPONSE

The administration says the pauses create space for negotiations while preserving the underlying enforcement tools. The tests are customs implementation, covered entries and voyages, any agreement, compliance findings, extension or reinstatement after January 9, prices, shipping patterns and domestic investment.

## MAYBE / THEREFORE

Maybe temporary relief supports negotiations and avoids near-term supply-chain costs without surrendering leverage, or repeated extensions may delay the shipbuilding and technology-transfer remedies the investigations were meant to advance. Therefore the record establishes implemented temporary suspensions—not termination of either investigation, permanent tariff relief or a completed trade agreement.


## SOURCES

- [Federal Register — further suspension of China maritime, logistics and shipbuilding Section 301 action](https://www.federalregister.gov/documents/2026/11/10/2026-22867/notice-of-modification-of-section-301-action-chinas-targeting-of-the-maritime-logistics-and-shipbuilding-sectors-for-dominance) — primary implemented trade-action notice
- [Federal Register — extension of 178 China Section 301 product exclusions](https://www.federalregister.gov/documents/2026/11/10/2026-22925/notice-of-product-exclusion-extensions-chinas-acts-policies-and-practices-related-to-technology-transfer-intellectual-property-and-innovation) — primary implemented trade-action notice
- [International Compliance Professionals Association — Section 301 tracker](https://www.icpainc.org/section-301-tracker/) — independent trade-compliance summary of the two final notices and implementation status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
