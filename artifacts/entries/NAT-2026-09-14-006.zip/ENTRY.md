# Abbott agrees to pay $384,999,040 to resolve federal and state infant-formula allegations

**Entry ID:** NAT-2026-09-14-006
**Date:** September 14, 2026
**Checked:** 2026-09-14 6:00 PM EDT
**Evidence state:** primary Justice Department settlement record, independent Reuters and Associated Press reporting, and Abbott's response; payment agreed, liability and product causation not determined
**Review state:** current-standard-reviewed

The civil settlement allocates $348.7 million to the United States and $36.3 million to states; it includes no admission or determination of liability.

## THE FACTS

- Abbott Laboratories agreed to pay $384,999,040 to resolve False Claims Act and related state allegations concerning powdered infant formula and nutritional products made at facilities in Sturgis, Michigan, and Casa Grande, Arizona, between 2018 and 2022.
- The Justice Department said $348,700,868 will go to the United States and $36,298,172 to participating states for Medicaid and WIC claims. Three former Abbott employees who brought the qui tam action will receive $69 million from the federal recovery.
- The government's complaint alleged roof leaks, damaged spray dryers, longer production runs between cleanings, avoidance of certain bacterial testing and failures to disclose some contamination results to FDA inspectors. These are allegations resolved by settlement; DOJ expressly said there has been no determination of liability.
- Abbott said the settlement is not a finding of fault or liability, that the related criminal investigation is closed and that no unopened distributed Abbott formula tested positive for Cronobacter sakazakii. Reuters and Associated Press reported the settlement and the company's response; the record does not infer a proven causal link between distributed formula and any infant illness.
- The settlement resolves the cited civil claims and creates a payment obligation. It does not establish criminal guilt, validate every allegation, independently audit manufacturing conditions after 2022 or substitute for future FDA inspection and product-safety data.

## SIGNIFICANCE

The agreement is a large federal and multistate recovery involving taxpayer-funded infant nutrition and alleged manufacturing-control failures. Its civil resolution supplies monetary accountability while deliberately leaving liability and product-causation questions undecided.

## GOALPOST / RESPONSE

DOJ says the settlement protects families and taxpayer programs; Abbott denies fault and points to negative tests of unopened distributed product. Payment records, settlement compliance, FDA inspections, environmental and product testing, disclosure practices, WIC and Medicaid recoveries, and any future enforcement or safety findings are the tests.

## MAYBE / THEREFORE

Maybe the settlement and prior plant changes reduce manufacturing and disclosure risks, or unresolved process weaknesses may require further oversight. Therefore the record establishes an agreed civil payment and the allegations it resolves—not an admission, a judicial liability finding, criminal guilt or proof that unopened distributed formula caused the reported illnesses.


## SOURCES

- [Justice Department — Abbott agrees to pay $384,999,040 to resolve infant-formula allegations](https://www.justice.gov/opa/pr/abbott-agrees-pay-over-384m-settle-allegations-related-contaminated-infant-formula) — primary civil-settlement announcement with payment allocation, pleaded allegations and explicit no-liability finding
- [Reuters — Abbott to pay $384 million over infant-formula allegations](https://www.reuters.com/legal/litigation/abbott-pay-384-mln-over-contaminated-infant-formula-allegations-us-justice-dept-2026-09-14/) — independent reporting of the civil settlement, no admission and closure of the related criminal investigation
- [Associated Press — Abbott agrees to $385 million infant-formula settlement](https://apnews.com/article/23b355c26f6347a7e07565aba76d0e4f) — independent reporting of the settlement, 2022 chronology and Abbott response
- [Abbott — response to Justice Department infant-formula settlement](https://www.prnewswire.com/news-releases/abbott-reaches-agreement-with-department-of-justice-to-resolve-claims-relating-to-2022-infant-formula-recall-302877834.html) — primary company response denying fault, noting the closed criminal investigation and describing product-test results

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
