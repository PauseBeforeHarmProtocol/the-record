# Labor Department requires states to share unemployment data for federal oversight

**Entry ID:** NAT-2026-09-16-002
**Date:** September 16, 2026
**Checked:** 2026-09-16 6:31 AM EDT
**Evidence state:** primary Labor Department final rule; disclosure mandate finalized for November 16 effectiveness, state-law transition through September 16, 2027, national database deferred and outcomes unmeasured
**Review state:** current-standard-reviewed

The final rule takes effect November 16, with extra time for required state-law changes; it does not create the national claims database discussed in the proposal.

## THE FACTS

- The Labor Department published a final rule on September 16 requiring state unemployment-compensation agencies to disclose confidential program information for specified federal oversight and audit functions. The rule takes effect November 16, 2026; states that must amend their laws have until September 16, 2027 to comply.
- The rule removes the permissive disclosure provision in 20 CFR 603.5(i) and adds mandatory disclosure for federal oversight and audits in 20 CFR 603.6(c), including for the Labor Department, its inspector general and the Government Accountability Office. Other federal officials must identify the intended use, the oversight or audit relationship and their legal authority, and use of disclosed information remains limited to the authorized purpose.
- The Department did not finalize the proposal's possible national unemployment-claims database. It said it would issue a supplemental notice of proposed rulemaking before pursuing that separate system.
- DOL cited earlier estimates of $45.6 billion in potentially fraudulent benefits across six risk areas and $191 billion in potentially improper pandemic unemployment payments as part of its rationale. Those figures are cited prior estimates, not new losses measured by the final rule or proof that mandatory sharing will recover them.
- The Department said it could not quantify states' technology, operational or state-law compliance costs and estimated only $15,780 in nationwide one-time familiarization costs. Commenters raised privacy, security and federalism concerns; DOL responded that statutory confidentiality, purpose limits and existing safeguards continue to govern disclosures.

## SIGNIFICANCE

The rule converts federal access to state unemployment data from an option into a legal requirement for defined oversight uses, potentially improving cross-program fraud review while imposing uncertain implementation costs and privacy responsibilities on states. Deferring the national database keeps the most centralized proposal outside this final action.

## GOALPOST / RESPONSE

DOL says mandatory access will strengthen oversight, audits and fraud detection while existing confidentiality rules constrain use. State-law amendments, system changes, request and disclosure logs, security incidents, audit findings, improper-payment recoveries, quantified state costs and any supplemental database proposal are the tests.

## MAYBE / THEREFORE

Maybe standardized federal access will expose fraud that fragmented state systems miss, or the rule may shift material technology and privacy burdens to states without producing commensurate recoveries. Therefore the record establishes a finalized disclosure mandate with staged compliance—not a national claims database, a measured reduction in fraud or a complete accounting of implementation costs.


## SOURCES

- [Federal Register — Federal-State Unemployment Compensation program data availability final rule](https://www.federalregister.gov/documents/2026/09/16/2026-18978/federal-state-unemployment-compensation-uc-program-data-availability) — primary final rule, effective November 16, 2026

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
