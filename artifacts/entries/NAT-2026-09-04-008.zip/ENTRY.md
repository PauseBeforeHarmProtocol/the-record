# Military services disclose disabling advertising identifiers on issued devices

**Entry ID:** NAT-2026-09-04-008
**Date:** February–September 4, 2026
**Checked:** 2026-09-04 12:00 PM EDT
**Evidence state:** released service-branch responses and named military statements reported by Reuters, with prior congressional disclosure of CENTCOM threat reports; implemented settings changes documented, coverage and effectiveness unresolved
**Review state:** current-standard-reviewed

Released letters and service statements describe staggered security-setting changes after commercial location data was reported as a threat to deployed forces; coverage and effectiveness remain incomplete.

## THE FACTS

- Reuters reported September 4, based on service-branch letters released by Senator Ron Wyden and attributed military statements, that the Air Force disabled advertising identifiers on computers and mobile phones about two months earlier and U.S. Special Operations Command had recently disabled them on Windows devices.
- The Army told Reuters that advertising identifiers had been blocked on Windows computers since before 2021 and disabled by default on Android and Apple mobile devices since at least February 2026. Separate Army and Navy letters said identifiers were disabled on military devices but did not provide complete implementation dates.
- Mobile advertising identifiers can connect app activity and commercially traded location data to devices. CENTCOM had told Congress in April that it received multiple threat reports involving adversary exploitation of commercial location data to target or surveil U.S. personnel during the Iran conflict.
- Wyden and Representative Pat Harrigan requested a Pentagon investigation into whether the changes adequately address the risk. The Pentagon said it would respond directly; the public record did not establish device-by-device coverage, controls for personal phones, enforcement, residual data-broker access or a measured reduction in targeting.

## SIGNIFICANCE

Commercial location data can expose troop patterns without penetrating a classified network. Disabling advertising identifiers is a concrete force-protection step, but the staggered implementation and unresolved personal-device and alternative-tracking risks leave the breadth of protection uncertain.

## GOALPOST / RESPONSE

Military services present the settings changes as part of protecting personnel while lawmakers say the response remains inadequate. Device-compliance audits, personal-device policy, mobile-device-management coverage, data-broker testing, incident and threat reporting, independent security assessment and the Pentagon's response to Congress are the tests.

## MAYBE / THEREFORE

Maybe disabling identifiers substantially removes the easiest commercial tracking vector, or adversaries may continue to locate personnel through personal devices, apps, network data and other identifiers. Therefore the record establishes disclosed settings changes on categories of military-issued devices—not universal implementation, elimination of commercial tracking or proof that prior data caused a specific attack.


## SOURCES

- [Reuters — military services disclose disabling advertising identifiers on devices](https://www.reuters.com/business/media-telecom/us-military-turns-off-ad-trackers-devices-amid-middle-east-targeting-reports-2026-09-04/) — independent reporting based on released service-branch letters and named military statements about implemented device-security settings
- [Senator Ron Wyden — congressional disclosure on commercial location-data threats to servicemembers](https://www.wyden.senate.gov/news/press-releases/foreign-adversaries-are-using-commercial-location-data-to-target-us-servicemembers-in-the-middle-east-wyden-harrigan-and-12-other-bipartisan-members-of-congress-reveal-members-call-on-department-to-adopt-commonsense-safeguards-to-protect-us-troops) — primary congressional release and letter documenting CENTCOM threat reports and requested Defense Department safeguards

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
