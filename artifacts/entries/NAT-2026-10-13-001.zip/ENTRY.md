# CBP proposes advance passenger data and no-board advice for international rail

**Entry ID:** NAT-2026-10-13-001
**Date:** October 13, 2026
**Checked:** 2026-10-13 12:05 PM EDT
**Evidence state:** primary CBP proposed rule; requirements, cost estimates and privacy commitments proposed, outcomes unmeasured
**Review state:** current-standard-reviewed

The proposed rule would extend advance vetting to rail passengers and crews; comments are due December 14 and no mandate is yet in effect.

## THE FACTS

- CBP published a proposed rule that would require international rail carriers to transmit advance train, passenger and crew information for trains entering, departing or transiting the United States. Carriers generally would provide train notice up to 24 hours before departure and submit electronic traveler data before boarding or departure; the proposal is not final or implemented.
- Required or available data would include identity and travel-document information, citizenship and residence, itinerary and U.S. address, alien-registration information when applicable, passenger-name-record fields, Known Traveler or redress numbers, seat and baggage information, and phone or email information when held by the carrier.
- CBP proposes using the data for advance vetting and could advise a carrier not to board a traveler identified as inadmissible, a law-enforcement match or a security concern. The filing says the existing program is voluntary and used by one carrier, so the proposal would create a mandatory nationwide framework for covered international rail service.
- CBP says rail is a gap in advance traveler screening and that earlier data would improve security, processing and enforcement. The rule acknowledges privacy implications and says CBP would update its Privacy Impact Assessment and System of Records Notice if a final rule changes collection; comments are due December 14, 2026.

## SIGNIFICANCE

The proposal would extend an aviation-style advance-vetting model to international rail and could affect whether travelers are allowed to board before they reach a U.S. inspection point. Its security value, error rate, redress process, privacy burden and operational cost remain prospective.

## GOALPOST / RESPONSE

CBP says mandatory advance data will close a security gap, improve admissibility decisions and make inspections more efficient. Final-rule terms, match accuracy, no-board recommendations, correction and redress outcomes, privacy controls, carrier burden and processing times are the tests.

## MAYBE / THEREFORE

Maybe earlier data lets CBP identify genuine threats before departure and reduces border delays, or incomplete and erroneous matches may deny travel and expand sensitive-data collection without commensurate benefit. Therefore CBP has proposed—not implemented—the rail-vetting system, and its claimed security and efficiency gains are not yet measured.


## SOURCES

- [Federal Register — Advance Traveler Information for Rail](https://www.federalregister.gov/documents/2026/10/13/2026-20884/advance-traveler-information-for-rail) — primary proposed rule and regulatory analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
