# DOJ urges narrower civil-contempt test in Apple–Epic Supreme Court case

**Entry ID:** NAT-2026-09-21-004
**Date:** September 21, 2026
**Checked:** 2026-09-22 12:02 PM EDT
**Evidence state:** complete primary United States amicus brief plus Reuters legal reporting; formal litigation position documented, Supreme Court disposition and practical effects unresolved
**Review state:** current-standard-reviewed

A United States amicus brief supports neither party, rejects contempt based only on an injunction's 'spirit,' and asks for different treatment of Apple's challenged restrictions; the Supreme Court has not ruled.

## THE FACTS

- The Solicitor General filed an amicus brief supporting neither party in Apple Inc. v. Epic Games, Inc., No. 25-1311. The brief asks the Supreme Court to hold that civil contempt requires a clear violation of an injunction's express terms, reasonably construed in context, rather than a violation of its general spirit.
- Applying that standard, the United States argues that Apple's 27% commission on directed off-app purchases presented a fair ground of doubt and should not support civil contempt, while Apple's plain-buttons-only restriction clearly violated the injunction and did support contempt.
- For four other design restrictions, the brief asks the Court to vacate and remand for reconsideration under the proposed standard. The government takes no position on whether Apple acted in bad faith or whether other sanctions could rest on that finding.
- The filing is the administration's formal legal position in pending private antitrust litigation. It does not change Apple's App Store rules, reverse the Ninth Circuit judgment, remove sanctions, decide Epic's claims or establish a nationwide contempt rule unless and until the Supreme Court acts.

## SIGNIFICANCE

The United States is asking the Court to clarify a general limit on civil contempt while also endorsing contempt for one Apple restriction. The resulting standard could shape how courts enforce injunctions well beyond the App Store dispute, but the brief itself changes no law or platform practice.

## GOALPOST / RESPONSE

DOJ says clear notice and the severe character of contempt require focus on an injunction's express terms, while still permitting contempt for objectively unreasonable evasion. Supreme Court questioning and judgment, treatment of each Apple restriction, the remand, sanctions and subsequent App Store compliance are the tests.

## MAYBE / THEREFORE

Maybe the proposed standard will improve notice without rewarding evasive conduct, or a narrower contempt rule could make complex injunctions harder to enforce. Therefore DOJ filed a mixed amicus position asking for reversal, affirmance and remand on different issues—not a government enforcement action, Supreme Court holding or change to Apple's commercial terms.


## SOURCES

- [Solicitor General — United States amicus brief in Apple Inc. v. Epic Games, Inc., No. 25-1311](https://fingfx.thomsonreuters.com/gfx/legaldocs/zgpodrmzjvd/25-1311npacUSA_Apple_v_EpicGames_final.pdf) — primary United States merits amicus brief (complete filed document hosted by Reuters)
- [Reuters — United States files mixed civil-contempt position in Apple–Epic case](https://www.reuters.com/legal/government/us-opposes-part-apple-contempt-finding-epic-games-case-us-supreme-court-2026-09-22/) — independent legal reporting on the government amicus brief

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
