# Reuters review measures political skew and avoided penalties in clemency for public officials

**Entry ID:** NAT-2026-10-13-011
**Date:** October 13, 2026
**Checked:** 2026-10-14 6:03 AM EDT
**Evidence state:** independent Reuters investigation based on recipient, court and political-affiliation records, with defined exclusions and administration responses; measured cross-case pattern, not a new grant or adjudicated finding of presidential motive
**Review state:** current-standard-reviewed

A records-based review identified at least 85 public officials granted clemency after corruption-related charges or convictions; the measured pattern is an independent finding, not a new pardon batch.

## THE FACTS

- A Reuters records-based review identified at least 85 public officials whom Trump granted clemency across his two presidential terms after charges or convictions related to corruption. The review counted elected or appointed government officials and civil or uniformed-service employees; it did not treat the 85 as every person Trump has pardoned.
- Among the 85, Reuters identified 36 elected Republicans, 19 Republican political appointees and nine other recipients who had campaigned for Trump or publicly supported his agenda. It identified four known Democrats and could not determine the affiliation of 17 others. These categories describe the outlet's documented sample and do not independently prove the president's motive in each decision.
- Reuters found that nearly three-quarters of the 85 left prison early, avoided trial or sentencing, or regained eligibility for rights such as gun ownership. It calculated that recipients were spared a combined 130 years of incarceration and more than $15 million in financial penalties. Those are the investigation's records-based estimates, not a government audit or a finding that every avoided consequence was improper.
- The review excluded at least 18 active-duty military, police and government employees swept into the roughly 1,500 January 6 clemency grants, making its denominator narrower than all official recipients. It also reported that more than half of the 85 remained in politics as officials or vocal Trump supporters after clemency.
- The White House told Reuters that Trump grants clemency to many Americans unjustly prosecuted by what it calls a weaponized Biden Justice Department. DOJ said it remains committed to public-corruption enforcement and that use of the constitutional pardon power is neither a change in criminal law nor a license for misconduct. Those responses supply the administration's rationale but do not resolve the measured affiliation and penalty pattern.

## SIGNIFICANCE

The review supplies a measurable outcome layer across individual clemency decisions: who in public service received relief, the political distribution Reuters documented and the incarceration and financial consequences avoided. That pattern is material to evaluating how presidential mercy interacts with public-corruption enforcement, while the methodology's defined scope and unresolved motive questions limit broader conclusions.

## GOALPOST / RESPONSE

The administration says clemency corrects unjust or politically motivated prosecutions and does not authorize future crime. Tests include complete recipient-level warrants and case dispositions, transparent and consistently applied review criteria, correction of any documented sample errors, comparison with similarly situated applicants, subsequent public-corruption enforcement and recipient outcomes—not political affiliation alone.

## MAYBE / THEREFORE

Maybe the measured skew reflects the cases Trump believed were politically tainted rather than a loyalty test, or incomplete affiliation data and the sample definition may affect comparisons. Therefore the records-based review documents at least 85 public-official recipients, a heavily Republican-or-pro-Trump distribution in the identified categories and substantial avoided penalties—not proof of motive in every pardon or a finding that clemency itself changed corruption law.


## SOURCES

- [Reuters Special Report — clemency for public officials and measured outcomes](https://www.reuters.com/investigations/trumps-pardons-public-officials-republicans-win-most-mercy-2026-10-13/) — independent records-based investigation measuring recipients, political affiliation and avoided penalties

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
