# Treasury and IRS propose expanded Opportunity Zone reporting and certification rules

**Entry ID:** NAT-2026-09-11-004
**Date:** September 11, 2026
**Checked:** 2026-09-11 5:58 AM EDT
**Evidence state:** complete primary proposed rule inspected; reporting and certification system proposed with agency burden estimates, final obligations and program outcomes unresolved
**Review state:** current-standard-reviewed

The proposal adds fund, business and investor reporting plus decertification procedures; its own estimates identify at least $1.50 million in annual small-entity burden.

## THE FACTS

- Treasury and the Internal Revenue Service published proposed Qualified Opportunity Zone regulations on September 11. Comments are due October 16, a public hearing is scheduled for November 5, and speaking outlines are due October 13, 2026.
- The proposal would implement 2025 statutory reporting provisions through annual information returns for Qualified Opportunity Funds, investor statements following specified dispositions, statements from Qualified Opportunity Zone businesses to funds, penalty rules and procedures for certification revocation or voluntary decertification.
- Treasury and IRS say the reporting would improve IRS visibility, help investors understand eligibility and supply policymakers with annual information for evaluating Opportunity Zone investment. Those purposes are prospective; the proposal does not itself demonstrate job creation, community benefit, investment additionality or enforcement success.
- The agencies estimated that about 11,280 small funds would incur 14,100 annual hours and $885,903 in monetized burden for Form 8996, while about 7,800 small businesses would incur 9,750 hours and $612,593 for business statements. They cautioned that burden could increase and said available data did not allow a determination of whether the rule would significantly affect a substantial number of small entities.

## SIGNIFICANCE

The proposal builds an audit and evaluation layer around a large place-based tax incentive while imposing measurable reporting work on thousands of small entities. Whether the data improve compliance or policy evaluation enough to justify the cost remains unknown.

## GOALPOST / RESPONSE

Treasury and IRS argue the reports are necessary for enforcement, investor clarity and congressional evaluation of Opportunity Zones. Final burden estimates, filing quality, audit findings, investment patterns and independently measured community outcomes are the tests.

## MAYBE / THEREFORE

Maybe standardized reporting makes tax benefits more transparent and enforceable, or incomplete data and compliance burden may persist without revealing whether investments helped targeted communities. Therefore the proposal specifies reporting and certification machinery with agency burden estimates—not a final mandate or proof that Opportunity Zones succeed or fail.


## SOURCES

- [Treasury and IRS — Qualified Opportunity Zone information reporting and fund certification](https://www.federalregister.gov/documents/2026/09/11/2026-18574/information-reporting-regarding-qualified-opportunity-zones-and-updated-qualified-opportunity-fund) — primary Federal Register proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
