# EPA and Army Corps announce supplemental proposal on federal water jurisdiction

**Entry ID:** NAT-2026-09-04-012
**Date:** September 4, 2026
**Checked:** 2026-09-04 6:00 PM EDT
**Evidence state:** primary EPA rulemaking page plus independent Reuters and Associated Press reporting; supplemental proposal announced, Federal Register publication, final text and effects pending
**Review state:** current-standard-reviewed

The agencies reopened the policy choice over which waters receive federal Clean Water Act coverage; no revised definition is final or operative yet.

## THE FACTS

- The Environmental Protection Agency and Army Corps of Engineers announced a supplemental proposed rule seeking additional public comment on the definition of 'waters of the United States' under the Clean Water Act.
- The agencies said the additional process is intended to produce a clearer definition consistent with the Supreme Court's 2023 Sackett decision. Their November 2025 proposal had received more than 220,000 comments after its initial comment period closed in January 2026.
- Associated Press reported that the supplement presents a wider range of approaches for comment amid disagreement over which wetlands and waterways have a sufficiently direct connection to traditionally navigable waters. A narrower definition shifts more regulation to states and tribes; a broader lawful definition would retain more federal permitting and pollution-control coverage.
- The additional comment period is scheduled to run for 30 days after Federal Register publication. The announcement is a supplemental proposal, not a final rule, and it does not itself change the current jurisdictional definition or decide how the agencies will resolve the competing options.

## SIGNIFICANCE

The definition governs the reach of federal permitting and pollution protections across wetlands, streams and development sites nationwide. Reopening the proposal signals that the agencies have not settled the final boundary, while any eventual rule is likely to face significant implementation and litigation tests.

## GOALPOST / RESPONSE

The administration says the additional input can produce a clear, durable rule that respects Sackett, economic activity and state and tribal authority. Environmental advocates warn that a narrow definition can remove protections from wetlands and streams. Federal Register text, submitted comments, the final definition, implementation guidance, jurisdictional determinations, state responses and judicial review are the tests.

## MAYBE / THEREFORE

Maybe the supplemental process will correct weaknesses and yield a more durable, administrable boundary, or it may delay resolution while inviting an even narrower rule and further litigation. Therefore the record establishes a formal additional proposal and comment period—not a changed operative definition, reduced or expanded protections at a particular site or a final legal settlement.


## SOURCES

- [EPA — Waters of the United States rulemaking page](https://www.epa.gov/wotus) — primary agency rulemaking page and proposal background
- [Reuters — EPA and Army Corps propose additional WOTUS rulemaking](https://www.reuters.com/legal/litigation/epa-army-corps-seek-more-input-federal-water-regulation-us-2026-09-04/) — independent reporting on the supplemental proposal and additional public input
- [Associated Press — EPA seeks more public comment on federal water jurisdiction](https://apnews.com/article/62178988f1da0ec626415bd85c88e5f6) — independent reporting on the supplemental proposal, prior comments and competing interpretations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
