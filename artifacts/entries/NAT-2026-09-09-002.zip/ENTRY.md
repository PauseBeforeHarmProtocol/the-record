# Census Bureau proposes excluding most noncitizens from apportionment and removing race questions

**Entry ID:** NAT-2026-09-09-002
**Date:** September 9, 2026
**Checked:** 2026-09-09 6:01 PM EDT
**Evidence state:** official proposed rule plus independent reporting
**Review state:** current-standard-reviewed

The two-part proposal would change who counts for House apportionment and bar race, ethnicity and sexual-orientation questions from the decennial enumeration form.

## THE FACTS

- A Census Bureau proposal signed September 8 was filed for public inspection September 9, with publication scheduled for September 10 and comments due 30 days after publication. It is not a final rule and has not changed the 2030 census.
- For House apportionment, the proposal would count foreign citizens only if they are also U.S. citizens or lawful permanent residents as of Census Day. Other foreign citizens, including people lawfully present on temporary visas, would not count for apportionment.
- It would define usual residence as the place where a person lawfully spent the most days from January 3 through April 1, supported by tax records, and contemplates using federal, state, local, tribal and commercial administrative data to determine residence and legal status.
- A separate part would bar race, ethnicity and sexual-orientation questions from the short-form decennial questionnaire and other enumeration questionnaires while permitting questions about biological sex, birth date and household relationships. It would not bar those demographic questions from the American Community Survey or prevent the bureau from receiving demographic data from administrative records.

## SIGNIFICANCE

If finalized and sustained, the residence rule could change state apportionment and redistricting inputs by excluding categories of residents counted in 2020, while the questionnaire rule would change a long-running federal demographic dataset. Neither representation, funding, response rates, privacy effects nor operational accuracy has changed or been measured yet.

## GOALPOST / RESPONSE

The bureau says the proposal better reflects usual residence and allegiance, protects privacy, reduces response burden and focuses the census on its constitutional apportionment function. Critics cited by Reuters argue that the Fourteenth Amendment requires counting the whole number of persons in each state. Comments, final text, methodology, litigation, census testing and the eventual apportionment count are the relevant tests.

## MAYBE / THEREFORE

Maybe narrower residence criteria and fewer sensitive questions could reduce burden and improve record linkage, or the changes could undercount settled communities and diminish essential demographic data. Therefore the evidence establishes a two-part proposal open to comment—not a changed census, lawful final rule, altered House map, improved response rate or measured privacy benefit.


## SOURCES

- [Federal Register public inspection — proposed decennial-census residence and demographic-question rules](https://www.federalregister.gov/public-inspection/2026-18481/decennial-census-of-the-population-of-americans-proposed-residence-criteria-and-proposed-regulations) — primary proposed rule filed for public inspection September 9 and scheduled for September 10 publication
- [Reuters — Census Bureau proposes narrower apportionment count and demographic-question limits](https://www.reuters.com/legal/government/trump-administration-proposes-dropping-huge-swath-immigrants-us-census-2026-09-09/) — independent reporting on the proposal, constitutional context and anticipated legal dispute

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
