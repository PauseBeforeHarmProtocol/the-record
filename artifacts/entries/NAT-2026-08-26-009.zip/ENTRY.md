# USAID watchdog reports three proposed UNRWA-related debarments

**Entry ID:** NAT-2026-08-26-009
**Date:** August 26, 2026
**Checked:** 2026-08-27 12:00 AM EDT
**Evidence state:** August 26 investigative summary from the statutorily independent USAID Office of Inspector General; three proposed State Department debarments reported, underlying evidence and final adjudications not public
**Review state:** current-standard-reviewed

USAID's inspector general says the State Department proposed barring three former UNRWA teachers from U.S.-funded programs based on alleged militant links or October 7 conduct.

## THE FACTS

- USAID's Office of Inspector General reported on August 26 that it had referred more than 100 current or former UNRWA staff to the State Department for independent evidence review and possible suspension or debarment based on alleged participation in the October 7 attacks and/or affiliation with Hamas.
- The watchdog said the State Department recently proposed three former UNRWA school teachers for debarment: two based on alleged Hamas roles or conduct and one based on an alleged Palestinian Islamic Jihad role. A proposed action involving a fourth person was terminated after records indicated he was dead.
- The summary says one earlier subject received a government-wide debarment and additional administrative or criminal referrals may follow. It does not say the three new proposals are final, that every person in the larger referral pool participated in the October 7 attacks, or that criminal charges have been filed.

## SIGNIFICANCE

A government-wide debarment can prevent a person from participating in U.S.-funded assistance programs, making the proposals a concrete federal oversight action rather than only political rhetoric. Because the underlying conduct allegations are grave and the public summary does not disclose the full evidence or identify the three subjects, procedural status and attribution are essential.

## GOALPOST / RESPONSE

USAID OIG says its investigation protects U.S.-funded humanitarian assistance from terrorist-affiliated actors and sends evidence to State for independent review. The strongest countervailing test is whether the evidence survives State's notice-and-response process. Final suspension or debarment decisions, disclosed findings, administrative appeals, criminal referrals, and any UNRWA or subject response are the evidence tests.

## MAYBE / THEREFORE

Maybe the confidential evidence establishes the alleged conduct and supports exclusion from U.S.-funded programs; maybe independent State review narrows or rejects some referrals. Therefore the record attributes the allegations to USAID OIG and records three proposed debarments, not three final debarments and not a proven finding against every person in the larger referral pool.


## SOURCES

- [USAID OIG — three proposed UNRWA-related debarments](https://oig.usaid.gov/node/8198) — primary investigative summary stating attributed allegations, referrals, and proposed-not-final debarment status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
