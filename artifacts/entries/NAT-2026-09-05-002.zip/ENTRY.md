# United States and Namibia announce transition from HIV funding to technical cooperation

**Entry ID:** NAT-2026-09-05-002
**Date:** September 5, 2026
**Checked:** 2026-09-05 6:00 PM EDT
**Evidence state:** Associated Press reporting quoting a joint U.S.-Namibian statement and named Namibian positions; funding amount and transition announced, successor agreement, replacement financing and outcomes pending
**Review state:** current-standard-reviewed

Washington will provide $45 million for Namibia's fiscal-year 2027 HIV response, then phase out direct financial support under the announced model.

## THE FACTS

- The United States and Namibia announced that U.S. support for Namibia's HIV response would transition from financial assistance to technical cooperation after fiscal year 2027.
- The United States will provide $45 million for fiscal year 2027. Namibia had received roughly $45 million annually in recent years through the President's Emergency Plan for AIDS Relief, and the United States says it has contributed more than $1.1 billion to Namibia's HIV response since 2003.
- The governments said the next year would be used to integrate the HIV response into Namibia's national health system in accordance with Namibian law. They reported that 96% of people living with HIV knew their status, 98% of those diagnosed received treatment and 98% of those treated had achieved viral suppression.
- The transition follows Namibia's rejection of proposed provisions for sharing health data and biological specimens, which Namibian officials said conflicted with national law, privacy protections and sovereignty over biological resources. Both governments were reported to be negotiating a revised bilateral health agreement; no completed agreement or detailed fiscal-year 2028 technical-cooperation plan was public by cutoff.
- The administration says its country agreements are intended to reduce donor dependency, increase domestic financing and protect U.S. interests. The announcement does not establish that Namibia has replaced the future U.S. financing, that services will remain unchanged or that health outcomes will improve or deteriorate after the transition.

## SIGNIFICANCE

The plan sets a concrete endpoint for direct U.S. HIV financing in a country where PEPFAR has operated for more than two decades. Namibia's strong reported treatment outcomes may support a transition, but funding replacement, continuity of prevention and treatment, data protections and the terms of technical cooperation remain consequential and unmeasured.

## GOALPOST / RESPONSE

The administration says bilateral transitions should build sustainable domestic systems and reduce donor dependence while protecting American interests; Namibia insists that cooperation comply with its privacy and sovereignty laws. A signed revised agreement, Namibia's replacement budget, staffing and commodity continuity, service coverage, viral suppression, new infections and mortality after fiscal year 2027 are the tests.

## MAYBE / THEREFORE

Maybe Namibia's reported 96-98-98 performance makes a planned, year-long transition to domestic financing responsible and sustainable, or ending direct support without a verified replacement may put proven services and gains at risk. Therefore the record establishes the $45 million fiscal-year 2027 commitment and announced later technical-only model—not a completed funding withdrawal, signed successor agreement, service disruption or measured health effect.


## SOURCES

- [Associated Press — United States and Namibia announce PEPFAR funding transition](https://apnews.com/article/namibia-hiv-us-foreign-aid-pepfar-68878a0f51a7a4f1387642779b507a6f) — independent reporting quoting the governments' joint statement on fiscal-year 2027 funding and later technical cooperation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
