# HHS appoints eight members to reconstituted preventive-services panel

**Entry ID:** NAT-2026-09-17-006
**Date:** September 17, 2026
**Checked:** 2026-09-18 5:59 AM EDT
**Evidence state:** primary USPSTF announcement and roster plus independent Reuters reporting; appointments implemented, future recommendations and coverage effects unresolved
**Review state:** current-standard-reviewed

The appointments restore the 16-member USPSTF roster; no new screening recommendation or coverage change was issued.

## THE FACTS

- The U.S. Preventive Services Task Force announced eight new members whose four-year terms began in September 2026, restoring the official roster to 16 volunteer members. Seth J. Corey is listed as chair.
- The official roster says HHS secretaries appoint members and that the panel comprises nationally recognized experts in prevention, evidence-based medicine and primary care. The appointments are completed personnel actions, not new clinical recommendations.
- USPSTF grades influence which preventive services many private insurance plans must cover without patient cost sharing under federal law. No recommendation, effective coverage rule or patient-level outcome changed through the appointment announcement alone.
- Reuters reported that the panel had not met for about a year and that the American Medical Association said the new composition departed from the panel's traditional makeup. HHS did not announce the next meeting date by cutoff.

## SIGNIFICANCE

Reconstituting the panel restores the membership body that evaluates evidence for nationally consequential preventive-care recommendations. The appointments may affect future priorities and judgments, but they do not by themselves alter coverage or prove that scientific standards have changed.

## GOALPOST / RESPONSE

HHS and the official task-force materials present the appointees as qualified experts serving the statutory evidence-review function. The strongest concern is whether the new composition preserves the panel's traditional independence and methodological standards. Meeting notices, conflict disclosures, evidence reviews, recommendation votes and resulting coverage effects are the tests.

## MAYBE / THEREFORE

Maybe the new members restart delayed work and apply the established evidence process, or the reconstitution may change priorities or confidence in the panel. Therefore the record confirms eight appointments and a restored roster—not a new screening rule, compromised recommendation or measured health outcome.


## SOURCES

- [U.S. Preventive Services Task Force — September 2026 membership announcement and roster](https://www.uspreventiveservicestaskforce.org/uspstf/about-uspstf/current-members) — primary announcement and official membership roster
- [Reuters — HHS secretary appoints eight members to preventive-services panel](https://www.reuters.com/world/us/us-health-secretary-kennedy-adds-eight-new-members-key-preventive-health-panel-2026-09-17/) — independent reporting on formal appointments, panel role and professional response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
