# DHS approves third 90-day extension of Jones Act waiver

**Entry ID:** NAT-2026-11-13-007
**Date:** November 13, 2026
**Checked:** 2026-11-14 12:08 AM EST
**Evidence state:** Primary CBP implementation guidance plus Reuters reporting; extension approved and effective November 16, individual voyage authorizations and downstream effects not yet established
**Review state:** current-standard-reviewed

The national-defense waiver will continue from November 16 through February 14 under a voyage-by-voyage vessel-availability process rather than blanket permission for every foreign-flag shipment.

## THE FACTS

- The Department of Homeland Security approved a third extension of the Jones Act waiver first dated March 17, 2026, at the Department of War's request. The additional 90-day period begins November 16 at 12:00 a.m. EST.
- CBP said covered products must be loaded aboard the relevant vessel before 11:59 p.m. EST on February 14, 2027. It also published a list of potentially covered products as of November 16.
- The extension does not automatically authorize every foreign-flag voyage. A prospective shipper must submit a vessel-availability request; the Maritime Administration surveys for coastwise-qualified vessels, and the Department of War then determines whether the waiver applies to the proposed voyage.
- Reuters reported that the waiver allows foreign-flagged vessels to move covered oil and other commodities between U.S. ports and described it as the longest waiver in the law's history. The Jones Act ordinarily reserves coastwise cargo movement to qualifying U.S.-built, U.S.-owned and U.S.-crewed vessels.
- The administration has presented the waiver as national-defense and supply flexibility during the Iran-war disruption. The inspected evidence does not independently establish how much the extension will reduce bottlenecks, fuel prices or military risk, and it does not resolve the tradeoff with domestic maritime capacity and employment.

## SIGNIFICANCE

A third extension continues a historically long suspension of a core domestic-shipping restriction and can affect energy logistics, freight costs and the U.S. maritime industrial base. The case-by-case process is material because it narrows the action from a blanket authorization while still allowing foreign-flag coastwise transport.

## GOALPOST / RESPONSE

The administration can demonstrate effectiveness with the number and cargo volume of approved voyages, coastwise-vessel survey results, delivery times, transport-cost and retail-price effects, military-supply outcomes, safety compliance and measured effects on U.S.-flag carriers, shipbuilding and maritime employment.

## MAYBE / THEREFORE

Maybe the extension will relieve genuine vessel bottlenecks and improve national-defense supply flexibility, or it may shift business from U.S.-qualified shipping without producing measurable consumer relief. Therefore the record establishes an approved 90-day extension with voyage-specific conditions—not a blanket exemption, a measured price reduction or proof that domestic capacity was unavailable in every case.


## SOURCES

- [CBP — third extension and implementation guidance for March 17 Jones Act waiver](https://content.govdelivery.com/accounts/USDHSCBP/bulletins/432c16c) — primary agency implementation notice stating the 90-day extension, effective time, shipment deadline and vessel-availability process
- [Reuters — United States extends Jones Act waiver for 90 days](https://www.reuters.com/world/us/us-extends-shipping-law-waiver-90-days-allow-freer-movement-oil-commodities-2026-11-13/) — independent reporting on the extension, foreign-flag scope, administration rationale and historical duration

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
