# Treasury removes Venezuela assembly leader Jorge Rodriguez from sanctions list

**Entry ID:** NAT-2026-10-14-005
**Date:** October 14, 2026
**Checked:** 2026-10-14 6:03 PM EDT
**Evidence state:** primary OFAC deletion notice plus independent Reuters reporting; designation removal implemented, rationale and negotiated conditions undisclosed
**Review state:** current-standard-reviewed

OFAC implemented the delisting as U.S.-backed political talks resumed; the public notice did not state a reason or impose an election timetable.

## THE FACTS

- The Treasury Department's Office of Foreign Assets Control removed Jorge Jesus Rodriguez Gomez and his aliases from the Specially Designated Nationals list under its Venezuela program on October 14. The list deletion was implemented, not merely proposed.
- Reuters identified Rodriguez as president of Venezuela's National Assembly, brother of acting president Delcy Rodriguez and a lead government negotiator in U.S.-backed talks with an opposition faction. The latest talks were set to address political reforms ahead of eventual elections.
- Neither OFAC's public notice nor the Reuters report supplied a U.S. explanation for the delisting. Venezuela's communications ministry did not immediately respond to Reuters, and no firm election date had been set in the material reviewed.
- Removing a person from the SDN list lifts the blocking restrictions tied to that listing; it does not itself certify democratic reform, resolve other sanctions, guarantee negotiations or establish that an election will occur on a particular date.

## SIGNIFICANCE

The delisting is a concrete sanctions-policy change affecting a central Venezuelan official during U.S.-backed political negotiations. Because the administration gave no public rationale or benchmark, the relationship between sanctions relief and negotiated reforms remains unverified.

## GOALPOST / RESPONSE

The apparent policy theory is that targeted sanctions relief can support negotiations and political-system changes. Tests include a stated rationale, reciprocal steps, verifiable electoral and judicial reforms, an election timetable, compliance with any private conditions and whether sanctions are restored if talks fail.

## MAYBE / THEREFORE

Maybe the delisting is calibrated leverage for a negotiated transition, or it may grant relief without enforceable democratic concessions. Therefore OFAC removed Rodriguez from the SDN list while talks were resuming—not proof that reforms were agreed, elections scheduled or broader Venezuela sanctions ended.


## SOURCES

- [OFAC — Venezuela-related designation removal for Jorge Rodriguez](https://ofac.treasury.gov/recent-actions/20261014) — primary sanctions-list deletion notice
- [Reuters — U.S. lifts sanctions on Venezuela legislature head](https://www.reuters.com/business/energy/us-lifts-sanctions-head-venezuela-legislature-2026-10-14/) — independent reporting on implemented delisting, political talks and absence of a stated reason

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
