# State Department narrows arms-export controls on protected civil aircraft

**Entry ID:** NAT-2026-08-28-003
**Date:** August 28, 2026
**Checked:** 2026-08-28 6:03 AM EDT
**Evidence state:** State Department interim final rule in the Federal Register; rule published August 28, scheduled effective October 13, comments and possible later revisions pending
**Review state:** current-standard-reviewed

The interim final ITAR rule takes effect October 13 and eases movement and ordinary servicing while retaining controls on defensive equipment, data, and related services.

## THE FACTS

- The State Department published an interim final rule removing certain otherwise-civil aircraft modified with specified aircraft survivability equipment from the U.S. Munitions List. The rule is scheduled to take effect October 13, 2026, with comments due September 28; it was published but was not yet operational at the checked time.
- The covered defensive equipment consists of secured directed-infrared countermeasures and associated missile-warning systems. State says the change will ease ordinary operation and maintenance of protected aircraft used by airlines, foreign governments, international organizations, and humanitarian groups.
- The rule also excludes specified temporary imports and reexports involving already-authorized secured equipment incorporated into qualifying aircraft. It does not deregulate the defensive equipment itself: the equipment remains on the Munitions List, and related technical data, defense services, removal, transfer to a new foreign person, and other retransfers remain controlled.
- State says the prior framework imposed unnecessary compliance burdens and put U.S. firms at a competitive disadvantage while offering no critical military or intelligence advantage for ordinary civil-aircraft servicing. It retains controls where the technology or service itself provides such an advantage.

## SIGNIFICANCE

The rule shifts a defined class of protected civil aircraft out of the stricter arms-export regime while retaining national-security controls on the countermeasure systems themselves. The distinction affects airlines, maintenance providers, government transport, humanitarian operations, and U.S. defense-trade competitiveness.

## GOALPOST / RESPONSE

State's case is that previously licensed equipment can remain protected without requiring separate review of routine aircraft movements and ordinary civil maintenance. The risk is whether simplified movement or servicing creates diversion, access, or technology-transfer gaps. Comments, licensing practice, enforcement disclosures, transfers, security incidents, and any changes in the final rule are the tests.

## MAYBE / THEREFORE

Maybe the aircraft-equipment distinction removes redundant paperwork without weakening control of sensitive technology, or operational exceptions may prove harder to police across jurisdictions. Therefore the record describes a published interim final rule with an October 13 effective date—not current blanket deregulation of missile countermeasures or authorization for defense services and technical-data transfers.


## SOURCES

- [State Department — ITAR rule for survivability-enhanced civil aircraft](https://www.federalregister.gov/documents/2026/08/28/2026-17660/international-traffic-in-arms-regulations-modification-of-civil-aircraft-to-incorporate-aircraft) — primary interim final arms-export-control rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
