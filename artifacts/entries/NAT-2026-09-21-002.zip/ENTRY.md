# Judge declines to block SpaceX wildlife-refuge land exchange

**Entry ID:** NAT-2026-09-21-002
**Date:** September 21, 2026
**Checked:** 2026-09-21 11:57 PM EDT
**Evidence state:** complete Fish and Wildlife Service finding of no significant impact plus Associated Press reporting quoting and characterizing the federal preliminary-injunction ruling; agency approval and denial of preliminary relief documented, full order, merits, transfer and environmental outcomes unresolved
**Review state:** current-standard-reviewed

The preliminary-injunction denial removes an immediate barrier to the federal land exchange while the challenge continues; it is not a merits ruling or proof of completed transfer.

## THE FACTS

- The U.S. Fish and Wildlife Service approved an exchange in June under which SpaceX would convey 683 acres it owns and receive 715 federal acres in the Lower Rio Grande Valley National Wildlife Refuge. The agency's finding of no significant impact says consolidating federal holdings would improve habitat connectivity and produce a net conservation benefit; those are the agency's analysis and rationale, not independently measured outcomes.
- On September 21, U.S. District Judge Fernando Rodriguez Jr. denied opponents' request for a preliminary injunction. Associated Press reported that the judge found their evidence of environmental harm relatively weak and said they had not shown aesthetic, environmental, cultural or historical degradation during the lawsuit. The order was reported but not independently retrieved for this release.
- Associated Press reported that the judge also found an injunction would burden SpaceX's development plans and its ability to meet milestones and contractual obligations. Denial of preliminary relief permits the exchange process to proceed; it does not decide the legality of the exchange on the merits, resolve every environmental claim or establish that the land has already transferred.
- The plaintiffs say the exchange improperly benefits a private company and threatens ecological and cultural resources, and they said their challenge will continue. Fish and Wildlife did not comment on the ruling, while SpaceX did not respond to Associated Press; no final judgment, appeal disposition, completed exchange, development approval or measured environmental effect existed by cutoff.

## SIGNIFICANCE

The ruling removes the immediate judicial obstacle to transferring refuge acreage near SpaceX's South Texas launch site, while preserving a live challenge to the agency's environmental and land-management judgment. The practical and environmental consequences remain contingent on transfer, development and later litigation.

## GOALPOST / RESPONSE

Fish and Wildlife says the exchange will consolidate refuge holdings and create a net conservation benefit; opponents say it shifts protected public land to a private company and risks ecological and cultural harm. The full order, merits record, deed and valuation documents, completed exchange, development permits, habitat monitoring and final judgment are the tests.

## MAYBE / THEREFORE

Maybe the exchange improves landscape-scale conservation while allowing development on a less valuable parcel, or the preliminary record may understate harms that emerge after transfer. Therefore the court denied preliminary relief and the agency's exchange may proceed during litigation—not that the exchange was finally upheld, completed or shown to benefit or harm the refuge.


## SOURCES

- [Fish and Wildlife Service — Boca Chica land-exchange finding of no significant impact](https://www.fws.gov/media/finding-no-significant-impact-boca-chica-land-exchange-2026) — primary agency environmental finding and exchange rationale
- [Associated Press — judge declines to block SpaceX wildlife-refuge land exchange](https://apnews.com/article/1f7199638f067cfbd447ed3ccd03e6b7) — independent reporting quoting the federal preliminary-injunction ruling

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
