# United States delivers donated C-130 transport aircraft to Colombia

**Entry ID:** NAT-2026-11-18-005
**Date:** November 18, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** Associated Press confirmation, Reuters pre-delivery reporting and Colombian ceremony coverage; aircraft delivered and donation documents reported signed, with valuation, authority and operational use unresolved
**Review state:** current-standard-reviewed

Hegseth presided over the Bogotá handover of aircraft FAC 1019 and transfer documents were signed; the sources did not establish the donation's valuation, funding authority or operational use.

## THE FACTS

- Defense Secretary Pete Hegseth presided over the November 18 delivery of a C-130 Hercules military transport aircraft to Colombia at the Military Transport Air Command in Bogotá. Colombian reporting identified the donated aircraft as FAC 1019 and said officials signed documents connected to the transfer.
- Associated Press independently reported the completed delivery and described the aircraft as capable of transporting troops into hostile areas and using makeshift runways. Reuters had reported before the ceremony that Colombia's defense minister expected Hegseth to hand over a Lockheed Martin C-130.
- Hegseth framed the delivery as part of shared counter-cartel cooperation and said the aircraft was 'just the beginning' as the United States expands military-equipment production and its Western Hemisphere focus. That statement announces intended broader cooperation, not a separately documented future transfer or joint operation.
- The inspected sources did not publish the aircraft's valuation, title-transfer terms, funding account, refurbishment costs, sustainment package, end-use conditions or evidence of operational deployment. No evidence tied this donation to the separate $52 million reprogramming recorded in NAT-2026-09-15-012.

## SIGNIFICANCE

The completed transfer adds airlift capacity to a security partner as the administration broadens regional counter-cartel cooperation. Its fiscal basis, conditions and operational effects remain unresolved, and delivery alone does not establish joint combat operations or successful interdiction outcomes.

## GOALPOST / RESPONSE

The administration presents the aircraft as an initial contribution to a shared fight against drug-trafficking organizations. The tests are publication of transfer and funding terms, Colombian acceptance and sustainment, actual missions, end-use monitoring, further equipment transfers and independently measured security outcomes.

## MAYBE / THEREFORE

Maybe the donated aircraft will improve Colombian mobility and interdiction capacity, or sustainment limits and policy changes may narrow its use. Therefore a specific C-130 was delivered and documented as a donation—not proof of operational deployment, a larger equipment package or measured counter-cartel success.


## SOURCES

- [Hegseth delivers military plane to Colombia as U.S. expands campaign against drug cartels](https://apnews.com/article/3d0f8ed366d6084e1cfe12a4d8020c55) — independent live reporting confirming the completed C-130 delivery and the administration's stated counter-cartel rationale
- [Hegseth, in Caracas, announces U.S.-Venezuela military partnership agreement](https://www.reuters.com/world/americas/us-defense-secretary-hegseth-vows-boost-venezuela-military-cooperation-2026-11-18/) — independent reporting on the announced agreement, training and intelligence-sharing scope, and both governments' explanations
- [Estados Unidos le donó a Colombia un avión Hércules C-130](https://www.elpais.com.co/colombia/estados-unidos-le-dono-a-colombia-un-avion-hercules-c-130-la-entrega-la-hizo-pete-hegseth-secretario-de-guerra-norteamericano-1847.html) — independent Colombian reporting on the donation ceremony, FAC 1019 identifier and signed transfer documents

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
