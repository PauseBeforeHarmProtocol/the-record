# DOJ reports nationwide COVID-loan fraud surge covering more than 160 defendants

**Entry ID:** NAT-2026-09-14-007
**Date:** September 14, 2026
**Checked:** 2026-09-14 6:00 PM EDT
**Evidence state:** primary Justice Department nationwide enforcement accounting with explicit allegation and presumption-of-innocence limits; charges, pleas and sentences reported, recoveries and final outcomes incomplete
**Review state:** current-standard-reviewed

Operation No Doze combined new charges, guilty pleas and sentences involving an agency-reported $245 million in intended loss; those lifecycle stages are not one conviction count.

## THE FACTS

- The Justice Department's National Fraud Enforcement Division, the Small Business Administration and SBA's inspector general announced results from Operation No Doze, a June 12–September 1 nationwide enforcement surge involving 44 U.S. Attorneys' Offices and federal, state and local investigative partners.
- DOJ reported felony charges against nearly 80 defendants associated with about $100 million in intended loss, guilty pleas by approximately 43 defendants associated with about $44 million, and sentences for approximately 40 defendants associated with nearly $100 million. The department summarized the combined activity as more than 160 defendants and approximately $245 million in intended loss.
- Charges, pleas and sentences are distinct lifecycle stages and the department's dollar figures describe intended loss, not a verified recovery total. The archive does not add the category figures to create a different total, assume the groups are perfectly comparable or treat every charged person as convicted.
- DOJ listed example cases involving alleged fabricated businesses, identity misuse, false payroll or revenue claims and concealed foreign ties. An indictment, information or complaint remains an allegation, and defendants who have not pleaded guilty or been convicted retain the presumption of innocence.
- The department also announced three new federal-state cooperation agreements with Missouri, Nebraska and Kansas officials. The administration says the surge protects taxpayer funds and expands fraud enforcement; the announcement did not provide a consolidated conviction rate, restitution collected, administrative cost or net-recovery calculation.

## SIGNIFICANCE

The surge is a nationwide implementation measure for the administration's new fraud division and supplies separate counts for charges, pleas and sentences. Its scale is material, but intended-loss totals are not interchangeable with proven loss, restitution or convictions.

## GOALPOST / RESPONSE

DOJ and SBA say coordinated federal-state enforcement will deter fraud and recover taxpayer money. Court dispositions, acquittals and dismissals, proven-loss findings, restitution and forfeiture collected, administrative costs, duplicate-defendant accounting and independently auditable program-wide fraud rates are the tests.

## MAYBE / THEREFORE

Maybe concentrated enforcement produces durable recoveries and deterrence, or headline intended-loss figures may overstate net taxpayer return if cases fail or collections lag. Therefore the announcement establishes a coordinated surge and its agency-reported stage-specific totals—not guilt for charged defendants, $245 million recovered or a measured program-wide reduction in fraud.


## SOURCES

- [Justice Department — Operation No Doze summer COVID-loan fraud enforcement surge](https://www.justice.gov/opa/pr/dojs-fraud-division-sba-and-sba-oig-target-245m-covid-loan-fraud-enforcement-activity-state) — primary nationwide enforcement accounting with charge, plea, sentence, intended-loss and partnership figures

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
