# DHS says incomplete ICE background checks and training now trigger administrative leave

**Entry ID:** NAT-2026-11-18-002
**Date:** November 18, 2026
**Checked:** 2026-11-18 6:08 PM EST
**Evidence state:** official House hearing page and video metadata plus Associated Press reporting and correction; implemented safeguard asserted in testimony, workforce counts and independent audit unavailable
**Review state:** current-standard-reviewed

Secretary Markwayne Mullin told Congress that ICE personnel lacking final background checks or the full 13-week training are on administrative leave; the assertion has not yet been matched to a public workforce audit.

## THE FACTS

- The House Homeland Security Committee held its annual worldwide-threats hearing from 10 a.m. to 1 p.m. EST on November 18. The official page identifies Homeland Security Secretary Markwayne Mullin as a witness and links official video ID I3htVxVRhDg; complete captions or an official hearing transcript were not retrieved.
- Associated Press reported that ICE had hired 12,000 new officers and special agents in an unprecedented expansion that prompted questions about shortened training and incomplete vetting.
- Mullin testified that every ICE officer currently in service has a completed full background check and that personnel without a final background check are on administrative leave.
- He also testified that officers who have not completed the full 13 weeks of training are on leave until they finish it. The statements describe an implemented personnel control, but no public roster, leave count, completion audit or inspector-general finding was located by cutoff.
- Associated Press corrected its live account to say Mullin did not acknowledge that ICE officers had been hired and allowed to work under lowered standards and incomplete background checks. This entry therefore records his present-tense safeguard assertion without treating disputed prior practice as an administration admission.

## SIGNIFICANCE

Removing incompletely vetted or trained immigration officers from active service is a material operational safeguard in a rapidly expanded armed workforce. The disclosure matters because the policy can be tested against personnel and training records, while testimony alone cannot establish complete compliance or remedy past conduct.

## GOALPOST / RESPONSE

The administration's strongest explanation is that regular training has been restored and personnel missing final vetting or training are no longer in active service. The tests are a dated workforce audit, the number placed on leave, completion and reinstatement records, training curriculum and firearms qualification, inspector-general or congressional findings, disciplinary outcomes and measured incident rates.

## MAYBE / THEREFORE

Maybe administrative leave and restored training fully corrected risks created by the hiring surge, or unresolved gaps may remain outside the secretary's testimony. Therefore the evidence establishes a sworn current safeguard assertion and a testable implementation claim—not an independent audit, a count of affected personnel or an admission about every prior deployment.


## SOURCES

- [Worldwide Threats to the Homeland: 25 Years After 9/11](https://homeland.house.gov/hearing/worldwide-threats-to-the-homeland-25-years-after-9-11/) — primary congressional hearing page and official video metadata; no complete transcript or captions retrieved
- [Takeaways from Mullin's House testimony on cyber outages, the Texas-LSU flight and immigration](https://apnews.com/article/ce63a22797c61ee53d88678000236c37) — independent reporting on sworn testimony concerning ICE background checks, training and administrative leave
- [The Latest: Congress grills Mullin on flight disruptions, his football trip and immigration](https://apnews.com/article/9994c430b2b12b16c03685b981c4830d) — independent live-report correction preserving what the secretary did and did not acknowledge in testimony

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
