# HHS publishes final Section 504 rule excluding specified gender dysphoria

**Entry ID:** NAT-2026-11-03-001
**Date:** November 3, 2026
**Checked:** 2026-11-03 12:07 PM EST
**Evidence state:** Federal Register final rule, HHS explanation and two attributed disability-rights responses; future implementation, individual coverage, outcomes and judicial review unresolved
**Review state:** current-standard-reviewed

The rule adds statutory disability exclusions to HHS's Section 504 regulation and interprets them to include gender dysphoria not resulting from a physical impairment; it takes effect January 4, 2027.

## THE FACTS

- HHS published a final rule at 91 FR 69207 on November 3. It amends the Section 504 regulation for programs and activities receiving HHS financial assistance and is scheduled to take effect January 4, 2027. Publication and a future effective date do not establish completed recipient implementation or measured effects.
- The rule adds the Rehabilitation Act's statutory exclusions to 45 CFR 84.4(g) and interprets the exclusion for gender identity disorders not resulting from physical impairments to encompass gender dysphoria not resulting from a physical impairment. It does not say that every instance of gender dysphoria is excluded, adjudicate any individual's condition or resolve protections under other laws.
- HHS said the rule resolves ambiguity it saw in the 2024 rule's preamble, conforms the regulation to statutory text and responds to more than 380 comments. That is the administration's legal and policy rationale, not a judicial holding that the interpretation is required or valid.
- The Center for Public Representation and the Disability Rights Education and Defense Fund opposed the final rule, warning that some transgender people could lose Section 504 nondiscrimination and reasonable-accommodation protections in HHS-funded settings. Those are stakeholder forecasts; no national post-effective-date denial or outcome measurement existed at cutoff.
- The operative scope is bounded: HHS-funded programs under this regulation, the specified statutory category and a future effective date. Recipient guidance, individual coverage disputes, enforcement, litigation and effects on access to care or accommodations remain unresolved.

## SIGNIFICANCE

The final rule changes the disability-definition framework used across HHS-funded health and social-service programs and may affect who can invoke Section 504 protections. Its practical and legal reach will turn on physical-impairment determinations, recipient implementation, enforcement and court review.

## GOALPOST / RESPONSE

HHS says the amendment faithfully carries statutory exclusions into the regulation and corrects ambiguity from 2024. Disability-rights groups say the interpretation will withdraw protections from some transgender people. The tests are the final rule's effective implementation, agency guidance, coverage and accommodation decisions, enforcement data and judicial review.

## MAYBE / THEREFORE

Maybe the rule only clarifies a narrow statutory exclusion, or its interpretation may materially reduce Section 504 protection in HHS-funded settings for people whose gender dysphoria is found not to result from a physical impairment. Therefore a final rule is published with a January 4 effective date; it is not yet an implemented outcome, a finding about every person with gender dysphoria or a ruling on other civil-rights laws.


## SOURCES

- [Federal Register — Section 504 final rule on statutory disability exclusions](https://www.federalregister.gov/documents/2026/11/03/2026-22380/nondiscrimination-on-the-basis-of-disability-in-programs-or-activities-receiving-federal-financial) — primary final rule, 91 FR 69207, effective January 4, 2027
- [HHS — final Section 504 rule on gender dysphoria](https://www.hhs.gov/press-room/hhs-finalizes-section-504-rule-gender-dysphoria-disability.html) — primary agency explanation of scope, statutory interpretation, comments and effective date
- [Center for Public Representation — response to HHS Section 504 final rule](https://www.centerforpublicrep.org/news/cpr-opposes-hhs-ocr-final-rule-excluding-gender-dysphoria/) — disability-rights stakeholder response describing anticipated accommodation and nondiscrimination consequences
- [Disability Rights Education and Defense Fund — statement on HHS Section 504 rule](https://dredf.org/dredf-statement-hhs-504-october-2026/) — disability-rights stakeholder response to the final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
