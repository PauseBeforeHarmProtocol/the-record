# Trump conditionally proposes $5,000 payments to adult citizens if Republicans retain Congress

**Entry ID:** NAT-2026-09-09-005
**Date:** September 9, 2026
**Checked:** 2026-09-10 12:02 AM EDT
**Evidence state:** Reuters and Associated Press independently reported and directly quoted the speech; proposal announced, authorization, funding, eligibility and implementation pending
**Review state:** current-standard-reviewed

The campaign pledge would likely exceed $1 trillion and require legislation; eligibility, funding and implementation remain unsettled.

## THE FACTS

- At a September 9 Republican convention in Dallas, Trump said he would issue a $5,000 'Trump Dividend' to every adult U.S. citizen if Republicans retained both the House and Senate in the November election. He said the money would have to be spent in the United States.
- Trump attributed the proposal to economic strength but gave no funding mechanism, eligibility process, payment date or legislative text. The statement is a conditional campaign proposal, not an enacted benefit, appropriation, executive order or payment authorization.
- Associated Press reported that the proposal would likely cost more than $1 trillion and require congressional approval. It placed that estimate beside a roughly $1.8 trillion annual deficit; those figures are estimates and context, not an enacted fiscal effect.
- Vice President JD Vance subsequently suggested wealthy people might be excluded and tariff revenue might fund the payments, while Trump's statement said every adult citizen. AP reported that tariff receipts were far below the estimated cost, and the White House supplied no clarifying plan by cutoff.

## SIGNIFICANCE

A conditional transfer exceeding $1 trillion would be a major fiscal and electoral proposal, with potential effects on the deficit, inflation and household spending if Congress enacted it. The absence of legislative text and inconsistent eligibility descriptions make its present status a pledge rather than operative policy.

## GOALPOST / RESPONSE

Trump presents the payment as a dividend from U.S. economic strength, while Vance suggested narrower eligibility and tariff funding. The tests are a submitted bill or budget request, a reconciled eligible population, an identified funding source, congressional passage, administrative rules, actual payments and measured fiscal and price effects.

## MAYBE / THEREFORE

Maybe a broadly distributed payment could return federal revenue to households and stimulate domestic demand, or an unfunded transfer of this scale could deepen deficits and inflation. Therefore the record establishes Trump's explicit, election-conditioned proposal and AP's cost and legal context—not available checks, secured votes, sufficient tariff revenue or an implemented program.


## SOURCES

- [Reuters — Trump promises $5,000 payment if Republicans retain Congress](https://www.reuters.com/world/us/trump-promises-5000-payout-us-adults-if-republicans-win-election-2026-09-10/) — independent reporting directly quoting Trump's conditional campaign proposal and noting that implementation details were unavailable
- [Associated Press — Trump Dividend pledge would require Congress and exceed $1 trillion](https://apnews.com/article/cc80644e3168acd31c892129fb849436) — independent reporting on Trump's conditional proposal, its estimated scale, congressional requirement and the administration's unsettled eligibility and funding descriptions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
