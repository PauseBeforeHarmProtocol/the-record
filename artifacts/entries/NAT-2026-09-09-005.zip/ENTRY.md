# Trump repeats election-conditioned $5,000 payment pledge without funding or authority

**Entry ID:** NAT-2026-09-09-005
**Date:** September 9–11, 2026
**Checked:** 2026-09-11 5:58 PM EDT
**Evidence state:** direct Trump post plus Reuters and AP legal, fiscal and historical reporting; pledge repeated and election-conditioned, authority, appropriation, implementation and criminal liability unresolved
**Review state:** current-standard-reviewed

Trump said the payment 'will happen' and ended with 'VOTE REPUBLICAN,' while Congress has enacted no appropriation and net customs receipts remain far below the proposal's roughly $1.2 trillion cost.

## THE FACTS

- At a September 9 Republican convention in Dallas, Trump said he would issue a $5,000 'Trump Dividend' to every adult U.S. citizen if Republicans retained both the House and Senate in the November election. He said the money would have to be spent in the United States.
- On September 11, Trump repeated on Truth Social that the dividend 'will happen,' invoked a previously funded $1,776 military payment as precedent and ended the post with 'VOTE REPUBLICAN.' The post is primary evidence that Trump made the statement; it is not evidence that revenue, authority or payments exist.
- Trump told CBS Texas that he did not believe congressional approval would be required but identified no legal authority. Congress holds the constitutional spending power, and no bill, appropriation, eligibility rule, funding mechanism, payment date or implementing order had been produced by cutoff.
- Reuters estimated roughly 240 million adults and a total cost near $1.2 trillion. Treasury's August statement reported $167.308 billion in net customs receipts for the fiscal year through August—material revenue but far below that estimate and already part of general federal receipts.
- Associated Press reported that earlier Trump proposals for a tariff dividend, a DOGE rebate and a health-savings payment had not produced the promised checks. The $1,776 military payment Trump cited used money Congress had already approved rather than unilateral new presidential spending.
- Federal election-bribery statutes prohibit paying or offering expenditures to induce an individual to vote or vote a particular way. Reuters reported that election-law specialists generally distinguish universally available policy promises from payments contingent on an individual's vote; the proposed checks were described for adult citizens regardless of how or whether each person votes. No court or prosecutor had found this statement criminal by cutoff.

## SIGNIFICANCE

An explicit cash-payment pledge paired with a partisan vote request creates a serious appearance of using prospective public benefits as electoral leverage. Legally and factually, however, the record must distinguish that concern from a payment conditioned on an identifiable person's vote, and it must distinguish a campaign promise from appropriated public spending.

## GOALPOST / RESPONSE

Trump presents the payment as a dividend from national economic success and says congressional approval is unnecessary; supporters may also characterize it as an ordinary universal policy promise. The tests are a cited legal authority, submitted bill or budget request, defined eligibility, credible funding, congressional action, administrative rules, actual payments, judicial or enforcement findings and measured fiscal and price effects.

## MAYBE / THEREFORE

Maybe the promise becomes a lawful universal rebate through Congress, or it may remain another unfunded campaign pledge whose electoral language never produces payments. The vote request may be politically coercive in effect without satisfying criminal statutes written around payment for an individual's voting conduct. Therefore the record establishes an explicit election-conditioned promise, renewed with 'VOTE REPUBLICAN,' and a large funding gap—not available checks, unilateral spending authority, secured votes or a proven election-bribery offense.


## SOURCES

- [Reuters — Trump promises $5,000 payment if Republicans retain Congress](https://www.reuters.com/world/us/trump-promises-5000-payout-us-adults-if-republicans-win-election-2026-09-10/) — independent reporting directly quoting Trump's conditional campaign proposal and noting that implementation details were unavailable
- [Associated Press — Trump Dividend pledge would require Congress and exceed $1 trillion](https://apnews.com/article/cc80644e3168acd31c892129fb849436) — independent reporting on Trump's conditional proposal, its estimated scale, congressional requirement and the administration's unsettled eligibility and funding descriptions
- [Donald Trump Truth Social post — $5,000 dividend and vote request](https://truthsocial.com/@realDonaldTrump/117253978301857789) — primary presidential social-media statement
- [Reuters — legal and fiscal analysis of Trump's $5,000 proposal](https://www.reuters.com/legal/government/is-trumps-5000-dividend-legal-how-would-it-work-2026-09-10/) — independent legal and fiscal analysis
- [Associated Press — Trump repeats $5,000 dividend pledge without funding plan](https://apnews.com/article/trump-dividend-5000-payment-midterms-ab4111f78473e003a8146750b1971f9b) — independent campaign and fiscal reporting
- [Treasury — Monthly Treasury Statement, August 2026](https://fiscaldata.treasury.gov/static-data/published-reports/mts/MonthlyTreasuryStatement_202608.pdf) — primary fiscal statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
