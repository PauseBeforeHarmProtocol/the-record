# ATF requires annual local-fire notices for explosives storage

**Entry ID:** NAT-2026-09-25-003
**Date:** September 25, 2026
**Checked:** 2026-09-25 11:59 AM EDT
**Evidence state:** primary Federal Register final rule; published September 25 and effective October 26, 2026, with agency burden estimates and safety rationale not yet measured
**Review state:** current-standard-reviewed

Beginning October 26, covered explosives licensees and permittees must renew storage-facility notices annually and report when storage ends.

## THE FACTS

- ATF published a final rule effective October 26 requiring people already obligated to notify a local fire authority when they begin storing explosive materials to renew that notice every 12 months and notify the authority when storage ceases.
- The rule requires covered licensees and permittees to retain copies of the notices for five years. It does not expand which explosives, storage facilities or people are otherwise regulated under the existing notification requirement.
- ATF estimates about 9,100 individuals or entities are affected and assumes five minutes to prepare each annual notice. The agency says current information will help first responders identify explosive-storage hazards; the rule does not measure response outcomes, and local-authority handling costs were not quantified.

## SIGNIFICANCE

The rule creates a recurring federal compliance duty intended to keep local first responders' hazard information current instead of relying on a one-time notice that may become stale.

## GOALPOST / RESPONSE

ATF says annual and cessation notices improve firefighter and community safety with limited burden. Compliance rates, accuracy of local records, inspection findings, emergency use and actual preparation and local-processing costs are the tests.

## MAYBE / THEREFORE

Maybe recurring notices will correct stale facility information before an emergency, or duplicative paperwork may add cost without changing response decisions. Therefore the rule establishes a new annual duty effective October 26—not a measured safety improvement.


## SOURCES

- [Annual Notices on Explosive Materials Storage Facilities to Local Fire Authority](https://www.govinfo.gov/content/pkg/FR-2026-09-25/pdf/2026-19694.pdf) — primary final rule; 91 FR 61073; effective October 26, 2026

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
