# Trump signs Russia and Iran sanctions legislation

**Entry ID:** NAT-2026-09-16-004
**Date:** September 16–18, 2026
**Checked:** 2026-09-18 6:32 PM EDT
**Evidence state:** primary congressional procedure record plus independent reports of the final votes and presidential signature; enacted, target-level implementation and outcomes unresolved
**Review state:** current-standard-reviewed

H.R. 5334 became law after bipartisan votes; target-level sanctions, tariff orders and collected duties remain separate implementation steps.

## THE FACTS

- Reuters reported a 262–159 House vote on September 16 for sanctions and tariff legislation aimed at increasing pressure on Russia over its invasion of Ukraine.
- The Rules Committee identifies the measure as the Senate amendments to H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, and the floor motion as concurrence in those amendments. Submitted amendments listed on that page are not treated as adopted provisions.
- The House passed the Senate-amended measure 262–159 after an 86–11 Senate vote.
- Associated Press reported that Trump signed H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, on September 18. The law authorizes sanctions against covered Russian officials, financial institutions and shadow-fleet vessels; directs tariffs of up to 100% against the five largest importers of Russian oil and gas subject to statutory exceptions and executive administration; and extends specified Iran sanctions for five years.
- The signature establishes enactment, not that every authorized target was designated, a final tariff schedule was issued, duties were collected or Russian conduct changed by cutoff.

## SIGNIFICANCE

Enactment creates a new statutory sanctions and secondary-tariff framework. Its reach will depend on target designations, importer calculations, exceptions, waivers and implementation notices rather than signature alone.

## GOALPOST / RESPONSE

Trump and congressional supporters present the law as leverage to pressure Russia and countries buying its energy. Opponents warned about broad secondary tariffs and executive discretion. Published law text, agency designations, tariff proclamations, waiver decisions, customs collections, energy flows and Russian conduct are the tests.

## MAYBE / THEREFORE

Maybe the enacted framework materially increases bargaining leverage, or exceptions, waivers and implementation choices may limit its effect while tariffs impose costs elsewhere. Therefore Trump signed the bill into law—not that every sanction or tariff was already implemented or that the law had changed Russian conduct by cutoff.


## SOURCES

- [Reuters — House passes sanctions and tariff bill, 262–159](https://www.reuters.com/world/us-house-passes-sanctions-tariff-bill-raise-economic-pressure-russia-2026-09-16/) — independent final floor-vote report
- [House Rules Committee — Senate amendment to H.R. 5334](https://rules.house.gov/bill/119/hr-5334) — primary congressional bill text and floor-procedure record
- [Associated Press — Trump signs Russia and Iran sanctions law](https://apnews.com/article/donald-trump-russia-sanctions-ukraine-lindsey-graham-d1715ad5e8feccba76bfae51c5f28c45) — independent reporting of presidential signature

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
