# Trump signs, then broadly waives, Russia and Iran sanctions legislation

**Entry ID:** NAT-2026-09-16-004
**Date:** September 16–October 16, 2026
**Checked:** 2026-10-16 11:59 PM EDT
**Evidence state:** primary executive order plus contemporaneous Reuters reporting; broad waiver implemented, congressional certification referenced but not inspected, later activation and outcomes unresolved
**Review state:** current-standard-reviewed

An October 16 order listed steep Russia-related duties but immediately waived them and most statutory sanctions until further presidential or delegated action.

## THE FACTS

- Reuters reported a 262–159 House vote on September 16 for sanctions and tariff legislation aimed at increasing pressure on Russia over its invasion of Ukraine.
- The Rules Committee identifies the measure as the Senate amendments to H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, and the floor motion as concurrence in those amendments. Submitted amendments listed on that page are not treated as adopted provisions.
- The House passed the Senate-amended measure 262–159 after an 86–11 Senate vote.
- Associated Press reported that Trump signed H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, on September 18. The law authorizes sanctions against covered Russian officials, financial institutions and shadow-fleet vessels; directs tariffs of up to 100% against the five largest importers of Russian oil and gas subject to statutory exceptions and executive administration; and extends specified Iran sanctions for five years.
- The signature establishes enactment, not that every authorized target was designated, a final tariff schedule was issued, duties were collected or Russian conduct changed by cutoff.
- On October 16, Trump issued an executive order listing a 500% duty on Russian goods and 100% duties tied to the largest purchasers of Russian oil and gas and leading sanctions-evasion facilitators, while assigning monitoring and recommendation duties to USTR and other agencies.
- The same order immediately waived every duty provided by sections 112 and 113 of the Graham Act and the order, along with the sanctions and restrictions identified in sections 102(a), 102(d), 102(e), 103 through 111 and 117. The waivers remain until the president or designated officials determine that further action is appropriate.
- Reuters independently reported the waiver before the measures took effect and noted that the law permits a presidential national-interest waiver after notice to Congress. The order says that certification and an explanatory report were submitted to Congress; the archive did not inspect those submissions.
- The order leaves pre-existing Russia emergency sanctions in place. It therefore changes implementation of the September law without erasing separately imposed sanctions or proving that the listed tariff rates were ever collected.

## SIGNIFICANCE

The order uses the statute's waiver authority to postpone its principal new Russia-related sanctions and duties before collection, converting an enacted pressure framework into a monitored but largely dormant one while preserving executive discretion to reactivate it.

## GOALPOST / RESPONSE

The administration says the waiver is in the national interest and preserves flexibility while agencies monitor Russian energy trade and sanctions evasion. Supporters of tougher pressure argue the waiver undercuts the law. Congressional certification, later waiver termination, target designations, customs notices and collections, energy-price effects and Russian conduct are the tests.

## MAYBE / THEREFORE

Maybe the waiver avoids near-term energy and consumer-price costs while retaining leverage, or it may reduce pressure on Russia and major oil buyers. Therefore the order listed statutory tariff rates and delegated monitoring but waived the new duties and most sanctions before they took effect; it did not collect those tariffs or terminate pre-existing Russia sanctions.


## SOURCES

- [Reuters — House passes sanctions and tariff bill, 262–159](https://www.reuters.com/world/us-house-passes-sanctions-tariff-bill-raise-economic-pressure-russia-2026-09-16/) — independent final floor-vote report
- [House Rules Committee — Senate amendment to H.R. 5334](https://rules.house.gov/bill/119/hr-5334) — primary congressional bill text and floor-procedure record
- [Associated Press — Trump signs Russia and Iran sanctions law](https://apnews.com/article/donald-trump-russia-sanctions-ukraine-lindsey-graham-d1715ad5e8feccba76bfae51c5f28c45) — independent reporting of presidential signature
- [White House — executive order implementing and waiving Graham Act sanctions and duties](https://www.whitehouse.gov/presidential-actions/2026/10/implementing-the-lindsey-o-graham-sanctioning-russia-and-iran-act-of-2026/) — primary executive order
- [Reuters — Trump waives Graham Act Russia sanctions and tariffs before effect](https://www.reuters.com/world/europe/trump-waives-many-russia-related-sanctions-tariffs-before-they-were-take-effect-2026-10-17/) — independent reporting on executive-order implementation

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
