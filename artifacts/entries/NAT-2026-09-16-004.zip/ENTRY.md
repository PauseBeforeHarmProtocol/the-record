# House passes Russia and Iran sanctions legislation 262–159

**Entry ID:** NAT-2026-09-16-004
**Date:** September 16, 2026
**Checked:** 2026-09-17 12:01 PM EDT
**Evidence state:** primary congressional procedure record plus independent final-vote report; House-passed, enactment unverified
**Review state:** current-standard-reviewed

A completed House vote advances H.R. 5334; this record does not establish enactment or implemented tariffs.

## THE FACTS

- Reuters reported a 262–159 House vote on September 16 for sanctions and tariff legislation aimed at increasing pressure on Russia over its invasion of Ukraine.
- The Rules Committee identifies the measure as the Senate amendments to H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, and the floor motion as concurrence in those amendments. Submitted amendments listed on that page are not treated as adopted provisions.
- The inspected evidence establishes House passage. Presidential signature, a final implemented tariff schedule and target-level sanctions under the legislation were not verified by cutoff.

## SIGNIFICANCE

A recorded legislative decision replaces the previously pending-vote lead. Congressional passage and executive implementation remain distinct stages.

## GOALPOST / RESPONSE

Supporters present sanctions as pressure on Russia. Committee materials document objections to broad secondary tariffs and waiver discretion. A specific administration response to the final vote was not verified; enrolled text, presidential action and implementation notices are the next tests.

## MAYBE / THEREFORE

Maybe the legislation increases bargaining leverage, or later waivers and implementation limit its effects. Therefore this entry records the House vote, not tariffs already collected or proven changes in Russian conduct.


## SOURCES

- [Reuters — House passes sanctions and tariff bill, 262–159](https://www.reuters.com/world/us-house-passes-sanctions-tariff-bill-raise-economic-pressure-russia-2026-09-16/) — independent final floor-vote report
- [House Rules Committee — Senate amendment to H.R. 5334](https://rules.house.gov/bill/119/hr-5334) — primary congressional bill text and floor-procedure record

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
