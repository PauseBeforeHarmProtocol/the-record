# Trump signs, then broadly waives, Russia and Iran sanctions legislation

**Entry ID:** NAT-2026-09-16-004
**Date:** September 16–October 18, 2026
**Checked:** 2026-10-18 5:58 PM EDT
**Evidence state:** primary executive order and presidential statement plus Reuters and Associated Press reporting; waiver implemented, review and negotiation rationale announced, later activation, diplomatic progress and market effects unresolved
**Review state:** current-standard-reviewed

After broadly waiving the law's new duties and sanctions, the administration announced an up-to-60-day economic review and Trump said he was delaying further action to preserve negotiations.

## THE FACTS

- Reuters reported a 262–159 House vote on September 16 for sanctions and tariff legislation aimed at increasing pressure on Russia over its invasion of Ukraine.
- The Rules Committee identifies the measure as the Senate amendments to H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, and the floor motion as concurrence in those amendments. Submitted amendments listed on that page are not treated as adopted provisions.
- The House passed the Senate-amended measure 262–159 after an 86–11 Senate vote.
- Associated Press reported that Trump signed H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, on September 18. The law authorizes sanctions against covered Russian officials, financial institutions and shadow-fleet vessels; directs tariffs of up to 100% against the five largest importers of Russian oil and gas subject to statutory exceptions and executive administration; and extends specified Iran sanctions for five years.
- The signature establishes enactment, not that every authorized target was designated, a final tariff schedule was issued, duties were collected or Russian conduct changed by cutoff.
- On October 16, Trump issued an executive order listing a 500% duty on Russian goods and 100% duties tied to the largest purchasers of Russian oil and gas and leading sanctions-evasion facilitators, while assigning monitoring and recommendation duties to USTR and other agencies.
- The same order immediately waived every duty provided by sections 112 and 113 of the Graham Act and the order, along with the sanctions and restrictions identified in sections 102(a), 102(d), 102(e), 103 through 111 and 117. The waivers remain until the president or designated officials determine that further action is appropriate.
- Reuters independently reported the waiver before the measures took effect and noted that the law permits a presidential national-interest waiver after notice to Congress. The order says that certification and an explanatory report were submitted to Congress; the archive did not inspect those submissions.
- The order leaves pre-existing Russia emergency sanctions in place. It therefore changes implementation of the September law without erasing separately imposed sanctions or proving that the listed tariff rates were ever collected.
- On October 17, Secretary of State Marco Rubio said Trump would use up to 60 days to assess what the waived Russia-related sanctions and tariffs could mean for the global and U.S. economies. Reuters reported the statement; it is an announced review period, not a tariff activation or sanctions designation.
- Trump said a final decision had not yet been announced. The October 16 executive order contains no 60-day deadline, and the public reporting did not establish that the review legally binds the president or requires action when the period ends.
- At 4:36 PM EDT on October 18, Trump said on Truth Social that he was withholding further Russia action to avoid driving Moscow from negotiations. He cited unspecified current hostage negotiations and Russia's limited assistance to Iran, and blamed Ukrainian refinery attacks for pressure on global diesel supplies. The post is primary evidence of Trump's explanation, not independent verification that negotiations were progressing, that any hostage terms existed, that Russia was limiting assistance to Iran or that the strikes caused the claimed market effect.
- Trump referred to signing 'that document' even though he had already signed the Graham Act and issued the waiver order. The post did not identify the document, so the archive does not recast the phrase as a new legal instrument or completed decision.
- Associated Press independently reported Trump's statement while documenting Ukrainian drone attacks on Russian oil infrastructure and Russian attacks on Ukrainian energy infrastructure. That reporting supplies conflict context but does not establish the causal or diplomatic claims in the post.

## SIGNIFICANCE

The October 16 order postponed the Graham Act's principal new Russia-related sanctions and duties before collection. Rubio's October 17 statement supplied a review horizon and economic rationale; Trump's October 18 post added negotiation, Iran and diesel-market rationales. Neither statement changed the order, created a binding 60-day deadline or established progress toward an agreement.

## GOALPOST / RESPONSE

The administration says the pause permits an economic review, preserves negotiations, limits incentives for Russia to assist Iran and protects diesel availability. The tests are an identified agreement or hostage process, a disclosed review result, congressional notice, waiver termination or extension, target designations, customs instructions and collections, measurable price effects and Russian conduct; explanations are not implementation or proof of outcomes.

## MAYBE / THEREFORE

Maybe the pause is deliberate leverage intended to avoid energy shocks and keep several negotiations open, or it may reward Russia without verifiable concessions and leave the statutory pressure unused. Therefore the archive records an implemented waiver and announced explanations—not proof of peace progress, a newly signed instrument, reactivated tariffs or a demonstrated causal effect on diesel markets.


## SOURCES

- [Reuters — House passes sanctions and tariff bill, 262–159](https://www.reuters.com/world/us-house-passes-sanctions-tariff-bill-raise-economic-pressure-russia-2026-09-16/) — independent final floor-vote report
- [House Rules Committee — Senate amendment to H.R. 5334](https://rules.house.gov/bill/119/hr-5334) — primary congressional bill text and floor-procedure record
- [Associated Press — Trump signs Russia and Iran sanctions law](https://apnews.com/article/donald-trump-russia-sanctions-ukraine-lindsey-graham-d1715ad5e8feccba76bfae51c5f28c45) — independent reporting of presidential signature
- [White House — executive order implementing and waiving Graham Act sanctions and duties](https://www.whitehouse.gov/presidential-actions/2026/10/implementing-the-lindsey-o-graham-sanctioning-russia-and-iran-act-of-2026/) — primary executive order
- [Reuters — Trump waives Graham Act Russia sanctions and tariffs before effect](https://www.reuters.com/world/europe/trump-waives-many-russia-related-sanctions-tariffs-before-they-were-take-effect-2026-10-17/) — independent reporting on executive-order implementation
- [Reuters — Rubio says Trump will take up to 60 days to weigh Russia sanctions](https://www.reuters.com/world/us/rubio-says-trump-take-up-60-days-weigh-russia-sanctions-2026-10-18/) — independent reporting on announced sanctions-waiver review
- [Donald Trump Truth Social post — explanation for delaying further Russia sanctions action](https://truthsocial.com/@realDonaldTrump/117463828588421761) — primary presidential statement establishing the explanation, not independent verification of the claims inside it
- [Associated Press — Ukraine launches more than 1,000 drones as Trump defends sanctions delay](https://apnews.com/article/f813d3725b8b5f23958a68a95729fd0d) — independent reporting on the presidential statement, sanctions posture and strike context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
