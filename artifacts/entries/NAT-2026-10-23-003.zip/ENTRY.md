# State Department reduces staffing at four Middle East embassies

**Entry ID:** NAT-2026-10-23-003
**Date:** October 23, 2026
**Checked:** 2026-10-24 12:02 AM EDT
**Evidence state:** Associated Press reporting on the announced drawdowns and obtained memo, independently corroborated by Axios with the displayed unclassified memo; staffing reductions implemented, threat claims remain intelligence assessments
**Review state:** current-standard-reviewed

Jordan, Lebanon, Qatar and UAE posts remain open under restricted operations; the intelligence rationale is a government assessment, not independently verified fact.

## THE FACTS

- The State Department announced staffing reductions at U.S. embassies in Jordan, Lebanon, Qatar and the United Arab Emirates. The posts were already under restricted-operations status and remain open; unlike the Saudi Arabia departure order, personnel at these four posts were not compelled to leave.
- Associated Press reported that State publicly cited increased threats from Yemen's Iran-backed Houthi rebels. AP and Axios separately obtained an October 23 unclassified memo in which Director of National Intelligence Jay Clayton told Secretary of State Marco Rubio that Iran had substantially increased efforts to target U.S. personnel and that lethal plots had reached advanced stages.
- The memo and officials' descriptions establish the U.S. government's intelligence assessment and operational rationale, not independent verification of the alleged plots, targets or timing. AP said three U.S. officials confirmed the memo and linked the Iranian and Houthi threats to the staffing changes; Axios independently displayed the one-page memo.
- U.S. officials denied that the drawdowns signaled planned U.S. or Israeli strikes on Iran. The inspected record does not establish an embassy closure, evacuation order for these four countries, attack, casualty or later effectiveness of the staffing reduction.

## SIGNIFICANCE

Reducing diplomatic staffing across four countries is an implemented regional security measure that limits U.S. government presence while preserving embassy operations. The action is consequential even though the underlying threat intelligence cannot be independently tested from the public memo.

## GOALPOST / RESPONSE

The administration says Houthi attacks and Iranian plots require a smaller essential-staff footprint while keeping embassies open. The tests are formal travel and departure notices, staffing and service changes, any declassification or corroborated plot evidence, attacks or disruptions, later restoration of operations and congressional oversight.

## MAYBE / THEREFORE

Maybe the reductions prudently lower exposure to credible threats, or they may constrain diplomacy and consular services on the basis of intelligence the public cannot verify. Therefore the evidence establishes implemented staffing reductions and a documented U.S. intelligence warning—not embassy closures, proven Iranian operational control, an imminent attack or a decision to launch new strikes.


## SOURCES

- [Associated Press — U.S. reduces staffing at four Middle East embassies](https://apnews.com/article/iran-war-houthis-embassies-staffing-rubio-9635852ea973064907ed0b7c0fca4799) — independent diplomatic reporting based on State Department action, an obtained DNI memo and three U.S. officials
- [Axios — DNI memo warns of advanced Iranian plots and embassy drawdowns](https://www.axios.com/2026/10/24/iran-war-us-embassies-evacuations-threat) — independent reporting with displayed October 23 unclassified DNI memo; intelligence assessment not independently adjudicated
- [Associated Press — October 23 live national updates](https://apnews.com/article/4b43d8df0f4d7666de64f272f7b81ae7) — independent live reporting on the nursing-home initiative, seafood package, embassy drawdown and presidential remarks

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
