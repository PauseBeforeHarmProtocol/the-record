# ICE arrests rise to nearly 51,000 while removals remain near 1,200 per day

**Entry ID:** NAT-2026-09-14-003
**Date:** September 14, 2026
**Checked:** 2026-09-14 11:58 AM EDT
**Evidence state:** Reuters analysis of preliminary U.S. government and records-request data with on-record administration response; arrest, removal and conviction-share measurements reported, causal decomposition and final totals unresolved
**Review state:** current-standard-reviewed

Reuters analysis of preliminary government data found record arrests without a comparable increase in deportations and a declining convicted-criminal share.

## THE FACTS

- Reuters analyzed preliminary U.S. government data showing that Immigration and Customs Enforcement arrests rose to nearly 51,000 in August, a record for the third consecutive month, while deportations remained mostly steady at an average of roughly 1,200 per day.
- The analysis found that May had about 19,000 fewer arrests than August but approximately the same average daily removals. Arrests and removals measure different stages and populations, so the comparison does not imply that every arrest should immediately result in deportation.
- Fewer than 25% of people arrested in July had criminal convictions, down from nearly 60% in December 2024. The data are preliminary and the categories do not determine the seriousness, recency or immigration relevance of each conviction or pending charge.
- The preliminary data do not by themselves identify why removals did not rise with arrests. Legal case status, available flights, receiving-country cooperation and custody processing are distinct constraints requiring separate measurement; the record does not assign the gap to a single cause.
- The White House disputed the report's framing and said the administration had removed dangerous offenders and that three million people had left the country; DHS says it has no arrest quotas and prioritizes the 'worst of the worst.' Reuters's analysis did not independently validate the broader three-million claim.

## SIGNIFICANCE

The arrest-removal gap is a concrete effectiveness measure for the administration's mass-deportation strategy. It indicates that record enforcement inputs did not produce a comparable short-term increase in completed removals, while the declining convicted-criminal share tests the administration's prioritization claims.

## GOALPOST / RESPONSE

The administration says it is removing dangerous offenders, denies quotas and cites both formal removals and voluntary departures. Final ICE and DHS datasets, case and custody outcomes, conviction categories, removal-order status, detention capacity, flight activity, receiving-country cooperation and independently auditable departure counts are the tests.

## MAYBE / THEREFORE

Maybe arrests will translate into later removals after legal and logistical processing, or rising detention of people without final orders may continue to widen the gap. Therefore the preliminary data establish record monthly arrests, mostly steady daily removals and a lower convicted-criminal share—not that every arrest was improper, that removal capacity alone caused the gap or that final annual outcomes are known.


## SOURCES

- [Reuters — ICE arrests rise without comparable increase in deportations](https://www.reuters.com/legal/government/ice-arrests-keep-soaring-heres-why-they-are-not-leading-more-deportations-2026-09-14/) — independent analysis of preliminary U.S. government enforcement data, records-request data and on-record administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
