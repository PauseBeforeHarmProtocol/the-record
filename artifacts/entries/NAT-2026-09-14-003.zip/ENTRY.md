# ICE reports record fiscal-year removals after monthly arrest surge

**Entry ID:** NAT-2026-09-14-003
**Date:** September 14–November 12, 2026
**Checked:** 2026-11-12 6:06 PM EST
**Evidence state:** Reuters analysis of preliminary government and records-request data, materially refreshed with Associated Press reporting of DHS fiscal-year totals and an on-record DHS response; annual aggregate reported, detailed official tables and causal decomposition unresolved
**Review state:** current-standard-reviewed

A newly reported fiscal-year total shows 483,200 removals—an agency record but below the White House’s one-million target—while missing detail limits prioritization claims.

## THE FACTS

- Reuters previously analyzed preliminary government data showing ICE arrests rose to nearly 51,000 in August while removals remained around 1,200 per day. Arrests and removals are different stages and populations, so the short-term gap did not establish a final fiscal-year result.
- Associated Press reported on November 12 that DHS said ICE deported 483,200 people in the fiscal year ending September 30: 9% above 442,640 in fiscal 2025 and 78% above 271,480 in fiscal 2024, which DHS called an agency record. The annual result was announced before this run’s research boundary and is added retrospectively as outcome evidence, not represented as a new post-boundary action.
- The reported 483,200 total remained below the administration’s one-million annual goal. A named Migration Policy Institute expert told AP the government produced the record with unprecedented resources and roughly doubled ICE staffing, while cautioning that historical comparisons are difficult because administrations count categories differently.
- AP reported that the sparse DHS release did not provide a detailed criminal-history breakdown. Citing data obtained by the Deportation Data Project, AP said roughly one quarter of people in ICE custody in July had criminal convictions and more than half had no criminal charges; those custody categories do not by themselves establish the legal posture or seriousness of every individual case.
- The new annual total resolves the earlier uncertainty about the fiscal-year removal count but does not isolate why throughput changed, how voluntary departures were counted, whether due-process constraints were met, or how many removals followed final orders.
- DHS spokesperson Tricia McLaughlin said the administration had unleashed ICE to target and remove people it described as public-safety and national-security threats. That is the administration’s stated justification; the limited release did not supply the detailed tables needed to test the prioritization claim.

## SIGNIFICANCE

The fiscal-year result materially updates the preliminary arrest-removal picture: removals reached an agency-reported record, but remained below the administration’s one-million goal and were achieved with extraordinary resources. The missing offense, legal-status and counting detail prevents the aggregate from independently proving criminal prioritization, legality or cost-effectiveness.

## GOALPOST / RESPONSE

The administration says expanded staffing and enforcement produced a record while targeting public-safety threats. The tests are auditable ICE and DHS tables with consistent definitions; convictions and charges by category; final-order and case outcomes; voluntary departures separated from formal removals; detention, flight and receiving-country constraints; expenditures; and independently reproducible comparisons across fiscal years.

## MAYBE / THEREFORE

Maybe the late-year increase shows that added staff and resources converted earlier arrests into completed removals, or different counting and case mixes may explain part of the jump. Therefore the evidence establishes an agency-reported record of 483,200 fiscal-year removals that missed the one-million goal—not that criminal prioritization, due process, cost-effectiveness or a single causal explanation has been proved.


## SOURCES

- [Reuters — ICE arrests rise without comparable increase in deportations](https://www.reuters.com/legal/government/ice-arrests-keep-soaring-heres-why-they-are-not-leading-more-deportations-2026-09-14/) — independent analysis of preliminary U.S. government enforcement data, records-request data and on-record administration response
- [ICE deported a record number of people last fiscal year, government says](https://apnews.com/article/ice-immigration-deportation-arrests-homeland-security-trump-2e8f9b619c009ddc183d1a80eb21629a) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
