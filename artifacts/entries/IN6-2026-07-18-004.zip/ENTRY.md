# IN‑6 general election is set: Shreve versus Cinde Wirth

**Entry ID:** IN6-2026-07-18-004
**Date:** May 6, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** local reporting on unofficial primary totals
**Review state:** current-standard-reviewed

Local reporting based on unofficial primary totals put Shreve at 53.1% and Wirth at 59.3% in their respective primaries.

## THE FACTS

- Local outlet WKKG reported that incumbent Republican Jefferson Shreve received 53.1% against Sarah Brown in the Republican primary, based on unofficial totals.
- The same report said Democrat Cinde Wirth won a four-candidate primary with 59.3%.
- The nominees are scheduled to meet in the November 3, 2026 general election.

## SIGNIFICANCE

The Record’s election coverage should compare candidates through sourced positions, votes, financing, access, and corrections—not horse-race rhetoric. Primary percentages should remain labeled unofficial until replaced by certified results.

## GOALPOST / RESPONSE

A safe-district rating is not a substitute for an accountability audit, and a close primary is not proof the general election will be competitive. Both claims require separate evidence.

## MAYBE / THEREFORE

Maybe the unofficial primary totals correctly identify the eventual nominees, but they are not certified and say little about general-election competitiveness. Therefore the matchup and percentages should be updated from certified results, while any competitiveness claim must be tested separately through sourced election evidence and the November result.


## SOURCES

- [WKKG — IN-6 primary results](https://wkkg.com/local-news/republican-incumbents-win-congressional-primaries/) — local reporting; results described as unofficial

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
