# White House formally requests $30.1 billion for aviation modernization

**Entry ID:** NAT-2026-09-28-008
**Date:** September 28–November 13, 2026
**Checked:** 2026-11-13 6:02 AM EST
**Evidence state:** official DOT endorsement and Senate bill text for the September proposal, plus Reuters reporting of the November Duffy–Vought request; formal request reported, underlying letter not publicly retrieved, enactment and implementation absent
**Review state:** current-standard-reviewed

The Duffy–Vought request advances the Modern Skies proposal into a formal administration funding ask, but Congress has not enacted or appropriated the additional money.

## THE FACTS

- Transportation Secretary Sean Duffy endorsed the introduced Modern Skies Act on September 28. That bill proposed roughly $30 billion for airport transitions, air-traffic-control technology, towers and airport improvements; introduction and executive endorsement did not enact the money.
- Reuters reported on November 13 that Duffy and Office of Management and Budget Director Russell Vought sent Congress a formal request for an additional $30.1 billion. The letter itself was not publicly retrieved by cutoff, so the new stage is recorded as a reported formal administration funding request rather than enacted or obligated spending.
- The request allocates $10.1 billion to air-traffic-control modernization, including $7.2 billion for automation platforms and controller workstations and $2 billion for cloud infrastructure; $2 billion for control towers; and $18 billion for airport projects, including $10 billion for terminals.
- Reuters reported that Congress approved $12.5 billion in 2025 for air-traffic-control upgrades and controller hiring. The new request is additional to that earlier funding and would require congressional action before the proposed amounts could be obligated.
- Duffy and airline groups argue that aging systems, outages and safety risks require accelerated modernization. No enacted bill, final account-level appropriation, project awards, obligations, construction schedule, audited spending or measured reliability improvement from the new request was located by cutoff.

## SIGNIFICANCE

The administration has moved an industry-backed legislative concept into a formal $30.1 billion request with revised airport allocations. That is a meaningful budget-policy stage, but it remains a proposal: congressional approval, execution capacity and measurable safety or reliability results are unresolved.

## GOALPOST / RESPONSE

Duffy, Vought and airline supporters say the package would accelerate modernization, improve safety and reduce disruption. The tests are public request text, congressional scoring and passage, account-level appropriations, obligations and project selections, schedules and cost controls, outage frequency, controller staffing and independently measured safety and capacity outcomes.

## MAYBE / THEREFORE

Maybe a concentrated additional appropriation will overcome fragmented modernization and airport-capacity gaps, or Congress may reject or reshape the request and execution risk may persist despite more funding. Therefore the record establishes a reported formal $30.1 billion administration request—not enacted appropriations, obligated funds, completed infrastructure or proven safety improvement.


## SOURCES

- [Transportation Secretary Duffy and Modern Skies Coalition support Modern Skies Act](https://www.transportation.gov/briefing-room/trumps-transportation-secretary-sean-p-duffy-modern-skies-coalition-applaud-senator) — agency release
- [Modern Skies Act legislative text (LAN26545)](https://www.schmitt.senate.gov/wp-content/uploads/2026/09/LAN26545.pdf) — introduced bill text
- [Duffy and airlines urge Congress to approve $30 billion aviation reform bill](https://www.reuters.com/business/media-telecom/duffy-airlines-urge-congress-quickly-approve-30-billion-aviation-reforms-2026-09-28/) — independent reporting
- [White House urges Congress to provide $30.1 billion for aviation reform](https://www.reuters.com/legal/government/white-house-urges-congress-provide-301-billion-aviation-reform-2026-11-13/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
