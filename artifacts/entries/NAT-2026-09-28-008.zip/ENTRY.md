# DOT backs proposed $30 billion Modern Skies aviation package

**Entry ID:** NAT-2026-09-28-008
**Date:** September 28, 2026
**Checked:** 2026-09-28 5:55 PM EDT
**Evidence state:** official DOT endorsement and Senate legislative text, with Reuters context; proposal introduced and supported, enactment, appropriation and implementation absent
**Review state:** current-standard-reviewed

The introduced bill would fund airport transitions, air-traffic-control technology, towers and terminal improvements; it has not been enacted or funded.

## THE FACTS

- Transportation Secretary Sean Duffy endorsed the introduced Modern Skies Act, a legislative proposal authorizing and appropriating $30 billion for specified aviation infrastructure and modernization if enacted.
- The draft allocates $10 billion to a transitional airport pilot program, approximately $10.1 billion to air-traffic-control improvements and $10 billion to control towers and airport improvements, subject to the bill's detailed terms and transfer authority.
- The air-traffic-control portion includes $300 million for consolidation, $7.2 billion for platform and workstation modernization, $2 billion for cloud and telecommunications infrastructure and $600 million for traffic-flow management. The airport portion includes $2 billion for towers, $3 billion for airport grants and $5 billion for terminal improvements.
- Introduction and executive-branch endorsement do not enact an appropriation, obligate funds, select projects or establish completed modernization. Congressional passage, appropriations availability, awards, schedules, audited spending and operating results remain pending.

## SIGNIFICANCE

The proposal would add a large, specifically allocated federal investment to an air-traffic-control modernization effort already supported by prior appropriations. Its present status is legislative advocacy and introduced text, not expenditure or implementation.

## GOALPOST / RESPONSE

DOT and industry supporters say the package would accelerate modernization, improve safety and avoid disruption. The strongest response is that capital inputs do not by themselves establish delivery, reliability or safety outcomes. Enactment, obligations, project selection, schedules, cost controls, outages and safety metrics are the tests.

## MAYBE / THEREFORE

Maybe a concentrated appropriation will overcome fragmented modernization and airport-capacity gaps, or execution risk may persist despite additional funding. Therefore the record preserves the proposal's exact allocations while making no claim that Congress approved, agencies obligated or recipients spent the money.


## SOURCES

- [Transportation Secretary Duffy and Modern Skies Coalition support Modern Skies Act](https://www.transportation.gov/briefing-room/trumps-transportation-secretary-sean-p-duffy-modern-skies-coalition-applaud-senator) — agency release
- [Modern Skies Act legislative text (LAN26545)](https://www.schmitt.senate.gov/wp-content/uploads/2026/09/LAN26545.pdf) — introduced bill text
- [Duffy and airlines urge Congress to approve $30 billion aviation reform bill](https://www.reuters.com/business/media-telecom/duffy-airlines-urge-congress-quickly-approve-30-billion-aviation-reforms-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
