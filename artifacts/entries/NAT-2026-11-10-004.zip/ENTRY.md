# DOJ adds two defendants and RAF Fairford plot to Iran-linked terrorism case

**Entry ID:** NAT-2026-11-10-004
**Date:** November 10, 2026
**Checked:** 2026-11-10 6:12 PM EST
**Evidence state:** signed superseding indictment, DOJ/SDNY announcement and Associated Press reporting; charges filed and unsealed, with defendant responses, evidence testing and adjudication unresolved
**Review state:** current-standard-reviewed

An eight-count superseding indictment alleges three men supported Iran-aligned organizations and coordinated attack plots; the charges are accusations, not findings of guilt.

## THE FACTS

- On November 10, prosecutors unsealed an eight-count superseding indictment in the Southern District of New York charging Mohammad Baqer Saad Dawood Al-Saadi, Mohsen Mohajeri and Mohammed Ali Al-Hassani with material-support, terrorism, bombing and financing offenses. Mohajeri and Al-Hassani are newly charged alongside Al-Saadi, who had been indicted in May.
- The indictment alleges the defendants worked in support of Kata'ib Hizballah and Iran's Islamic Revolutionary Guard Corps and were involved in nearly 20 attacks or attempted attacks in Europe and the United States. Those assertions are charging allegations and have not been adjudicated.
- Prosecutors allege Al-Hassani organized a September plot against RAF Fairford while U.S. aircraft and personnel were present, using associates, disguised vans, fuel and potential explosive materials; British authorities allegedly stopped the vehicles and arrested their occupants. DOJ says Al-Saadi passed coded messages from federal custody and Mohajeri helped coordinate the network.
- DOJ describes the case as a disruption of an alleged global terrorism conspiracy and says it will pursue threats to U.S. personnel and Jewish communities. Associated Press reported that Al-Saadi previously pleaded not guilty; the new defendants' responses were not located by cutoff. Every defendant is presumed innocent unless proved guilty beyond a reasonable doubt.

## SIGNIFICANCE

The superseding indictment expands an existing U.S. prosecution to two additional alleged operatives and a recent plot involving a British base used by U.S. forces. It is a material national-security investigation step, but its international allegations require testing through discovery, trial evidence and judicial findings.

## GOALPOST / RESPONSE

The administration says the charges disrupt an Iran-aligned network and protect U.S. service members and civilian targets. The tests are arraignments and custody, defense responses, admissible evidence connecting each defendant to each act, foreign-partner records, motions, verdicts and any independently verified account of how the Fairford plot was stopped.

## MAYBE / THEREFORE

Maybe the superseding case proves coordinated operational control and financing across the alleged attacks, or evidence and jurisdictional challenges may narrow or defeat some charges. Therefore the record establishes an unsealed federal charging instrument and DOJ allegations—not guilt, Iranian-state direction as an adjudicated fact, completed convictions or proof of every claimed attack.


## SOURCES

- [DOJ — three alleged Iran-backed operatives charged in superseding indictment](https://www.justice.gov/opa/pr/three-iran-backed-operatives-indicted-their-roles-nearly-20-terrorist-attacks-and) — primary prosecution announcement; allegations only
- [SDNY — signed superseding indictment in United States v. Al-Saadi et al.](https://www.justice.gov/usao-sdny/media/1471301/dl) — primary charging instrument; allegations only
- [AP via ITV — U.S. charges three men over alleged Iran-backed attack plots](https://www.itv.com/news/2026-11-10/us-charges-3-men-with-plotting-terror-attacks-including-planned-assault-on-airbase-in-britain) — independent reporting and defendant plea context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
