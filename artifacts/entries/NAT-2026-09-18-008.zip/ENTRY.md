# Denmark and Greenland acknowledge proposed U.S. security framework

**Entry ID:** NAT-2026-09-18-008
**Date:** September 18, 2026
**Checked:** 2026-09-19 6:01 PM EDT
**Evidence state:** Trump's retained statement plus Reuters reporting based on named Danish and Greenlandic leaders; framework acknowledged, final signing, public text, authorities, cost and implementation unresolved
**Review state:** current-standard-reviewed

Partner governments now acknowledge a framework for expanded U.S. military presence, but final terms remain unsigned and preserve sovereignty and self-determination.

## THE FACTS

- President Trump announced on Truth Social that the United States had entered an agreement with Denmark and Greenland giving the United States permanent control over security and what he called 'all other needs' in Greenland. The post establishes that he made the claim, not that all parties executed those terms.
- Trump described the claimed arrangement as having no cost and no end, giving the United States approval authority over adversary bases, military presence and sensitive investment, and allowing immediate development of a large U.S. military presence.
- Reuters reported on September 19 that U.S., Danish and Greenlandic officials described a framework intended to support a significant U.S. military presence and prevent adversary bases. Danish Foreign Minister Lars Løkke Rasmussen said a binding agreement was still expected to be signed the following week, so the framework had not yet reached a final signed stage by cutoff.
- Greenland Prime Minister Jens-Frederik Nielsen said the proposal recognizes Greenland's sovereignty, territorial integrity and right to self-determination. No public text established Trump's broader claim of permanent U.S. control over 'all other needs,' a sovereignty transfer, ownership, exclusive jurisdiction, appropriated cost or implemented expansion beyond existing defense rights.

## SIGNIFICANCE

Partner acknowledgement advances the event from a unilateral presidential claim to a proposed intergovernmental security framework. It could materially expand the U.S. Arctic military posture, but unsigned terms and explicit sovereignty protections leave Trump's broader description and the operational change unresolved.

## GOALPOST / RESPONSE

Trump presents the arrangement as a permanent, no-cost solution giving the United States broad approval authority. Denmark and Greenland describe a security framework that must respect sovereignty and self-determination. A signed public instrument, defined authorities, basing and construction plans, funding, environmental and self-government review, force deployment and observed effects are the tests.

## MAYBE / THEREFORE

Maybe the expected instrument will authorize a substantial new U.S. presence while fitting within Danish sovereignty and Greenlandic self-government, or final terms may narrow or delay the framework. Therefore partner governments now acknowledge a proposed security framework—not a signed treaty, sovereignty transfer, costless permanent-control arrangement or implemented military expansion.


## SOURCES

- [Donald Trump Truth Social post claiming Greenland security agreement](https://truthsocial.com/@realDonaldTrump/117294126158197822) — primary presidential statement
- [Associated Press — Trump claims Denmark and Greenland security agreement](https://apnews.com/article/4cf77cb4608b685a70410bd679479193) — independent reporting
- [Financial Times — Trump claims permanent U.S. Greenland security control](https://www.ft.com/content/2ecc74bd-2fba-4ca6-9f1c-f0a927ed983c) — independent reporting
- [Reuters — Greenland and Denmark acknowledge proposed U.S. framework while preserving sovereignty](https://www.reuters.com/world/europe/greenland-denmark-say-us-deal-will-not-cede-sovereignty-2026-09-19/) — independent reporting with named Danish and Greenlandic government statements

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
