# U.S., Denmark and Greenland sign Arctic security agreement

**Entry ID:** NAT-2026-09-18-008
**Date:** September 18–November 19, 2026
**Checked:** 2026-11-19 12:16 PM EST
**Evidence state:** presidential statement, signing coverage, primary Danish parliamentary approval notice, Greenland government page and Reuters reporting; both parliaments approved, with diplomatic notification and implementation still pending
**Review state:** current-standard-reviewed

Greenland and Denmark approved the signed defense agreement; Denmark must still send formal notice to the United States before it becomes legally binding, and base, funding and implementation details remain unresolved.

## THE FACTS

- President Trump announced on Truth Social that the United States had entered an agreement with Denmark and Greenland giving the United States permanent control over security and what he called 'all other needs' in Greenland. The post establishes that he made the claim, not that all parties executed those terms.
- Trump described the claimed arrangement as having no cost and no end, giving the United States approval authority over adversary bases, military presence and sensitive investment, and allowing immediate development of a large U.S. military presence.
- President Trump, Danish Prime Minister Mette Frederiksen and Greenland Prime Minister Jens-Frederik Nielsen signed the agreement on September 22 on the sidelines of the United Nations General Assembly. Associated Press reported the completed signing after the governments had provided few public details.
- Trump said the United States would immediately begin developing a large military presence at appropriate locations, including two major bases. The statement announces a development process; no published instrument, appropriation, contract, site approval, construction start or force deployment was independently verified by cutoff.
- Frederiksen said the agreement recognizes the sovereignty and territorial integrity of the Kingdom of Denmark and Greenland's right to self-determination. No public text established Trump's broader claim of permanent U.S. control over 'all other needs,' a sovereignty transfer, ownership, exclusive jurisdiction or a costless arrangement.
- Greenland's Inatsisartut approved the agreement on November 3, and Denmark's Parliament unanimously consented on November 19 after two readings. The Danish Parliament said the agreement amends and supplements the 1951 defense agreement and that both parliaments have now approved it.
- The Danish government may now formally notify the United States that domestic procedures are complete. The Danish Parliament and Reuters both state that this diplomatic notification completes ratification and makes the agreement legally binding; the inspected sources did not establish that the notification had already been delivered by cutoff.
- Reuters reported that the agreement permits work toward a Golden Dome missile-defense role and two new U.S. military bases while reaffirming Danish sovereignty and Greenlandic self-determination. Danish officials said site purposes and arrangements still require concrete planning; no inspected source established construction, appropriation or deployed forces.

## SIGNIFICANCE

The two parliamentary approvals materially advance the agreement from executive signature toward legal effect and authorize the final diplomatic notification. They do not themselves establish that notification occurred or that bases, forces, appropriations or construction were implemented.

## GOALPOST / RESPONSE

Trump presents the arrangement as permanent, costless and broadly controlling, while Denmark and Greenland describe a defense agreement preserving sovereignty and self-determination. The next tests are delivery of the diplomatic notification, publication of the instrument and implementing law, site and Golden Dome plans, appropriations, environmental and self-government review, force deployments and observed effects.

## MAYBE / THEREFORE

Maybe formal notification will promptly bring the agreement into force and lead to a substantial U.S. Arctic presence, or implementation may be narrowed by local law, funding, site review and political consent. Therefore both parliaments approved the signed agreement—this is not yet proof of completed notification, sovereignty transfer, base construction or deployed forces.


## SOURCES

- [Donald Trump Truth Social post claiming Greenland security agreement](https://truthsocial.com/@realDonaldTrump/117294126158197822) — primary presidential statement
- [Associated Press — Trump claims Denmark and Greenland security agreement](https://apnews.com/article/4cf77cb4608b685a70410bd679479193) — independent reporting
- [Financial Times — Trump claims permanent U.S. Greenland security control](https://www.ft.com/content/2ecc74bd-2fba-4ca6-9f1c-f0a927ed983c) — independent reporting
- [Reuters — Greenland and Denmark acknowledge proposed U.S. framework while preserving sovereignty](https://www.reuters.com/world/europe/greenland-denmark-say-us-deal-will-not-cede-sovereignty-2026-09-19/) — independent reporting with named Danish and Greenlandic government statements
- [Associated Press — U.S., Denmark and Greenland sign Arctic security agreement](https://apnews.com/article/trump-greenland-denmark-security-agreement-084ac2a82952c2dff403c48bd3564113) — independent post-signing reporting with named government leaders
- [The Danish Parliament Approves Agreement on Defence of Greenland](https://www.thedanishparliament.dk/en/news/2026/11/the-danish-parliament-approves-agreement-on-defence-of-greenland) — primary parliamentary notice recording Danish consent, Greenland's prior approval and the remaining diplomatic-notification step
- [Greenland government statement on the U.S.-Denmark-Greenland security agreement](https://naalakkersuisut.gl/Nyheder/2026/11/1911_usa_aftale?sc_lang=kl-GL) — primary Greenland government page concerning the approved defense and security agreement
- [Denmark ratifies Trump deal over Greenland, hoping to end conflict](https://www.reuters.com/world/denmark-expected-ratify-trump-deal-over-greenland-thursday-2026-11-19/) — independent reporting on the unanimous vote, entry-into-force step, planned bases and both governments' explanations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
