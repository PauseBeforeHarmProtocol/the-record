# U.S., Denmark and Greenland sign Arctic security agreement

**Entry ID:** NAT-2026-09-18-008
**Date:** September 18, 2026
**Checked:** 2026-09-22 12:02 PM EDT
**Evidence state:** retained presidential statement, earlier Reuters reporting and complete Associated Press post-signing report with named leaders; signing documented, public instrument, authorities, funding and implementation unresolved
**Review state:** current-standard-reviewed

The three governments signed an agreement for an expanded U.S. military presence while preserving Danish sovereignty and Greenlandic self-determination; the complete instrument, authorities, funding and implementation plans remain unpublished.

## THE FACTS

- President Trump announced on Truth Social that the United States had entered an agreement with Denmark and Greenland giving the United States permanent control over security and what he called 'all other needs' in Greenland. The post establishes that he made the claim, not that all parties executed those terms.
- Trump described the claimed arrangement as having no cost and no end, giving the United States approval authority over adversary bases, military presence and sensitive investment, and allowing immediate development of a large U.S. military presence.
- President Trump, Danish Prime Minister Mette Frederiksen and Greenland Prime Minister Jens-Frederik Nielsen signed the agreement on September 22 on the sidelines of the United Nations General Assembly. Associated Press reported the completed signing after the governments had provided few public details.
- Trump said the United States would immediately begin developing a large military presence at appropriate locations, including two major bases. The statement announces a development process; no published instrument, appropriation, contract, site approval, construction start or force deployment was independently verified by cutoff.
- Frederiksen said the agreement recognizes the sovereignty and territorial integrity of the Kingdom of Denmark and Greenland's right to self-determination. No public text established Trump's broader claim of permanent U.S. control over 'all other needs,' a sovereignty transfer, ownership, exclusive jurisdiction or a costless arrangement.

## SIGNIFICANCE

The signing advances the event from a proposed framework to an executed intergovernmental agreement and could materially expand the U.S. Arctic military posture. The explicit sovereignty protections and absence of published operative terms still leave Trump's broader description, legal authorities, cost and real-world expansion unresolved.

## GOALPOST / RESPONSE

Trump presents the agreement as permanent, costless and broadly controlling, and says two major bases will be developed. Denmark and Greenland present a security agreement that preserves sovereignty and self-determination. Publication of the instrument, defined authorities, site and construction approvals, appropriations, environmental and self-government review, force deployment and observed effects are the tests.

## MAYBE / THEREFORE

Maybe the signed agreement will support a substantial new U.S. presence while remaining within Danish sovereignty and Greenlandic self-government, or unpublished limits and later approvals may narrow or delay the announced expansion. Therefore the three governments signed an Arctic security agreement—not a sovereignty transfer, proof of costless permanent control, completed base development or implemented military expansion.


## SOURCES

- [Donald Trump Truth Social post claiming Greenland security agreement](https://truthsocial.com/@realDonaldTrump/117294126158197822) — primary presidential statement
- [Associated Press — Trump claims Denmark and Greenland security agreement](https://apnews.com/article/4cf77cb4608b685a70410bd679479193) — independent reporting
- [Financial Times — Trump claims permanent U.S. Greenland security control](https://www.ft.com/content/2ecc74bd-2fba-4ca6-9f1c-f0a927ed983c) — independent reporting
- [Reuters — Greenland and Denmark acknowledge proposed U.S. framework while preserving sovereignty](https://www.reuters.com/world/europe/greenland-denmark-say-us-deal-will-not-cede-sovereignty-2026-09-19/) — independent reporting with named Danish and Greenlandic government statements
- [Associated Press — U.S., Denmark and Greenland sign Arctic security agreement](https://apnews.com/article/trump-greenland-denmark-security-agreement-084ac2a82952c2dff403c48bd3564113) — independent post-signing reporting with named government leaders

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
