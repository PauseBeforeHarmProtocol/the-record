# Trump claims permanent Greenland security agreement

**Entry ID:** NAT-2026-09-18-008
**Date:** September 18, 2026
**Checked:** 2026-09-18 5:59 PM EDT
**Evidence state:** Trump's complete retained Truth Social text plus independent AP and Financial Times reporting; presidential announcement verified, partner confirmation and agreement text absent at cutoff
**Review state:** current-standard-reviewed

Denmark and Greenland had not confirmed the claimed no-cost, indefinite U.S. control arrangement, and no agreement text was public by cutoff.

## THE FACTS

- President Trump announced on Truth Social that the United States had entered an agreement with Denmark and Greenland giving the United States permanent control over security and what he called 'all other needs' in Greenland. The post establishes that he made the claim, not that all parties executed those terms.
- Trump described the claimed arrangement as having no cost and no end, giving the United States approval authority over adversary bases, military presence and sensitive investment, and allowing immediate development of a large U.S. military presence.
- Associated Press and the Financial Times reported that Denmark and Greenland had not confirmed the agreement by cutoff. No signed text, implementing instrument, basing plan, appropriation, construction contract, legal analysis or agreed definition of the claimed authorities was public.
- The United States already has defense rights in Greenland under longstanding arrangements, including operation of Pituffik Space Base. The announcement does not by itself establish a transfer of sovereignty, ownership, exclusive jurisdiction or implemented expansion beyond existing rights.

## SIGNIFICANCE

If confirmed on the terms Trump described, an indefinite security arrangement and veto over adversary activity would materially alter Arctic defense and U.S. relations with Denmark and Greenland. The missing text and lack of partner confirmation make the legal and operational change unresolved.

## GOALPOST / RESPONSE

Trump presents the claim as a no-cost, permanent solution to U.S. security concerns. Confirmation by Denmark and Greenland, signed terms, compatibility with Greenlandic self-government and Danish sovereignty, congressional funding, basing plans, construction and actual force deployment are the tests.

## MAYBE / THEREFORE

Maybe a negotiated framework exists but partner governments are delaying publication, or Trump's description may overstate preliminary or existing defense arrangements. Therefore the verified fact is the president's consequential announcement—not a confirmed treaty, sovereignty transfer, costless program or implemented military expansion.


## SOURCES

- [Donald Trump Truth Social post claiming Greenland security agreement](https://truthsocial.com/@realDonaldTrump/117294126158197822) — primary presidential statement
- [Associated Press — Trump claims Denmark and Greenland security agreement](https://apnews.com/article/4cf77cb4608b685a70410bd679479193) — independent reporting
- [Financial Times — Trump claims permanent U.S. Greenland security control](https://www.ft.com/content/2ecc74bd-2fba-4ca6-9f1c-f0a927ed983c) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
