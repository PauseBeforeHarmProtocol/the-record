# BLS reports 0.4% August consumer-price rise and 3.4% annual inflation

**Entry ID:** NAT-2026-09-11-006
**Date:** September 11, 2026
**Checked:** 2026-09-11 12:02 PM EDT
**Evidence state:** primary BLS statistical release and Reuters context inspected; price changes measured, causal attribution and future monetary-policy effects unresolved
**Review state:** current-standard-reviewed

Gasoline drove more than one-third of the monthly increase; the official indexes measure price change but do not assign it to one policy, conflict or political actor.

## THE FACTS

- The Bureau of Labor Statistics reported on September 11 that the Consumer Price Index for All Urban Consumers rose 0.4% on a seasonally adjusted basis in August after a 0.1% July increase. The all-items index was 3.4% higher than a year earlier, unchanged from July's annual rate.
- Gasoline rose 3.9% during August and accounted for more than one-third of the monthly all-items increase. Over 12 months, gasoline rose 27.4%, fuel oil 52.0% and the overall energy index 16.3%.
- Food rose 0.1% during August and 2.7% over 12 months; food at home was unchanged during the month and 2.2% higher annually. Shelter rose 0.3% during August.
- The index excluding food and energy rose 0.3% during August, its largest monthly rise since April, and 2.4% over 12 months. Reuters reported that financial markets subsequently priced a roughly 91% chance of a Federal Reserve rate increase the following week; that market estimate is not an enacted rate decision.

## SIGNIFICANCE

The release measures the household price environment immediately before the midterm election and after a stronger producer-price report. Large energy increases can affect budgets and monetary policy, but neither BLS nor the data isolate tariffs, war, supply constraints or administration policy as a single cause.

## GOALPOST / RESPONSE

Administration officials have argued for lower interest rates while Trump has linked trade policy to Fed action. The BLS series, future revisions, real earnings, category-level prices, household spending and the Federal Reserve's actual decision are the tests—not campaign attribution or market probabilities alone.

## MAYBE / THEREFORE

Maybe energy shocks fade while core inflation continues easing annually, or transport and fuel costs may broaden into other prices. Therefore August shows a measured 0.4% monthly CPI rise and 3.4% annual inflation—not proof of one cause, a forecast of every household's costs or a completed Federal Reserve response.


## SOURCES

- [BLS — Consumer Price Index, August 2026](https://www.bls.gov/news.release/cpi.nr0.htm) — primary statistical release
- [Reuters — August consumer inflation and market context](https://www.reuters.com/world/us/us-consumer-inflation-picks-up-august-2026-09-11/) — independent economic reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
