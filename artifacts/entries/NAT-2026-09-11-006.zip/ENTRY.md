# BLS reports 0.6% September consumer-price rise and 3.7% annual inflation

**Entry ID:** NAT-2026-09-11-006
**Date:** September 11, 2026
**Checked:** 2026-10-14 11:55 AM EDT
**Evidence state:** primary BLS August and September statistical releases plus Reuters context; price acceleration measured, causal attribution and future monetary-policy effects unresolved
**Review state:** current-standard-reviewed

Gasoline accounted for more than half of the monthly rise; core inflation also accelerated annually, while the official indexes do not assign one political cause.

## THE FACTS

- The Bureau of Labor Statistics reported on September 11 that the Consumer Price Index for All Urban Consumers rose 0.4% on a seasonally adjusted basis in August after a 0.1% July increase. The all-items index was 3.4% higher than a year earlier, unchanged from July's annual rate.
- Gasoline rose 3.9% during August and accounted for more than one-third of the monthly all-items increase. Over 12 months, gasoline rose 27.4%, fuel oil 52.0% and the overall energy index 16.3%.
- Food rose 0.1% during August and 2.7% over 12 months; food at home was unchanged during the month and 2.2% higher annually. Shelter rose 0.3% during August.
- The index excluding food and energy rose 0.3% during August, its largest monthly rise since April, and 2.4% over 12 months. Reuters reported that financial markets subsequently priced a roughly 91% chance of a Federal Reserve rate increase the following week; that market estimate is not an enacted rate decision.
- BLS reported on October 14 that the Consumer Price Index rose 0.6% on a seasonally adjusted basis in September after the 0.4% August increase. The all-items index was 3.7% higher than a year earlier, up from 3.4% in August.
- Gasoline rose 9.1% in September and accounted for more than half of the monthly all-items increase. The broader energy index rose 5.2% during the month and 20.4% over 12 months; food was unchanged during the month and food at home fell 0.1%.
- The index excluding food and energy rose 0.3% during September and 2.6% over 12 months, compared with 2.4% annual core inflation in August. Reuters reported market-implied odds of an October Federal Reserve rate increase moved to about 52% from 22%; that probability is not an enacted rate decision.

## SIGNIFICANCE

The September release measures faster household-price growth immediately before the midterm election and after the Federal Reserve's September rate increase. Energy dominated the monthly move, but core inflation also accelerated; neither BLS nor the indexes isolate war, tariffs, supply constraints or administration policy as a single cause.

## GOALPOST / RESPONSE

Administration officials have argued for lower prices and interest rates, while the Federal Reserve targets 2% inflation using a different index. Tests include later revisions, real earnings, category-level prices, household spending and the Fed's actual October decision—not political attribution or market probabilities alone.

## MAYBE / THEREFORE

Maybe the gasoline shock fades while grocery prices remain subdued, or fuel and transport costs may spread further into shelter and other services. Therefore September shows a measured 0.6% monthly CPI rise, 3.7% annual inflation and 2.6% core inflation—not proof of one cause, every household's experience or a completed Federal Reserve response.


## SOURCES

- [BLS — Consumer Price Index, August 2026](https://www.bls.gov/news.release/cpi.nr0.htm) — primary statistical release
- [Reuters — August consumer inflation and market context](https://www.reuters.com/world/us/us-consumer-inflation-picks-up-august-2026-09-11/) — independent economic reporting
- [BLS — Consumer Price Index, September 2026](https://www.bls.gov/news.release/archives/cpi_10142026.htm) — primary federal statistical release
- [Reuters — September inflation and Federal Reserve context](https://www.reuters.com/world/us/us-consumer-prices-accelerate-september-costlier-gasoline-core-cpi-firmer-2026-10-14/) — independent economic reporting and market context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
