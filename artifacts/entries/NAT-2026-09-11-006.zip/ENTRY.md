# BLS reports 0.4% October CPI rise with annual rate unavailable

**Entry ID:** NAT-2026-09-11-006
**Date:** September 11–November 10, 2026
**Checked:** 2026-11-10 12:07 PM EST
**Evidence state:** primary BLS August, September and October statistical releases plus Reuters context; monthly price changes measured, October annual comparison unavailable and causal attribution and future monetary-policy effects unresolved
**Review state:** current-standard-reviewed

Shelter, food and energy prices rose, core CPI increased 0.3%, and the 2025 shutdown left BLS without the October base needed for a year-over-year rate.

## THE FACTS

- The Bureau of Labor Statistics reported on September 11 that the Consumer Price Index for All Urban Consumers rose 0.4% on a seasonally adjusted basis in August after a 0.1% July increase. The all-items index was 3.4% higher than a year earlier, unchanged from July's annual rate.
- Gasoline rose 3.9% during August and accounted for more than one-third of the monthly all-items increase. Over 12 months, gasoline rose 27.4%, fuel oil 52.0% and the overall energy index 16.3%.
- Food rose 0.1% during August and 2.7% over 12 months; food at home was unchanged during the month and 2.2% higher annually. Shelter rose 0.3% during August.
- The index excluding food and energy rose 0.3% during August, its largest monthly rise since April, and 2.4% over 12 months. Reuters reported that financial markets subsequently priced a roughly 91% chance of a Federal Reserve rate increase the following week; that market estimate is not an enacted rate decision.
- BLS reported on October 14 that the Consumer Price Index rose 0.6% on a seasonally adjusted basis in September after the 0.4% August increase. The all-items index was 3.7% higher than a year earlier, up from 3.4% in August.
- Gasoline rose 9.1% in September and accounted for more than half of the monthly all-items increase. The broader energy index rose 5.2% during the month and 20.4% over 12 months; food was unchanged during the month and food at home fell 0.1%.
- The index excluding food and energy rose 0.3% during September and 2.6% over 12 months, compared with 2.4% annual core inflation in August. Reuters reported market-implied odds of an October Federal Reserve rate increase moved to about 52% from 22%; that probability is not an enacted rate decision.
- BLS reported on November 10 that the Consumer Price Index rose 0.4% on a seasonally adjusted basis in October after September's 0.6% increase. Shelter rose 0.3% and accounted for more than 30% of the monthly all-items increase; food rose 0.5%, energy rose 0.7% and gasoline rose 1.0%.
- The index excluding food and energy rose 0.3% in October, the same monthly increase as in September. Reuters reported the headline and core increases exceeded economists' median forecasts of 0.3% and 0.2%, respectively; forecasts and market reactions are context, not official inflation measures.
- BLS did not publish 12-month October indexes because the 2025 government shutdown prevented collection of October 2025 consumer-price data. The missing comparison means no official October year-over-year CPI rate was available; it does not mean annual inflation was zero or unchanged.
- Reuters reported financial markets priced roughly an 89% chance of a quarter-point Federal Reserve rate increase in December after the release. That probability is not an enacted monetary-policy decision, and neither BLS nor the CPI release assigns the monthly change to a single administration policy, war, tariff or supply factor.

## SIGNIFICANCE

The October release shows a third consecutive month of at least 0.4% headline CPI growth and continued 0.3% core growth, with increases across shelter, food and energy. The unavailable annual comparison is a material data limitation; monthly indexes still measure price change but do not establish one political cause or every household's experience.

## GOALPOST / RESPONSE

Administration officials have argued for lower prices and interest rates, while the Federal Reserve targets 2% inflation using a different index. Tests include November data, later revisions, real earnings, category-level prices and the Fed's actual December decision—not a reconstructed annual rate, political attribution or market probability alone.

## MAYBE / THEREFORE

Maybe the October monthly increase fades as energy costs ease, or persistent shelter, food and core increases may keep inflation pressure elevated. Therefore October shows measured 0.4% headline and 0.3% core CPI growth, with no official 12-month rate because the comparison base is missing—not zero annual inflation, proof of one cause or a completed Federal Reserve response.


## SOURCES

- [BLS — Consumer Price Index, August 2026](https://www.bls.gov/news.release/cpi.nr0.htm) — primary statistical release
- [Reuters — August consumer inflation and market context](https://www.reuters.com/world/us/us-consumer-inflation-picks-up-august-2026-09-11/) — independent economic reporting
- [BLS — Consumer Price Index, September 2026](https://www.bls.gov/news.release/archives/cpi_10142026.htm) — primary federal statistical release
- [Reuters — September inflation and Federal Reserve context](https://www.reuters.com/world/us/us-consumer-prices-accelerate-september-costlier-gasoline-core-cpi-firmer-2026-10-14/) — independent economic reporting and market context
- [BLS — Consumer Price Index, October 2026](https://www.bls.gov/news.release/archives/cpi_11102026.htm) — primary federal statistical release
- [Reuters — October inflation and Federal Reserve context](https://www.reuters.com/world/us/us-consumer-prices-rise-above-expectations-october-2026-11-10/) — independent economic reporting and market context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
