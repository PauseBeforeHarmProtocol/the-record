# Administration files emergency Supreme Court request to keep Venezuela TPS judgment stayed

**Entry ID:** NAT-2026-10-05-004
**Date:** October 5–November 18, 2026
**Checked:** 2026-11-18 6:08 PM EST
**Evidence state:** official Supreme Court docket and government application plus Associated Press reporting; emergency relief requested, no Supreme Court ruling located by cutoff
**Review state:** current-standard-reviewed

The Solicitor General asked for an immediate administrative stay and a stay pending appeal before the lower-court judgment was set to resume effect November 20; the application remains pending.

## THE FACTS

- In Mullin v. National TPS Alliance, No. 26-48, the Supreme Court on October 5 granted the government's certiorari petition, vacated the Ninth Circuit's January 28 judgment and remanded the case for further consideration in light of Mullin v. Doe, 609 U.S. 324 (2026).
- The vacated judgment had affirmed rulings against the Secretary of Homeland Security's vacatur and termination actions involving Venezuela and partial vacatur involving Haiti. The government's petition argued that the later Mullin v. Doe decision, including its reading of the TPS statute's judicial-review bar, required reconsideration.
- The National TPS Alliance and individual respondents did not oppose grant, vacatur and remand. Their filed response said Mullin v. Doe altered the premises of the decision below and agreed that reconsideration was appropriate.
- The Supreme Court issued no new merits opinion in docket 26-48 and did not itself resolve every remaining statutory or constitutional claim. The remand vacates the appellate judgment and returns the dispute to the Ninth Circuit; subsequent orders will determine the remaining claims and procedural consequences.
- The docket action did not itself create a new TPS designation or extension, and it should not be read as a finding that conditions in Venezuela or Haiti are safe. Earlier Supreme Court stays had already allowed termination actions to proceed while litigation continued, so the October 5 GVR is recorded as a litigation stage rather than a newly implemented removal program.
- On November 3, the Ninth Circuit withdrew its October 30 order denying an administrative stay and granted the government's request for a 14-day administrative stay. The published order states that the 14 days begin when the Supreme Court issues its judgment in the remanded case, expected November 6.
- The administrative stay continues the pause on the district court injunction for that limited period while the appellate court considers the government's motion for a stay pending appeal. It is an operative procedural order, not a final merits ruling on the remaining claims or a new TPS designation.
- The order does not itself decide every affected person's immigration status or work authorization. Concrete agency guidance, the stay-pending-appeal ruling and later remand proceedings remain necessary to determine downstream effects.
- On November 18, the Solicitor General filed emergency application No. 26A714 asking Justice Elena Kagan and the Supreme Court to administratively stay, and then stay pending appeal, the district-court judgment restoring Venezuela's 2023 TPS designation. The official docket showed the application pending at cutoff.
- The application says the earlier stay would end November 20 and asserts that renewed TPS effect could require release of as many as about 1,800 detained Venezuelan nationals, prevent near-term execution of approximately 332 final removal orders and require work authorization. Those figures and consequences are the government's representations in a pending filing, not independent measurements or a court finding.
- Associated Press independently reported the filing and the same asserted operational consequences. No order granting an administrative stay or ultimate stay was located by cutoff, so TPS restoration, detention releases and individual work-authorization effects should not be described as completed outcomes of the application itself.

## SIGNIFICANCE

The emergency application moves the remand dispute back to the Supreme Court immediately before the district-court judgment was scheduled to resume effect. It presents concrete asserted detention, removal and work-authorization consequences, but filing an application neither stays the judgment nor proves those estimates.

## GOALPOST / RESPONSE

The government argues Mullin v. Doe forecloses the district-court judgment and that short-term compliance would create severe disruption; respondents have not yet supplied a response on the inspected docket. The tests are an administrative-stay order, any requested response, the Court's ultimate stay decision, Ninth Circuit merits proceedings and concrete DHS guidance for affected people.

## MAYBE / THEREFORE

Maybe the Court will again stay the judgment and the asserted immediate operational effects will not occur, or it may deny relief and allow the lower-court judgment to resume while the appeal proceeds. Therefore the record establishes a pending emergency request and party-asserted consequences—not a granted stay, final TPS ruling, completed release or individualized status determination.


## SOURCES

- [Supreme Court docket 26-48 — Mullin v. National TPS Alliance](https://www.supremecourt.gov/docket/docketfiles/html/public/26-48.html) — primary official docket recording grant, vacatur and remand
- [Solicitor General — petition in Mullin v. National TPS Alliance](https://www.supremecourt.gov/DocketPDF/26/26-48/416072/20260709130950638_NTPSA_Petition_Final.pdf) — primary government litigation filing
- [National TPS Alliance — response to certiorari petition in docket 26-48](https://www.supremecourt.gov/DocketPDF/26/26-48/419629/20260820132915252_26-48_Brief.pdf) — primary respondent litigation filing
- [Mealey's — Supreme Court vacates Ninth Circuit TPS judgment](https://www.mealeys.com/mealeys/mealeys-class-actions/articles/2534089/u-s-high-court-vacates-judgment-in-class-suit-over-tps-end-for-venezuela-haiti) — independent legal reporting
- [Ninth Circuit — administrative stay order in National TPS Alliance litigation](https://cdn.ca9.uscourts.gov/datastore/opinions/2026/11/03/25-5724.pdf) — primary published court order withdrawing the October 30 denial and granting a 14-day administrative stay
- [Mullin v. National TPS Alliance, No. 26A714 — application for stay](https://www.supremecourt.gov/DocketPDF/26/26A714/433148/20261118141121255_20261118_Mullin_v_NTSPA_Stay_App_FILE.pdf) — primary emergency stay application submitted to Justice Kagan; requested relief and asserted operational consequences are party claims pending decision
- [Mullin v. National TPS Alliance, No. 26A714 — docket](https://www.supremecourt.gov/docket/docketfiles/html/public/26a714.html) — primary Supreme Court emergency docket showing filing and pending status
- [Trump administration appeals to Supreme Court over legal protections for Venezuelan migrants](https://apnews.com/article/34f5293fe85f3befb2a599f513308d60) — independent reporting on the pending emergency application and government-asserted effects

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
