# Supreme Court vacates Ninth Circuit TPS judgment and orders reconsideration

**Entry ID:** NAT-2026-10-05-004
**Date:** October 5, 2026
**Checked:** 2026-10-06 5:57 AM EDT
**Evidence state:** official Supreme Court docket, government petition and respondents' filed response plus independent legal reporting; appellate judgment vacated and remand ordered, downstream merits and individual-status consequences pending
**Review state:** current-standard-reviewed

The GVR sends the Venezuela-and-Haiti dispute back under the Court's June jurisdiction ruling; it is not a new merits opinion or a final status determination.

## THE FACTS

- In Mullin v. National TPS Alliance, No. 26-48, the Supreme Court on October 5 granted the government's certiorari petition, vacated the Ninth Circuit's January 28 judgment and remanded the case for further consideration in light of Mullin v. Doe, 609 U.S. 324 (2026).
- The vacated judgment had affirmed rulings against the Secretary of Homeland Security's vacatur and termination actions involving Venezuela and partial vacatur involving Haiti. The government's petition argued that the later Mullin v. Doe decision, including its reading of the TPS statute's judicial-review bar, required reconsideration.
- The National TPS Alliance and individual respondents did not oppose grant, vacatur and remand. Their filed response said Mullin v. Doe altered the premises of the decision below and agreed that reconsideration was appropriate.
- The Supreme Court issued no new merits opinion in docket 26-48 and did not itself resolve every remaining statutory or constitutional claim. The remand vacates the appellate judgment and returns the dispute to the Ninth Circuit; subsequent orders will determine the remaining claims and procedural consequences.
- The docket action did not itself create a new TPS designation or extension, and it should not be read as a finding that conditions in Venezuela or Haiti are safe. Earlier Supreme Court stays had already allowed termination actions to proceed while litigation continued, so the October 5 GVR is recorded as a litigation stage rather than a newly implemented removal program.

## SIGNIFICANCE

Vacating the appellate judgment removes a precedential ruling that constrained the administration's Venezuela and Haiti TPS actions and directs the lower court to apply a Supreme Court decision sharply limiting judicial review, while leaving the remand's final scope to further proceedings.

## GOALPOST / RESPONSE

The government says the TPS statute bars review of the Secretary's designation decisions and sought this remand after Mullin v. Doe. The respondents agreed that the intervening ruling changed the legal premises but did not concede every claim. The Ninth Circuit's remand proceedings, treatment of constitutional claims, later district-court orders and concrete status or work-authorization guidance are the tests.

## MAYBE / THEREFORE

Maybe the remand will end most challenges under the statutory review bar, or narrower constitutional and document-specific issues may remain. Therefore the record establishes grant, vacatur and remand of the Ninth Circuit judgment—not a new Supreme Court merits holding, a country-conditions finding or a final adjudication of every affected person's status.


## SOURCES

- [Supreme Court docket 26-48 — Mullin v. National TPS Alliance](https://www.supremecourt.gov/docket/docketfiles/html/public/26-48.html) — primary official docket recording grant, vacatur and remand
- [Solicitor General — petition in Mullin v. National TPS Alliance](https://www.supremecourt.gov/DocketPDF/26/26-48/416072/20260709130950638_NTPSA_Petition_Final.pdf) — primary government litigation filing
- [National TPS Alliance — response to certiorari petition in docket 26-48](https://www.supremecourt.gov/DocketPDF/26/26-48/419629/20260820132915252_26-48_Brief.pdf) — primary respondent litigation filing
- [Mealey's — Supreme Court vacates Ninth Circuit TPS judgment](https://www.mealeys.com/mealeys/mealeys-class-actions/articles/2534089/u-s-high-court-vacates-judgment-in-class-suit-over-tps-end-for-venezuela-haiti) — independent legal reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
