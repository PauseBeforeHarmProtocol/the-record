# Ninth Circuit adds 14-day administrative stay after Supreme Court TPS remand

**Entry ID:** NAT-2026-10-05-004
**Date:** October 5–November 6, 2026
**Checked:** 2026-11-06 6:10 AM EST
**Evidence state:** official Ninth Circuit published order withdrawing the October 30 denial and granting a 14-day administrative stay beginning upon issuance of the Supreme Court judgment; appeal, longer stay and merits unresolved
**Review state:** current-standard-reviewed

The appellate court withdrew its earlier denial and ordered a short administrative stay beginning when the Supreme Court judgment issues; the appeal and longer stay request remain unresolved.

## THE FACTS

- In Mullin v. National TPS Alliance, No. 26-48, the Supreme Court on October 5 granted the government's certiorari petition, vacated the Ninth Circuit's January 28 judgment and remanded the case for further consideration in light of Mullin v. Doe, 609 U.S. 324 (2026).
- The vacated judgment had affirmed rulings against the Secretary of Homeland Security's vacatur and termination actions involving Venezuela and partial vacatur involving Haiti. The government's petition argued that the later Mullin v. Doe decision, including its reading of the TPS statute's judicial-review bar, required reconsideration.
- The National TPS Alliance and individual respondents did not oppose grant, vacatur and remand. Their filed response said Mullin v. Doe altered the premises of the decision below and agreed that reconsideration was appropriate.
- The Supreme Court issued no new merits opinion in docket 26-48 and did not itself resolve every remaining statutory or constitutional claim. The remand vacates the appellate judgment and returns the dispute to the Ninth Circuit; subsequent orders will determine the remaining claims and procedural consequences.
- The docket action did not itself create a new TPS designation or extension, and it should not be read as a finding that conditions in Venezuela or Haiti are safe. Earlier Supreme Court stays had already allowed termination actions to proceed while litigation continued, so the October 5 GVR is recorded as a litigation stage rather than a newly implemented removal program.
- On November 3, the Ninth Circuit withdrew its October 30 order denying an administrative stay and granted the government's request for a 14-day administrative stay. The published order states that the 14 days begin when the Supreme Court issues its judgment in the remanded case, expected November 6.
- The administrative stay continues the pause on the district court injunction for that limited period while the appellate court considers the government's motion for a stay pending appeal. It is an operative procedural order, not a final merits ruling on the remaining claims or a new TPS designation.
- The order does not itself decide every affected person's immigration status or work authorization. Concrete agency guidance, the stay-pending-appeal ruling and later remand proceedings remain necessary to determine downstream effects.

## SIGNIFICANCE

The Ninth Circuit's new order preserves the government's litigation position for a defined 14-day period after the Supreme Court judgment and prevents the district court injunction from immediately resuming effect. It is a material procedural consequence of the remand, while the longer stay request and merits remain pending.

## GOALPOST / RESPONSE

The government says the TPS statute restricts judicial review and seeks a stay while the remand proceeds; respondents agreed the intervening Supreme Court decision changed the legal premises without conceding all remaining claims. The Ninth Circuit's stay-pending-appeal ruling, treatment of constitutional claims, later district-court orders and concrete DHS status and work-authorization guidance are the tests.

## MAYBE / THEREFORE

Maybe the short stay will be replaced by a longer appellate stay and most challenges will end, or narrower claims may survive and relief may resume. Therefore the record establishes a defined 14-day administrative stay beginning with the November 6 Supreme Court judgment—not a final merits decision, permanent termination of relief or individualized status determination.


## SOURCES

- [Supreme Court docket 26-48 — Mullin v. National TPS Alliance](https://www.supremecourt.gov/docket/docketfiles/html/public/26-48.html) — primary official docket recording grant, vacatur and remand
- [Solicitor General — petition in Mullin v. National TPS Alliance](https://www.supremecourt.gov/DocketPDF/26/26-48/416072/20260709130950638_NTPSA_Petition_Final.pdf) — primary government litigation filing
- [National TPS Alliance — response to certiorari petition in docket 26-48](https://www.supremecourt.gov/DocketPDF/26/26-48/419629/20260820132915252_26-48_Brief.pdf) — primary respondent litigation filing
- [Mealey's — Supreme Court vacates Ninth Circuit TPS judgment](https://www.mealeys.com/mealeys/mealeys-class-actions/articles/2534089/u-s-high-court-vacates-judgment-in-class-suit-over-tps-end-for-venezuela-haiti) — independent legal reporting
- [Ninth Circuit — administrative stay order in National TPS Alliance litigation](https://cdn.ca9.uscourts.gov/datastore/opinions/2026/11/03/25-5724.pdf) — primary published court order withdrawing the October 30 denial and granting a 14-day administrative stay

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
