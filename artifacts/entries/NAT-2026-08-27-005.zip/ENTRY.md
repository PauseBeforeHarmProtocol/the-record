# Twenty-three states challenge HHS's FY2027 Title X grant conditions

**Entry ID:** NAT-2026-08-27-005
**Date:** August 27, 2026
**Checked:** 2026-08-27 11:59 AM EDT
**Evidence state:** official FY2027 funding notice plus independent Reuters reporting on the filed 23-state complaint; solicitation conditions implemented, grants and judicial review pending
**Review state:** current-standard-reviewed

The filed federal lawsuit contests conditions in a solicitation estimating up to $257 million for family-planning services; no injunction has issued and no FY2027 awards have been made.

## THE FACTS

- Twenty-three states filed a federal lawsuit in Maryland challenging conditions in the Department of Health and Human Services' fiscal-year 2027 Title X family-planning notice of funding opportunity. The complaint's claims are allegations; the court had not issued an injunction or merits ruling by the checked time.
- The official solicitation estimates up to $257 million for as many as 90 awards, with applications due January 9, 2027 and anticipated awards beginning April 1, 2027. Actual funding depends on the fiscal-year 2027 budget, so the notice is not a completed appropriation, award, or expenditure.
- The notice instructs applicants to address administration priorities including chronic-disease prevention, ending diversity-equity-and-inclusion practices, reducing what it calls overmedicalization, immigration-related requirements, parental rights, health literacy, and reproductive-goals counseling. It permits corrective action, added reporting, or termination for noncompliance.
- The states allege that the conditions exceed Title X authority, conflict with statutory counseling and nondiscrimination requirements, and impose major policy changes without required rulemaking. Reuters reported that HHS had not responded to a request for comment by publication.

## SIGNIFICANCE

The solicitation makes access to a major nationwide family-planning grant program contingent on alignment with broad administration priorities, while the lawsuit tests whether those conditions fit the governing statute and administrative-law process. The practical effect depends on emergency relief, applicant participation, later award decisions, and actual service access.

## GOALPOST / RESPONSE

HHS presents the conditions as program-integrity and public-health priorities intended to improve outcomes, parental involvement, and compliance with federal policy. The states argue they are politically driven, legally unauthorized, and likely to disrupt confidential and comprehensive care. Court rulings, application and award patterns, provider participation, corrective actions, and patient-access measures are the tests.

## MAYBE / THEREFORE

Maybe HHS can lawfully use grant-selection criteria to redirect Title X services toward its stated priorities, or a court may find that some conditions require rulemaking or conflict with the statute. Therefore the record distinguishes the implemented solicitation and filed lawsuit from unawarded funds, unproven service effects, and any future judicial determination.


## SOURCES

- [HHS Office of Population Affairs — FY2027 Title X services notice of funding opportunity](https://files.simpler.grants.gov/opportunities/770eae58-b245-4431-a4b8-7b1aca9e917f/attachments/5e3ac609-8998-466a-a8b6-c3d7d49a2e6c/2027_Title_X_Services_NOFO_PA-FPH-27-001_PDF.pdf) — primary funding notice with eligibility conditions, estimated funding, award schedule, and agency priorities
- [Reuters — 23 states sue over FY2027 Title X grant conditions](https://www.reuters.com/legal/litigation/us-states-sue-block-new-conditions-family-planning-grants-2026-08-27/) — independent reporting on the filed complaint, challenged conditions, funding context, and procedural status

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
