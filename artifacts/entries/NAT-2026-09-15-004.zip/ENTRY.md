# OPM restores displaced-employee protections omitted by its reduction-in-force rule

**Entry ID:** NAT-2026-09-15-004
**Date:** August 3–September 15, 2026
**Checked:** 2026-09-15 12:00 PM EDT
**Evidence state:** primary Federal Register final rule and effective correcting amendment; the omitted and restored text, agency rationale and effective dates are explicit, while employee-level consequences are unmeasured
**Review state:** current-standard-reviewed

An effective correcting amendment restores two CTAP eligibility paragraphs that OPM says its August rule removed inadvertently; the agency calls the correction nonsubstantive.

## THE FACTS

- OPM published an immediately effective correcting amendment on September 15 to its August 3 reduction-in-force final rule, which took effect September 2. The correction is implemented regulatory text, not a proposed change.
- OPM says amendatory instruction 11 inadvertently removed two subparagraphs from the 5 CFR 330.602 definition of a displaced employee for Career Transition Assistance Plan purposes. The missing provisions cover a competitive-service employee who receives a RIF separation notice or a proposed-removal notice for declining a directed relocation outside the local commuting area.
- The amendment restores both subparagraphs as they read before September 2 and leaves the rule's separate revision to the definition of surplus unchanged. OPM says the omission made the displaced definition incomplete and did not reflect the proposal or the final rule's discussion.
- OPM invoked Administrative Procedure Act good cause to bypass prior notice and comment and make the repair effective upon publication, describing it as no substantive change. That characterization and the restored text are established; the record does not infer how many employees were affected during the 13-day interval.

## SIGNIFICANCE

CTAP status affects priority consideration for displaced federal employees. Restoring the omitted circumstances closes an unintended gap in the operative definition, while documenting that the prior final rule briefly failed to say what OPM intended.

## GOALPOST / RESPONSE

OPM says the correction is nonsubstantive because it restores preexisting text the agency never proposed to remove. The tests are the operative eCFR text, agency implementation, CTAP eligibility decisions, any challenges and evidence of employees denied priority consideration during the interval.

## MAYBE / THEREFORE

Maybe agencies continued applying the intended definition despite the publication error, or the incomplete text created real uncertainty for employees during the interval. Therefore OPM has restored the two CTAP circumstances effective September 15, but the record does not establish a measured denial, retroactive remedy or broader reversal of the August RIF rule.


## SOURCES

- [Federal Register — Reduction in Force correcting amendment](https://www.federalregister.gov/documents/2026/09/15/2026-18800/reduction-in-force-correction) — primary final correcting amendment effective on publication
- [Federal Register — Reduction in Force final rule](https://www.federalregister.gov/documents/2026/08/03/2026-15665/reduction-in-force) — primary underlying final rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
