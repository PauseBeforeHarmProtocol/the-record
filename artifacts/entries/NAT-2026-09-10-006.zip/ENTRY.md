# BLS reports September producer prices rose 1.3% and 6.3% annually

**Entry ID:** NAT-2026-09-10-006
**Date:** September 10–October 15, 2026
**Checked:** 2026-10-16 11:57 AM EDT
**Evidence state:** primary BLS statistical release plus independent Reuters context; September and revised August measurements published, later revisions, pass-through and causal attribution unresolved
**Review state:** current-standard-reviewed

The largest monthly rise since March 2022 was broad-based but led by energy; BLS also revised August’s increase from 0.4% to 0.5%.

## THE FACTS

- The Bureau of Labor Statistics reported that the Producer Price Index for final demand increased 1.3% in September 2026 on a seasonally adjusted basis, the largest monthly rise since March 2022. Final-demand prices were 6.3% higher over 12 months, the largest annual increase since December 2022.
- BLS revised the August monthly increase from the initially reported 0.4% to 0.5%. The Record’s prior August figure was accurate to the then-current release; this update preserves the standard statistical revision rather than treating the preliminary estimate as final.
- Final-demand goods prices rose 2.6%, the largest increase since the series began in December 2009, and services rose 0.8%. More than 80% of the goods increase was attributable to a 10.8% increase in final-demand energy prices.
- Gasoline producer prices jumped 20.3% and diesel-fuel prices rose 21.0% in September. Prices excluding foods, energy and trade services rose 0.5% for the month and 5.0% over 12 months, showing pressure beyond the most volatile categories without assigning it to one cause.
- Reuters reported that retail sales rose 0.8%, largely reflecting higher gasoline receipts, while the core retail-sales measure edged up 0.1%. Those data provide economic context; neither PPI nor nominal retail receipts by themselves establish an identical household cost change or isolate tariffs, war, monetary policy or another single cause.

## SIGNIFICANCE

The September release documents the sharpest producer-price rise in four and a half years, with both energy and broader components contributing. Pipeline inflation can affect business margins and later consumer prices, but the release does not measure complete pass-through, household losses or the causal share of any administration policy.

## GOALPOST / RESPONSE

The administration argues that expanded domestic energy production and related policies will reduce costs. Subsequent PPI, CPI and PCE releases, fuel inventories, freight rates, retail prices, real wages and policy-specific causal analysis—not one monthly headline—are the tests of whether inflation pressure subsides and why.

## MAYBE / THEREFORE

Maybe September reflects a temporary energy shock that eases as supply adjusts, or the broader goods and services increases may persist and pass through to consumers. Therefore the record establishes a 1.3% monthly and 6.3% annual producer-price increase plus a revised August estimate—not a permanent inflation path, a completed household-cost calculation or proof of single-policy causation.

## CORRECTIONS

- **2026-10-16T15:57:45Z** — Updated the preliminary August PPI increase from 0.4% to BLS’s revised 0.5% figure and preserved the original preliminary value in version history.


## SOURCES

- [BLS — Producer Price Indexes, September 2026](https://www.bls.gov/news.release/ppi.nr0.htm) — primary statistical release updated October 15
- [Reuters — September producer prices post largest gain in 4-1/2 years](https://www.reuters.com/business/us-producer-prices-post-largest-increase-4-12-years-september-2026-10-15/) — independent economic report and contextual analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
