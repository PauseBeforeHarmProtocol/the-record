# Trump orders new HHS women's-health division and White House task force

**Entry ID:** NAT-2026-10-19-002
**Date:** October 19, 2026
**Checked:** 2026-10-19 12:02 PM EDT
**Evidence state:** signed White House executive order, administration fact sheet and independent Associated Press reporting; organizational duties ordered, funding, implementation and outcomes unresolved
**Review state:** current-standard-reviewed

The signed order sets 90-day organizational deadlines and a research-coordination mandate but appropriates no money and does not establish completed programs or measured outcomes.

## THE FACTS

- President Trump signed an executive order directing the health secretary, through the National Institutes of Health director, to establish a Division of Women's Health within 90 days. The division is ordered to coordinate research and translate findings across life stages; the order establishes the duty and deadline, not a completed reorganization or funded program.
- The order also creates a White House Women's Health Task Force co-chaired by the health secretary and White House chief of staff. It directs participating agencies to identify research gaps, improve coordination and recommend actions within existing authorities.
- The order revokes Executive Order 14120 and a November 13, 2023 presidential memorandum on women's-health research. The administration says the new structure will replace fragmented work with life-stage research and faster translation into care.
- Associated Press reported that the order specifies no new appropriation. Spending, staffing, research priorities and program outputs therefore remain subject to later agency action and available funds.

## SIGNIFICANCE

The order reorganizes federal coordination of women's-health research and places a new task force in the White House, potentially influencing NIH priorities and cross-agency work. Its practical effect depends on staffing, budgets, published plans, research awards and measurable changes in care or outcomes.

## GOALPOST / RESPONSE

The administration says a life-stage approach and centralized coordination will close research gaps and speed useful findings into care. The 90-day division deadline, membership and work products, appropriations, grants, clinical guidance, participation across agencies and independently measured health outcomes are the tests.

## MAYBE / THEREFORE

Maybe a dedicated division and task force improve coordination and address neglected conditions, or the change may relabel existing work without new resources and may redirect priorities. Therefore the order is signed and organizational duties are ordered—not that the division is already operating, new money has been appropriated or health outcomes have improved.


## SOURCES

- [White House — Advancing Women's Health to Improve Outcomes in All Phases of Life executive order](https://www.whitehouse.gov/presidential-actions/2026/10/advancing-womens-health-to-improve-outcomes-in-all-phases-of-life/) — primary signed executive order establishing the Women's Health Division and White House task force
- [White House fact sheet — Advancing Women's Health](https://www.whitehouse.gov/fact-sheets/2026/10/fact-sheet-president-donald-j-trump-advances-womens-health-to-improve-outcomes-in-all-phases-of-life/) — primary administration explanation of the executive order and stated objectives
- [Associated Press — Trump signs women's-health executive order](https://apnews.com/article/melania-trump-womens-health-executive-order-47534d721ac1328832ca46d9286ca833) — independent reporting on the signed order, implementation timetable and lack of specified funding

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
