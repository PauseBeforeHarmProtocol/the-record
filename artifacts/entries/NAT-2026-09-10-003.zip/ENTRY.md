# Administration begins sending $500 ACA refunds to eligible federal-exchange enrollees

**Entry ID:** NAT-2026-09-10-003
**Date:** September 10–30, 2026
**Checked:** 2026-10-01 5:57 AM EDT
**Evidence state:** primary White House program announcement plus independent implementation reporting; initial mailing reported, complete delivery, audited funding calculation and measured affordability effect unresolved
**Review state:** current-standard-reviewed

The announced program advanced to initial mailing; distribution to every eligible recipient, the precise funding calculation and net premium effects remain unverified.

## THE FACTS

- On September 10, the White House announced $500 refunds for nearly one million people in 30 states who enrolled through the federal Affordable Care Act exchange without premium assistance. Indiana is among the listed states.
- The fact sheet says checks will begin going out in October 2026. It attributes the money to excessive exchange user fees and accumulated surplus, blaming the prior administration; that account is an administration claim, not an independently audited overcharge finding.
- The inspected announcement supplies neither an individual eligibility lookback and calculation nor a detailed funding-authority instrument. It does not establish that checks have been sent. This targeted ACA announcement is separate from the conditional $5,000 campaign proposal in NAT-2026-09-09-005.
- The Wall Street Journal and CBS News reported on September 30 that the administration began sending the $500 checks, accompanied by a presidential letter, to more than 950,000 eligible people. Initial mailing is an implementation step; the inspected evidence did not establish receipt by every eligible person, a complete disbursement ledger or an independent audit of the claimed overcharge and surplus.

## SIGNIFICANCE

The first reported mailings move the program from an announcement to implementation and potentially distribute roughly $475 million if more than 950,000 recipients each receive $500. That multiplication is a scale estimate, not verified final expenditure, and the program excludes subsidized and state-exchange enrollees.

## GOALPOST / RESPONSE

The White House says the checks return excess user-fee collections to affected consumers. Critics and health-policy experts question the overcharge characterization, targeting and broader affordability effect. Treasury or CMS disbursement records, returned or undeliverable payments, the legal funding instrument, audited surplus calculations and net premiums are the tests.

## MAYBE / THEREFORE

Maybe returning a genuine fee surplus supplies timely relief to the intended enrollees, or incomplete delivery and disputed accounting may narrow the practical benefit. Therefore independent reporting establishes that mailing began—not universal receipt, a final expenditure total, a universal health benefit or an independently proved overcharge.


## SOURCES

- [White House — Working Families Obamacare Refunds](https://www.whitehouse.gov/fact-sheets/2026/09/fact-sheet-president-donald-j-trump-announces-the-working-families-obamacare-refunds/) — primary announcement
- [Wall Street Journal — administration begins sending $500 ACA refund checks](https://www.wsj.com/politics/policy/trump-sending-500-checks-with-letter-touting-healthcare-record-aa6923b6) — independent reporting on payment implementation and accompanying letter
- [CBS News — administration starts sending $500 ACA refund checks](https://www.cbsnews.com/news/trump-obamacare-500-refund-checks/) — independent reporting on payment implementation and eligibility

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
