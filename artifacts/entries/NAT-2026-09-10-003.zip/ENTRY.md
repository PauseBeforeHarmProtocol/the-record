# White House announces $500 ACA refunds for nearly one million unsubsidized federal-exchange enrollees

**Entry ID:** NAT-2026-09-10-003
**Date:** September 10, 2026
**Checked:** 2026-09-10 5:57 PM EDT
**Evidence state:** primary White House fact sheet inspected; announced, not disbursed; detailed implementation and independent audit remain unverified
**Review state:** current-standard-reviewed

The administration schedules checks to begin in October; the announcement does not establish completed payments or a universal benefit.

## THE FACTS

- On September 10, the White House announced $500 refunds for nearly one million people in 30 states who enrolled through the federal Affordable Care Act exchange without premium assistance. Indiana is among the listed states.
- The fact sheet says checks will begin going out in October 2026. It attributes the money to excessive exchange user fees and accumulated surplus, blaming the prior administration; that account is an administration claim, not an independently audited overcharge finding.
- The inspected announcement supplies neither an individual eligibility lookback and calculation nor a detailed funding-authority instrument. It does not establish that checks have been sent. This targeted ACA announcement is separate from the conditional $5,000 campaign proposal in NAT-2026-09-09-005.

## SIGNIFICANCE

The announcement potentially directs hundreds of millions of dollars to a defined health-insurance population. Eligibility, legal authority, actual payment and net premium effects matter more than treating the announced amount as delivered relief for all Americans.

## GOALPOST / RESPONSE

The White House describes the refunds as returning excess fees to consumers and separately asks Congress to enact its Great Healthcare Plan. Published eligibility instructions, the funding instrument, disbursement records and net premium costs are the tests; the fact sheet alone does not independently establish the asserted misconduct by the prior administration.

## MAYBE / THEREFORE

Maybe returning a genuine fee surplus provides useful relief to affected enrollees, or eligibility and funding limitations may make the headline promise broader than its practical benefit. Therefore this is an announced, targeted October refund—not a paid check, a universal entitlement or an independently proved overcharge.


## SOURCES

- [White House — Working Families Obamacare Refunds](https://www.whitehouse.gov/fact-sheets/2026/09/fact-sheet-president-donald-j-trump-announces-the-working-families-obamacare-refunds/) — primary announcement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
