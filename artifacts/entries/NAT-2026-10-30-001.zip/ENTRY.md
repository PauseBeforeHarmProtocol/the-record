# DOJ makes first disclosed Model Cities award after four-jurisdiction selection

**Entry ID:** NAT-2026-10-30-001
**Date:** October 30–November 5, 2026
**Checked:** 2026-11-05 12:05 PM EST
**Evidence state:** primary DOJ selection announcement, program notice and East Baton Rouge award announcement, state response and independent local reporting; one award announced, disbursement and outcomes not established
**Review state:** current-standard-reviewed

DOJ says East Baton Rouge Parish received a $63,532,285 award; plan finalization, disbursement, implementation and results remain separate stages.

## THE FACTS

- On October 30, DOJ announced selection of Jacksonville’s Sheriff’s Office, East Baton Rouge Parish, the City of Jackson and St. Louis Police Department for nearly $300 million through the Model Cities Initiative. The updated release identifies the departments and says DOJ will finalize public-safety plans with the jurisdictions. Mississippi’s governor separately confirmed Jackson’s selection. These are announced awards, not a verified ledger of disbursements.
- The June 3 program notice describes cooperative agreements with substantial DOJ involvement, immigration-cooperation requirements and priorities including violent-crime enforcement, urban-camping restrictions and treatment. Its implementation section requires action-plan and final-budget review and contemplates funds released at milestones. These are program terms, not proof that every city’s final award instrument or local policy has been implemented.
- Mississippi Today reported that Jackson’s council still had to vote on accepting the grant and that the department had requested up to $125 million over three years. That application amount is not treated as the amount awarded. The report describes proposed investigative technology and surveillance; neither the proposals nor selection establishes an operational system or a measured safety benefit.
- On November 5, DOJ said it had awarded East Baton Rouge Parish $63,532,285 on November 4 through the Model Cities Initiative. The release calls this an award and identifies planned uses including personnel, technology, vehicles, equipment, training, treatment and victim services. It also says DOJ will continue working with each jurisdiction to finalize and implement its plan, so the announcement does not establish that the full amount was disbursed or spent or that every proposed activity is operational.

## SIGNIFICANCE

The first disclosed dollar-specific award moves the program beyond selection for one jurisdiction while preserving important lifecycle distinctions. Federal influence, local safeguards and public-safety consequences depend on executed terms, actual disbursement and spending, implementation and measured outcomes.

## GOALPOST / RESPONSE

DOJ presents the initiative as locally tailored coordination, staffing, technology, treatment and victim support intended to reduce violence and recidivism. The tests are published award instruments, local acceptance, milestone releases, actual expenditures, lawful implementation, civil-rights safeguards and comparable crime and service outcomes.

## MAYBE / THEREFORE

Maybe the East Baton Rouge award improves investigative and treatment capacity, or conditions and technology may impose costs and rights risks without additional benefit. Therefore one $63,532,285 award is now disclosed; cash disbursement, completed spending, implementation and causal crime reduction remain unverified, and the other jurisdictions' final dollar awards remain unresolved.


## SOURCES

- [DOJ — Four jurisdictions selected for nearly $300 million](https://www.justice.gov/opa/pr/justice-department-announces-nearly-300-million-awards-four-model-cities-combat-violent) — primary announced award selections; updated departments list
- [DOJ — FY2026 Model Cities Initiative funding notice](https://www.justice.gov/asg/media/1444021/dl?inline=) — primary program solicitation; contextual terms, not executed awards
- [Mississippi governor — Jackson Model Cities selection](https://governorreeves.ms.gov/jackson-one-of-four-jurisdictions-in-america-to-receive-trump-administration-funding-to-combat-crime/) — primary state response to federal selection
- [Mississippi Today — Jackson grant and pending acceptance](https://mississippitoday.org/2026/10/30/trump-doj-wants-to-give-the-jackson-police-department-millions-with-strings-attached/) — independent local reporting; own interviews and application review
- [DOJ — East Baton Rouge Parish awarded $63,532,285 through Model Cities Initiative](https://www.justice.gov/opa/pr/justice-department-awards-east-baton-rouge-parish-more-635m-combat-violent-crime-and-restore) — primary award announcement and implementation-status statement

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
