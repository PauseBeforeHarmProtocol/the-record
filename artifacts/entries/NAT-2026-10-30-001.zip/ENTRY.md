# DOJ selects four jurisdictions for nearly $300 million in public-safety awards

**Entry ID:** NAT-2026-10-30-001
**Date:** October 30, 2026
**Checked:** 2026-10-30 6:11 PM EDT
**Evidence state:** primary DOJ selection announcement and original program notice, state response and independent local reporting; announced selections, no executed award/disbursement ledger inspected
**Review state:** current-standard-reviewed

Announced Model Cities selections carry implementation and policy conditions; selection is not completed spending or measured crime reduction.

## THE FACTS

- On October 30, DOJ announced selection of Jacksonville’s Sheriff’s Office, East Baton Rouge Parish, the City of Jackson and St. Louis Police Department for nearly $300 million through the Model Cities Initiative. The updated release identifies the departments and says DOJ will finalize public-safety plans with the jurisdictions. Mississippi’s governor separately confirmed Jackson’s selection. These are announced awards, not a verified ledger of disbursements.
- The June 3 program notice describes cooperative agreements with substantial DOJ involvement, immigration-cooperation requirements and priorities including violent-crime enforcement, urban-camping restrictions and treatment. Its implementation section requires action-plan and final-budget review and contemplates funds released at milestones. These are program terms, not proof that every city’s final award instrument or local policy has been implemented.
- Mississippi Today reported that Jackson’s council still had to vote on accepting the grant and that the department had requested up to $125 million over three years. That application amount is not treated as the amount awarded. The report describes proposed investigative technology and surveillance; neither the proposals nor selection establishes an operational system or a measured safety benefit.

## SIGNIFICANCE

A large federal award-selection program can expand local investigative capacity while increasing federal influence over policing, immigration cooperation and treatment policy. The consequences depend on executed conditions, local acceptance, actual spending, safeguards and outcomes—not the announcement alone.

## GOALPOST / RESPONSE

DOJ presents the initiative as locally tailored coordination, better staffing and technology, and reduced violence and recidivism. Mississippi officials welcome support for investigations and prevention. The program also allows treatment services. The strongest test is transparent award terms and spending, lawful implementation, civil-rights safeguards and comparable crime outcomes.

## MAYBE / THEREFORE

Maybe the cooperative awards improve public safety and treatment capacity, or conditions and technology may impose costs and rights risks without additional benefit. Therefore four jurisdictions were selected for announced federal support; completed expenditures, local acceptance, implementation and causal crime reductions remain unverified.


## SOURCES

- [DOJ — Four jurisdictions selected for nearly $300 million](https://www.justice.gov/opa/pr/justice-department-announces-nearly-300-million-awards-four-model-cities-combat-violent) — primary announced award selections; updated departments list
- [DOJ — FY2026 Model Cities Initiative funding notice](https://www.justice.gov/asg/media/1444021/dl?inline=) — primary program solicitation; contextual terms, not executed awards
- [Mississippi governor — Jackson Model Cities selection](https://governorreeves.ms.gov/jackson-one-of-four-jurisdictions-in-america-to-receive-trump-administration-funding-to-combat-crime/) — primary state response to federal selection
- [Mississippi Today — Jackson grant and pending acceptance](https://mississippitoday.org/2026/10/30/trump-doj-wants-to-give-the-jackson-police-department-millions-with-strings-attached/) — independent local reporting; own interviews and application review

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
