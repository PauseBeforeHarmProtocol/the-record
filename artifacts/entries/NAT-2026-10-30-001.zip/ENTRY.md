# DOJ discloses second Model Cities award: more than $73 million to Jacksonville

**Entry ID:** NAT-2026-10-30-001
**Date:** October 30–November 6, 2026
**Checked:** 2026-11-07 12:07 PM EST
**Evidence state:** primary DOJ program and award announcements plus independent local reporting; two award amounts announced, final plans, disbursement, spending and outcomes not established
**Review state:** current-standard-reviewed

Jacksonville joins East Baton Rouge with a disclosed dollar-specific award; local reporting says the money spans three years, while final plans, milestone releases, spending and results remain separate stages.

## THE FACTS

- On October 30, DOJ announced selection of Jacksonville’s Sheriff’s Office, East Baton Rouge Parish, the City of Jackson and St. Louis Police Department for nearly $300 million through the Model Cities Initiative. The updated release identifies the departments and says DOJ will finalize public-safety plans with the jurisdictions. Mississippi’s governor separately confirmed Jackson’s selection. These are announced awards, not a verified ledger of disbursements.
- The June 3 program notice describes cooperative agreements with substantial DOJ involvement, immigration-cooperation requirements and priorities including violent-crime enforcement, urban-camping restrictions and treatment. Its implementation section requires action-plan and final-budget review and contemplates funds released at milestones. These are program terms, not proof that every city’s final award instrument or local policy has been implemented.
- Mississippi Today reported that Jackson’s council still had to vote on accepting the grant and that the department had requested up to $125 million over three years. That application amount is not treated as the amount awarded. The report describes proposed investigative technology and surveillance; neither the proposals nor selection establishes an operational system or a measured safety benefit.
- On November 5, DOJ said it had awarded East Baton Rouge Parish $63,532,285 on November 4 through the Model Cities Initiative. The release calls this an award and identifies planned uses including personnel, technology, vehicles, equipment, training, treatment and victim services. It also says DOJ will continue working with each jurisdiction to finalize and implement its plan, so the announcement does not establish that the full amount was disbursed or spent or that every proposed activity is operational.
- On November 6, DOJ said it awarded Jacksonville more than $73 million through Model Cities. Independent local reports described a three-year award and a ceremonial presentation. DOJ still said it would work with each jurisdiction to finalize and implement its public-safety plan, so the announcement does not by itself establish that the full amount was disbursed or spent.
- Jacksonville officials said proposed uses include 40 sworn-officer positions, training and equipment, expansion of the Real Time Crime Center, drone and counter-drone programs and forensic capacity. Those are planned uses rather than verified completed hiring, procurement, deployment or measured results; DOJ's cited 2023–2025 crime declines predate the award and do not measure its effect.

## SIGNIFICANCE

A second dollar-specific award moves another selected jurisdiction beyond the initial program announcement. Federal influence, local safeguards and public-safety consequences still depend on final terms, milestone releases, actual spending, lawful implementation and measured outcomes.

## GOALPOST / RESPONSE

DOJ and Jacksonville officials say the award will expand staffing, forensics, technology and investigative capacity while building on falling violent-crime measures. The tests are the executed agreement, local acceptance, milestone releases, actual expenditures, civil-rights and privacy safeguards, staffing and procurement records, and comparable crime and service outcomes.

## MAYBE / THEREFORE

Maybe the Jacksonville and East Baton Rouge awards improve investigative and treatment capacity, or conditions and surveillance-oriented technology may impose costs and rights risks without additional benefit. Therefore two dollar-specific awards are now publicly disclosed; disbursement, completed spending, implementation and causal crime reduction remain unverified, and Jackson and St. Louis dollar amounts remain unresolved.


## SOURCES

- [DOJ — Four jurisdictions selected for nearly $300 million](https://www.justice.gov/opa/pr/justice-department-announces-nearly-300-million-awards-four-model-cities-combat-violent) — primary announced award selections; updated departments list
- [DOJ — FY2026 Model Cities Initiative funding notice](https://www.justice.gov/asg/media/1444021/dl?inline=) — primary program solicitation; contextual terms, not executed awards
- [Mississippi governor — Jackson Model Cities selection](https://governorreeves.ms.gov/jackson-one-of-four-jurisdictions-in-america-to-receive-trump-administration-funding-to-combat-crime/) — primary state response to federal selection
- [Mississippi Today — Jackson grant and pending acceptance](https://mississippitoday.org/2026/10/30/trump-doj-wants-to-give-the-jackson-police-department-millions-with-strings-attached/) — independent local reporting; own interviews and application review
- [DOJ — East Baton Rouge Parish awarded $63,532,285 through Model Cities Initiative](https://www.justice.gov/opa/pr/justice-department-awards-east-baton-rouge-parish-more-635m-combat-violent-crime-and-restore) — primary award announcement and implementation-status statement
- [DOJ — more than $73 million Model Cities award to Jacksonville](https://www.justice.gov/opa/pr/justice-department-awards-jacksonville-more-73m-combat-violent-crime-and-restore-law-and) — primary award announcement and administration explanation; spending and outcomes not measured
- [News4JAX — Jacksonville Model Cities award plans](https://www.news4jax.com/news/local/2026/11/06/jso-among-4-agencies-selected-nationally-for-doj-model-cities-initiative/) — independent local reporting on award duration, planned hiring and technology uses
- [Jacksonville Daily Record — DOJ awards Jacksonville public-safety funding](https://www.jaxdailyrecord.com/news/2026/nov/06/doj-awards-jacksonville-73-million-for-public-safety/) — independent local reporting on the ceremonial award and proposed uses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
