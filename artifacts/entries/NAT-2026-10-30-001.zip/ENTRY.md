# DOJ completes dollar-specific Model Cities award rollout for four jurisdictions

**Entry ID:** NAT-2026-10-30-001
**Date:** October 30–November 9, 2026
**Checked:** 2026-11-10 6:10 AM EST
**Evidence state:** primary DOJ award announcements plus independent local reporting; four amounts announced, local acceptance, disbursement, spending, implementation and outcomes not fully established
**Review state:** current-standard-reviewed

DOJ announced more than $63 million for Jackson and more than $68 million for St. Louis, completing dollar-specific announcements for all four selections; acceptance, disbursement, spending and outcomes remain separate stages.

## THE FACTS

- On October 30, DOJ announced selection of Jacksonville’s Sheriff’s Office, East Baton Rouge Parish, the City of Jackson and St. Louis Police Department for nearly $300 million through the Model Cities Initiative. The updated release identifies the departments and says DOJ will finalize public-safety plans with the jurisdictions. Mississippi’s governor separately confirmed Jackson’s selection. These are announced awards, not a verified ledger of disbursements.
- The June 3 program notice describes cooperative agreements with substantial DOJ involvement, immigration-cooperation requirements and priorities including violent-crime enforcement, urban-camping restrictions and treatment. Its implementation section requires action-plan and final-budget review and contemplates funds released at milestones. These are program terms, not proof that every city’s final award instrument or local policy has been implemented.
- Mississippi Today reported that Jackson’s council still had to vote on accepting the grant and that the department had requested up to $125 million over three years. That application amount is not treated as the amount awarded. The report describes proposed investigative technology and surveillance; neither the proposals nor selection establishes an operational system or a measured safety benefit.
- On November 5, DOJ said it had awarded East Baton Rouge Parish $63,532,285 on November 4 through the Model Cities Initiative. The release calls this an award and identifies planned uses including personnel, technology, vehicles, equipment, training, treatment and victim services. It also says DOJ will continue working with each jurisdiction to finalize and implement its plan, so the announcement does not establish that the full amount was disbursed or spent or that every proposed activity is operational.
- On November 6, DOJ said it awarded Jacksonville more than $73 million through Model Cities. Independent local reports described a three-year award and a ceremonial presentation. DOJ still said it would work with each jurisdiction to finalize and implement its public-safety plan, so the announcement does not by itself establish that the full amount was disbursed or spent.
- Jacksonville officials said proposed uses include 40 sworn-officer positions, training and equipment, expansion of the Real Time Crime Center, drone and counter-drone programs and forensic capacity. Those are planned uses rather than verified completed hiring, procurement, deployment or measured results; DOJ's cited 2023–2025 crime declines predate the award and do not measure its effect.
- On November 9, DOJ announced an award of more than $63 million to Jackson, Mississippi. Mississippi Today reported the presentation used a symbolic check, Jackson’s city council still must decide whether to accept the award, and the money was expected to arrive beginning in early 2027. Proposed uses included hiring, forensic capacity and surveillance technology; those plans are not completed expenditures or measured results.
- Also on November 9, DOJ announced an award of more than $68 million to the St. Louis Metropolitan Police Department. Spectrum News reported a three-year distribution and proposed uses including the Real Time Crime Center, recruitment incentives, homeless outreach, a replacement radio tower and technology. The announcement and proposed uses do not establish full disbursement, completed procurement or causal crime effects.
- With the Jackson and St. Louis announcements, DOJ has now disclosed dollar-specific awards for all four selected jurisdictions: East Baton Rouge $63,532,285, Jacksonville more than $73 million, Jackson more than $63 million and St. Louis more than $68 million. Because three figures are stated only as lower bounds, the archive does not manufacture an exact four-city total.

## SIGNIFICANCE

Dollar-specific announcements now cover all four selected jurisdictions, moving the program’s public record beyond the original nearly-$300-million selection summary. Federal influence, privacy and civil-rights safeguards, local acceptance and public-safety consequences still depend on agreements, milestone releases, actual spending, lawful implementation and measured outcomes.

## GOALPOST / RESPONSE

DOJ and local officials say the awards will improve staffing, investigations, technology, treatment and victim support while reducing violence. The tests are executed agreements, Jackson council acceptance, milestone releases, public expenditure and procurement records, civil-rights and privacy safeguards, implementation and comparable outcome measures.

## MAYBE / THEREFORE

Maybe the four cooperative awards improve investigative and treatment capacity, or conditions and surveillance-oriented investments may impose costs and rights risks without additional benefit. Therefore all four jurisdictions now have dollar-specific announced awards; the archive does not treat symbolic checks, proposed uses or award announcements as completed spending or proven crime reduction.


## SOURCES

- [DOJ — Four jurisdictions selected for nearly $300 million](https://www.justice.gov/opa/pr/justice-department-announces-nearly-300-million-awards-four-model-cities-combat-violent) — primary announced award selections; updated departments list
- [DOJ — FY2026 Model Cities Initiative funding notice](https://www.justice.gov/asg/media/1444021/dl?inline=) — primary program solicitation; contextual terms, not executed awards
- [Mississippi governor — Jackson Model Cities selection](https://governorreeves.ms.gov/jackson-one-of-four-jurisdictions-in-america-to-receive-trump-administration-funding-to-combat-crime/) — primary state response to federal selection
- [Mississippi Today — Jackson grant and pending acceptance](https://mississippitoday.org/2026/10/30/trump-doj-wants-to-give-the-jackson-police-department-millions-with-strings-attached/) — independent local reporting; own interviews and application review
- [DOJ — East Baton Rouge Parish awarded $63,532,285 through Model Cities Initiative](https://www.justice.gov/opa/pr/justice-department-awards-east-baton-rouge-parish-more-635m-combat-violent-crime-and-restore) — primary award announcement and implementation-status statement
- [DOJ — more than $73 million Model Cities award to Jacksonville](https://www.justice.gov/opa/pr/justice-department-awards-jacksonville-more-73m-combat-violent-crime-and-restore-law-and) — primary award announcement and administration explanation; spending and outcomes not measured
- [News4JAX — Jacksonville Model Cities award plans](https://www.news4jax.com/news/local/2026/11/06/jso-among-4-agencies-selected-nationally-for-doj-model-cities-initiative/) — independent local reporting on award duration, planned hiring and technology uses
- [Jacksonville Daily Record — DOJ awards Jacksonville public-safety funding](https://www.jaxdailyrecord.com/news/2026/nov/06/doj-awards-jacksonville-73-million-for-public-safety/) — independent local reporting on the ceremonial award and proposed uses
- [DOJ — Jackson awarded more than $63 million through Model Cities](https://www.justice.gov/opa/pr/justice-department-awards-jackson-mississippi-more-63m-combat-violent-crime-and-restore-law) — primary agency award announcement
- [Mississippi Today — Jackson gets $64 million federal grant](https://mississippitoday.org/2026/11/09/jackson-gets-64-million-federal-grant/) — independent local reporting on acceptance, timing and proposed uses
- [DOJ — St. Louis awarded more than $68 million through Model Cities](https://www.justice.gov/opa/pr/justice-department-awards-st-louis-more-68m-combat-violent-crime-and-restore-law-and-order) — primary agency award announcement
- [Spectrum News — St. Louis Police Department to receive $68 million](https://spectrumlocalnews.com/mo/st-louis/news/2026/11/09/slmpd-to-receive--68-million-thanks-to-federal-grant) — independent local reporting on award duration and proposed uses

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
