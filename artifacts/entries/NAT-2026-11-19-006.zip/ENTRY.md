# FERC reports FY2026 enforcement, audit recoveries and unresolved major penalty

**Entry ID:** NAT-2026-11-19-006
**Date:** Fiscal year 2026 report, released November 19, 2026
**Checked:** 2026-11-19 6:07 PM EST
**Evidence state:** official 86-page annual enforcement report and agency release; figures are agency-reported, with the large contested matter distinguished from collected settlements
**Review state:** current-standard-reviewed

The agency reported eight settlements, audit recoveries and corrective actions for FY2026 while separately identifying a $1.132 billion American Efficient penalty and disgorgement order as a significant pending matter.

## THE FACTS

- FERC's 2026 Report on Enforcement says the Office of Enforcement opened 28 investigations and closed 10 without further action during fiscal year 2026.
- The report says the Commission approved eight settlements totaling $7,086,687: $5,573,851 in civil penalties and $1,512,836.267 in disgorgement. These are agency-reported settlement figures, not an independent effectiveness audit.
- The report separately identifies the April 15 American Efficient order assessing a $722 million civil penalty and approximately $410 million in disgorgement as a significant pending matter. The report does not support adding that contested order to the settled or collected total.
- FERC says seven audits produced 27 noncompliance findings and 133 corrective recommendations, with a majority implemented within six months. It reports $39,616,867 in refunds and other recoveries, consisting of $16,016,867 in refunds and $23.6 million in inappropriate future costs prevented.

## SIGNIFICANCE

The report provides a formal annual accounting of federal energy-market enforcement, audit findings, monetary settlements and consumer recoveries. Separating settlements and recoveries from a major pending assessment prevents an inflated enforcement total.

## GOALPOST / RESPONSE

FERC presents the report as evidence of consumer protection, market integrity and compliance. The tests are settlement payment and disgorgement records, resolution of the American Efficient matter and any appeals, documented implementation of all corrective recommendations, independently verifiable refunds or avoided costs, and later recurrence or compliance measurements.

## MAYBE / THEREFORE

Maybe the reported settlements, refunds and corrective actions deter misconduct and prevent future costs, or the figures may mostly measure agency activity without establishing durable market outcomes. Therefore the report documents FERC's FY2026 enforcement and audit claims; it does not establish that the contested $1.132 billion American Efficient assessment was collected or independently prove program effectiveness.


## SOURCES

- [FERC — 2026 Report on Enforcement](https://www.ferc.gov/sites/default/files/2026-11/2026%20Report%20on%20Enforcement.pdf) — primary annual agency enforcement and audit report
- [FERC — annual enforcement report release](https://ferc.gov/news-events/news/fercs-annual-enforcement-report-highlights-tough-action-shield-consumers-fraud-and) — primary agency summary of reported FY2026 enforcement activity

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
