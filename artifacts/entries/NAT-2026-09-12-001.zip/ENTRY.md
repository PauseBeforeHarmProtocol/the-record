# AP analysis finds most protest-related federal felony-assault cases were dismissed or reduced

**Entry ID:** NAT-2026-09-12-001
**Date:** September 12, 2026
**Checked:** 2026-09-12 6:00 PM EDT
**Evidence state:** Associated Press case-by-case measured analysis, inspected in full through an authorized PBS syndication; cohort outcomes reported, underlying case file set not independently reproduced
**Review state:** current-standard-reviewed

A case-by-case review of 167 arrests found no felony-assault trial convictions in the four-city cohort, while preserving guilty pleas, serious convictions outside the cohort and the Justice Department's case-specific explanation.

## THE FACTS

- The Associated Press tracked the outcomes of 167 arrests arising from protests during summer and fall 2025 in Los Angeles, Chicago, Portland and Washington, cities where President Trump sought or successfully deployed the National Guard. Of those arrests, 102 initially involved felony assault on a federal officer.
- Among the 102 felony-assault cases, AP found that 41% were dismissed and 34% were reduced through misdemeanor pleas. Ten defendants pleaded guilty to felony assault, and nine received prison sentences. The last three felony-assault cases in the cohort were scheduled for trial in fall 2026.
- All 12 felony-assault cases in the cohort that had reached trial ended in acquittal, mistrial or dismissal. AP also reported that fewer than half of protesters charged with felony or misdemeanor assault were convicted, compared with an 82% conviction rate by trial or plea among all federal felony and misdemeanor assault defendants in 2024, using Administrative Office of the U.S. Courts data.
- The four-city cohort did not include every protest prosecution. AP separately identified prison sentences for arson and obstruction within the 167 arrests and serious convictions in Texas and Spokane outside the study group. The outcome counts therefore do not establish that every initial arrest or charge was improper, and the national comparison groups are not identical.
- The Justice Department said prosecutors were right to prioritize alleged assaults on federal officers, that every case turns on its facts, and that mitigating facts may properly lead prosecutors to reduce or dismiss charges. The U.S. Attorney's Office in Los Angeles said it acted amid violence against officers and voluntarily dismissed some cases after further investigation.

## SIGNIFICANCE

The analysis supplies a measured outcome test for a highly publicized federal crackdown: most felony-assault arrests in the defined four-city cohort did not produce felony convictions, and every completed felony trial failed to yield one. It raises questions about charging quality and deterrence while stopping short of converting aggregate outcomes into findings about individual prosecutorial motive or guilt.

## GOALPOST / RESPONSE

The Justice Department says protecting federal officers justifies prioritizing these cases and that reductions or dismissals can reflect responsible, fact-specific reassessment. The relevant tests are the final three trials, any appellate outcomes, documented charging reviews, comparable case-selection data and whether later prosecutions produce durable convictions without suppressing lawful protest.

## MAYBE / THEREFORE

Maybe the results reflect rushed or overly aggressive charging, or they may partly reflect ordinary reassessment, difficult proof and a cohort selected from unusually contested protests. Therefore AP's case review establishes weak conviction outcomes for this defined group—especially zero felony convictions in 12 completed trials—not that every arrest lacked probable cause, every prosecutor acted politically or assaults on officers did not occur.


## SOURCES

- [Associated Press — outcomes of protest-related federal assault prosecutions](https://apnews.com/article/54db940f84a0e89c61ba53a2eed43a25) — independent case-by-case legal analysis

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
