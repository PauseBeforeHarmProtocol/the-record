# Treasury proposes cutting Banque Misr UAE from U.S. correspondent banking

**Entry ID:** NAT-2026-08-28-006
**Date:** August 28, 2026
**Checked:** 2026-08-28 6:08 PM EDT
**Evidence state:** FinCEN announcement and NPRM, OFAC list update, and independent Reuters and AP reporting; section 311 measure proposed, two related sanctions listings implemented
**Review state:** current-standard-reviewed

FinCEN proposed—not finalized—a section 311 prohibition while OFAC separately implemented sanctions against one manager and one Hong Kong entity.

## THE FACTS

- FinCEN issued a notice of proposed rulemaking finding Banque Misr's five United Arab Emirates branches to be a foreign financial institution of primary money-laundering concern and proposing a USA PATRIOT Act section 311 special measure.
- If finalized, the rule would prohibit U.S. financial institutions from opening or maintaining correspondent accounts for Banque Misr UAE and require due diligence intended to prevent foreign correspondent accounts from processing its transactions. It applies only to the UAE branches, not Banque Misr's operations elsewhere, and remains subject to a 30-day comment period.
- Treasury alleges that the branches processed about $1.8 billion from January 2024 through June 2026 for 103 companies potentially linked to Iranian shadow-banking networks. That transaction characterization is an agency finding in a proposed rule, not an adjudicated criminal judgment.
- In a separate implemented action, OFAC added Bank Melli UAE branch manager Reza Mohammad Taeedi and Hong Kong-based Kameng Trading Limited to the sanctions list. Reuters and AP independently confirmed the distinction between the proposed banking restriction and the immediately operative designations; Egypt's central bank said the proposal does not reach Banque Misr's Egyptian or other overseas operations.

## SIGNIFICANCE

The proposal targets access to dollar clearing through a foreign bank rather than only naming alleged shell companies, potentially extending U.S. financial pressure beyond direct Iranian entities. Its practical reach and banking effects depend on finalization and compliance, while the two OFAC listings already create blocking and transaction consequences.

## GOALPOST / RESPONSE

Treasury says Banque Misr UAE was a major conduit for Iranian shadow banking and that the tailored measure protects the U.S. financial system while avoiding the bank's other operations. The bank and affected governments may contest the evidence, scope, or economic effects. Comments, a final rule, correspondent-bank notices, transaction data, legal challenges, delisting petitions, and sanctions enforcement are the tests.

## MAYBE / THEREFORE

Maybe the narrow UAE-only proposal will close a documented sanctions-evasion channel without broader disruption, or transactions may migrate and some suspected counterparties may prove unrelated to Iran. Therefore the record distinguishes a proposed correspondent-account prohibition from two implemented OFAC listings and does not describe the bank as already cut off by a final rule.


## SOURCES

- [FinCEN — proposed Banque Misr UAE correspondent-account prohibition](https://www.fincen.gov/news/news-releases/fincen-proposes-rule-would-revoke-banque-misr-uaes-correspondent-banking-access) — primary agency announcement of a proposed USA PATRIOT Act section 311 special measure
- [FinCEN — Banque Misr UAE notice of proposed rulemaking](https://www.fincen.gov/system/files/2026-08/Banque-Misr-UAE-NPRM.pdf) — primary proposed rule and money-laundering-concern finding
- [OFAC — August 28 Iran-related and counterterrorism designations](https://ofac.treasury.gov/recent-actions/20260828) — primary sanctions-list update naming one individual and one entity
- [Reuters — U.S. targets Banque Misr UAE and adds Iran-linked sanctions](https://www.reuters.com/business/finance/us-issues-fresh-iran-related-sanctions-war-marks-six-months-2026-08-28/) — independent reporting distinguishing the proposed banking rule from implemented OFAC designations
- [Associated Press — Treasury targets Banque Misr UAE under Iran-pressure campaign](https://apnews.com/article/ae1c438ff169effa0c63a56a93ca23ae) — independent reporting on the proposal, 30-day comment period, scope, and Egyptian response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
