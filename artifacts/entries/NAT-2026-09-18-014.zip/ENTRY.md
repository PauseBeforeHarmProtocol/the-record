# Justice Department revises False Claims Act enforcement policy

**Entry ID:** NAT-2026-09-18-014
**Date:** September 18, 2026
**Checked:** 2026-09-19 6:01 AM EDT
**Evidence state:** DOJ announcement and complete revised Justice Manual sections 1-19.000 and 4-4.111; implemented internal policy with case-level and outcome effects unresolved
**Review state:** current-standard-reviewed

The Justice Manual now limits reliance on nonbinding guidance and directs recurring dismissal review in declined whistleblower suits; case-level effects remain unmeasured.

## THE FACTS

- The Justice Department revised Justice Manual section 1-19.000 to state that enforcement actions must rest on binding legal requirements rather than mere noncompliance with agency guidance. The manual still permits specified evidentiary uses of guidance without giving it the force of law.
- Revised section 4-4.111 directs attorneys, when recommending nonintervention in a False Claims Act qui tam case, to assess whether dismissal would serve the government's interests and to reconsider dismissal as litigation progresses.
- The manual lists nonexclusive dismissal factors including meritless, duplicative or opportunistic suits; interference with agency policy; litigation control; classified information; resource costs; and serious procedural errors. It preserves consultation and approval requirements rather than mandating dismissal in every declined case.
- DOJ says the changes strengthen enforcement by focusing resources on binding obligations and meritorious fraud matters. The revisions are implemented internal policy, not a court ruling, a dismissal in a particular case or a measured change in recoveries, whistleblower filings or fraud.

## SIGNIFICANCE

The revisions change how federal lawyers evaluate guidance-based theories and declined whistleblower cases, potentially narrowing some enforcement paths while concentrating resources on claims DOJ views as legally grounded.

## GOALPOST / RESPONSE

DOJ says the policy protects regulated parties from nonbinding guidance while strengthening meritorious False Claims Act enforcement. Dismissal motions, judicial rulings, recoveries, relator participation, processing time and proven fraud outcomes are the tests.

## MAYBE / THEREFORE

Maybe the revisions reduce weak or coercive cases and preserve resources for stronger fraud enforcement, or they may discourage whistleblowers and prematurely end viable cases. Therefore DOJ changed its internal enforcement manual—not that courts adopted its legal views or enforcement outcomes improved.


## SOURCES

- [DOJ — Justice Manual revisions for False Claims Act enforcement](https://www.justice.gov/opa/pr/doj-revises-justice-manual-strengthen-false-claims-act-enforcement) — primary policy announcement
- [Justice Manual 1-19.000 — limitations on guidance documents](https://www.justice.gov/jm/1-19000-limitation-issuance-guidance-documents-1) — primary implemented enforcement policy
- [Justice Manual 4-4.111 — dismissal of civil qui tam actions](https://www.justice.gov/jm/jm-4-4000-commercial-litigation#4-4.111) — primary implemented enforcement policy

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
