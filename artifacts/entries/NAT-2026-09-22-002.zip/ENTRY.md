# FDIC proposes State Bank Parity rule for cross-state services

**Entry ID:** NAT-2026-09-22-002
**Date:** September 22, 2026
**Checked:** 2026-09-22 5:57 AM EDT
**Evidence state:** complete Federal Register proposed rule; proposed interpretation, limits, assumptions and comment deadline documented, final rule and effects unresolved
**Review state:** current-standard-reviewed

The proposal would generally give out-of-state state banks the same host-state-law treatment as national banks, including when services are provided without a branch; it does not itself preempt a specific state law.

## THE FACTS

- The FDIC published a proposed State Bank Parity rule on September 22, with comments due November 23, 2026. It remains a proposal with no final rule or effective date.
- Under the proposal, when a host-state law does not apply to an out-of-state national bank, that law likewise would not apply to an out-of-state state bank providing services in the host state, whether or not the state bank has a branch there; the bank's home-state law would instead apply.
- The proposed interpretation would cover host-state laws in areas named by the regulation, including community reinvestment, consumer protection, fair lending and establishment of intrastate branches. The FDIC says the rule would not determine that any particular state law is federally preempted and would not change state-bank loan-interest authority under section 27 of the Federal Deposit Insurance Act.
- The FDIC identifies online and mobile banking and litigation over Illinois's Interchange Fee Prohibition Act as reasons to clarify parity. Its analysis estimates possible compliance-cost and interchange-fee effects under assumptions about that law, but says precise effects are uncertain; no avoided cost, merchant transfer or consumer outcome has yet been measured under the proposed rule.

## SIGNIFICANCE

The proposal would affect which state's consumer, fair-lending and banking rules govern state-chartered banks serving customers across state lines. It could reduce competitive differences with national banks while also limiting application of some host-state protections, depending on separate preemption law and the final rule.

## GOALPOST / RESPONSE

The FDIC says Congress intended parity between national and state banks and that branchless digital banking makes the existing text uncertain. The scope of applicable state laws, preemption decisions, final language, litigation, bank compliance changes and measured effects on merchants and consumers are the tests.

## MAYBE / THEREFORE

Maybe the proposal removes an unintended charter disadvantage and creates predictable nationwide service rules, or it may displace host-state safeguards without sufficient local accountability. Therefore the FDIC has proposed a parity interpretation for public comment—not preempted a named state law, finalized the rule or established its economic effects.


## SOURCES

- [Federal Register — FDIC proposed State Bank Parity rule](https://www.govinfo.gov/content/pkg/FR-2026-09-22/pdf/2026-19310.pdf) — primary proposed rule (91 FR 60018; FR Doc. 2026-19310)

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
