# Appeals court largely preserves block on ideological conditions for transportation and homelessness grants

**Entry ID:** NAT-2026-08-25-003
**Date:** August 25, 2026
**Checked:** 2026-08-25 6:00 PM EDT
**Evidence state:** published Ninth Circuit ruling independently reported by Reuters; injunction largely affirmed and partially remanded for narrowing
**Review state:** current-standard-reviewed

The Ninth Circuit held that HUD and Transportation lacked authority for most new conditions attached after billions of dollars in grants had been awarded.

## THE FACTS

- A 2–1 panel of the U.S. Court of Appeals for the Ninth Circuit largely upheld an injunction preventing the Departments of Housing and Urban Development and Transportation from conditioning federal grants to 31 local governments and agencies on alignment with administration positions.
- The challenged conditions concerned federal anti-discrimination law, 'gender ideology,' elective abortion, illegal immigration, and verification of some beneficiaries' immigration status. The majority said most conditions exceeded authority granted by Congress and were imposed after the funds had been awarded.
- The court remanded for the district judge to narrow the injunction as to compliance with federal anti-discrimination law. Judge Patrick Bumatay dissented, arguing that the agencies acted lawfully and that courts were intruding on executive discretion over federal spending.

## SIGNIFICANCE

The ruling keeps billions of dollars in transportation infrastructure and homelessness-program funding insulated from most of the administration's new conditions while litigation continues. It also limits the use of executive orders and agency grant terms to redirect congressionally authorized spending after awards.

## GOALPOST / RESPONSE

The administration's position is that agencies may use grant conditions to ensure federal funds do not support unlawful discrimination, abortion, unauthorized immigration, or policies it characterizes as gender ideology. The majority distinguished lawful program administration from conditions that exceeded statutory authority; the dissent favored broader executive discretion. Further review and the narrowed remand order remain evidence tests.

## MAYBE / THEREFORE

Maybe the government will obtain rehearing or Supreme Court review, and a narrower anti-discrimination condition may survive on remand. Therefore the record says the appellate court largely preserved the existing block, not that every condition was permanently invalidated.


## SOURCES

- [County of King v. Turner — Ninth Circuit opinion on federal grant conditions](https://fingfx.thomsonreuters.com/gfx/legaldocs/mopazgdxlva/08252026grants.pdf) — primary published appellate opinion
- [Reuters — Ninth Circuit largely preserves block on transportation and homelessness grant conditions](https://www.reuters.com/legal/government/trump-cannot-impose-conditions-transportation-homelessness-grants-us-appeals-2026-08-25/) — independent reporting on the appellate ruling, dissent, and remand

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
