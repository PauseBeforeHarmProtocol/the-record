# DEA temporary Schedule I order for three opioid-active compounds takes effect

**Entry ID:** NAT-2026-08-25-004
**Date:** August 25, 2026
**Checked:** 2026-08-26 12:02 PM EDT
**Evidence state:** published Federal Register temporary scheduling order with an August 26 effective date, plus DOJ's official scope and enforcement explanation; binding controls effective and enforcement-discretion boundary stated explicitly
**Review state:** current-standard-reviewed

Federal Register publication made the two-year order effective August 26; DOJ's trace-MGPI enforcement discretion remains a policy, not a legal exemption.

## THE FACTS

- The Drug Enforcement Administration issued a temporary scheduling order placing mitragynine pseudoindoxyl, MGM-15, and MGM-16, including specified chemical variants, in Schedule I of the Controlled Substances Act.
- The order was published in the Federal Register and took effect on August 26, 2026. It subjects unauthorized manufacture, distribution, import, export, research, and possession to Schedule I controls and sanctions through August 26, 2028 unless extended or made permanent.
- DEA said the compounds are potent mu-opioid-receptor agonists and cited market availability, misuse, dependence, and respiratory-depression risks. DOJ said the action targets manufactured or concentrated products rather than traditional botanical kratom and announced enforcement discretion for incidental trace MGPI in an otherwise botanical product; that policy is not a legal exemption and does not cover MGM-15, MGM-16, or intentionally added MGPI.

## SIGNIFICANCE

Federal Register publication converted the filed order into a nationwide controlled-substance restriction with criminal, civil, registration, inventory, and research consequences. The distinction between the scheduled molecules, ordinary botanical material, and DOJ's nonbinding enforcement discretion is central to consumer notice and consistent enforcement.

## GOALPOST / RESPONSE

DOJ says emergency scheduling is needed to prevent a broader opioid threat and that enforcement discretion protects traditional botanical products containing only incidental trace MGPI. The order cites preclinical evidence and emerging toxicology and market data; researchers and botanical-product sellers may contest the scientific boundary or seek clearer testing thresholds. Federal Register publication, enforcement practice, toxicology data, and any permanent-scheduling proceeding are the evidence tests.

## MAYBE / THEREFORE

Maybe the order will remove high-potency designer products without materially affecting traditional botanical kratom because DOJ has announced trace-level enforcement discretion. Therefore the record now describes the Schedule I controls as effective, while continuing to distinguish the binding order from the nonbinding enforcement policy.


## SOURCES

- [Drug Enforcement Administration — temporary Schedule I order for mitragynine pseudoindoxyl, MGM-15, and MGM-16](https://public-inspection.federalregister.gov/2026-17429.pdf) — primary temporary scheduling order filed for public inspection
- [Justice Department — emergency scheduling announcement and enforcement policy](https://www.justice.gov/opa/pr/justice-department-announces-emergency-scheduling-three-potent-opioid-compounds) — official administration announcement, rationale, and enforcement explanation
- [HHS and FDA — scientific and procedural background on DEA's temporary scheduling process](https://www.hhs.gov/press-room/hhs-fda-support-dea-7-oh-scheduling.html) — official scientific recommendation and administration rationale
- [Federal Register — temporary Schedule I placement of MGPI, MGM-15, and MGM-16](https://www.federalregister.gov/documents/2026/08/26/2026-17429/schedules-of-controlled-substances-temporary-placement-of-mitragynine-pseudoindoxyl-mgm-15-and) — primary published temporary scheduling order and effective date

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
