# Federal Railroad Administration finalizes ten-rule deregulatory package

**Entry ID:** NAT-2026-08-31-004
**Date:** August 31, 2026
**Checked:** 2026-08-31 5:58 AM EDT
**Evidence state:** primary Transportation Department rule index plus representative Federal Railroad Administration final rules covering brake requirements, older freight cars, horn patterns and roadway workplace safety; package finalized, operational and safety effects not yet measured
**Review state:** current-standard-reviewed

The package changes brake, horn, older-car, workplace-safety, training and reporting requirements while converting several longstanding waivers into general rules.

## THE FACTS

- The Federal Railroad Administration published ten final rules on August 31 under the administration's deregulatory directives. The actions cover brake maintenance and inspection, three-dimensional simulation training, locomotive-horn practices, freight cars more than 50 years old, end-of-car cushioning units, wheel-set diameter tolerances, roadway workplace safety, and accident-reporting forms and deadlines.
- One rule incorporates longstanding brake-system waivers into standards for passenger and freight equipment. Another permits instructor-led computer-based three-dimensional simulation to satisfy the hands-on portion of periodic brake-system refresher training. FRA says these changes make successful waivers permanent and can expose trainees to randomized scenarios with real-time feedback; rail labor commenters raised concerns that longer or heavier trains justify more frequent physical inspection and hands-on training.
- A separate final rule replaces advance special approval for freight cars more than 50 years old or with listed restricted components with notice to FRA and the ordinary Part 215 safety requirements. FRA says railroads will avoid petition and inspection costs; the rule does not exempt the cars from general freight-car safety standards.
- Two horn rules allow a single blast in specified stopped-near-crossing circumstances and clarify railroad discretion at passenger stations. The crossing rule requires the engineer to judge that the nearby crossing is unobstructed and that gates are fully lowered or no conflicting motorist or pedestrian traffic is approaching. A rail union warned that changing the familiar pattern could reduce warning clarity; FRA cited a longstanding waiver without identified adverse safety effects.
- The remaining rules revise accident reporting and retention, retire two forms, expand certain alternating-current locomotive wheel-diameter tolerances, make waiver-based relief for functioning cushioning units permanent, and repeal specified roadway workplace requirements while creating a public special-approval path for equivalent or better bridge-worker safety. The package finalizes legal requirements; it does not establish that accident, injury, maintenance or compliance rates have improved.

## SIGNIFICANCE

Publishing ten related final rules at once materially shifts federal rail oversight toward waiver codification, carrier and engineer discretion, electronic reporting and reduced approval requirements. Some changes are technical or preserve existing practice, while others alter safety-process safeguards; their combined effect should be measured rather than inferred from the administration's deregulatory label.

## GOALPOST / RESPONSE

FRA says the rules remove obsolete burdens, codify waivers with acceptable safety records, improve training flexibility and retain baseline safety protections. Labor commenters and safety advocates raised concerns about less hands-on training, altered horn warnings, older equipment and reduced inspection safeguards. Waiver histories, implementation guidance, defects, crossing incidents, brake failures, report completeness, enforcement actions and NTSB or FRA trend data are the tests.

## MAYBE / THEREFORE

Maybe the package mainly converts mature waivers and outdated paperwork into clearer rules without weakening safety, or the cumulative loss of approvals and prescribed practices may become consequential under real operating conditions. Therefore the record treats the ten notices as one coordinated deregulatory package, preserves important limits and objections, and does not count each technical rule as a separate event or claim a safety outcome before data exist.


## SOURCES

- [Department of Transportation — August 31 rulemaking index](https://www.transportation.gov/regulations/federal-register-documents) — primary department index enumerating the ten Federal Railroad Administration final rules and related transportation actions
- [Federal Register — FRA brake maintenance and inspection amendments](https://www.federalregister.gov/documents/2026/08/31/2026-17784/amendments-to-brake-system-maintenance-and-inspection-requirements) — primary final rule incorporating longstanding brake-system waivers and recording labor comments
- [Federal Register — FRA rule for freight cars more than 50 years old](https://www.federalregister.gov/documents/2026/08/31/2026-17787/repealing-special-approval-requirement-for-freight-cars-more-than-50-years-old) — primary final rule replacing special approval with notice while retaining general freight-car safety standards
- [Federal Register — FRA grade-crossing horn-pattern relief](https://www.federalregister.gov/documents/2026/08/31/2026-17783/regulatory-relief-from-locomotive-horn-sounding-pattern-at-public-highway-rail-grade-crossings) — primary final rule describing the limited single-blast option, safety conditions, comments and agency response
- [Federal Register — FRA roadway workplace safety revisions](https://www.federalregister.gov/documents/2026/08/31/2026-17789/repealing-outdated-railroad-workplace-safety-requirements-and-making-other-improvements) — primary final rule repealing specified obsolete requirements and establishing an alternative bridge-worker safety approval path

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
