# CMS finalizes 2027 Medicare physician payment and Part B policy changes

**Entry ID:** NAT-2026-11-04-002
**Date:** November 4, 2026
**Checked:** 2026-11-05 12:07 AM EST
**Evidence state:** CMS final-rule fact sheet and Federal Register public-inspection record, corroborated by an AHA policy summary
**Review state:** current-standard-reviewed

The final rule sets lower physician conversion factors after a temporary 2026 boost expires and modifies several proposed billing restrictions.

## THE FACTS

- On November 4, CMS issued the CY 2027 Medicare Physician Fee Schedule final rule, CMS-1848-F. The public-inspection document is scheduled for Federal Register publication November 9 and states that the regulations are effective January 1, 2027. This same-day action occurred before the prior archive cutoff and is recorded as a disclosed backfill discovered and inspected in this run.
- CMS set a $32.95 conversion factor for qualifying alternative-payment-model participants, a projected 1.83% decrease from 2026, and a $32.63 factor for other practitioners, a projected 2.31% decrease. CMS attributes much of the year-to-year decline to expiration of a one-year 2.5% statutory increase for 2026; the final factors also include statutory 2027 updates and a budget-neutrality adjustment.
- CMS narrowed its proposed same-day payment reduction. When a separately identifiable office or outpatient evaluation-and-management visit and a zero-day global procedure occur on the same day, the most expensive service will be paid at 100% and the other at 80%; CMS did not extend the final policy to 10- or 90-day global procedures and did not adopt the proposed 50% secondary payment.
- The rule also converts the G2211 visit-complexity add-on to modifier B1 with a 16% increase to the associated E/M code, finalizes remote-monitoring billing changes, delays a contractor-versus-employed-clinical-staff restriction until 2029 and delays the planned end of traditional MIPS reporting until 2031.
- The administration describes the rule as supporting quality, efficiency, beneficiary empowerment and innovation. The payment percentages and savings claims are finalized rate calculations and projections; no 2027 access, utilization, clinician-participation or quality outcome has yet been measured.

## SIGNIFICANCE

The rule changes national Medicare payment rates and billing rules for physicians and other practitioners. The conversion-factor declines and practice changes are operative policy, while their effects on beneficiary access, clinician participation, practice finances and care quality remain prospective and should be measured after implementation.

## GOALPOST / RESPONSE

CMS says the rule should improve quality, efficiency and innovation and says the same-day E/M reduction addresses duplicated payment. Public comments led CMS to narrow that policy substantially. The tests are actual 2027 payment, participation, access, utilization and quality data—not the agency's projections alone.

## MAYBE / THEREFORE

Maybe later legislation restores a temporary payment increase, implementation guidance changes operational burden, or the final mix of services offsets some headline conversion-factor declines. Therefore the archive records finalized January 2027 payment and billing policy, not a measured decline in physician access or care quality.


## SOURCES

- [CMS — CY 2027 Medicare Physician Fee Schedule final rule fact sheet](https://www.cms.gov/newsroom/fact-sheets/calendar-year-cy-2027-medicare-physician-fee-schedule-final-rule) — primary final-rule fact sheet stating payment rates, effective posture and finalized policies
- [Federal Register public inspection — CMS-1848-F physician fee schedule final rule](https://www.federalregister.gov/public-inspection/2026-22743/medicare-and-medicaid-programs-calendar-year-2027-payment-policies-under-the-physician-fee-schedule) — primary public-inspection record identifying the final rule, scheduled publication and effective date
- [AHA — CMS issues CY 2027 physician fee schedule final rule](https://www.aha.org/news/headline/2026-11-04-cms-issues-cy-2027-physician-fee-schedule-final-rule) — stakeholder summary corroborating finalized payment and program provisions

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
