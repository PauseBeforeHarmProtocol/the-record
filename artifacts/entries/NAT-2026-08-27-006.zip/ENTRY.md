# HHS and USDA announce up to $127.5 million in school-nutrition initiatives

**Entry ID:** NAT-2026-08-27-006
**Date:** August 24–27, 2026
**Checked:** 2026-08-27 11:59 AM EDT
**Evidence state:** two primary HHS announcements with amounts and prospective schedules, plus independent Reuters context on a separate prior cancellation; initiatives announced, recipient awards and outcomes pending
**Review state:** current-standard-reviewed

The announced ceiling combines cafeteria infrastructure, Farm to School grants, and a research-and-demonstration pilot; recipient awards and measured meal outcomes remain pending.

## THE FACTS

- HHS and USDA announced Harvest to Hallways, including up to $70 million for school-cafeteria infrastructure and up to $25 million in additional fiscal-year 2026 Farm to School grants intended to connect schools with local producers and increase access to minimally processed food.
- HHS separately announced a $32.5 million one-time DEPEND initiative led by the Agency for Healthcare Research and Quality and the National Institutes of Health for school-meal research and demonstration projects. It described anticipated awards of $75,000 to $2.5 million, said applications would open soon, and expected first awards in October.
- The components total an announced ceiling of up to $127.5 million. The announcements do not identify completed recipient awards or expenditures, and any additional DEPEND funding in fiscal year 2027 remains contingent on available funds.
- The administration says the initiatives will replace highly processed foods with nutrient-dense meals, modernize kitchens, support farmers, and test scalable approaches. For context, Reuters reported in May 2025 that the administration had canceled a separate $660 million Local Food for Schools program; the record does not assume the new initiatives replace that program dollar-for-dollar or serve the same recipients.

## SIGNIFICANCE

The initiatives put federal resources behind the administration's stated school-food agenda through infrastructure, procurement, and evidence-building rather than nutritional guidance alone. Their scale and durability will depend on the final solicitations, recipient selection, implementation, later appropriations, and measurable effects on food quality, participation, cost, and local purchasing.

## GOALPOST / RESPONSE

HHS and USDA say the programs will help schools serve more real, nutritious food while supporting producers and generating replicable evidence. The strongest countervailing question is whether the smaller new funding streams offset prior cuts and produce durable improvements rather than short pilots. Award notices, kitchen upgrades, procurement data, meal composition, student participation, waste, cost, and health measures are the tests.

## MAYBE / THEREFORE

Maybe targeted kitchen investments and competitive pilots can produce more useful and sustainable change than a larger procurement program, or applications and execution may fall short of the announced ceilings. Therefore the record reports up to $127.5 million announced—not awarded or spent—and keeps the canceled $660 million program as context rather than treating unlike initiatives as interchangeable.


## SOURCES

- [HHS and USDA — Harvest to Hallways school-nutrition funding announcement](https://www.hhs.gov/press-room/hhs-usda-harvest-to-hallways-healthier-school-meals.html) — primary announcement of prospective cafeteria-infrastructure and Farm to School funding
- [HHS — DEPEND school-meal pilot funding announcement](https://www.hhs.gov/press-room/hhs-depend-initiative-healthier-school-meals-real-food.html) — primary announcement of a one-time pilot initiative, anticipated award range, and prospective schedule
- [Reuters — school-meal policy and canceled local-food funding context](https://www.reuters.com/business/healthcare-pharmaceuticals/rfk-jr-calls-healthier-school-meals-trump-cancels-program-that-funded-them-2025-05-20/) — independent reporting providing countervailing federal school-food funding context

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
