# U.S. public debt exceeds $40 trillion as borrowing-cost pressure persists

**Entry ID:** NAT-2026-09-02-005
**Date:** August 20–September 2, 2026
**Checked:** 2026-09-02 11:57 AM EDT
**Evidence state:** primary Treasury daily debt measurement and independent Reuters fiscal analysis with attributed CBO, GAO and White House positions; threshold measured, causal allocation and future trajectory disputed
**Review state:** current-standard-reviewed

Treasury data establish the threshold; the cumulative total spans administrations and Congresses and does not by itself assign the full debt to Trump.

## THE FACTS

- Treasury's Debt to the Penny dataset reported total public debt outstanding of $40,033,256,786,764.37 on August 20, the first daily reading above $40 trillion.
- Reuters reported the threshold on September 2 as an effectiveness checkpoint against President Trump's promises of fiscal restraint. The total is cumulative debt built under many presidents and Congresses; crossing the threshold during Trump's second term does not mean his administration alone incurred the full amount.
- Reuters cited the Congressional Budget Office's estimate that the administration's tax and immigration law would add about $4.7 trillion to debt over a decade. It also reported that the 2025 deficit narrowed only marginally while total debt continued to rise and that high borrowing costs constrain future fiscal choices.
- The White House said Trump was the first president to seriously address waste, fraud and abuse and pointed to workforce and program reductions. Reuters also cited a Government Accountability Office assessment that roughly $110 billion in claimed DOGE savings rested on overstated or unverifiable claims; neither statement by itself supplies a complete causal accounting of the debt level.

## SIGNIFICANCE

Passing $40 trillion is a measured fiscal condition, not merely a forecast, and rising debt-service costs can crowd out programs, tax relief or crisis response. Accountability requires separating the inherited stock of debt from the incremental effects of current laws, spending, revenues and interest rates.

## GOALPOST / RESPONSE

The administration says spending reductions and anti-waste efforts demonstrate fiscal discipline, while critics point to the projected cost of its tax and immigration law and limited deficit improvement. Annual deficits, net interest costs, independently verified savings, enacted revenues and spending, CBO re-estimates and the debt-to-GDP path are the tests—not a single cumulative headline number.

## MAYBE / THEREFORE

Maybe future growth, revenues and durable spending reductions will slow the debt trajectory, or current tax, spending and interest-cost dynamics may push borrowing higher. Therefore the record confirms that gross federal debt exceeded $40 trillion and that this occurred despite a restraint pledge—not that Trump alone created the accumulated debt, that every administration savings claim is false or that a fiscal crisis has already occurred.


## SOURCES

- [Treasury Fiscal Data — Debt to the Penny](https://fiscaldata.treasury.gov/datasets/debt-to-the-penny/) — primary daily measurement of total public debt outstanding when it first exceeded $40 trillion
- [Reuters — U.S. debt tops $40 trillion despite Trump restraint pledge](https://www.reuters.com/world/us/trump-pledged-fiscal-restraint-instead-debt-tops-40-trillion-borrowing-costs-2026-09-02/) — independent fiscal analysis of the measured debt threshold, borrowing costs and competing responsibility claims

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
