# Trump signs satellite-alert and Sacramento land-conveyance bills

**Entry ID:** NAT-2026-10-22-005
**Date:** October 22, 2026
**Checked:** 2026-10-22 6:03 PM EDT
**Evidence state:** official White House enactment notice and GovInfo bill text for the satellite-alert duties; no completed FCC rule, provider deployment or Interior conveyance was located
**Review state:** current-standard-reviewed

H.R. 7022 requires an FCC satellite-alert rulemaking, while H.R. 952 directs Interior to convey a federal reversionary interest; enactment does not complete either implementation process.

## THE FACTS

- The White House announced that Trump signed H.R. 7022, the Mystic Alerts Act, and H.R. 952, the Reversionary Interest Conveyance Act, into law on October 22.
- The Mystic Alerts Act requires commercial mobile providers that voluntarily participate in wireless emergency alerts to elect whether they will also transmit alerts by satellite. Providers electing satellite delivery must follow FCC requirements, while providers declining must notify subscribers; consumers retain specified opt-out protections.
- The act directs the FCC to publish a notice of proposed rulemaking within six months and, in consultation with Homeland Security and FEMA, issue a final technical and interoperability rule within 12 months. Signing enacted those duties but did not itself activate satellite alerting for every provider or device.
- H.R. 952 directs Interior to convey the United States' reversionary interest in certain Sacramento, California land. The White House signing notice establishes enactment; the conveyance itself, any required requests or payments and resulting land-use consequences were not documented as completed by cutoff.

## SIGNIFICANCE

The two statutes create concrete federal duties in emergency communications and public-land title, but their operational consequences remain downstream. The alert law's reach depends on provider elections, FCC standards, satellite capability and device support; the land law requires administrative conveyance steps.

## GOALPOST / RESPONSE

Supporters describe satellite alerts as a resilience tool when terrestrial networks fail, while the land bill is framed as resolving a federal property interest. The tests are timely FCC proposed and final rules, provider elections, interoperability and delivered-alert performance, plus a documented Interior conveyance and its terms.

## MAYBE / THEREFORE

Maybe the alert framework expands life-saving coverage and the land conveyance removes a narrow title constraint, or voluntary participation and technical limits may narrow alert benefits while the land transfer remains administrative. Therefore both bills are enacted, but neither nationwide satellite delivery nor the Sacramento conveyance was completed by cutoff.


## SOURCES

- [White House — H.R. 952 and H.R. 7022 signed into law](https://www.whitehouse.gov/briefings-statements/2026/10/congressional-bills-h-r-952-and-h-r-7022-signed-into-law/) — official enactment notice identifying the two signed bills and their purposes
- [GovInfo — H.R. 7022 Mystic Alerts Act text](https://www.govinfo.gov/content/pkg/BILLS-119hr7022ih/xhtml/BILLS-119hr7022ih.html) — official bill text specifying provider elections and FCC rulemaking deadlines

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
