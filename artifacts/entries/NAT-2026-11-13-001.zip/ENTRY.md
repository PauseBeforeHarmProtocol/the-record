# Second Circuit invalidates $73.5 million New York highway-funding penalty

**Entry ID:** NAT-2026-11-13-001
**Date:** November 13, 2026
**Checked:** 2026-11-13 12:05 PM EST
**Evidence state:** Reuters report of the Second Circuit ruling and operative reasoning, supported by the appellate docket, New York petition and FMCSA final determination; ruling established, opinion PDF and post-ruling disbursement not independently retrieved by cutoff
**Review state:** current-standard-reviewed

The appellate court held that Transportation exceeded its authority and denied fair notice when it tied highway funds to the state's handling of non-domiciled commercial licenses.

## THE FACTS

- The U.S. Court of Appeals for the Second Circuit invalidated the Department of Transportation's April decision to withhold $73,502,543—4% of New York's fiscal 2027 National Highway Performance Program and Surface Transportation Block Grant funds—over the state's issuance of some non-domiciled commercial driver's licenses.
- Reuters reported that the court said the department's approach ran afoul of fair-notice principles, departed from the regulatory text and underestimated the complexity of the licensing rules. The November 13 opinion itself was not independently retrieved by cutoff; the docket, underlying agency determination and New York petition were inspected.
- FMCSA said an audit sample found that 101 of 200 non-domiciled CDL records had expiration dates later than the corresponding lawful-presence documents. Its April final determination ordered corrective steps and said a continued failure could expose another $147,005,086—8%—in the following fiscal year.
- New York argued that the agency misread the rules that governed the licenses and lacked authority to impose the funding penalty on that basis. The appellate ruling invalidated this withholding decision; the inspected material did not establish that funds had already been restored or disbursed.
- The administration framed the audit and penalty as enforcement of federal licensing requirements and a public-safety safeguard. The ruling addresses legal authority and notice under the governing framework rather than independently measuring the safety performance of the affected drivers.

## SIGNIFICANCE

The decision blocks a large federal funding sanction and constrains the department's use of highway grants to enforce its interpretation of commercial-license rules. It is a judicial check on this penalty, not a blanket prohibition on later sanctions issued under clearer authority or rules.

## GOALPOST / RESPONSE

DOT and FMCSA can respond through rehearing, further appeal, a legally supported new determination or prospective rules that give states clear notice. The tests are the mandate and any remand order, actual restoration of funds, any renewed enforcement instrument, license corrections and measured safety outcomes.

## MAYBE / THEREFORE

Maybe the ruling principally constrains an old regulatory interpretation while a clearer prospective rule can support future enforcement, or it may expose a broader mismatch between the funding sanction and the governing statute and regulations. Therefore the record establishes that this $73.5 million withholding decision was judicially invalidated—not that every challenged license was valid, that the funds were already paid or that future lawful sanctions are barred.


## SOURCES

- [Trump cannot withhold highway funding from New York, court says](https://www.reuters.com/world/trump-cannot-withhold-highway-funding-new-york-court-says-2026-11-13/) — independent reporting
- [New York final determination on non-domiciled commercial driver licenses](https://www.transportation.gov/sites/dot.gov/files/2026-04/FMCSA%20New%20York%20Final%20Determination%204.16.2026.pdf) — agency final determination
- [State of New York v. U.S. Department of Transportation petition for review](https://ag.ny.gov/sites/default/files/court-filings/state-of-new-york-new-york-state-department-of-motor-vehicles-v-united-states-department-of-transportation-et-al-petition-for-review-2026.pdf) — court petition
- [State of New York v. United States Department of Transportation, No. 26-1097](https://www.courtlistener.com/docket/73244048/state-of-new-york-v-united-states-department-of-transportation/) — appellate docket

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
