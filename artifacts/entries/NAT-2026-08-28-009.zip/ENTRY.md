# Trump administration appeals Hudson Tunnel funding injunction

**Entry ID:** NAT-2026-08-28-009
**Date:** June 29–August 28, 2026
**Checked:** 2026-08-28 6:08 PM EDT
**Evidence state:** federal case docket containing the June merits order and appeal history plus independent Reuters reporting; appeal filed, injunction and payment obligation remain unless stayed or reversed
**Review state:** current-standard-reviewed

The appeal challenges an order requiring continued grant payments for the $16 billion project; funding remains ordered unless appellate relief changes that posture.

## THE FACTS

- The administration appealed a June 29 federal order that vacated the Transportation Department's September 2025 suspension of Gateway Development Commission grants and permanently barred reliance on that suspension to withhold those grant funds.
- The $16 billion Hudson Tunnel project would build a new passenger-rail tunnel between New Jersey and Manhattan and rehabilitate the existing Hurricane Sandy-damaged tunnel. Reuters reported approximately $15 billion in federal support, about $2 billion spent, and more than 200,000 daily riders using the affected corridor.
- Transportation stopped payments in October 2025 while reviewing compliance with restrictions on diversity, equity, and inclusion policies. A February court order restarted payments, construction resumed after $235 million was released, and the June judgment made the grant relief permanent while dismissing separate loan claims for lack of jurisdiction.
- Trump has opposed the project, cited cost concerns, and previously said it was terminated. The August 28 filing seeks appellate reversal; it does not itself stay the injunction, terminate the grants, recover spent funds, or halt construction.

## SIGNIFICANCE

The appeal continues an executive-congressional and regional dispute over one of the country's largest infrastructure projects and whether the administration may suspend previously awarded grants through compliance review. The practical question is whether payments and construction continue during appellate litigation.

## GOALPOST / RESPONSE

The administration says compliance concerns and cost risks justify review of the awards and asks the appeals court to reverse the injunction. New York, New Jersey, and the Gateway commission say binding grants cannot be frozen for unrelated policy leverage and that delay threatens a nationally important rail link. Stay motions, payment records, construction progress, Second Circuit rulings, cost updates, and the parallel Court of Federal Claims case are the tests.

## MAYBE / THEREFORE

Maybe appellate review will identify lawful grounds for a narrower funding suspension, or the permanent injunction will be affirmed and payments will continue. Therefore the record reports an appeal from a grant-funding injunction—not a new funding cutoff, final appellate loss, completed tunnel, or guarantee against future cost overruns.


## SOURCES

- [State of New Jersey v. U.S. Department of Transportation — Gateway funding docket](https://www.courtlistener.com/docket/72228444/state-of-new-jersey-v-united-states-department-of-transportation/) — primary federal case docket containing the permanent-injunction order and subsequent appeal history
- [Reuters — Trump administration appeals Hudson Tunnel funding order](https://www.reuters.com/world/us-appeals-ruling-requiring-continued-payments-16-billion-new-york-tunnel-2026-08-28/) — independent reporting on the appeal, funding posture, project scale, and administration rationale

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
