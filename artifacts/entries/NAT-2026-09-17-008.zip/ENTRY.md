# Russia and China veto U.S. bid to extend UN Iran sanctions monitoring

**Entry ID:** NAT-2026-09-17-008
**Date:** September 17, 2026
**Checked:** 2026-09-18 5:59 AM EDT
**Evidence state:** independent Associated Press and Reuters reporting on the recorded Security Council outcome and legal scope; extension vetoed, underlying sanctions retained
**Review state:** current-standard-reviewed

The 11–2 vote ended the expert-panel mandate; the underlying Security Council sanctions remain in force.

## THE FACTS

- Russia and China vetoed a U.S.-drafted Security Council resolution that would have extended the mandate of the independent expert panel monitoring UN sanctions on Iran.
- The vote was 11 in favor and two against, with Pakistan and Somalia abstaining. Because two permanent members voted no, the extension failed despite the numerical majority.
- The veto ended the monitoring panel's mandate but did not repeal the underlying Security Council sanctions. Reuters reported that the panel had not operated during the preceding year because members could not agree on expert appointments.
- The United States argued that independent monitoring was needed to investigate violations; Russia and China opposed the extension. The result establishes a failed U.S. proposal and loss of the panel mandate, not removal of substantive sanctions or proof about alleged violations.

## SIGNIFICANCE

The vote removes an independent reporting mechanism from an already contested sanctions regime, reducing a formal source of verification while leaving the legal restrictions intact. The practical effect depends on alternative monitoring and enforcement.

## GOALPOST / RESPONSE

The United States said the panel was needed for credible, independent oversight; Russia and China rejected extension. Future Security Council action, alternative reporting, national enforcement records and documented sanctions violations are the tests.

## MAYBE / THEREFORE

Maybe member states and UN bodies can sustain monitoring through other channels, or the loss of the panel may make violations harder to verify and enforce. Therefore the resolution failed and the panel mandate ended—not the underlying sanctions themselves.


## SOURCES

- [Associated Press — Russia and China veto extension of UN Iran sanctions monitoring panel](https://apnews.com/article/c509e344bc45ba87670b9a668afbbb49) — independent reporting on the Security Council vote and legal scope
- [Reuters — Russia and China end mandate for independent monitoring of UN Iran sanctions](https://www.reuters.com/world/china/russia-china-end-mandate-independent-monitoring-un-sanctions-iran-2026-09-17/) — independent reporting on the Security Council vote and prior panel inactivity

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
