# United States formally withdraws from European anti-corruption watchdog

**Entry ID:** NAT-2026-09-29-009
**Date:** September 29, 2026
**Checked:** 2026-09-30 6:00 AM EDT
**Evidence state:** Council of Europe membership and evaluation records plus Associated Press reporting carrying direct confirmations and stated rationales from the Council and State Department; withdrawal confirmed, costs and consequences not yet measured
**Review state:** current-standard-reviewed

The administration notified the Council of Europe that it was leaving GRECO, ending U.S. participation in a peer-review system it had joined in 2000.

## THE FACTS

- The Council of Europe said the United States formally notified it on September 28 that it would leave the Group of States against Corruption, known as GRECO. The State Department confirmed the withdrawal on September 29.
- GRECO monitors members' compliance with anti-corruption standards through mutual evaluation and follow-up. The United States joined in 2000 and had undergone five evaluation rounds covering matters including public integrity, judges, prosecutors, party financing and law enforcement.
- The State Department said participation required an annual contribution and did not provide tangible national-security benefits. It said the department would instead prioritize visa restrictions, sanctions and targeted foreign assistance aimed at corruption that threatens U.S. security or prosperity.
- The Council of Europe called the United States a valuable contributor and said GRECO remained open to future cooperation. Associated Press reported that Russia and Belarus were the only prior states to leave the group.
- The withdrawal ends participation in this peer-review mechanism. It does not withdraw the United States from every anti-corruption treaty or monitoring system, demonstrate savings beyond the unspecified annual contribution, or measure the effectiveness of the alternative tools.

## SIGNIFICANCE

Leaving GRECO removes one external peer-review and recommendation channel for U.S. anti-corruption policy and continues the administration's broader retreat from multilateral bodies. The practical effect depends on what monitoring, cooperation and enforcement replace it.

## GOALPOST / RESPONSE

The State Department says GRECO produced no tangible national-security benefit and that targeted sanctions, visa restrictions and assistance are higher-impact tools. The strongest response is that peer review can expose domestic integrity gaps and facilitate shared standards that unilateral enforcement does not replace. Future U.S. evaluations, contributions, sanctions, investigations and cooperation with GRECO members are the tests.

## MAYBE / THEREFORE

Maybe the United States can maintain or improve anti-corruption enforcement through other treaties and targeted tools at lower cost, or ending peer review may reduce transparency, reciprocal scrutiny and international coordination. Therefore the record establishes a formal withdrawal from GRECO—not abandonment of every anti-corruption obligation or proof that either approach produces better outcomes.


## SOURCES

- [Council of Europe — GRECO United States evaluation record](https://www.coe.int/en/web/greco/evaluations/usa) — official membership and peer-evaluation record
- [State Department — Recognizing GRECO's 25th anniversary](https://2021-2025.state.gov/recognizing-the-25th-anniversary-of-the-council-of-europes-group-of-states-against-corruption/) — archived official description of U.S. participation and GRECO peer review
- [Associated Press — United States withdraws from GRECO](https://apnews.com/article/31f7f0e4bba7bf26dfc99cd2c3a20d16) — independent reporting carrying direct State Department and Council of Europe confirmations

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
