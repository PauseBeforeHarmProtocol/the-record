# Lockheed Martin agrees to $29.5 million federal employment-practice settlements

**Entry ID:** NAT-2026-11-03-005
**Date:** November 3–4, 2026
**Checked:** 2026-11-05 12:05 PM EST
**Evidence state:** primary DOJ and EEOC settlement announcements corroborated by Associated Press reporting and an attributed company denial; settlements announced and signed, implementation outcomes pending
**Review state:** current-standard-reviewed

Two signed settlements resolve federal allegations involving employee referrals and demographic information; Lockheed denies wrongdoing and no court adjudicated the allegations.

## THE FACTS

- The Justice Department and Equal Employment Opportunity Commission announced two agreements under which Lockheed Martin will pay $29.5 million to resolve employment-practice allegations. The Justice Department settlement provides $22 million to the United States over allegations that Lockheed used employee referrals to hire engineers and technicians at some facilities in ways that improperly favored connected candidates and created False Claims Act exposure through federal contract certifications.
- The EEOC settlement provides $7.5 million to more than 1,000 employees who the agency says were required to disclose age, sex, race or ethnicity when referring applicants. EEOC says the agreement also requires policy changes, training, recordkeeping, reporting and agency monitoring. The announced allocations total $29.5 million; they are settlement payments and employee relief, not a fine imposed after trial.
- The Justice Department says whistleblower Tim Booher will receive approximately $4.4 million from the federal share. The settlement resolves alleged conduct and contains no judicial finding that Lockheed violated the False Claims Act or Title VII.
- Associated Press reported Lockheed's response that the company denied wrongdoing and liability and settled to avoid the cost and distraction of prolonged litigation. The company said its policies prohibit employment discrimination and that it would continue compliance and training efforts.

## SIGNIFICANCE

The agreements use federal contracting and civil-rights enforcement to impose monetary and compliance consequences on a major defense contractor. Their practical value depends on payments, monitoring, policy changes and future hiring outcomes; settlement does not convert disputed allegations into adjudicated facts.

## GOALPOST / RESPONSE

DOJ and EEOC say the agreements protect fair competition for federally funded jobs and stop collection of demographic information that could deter referrals. Lockheed denies wrongdoing and says it settled to avoid prolonged litigation. The tests are completed payments, claimant distribution, verified policy changes, monitoring findings, recurrence and any later enforcement.

## MAYBE / THEREFORE

Maybe the settlements correct referral practices and deter discrimination, or payment and training may not produce durable hiring changes. Therefore the archive records signed monetary and compliance agreements resolving allegations—not an admission, a trial verdict or proof of future effectiveness.


## SOURCES

- [DOJ — Lockheed Martin agrees to $29.5 million employment-discrimination settlement](https://www.justice.gov/usao-ndtx/pr/lockheed-martin-agrees-pay-295m-resolve-alleged-employment-discrimination-violations) — primary settlement announcement and agency explanation of alleged conduct and monetary terms
- [EEOC — Lockheed Martin agrees to pay $29.5 million to resolve alleged employment discrimination](https://www.eeoc.gov/index.php/newsroom/lockheed-martin-agrees-pay-295-million-resolve-alleged-employment-discrimination) — primary agency settlement announcement and compliance terms
- [AP — Lockheed Martin to pay $29.5 million in federal employment-practice settlements](https://apnews.com/article/5c6f6fa12858a9c586d6bf57eb571c68) — independent reporting and attributed company response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
