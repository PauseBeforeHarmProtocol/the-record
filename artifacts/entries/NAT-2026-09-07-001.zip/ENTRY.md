# Trump threatens to bar Bombardier sales unless the company manufactures in the United States

**Entry ID:** NAT-2026-09-07-001
**Date:** September 7, 2026
**Checked:** 2026-09-07 6:10 PM EDT
**Evidence state:** Trump's public post establishes the announcement; Reuters independently reported the statement, prior unimplemented threats, existing regulatory and trade status, U.S. footprint and the absence of an identified enforcement mechanism. No implementing instrument or measured result was public by cutoff.
**Review state:** current-standard-reviewed

The president announced a market-access threat during a Canada trade dispute, but no implementing instrument or sales prohibition was public by cutoff.

## THE FACTS

- On September 7, President Trump wrote on Truth Social that Bombardier would no longer be allowed to sell aircraft in the United States unless it manufactured in the country. The post establishes that he announced the threat; it does not by itself create or prove an enforceable sales ban.
- Reuters reported that the White House did not answer how the administration would enforce the statement or bar deliveries of Bombardier jets already approved by the Federal Aviation Administration. By cutoff, the reviewed sources identified no executive order, tariff notice, customs directive, FAA decertification or other implementing instrument.
- Reuters reported that Bombardier aircraft comply with the United States-Mexico-Canada Agreement and that the company has about 3,500 U.S. workers, 2,800 U.S. suppliers, Texas wing production, a Kansas special-mission aircraft factory and U.S. operators for roughly half of its 5,100-aircraft global fleet.
- Trump said Canada had unfairly blocked Gulfstream and other U.S. businesses and framed domestic production as the condition for continued access to the U.S. market. Those are the president's stated rationale and claims, not independent findings established by the post.
- In January, Trump had threatened 50% tariffs on Canadian-made aircraft and decertification of some Bombardier jets. Reuters reported that neither measure occurred and that Canada subsequently certified several Gulfstream aircraft. No canceled Bombardier order or halted U.S. delivery was reported from the September statement by cutoff.

## SIGNIFICANCE

A presidential threat to exclude a major aircraft manufacturer can create immediate commercial and regulatory uncertainty even before any legal instrument exists. Bombardier's substantial U.S. workforce, supplier network and U.S.-made components mean that any later restriction could also affect American workers, operators and manufacturers; those effects remain prospective and unmeasured.

## GOALPOST / RESPONSE

Trump presents market access as leverage for reciprocal treatment of U.S. companies and more domestic aircraft manufacturing. A published legal authority and implementing instrument, FAA or customs action, actual delivery or sales restrictions, Canadian concessions, new U.S. production and measured effects on customers, workers and suppliers are the tests.

## MAYBE / THEREFORE

Maybe the threat is negotiating leverage that produces greater Canadian market access or additional U.S. production without disrupting current orders, or it may remain rhetoric like the unimplemented January tariff and decertification threats. Therefore the record establishes a presidential sales-ban threat and its stated condition—not an operative prohibition, revoked aircraft approval, imposed tariff, stopped delivery or demonstrated economic result.


## SOURCES

- [Donald Trump Truth Social post — Bombardier sales threat](https://truthsocial.com/@realDonaldTrump/117230978314061095) — primary evidence that the president published the stated sales threat and domestic-manufacturing condition; not independent verification of claims inside the post
- [Reuters — Trump threatens to bar Bombardier sales unless it manufactures in the United States](https://www.reuters.com/business/aerospace-defense/trump-says-canadas-bombardier-cannot-sell-us-unless-it-builds-there-2026-09-07/) — independent reporting on the announced threat, lack of an identified enforcement mechanism, prior unimplemented threats and Bombardier's U.S. footprint

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
