# FinCEN and Federal Reserve withdraw proposed $250 cross-border transfer threshold

**Entry ID:** NAT-2026-11-06-004
**Date:** November 6, 2026
**Checked:** 2026-11-07 12:07 PM EST
**Evidence state:** primary FinCEN announcement and jointly filed withdrawal notice plus independent banking-trade reporting; proposal withdrawn, existing rule retained, future rulemaking and effects unresolved
**Review state:** current-standard-reviewed

The agencies ended a 2020 proposal rather than changing the current rule; the existing $3,000 threshold remains unless a new rulemaking proceeds with another opportunity for comment.

## THE FACTS

- FinCEN and the Federal Reserve jointly withdrew a 2020 notice of proposed rulemaking that would have changed recordkeeping and Travel Rule obligations for certain cross-border transfers and digital assets. The withdrawal notice was filed for public inspection on November 6 and scheduled for Federal Register publication on November 9.
- The proposal would have lowered the threshold for covered transfers that begin or end outside the United States from $3,000 to $250. Withdrawing the proposal means no final rule will issue from that docket; it does not repeal the existing Recordkeeping or Travel Rules, and the current $3,000 threshold remains.
- The withdrawn proposal also would have clarified that convertible virtual currency and certain digital assets fall within the rule's treatment of money. Because the proposal never became final, the withdrawal is a formal reversal of a proposed expansion, not a completed rollback of an already implemented $250 requirement.
- The agencies cited comments that the lower threshold could impose significant burden, particularly on smaller financial institutions, and said withdrawal would give the public certainty that no final rule would issue without another opportunity to comment. The notice leaves any future proposal, compliance costs and enforcement effects unresolved.

## SIGNIFICANCE

The withdrawal ends a six-year-old proposal that would have expanded low-dollar cross-border reporting and explicitly addressed digital assets. Its immediate effect is regulatory certainty and preservation of the current threshold, not a measured change in illicit-finance detection or compliance costs.

## GOALPOST / RESPONSE

The agencies present withdrawal as a response to burden concerns and a guarantee of another public-comment opportunity before any final rule. The tests are any new notice, cost analysis, comment record, final rule, compliance guidance and measured effects on reporting, smaller institutions and illicit-finance detection.

## MAYBE / THEREFORE

Maybe retaining the $3,000 threshold avoids disproportionate compliance burden, or it may leave fewer low-dollar cross-border transfers subject to recordkeeping than the abandoned proposal contemplated. Therefore the 2020 proposal is withdrawn and the current threshold remains—not that the underlying policy debate or digital-asset risks are resolved.


## SOURCES

- [FinCEN — withdrawal of proposed Recordkeeping and Travel Rule amendments](https://www.fincen.gov/news/news-releases/fincen-announces-withdrawal-proposed-rule-related-recordkeeping-and-travel-rule) — primary agency announcement of a jointly withdrawn notice of proposed rulemaking
- [FinCEN and Federal Reserve — withdrawal of proposed cross-border transfer and digital-asset rule](https://public-inspection.federalregister.gov/2026-22809.pdf) — primary filed withdrawal notice; scheduled for November 9 publication
- [ABA Banking Journal — FinCEN and Fed withdraw international-transfer threshold proposal](https://bankingjournal.aba.com/2026/11/fincen-fed-withdraw-proposal-to-lower-international-fund-transfer-recordkeeping-threshold/) — independent trade-press reporting on the proposal, withdrawal and retained threshold

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
