# Court bars renewed Reflecting Pool vandalism prosecution

**Entry ID:** NAT-2026-10-01-001
**Date:** October 1, 2026
**Checked:** 2026-10-01 12:04 PM EDT
**Evidence state:** two independent reports describing and quoting the dismissal order and government filing; charge dismissed with prejudice, broader repair responsibility unresolved
**Review state:** current-standard-reviewed

A D.C. judge dismissed David Hearn's felony charge with prejudice after the government sought dismissal; the order prevents refiling but does not decide every repair dispute.

## THE FACTS

- On October 1, D.C. Superior Court Judge Todd Edelman dismissed with prejudice the felony property-destruction charge against former Olympic kayaker David Hearn over damage to the Lincoln Memorial Reflecting Pool. The disposition bars prosecutors from refiling that charge.
- The Justice Department had moved to dismiss after Interior Department evidence indicated that a flawed or unsuccessful repair installation, rather than vandalism by Hearn, caused the condition at issue. The government asked for dismissal without prejudice so it could refile if new evidence emerged.
- President Trump had publicly criticized an earlier dismissal, and U.S. Attorney Jeanine Pirro's office argued that a grand jury should be able to consider new evidence. Edelman concluded that exceptional circumstances justified finality and that the government should not compound its earlier errors by leaving Hearn exposed to renewed prosecution.
- The order resolves this criminal charge. It does not establish civil liability, adjudicate every contractor or agency failure, measure the full cost of pool repairs or decide the outcome of the broader Reflecting Pool project.

## SIGNIFICANCE

The with-prejudice disposition converts a previously unresolved prosecution and contractor-evidence lead into a final trial-court bar on refiling this charge. It also documents a limit on renewed prosecutorial leverage after the government acknowledged evidence inconsistent with its original theory.

## GOALPOST / RESPONSE

The Justice Department said dismissal was appropriate on the existing record but sought the ability to refile if new evidence emerged; administration officials had framed the episode as vandalism deserving prosecution. The concrete tests are any lawful appellate challenge, disclosed investigative findings and separate repair-accountability proceedings—not rhetoric or the dismissed accusation.

## MAYBE / THEREFORE

Maybe the dismissal reflects a case-specific correction once contrary evidence surfaced, or it may illustrate the risk of political pressure sustaining a weak prosecution. Therefore the established result is a with-prejudice dismissal of Hearn's charge—not a finding that every official acted improperly or a complete adjudication of the pool's repair history.


## SOURCES

- [Associated Press — Reflecting Pool prosecution dismissed with prejudice](https://apnews.com/article/trump-reflecting-pool-olympian-david-hearn-8404849d27c85e210cc5a895c150645a) — independent reporting on court disposition and government position
- [Washington Post — judge bars renewed Reflecting Pool prosecution](https://www.washingtonpost.com/dc-md-va/2026/10/01/judge-says-us-cant-prosecute-ex-olympian-again-reflecting-pool-case/) — independent reporting quoting and describing the dismissal order

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
