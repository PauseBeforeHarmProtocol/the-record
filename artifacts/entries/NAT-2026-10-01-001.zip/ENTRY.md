# Court bars renewed Reflecting Pool vandalism prosecution

**Entry ID:** NAT-2026-10-01-001
**Date:** October 1, 2026
**Checked:** 2026-10-21 11:57 AM EDT
**Evidence state:** two independent reports described the dismissal order and government filing; Associated Press reported the inspector general's jurisdictional response and defense request for reconsideration; misconduct allegations remain unadjudicated
**Review state:** current-standard-reviewed

A D.C. judge dismissed David Hearn's felony charge with prejudice after the government sought dismissal; the order prevents refiling but does not decide every repair dispute.

## THE FACTS

- On October 1, D.C. Superior Court Judge Todd Edelman dismissed with prejudice the felony property-destruction charge against former Olympic kayaker David Hearn over damage to the Lincoln Memorial Reflecting Pool. The disposition bars prosecutors from refiling that charge.
- The Justice Department had moved to dismiss after Interior Department evidence indicated that a flawed or unsuccessful repair installation, rather than vandalism by Hearn, caused the condition at issue. The government asked for dismissal without prejudice so it could refile if new evidence emerged.
- President Trump had publicly criticized an earlier dismissal, and U.S. Attorney Jeanine Pirro's office argued that a grand jury should be able to consider new evidence. Edelman concluded that exceptional circumstances justified finality and that the government should not compound its earlier errors by leaving Hearn exposed to renewed prosecution.
- The order resolves this criminal charge. It does not establish civil liability, adjudicate every contractor or agency failure, measure the full cost of pool repairs or decide the outcome of the broader Reflecting Pool project.
- On October 21, the Justice Department inspector general declined a defense request to investigate the handling of the prosecution, saying the alleged professional misconduct fell outside the inspector general's jurisdiction and within the Office of Professional Responsibility's remit. Hearn's lawyers asked for reconsideration; their misconduct allegations remain unadjudicated, and AP reported no immediate DOJ or inspector-general comment beyond the letter.

## SIGNIFICANCE

The with-prejudice disposition remains a final trial-court bar on refiling this charge. The inspector general's jurisdictional refusal closes one requested watchdog route without resolving the defense allegations or establishing misconduct, leaving any Office of Professional Responsibility review as the relevant internal channel.

## GOALPOST / RESPONSE

The Justice Department said dismissal was appropriate on the existing record but sought the ability to refile if new evidence emerged; administration officials had framed the episode as vandalism deserving prosecution. The concrete tests are any appellate action, disclosed OPR findings and separate repair-accountability proceedings—not the inspector general's jurisdictional response or the dismissed accusation alone.

## MAYBE / THEREFORE

Maybe the dismissal reflects a case-specific correction and the referral boundary is routine, or the sequence may illustrate inadequate scrutiny of a politically charged prosecution. Therefore the record establishes a with-prejudice dismissal and an inspector-general jurisdictional refusal—not proven professional misconduct or a complete adjudication of the pool's repair history.


## SOURCES

- [Associated Press — Reflecting Pool prosecution dismissed with prejudice](https://apnews.com/article/trump-reflecting-pool-olympian-david-hearn-8404849d27c85e210cc5a895c150645a) — independent reporting on court disposition and government position
- [Washington Post — judge bars renewed Reflecting Pool prosecution](https://www.washingtonpost.com/dc-md-va/2026/10/01/judge-says-us-cant-prosecute-ex-olympian-again-reflecting-pool-case/) — independent reporting quoting and describing the dismissal order
- [Associated Press — DOJ inspector general declines Hearn-prosecution review](https://apnews.com/article/2206ea05e0f543610b447d73a0a8c2d2) — independent reporting on the inspector general's jurisdictional disposition and the defense request for reconsideration

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
