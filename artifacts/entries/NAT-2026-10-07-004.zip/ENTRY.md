# CMS and CDC propose nationwide CLIA modernization

**Entry ID:** NAT-2026-10-07-004
**Date:** October 7, 2026
**Checked:** 2026-10-07 12:18 PM EDT
**Evidence state:** primary CMS/CDC proposed rule; modernization proposed, compliance burden projected, laboratory and patient outcomes unmeasured
**Review state:** current-standard-reviewed

The laboratory proposal would codify virtual access, update personnel and proficiency rules, and remove COVID-19 reporting language.

## THE FACTS

- CMS and CDC filed a proposed rule for October 8 publication that would allow qualified personnel to review digital laboratory data, results, live images and digital images from remote locations under the primary laboratory's CLIA certificate, subject to specified safeguards and director accountability. The proposal is not final.
- Virtual access would not cover cytology screening or physical-slide review, which must occur at a separately certified site. The proposal also would allow digital images in gynecologic cytology proficiency testing and revise laboratory-personnel qualification pathways.
- Other proposed changes would remove SARS-CoV-2 reporting provisions, revise certificate and test-report requirements, expand alternative-sanction language and update enforcement and consultation provisions. The agencies say the package responds to technology, workforce shortages and administrative burden while retaining quality standards.
- The agencies estimate one-time information-collection costs of about $25.3 million to $48.2 million plus $4.62 million in annual ongoing burden, for a one-time-plus-ongoing total of about $29.9 million to $52.8 million. These are projected compliance burdens, not measured patient-safety or access outcomes.

## SIGNIFICANCE

The proposal would convert pandemic-era remote-review flexibility into a national regulatory framework and revise workforce and oversight rules across clinical laboratories. Its value depends on accuracy, security, access, staffing and enforcement after any final rule.

## GOALPOST / RESPONSE

The agencies say modernization can reduce burden and workforce constraints without weakening accurate, timely and reliable testing. Error rates, proficiency performance, cyber and privacy incidents, staffing access, survey findings and compliance cost are the tests.

## MAYBE / THEREFORE

Maybe regulated virtual review and updated qualification paths expand expertise and efficiency, or dispersed work may create oversight, security or quality risks. Therefore the agencies have proposed safeguards and estimated burden; they have not yet finalized the rules or demonstrated outcomes.


## SOURCES

- [CMS and CDC — CLIA modernization proposed rule](https://public-inspection.federalregister.gov/2026-20613.pdf) — official Federal Register public-inspection proposed rule

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
