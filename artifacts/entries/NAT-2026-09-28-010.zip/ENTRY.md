# States petition court to set aside FAA drone-delivery environmental review

**Entry ID:** NAT-2026-09-28-010
**Date:** September 28, 2026
**Checked:** 2026-09-28 11:59 PM EDT
**Evidence state:** file-stamped appellate petition and independent Reuters reporting; challenge filed, allegations unadjudicated and no stay or merits ruling located
**Review state:** current-standard-reviewed

Fifteen states and Harris County challenge the agency's nationwide assessment; the petition requests review but creates no injunction or final ruling.

## THE FACTS

- Fifteen states and Harris County filed a petition in the U.S. Court of Appeals for the Second Circuit on September 28 seeking review and vacatur of the FAA and Transportation Department's final programmatic environmental assessment, finding of no significant impact and record of decision for drone package-delivery operations.
- The petitioners allege that the review inadequately assessed environmental and safety effects. Those allegations are not findings, and the filing produced no injunction, stay or merits ruling by cutoff.
- The challenged decision supports the agency's work toward broader beyond-visual-line-of-sight commercial drone rules. The proposed rule had not been finalized, and Reuters reported that existing waiver-based operations could continue.
- The FAA did not immediately respond to Reuters. Later agency filings, judicial relief, the final rule, site-specific review and independently measured noise, safety and environmental outcomes remain the tests.

## SIGNIFICANCE

The formal appellate challenge targets the environmental foundation for nationwide expansion of commercial drone delivery. It may affect the regulatory path, but it has not invalidated an agency decision or stopped existing operations.

## GOALPOST / RESPONSE

The FAA has framed nationwide assessment and beyond-visual-line-of-sight rules as a path to safer and more scalable drone operations. The petitioners argue that a programmatic review understates local environmental and safety effects. The agency response, court orders, final rule and operational evidence are the tests.

## MAYBE / THEREFORE

Maybe a programmatic assessment can adequately bound nationwide effects with later site-specific safeguards, or local variation may require fuller review before expansion. Therefore the record verifies the filed challenge and its requested relief—not the allegations, a court victory or suspension of drone delivery.


## SOURCES

- [Petition for review of FAA drone package-delivery environmental decision](https://oag.ca.gov/system/files/attachments/press-docs/petition-reviewny-v-faa-usdot.pdf) — court filing
- [States challenge FAA environmental review for commercial drone package rules](https://www.reuters.com/world/us-states-challenge-faa-environmental-review-commercial-drone-package-rules-2026-09-28/) — independent reporting

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
