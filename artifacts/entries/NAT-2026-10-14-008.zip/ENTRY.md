# GAO finds management gaps in CBP and ICE body-camera programs

**Entry ID:** NAT-2026-10-14-008
**Date:** October 14, 2026
**Checked:** 2026-10-14 11:56 PM EDT
**Evidence state:** primary GAO performance audit and agency response plus independent Reuters reporting; findings and recommendations are final audit results, corrective actions and broader deployment remain incomplete or unverified
**Review state:** current-standard-reviewed

The audit found stale plans, weak outcome measures and operational-guidance gaps; DHS accepted six recommendations but rejected automatic activation for ICE cameras.

## THE FACTS

- The Government Accountability Office publicly released GAO-26-108157 on October 14 after an audit conducted from February 2025 through September 2026. GAO examined Customs and Border Protection and Immigration and Customs Enforcement body-worn-camera program management, operational guidance and controls.
- GAO reported that CBP had deployed about 11,500 cameras as of June 2026, nearly all to Border Patrol, and ICE about 4,800 as of April 2026, divided almost evenly between Enforcement and Removal Operations and Homeland Security Investigations. The audit says the agencies continued supporting deployed cameras after pausing further deployment in 2025; those counts do not establish that every encounter was recorded.
- GAO found that CBP's and ICE's program plans, last updated in 2022 and 2024 respectively, did not reflect changes in costs, schedules, requirements and risks. It also found that the programs lacked results-oriented performance goals and that most offices had not supplied operation-specific recording guidance for personnel whose work differs from routine patrol or arrest activity.
- GAO made seven recommendations. DHS agreed with six, including updating plans, creating performance goals, developing additional operational guidance and improving cross-system information about significant incidents and available footage.
- DHS rejected GAO's recommendation that ICE add controls such as automatic activation. It cited false or inadvertent activation during routine movement and risks of recording confidential informants, victims, sensitive interactions, bystanders or protected First Amendment activity. GAO said the response did not address environments where automatic activation might work or alternative activation controls.
- A DHS spokesperson told Reuters that ICE had acquired enough cameras for all officers and would begin training for broader use. That is an administration statement about capacity and planned training, not independent proof of completed universal deployment, activation compliance or program effectiveness.

## SIGNIFICANCE

Body cameras are a major accountability control for federal immigration enforcement. The audit documents concrete program-management and guidance gaps across thousands of deployed devices while preserving DHS's privacy and operational objections to one proposed technical control.

## GOALPOST / RESPONSE

DHS and the components accepted six recommendations and say broader ICE deployment and training are advancing. Tests include dated corrective-action plans, updated program baselines, measurable outcome goals, office-specific guidance, deployment and training completion, activation and footage-availability data, privacy incidents and GAO closure of each recommendation.

## MAYBE / THEREFORE

Maybe the accepted management reforms and broader deployment will improve evidence and accountability, while automatic activation could create genuine privacy and operational harms; or weak activation controls and stale planning may continue to leave important encounters undocumented. Therefore the record captures an evidence-based federal audit and an agency disagreement over one safeguard—not proof of a specific civil-rights violation, universal camera nonuse or measured program failure.


## SOURCES

- [GAO — CBP and ICE Should Improve Body-Worn Camera Program Management](https://files.gao.gov/reports/GAO-26-108157/index.html) — primary performance audit, recommendations and agency response
- [Reuters — administration rejects automatic-activation recommendation for ICE body cameras](https://www.reuters.com/world/us-rejects-recommendation-ice-body-cams-be-automatically-activated-2026-10-15/) — independent reporting on GAO findings and administration response

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
