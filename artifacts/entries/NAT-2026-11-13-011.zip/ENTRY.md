# HHS finalizes repeal of Head Start wage and benefit requirements

**Entry ID:** NAT-2026-11-13-011
**Date:** November 13, 2026
**Checked:** 2026-11-14 6:05 AM EST
**Evidence state:** Federal Register public-inspection final rule plus Associated Press reporting and the National Head Start Association response; finalized and scheduled for publication, not yet effective or measured
**Review state:** current-standard-reviewed

The rule removes the 2024 compensation mandates, including public-preschool pay comparability for larger programs; publication is scheduled for November 16 and the rule is not yet effective.

## THE FACTS

- The Administration for Children and Families finalized Restoring Flexibility to Support Head Start Program Access. The public-inspection copy identifies the action as a final rule scheduled for Federal Register publication on November 16, 2026, with an effective date 60 days after publication.
- The final rule removes the 2024 wage and benefit requirements in 45 C.F.R. § 1302.90(e) and (f). The rescinded provisions would have required programs to develop or update pay scales, move education-staff pay toward public-preschool comparability, cover basic living costs, promote comparability across Head Start and Early Head Start, and provide specified benefits.
- ACF estimated that the rescission would produce more than $2 billion in future cost savings and said the prior requirements were costly, overly prescriptive and risked reducing funded slots without additional appropriations. The agency also acknowledged that workforce challenges may persist and said programs may voluntarily retain compensation increases within their budgets.
- The National Head Start Association called the choice between staff pay and preserving slots false, arguing that staffing shortages already prevent some classrooms from opening and that stable compensation requires additional federal investment. AP independently reported the administration's access rationale and advocates' recruitment-and-retention objection.
- The action is finalized but was not yet published or effective at the evidence cutoff. It does not require programs to reverse salary increases already made, and the inspected material does not measure future enrollment, staffing, turnover or classroom capacity after implementation.

## SIGNIFICANCE

The final rule materially reverses a national workforce policy before its principal 2031 requirements took effect. It may preserve program slots under fixed appropriations, but removing compensation standards can also affect recruitment, retention and the ability to staff those slots; neither outcome has yet been measured.

## GOALPOST / RESPONSE

The administration's access rationale can be tested after implementation through funded and occupied enrollment slots, classroom closures, vacancies, turnover, wages and benefits, service quality and congressional appropriations. Claimed savings should remain separate from demonstrated access or workforce outcomes.

## MAYBE / THEREFORE

Maybe local flexibility will let programs preserve more funded places, or removing federal compensation floors may deepen staffing shortages and leave slots unusable. Therefore the record establishes a finalized rescission scheduled to take effect 60 days after publication—not an already effective rule or proof of improved access, lower turnover or reduced service quality.


## SOURCES

- [Federal Register public-inspection copy — Restoring Flexibility to Support Head Start Program Access](https://public-inspection.federalregister.gov/2026-23279.pdf) — primary final rule scheduled for November 16 publication; operative wage-and-benefit rescission and effective-date text
- [Associated Press — Trump administration cancels mandatory Head Start pay hike](https://apnews.com/article/5fa1e755af4d46c48f6288132292afda) — independent reporting on the finalized rule, affected requirements, administration rationale and workforce objections
- [National Head Start Association — response to final workforce-compensation rule](https://nhsa.org/about-nhsa/newsroom/press-releases/acf-releases-final-rule-on-head-start-workforce-compensation/) — stakeholder response on compensation, staffing and program-access tradeoffs

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
