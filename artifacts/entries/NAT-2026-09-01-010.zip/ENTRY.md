# FEMA discloses more than $66 million in regional recovery and resilience approvals

**Entry ID:** NAT-2026-09-01-010
**Date:** September 1, 2026
**Checked:** 2026-09-02 12:00 AM EDT
**Evidence state:** three primary FEMA funding announcements plus the separate Truth Social feed as a research lead; agency approvals reported, disbursement, expenditure, project completion and outcomes unresolved
**Review state:** current-standard-reviewed

Three coordinated agency releases document approved funding for New England, Montana and South Dakota; approval is not the same as completed disbursement or measured recovery.

## THE FACTS

- FEMA published three regional announcements on September 1 saying it had approved nearly $50 million for communities in Connecticut, Maine, Massachusetts, New Hampshire and Vermont; more than $10 million for Montana; and more than $6.6 million for South Dakota.
- The agency described the funds as post-disaster recovery and resilience support. The announcements establish agency approval of more than $66 million in aggregate across the three grouped releases, but they do not establish that every dollar had been obligated, drawn down or spent by recipients by cutoff.
- Trump separately posted several state- and tribal-specific disaster-aid amounts after the prior feed check. Those posts establish what the president announced; only awards supported by located FEMA releases are treated here as agency-confirmed actions, and the other posted amounts remain outside the canonical record pending an award instrument or independent confirmation.
- The releases did not measure whether funded projects were completed, reduced future losses or improved recovery outcomes. Those results require later project, expenditure and audit data.

## SIGNIFICANCE

The grouped approvals direct material federal resources to disaster recovery and mitigation across multiple regions while avoiding a separate archive record for each routine grant. Their public value depends on later obligations, recipient use, completion and measured resilience rather than announcement totals alone.

## GOALPOST / RESPONSE

FEMA says the funding helps states, tribes and local communities recover while strengthening locally led resilience and protecting taxpayer value. Critics of the administration's disaster policy may question delays, conditions, distribution and whether approvals translate into timely aid. Award documents, obligations, drawdowns, project completion, audits and loss-reduction outcomes are the tests.

## MAYBE / THEREFORE

Maybe the approvals will finance effective locally selected recovery and mitigation projects, or funds may be delayed, underspent or produce uneven results. Therefore the record confirms more than $66 million in FEMA-approved funding disclosed through three grouped releases—not universal delivery, completed projects, audited spending or proven resilience gains.


## SOURCES

- [FEMA — nearly $50 million in New England recovery and resilience funding](https://www.fema.gov/press-release/20260901/trump-administration-delivers-nearly-50-million-through-fema-help) — primary agency announcement of approved regional post-disaster funding
- [FEMA — more than $10 million in Montana recovery funding](https://www.fema.gov/press-release/20260901/trump-administration-delivers-more-10-million-through-fema-help-communities) — primary agency announcement of approved disaster-recovery funding
- [FEMA — more than $6.6 million in South Dakota recovery and resilience funding](https://www.fema.gov/press-release/20260901/trump-administration-delivers-more-66-million-through-fema-help-communities) — primary agency announcement of approved post-disaster funding

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
