# NATIONAL update pack

Release: 10.39.0 · September 9, 2026
Editorial cutoff: 2026-09-09 6:00 AM EDT
Contains 160 national records. 4 records were added or materially refreshed in this run.
