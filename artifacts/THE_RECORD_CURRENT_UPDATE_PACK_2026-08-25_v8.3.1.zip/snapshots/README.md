# Preserved snapshots

`THE_RECORD_IN6_UPDATE_BRIEF_2026-07-18.md` is the immutable July 18 IN-6 brief. The current canonical IN-6 brief for release 8.3.1 is `../THE_RECORD_IN6_CURRENT_BRIEF_2026-08-25_v8.3.1.md`. The snapshot and current per-entry packs must not be treated as one contemporaneous package.
