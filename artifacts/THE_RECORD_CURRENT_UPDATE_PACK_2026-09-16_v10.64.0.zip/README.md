# The Record current update pack

Release: 10.64.0
Release date: September 16, 2026
Editorial/base-release cutoff: 2026-09-16 6:31 AM EDT

Contains 218 national and 4 IN-6 current-layer records. Each brief and entry pack preserves the individual record's evidence-check time; the release cutoff does not imply that every record was re-researched on that date. The national and IN-6 briefs at the pack root are generated from the current canonical layer. A separately labeled snapshots directory preserves the immutable July 18 IN-6 brief without presenting it as current. The full searchable Trump archive renders 4,949 active canonical/bridged entries. It retains 11 duplicate tombstones outside that count. External archive units and normalized crosslinks remain separate until source review and deduplication promote a distinct event.
